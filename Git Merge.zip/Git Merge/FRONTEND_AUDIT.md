# YOUR CHOICE — frontend audit

**18 November 2026 · Read-only inspection of the supplied deployment**  
Companion: `FRONTEND_INVENTORY.json` (route declarations, render evidence, component/control index, data shapes and comparison keys).

## Conclusion

The deployed application declares **79 page routes implemented by 70 distinct page components**. It has a substantial browser implementation: the cart merges line items, the 2D editor changes an SVG layer document, and the admin console edits its own catalogue. **None of those operations establishes a business API.** The checkout handler creates an order in local storage; the publisher adds a local submission; “mark paid” changes an admin record. These are three different stores, not stages of a verified transaction.

The supplied text file contains only `agent deployment: https://your-choice-phase03-qt9x.arcada.app`. There was **no source checkout, Git history, repository archive, or Codex backend audit** in the workspace. Coverage below is complete for the **route declarations in the inspected build**, not for unpublished files or branches. No backend comparison has been performed.

## What was inspected, and what the evidence means

- Read the local copy of the 61-byte attachment, fetched the referenced HTML and its linked JS/CSS, and parsed the complete JS entry module. Build fingerprint: `/assets/index-DgdAw_6D.js`, 1,307,694 bytes, SHA-256 `bf1fe9f0472bb7f1335a91838fb14dd5fe671faf3d408fae8fcbae00b02c504d`. CSS: `/assets/index-DSn37VE-.css`. The bundle contains source-location tags for **32 TSX paths**; those tags are not source files. No `sourceMappingURL` was advertised in the entry module.
- Reconstructed nested routes from `src/App.tsx:77–130`, including index children, reused elements, mode props, redirects and the wildcard. Replayed the unchanged shell/module/stylesheet in a disposable Chromium context, using fixture IDs for detail pages. Checked **96 client navigations**: 79 pages, 16 redirects and one unmatched URL. Layouts were exercised through their children. Every page sample rendered its expected tagged module; every redirect reached its declared target.
- Replay did not test server rewrites: each document navigation was given the fetched shell. Images, external scripts and outbound requests were blocked. The blocked host page-view POST produced `Failed to fetch` in the replay; it was not a failed order or catalogue request. No live form submission, file upload, financial operation, admin action, package installation or source change was performed. App initialization wrote its sample data only in the disposable browser profile.
- **Rendered** = present in the initial DOM. **Wired** = a control can be traced to a handler, state setter, navigation, export or provider in the build; it is not a successful end-to-end test. **Local** = component memory or same-origin browser storage, as specified. **Not evidenced** = no supporting implementation found in this artifact, not proof that a service does not exist elsewhere. All counts and financial examples below describe fixtures, not real inventory, customers or revenue.

### Count reconciliation

| Area | Page routes | Distinct page components | Why counts differ |
|---|---:|---:|---|
| Public Website | 28 | 24 | Collection detail has two paths, product detail three, confirmation two. |
| Customer | 8 | 8 | One index and seven nested pages. |
| Marketplace | 9 | 6 | Explore, featured, trending and category detail share a list implementation. |
| Creator | 9 | 9 | One index and eight nested pages. |
| Design Studio | 5 | 5 | Landing, mode, blanks and two editors. |
| Admin | 20 | 18 | Dashboard has two paths; create/edit share the product form. |
| **Total** | **79** | **70** | **Plus 4 layout declarations, 16 client redirects and 1 wildcard = 100 declarations.** |

The `/account`, `/marketplace`, `/creator` and `/admin` layout paths each also have an index page. A sample slug, query, tab, modal, form step, or new page of table rows is **not** counted as a separate route.

## Page and action register

Each row covers one implementation; backticked paths in the same cell are separate declarations. The **Build key** joins to `components` in the JSON. There, `source` + `at` identifies a control's embedded source location; `routes[].declaration` identifies its registration. Data keys refer to the comparison register below, **not** existing API names.

### Public Website

| Build key | Route(s) | Features and wired actions | Data / boundary | Data keys |
|---|---|---|---|---|
| yA | `/` | Editorial landing, category and sort controls, selectable product orbit/rail, shop links, Studio waitlist and newsletter. | Bundled products; animation and filtering in browser. Signup displays timed feedback. | CAT, CARE |
| jA | `/shop` | Search catalogue text; filter category, colour family, size, fit and price band; sort, reset, hide filters, change 2/3/4-column view, open size guide. | Filters the local product array, not server search or available stock. | CAT |
| PA | `/collections/t-shirts` | Tee substyle and size filters, price/featured sorting, tee fit guide and product cards. | Category subset of the store catalogue. | CAT |
| vA | `/collections/polo-shirts` | Polo construction/substyle filter, sort, fit guide, product/variant navigation. | Polo subset of the same fixture. | CAT |
| nj | `/collections`, `/collections/:slug` | Collection story, hero, ordered featured pieces and links to other collections. | Joins collection.featuredSlugs to products; absent/unknown slug shows first collection. | CAT |
| dm | `/product/:slug`, `/product`, `/product-details` | Front/detail/editorial gallery, zoom dialog, colour links, size and quantity, low-stock cue, care/fit/delivery sections, wishlist, add or buy now. | Unknown slug falls back to second product. Add checks size; express checkout chooses L or first size if unset. Detail crops reuse the product image. | CAT, CART |
| bA | `/search` | Query and suggestion chips, all/products/collections/care tabs, category and sort; updates `?q=`. | Matches local product, collection and FAQ strings; empty query presents suggestions/results. | CAT, CARE |
| CA | `/wishlist` | Pick per-product size, add one/all, remove/clear, restore sample board, share. | Persists product IDs. “Move” adds a bag line without removing the wish. Share copies current URL, not list contents or a public list ID. | CART |
| SA | `/bag` | Change size/quantity, remove line, toggle wish, promo form and chips, packaging and gift note, order estimate, checkout; sample quick-add when empty. | Line key is productId-size. Size collisions merge quantities. Promo/packaging/note are memory state, not persisted bag fields. | CART, ORDER |
| NA | `/checkout` | Contact, address, country, courier and payment-choice form; sample card fields, cost summary, empty-bag recovery, complete order. | Local timeout calls placeOrder, snapshots items and clears bag; pushes confirmation URL. No gateway, address-book lookup or courier call. | CART, ORDER |
| ij | `/order-confirmation`, `/order-confirmation/:orderId` | Receipt, item manifest, totals, address, method, tracking link, copy reference, print. | Case-insensitive local order lookup; missing/unknown reference displays first order, not a verified receipt. | ORDER |
| kA | `/order-tracking` | Enter reference, optional email, use sample references, view status steps/scan timeline, items and copy tracking code; `?order=`. | Looks up order number only. Email is not used for ownership verification. Explicit no-match branch. | ORDER |
| wA | `/login` | Sign-in form, password visibility, keep-signed-in control, demo login; member summary, switch/sign out. | Submit passes email to local loginMember; neither password nor persistence checkbox is used for authentication. | ID |
| AA | `/register` | Names, email, password strength/visibility, wardrobe focus, marketing and terms checkboxes; submit then login screen. | Accepted terms gate simulated registration. Saves local member name/email/preference, not credentials or a server account. | ID |
| EA | `/forgot-password` | Email form, confirmation state, simulated reset-link navigation. | No email sent; link constructs reset parameters in browser. | ID |
| DA | `/reset-password` | Reads email/token, two password fields, visibility, length/uppercase/number-or-symbol/match checks, success state. | Token has a local default; no validation with issuer or credential update. | ID |
| TA | `/about` | Brand identity, emblem, manufacturing/craft narrative, shop navigation and Studio waitlist. | Editorial copy and local signup UI; claims about production are not verified. | CARE |
| MA | `/contact` | Department, name, email, optional order reference and message; submit displays a case number. | Generates random `YC-CARE-…` in component state; no ticket creation, delivery or lookup. | CARE |
| OA | `/faq` | Search, category, expand/collapse entries and expand-all; contact navigation. | Reads 12 bundled Q&As. | CARE |
| RA | `/size-guide` | Category measurements, cm/in conversion, height/weight and fit-preference controls calculate recommended size. | Shared with fit modal; four chart families and local arithmetic, not a fit service or retained measurements. | CAT |
| zA | `/shipping-delivery` | Switch region to view service/duty/ETA information; track and returns links. | Static regional tables; displayed shipping commitments not live carrier data. | CARE, ORDER |
| LA | `/returns-refunds` | Order reference, exchange/refund choice, conditional replacement size and authorization result. | Generates random `RMA-YC-…`; no eligibility lookup, label, refund or return record. | CARE, ORDER |
| HA | `/privacy-policy` | Anchored policy sections, two cookie/privacy preferences and save button. | Toggles component state; save only toasts. No evidence it configures storage or host telemetry. | CARE |
| UA | `/terms-conditions` | Anchored legal sections and print/save PDF. | Calls browser print; no document-generation service or recorded terms acceptance here. | CARE |

### Customer

| Build key | Route(s) | Features and wired actions | Data / boundary | Data keys |
|---|---|---|---|---|
| YA | `/account` | Overview, order pulse/spend, wish/bag counts, latest order, recent projects, shortcuts to tracking, addresses, Studio and creator onboarding. | Mix of store orders/bag and separate seeded account profile/designs. Address shortcut literally says “2 saved addresses”. | ID, ORDER, ACCOUNT, DESIGN |
| VA | `/account/profile` | Edit identity/contact, birthday, usual size, fit and bio; discard or save. | Local account profile; avatar is initials, not an upload. Not the login member record. | ACCOUNT |
| GA | `/account/addresses` | Add/edit drawer; label, name, lines, city, postal code, country, phone and default flag; make default or delete non-default. | Local address IDs; setting default clears other defaults. Default-delete control disabled. | ACCOUNT |
| qA | `/account/orders` | Search order list, filter all/in progress/delivered, open detail, clear empty search. | Reads store orders, not an account-scoped request; delivered condition is statusStep 5. | ORDER |
| $A | `/account/orders/:orderId` | Manifest, totals, delivery, tracking journal; reorder all adds original product/size/quantity lines and navigates to bag. | Missing ID falls back to first local order; no stock reconciliation. | ORDER, CART |
| FA | `/account/designs` | Search shelf, start/open project, duplicate into a new draft and open it, delete local design. | Continue links always target 2D with `?project=`; seed entries can have null project data. | DESIGN |
| XA | `/account/wishlist` | Everything/garments/artwork filters; product and design cards support their respective save toggles. | Joins two independent ID lists to store products and marketplace designs. | CART, MARKET |
| KA | `/account/settings` | Notification/privacy switches, download my data, inline confirm restore, member sign-out or sign-in link. | JSON export is profile, addresses, designs, settings and timestamp, not all account data. Reset removes phase02 keys and re-seeds selected in-memory slices; not account deletion or a full store/admin reset. | ACCOUNT, ID |

### Marketplace

| Build key | Route(s) | Features and wired actions | Data / boundary | Data keys |
|---|---|---|---|---|
| WA | `/marketplace` | Featured selection, trending works, categories and creator spotlight; cards open artwork/creator, save design. | Eight curated listings, four creator fixtures. Featured landing section actually filters the featured flag. | MARKET |
| od | `/marketplace/explore`, `/marketplace/trending`, `/marketplace/featured`, `/marketplace/category/:slug` | Search title/tags/creator, category chips, filter panel, curated/trending/likes/newest/price sort, resets and empty state. | Trending route passes a mode and filters flagged works; featured route passes no featured-only mode. Category filter reads `?category=`, not `:slug`; `?q=` initializes search. | MARKET |
| JA | `/marketplace/categories` | Category editorial cards with descriptions, counts and discovery links. | Category metadata and design counts are bundled; navigating with category query is distinct from matching a path slug. | MARKET |
| eE | `/marketplace/design/:slug` | Garment front/back, dye and size, work/print/royalty tabs, like, follow, buy base, open 2D/3D remix, related work. | Joins design.creator to handle, design.productId to base. Unknown slug selects first work. Bag write has no design ID, chosen dye, listing price or royalty. | MARKET, CART, DESIGN |
| sE | `/marketplace/creator/:handle` | Creator profile, verification presentation, designs/about tabs, follow and copy-link share. | Looks up static handle or first creator. Local creator-profile overlay is special-cased for Sora; no public profile service. | MARKET, CREATOR |
| aE | `/marketplace/become-creator` | Three steps: identity/contact/location; portfolio, specialty, statement and originality; review and terms. Back/continue, validation message and sample success. | Writes one application with submittedAt to `yc-phase02-creator-application`; no admin queue insertion or role grant. | CREATOR |

### Creator

| Build key | Route(s) | Features and wired actions | Data / boundary | Data keys |
|---|---|---|---|---|
| tE | `/creator` | Dashboard, royalty chart, studio pulse, live originals, recent sales; links to publishing, submissions and earnings. | Local submissions/profile combined with fixed creator sales, not current revenue. | CREATOR, MONEY |
| rE | `/creator/designs` | Search, status filters, grid/list, listing/draft links and more-options action. Create study changes title/status/sales/earnings. | Create study patches the existing submission ID, not a new object. Draft can be moved into review. | CREATOR |
| cE | `/creator/publish` | Four steps: upload/drop or sample artwork, title/details/tags/category, blanks/colour/price, rights/review; save draft or submit. | FileReader checks image MIME and max 3 MiB. Local submission retains title/category/artwork/products/status/note; price, tags, description, preview colour and rights are not included in addSubmission payload. No draft-query hydration. | CREATOR, MARKET |
| lE | `/creator/submissions` | Filter by lane, select submission, view feedback, continue draft or mark changes complete. | Resubmission changes local status to In review. Continue links pass `?draft=`; publish initializes a new form. | CREATOR |
| nE | `/creator/earnings` | Period selector, gross/royalty and pending/cleared breakdowns, chart, design contribution. | Sample date comparisons and two named design IDs; “30 days” uses the sample ledger, not a rolling API. | MONEY |
| iE | `/creator/sales` | Query sales, filter design/status, reset; export current filtered ledger to CSV. | Browser Blob download with date, order, design, product, territory, quantity, gross USD, royalty USD and status. | MONEY |
| uE | `/creator/rewards` | Level progress and benefits; eligible claim, claimed and locked states. | Local claimed IDs and hardcoded benefit/level display. No entitlement delivery. | MONEY |
| pE | `/creator/payout` | Bank/PayPal presentation, holder, finance email, country, schedule, sample tax status; save/discard and sample balance. | Local preferences only; actual payout control disabled. No banking credentials verified or money sent. | MONEY |
| gE | `/creator/profile` | Display name/handle, location, role, bio, statement, specialty tags and commissions switch; save/discard and view profile. | Local creator profile patch. Editing a handle does not register a new public lookup key. | CREATOR, MARKET |

### Design Studio

| Build key | Route(s) | Features and wired actions | Data / boundary | Data keys |
|---|---|---|---|---|
| mE | `/studio` | Studio introduction, workflow anchor, blank previews, entry links to mode choice or editors. | Read-only presentation of sample blanks and example art. Separate from public early-access signup. | DESIGN |
| xE | `/studio/mode` | Compare flat composition and spatial preview; choose an editor. | Sends `mode=2d` or `mode=3d` to blank selector. | DESIGN |
| fE | `/studio/products` | Filter blank type, choose blank/dye, inspect material and continue. | Four static blanks. Reads `mode`/`type`; links pass product ID and colour, not a configured variant record. | CAT, DESIGN |
| PE | `/studio/2d` | Named front/back layer document; text/image/shape tools, transforms, layer stack, undo/redo, autosave, preview, SVG export, save and add base. | Local document and shelf. No remote assets workflow or print order. See editor findings below. | DESIGN, CART |
| vE | `/studio/3d` | Garment and artwork controls, orbit, lighting/material presentation, presentation mode, snapshot, save study and add base. | An SVG-based view simulation, not evidence of a mesh renderer, cloth engine or manufacturable model. | DESIGN, CART |

### Admin

| Build key | Route(s) | Features and wired actions | Data / boundary | Data keys |
|---|---|---|---|---|
| Oj | `/admin`, `/admin/dashboard` | Operations KPIs, revenue/order charts, activity, orders, customers, moderation/payout/stock shortcuts. | Mixes fixed time series and calculations on admin seeds. Loading state uses a timer. | OPS, MONEY |
| TE | `/admin/products` | Search by name/SKU/colour etc., status/category filters, pagination, create/edit, toggle active/draft and confirm delete. | Admin products only. Delete also removes related admin inventory; does not delete public catalogue product. | CAT, STOCK |
| Rj | `/admin/products/new`, `/admin/products/:id` | Identity, media selection/path, hero/lifestyle preview, pricing/cost/compare-at, taxable/visible/customisable, colour, sizes/stock, fabric and print areas; cancel/save. | Validates name and positive price; derives slug/SKU defaults; upserts local product. Unmatched ID initializes a new-product-shaped form. Not a media upload service. | CAT, STOCK, DESIGN |
| RE | `/admin/categories` | Category cards, create/edit inspectors, name/description/banner/featured setting, removal confirmation. | Local category CRUD, not a cascading storefront taxonomy update. | CAT |
| zE | `/admin/collections` | Publish switch and merchandising inspector: banner, subtitle and included product checkboxes. | Updates local collection and product ID membership; public collection page uses bundled featured slugs instead. | CAT |
| LE | `/admin/inventory` | Search SKU/product/colour, warehouse and low/incoming/out filters, pages, inline quantity edit, links to product. | Uses onHand minus reserved for availability. On-hand update mirrors into admin product.stockBySize. No reservation or warehouse request. | STOCK |
| HE | `/admin/orders` | Search order/customer/tracking, channel and status filters, pages and row-to-detail navigation. | Nine admin order fixtures at initialization; different store from checkout. | ORDER, OPS |
| UE | `/admin/orders/:id` | Manifest, customer, timeline, status selector including Cancelled/Returned, internal note. | Selection adds admin event and activity locally. No shipment, refund or corresponding customer order update. | ORDER, OPS |
| BE | `/admin/customers` | Search name/email/city/country, segment filter, paginated directory and detail links. | Ten admin customer seeds, not registered browser members. | ACCOUNT, OPS |
| IE | `/admin/customers/:id` | Customer statistics and order history; change Active/Paused/Flagged, save notes. | Joins admin orders by customerId or email. No change to login permissions. | ACCOUNT, OPS |
| _E | `/admin/creators` | Search roster, quick-view inspector, detail; applications tab with approve/waitlist/decline. | Changes admin application status. No link to marketplace application key, payout rail or authentication. | CREATOR, OPS |
| YE | `/admin/creators/:handle` | Creator activity/performance, moderation and payout views; Active/Paused/Suspended selection. | Admin handle joins moderation, ledger and payouts. Status is an admin record field. | CREATOR, MONEY |
| VE | `/admin/moderation` | Search and filter review queue, inspect artwork and history, enter notes, confirm approval/rejection or request changes. | Updates admin moderation record/history/activity. Does not publish a marketplace listing or change the creator submission store. | CREATOR, MARKET |
| GE | `/admin/rewards` | Add/edit/remove rule, percentage/fixed value, scope/target/description, enable switch, creator ledger. | Local rules and sample ledger. Rule edits not shown to recalculate creator earnings. | MONEY |
| qE | `/admin/payouts` | Queue totals and status lanes; hold or confirm mark paid. | Changes status/notes/activity in admin storage. No transfer, payment receipt or reconciliation. | MONEY |
| $E | `/admin/content` | Filter blocks by slot, new/select/edit, active state, fields and CTA, save/remove. | Six seed blocks; home page does not consume admin content state. | CMS |
| FE | `/admin/settings` | General, brand colours, currency/language/timezone, tax/shipping thresholds, zones, royalty and notifications; save or confirm reset. | Updates admin settings; reset restores admin demo data. Public price formatting, rates and royalty displays are not driven by these settings. | CMS, OPS |
| XE | `/admin/reports` | YTD/90d/30d selector, revenue/orders charts, product performance, customer mix and creator contribution. | Fixed month series scaled by 1/.42/.18; product leaders computed from paid admin order items. Not live analytics or a date-range query. | OPS, MONEY |

### Redirects and unmatched paths

All 16 are client-side replacements, not evidence of HTTP 301/302 rules:

| From | To | From | To |
|---|---|---|---|
| `/products` | `/shop` | `/collection-details` | `/collections/expression-vol-01` |
| `/t-shirts` | `/collections/t-shirts` | `/polo-shirts` | `/collections/polo-shirts` |
| `/cart` | `/bag` | `/shopping-bag` | `/bag` |
| `/track-order` | `/order-tracking` | `/registration` | `/register` |
| `/shipping` | `/shipping-delivery` | `/returns` | `/returns-refunds` |
| `/privacy` | `/privacy-policy` | `/terms` | `/terms-conditions` |
| `/dashboard` | `/account` | `/become-creator` | `/marketplace/become-creator` |
| `/creator-dashboard` | `/creator` | `/design-studio` | `/studio` |

`*` renders fallback `QE` with “Explore All Products” → `/shop`. An unknown **matched** parameter can instead show sample content; a rendered product or receipt is therefore not proof that the requested record exists.

## Navigation, shared components and overlays

| Surface | Reusable components and navigation | Interaction evidence / limits |
|---|---|---|
| Public shell | `pA` (`Layout.tsx`), brand marks `ar/Gm/cb`, reveal `Ec`, product card `lr`, email form `lb`, size guide `nb`. Header, mobile menu, footer, ecosystem directory, skip link, toast. | The shell uses a reduced workspace layout for paths starting with `/account`, `/creator`, `/studio`, `/admin`. Public bag/search/size dialogs are not mounted in that branch even if a reused card sets the global flag. Product card quick-add label says M; handler chooses L or first size. |
| Public overlays | Shared dialog `yo`: bag, search, Design Studio early access, fit guide, mobile navigation, ecosystem directory. Product zoom is a separate dialog. | Bag drawer edits quantity/removes, totals/free-shipping progress and checkout links. Search previews filtered local products, submits `?q=`. Waitlist shares the simulated email form. `yo` handles backdrop, close, Escape, focus restore and body scroll locking; no claim of a complete focus trap. |
| Customer/creator shell | `dj`, nav arrays `BA/IA`, workspace switcher, responsive sidebar/backdrop, marketplace/storefront cross-links, contextual Bag/New design action. Shared heading, metric cards, status pill, switch, empty state and JSON export. | Notification bell dispatches `yc-notification`; no matching listener was found in the bundle. Customer address editor reuses `yo`. Settings restore uses an inline confirmation. |
| Marketplace | `ZA` subnav: explore, categories, trending, creators, saved, become creator. `bn` design card, `vn` design mockup, `pa` garment SVG, `_A` related designs. | Creators nav goes to a particular creator profile, not a directory. Saved opens the customer wishlist. Per-design like/follow is local, not a platform-wide count. |
| Studio | `Bx` Studio chrome, `mj` interactive 2D canvas, `jE` layer renderer, shared garment SVG; preview overlay in 2D and presentation state in 3D. | Front/back views, properties/layers and preview are editor states, not routes. Editor-to-editor links pass only blank ID and colour. |
| Admin shell | `wE` mounts admin provider; `AE` sidebar, breadcrumbs/page title, sidebar badges, command/search suggestions, notifications menu, mobile scrim, toast. | Search matches console pages; unmatched text goes to `/admin/products?q=…`. Notification links can mark read; mark-all-read is local. `AdminShared.tsx`: search, segmented filters, pagination, pills, KPI/avatar, SVG charts, skeleton, empty state, switch. |
| Admin overlays | `Bd` inspector used for category edit/new, collection merchandising, creator quick view. `Sn` confirmation for product/category/rule removal, moderation approval/rejection, payout marked paid. | Cancel/close and confirm callbacks are recorded separately. Both shared overlays implement Escape handling. Content/reward editors and settings reset are in-page interfaces, not additional modal routes. |

The JSON indexes **18 native form sites** and **609 statically identifiable interaction sites**, including shared controls, file inputs, pointer surfaces and callbacks on custom components. These are definition-site counts, **not** a count of unique workflows or visible buttons. For field labels, required/disabled conditions, input types, bounds, select options, form membership and submit handlers, follow `routes[].component → components[key].forms / interactionSites / uses`. `render.controls` lists resolved page-tagged DOM instances for the chosen sample; shared/conditional controls are also indexed at their definition sites. Wizard and inline editors need not contain a native `<form>`.

## Design Studio: what the editors actually retain

**2D — `Studio2D.tsx` / `PE`, `mj`, `jE`.** Data model: project `id, name, productId, color, views.front[], views.back[]`. A layer has `id, type, name, x, y, width, height, rotation, opacity, color, visible, locked`. Text adds content, family, size, weight, letter spacing and alignment; image adds `src`; shape adds a rectangle/circle/star discriminator. A new canvas starts with image and text on the front. Front and back are distinct stacks.

- Add preset/custom text, bundled artwork, local image (`image/*`, max 3 MiB; FileReader data URL) or shape. Select, drag, resize (Shift preserves ratio on the resize path), rotate, enter numeric transforms, edit type/colour/opacity, duplicate, delete, reorder, hide or lock. Lock prevents pointer manipulation; it is not an ownership control. Zoom, reset/fit, grid and preview are browser presentation.
- History checkpoints retain up to 50 prior document snapshots. Ctrl/Cmd-Z and Shift-Z undo/redo; Ctrl/Cmd-D duplicates, Delete/Backspace removes selection, Escape deselects/closes preview. The key handler ignores input/textarea/select targets. Do not infer that every slider movement creates its own undo step.
- A 650 ms debounced effect serializes the current document to `yc-phase02-studio-autosave`. Restore prefers a recognized saved project; bare editor entry can restore autosave; `design` can seed art/text. Manual save upserts a shelf record with project object and timestamp. Storage errors in autosave are caught before setting the UI to “saved”; the status is not proof of durable storage.
- Download clones the current SVG, removes editor-only elements and serializes a 1200 × 1400 SVG through Blob/object URL. Artwork hrefs can remain references, not embedded print-ready assets. Save-and-add stores the design **and separately** adds only base product and size to the bag. No order line references the project.

**3D — `Studio3D.tsx` / `vE`, shared `pa`.** Pointer drag changes yaw. Yaw selects the nearest of four garment views and applies a view transform. Front/right/back/left controls, auto-rotation (suppressed for reduced motion), zoom/reset, grid, presentation, garment/dye, three materials, roughness, lighting presets, art selection, scale, vertical placement, rotation, opacity and size are wired browser controls. The snapshot serializes the garment SVG, **not** a rendered scene or model file.

Save stores `type: "3d", productId, color, artwork, artScale, artY, artRotation, artOpacity, yaw, zoom, lighting, material, roughness` inside a shelf entry. The 3D editor reads `design/product/color`, not a saved project ID. The shelf opens `/studio/2d?project=…`; 2D recognizes documents with `views` and `productId`, which the 3D payload lacks. Thus **saving a spatial study is evidenced; reopening it with its spatial state intact is not**. No evidence of meshes, UV maps, physics, calibrated print positioning, server rendering, cloud collaboration or production export.

## Roles and user journeys

Roles below describe **which interface exposes an action**, not authenticated permissions. Clean-context renders reached customer, creator and admin screens without a member record; the route declarations have no observed auth/role gate. Backend authorization remains unknown.

| Interface | Capabilities exposed | Actual boundary |
|---|---|---|
| Visitor / store member | Browse, search, fit, wish, bag, checkout, tracking, account access simulations and support forms. | Member object lives on device; order and wish stores are not keyed by authenticated user. |
| Customer | Edit profile/address/preferences, view and reorder orders, curate designs/artwork, JSON export/reset. | Browser-local profile independent of sign-in. No cross-device or per-user isolation demonstrated. |
| Marketplace participant | Discover art, like/follow/share, remix, buy base and apply. | Static public catalogue plus own local selections/application. |
| Creator | Manage submissions and studio profile; inspect sales/earnings; claim demo benefits and set payout preferences. | No approval prerequisite evidenced, no actual royalty transfer or publication. |
| Studio user | Edit/save 2D and spatial studies, download SVG, add base garment. | Local design shelf, separate bag lines; no production job. |
| Admin | Catalogue/stock/order/people/content operations, moderation, rules/payout labels, reports and settings. | Separate demo storage; console availability is not authorization to any server operation. |

| Journey | Observed chain | Where the evidence stops |
|---|---|---|
| J01 · Purchase | Shop/search → product → choose size or express checkout → bag edits/promo → checkout → confirmation → tracking/account orders → reorder. | Local order snapshot; no stock deduction, processor capture, fulfillment or admin order creation. |
| J02 · Membership | Register or sign in → local member summary; forgot → simulated link → reset success; account → profile/address/preferences. | No credential service or reset email. Membership, customer profile and address book are separate from checkout defaults. |
| J03 · Collect originals | Marketplace → search/filter → design/creator → like/follow → account wishlist → remix or buy. | Buying calls addToBag(productId, size, 1); the advertised creator royalty and design-specific sale do not follow the line. |
| J04 · Design | Studio → mode → select blank/dye → edit → save/preview/export → customer shelf or base in bag. | Full front/back project can return to 2D; cross-mode links do not transfer layers and 3D lacks a matching restore path. |
| J05 · Creator pipeline | Become creator → local application success → creator workspace → publish steps → draft/review → submissions → mark changes complete. | Application/submission do not enter admin queues. Admin approval does not make a new listing in the static marketplace. |
| J06 · Operations | Admin products → edit/save → inventory SKU; orders → detail/status/note; creator review → moderation/history; payouts → hold/mark paid. | Effects limited to admin namespace. These are not customer-visible dispatches or financial transactions. |
| J07 · Support/aftercare | FAQ/size/shipping → contact or returns portal → displayed case/RMA reference. | Component-state acknowledgment only. No correspondence, return tracking, refund or label. |

## State, mock sources and data ownership

| Source | What is actually present | Storage / important joins |
|---|---|---|
| Store catalogue | `vs`: 15 products; `bo`: 4 collections; `sn`: 12 FAQs; `lm`: 4 size chart families. Product ID, slug, variant slugs, category/substyle, sizes/lowStockSizes, fit, GSM, price/compare-at, material/care, images and flags. | Bundled arrays. Public catalogue is not read from admin storage. Variant swatch can route to another product slug. Collection featured slugs set the displayed order. |
| Store provider `nA` | Two starter bag lines, three wishlist IDs, three sample orders; nullable member. | `yc-phase01-{bag,wishlist,orders,member}`. Line `{key,productId,size,quantity}`. Orders snapshot item price/name/colour/slug/image and delivery/payment summary. Promo, packaging, gift note, drawer flags and toast remain in memory. |
| Ecosystem provider `iA` | Seeded customer profile, 2 addresses, 3 saved-design records, 5 submissions, selected likes/follows, creator profile, reward claims, notification settings and payout preferences. | `yc-phase02-{profile,addresses,settings,liked-designs,followed-creators,studio-designs,submissions,payout,creator-profile,rewards}`. Two further direct-write keys: `creator-application` and `studio-autosave` with the same prefix. |
| Marketplace / creator / blanks | `Ba`: 4 creators; `Je`: 8 designs; `dA`/`Ja`: 12 sales; `st`: 4 blanks with IDs 2/4/1/6; bundled art and 4 benefit definitions. | Design.creator → handle, productId → store base, sale.designId → design. Base catalogue and blank labels need not match. Designer earnings are not computed from the customer order store. |
| Admin provider `SE` | Seeds: products 15, categories 4, collections 4, inventory 85 SKU rows, orders 9, customers 10, creators 4, applications 3, moderation 11, reward rules 5, ledger 8, payouts 7, content blocks 6, activity 8, notifications 5, and settings. | `yc-admin-v1-{products,categories,collections,inventory,orders,customers,creators,applications,moderation,rewards,ledger,payouts,content,settings,activity,notifications}`. Some seeds derive from public arrays; subsequent state is independent. JSON `storage` lists observed nested fields/types and seed counts. |
| Navigation / presentation | `lA` and `jd`: curated phase directories; `BA`, `IA`, `CE`: workspace nav; admin `kc`, `Fl`, `an`: monthly chart series and labels. | Directory counts are not the router count. Admin loading skeleton precedes a 420 ms timer, not a server response. |

**Order semantics that matter for comparison.** Store promo codes are case-normalized. YC10/FIRSTCHOICE apply a rounded 10% discount; INDEPENDENT 15%; FREESHIP zeroes delivery. Checkout uses standard/express rates of 10/18 below a 150 subtotal, zero for those methods above or at threshold, and 28 for priority before the free-shipping override; collector packaging adds 8. All are fixture USD values. Order IDs are randomly formatted `YC-2026-…`, display dates/events are constructed locally, and the payment summary is a method label or card suffix. Mobile number, CVC and expiry do not appear in the order creation payload. Store tracking treats delivered as step 5; admin status mapping uses step 6. Matching names across screens is insufficient to equate the models.

## API and backend-comparison register

**Observed business HTTP/RPC dependencies: none identified.** The entry bundle's `fetch(i.href, …)` belongs to the module-preload shim. Static JS/CSS, favicon, artwork, editorial images and portraits are asset dependencies, not commerce endpoints. No application XHR, WebSocket, GraphQL client, payment SDK call or remote storage upload was identified in the inspected code paths.

**Observed host integration, separately:** the HTML includes Arena recording, view counting and picker scripts. The view script targets `POST https://www.designarena.ai/api/agon/page-views`; the recorder references jsDelivr `rrweb@2.0.0-alpha.4`, uses session storage and host-window messages. Both the POST and the external script load were observed as **blocked attempts**, not completed transfers. Neither is a YOUR CHOICE business API. Local browser dependencies include history/query navigation, localStorage, FileReader, clipboard, window.print, Blob/object URLs, SVG DOM/serialization and pointer events. Clipboard permission, exported asset portability and storage quotas were not exercised.

The following are **data/operation requirements inferred from the UI if it were backed by a service**. They are not proposed endpoint paths, confirmed backend features, or a request to implement anything. Each key is reusable when the Codex audit is available.

| Key | Operation to compare | Fields / relationships the UI needs | Frontend evidence and discrepancy |
|---|---|---|---|
| CAT | Catalogue, variants, search, collections, size guidance and merchandising | Product ID vs slug; variant slug/colour/image; sizes, merchandising flags, ordered collection membership, fabric/fit and price; size chart rows. | Public `vs/bo/lm` vs admin products/categories/collections. Define which catalogue and sort order would be authoritative. |
| CART | Wishlist and cart line lifecycle, pricing and promotions | Account/guest ownership; product/variant/size/qty, price basis, discount, packaging and gift note; design/creator attribution if sold as an original. | StoreContext merges by productId-size only; marketplace price, chosen dye and saved project are lost. Wishlist share is a page URL. |
| ORDER | Quote, checkout, confirmation, fulfillment lookup, reorder and returns | Customer reference, email/address, order number vs admin ID, method/status, monetary totals, immutable item snapshots, carrier/tracking/events; status enum mapping. | Local placeOrder vs admin order store; tracking ignores email. No payment token/capture, carrier event ingestion, reservation or return/refund evidenced. |
| ID | Identity, sessions, registration, recovery and role access | User identity → profile/creator/admin permissions; credential lifecycle, ownership, token and expiry semantics. | Local member object and form-only recovery; no server sessions/permission claims seen. |
| ACCOUNT | Profile, addresses, preferences, account export | Contact/fit/birthday/bio, address ID/default flag, notification preferences, owner associations and export scope. | EcosystemContext local state. Profile edits do not establish an authenticated identity or feed checkout address selection. |
| MARKET | Listing and creator discovery, likes/follows, public profiles, remix attribution | Design id/slug, creator handle, artwork/placement, base/colour/price/royalty, category/tags, featured/trending and metrics. | Static listings plus local ID sets. Featured/category routing and handle lookup need reconciliation. |
| CREATOR | Application, draft, publishing, moderation and public listing lifecycle | Applicant portfolio/rights, draft metadata/assets, submitted products, reviewer/status/note/history, published slug and creator identity. | Phase02 application/submission, admin application/moderation and marketplace list are independent. No shared transition or asset ID. |
| DESIGN | Project persistence, assets, previews and customized order linkage | Owner/project ID, schema/type/version, per-side layer geometry/style/artwork, 3D camera/material settings, blank/print area and linked cart item. | Two project shapes, local FileReader data and SVG downloads. No remote save/version control or production handoff. |
| STOCK | SKU-level stock, availability and inventory administration | productId, SKU, size/colour, warehouse, onHand, reserved, incoming, reorder point and available units. | Admin inventory can update admin stockBySize. Store low-stock labels come from fixtures; checkout does not reserve stock. |
| MONEY | Sales attribution, royalty rules, reward entitlement and payout settlement | Order/design/creator links, gross, qty, rate/amount, currency, transaction status/date, claim and payout schedule/reference. | Creator ledger, admin rules/ledger/payouts are different local sources. Mark paid and claim do not initiate fulfillment. |
| CMS | Homepage management, publishing, store configuration | Block id/slot/title/body/image/CTA/order/active; brand, locales, currency, zones/rates, threshold, tax and notification config. | Admin-only state; public home/policy/rate decisions use separate constants. |
| OPS | Console records, status mutations, activity, notifications and reports | Actor, record ID, status transition, timestamp/history, read state, metric period/filters and aggregation basis. | Local mutations and generated activity, hardcoded actor/dates/series; no remote audit trail or analytics ingestion. |
| CARE | Support, newsletter/waitlist, consent and returns requests | Contact email/name/department/message/orderRef; consent purpose; subscribed list; RMA method/size, eligibility and decision. | Timeouts, local toggles and random case/RMA strings. No submitted support/subscriber/consent/return API evidenced. |

## Material gaps and unknowns

1. **No source-repository parity claim.** Original exports, complete module/file inventory, dependency versions, package scripts, tests, source maps, unbuilt pages, feature flags, branch and commit are unavailable. Build symbols are exact for this artifact only.
2. **No evidence of shared business state across roles.** A storefront order does not enter the admin order queue; approval does not publish a creator draft; admin stock/content changes do not update the storefront. Same-looking IDs and sample names do not establish integration.
3. **Success feedback is not proof of completion.** Contact, returns, recovery, waitlist, payment, tracking, consent, moderation and payout screens have distinct local behaviors, detailed above. A “saved,” “sent,” “verified,” or “paid” label is not a server acknowledgment.
4. **Identity and permissions are unknown outside this build.** Local access to a demo admin screen is not evidence of access to protected records. No account was created or used and no security testing was performed.
5. **Asset delivery and runtime edge cases are unverified.** Replay tests route matching and initial DOM, not visual fidelity, real files, mobile gestures, print/clipboard acceptance, storage exhaustion, accessibility conformance, user isolation, concurrency or end-to-end transactions.
6. **Backend comparison is pending evidence.** For each comparison key, match a Codex-audited implementation and ownership checks to the fields, operations and side effects here. Record verified match, partial match, conflict, not found in backend evidence, or unknown. No method/path, backend schema or integration is assumed.

## Verification

The route matrix, detailed interaction index, fixture schemas, storage namespaces and render samples refer to the same fingerprinted build. Counts exclude redirects/layouts/fallback from the 79 page routes. Companion JSON is structured for joining `routes[].component` to `components`, not for treating a display label as a verified capability. Both deliverables were checked for parseability/structure, coverage and consistent route totals. Inspection stopped without changing the application.
