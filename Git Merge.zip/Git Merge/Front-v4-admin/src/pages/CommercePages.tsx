import React, { useMemo, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronRight,
  Copy,
  CreditCard,
  Gift,
  Heart,
  Lock,
  MapPin,
  Minus,
  Package,
  Plus,
  Printer,
  RotateCcw,
  Share2,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Tag,
  Trash2,
  Truck,
} from 'lucide-react';
import { PRODUCTS, formatPrice } from '../data/catalog';
import { useStore } from '../context/StoreContext';
import { OfficialEmblem } from '../components/BrandMarks';
import { ProductCard } from '../components/ProductCard';

/* ============================================================================
   7. WISHLIST (/wishlist)
   ============================================================================ */
export function WishlistPage() {
  const {
    wishlistIds,
    toggleWishlist,
    clearWishlist,
    restoreSampleWishlist,
    addToBag,
    showToast,
  } = useStore();

  const [sizePicks, setSizePicks] = useState<Record<number, string>>({});

  const savedProducts = useMemo(
    () =>
      wishlistIds
        .map((id) => PRODUCTS.find((p) => p.id === id))
        .filter((x): x is NonNullable<typeof x> => Boolean(x)),
    [wishlistIds]
  );

  const handleMoveAllToBag = () => {
    savedProducts.forEach((p) => {
      const sz = sizePicks[p.id] || (p.sizes.includes('L') ? 'L' : p.sizes[0]);
      addToBag(p.id, sz, 1, false);
    });
    showToast(`Added all ${savedProducts.length} saved pieces to your Shopping Bag.`);
  };

  const handleShareWishlist = () => {
    try {
      navigator.clipboard?.writeText(window.location.href);
    } catch {
      // fallback
    }
    showToast('Curated wishlist link copied to clipboard.');
  };

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Saved Wishlist</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <i /> PERSONAL CURATION BOARD
            </p>
            <h1 className="page-title">
              YOUR <span>WISHLIST.</span>
            </h1>
          </div>
          <div className="space-y-4">
            <p className="page-lead">
              Keep track of silhouettes, colorways, and upcoming drops before moving them into your active rotation.
            </p>
            {savedProducts.length > 0 && (
              <div className="flex flex-wrap gap-2.5">
                <button type="button" onClick={handleMoveAllToBag} className="button button-blue">
                  Add All ({savedProducts.length}) to Bag <ShoppingBag size={16} />
                </button>
                <button
                  type="button"
                  onClick={handleShareWishlist}
                  className="button button-outline"
                >
                  Share List <Share2 size={15} />
                </button>
                <button
                  type="button"
                  onClick={clearWishlist}
                  className="px-3.5 py-2 text-xs text-[#60675a] underline hover:text-[#18191a]"
                >
                  Clear All
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="section-pad pt-10">
        {savedProducts.length === 0 ? (
          <div className="editorial-card py-20 text-center space-y-5">
            <Heart size={42} strokeWidth={1.2} className="mx-auto text-[#8b9282]" />
            <div className="space-y-2">
              <p className="mono text-[10px] text-[var(--blue)]">0 SAVED PIECES</p>
              <h2 className="text-3xl font-semibold tracking-tight">
                Your wishlist is a clean slate.
              </h2>
              <p className="text-xs text-[#60675a] max-w-md mx-auto">
                Tap the heart icon on any T-shirt, Polo shirt, or Outerwear silhouette to curate your personal rotation.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <Link to="/shop" className="button button-blue">
                Explore All Products <ArrowUpRight size={17} />
              </Link>
              <button
                type="button"
                onClick={restoreSampleWishlist}
                className="button button-outline"
              >
                Load Sample Curated Board <RotateCcw size={15} />
              </button>
            </div>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {savedProducts.map((product) => {
              const selectedSz =
                sizePicks[product.id] || (product.sizes.includes('L') ? 'L' : product.sizes[0]);
              return (
                <article
                  key={product.id}
                  className="border border-[var(--line)] bg-[#fafaf7] flex flex-col justify-between"
                >
                  <div>
                    <div className="product-image">
                      <div className="product-meta">
                        <span>{product.category}</span>
                        <span>{product.code}</span>
                      </div>
                      <Link to={`/product/${product.slug}`} className="block w-full h-full">
                        <img src={product.image} alt={product.name} />
                      </Link>
                      <button
                        type="button"
                        onClick={() => toggleWishlist(product.id)}
                        aria-label={`Remove ${product.name} from wishlist`}
                        className="absolute top-3.5 right-3.5 z-10 w-8 h-8 bg-[#f5f5f1] border border-black/10 grid place-items-center hover:bg-black hover:text-white transition-colors"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>

                    <div className="p-5 space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <h2 className="text-base font-semibold tracking-tight">
                            <Link
                              to={`/product/${product.slug}`}
                              className="hover:text-[var(--blue)]"
                            >
                              {product.name}
                            </Link>
                          </h2>
                          <p className="text-xs text-[#60675a] mt-0.5">
                            {product.color} · {product.gsm}
                          </p>
                        </div>
                        <span className="font-mono text-sm font-semibold">
                          {formatPrice(product.price)}
                        </span>
                      </div>

                      {/* Inline Size Picker */}
                      <div>
                        <span className="mono text-[9px] text-[#60675a] block mb-1.5">
                          SELECT SIZE TO ADD:
                        </span>
                        <div className="grid grid-cols-6 gap-1">
                          {product.sizes.map((sz) => (
                            <button
                              key={sz}
                              type="button"
                              onClick={() =>
                                setSizePicks((prev) => ({ ...prev, [product.id]: sz }))
                              }
                              className={`h-8 font-mono text-[10px] border ${
                                selectedSz === sz
                                  ? 'bg-[#18191a] text-white border-[#18191a]'
                                  : 'border-[#cbcec5] bg-white'
                              }`}
                            >
                              {sz}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="px-5 pb-5">
                    <button
                      type="button"
                      onClick={() => addToBag(product.id, selectedSz, 1, true)}
                      className="button button-blue w-full"
                    >
                      Move Size {selectedSz} to Bag <ShoppingBag size={16} />
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {/* Recommended Additions */}
        <section className="mt-16 pt-12 border-t border-[var(--line)]">
          <div className="flex items-center justify-between mb-7">
            <div>
              <span className="eyebrow">
                <i /> CURATED FOR YOUR ROTATION
              </span>
              <h2 className="text-2xl font-semibold tracking-tight mt-1.5">
                Essential Pairings
              </h2>
            </div>
            <Link to="/shop" className="text-link">
              All products <ArrowUpRight size={14} />
            </Link>
          </div>
          <div className="product-grid">
            {PRODUCTS.filter((p) => !wishlistIds.includes(p.id))
              .slice(0, 3)
              .map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
          </div>
        </section>
      </div>
    </div>
  );
}

/* ============================================================================
   8. SHOPPING BAG (/bag)
   ============================================================================ */
export function ShoppingBagPage() {
  const {
    bag,
    bagCount,
    bagSubtotal,
    promoCode,
    discountAmount,
    applyPromoCode,
    clearPromoCode,
    collectorPackaging,
    setCollectorPackaging,
    giftNote,
    setGiftNote,
    updateBagQuantity,
    updateBagSize,
    removeFromBag,
    toggleWishlist,
    addToBag,
  } = useStore();

  const [promoInput, setPromoInput] = useState(promoCode);
  const [promoStatus, setPromoStatus] = useState('');

  const freeShipRemaining = Math.max(0, 150 - bagSubtotal);
  const freeShipPct = Math.min(100, Math.round((bagSubtotal / 150) * 100));
  const shippingEstimate =
    bagSubtotal === 0 || bagSubtotal >= 150 || promoCode.toUpperCase() === 'FREESHIP' ? 0 : 12;
  const packagingFee = collectorPackaging ? 8 : 0;
  const grandTotal = Math.max(0, bagSubtotal - discountAmount + shippingEstimate + packagingFee);

  const handlePromoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = applyPromoCode(promoInput);
    setPromoStatus(res.message);
  };

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <Link to="/shop">Shop</Link>
        <ChevronRight size={11} />
        <span>Shopping Bag</span>
      </nav>

      <header className="page-masthead">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">
              <i /> GOOD CHOICES, READY TO WEAR
            </p>
            <h1 className="page-title">
              SHOPPING <span>BAG ({bagCount}).</span>
            </h1>
          </div>
          <Link to="/shop" className="text-link">
            <ArrowLeft size={14} /> Continue exploring pieces
          </Link>
        </div>
      </header>

      {bag.length === 0 ? (
        <div className="section-pad pt-12">
          <div className="editorial-card py-20 text-center space-y-5">
            <ShoppingBag size={46} strokeWidth={1.1} className="mx-auto text-[#8b9282]" />
            <div className="space-y-2">
              <p className="mono text-[10px] text-[var(--blue)]">BAG IS CURRENTLY EMPTY</p>
              <h2 className="text-3xl font-semibold tracking-tight">
                A little room for expression.
              </h2>
              <p className="text-xs text-[#60675a] max-w-md mx-auto">
                Explore our heavyweight T-Shirt Collection, structured Polo Shirts, or add one of our signature Vol. 01 pieces below.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <Link to="/shop" className="button button-blue">
                Browse All Products <ArrowUpRight size={17} />
              </Link>
              <button
                type="button"
                onClick={() => addToBag(2, 'L', 1, false)}
                className="button button-outline"
              >
                Quick-Add Signature Blue Tee ($42) <Plus size={15} />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="two-col-commerce">
          {/* Left Column: Bag Lines & Packaging Options */}
          <div className="space-y-6">
            {/* Free Shipping Progress */}
            <div className="editorial-card !p-5">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="inline-flex items-center gap-2 font-medium">
                  <Truck size={15} className="text-[var(--blue)]" />
                  {freeShipRemaining === 0
                    ? 'You unlocked Complimentary DHL Express Carbon-Neutral Delivery.'
                    : `Add ${formatPrice(freeShipRemaining)} more to unlock Free Express Delivery.`}
                </span>
                <span className="font-mono text-[10px]">{freeShipPct}%</span>
              </div>
              <div className="h-1.5 bg-[#d5d8cf] overflow-hidden">
                <div
                  className="h-full bg-[var(--blue)] transition-all duration-300"
                  style={{ width: `${freeShipPct}%` }}
                />
              </div>
            </div>

            {/* Line Items */}
            <div className="border-t border-[var(--line)]">
              {bag.map((line) => {
                const prod = PRODUCTS.find((p) => p.id === line.productId);
                if (!prod) return null;
                return (
                  <div
                    key={line.key}
                    className="py-6 border-b border-[var(--line)] grid sm:grid-cols-[120px_1fr_auto] gap-5 items-start"
                  >
                    <Link
                      to={`/product/${prod.slug}`}
                      className="bg-[#e7eae2] border border-[#d4d7cf] aspect-[0.88] p-3 block"
                    >
                      <img
                        src={prod.image}
                        alt={prod.name}
                        className="w-full h-full object-contain"
                      />
                    </Link>

                    <div className="space-y-2.5">
                      <div>
                        <span className="mono text-[9px] text-[#60675a]">
                          {prod.code} · {prod.category}
                        </span>
                        <h2 className="text-lg font-semibold tracking-tight">
                          <Link
                            to={`/product/${prod.slug}`}
                            className="hover:text-[var(--blue)]"
                          >
                            {prod.name}
                          </Link>
                        </h2>
                        <p className="text-xs text-[#60675a]">
                          Color: {prod.color} · {prod.gsm}
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 pt-1">
                        {/* Inline Size Switcher */}
                        <label className="inline-flex items-center gap-2 text-xs">
                          <span className="mono text-[10px] text-[#60675a]">SIZE:</span>
                          <select
                            aria-label={`Change size for ${prod.name}`}
                            value={line.size}
                            onChange={(e) => updateBagSize(line.key, e.target.value)}
                            className="border border-[#c4c8be] bg-[#fafaf7] px-2.5 py-1 font-mono text-xs"
                          >
                            {prod.sizes.map((sz) => (
                              <option key={sz} value={sz}>
                                {sz}
                              </option>
                            ))}
                          </select>
                        </label>

                        {/* Quantity Control */}
                        <div className="quantity !mt-0 bg-[#fafaf7]">
                          <button
                            type="button"
                            aria-label={`Decrease ${prod.name} quantity`}
                            onClick={() => updateBagQuantity(line.key, line.quantity - 1)}
                          >
                            <Minus size={12} />
                          </button>
                          <span className="font-mono px-1">{line.quantity}</span>
                          <button
                            type="button"
                            aria-label={`Increase ${prod.name} quantity`}
                            disabled={line.quantity >= 10}
                            onClick={() => updateBagQuantity(line.key, line.quantity + 1)}
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 pt-1 text-[11px] text-[#60675a]">
                        <button
                          type="button"
                          onClick={() => {
                            toggleWishlist(prod.id);
                          }}
                          className="underline hover:text-[var(--blue)]"
                        >
                          Save to Wishlist
                        </button>
                        <button
                          type="button"
                          onClick={() => removeFromBag(line.key)}
                          className="underline hover:text-[#b42318]"
                        >
                          Remove
                        </button>
                      </div>
                    </div>

                    <div className="text-right">
                      <strong className="font-mono text-base">
                        {formatPrice(prod.price * line.quantity)}
                      </strong>
                      {line.quantity > 1 && (
                        <span className="block font-mono text-[10px] text-[#60675a]">
                          {formatPrice(prod.price)} each
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Archival Collector Packaging Option */}
            <div className="editorial-card space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <Gift size={18} className="text-[var(--blue)] mt-0.5 shrink-0" />
                  <div>
                    <h3 className="text-sm font-semibold">
                      Upgrade to Rigid Matte Collector Box &amp; Printed Note (+$8)
                    </h3>
                    <p className="text-xs text-[#60675a] mt-0.5">
                      Every order ships in recyclable matte dust bags for free, or upgrade to our magnetic obsidian gift presentation box.
                    </p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={collectorPackaging}
                  onChange={(e) => setCollectorPackaging(e.target.checked)}
                  aria-label="Add Collector Box Packaging"
                  className="w-4 h-4 mt-1 accent-[var(--blue)]"
                />
              </div>

              {collectorPackaging && (
                <div className="field-group pt-2">
                  <label className="field-label" htmlFor="gift-note">
                    Optional Personal Card Message
                  </label>
                  <input
                    id="gift-note"
                    type="text"
                    maxLength={140}
                    value={giftNote}
                    onChange={(e) => setGiftNote(e.target.value)}
                    placeholder="Not for everyone. For you. — Write your message..."
                    className="field-input"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Sticky Order Summary */}
          <aside className="summary-sticky space-y-5">
            <div>
              <span className="eyebrow">
                <i /> ORDER SUMMARY
              </span>
              <h2 className="text-2xl font-semibold tracking-tight mt-1">Your Selection</h2>
            </div>

            {/* Promo Code Form */}
            <form onSubmit={handlePromoSubmit} className="space-y-2">
              <label className="field-label flex items-center gap-1.5" htmlFor="bag-promo">
                <Tag size={11} /> Studio / Privilege Code
              </label>
              <div className="flex gap-2">
                <input
                  id="bag-promo"
                  type="text"
                  value={promoInput}
                  onChange={(e) => setPromoInput(e.target.value)}
                  placeholder="Try YC10 or INDEPENDENT"
                  className="field-input !py-2 font-mono text-xs uppercase"
                />
                <button type="submit" className="px-4 bg-[#18191a] text-white text-xs font-medium">
                  Apply
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5 pt-0.5">
                {['YC10', 'INDEPENDENT', 'FREESHIP'].map((code) => (
                  <button
                    key={code}
                    type="button"
                    onClick={() => {
                      setPromoInput(code);
                      setPromoStatus(applyPromoCode(code).message);
                    }}
                    className="px-2 py-0.5 border border-[#c5c8bf] bg-[#fafaf7] font-mono text-[9px] hover:border-[var(--blue)]"
                  >
                    {code}
                  </button>
                ))}
                {promoCode && (
                  <button
                    type="button"
                    onClick={() => {
                      clearPromoCode();
                      setPromoInput('');
                      setPromoStatus('');
                    }}
                    className="text-[10px] underline text-[#60675a] ml-auto"
                  >
                    Remove {promoCode}
                  </button>
                )}
              </div>
              {promoStatus && <p className="text-[11px] text-[var(--blue)]">{promoStatus}</p>}
            </form>

            <div className="border-t border-b border-[#cfd2c9] py-4 space-y-2.5 text-xs">
              <div className="flex justify-between">
                <span className="text-[#555b4f]">Subtotal ({bagCount} items)</span>
                <span className="font-mono">{formatPrice(bagSubtotal)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-[var(--blue)] font-medium">
                  <span>Privilege Discount ({promoCode})</span>
                  <span className="font-mono">-{formatPrice(discountAmount)}</span>
                </div>
              )}
              {collectorPackaging && (
                <div className="flex justify-between">
                  <span className="text-[#555b4f]">Rigid Collector Box</span>
                  <span className="font-mono">{formatPrice(packagingFee)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-[#555b4f]">Estimated Delivery</span>
                <span className="font-mono">
                  {shippingEstimate === 0 ? 'COMPLIMENTARY' : formatPrice(shippingEstimate)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#555b4f]">Duties &amp; Taxes (DDP)</span>
                <span className="font-mono">INCLUDED</span>
              </div>
            </div>

            <div className="flex justify-between items-baseline">
              <span className="text-sm font-semibold">Estimated Total</span>
              <strong className="font-mono text-2xl">{formatPrice(grandTotal)}</strong>
            </div>

            <Link to="/checkout" className="button button-blue w-full">
              Proceed to Checkout <ArrowRight size={17} />
            </Link>

            <div className="space-y-1.5 pt-2 text-[11px] text-[#60675a]">
              <p className="flex items-center gap-2">
                <Lock size={12} className="text-[var(--blue)]" /> Encrypted studio checkout · Visa, Mastercard, Apple Pay, Klarna
              </p>
              <p className="flex items-center gap-2">
                <ShieldCheck size={12} className="text-[var(--blue)]" /> 30-day returns &amp; instant free size exchanges
              </p>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}

/* ============================================================================
   9. CHECKOUT (/checkout)
   ============================================================================ */
export function CheckoutPage() {
  const navigate = useNavigate();
  const {
    bag,
    bagCount,
    bagSubtotal,
    promoCode,
    discountAmount,
    collectorPackaging,
    member,
    placeOrder,
    addToBag,
  } = useStore();

  const [email, setEmail] = useState(member?.email || 'alex.mercer@yourchoice.studio');
  const [fullName, setFullName] = useState(member?.name || 'Alex Mercer');
  const [phone, setPhone] = useState('+44 20 7946 0821');
  const [line1, setLine1] = useState('42 Redchurch Street, Studio 4B');
  const [line2, setLine2] = useState('Shoreditch');
  const [city, setCity] = useState('London');
  const [postalCode, setPostalCode] = useState('E2 7DP');
  const [country, setCountry] = useState('United Kingdom');

  const [shippingOption, setShippingOption] = useState<'standard' | 'express' | 'priority'>(
    'express'
  );
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'apple' | 'klarna' | 'cod'>('card');
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('09 / 29');
  const [cardCvc, setCardCvc] = useState('842');
  const [submitting, setSubmitting] = useState(false);

  const shippingCost = useMemo(() => {
    if (promoCode.toUpperCase() === 'FREESHIP') return 0;
    if (shippingOption === 'standard') return bagSubtotal >= 150 ? 0 : 10;
    if (shippingOption === 'express') return bagSubtotal >= 150 ? 0 : 18;
    return 28;
  }, [shippingOption, bagSubtotal, promoCode]);

  const packagingCost = collectorPackaging ? 8 : 0;
  const finalTotal = Math.max(0, bagSubtotal - discountAmount + shippingCost + packagingCost);

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (bag.length === 0) return;
    setSubmitting(true);

    const shippingMethodLabel =
      shippingOption === 'priority'
        ? 'Priority Studio Same-Day Air (1–2 Days)'
        : shippingOption === 'express'
        ? 'DHL Express Carbon-Neutral (2–3 Days)'
        : 'Standard Tracked Courier (4–6 Days)';

    const paymentSummaryLabel =
      paymentMethod === 'apple'
        ? 'Apple Pay Express'
        : paymentMethod === 'klarna'
        ? 'Klarna 4x Interest-Free'
        : paymentMethod === 'cod'
        ? 'Cash on Delivery (Verified)'
        : `Card ending in ${cardNumber.slice(-4) || '4242'}`;

    setTimeout(() => {
      const created = placeOrder({
        email,
        customerName: fullName,
        shippingAddress: {
          line1,
          line2: line2 || undefined,
          city,
          postalCode,
          country,
        },
        shippingMethod: shippingMethodLabel,
        shippingCost,
        paymentSummary: paymentSummaryLabel,
      });
      setSubmitting(false);
      navigate(`/order-confirmation/${created.orderNumber}`);
    }, 450);
  };

  return (
    <div className="page-shell">
      {/* Stepper Breadcrumb */}
      <div className="breadcrumb-bar">
        <Link to="/bag">01 Shopping Bag</Link>
        <ChevronRight size={11} />
        <span className="text-[var(--blue)] font-semibold">02 Secure Checkout</span>
        <ChevronRight size={11} />
        <span>03 Order Confirmation</span>
      </div>

      <header className="page-masthead">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">
              <Lock size={12} className="text-[var(--blue)]" /> ENCRYPTED STUDIO CHECKOUT
            </p>
            <h1 className="page-title !text-[clamp(44px,5.5vw,82px)]">
              COMPLETE YOUR <span>CHOICE.</span>
            </h1>
          </div>
          {!member && (
            <Link to="/login" className="text-link">
              Have an Inner Circle account? Sign in <ArrowUpRight size={13} />
            </Link>
          )}
        </div>
      </header>

      {bag.length === 0 ? (
        <div className="section-pad pt-12">
          <div className="editorial-card py-16 text-center space-y-4">
            <h2 className="text-2xl font-semibold">Your bag is empty.</h2>
            <p className="text-xs text-[#60675a]">
              Add at least one piece before completing checkout, or load a sample piece below to preview the checkout experience.
            </p>
            <div className="flex justify-center gap-3">
              <button
                type="button"
                onClick={() => addToBag(2, 'L', 1, false)}
                className="button button-blue"
              >
                Load Signature Blue Tee ($42) <Plus size={15} />
              </button>
              <Link to="/shop" className="button button-outline">
                Return to Shop
              </Link>
            </div>
          </div>
        </div>
      ) : (
        <form onSubmit={handlePlaceOrder} className="two-col-commerce">
          {/* Left Checkout Steps */}
          <div className="space-y-8">
            {/* Step 01: Contact */}
            <section className="editorial-card space-y-5">
              <div className="flex items-center justify-between border-b border-[var(--line)] pb-3">
                <h2 className="text-lg font-semibold tracking-tight">
                  01 / Contact Information
                </h2>
                <span className="mono text-[9px] text-[#60675a]">ORDER UPDATES &amp; RECEIPT</span>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="field-group sm:col-span-2">
                  <label className="field-label" htmlFor="chk-email">
                    Email Address *
                  </label>
                  <input
                    id="chk-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="field-input"
                  />
                </div>
                <div className="field-group">
                  <label className="field-label" htmlFor="chk-name">
                    Full Name *
                  </label>
                  <input
                    id="chk-name"
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="field-input"
                  />
                </div>
                <div className="field-group">
                  <label className="field-label" htmlFor="chk-phone">
                    Mobile Number (Courier SMS) *
                  </label>
                  <input
                    id="chk-phone"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="field-input"
                  />
                </div>
              </div>
            </section>

            {/* Step 02: Shipping Address & Method */}
            <section className="editorial-card space-y-5">
              <div className="flex items-center justify-between border-b border-[var(--line)] pb-3">
                <h2 className="text-lg font-semibold tracking-tight">
                  02 / Shipping Destination &amp; Courier
                </h2>
                <span className="mono text-[9px] text-[var(--blue)]">DDP DUTIES INCLUDED</span>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="field-group sm:col-span-2">
                  <label className="field-label" htmlFor="chk-line1">
                    Street Address &amp; Studio / Apt *
                  </label>
                  <input
                    id="chk-line1"
                    type="text"
                    required
                    value={line1}
                    onChange={(e) => setLine1(e.target.value)}
                    className="field-input"
                  />
                </div>
                <div className="field-group">
                  <label className="field-label" htmlFor="chk-line2">
                    District / Floor (Optional)
                  </label>
                  <input
                    id="chk-line2"
                    type="text"
                    value={line2}
                    onChange={(e) => setLine2(e.target.value)}
                    className="field-input"
                  />
                </div>
                <div className="field-group">
                  <label className="field-label" htmlFor="chk-city">
                    City *
                  </label>
                  <input
                    id="chk-city"
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="field-input"
                  />
                </div>
                <div className="field-group">
                  <label className="field-label" htmlFor="chk-zip">
                    Postal / ZIP Code *
                  </label>
                  <input
                    id="chk-zip"
                    type="text"
                    required
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="field-input"
                  />
                </div>
                <div className="field-group">
                  <label className="field-label" htmlFor="chk-country">
                    Country / Region *
                  </label>
                  <select
                    id="chk-country"
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="field-select"
                  >
                    <option>United Kingdom</option>
                    <option>United States</option>
                    <option>Canada</option>
                    <option>Germany</option>
                    <option>France</option>
                    <option>Japan</option>
                    <option>United Arab Emirates</option>
                    <option>Bangladesh</option>
                    <option>Australia</option>
                  </select>
                </div>
              </div>

              {/* Delivery Speed Cards */}
              <div className="space-y-2.5 pt-2">
                <span className="field-label block">Select Courier Service</span>
                {[
                  {
                    id: 'express' as const,
                    title: 'DHL Express Carbon-Neutral',
                    eta: '2–3 Business Days · Real-time air telemetry',
                    cost: bagSubtotal >= 150 ? 'FREE' : '$18',
                  },
                  {
                    id: 'standard' as const,
                    title: 'Standard Tracked Courier',
                    eta: '4–6 Business Days · Fully insured',
                    cost: bagSubtotal >= 150 ? 'FREE' : '$10',
                  },
                  {
                    id: 'priority' as const,
                    title: 'Priority Atelier Direct Air',
                    eta: '1–2 Business Days · Priority queue & signature',
                    cost: '$28',
                  },
                ].map((opt) => (
                  <label
                    key={opt.id}
                    className={`p-3.5 border flex items-center justify-between gap-4 cursor-pointer transition-colors ${
                      shippingOption === opt.id
                        ? 'border-[var(--blue)] bg-[#2349ed0c]'
                        : 'border-[#c8cbc2] bg-[#fafaf7]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="shipping-method"
                        checked={shippingOption === opt.id}
                        onChange={() => setShippingOption(opt.id)}
                        className="accent-[var(--blue)]"
                      />
                      <div>
                        <strong className="text-xs block">{opt.title}</strong>
                        <span className="text-[11px] text-[#60675a]">{opt.eta}</span>
                      </div>
                    </div>
                    <span className="font-mono text-xs font-semibold">{opt.cost}</span>
                  </label>
                ))}
              </div>
            </section>

            {/* Step 03: Payment */}
            <section className="editorial-card space-y-5">
              <div className="flex items-center justify-between border-b border-[var(--line)] pb-3">
                <h2 className="text-lg font-semibold tracking-tight">03 / Payment Method</h2>
                <span className="mono text-[9px] text-[#60675a]">FRONTEND UI SIMULATION</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'card' as const, label: 'Card' },
                  { id: 'apple' as const, label: 'Apple Pay' },
                  { id: 'klarna' as const, label: 'Klarna 4x' },
                  { id: 'cod' as const, label: 'Cash on Delivery' },
                ].map((pm) => (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => setPaymentMethod(pm.id)}
                    className={`py-2.5 px-3 border text-xs font-medium transition-colors ${
                      paymentMethod === pm.id
                        ? 'bg-[#18191a] text-white border-[#18191a]'
                        : 'bg-[#fafaf7] border-[#c8cbc2]'
                    }`}
                  >
                    {pm.label}
                  </button>
                ))}
              </div>

              {paymentMethod === 'card' ? (
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="field-group sm:col-span-2">
                    <label className="field-label" htmlFor="card-num">
                      Card Number
                    </label>
                    <div className="relative">
                      <input
                        id="card-num"
                        type="text"
                        required
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        className="field-input font-mono"
                      />
                      <CreditCard
                        size={16}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#60675a]"
                      />
                    </div>
                  </div>
                  <div className="field-group">
                    <label className="field-label" htmlFor="card-exp">
                      Expiration (MM / YY)
                    </label>
                    <input
                      id="card-exp"
                      type="text"
                      required
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="field-input font-mono"
                    />
                  </div>
                  <div className="field-group">
                    <label className="field-label" htmlFor="card-cvc">
                      Security Code (CVC)
                    </label>
                    <input
                      id="card-cvc"
                      type="text"
                      required
                      value={cardCvc}
                      onChange={(e) => setCardCvc(e.target.value)}
                      className="field-input font-mono"
                    />
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-[#fafaf7] border border-[#c8cbc2] text-xs text-[#4b5145]">
                  {paymentMethod === 'apple' &&
                    'Apple Pay Express selected. Biometric confirmation will simulate immediately when you click Complete Order.'}
                  {paymentMethod === 'klarna' &&
                    `Split into 4 interest-free payments of ${formatPrice(
                      finalTotal / 4
                    )} every 2 weeks with Klarna.`}
                  {paymentMethod === 'cod' &&
                    'Pay by card or cash upon courier arrival. Available for verified studio deliveries.'}
                </div>
              )}
            </section>
          </div>

          {/* Right Order Summary */}
          <aside className="summary-sticky space-y-5">
            <div className="flex items-center justify-between">
              <span className="eyebrow">
                <i /> MANIFEST ({bagCount})
              </span>
              <Link to="/bag" className="text-link">
                Edit bag
              </Link>
            </div>

            <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
              {bag.map((line) => {
                const prod = PRODUCTS.find((p) => p.id === line.productId);
                if (!prod) return null;
                return (
                  <div key={line.key} className="flex items-center gap-3 text-xs">
                    <div className="w-14 h-16 bg-[#e3e6de] p-1.5 shrink-0">
                      <img
                        src={prod.image}
                        alt={prod.name}
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{prod.name}</p>
                      <p className="text-[11px] text-[#60675a]">
                        {prod.color} · Size {line.size} × {line.quantity}
                      </p>
                    </div>
                    <span className="font-mono">{formatPrice(prod.price * line.quantity)}</span>
                  </div>
                );
              })}
            </div>

            <div className="border-t border-b border-[#cfd2c9] py-4 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-[#555b4f]">Subtotal</span>
                <span className="font-mono">{formatPrice(bagSubtotal)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-[var(--blue)]">
                  <span>Discount ({promoCode})</span>
                  <span className="font-mono">-{formatPrice(discountAmount)}</span>
                </div>
              )}
              {collectorPackaging && (
                <div className="flex justify-between">
                  <span className="text-[#555b4f]">Rigid Collector Box</span>
                  <span className="font-mono">{formatPrice(packagingCost)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-[#555b4f]">Courier Shipping</span>
                <span className="font-mono">
                  {shippingCost === 0 ? 'FREE' : formatPrice(shippingCost)}
                </span>
              </div>
            </div>

            <div className="flex justify-between items-baseline">
              <span className="text-sm font-semibold">Total Due</span>
              <strong className="font-mono text-2xl">{formatPrice(finalTotal)}</strong>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="button button-blue w-full"
            >
              <span>
                {submitting
                  ? 'Confirming studio allocation…'
                  : `Complete Order — ${formatPrice(finalTotal)}`}
              </span>
              <ArrowRight size={17} />
            </button>

            <p className="text-[10px] text-[#60675a] leading-relaxed">
              By placing this order you agree to YOUR CHOICE{' '}
              <Link to="/terms-conditions" className="underline">
                Terms &amp; Conditions
              </Link>{' '}
              and{' '}
              <Link to="/returns-refunds" className="underline">
                30-Day Returns Policy
              </Link>
              . Frontend UI simulation — no live charge is processed.
            </p>
          </aside>
        </form>
      )}
    </div>
  );
}

/* ============================================================================
   10. ORDER CONFIRMATION (/order-confirmation & /order-confirmation/:orderId)
   ============================================================================ */
export function OrderConfirmationPage() {
  const { orderId } = useParams<{ orderId?: string }>();
  const { orders, showToast } = useStore();

  const order = useMemo(() => {
    if (orderId) {
      const found = orders.find((o) => o.orderNumber.toLowerCase() === orderId.toLowerCase());
      if (found) return found;
    }
    return orders[0];
  }, [orderId, orders]);

  const copyOrderNum = () => {
    try {
      navigator.clipboard?.writeText(order.orderNumber);
    } catch {
      // ignore
    }
    showToast(`Copied order reference ${order.orderNumber}`);
  };

  return (
    <div className="page-shell">
      {/* Celebratory Dark Editorial Banner with Official Crest */}
      <section className="bg-[#121416] text-[#f5f5f1] px-[5.1%] py-14 border-b border-white/10">
        <div className="max-w-5xl mx-auto grid lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-8 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[var(--blue)] text-white font-mono text-[10px]">
              <CheckCircle2 size={13} /> ORDER CONFIRMED &amp; ALLOCATED
            </div>
            <h1 className="display-condensed text-[clamp(52px,6.5vw,92px)]">
              A GOOD CHOICE,
              <br />
              <span className="text-[#6b8aff]">{order.customerName.split(' ')[0].toUpperCase()}.</span>
            </h1>
            <p className="text-sm text-[#c7ccd4] max-w-xl leading-relaxed">
              Your pieces have been reserved at our Porto studio. Confirmation details have been prepared for{' '}
              <strong className="text-white">{order.email}</strong>.
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <Link
                to={`/order-tracking?order=${encodeURIComponent(order.orderNumber)}`}
                className="button button-blue"
              >
                Track Order Live <Truck size={17} />
              </Link>
              <button
                type="button"
                onClick={() => window.print()}
                className="button button-ghost-light"
              >
                Print Studio Receipt <Printer size={16} />
              </button>
            </div>
          </div>

          <div className="lg:col-span-4 bg-[#1a1e26] border border-white/10 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <OfficialEmblem className="w-14 h-10 object-contain" />
              <span className="mono text-[9px] text-[var(--cyan)]">OFFICIAL RECEIPT</span>
            </div>
            <div>
              <span className="mono text-[9px] text-[#9aa2ae] block">ORDER REFERENCE</span>
              <div className="flex items-center gap-2 mt-1">
                <strong className="font-mono text-xl">{order.orderNumber}</strong>
                <button
                  type="button"
                  onClick={copyOrderNum}
                  aria-label="Copy order number"
                  className="p-1 text-[#9aa2ae] hover:text-white"
                >
                  <Copy size={14} />
                </button>
              </div>
            </div>
            <div className="border-t border-white/10 pt-3 grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="mono text-[9px] text-[#9aa2ae] block">EST. ARRIVAL</span>
                <strong>{order.estimatedDelivery}</strong>
              </div>
              <div>
                <span className="mono text-[9px] text-[#9aa2ae] block">TOTAL PAID</span>
                <strong className="font-mono">{formatPrice(order.total)}</strong>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Order Manifest & Shipping Details */}
      <div className="section-pad pt-12 max-w-6xl mx-auto grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-6">
          <div className="editorial-card space-y-4">
            <h2 className="text-lg font-semibold tracking-tight border-b border-[var(--line)] pb-3">
              Confirmed Garment Manifest ({order.items.reduce((s, i) => s + i.quantity, 0)} Pieces)
            </h2>
            {order.items.map((item, idx) => (
              <div
                key={`${item.slug}-${idx}`}
                className="flex items-center gap-4 py-3 border-b border-[#dfe2da] last:border-b-0"
              >
                <Link
                  to={`/product/${item.slug}`}
                  className="w-16 h-20 bg-[#e4e7df] p-2 shrink-0"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-contain"
                  />
                </Link>
                <div className="flex-1">
                  <Link
                    to={`/product/${item.slug}`}
                    className="font-semibold text-sm hover:text-[var(--blue)]"
                  >
                    {item.name}
                  </Link>
                  <p className="text-xs text-[#60675a] mt-0.5">
                    {item.color} · Size {item.size} · Qty {item.quantity}
                  </p>
                </div>
                <strong className="font-mono text-sm">
                  {formatPrice(item.price * item.quantity)}
                </strong>
              </div>
            ))}
          </div>

          {order.giftNote && (
            <div className="editorial-card flex items-start gap-3">
              <Sparkles size={16} className="text-[var(--blue)] mt-0.5" />
              <div className="text-xs">
                <strong className="block">Collector Box Gift Note Included:</strong>
                <p className="text-[#555b4f] mt-1 italic">&ldquo;{order.giftNote}&rdquo;</p>
              </div>
            </div>
          )}
        </div>

        <div className="lg:col-span-5 space-y-5">
          <div className="editorial-card space-y-4 text-xs">
            <h2 className="text-base font-semibold border-b border-[var(--line)] pb-2.5">
              Delivery &amp; Payment Summary
            </h2>
            <div>
              <span className="mono text-[9px] text-[#60675a] block">SHIPPING DESTINATION</span>
              <p className="font-medium mt-1">{order.customerName}</p>
              <p className="text-[#555b4f]">
                {order.shippingAddress.line1}
                {order.shippingAddress.line2 ? `, ${order.shippingAddress.line2}` : ''}
                <br />
                {order.shippingAddress.city}, {order.shippingAddress.postalCode}
                <br />
                {order.shippingAddress.country}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#dfe2da]">
              <div>
                <span className="mono text-[9px] text-[#60675a] block">COURIER SERVICE</span>
                <p className="mt-0.5">{order.shippingMethod}</p>
              </div>
              <div>
                <span className="mono text-[9px] text-[#60675a] block">PAYMENT</span>
                <p className="mt-0.5">{order.paymentSummary}</p>
              </div>
            </div>
            <div className="pt-3 border-t border-[#dfe2da] space-y-1.5">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono">{formatPrice(order.subtotal)}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-[var(--blue)]">
                  <span>Privilege Discount</span>
                  <span className="font-mono">-{formatPrice(order.discount)}</span>
                </div>
              )}
              {order.packagingCost > 0 && (
                <div className="flex justify-between">
                  <span>Rigid Collector Box</span>
                  <span className="font-mono">{formatPrice(order.packagingCost)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Shipping</span>
                <span className="font-mono">
                  {order.shippingCost === 0 ? 'FREE' : formatPrice(order.shippingCost)}
                </span>
              </div>
              <div className="flex justify-between text-sm font-semibold pt-2 border-t border-[var(--line)]">
                <span>Total</span>
                <span className="font-mono">{formatPrice(order.total)}</span>
              </div>
            </div>
          </div>

          <Link to="/shop" className="button button-dark w-full">
            Continue Exploring Storefront <ArrowUpRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   11. ORDER TRACKING (/order-tracking)
   ============================================================================ */
export function OrderTrackingPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { orders, showToast } = useStore();

  const initialCode = searchParams.get('order') || orders[0]?.orderNumber || 'YC-2026-8841';
  const [lookupInput, setLookupInput] = useState(initialCode);
  const [emailInput, setEmailInput] = useState('');
  const [activeOrderNumber, setActiveOrderNumber] = useState(initialCode);

  const matchedOrder = useMemo(
    () =>
      orders.find(
        (o) => o.orderNumber.toLowerCase() === activeOrderNumber.trim().toLowerCase()
      ) || null,
    [orders, activeOrderNumber]
  );

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = lookupInput.trim();
    if (!cleaned) return;
    setActiveOrderNumber(cleaned);
    setSearchParams({ order: cleaned }, { replace: true });
  };

  const selectQuickOrder = (num: string) => {
    setLookupInput(num);
    setActiveOrderNumber(num);
    setSearchParams({ order: num }, { replace: true });
  };

  const milestones = [
    { step: 1, label: 'Order Confirmed', sub: 'Allocated at studio' },
    { step: 2, label: 'Atelier Inspection', sub: 'Steamed & verified' },
    { step: 3, label: 'Dispatched', sub: 'Handed to courier' },
    { step: 4, label: 'In Transit', sub: 'Air hub routing' },
    { step: 5, label: 'Delivered', sub: 'Signed at destination' },
  ];

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Order Tracking</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <i /> LIVE STUDIO &amp; COURIER TELEMETRY
            </p>
            <h1 className="page-title">
              TRACK YOUR <span>ORDER.</span>
            </h1>
          </div>
          <p className="page-lead">
            Follow your consignment from quality inspection at our Porto atelier through international air transit to your door.
          </p>
        </div>

        {/* Lookup Form */}
        <form onSubmit={handleLookup} className="mt-8 grid md:grid-cols-[1.2fr_1fr_auto] gap-3 max-w-4xl">
          <input
            type="text"
            value={lookupInput}
            onChange={(e) => setLookupInput(e.target.value)}
            placeholder="Order number (e.g. YC-2026-8841)"
            aria-label="Order number"
            className="field-input font-mono uppercase"
          />
          <input
            type="email"
            value={emailInput}
            onChange={(e) => setEmailInput(e.target.value)}
            placeholder="Billing email (optional for demo)"
            aria-label="Email address"
            className="field-input"
          />
          <button type="submit" className="button button-blue">
            Locate Shipment <ArrowRight size={16} />
          </button>
        </form>

        {/* Quick Demo Switcher Pills */}
        <div className="flex flex-wrap items-center gap-2 mt-4">
          <span className="mono text-[9px] text-[#60675a]">SAMPLE &amp; RECENT ORDERS:</span>
          {orders.slice(0, 4).map((o) => (
            <button
              key={o.orderNumber}
              type="button"
              onClick={() => selectQuickOrder(o.orderNumber)}
              className={`px-2.5 py-1 font-mono text-[10px] border transition-colors ${
                matchedOrder?.orderNumber === o.orderNumber
                  ? 'bg-[#18191a] text-white border-[#18191a]'
                  : 'border-[#c8cbc2] bg-[#fafaf7] hover:border-[var(--blue)]'
              }`}
            >
              {o.orderNumber} · {o.statusStep === 5 ? 'Delivered' : o.statusStep === 1 ? 'Confirmed' : 'In Transit'}
            </button>
          ))}
        </div>
      </header>

      <div className="section-pad pt-10">
        {!matchedOrder ? (
          <div className="editorial-card py-16 text-center space-y-4">
            <Package size={40} className="mx-auto text-[#8a9082]" />
            <h2 className="text-2xl font-semibold">
              No shipment found for &ldquo;{activeOrderNumber}&rdquo;.
            </h2>
            <p className="text-xs text-[#60675a] max-w-md mx-auto">
              Check your confirmation email for your <code className="font-mono">YC-2026-XXXX</code> reference, or click one of the active sample orders above.
            </p>
            <button
              type="button"
              onClick={() => selectQuickOrder(orders[0].orderNumber)}
              className="button button-blue"
            >
              View Order {orders[0].orderNumber}
            </button>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Top Status Banner + 5-Stage Milestone Stepper */}
            <section className="editorial-card is-dark space-y-8">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-white/10 pb-6">
                <div>
                  <span className="mono text-[10px] text-[var(--cyan)]">
                    {matchedOrder.orderNumber} · {matchedOrder.carrier}
                  </span>
                  <h2 className="text-2xl md:text-3xl font-semibold tracking-tight mt-1">
                    {matchedOrder.statusLabel}
                  </h2>
                  <p className="text-xs text-[#adb4bf] mt-1">
                    Placed {matchedOrder.placedAt} · Tracking ID:{' '}
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(matchedOrder.trackingCode);
                        showToast(`Copied tracking code ${matchedOrder.trackingCode}`);
                      }}
                      className="font-mono underline text-white"
                    >
                      {matchedOrder.trackingCode}
                    </button>
                  </p>
                </div>

                <div className="bg-white/10 px-4 py-3 border border-white/15 text-right">
                  <span className="mono text-[9px] text-[#9ea6b2] block">ESTIMATED DELIVERY</span>
                  <strong className="text-base text-white">{matchedOrder.estimatedDelivery}</strong>
                </div>
              </div>

              {/* 5-Stage Milestone Stepper */}
              <div className="grid sm:grid-cols-5 gap-4">
                {milestones.map((m) => {
                  const done = matchedOrder.statusStep >= m.step;
                  const current = matchedOrder.statusStep === m.step;
                  return (
                    <div
                      key={m.step}
                      className={`p-4 border transition-colors ${
                        current
                          ? 'border-[var(--cyan)] bg-[#2349ed33]'
                          : done
                          ? 'border-white/25 bg-white/5'
                          : 'border-white/10 opacity-45'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-mono text-[10px] text-[#9eb0ff]">
                          0{m.step}
                        </span>
                        {done && <Check size={14} className="text-[var(--cyan)]" />}
                      </div>
                      <strong className="text-xs block">{m.label}</strong>
                      <span className="text-[11px] text-[#a7aeb9]">{m.sub}</span>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Telemetry Log + Destination & Manifest */}
            <div className="grid lg:grid-cols-12 gap-8">
              <section className="lg:col-span-7 editorial-card space-y-5">
                <h3 className="text-lg font-semibold tracking-tight border-b border-[var(--line)] pb-3">
                  Chronological Scan Telemetry
                </h3>
                <div className="space-y-5">
                  {matchedOrder.events.map((ev, idx) => (
                    <div key={idx} className="grid sm:grid-cols-[150px_1fr] gap-3 pb-4 border-b border-[#dfe2da] last:border-b-0">
                      <div className="font-mono text-[10px] text-[#60675a]">
                        <strong className="block text-[#18191a]">{ev.date}</strong>
                        <span>{ev.time}</span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              idx === 0 ? 'bg-[var(--blue)]' : 'bg-[#8d9386]'
                            }`}
                          />
                          <strong className="text-sm">{ev.status}</strong>
                        </div>
                        <p className="mono text-[10px] text-[var(--blue)] mt-0.5 pl-4">
                          {ev.location}
                        </p>
                        <p className="text-xs text-[#555b4f] mt-1 pl-4 leading-relaxed">
                          {ev.detail}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <aside className="lg:col-span-5 space-y-5">
                <div className="editorial-card space-y-3 text-xs">
                  <div className="flex items-center gap-2 font-semibold text-sm border-b border-[var(--line)] pb-2.5">
                    <MapPin size={15} className="text-[var(--blue)]" /> Route &amp; Destination
                  </div>
                  <div className="flex items-center justify-between py-1 font-mono text-[10px]">
                    <span>ORIGIN: PORTO ATELIER, PT</span>
                    <span>→</span>
                    <span>DEST: {matchedOrder.shippingAddress.city.toUpperCase()}</span>
                  </div>
                  <p className="text-[#555b4f]">
                    {matchedOrder.customerName}
                    <br />
                    {matchedOrder.shippingAddress.line1}
                    <br />
                    {matchedOrder.shippingAddress.city}, {matchedOrder.shippingAddress.postalCode},{' '}
                    {matchedOrder.shippingAddress.country}
                  </p>
                </div>

                <div className="editorial-card space-y-3">
                  <h3 className="text-sm font-semibold border-b border-[var(--line)] pb-2.5">
                    Consignment Pieces ({matchedOrder.items.length})
                  </h3>
                  {matchedOrder.items.map((it, i) => (
                    <Link
                      key={i}
                      to={`/product/${it.slug}`}
                      className="flex items-center gap-3 py-1.5 hover:text-[var(--blue)]"
                    >
                      <img
                        src={it.image}
                        alt={it.name}
                        className="w-12 h-14 object-contain bg-[#e3e6de] p-1"
                      />
                      <div className="flex-1 text-xs">
                        <strong className="block">{it.name}</strong>
                        <span className="text-[#60675a]">
                          {it.color} · Size {it.size} × {it.quantity}
                        </span>
                      </div>
                      <span className="font-mono text-xs">{formatPrice(it.price * it.quantity)}</span>
                    </Link>
                  ))}
                </div>

                <div className="flex gap-3">
                  <Link to="/contact" className="button button-outline flex-1">
                    Concierge Support
                  </Link>
                  <Link to="/returns-refunds" className="button button-outline flex-1">
                    Returns &amp; Exchanges
                  </Link>
                </div>
              </aside>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
