import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, ArrowUpRight, Box, Check, ChevronRight, Copy, Download, Edit3, Heart,
  Home, MapPin, MoreHorizontal, Package, Palette, Plus, RotateCcw, Search, ShieldCheck, ShoppingBag,
  Sparkles, Trash2, Truck, User, X,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Address, useEcosystem } from '../context/EcosystemContext';
import { MARKETPLACE_DESIGNS, MARKETPLACE_DESIGNS as DESIGNS } from '../data/phase2';
import { formatPrice } from '../data/catalog';
import { DesignCard, DesignMockup, DownloadDataButton, EmptyState, GarmentIllustration, PageHeading, StatCard, StatusPill, Toggle } from '../components/Phase2UI';
import { ProductCard } from '../components/ProductCard';
import { DialogDrawer } from '../components/Layout';

const artworkForDesign = (id: string) => id.includes('terrain') ? '/art/signal-terrain.png' : id.includes('bloom') ? '/art/cobalt-bloom.png' : '/art/chrome-wings.png';

export function CustomerOverviewPage() {
  const { orders, wishlistIds, bagCount } = useStore();
  const { profile, savedDesigns, likedDesignIds, followedCreators } = useEcosystem();
  const latest = orders[0];
  const spend = orders.reduce((sum, order) => sum + order.total, 0);
  return (
    <div className="p2-stack xl">
      <section className="customer-welcome">
        <div><span className="p2-kicker">Tuesday, 17 November</span><h1>Good morning, {profile.firstName}.</h1><p>Your wardrobe, your work and every good choice — in one place.</p></div>
        <Link to="/studio/products" className="p2-button primary"><Palette size={17}/> Create something new <ArrowUpRight size={16}/></Link>
        <span className="welcome-stamp" aria-hidden="true">YC<sup>®</sup><small>MEMBER / 2026</small></span>
      </section>
      <section className="stats-grid four">
        <StatCard label="Lifetime orders" value={String(orders.length).padStart(2, '0')} delta={`${formatPrice(spend)} total order value`} icon={<Package size={17}/>} bars={[35, 46, 40, 65, 58, 82, 70]}/>
        <StatCard label="Studio projects" value={String(savedDesigns.length).padStart(2, '0')} delta={`${savedDesigns.filter((d) => d.status === 'Draft').length} draft in progress`} icon={<Palette size={17}/>} bars={[20, 45, 35, 62, 74, 66, 88]}/>
        <StatCard label="Curated pieces" value={String(wishlistIds.length + likedDesignIds.length).padStart(2, '0')} delta={`${likedDesignIds.length} independent artworks`} icon={<Heart size={17}/>} bars={[40, 38, 52, 48, 70, 64, 79]}/>
        <StatCard label="Creators followed" value={String(followedCreators.length).padStart(2, '0')} delta="New drop this Friday" icon={<Sparkles size={17}/>} bars={[20, 20, 40, 40, 60, 80, 80]}/>
      </section>

      <div className="customer-overview-grid">
        <section className="p2-panel current-order-panel">
          <div className="p2-panel-head"><div><span className="p2-kicker">Latest order</span><h2>On its way to you.</h2></div><Link to={`/account/orders/${latest.orderNumber}`} className="text-arrow">Order details <ArrowUpRight size={15}/></Link></div>
          <div className="order-summary-line"><div><span>{latest.orderNumber}</span><strong>{latest.statusLabel}</strong></div><StatusPill status={latest.statusStep === 5 ? 'Delivered' : 'In transit'}/></div>
          <div className="order-progress" aria-label={`Order stage ${latest.statusStep} of 5`}>{[1,2,3,4,5].map((step) => <div key={step} className={step <= latest.statusStep ? 'complete' : ''}><i>{step < latest.statusStep ? <Check size={11}/> : step}</i><span>{['Confirmed', 'Inspection', 'Dispatched', 'In transit', 'Delivered'][step-1]}</span></div>)}</div>
          <div className="latest-order-products">{latest.items.slice(0,3).map((item) => <div key={`${item.productId}-${item.size}`}><img src={item.image} alt={item.name}/><span>{item.name}<small>{item.color} · {item.size} · Qty {item.quantity}</small></span></div>)}</div>
          <div className="order-delivery-note"><Truck size={18}/><div><strong>Estimated {latest.estimatedDelivery}</strong><span>{latest.carrier} · {latest.trackingCode}</span></div><Link to="/order-tracking">Track <ArrowRight size={14}/></Link></div>
        </section>
        <section className="p2-panel account-shortcuts">
          <div className="p2-panel-head"><div><span className="p2-kicker">Your space</span><h2>Pick up where you left off.</h2></div></div>
          <Link to="/account/designs"><span><Palette size={20}/></span><div><strong>Open your design shelf</strong><small>{savedDesigns.length} projects saved locally</small></div><ChevronRight size={18}/></Link>
          <Link to="/account/addresses"><span><MapPin size={20}/></span><div><strong>Delivery preferences</strong><small>2 saved addresses</small></div><ChevronRight size={18}/></Link>
          <Link to="/account/wishlist"><span><Heart size={20}/></span><div><strong>Your curated edit</strong><small>{wishlistIds.length + likedDesignIds.length} pieces and prints</small></div><ChevronRight size={18}/></Link>
          <Link to="/bag"><span><ShoppingBag size={20}/></span><div><strong>Return to your bag</strong><small>{bagCount} items waiting</small></div><ChevronRight size={18}/></Link>
        </section>
      </div>

      <section>
        <div className="p2-section-title"><div><span className="p2-kicker">Your design shelf</span><h2>Made by you. Ready when you are.</h2></div><Link to="/account/designs" className="text-arrow">View all projects <ArrowRight size={15}/></Link></div>
        <div className="saved-design-row">{savedDesigns.slice(0,3).map((design) => <Link to={`/studio/2d?project=${design.id}`} className="saved-design-mini" key={design.id}><div><GarmentIllustration color={design.color} artwork={artworkForDesign(design.id)} productType={design.productId === 1 ? 'Hoodie' : design.productId === 4 ? 'Polo' : 'T-Shirt'}/></div><span><strong>{design.name}</strong><small>{design.productName} · {design.updatedAt}</small></span><StatusPill status={design.status}/></Link>)}<Link to="/studio/products" className="saved-design-new"><Plus size={26}/><strong>Start a new canvas</strong><span>Choose an atelier blank</span></Link></div>
      </section>
      <section className="member-creator-callout"><div><span className="p2-kicker">The other side of your choice</span><h2>Your ideas could earn<br/>their own following.</h2><p>Publish original artwork on premium atelier blanks. You keep the credit and earn 15% from every sale.</p><Link to="/marketplace/become-creator" className="p2-button light">Meet the creator marketplace <ArrowUpRight size={16}/></Link></div><DesignMockup design={DESIGNS[3]}/></section>
    </div>
  );
}

export function ProfilePage() {
  const { profile, updateProfile } = useEcosystem();
  const [form, setForm] = useState(profile);
  useEffect(() => setForm(profile), [profile]);
  const set = (key: keyof typeof form, value: string) => setForm((prev) => ({ ...prev, [key]: value }));
  return <div className="p2-stack xl narrow-page">
    <PageHeading eyebrow="Personal information" title="Your profile, your rules." copy="This information personalizes your fit recommendations and checkout. Changes are stored on this device."/>
    <form className="p2-panel p2-form" onSubmit={(e) => { e.preventDefault(); updateProfile(form); }}>
      <div className="profile-identity-row"><div className="profile-avatar">{form.firstName[0]}{form.lastName[0]}<button type="button" aria-label="Profile photo is represented by initials" title="Initials are generated from your name"><Edit3 size={14}/></button></div><div><h2>{form.firstName} {form.lastName}</h2><p>Inner Circle member since March 2025</p><span>Member ID · YC-AM-2048</span></div></div>
      <div className="form-section-title"><User size={17}/><div><h3>Identity & contact</h3><p>Used for order updates and account personalization.</p></div></div>
      <div className="form-grid two">
        <label>First name<input required value={form.firstName} onChange={(e) => set('firstName', e.target.value)}/></label>
        <label>Last name<input required value={form.lastName} onChange={(e) => set('lastName', e.target.value)}/></label>
        <label>Email address<input required type="email" value={form.email} onChange={(e) => set('email', e.target.value)}/></label>
        <label>Phone number<input type="tel" value={form.phone} onChange={(e) => set('phone', e.target.value)}/></label>
        <label>Date of birth<input type="date" value={form.birthday} onChange={(e) => set('birthday', e.target.value)}/></label>
      </div>
      <div className="form-section-title"><Sparkles size={17}/><div><h3>Fit profile</h3><p>We use these choices to make size guidance more relevant.</p></div></div>
      <div className="form-grid two"><label>Usual size<select value={form.size} onChange={(e) => set('size', e.target.value)}>{['XS','S','M','L','XL','XXL'].map((size) => <option key={size}>{size}</option>)}</select></label><label>Preferred silhouette<select value={form.fit} onChange={(e) => set('fit', e.target.value)}>{['Oversized','Boxy','Structured','Relaxed'].map((fit) => <option key={fit}>{fit}</option>)}</select></label></div>
      <label>Personal note<textarea rows={3} maxLength={180} value={form.bio} onChange={(e) => set('bio', e.target.value)}/><small>{form.bio.length}/180 characters · Only visible to you</small></label>
      <div className="form-actions"><button type="button" className="p2-button ghost" onClick={() => setForm(profile)}>Discard changes</button><button className="p2-button primary" type="submit"><Check size={16}/> Save profile</button></div>
    </form>
  </div>;
}

const blankAddress = (): Address => ({ id: `addr-${Date.now()}`, label: 'Home', name: '', line1: '', line2: '', city: '', postalCode: '', country: 'United Kingdom', phone: '', isDefault: false });

export function AddressBookPage() {
  const { addresses, saveAddress, deleteAddress, setDefaultAddress, profile } = useEcosystem();
  const [editing, setEditing] = useState<Address | null>(null);
  const [form, setForm] = useState<Address>(blankAddress);
  const open = (address?: Address) => { const next = address ? { ...address } : { ...blankAddress(), name: `${profile.firstName} ${profile.lastName}`, phone: profile.phone }; setForm(next); setEditing(next); };
  const set = (key: keyof Address, value: string | boolean) => setForm((prev) => ({ ...prev, [key]: value }));
  return <div className="p2-stack xl">
    <PageHeading eyebrow="Delivery network" title="Address book." copy="Save the places your choices go. Set a default for a faster checkout." actions={<button className="p2-button primary" onClick={() => open()}><Plus size={16}/> Add address</button>}/>
    <div className="address-grid">{addresses.map((address) => <motion.article layout key={address.id} className={`address-card ${address.isDefault ? 'is-default' : ''}`}>
      <div className="address-card-top"><span>{address.label === 'Home' ? <Home size={18}/> : <MapPin size={18}/>}</span>{address.isDefault ? <StatusPill status="Default"/> : <button onClick={() => setDefaultAddress(address.id)}>Make default</button>}</div>
      <h2>{address.label}</h2><address><strong>{address.name}</strong>{address.line1}<br/>{address.line2 && <>{address.line2}<br/></>}{address.city}, {address.postalCode}<br/>{address.country}<br/><span>{address.phone}</span></address>
      <div className="address-card-actions"><button onClick={() => open(address)}><Edit3 size={14}/> Edit</button><button onClick={() => deleteAddress(address.id)} disabled={address.isDefault} title={address.isDefault ? 'Set another default before deleting this address' : 'Remove address'}><Trash2 size={14}/> Remove</button></div>
    </motion.article>)}<button className="address-add-card" onClick={() => open()}><Plus size={26}/><strong>Add another address</strong><span>Home, studio, or somewhere new</span></button></div>
    <div className="p2-info-strip"><ShieldCheck size={20}/><div><strong>Private by default.</strong><span>Your addresses stay in this browser for this frontend demonstration. No address is transmitted.</span></div></div>
    <AnimatePresence>{editing && <DialogDrawer title={addresses.some((a) => a.id === editing.id) ? 'Edit address' : 'Add address'} onClose={() => setEditing(null)}><form className="drawer-content p2-form" onSubmit={(e) => { e.preventDefault(); saveAddress(form); setEditing(null); }}>
      <span className="p2-kicker">Delivery details</span><h2>{addresses.some((a) => a.id === editing.id) ? 'Edit address' : 'A new destination.'}</h2>
      <div className="form-grid two"><label>Label<select value={form.label} onChange={(e) => set('label', e.target.value)}><option>Home</option><option>Studio</option><option>Work</option><option>Other</option></select></label><label>Full name<input required value={form.name} onChange={(e) => set('name', e.target.value)}/></label></div>
      <label>Address line 1<input required value={form.line1} onChange={(e) => set('line1', e.target.value)} placeholder="Street and number"/></label><label>Address line 2 <span>(optional)</span><input value={form.line2} onChange={(e) => set('line2', e.target.value)} placeholder="Apartment, floor or studio"/></label>
      <div className="form-grid two"><label>City<input required value={form.city} onChange={(e) => set('city', e.target.value)}/></label><label>Postal code<input required value={form.postalCode} onChange={(e) => set('postalCode', e.target.value)}/></label><label>Country<select value={form.country} onChange={(e) => set('country', e.target.value)}>{['United Kingdom','United States','Germany','France','Japan','United Arab Emirates'].map((c) => <option key={c}>{c}</option>)}</select></label><label>Phone<input required value={form.phone} onChange={(e) => set('phone', e.target.value)}/></label></div>
      <label className="check-label"><input type="checkbox" checked={form.isDefault} onChange={(e) => set('isDefault', e.target.checked)}/> Use as my default delivery address</label>
      <button className="p2-button primary full" type="submit"><Check size={16}/> Save address</button>
    </form></DialogDrawer>}</AnimatePresence>
  </div>;
}

export function OrderHistoryPage() {
  const { orders } = useStore();
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('All');
  const filtered = orders.filter((order) => (status === 'All' || (status === 'Delivered' ? order.statusStep === 5 : order.statusStep < 5)) && `${order.orderNumber} ${order.items.map((i) => i.name).join(' ')}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="p2-stack xl">
    <PageHeading eyebrow="Order archive" title="Every choice, accounted for." copy={`${orders.length} orders placed through your YOUR CHOICE account.`} actions={<Link to="/shop" className="p2-button secondary">Shop new arrivals <ArrowUpRight size={15}/></Link>}/>
    <div className="list-controls"><div className="p2-search"><Search size={16}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search order number or product" aria-label="Search orders"/></div><div className="segmented-control">{['All','In progress','Delivered'].map((item) => <button key={item} className={status === item ? 'active' : ''} onClick={() => setStatus(item)}>{item}</button>)}</div></div>
    <div className="orders-list">{filtered.map((order) => <article className="order-history-card" key={order.orderNumber}>
      <div className="order-history-head"><div><span>Order</span><Link to={`/account/orders/${order.orderNumber}`}>{order.orderNumber}</Link></div><div><span>Placed</span><strong>{order.placedAt.split(' · ')[0]}</strong></div><div><span>Total</span><strong>{formatPrice(order.total)}</strong></div><StatusPill status={order.statusStep === 5 ? 'Delivered' : 'In transit'}/></div>
      <div className="order-history-body"><div className="order-thumbnails">{order.items.map((item) => <img key={`${item.productId}-${item.size}`} src={item.image} alt={item.name} title={`${item.name} · ${item.size}`}/>)}</div><div className="order-history-copy"><strong>{order.items[0].name}{order.items.length > 1 && ` + ${order.items.length - 1} more`}</strong><span>{order.statusStep === 5 ? `Delivered · ${order.estimatedDelivery}` : `Estimated ${order.estimatedDelivery}`}</span></div><div className="order-history-actions"><Link to="/order-tracking" className="p2-button ghost">Track</Link><Link to={`/account/orders/${order.orderNumber}`} className="p2-button secondary">View order <ArrowRight size={14}/></Link></div></div>
    </article>)}</div>
    {!filtered.length && <EmptyState title="No orders match that search." copy="Try another order number, product name or status." action={<button className="p2-button secondary" onClick={() => { setQuery(''); setStatus('All'); }}>Clear filters</button>}/>}
  </div>;
}

export function OrderDetailsPage() {
  const { orderId } = useParams();
  const { orders, addToBag } = useStore();
  const navigate = useNavigate();
  const order = orders.find((item) => item.orderNumber === orderId) || orders[0];
  const reorder = () => { order.items.forEach((item) => addToBag(item.productId, item.size, item.quantity, false)); navigate('/bag'); };
  return <div className="p2-stack xl">
    <Link to="/account/orders" className="back-link"><ArrowLeft size={15}/> All orders</Link>
    <PageHeading eyebrow={`Order / ${order.orderNumber}`} title={order.statusStep === 5 ? 'Delivered. Enjoy the choice.' : 'Your order is in motion.'} copy={`Placed ${order.placedAt} · ${order.items.reduce((sum, item) => sum + item.quantity, 0)} pieces`} actions={<button className="p2-button primary" onClick={reorder}><RotateCcw size={15}/> Reorder all</button>}/>
    <section className="p2-panel order-detail-progress"><div className="order-summary-line"><div><span>Current status</span><strong>{order.statusLabel}</strong></div><StatusPill status={order.statusStep === 5 ? 'Delivered' : 'In transit'}/></div><div className="order-progress">{[1,2,3,4,5].map((step) => <div key={step} className={step <= order.statusStep ? 'complete' : ''}><i>{step < order.statusStep ? <Check size={11}/> : step}</i><span>{['Confirmed','Inspection','Dispatched','In transit','Delivered'][step-1]}</span></div>)}</div><div className="order-delivery-note"><Truck size={18}/><div><strong>{order.statusStep === 5 ? 'Delivered' : `Estimated ${order.estimatedDelivery}`}</strong><span>{order.carrier} · {order.trackingCode}</span></div><Link to="/order-tracking">Full tracking <ArrowRight size={14}/></Link></div></section>
    <div className="order-detail-grid"><section className="p2-panel"><div className="p2-panel-head"><h2>Garment manifest</h2><span>{order.items.length} styles</span></div><div className="manifest-list">{order.items.map((item) => <div key={`${item.productId}-${item.size}`}><img src={item.image} alt={item.name}/><div><Link to={`/product/${item.slug}`}>{item.name}</Link><span>{item.color} · Size {item.size} · Qty {item.quantity}</span><small>Cut & sewn in Porto, Portugal</small></div><strong>{formatPrice(item.price * item.quantity)}</strong></div>)}</div></section>
      <aside className="p2-panel order-totals"><h2>Order summary</h2><dl><div><dt>Subtotal</dt><dd>{formatPrice(order.subtotal)}</dd></div><div><dt>Discount</dt><dd>−{formatPrice(order.discount)}</dd></div><div><dt>Delivery</dt><dd>{order.shippingCost ? formatPrice(order.shippingCost) : 'Complimentary'}</dd></div>{order.packagingCost > 0 && <div><dt>Collector packaging</dt><dd>{formatPrice(order.packagingCost)}</dd></div>}<div className="total"><dt>Total</dt><dd>{formatPrice(order.total)}</dd></div></dl><p><ShieldCheck size={15}/> Duties and taxes included. Paid with {order.paymentSummary}.</p></aside></div>
    <div className="order-detail-grid"><section className="p2-panel"><div className="p2-panel-head"><h2>Tracking journal</h2><span>Newest first</span></div><div className="tracking-journal">{order.events.map((event, i) => <div key={`${event.date}-${event.time}`}><i className={i === 0 ? 'active' : ''}/><span>{event.date}<small>{event.time}</small></span><div><strong>{event.status}</strong><p>{event.detail}</p><small>{event.location}</small></div></div>)}</div></section><aside className="p2-panel shipping-address-panel"><h2>Delivery address</h2><address><strong>{order.customerName}</strong>{order.shippingAddress.line1}<br/>{order.shippingAddress.line2}{order.shippingAddress.line2 && <br/>}{order.shippingAddress.city}, {order.shippingAddress.postalCode}<br/>{order.shippingAddress.country}</address><div><span>Delivery method</span><strong>{order.shippingMethod}</strong></div><Link to="/contact" className="text-arrow">Need help with this order? <ArrowUpRight size={14}/></Link></aside></div>
  </div>;
}

export function SavedDesignsPage() {
  const { savedDesigns, duplicateStudioDesign, deleteStudioDesign } = useEcosystem();
  const [query, setQuery] = useState('');
  const navigate = useNavigate();
  const filtered = savedDesigns.filter((design) => `${design.name} ${design.productName}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="p2-stack xl"><PageHeading eyebrow="Personal studio shelf" title="Saved designs." copy="Your private works in progress. Projects are stored locally in this browser." actions={<Link to="/studio/products" className="p2-button primary"><Plus size={16}/> New design</Link>}/>
    <div className="list-controls"><div className="p2-search"><Search size={16}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search your projects" aria-label="Search saved designs"/></div><span className="mono-note">{filtered.length} PROJECTS · LOCAL STORAGE</span></div>
    <div className="saved-design-grid">{filtered.map((design) => <motion.article layout key={design.id} className="saved-project-card"><Link to={`/studio/2d?project=${design.id}`} className="saved-project-visual"><GarmentIllustration color={design.color} artwork={artworkForDesign(design.id)} productType={design.productId === 1 ? 'Hoodie' : design.productId === 4 ? 'Polo' : 'T-Shirt'}/><span>Open in 2D Studio <ArrowUpRight size={15}/></span></Link><div className="saved-project-info"><div><StatusPill status={design.status}/><span>{design.updatedAt}</span></div><h2>{design.name}</h2><p>{design.productName}</p><div><Link to={`/studio/2d?project=${design.id}`}><Edit3 size={14}/> Continue</Link><button onClick={() => { const id = duplicateStudioDesign(design.id); if (id) navigate(`/studio/2d?project=${id}`); }}><Copy size={14}/> Duplicate</button><button className="danger" onClick={() => deleteStudioDesign(design.id)} aria-label={`Delete ${design.name}`}><Trash2 size={14}/></button></div></div></motion.article>)}</div>
    {!filtered.length && <EmptyState icon={<Palette size={30}/>} title="No saved designs found." copy="Start a new canvas or clear your search to see your shelf." action={<Link to="/studio/products" className="p2-button primary">Open Design Studio</Link>}/>}
  </div>;
}

export function AccountWishlistPage() {
  const { products, wishlistIds } = useStore();
  const { likedDesignIds } = useEcosystem();
  const [tab, setTab] = useState<'all' | 'products' | 'artwork'>('all');
  const productList = products.filter((p) => wishlistIds.includes(p.id));
  const designList = MARKETPLACE_DESIGNS.filter((d) => likedDesignIds.includes(d.id));
  return <div className="p2-stack xl"><PageHeading eyebrow="Your curated edit" title="Worth coming back to." copy={`${productList.length} garments and ${designList.length} independent artworks, saved in one place.`} actions={<Link to="/marketplace/explore" className="p2-button secondary">Discover more <ArrowUpRight size={15}/></Link>}/>
    <div className="segmented-control large">{(['all','products','artwork'] as const).map((item) => <button className={tab === item ? 'active' : ''} key={item} onClick={() => setTab(item)}>{item === 'all' ? `Everything (${productList.length + designList.length})` : item === 'products' ? `Garments (${productList.length})` : `Artwork (${designList.length})`}</button>)}</div>
    {(tab === 'all' || tab === 'artwork') && <section><div className="p2-section-title"><div><span className="p2-kicker">Independent artwork</span><h2>Prints with a point of view.</h2></div></div><div className="market-grid three">{designList.map((design, i) => <DesignCard key={design.id} design={design} index={i}/>)}</div>{!designList.length && <EmptyState title="No saved artwork yet." copy="Explore the marketplace and tap the heart on work you want to remember."/>}</section>}
    {(tab === 'all' || tab === 'products') && <section><div className="p2-section-title"><div><span className="p2-kicker">Atelier garments</span><h2>Your future rotation.</h2></div><Link to="/wishlist" className="text-arrow">Open full wishlist <ArrowUpRight size={14}/></Link></div><div className="account-product-grid">{productList.map((product, i) => <ProductCard key={product.id} product={product} index={i}/>)}</div>{!productList.length && <EmptyState title="Your garment edit is empty." copy="Save a silhouette from the shop to see it here."/>}</section>}
  </div>;
}

export function AccountSettingsPage() {
  const ecosystem = useEcosystem();
  const { settings, updateSetting, profile, addresses, savedDesigns, resetLocalData } = ecosystem;
  const { member, logoutMember } = useStore();
  const [resetConfirm, setResetConfirm] = useState(false);
  const groups = [
    { title: 'Notifications', copy: 'Choose what earns a place in your inbox.', items: [{ key: 'orderUpdates', title: 'Order & delivery updates', copy: 'Confirmation, quality inspection and courier milestones.' }, { key: 'creatorDrops', title: 'Creator drops', copy: 'New work from creators you follow and editorial selections.' }, { key: 'studioNotes', title: 'Studio notes', copy: 'Design techniques, product blanks and creative prompts.' }, { key: 'newsletter', title: 'The Inner Circle newsletter', copy: 'A considered monthly edit. No daily noise.' }] },
    { title: 'Privacy & personalization', copy: 'Control how this local experience uses your choices.', items: [{ key: 'publicWishlist', title: 'Public wishlist', copy: 'Allow anyone with your wishlist link to view your curated edit.' }, { key: 'personalizedEdits', title: 'Personalized edits', copy: 'Use your saved sizes and liked work to tune recommendations.' }] },
  ];
  return <div className="p2-stack xl narrow-page"><PageHeading eyebrow="Account controls" title="Settings & privacy." copy="Simple controls, clear language and no hidden connections."/>
    {groups.map((group) => <section className="p2-panel settings-section" key={group.title}><div className="form-section-title"><SettingsIcon/><div><h2>{group.title}</h2><p>{group.copy}</p></div></div>{group.items.map((item) => <div className="setting-row" key={item.key}><div><strong>{item.title}</strong><span>{item.copy}</span></div><Toggle label={item.title} checked={Boolean(settings[item.key])} onChange={(value) => updateSetting(item.key, value)}/></div>)}</section>)}
    <section className="p2-panel settings-section"><div className="form-section-title"><ShieldCheck size={19}/><div><h2>Your local data</h2><p>Download a portable copy or restore the authored sample workspace.</p></div></div><div className="settings-data-actions"><DownloadDataButton data={{ exportedAt: new Date().toISOString(), profile, addresses, savedDesigns, settings }} label="Download my data"/><button className="p2-button secondary danger-outline" onClick={() => setResetConfirm(true)}><RotateCcw size={15}/> Restore sample data</button></div>{resetConfirm && <div className="inline-confirm"><div><strong>Restore the original Phase 02 workspace?</strong><span>This replaces your local profile edits, saved projects and creator submissions.</span></div><button onClick={() => setResetConfirm(false)}>Cancel</button><button className="danger" onClick={() => { resetLocalData(); setResetConfirm(false); }}>Restore data</button></div>}</section>
    <section className="p2-panel settings-section"><div className="setting-row"><div><strong>Storefront session</strong><span>{member ? `Signed in as ${member.email}` : 'You are browsing the sample member workspace. Sign in from the storefront to personalize your session.'}</span></div>{member ? <button className="p2-button secondary" onClick={logoutMember}>Sign out</button> : <Link to="/login" className="p2-button secondary">Go to sign in</Link>}</div></section>
  </div>;
}

function SettingsIcon() { return <User size={19}/>; }
