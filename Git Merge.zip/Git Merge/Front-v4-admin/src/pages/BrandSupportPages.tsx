import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  ArrowUpRight,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  Globe,
  Layers,
  Mail,
  MapPin,
  MessageSquare,
  Search,
  Send,
  Sparkles,
} from 'lucide-react';
import { FAQ_ITEMS, FaqEntry } from '../data/catalog';
import { OfficialLogoLockup, Reveal } from '../components/BrandMarks';
import { SizeGuideInteractive } from '../components/SizeGuideContent';
import { useStore } from '../context/StoreContext';

/* ============================================================================
   16. ABOUT (/about)
   ============================================================================ */
export function AboutPage() {
  const { setStudioDrawerOpen } = useStore();

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>About YOUR CHOICE</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <i /> INDEPENDENT BY DESIGN · EST. FOR SELF-EXPRESSION
            </p>
            <h1 className="page-title">
              ALWAYS THE
              <br />
              <span>BEST CHOICE.</span>
            </h1>
          </div>
          <p className="page-lead">
            YOUR CHOICE was founded on a simple refusal: everyday essentials shouldn’t force you to choose between architectural quality and independent personal identity.
          </p>
        </div>
      </header>

      {/* Official Crest & Identity Stage */}
      <section className="section-pad pt-12">
        <div className="bg-[#0f1217] text-[#f5f5f1] border border-white/10 p-8 md:p-14 grid lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5 flex flex-col items-center justify-center p-8 bg-[#080a0d] border border-[#2349ed44]">
            <OfficialLogoLockup className="w-72 max-w-full h-auto object-contain" />
          </div>

          <div className="lg:col-span-7 space-y-5">
            <span className="eyebrow text-[var(--cyan)]">
              <i /> OFFICIAL EMBLEM &amp; MONOGRAM ANATOMY
            </span>
            <h2 className="display-condensed text-5xl md:text-6xl">
              THE WINGED YC MARK: ENGINEERED CRAFT MEETS CONNECTED CULTURE.
            </h2>
            <p className="text-xs md:text-sm text-[#c3c8d1] leading-relaxed">
              Our official crest unites three elements into a single soaring monogram. On the left wing, precision circuit lines represent pattern engineering and technical garment construction. On the right wing, interconnected nodes embody our global network of independent creators. At the center, the sculpted <strong>YC</strong> falcon silhouette rises in signature Royal Blue (<code className="font-mono text-[#7a96ff]">#2349ed</code>).
            </p>
            <div className="grid sm:grid-cols-3 gap-4 pt-3 border-t border-white/10 text-xs">
              <div>
                <span className="mono text-[9px] text-[var(--cyan)] block">LEFT WING</span>
                <strong>Pattern &amp; Textile Precision</strong>
              </div>
              <div>
                <span className="mono text-[9px] text-[var(--cyan)] block">CENTER MONOGRAM</span>
                <strong>Unrestricted YC Flight</strong>
              </div>
              <div>
                <span className="mono text-[9px] text-[var(--cyan)] block">RIGHT WING</span>
                <strong>Creator Network</strong>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Three Pillars */}
      <section className="section-pad pt-14">
        <Reveal className="grid md:grid-cols-3 gap-6">
          {[
            {
              num: '01 / DESIGN IT',
              title: 'Considered Proportions First',
              body: 'Every T-shirt, piqué polo, and outer shell begins on the pattern table — dialing collar stance, shoulder drop, and hem break to the millimeter.',
            },
            {
              num: '02 / WEAR IT',
              title: 'Tactile Heavyweight Fabrics',
              body: 'We work exclusively with 285–500 GSM GOTS-certified organic cottons, Biella-spun merino blends, and water-repellent technical nylons that improve with wear.',
            },
            {
              num: '03 / EARN FROM IT',
              title: 'Built for Independent Creators',
              body: 'Through our upcoming Design Studio, independent artists transform our 320 GSM Atelier Blanks into numbered runs and earn royalties on every piece.',
            },
          ].map((pillar) => (
            <div key={pillar.num} className="editorial-card space-y-3">
              <span className="mono text-[10px] text-[var(--blue)] font-semibold">
                {pillar.num}
              </span>
              <h3 className="text-xl font-semibold tracking-tight">{pillar.title}</h3>
              <p className="text-xs text-[#596052] leading-relaxed">{pillar.body}</p>
            </div>
          ))}
        </Reveal>
      </section>

      {/* Editorial Split Image + Supply Chain Metrics */}
      <section className="section-pad pt-14">
        <div className="grid lg:grid-cols-12 gap-8 items-center border-t border-[var(--line)] pt-14">
          <div className="lg:col-span-6">
            <img
              src="/images/collection-polos-hero.webp"
              alt="YOUR CHOICE Atelier garments in architectural gallery"
              className="w-full h-[420px] object-cover border border-[var(--line)]"
            />
          </div>
          <div className="lg:col-span-6 space-y-5">
            <span className="eyebrow">
              <Layers size={13} className="text-[var(--blue)]" /> TRANSPARENT ATELIER STANDARDS
            </span>
            <h2 className="display-condensed text-5xl">
              SMALL BATCHES. ZERO DEADSTOCK WASTE.
            </h2>
            <p className="text-xs md:text-sm text-[#545a4e] leading-relaxed">
              Rather than overproducing seasonal trends, YOUR CHOICE releases tightly edited chapters. Our knitting and cut-and-sew partners in Barcelos, Guimarães, and Porto operate on closed-loop water filtration and renewable solar power.
            </p>
            <div className="grid grid-cols-3 gap-4 py-4 border-y border-[var(--line)]">
              <div>
                <strong className="display-condensed text-4xl text-[var(--blue)]">100%</strong>
                <span className="block mono text-[9px] text-[#60675a]">GOTS ORGANIC COTTON</span>
              </div>
              <div>
                <strong className="display-condensed text-4xl">310+</strong>
                <span className="block mono text-[9px] text-[#60675a]">GSM SIGNATURE JERSEY</span>
              </div>
              <div>
                <strong className="display-condensed text-4xl">0%</strong>
                <span className="block mono text-[9px] text-[#60675a]">VIRGIN PLASTIC PACKAGING</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link to="/shop" className="button button-blue">
                Explore Vol. 01 Collection <ArrowRight size={16} />
              </Link>
              <button
                type="button"
                onClick={() => setStudioDrawerOpen(true)}
                className="button button-outline"
              >
                Join Design Studio Waitlist <Sparkles size={15} />
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

/* ============================================================================
   17. CONTACT (/contact)
   ============================================================================ */
export function ContactPage() {
  const [topic, setTopic] = useState('Order & Shipment Inquiry');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [orderRef, setOrderRef] = useState('');
  const [message, setMessage] = useState('');
  const [ticketId, setTicketId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const id = `YC-CARE-${Math.floor(1000 + Math.random() * 8999)}`;
    setTicketId(id);
  };

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Contact Concierge</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <i /> CLIENT CONCIERGE &amp; STUDIO DESK
            </p>
            <h1 className="page-title">
              SPEAK WITH <span>US.</span>
            </h1>
          </div>
          <p className="page-lead">
            Direct human support from people who know every garment measurement, fabric weight, and courier route. Average response time: under 4 business hours.
          </p>
        </div>
      </header>

      <div className="two-col-commerce">
        {/* Left: Inquiry Form */}
        <div>
          {ticketId ? (
            <div className="editorial-card space-y-5">
              <div className="w-12 h-12 bg-[var(--blue)] text-white grid place-items-center">
                <CheckCircle2 size={24} />
              </div>
              <div className="space-y-2">
                <span className="mono text-[10px] text-[var(--blue)]">
                  CONCIERGE TICKET #{ticketId}
                </span>
                <h2 className="text-2xl font-semibold tracking-tight">
                  Message received by our studio desk.
                </h2>
                <p className="text-xs text-[#555b4f] leading-relaxed">
                  Thank you, <strong>{name}</strong>. Our specialist team for{' '}
                  <strong>{topic}</strong> will reply to <strong>{email}</strong> within 4 business hours.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setTicketId('');
                  setMessage('');
                }}
                className="button button-outline"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="editorial-card space-y-5">
              <div className="flex items-center justify-between border-b border-[var(--line)] pb-3">
                <h2 className="text-lg font-semibold tracking-tight">Direct Studio Message</h2>
                <span className="mono text-[9px] text-[#60675a]">MON–SAT · 08:00–20:00 UTC</span>
              </div>

              <div className="field-group">
                <label className="field-label" htmlFor="cnt-topic">
                  Inquiry Department
                </label>
                <select
                  id="cnt-topic"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="field-select"
                >
                  <option>Order &amp; Shipment Inquiry</option>
                  <option>Sizing, Drape &amp; Styling Advice</option>
                  <option>Returns &amp; Instant Size Exchange</option>
                  <option>Design Studio Creator Partnerships</option>
                  <option>Press, Editorial &amp; Showroom</option>
                </select>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="field-group">
                  <label className="field-label" htmlFor="cnt-name">
                    Full Name *
                  </label>
                  <input
                    id="cnt-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name"
                    className="field-input"
                  />
                </div>
                <div className="field-group">
                  <label className="field-label" htmlFor="cnt-email">
                    Email Address *
                  </label>
                  <input
                    id="cnt-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@domain.com"
                    className="field-input"
                  />
                </div>
              </div>

              <div className="field-group">
                <label className="field-label" htmlFor="cnt-order">
                  Order Reference (Optional)
                </label>
                <input
                  id="cnt-order"
                  type="text"
                  value={orderRef}
                  onChange={(e) => setOrderRef(e.target.value)}
                  placeholder="e.g. YC-2026-8841"
                  className="field-input font-mono"
                />
              </div>

              <div className="field-group">
                <label className="field-label" htmlFor="cnt-msg">
                  How can we help? *
                </label>
                <textarea
                  id="cnt-msg"
                  rows={5}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Share details on garment sizing, order modifications, or partnership inquiries..."
                  className="field-textarea"
                />
              </div>

              <button type="submit" className="button button-blue w-full">
                Dispatch Message to Concierge <Send size={16} />
              </button>
            </form>
          )}
        </div>

        {/* Right: Studio Hubs & Instant Self-Service */}
        <aside className="space-y-5">
          <div className="editorial-card space-y-4">
            <span className="eyebrow">
              <Globe size={13} className="text-[var(--blue)]" /> GLOBAL CHANNELS &amp; STUDIOS
            </span>
            <div className="space-y-3.5 text-xs">
              <div className="pb-3 border-b border-[#dfe2da]">
                <strong className="block text-sm">Client Care &amp; Styling</strong>
                <p className="text-[#596052] mt-0.5 flex items-center gap-2">
                  <Mail size={12} /> care@yourchoice.studio
                </p>
                <p className="text-[#596052] mt-0.5 flex items-center gap-2">
                  <Clock size={12} /> Mon–Sat, 08:00 – 20:00 UTC
                </p>
              </div>

              <div className="pb-3 border-b border-[#dfe2da]">
                <strong className="block text-sm">London Creative Studio</strong>
                <p className="text-[#596052] mt-0.5 flex items-start gap-2">
                  <MapPin size={12} className="mt-0.5 shrink-0" /> 42 Redchurch Street, Shoreditch, London E2 7DP (By Appointment)
                </p>
              </div>

              <div>
                <strong className="block text-sm">Porto Production Atelier</strong>
                <p className="text-[#596052] mt-0.5 flex items-start gap-2">
                  <MapPin size={12} className="mt-0.5 shrink-0" /> Zona Industrial da Maia, Porto, Portugal · Quality &amp; Logistics Hub
                </p>
              </div>
            </div>
          </div>

          <div className="editorial-card space-y-3">
            <span className="mono text-[9px] text-[#60675a] block">INSTANT SELF-SERVICE</span>
            {[
              { label: 'Track an Existing Order', to: '/order-tracking' },
              { label: 'Start a Return or Free Size Exchange', to: '/returns-refunds' },
              { label: 'Size Guide & Fit Finder Calculator', to: '/size-guide' },
              { label: 'Frequently Asked Questions', to: '/faq' },
            ].map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="flex items-center justify-between py-2 border-b border-[#dfe2da] last:border-b-0 text-xs font-medium hover:text-[var(--blue)]"
              >
                <span>{item.label}</span>
                <ArrowUpRight size={14} />
              </Link>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ============================================================================
   18. FAQ (/faq)
   ============================================================================ */
export function FaqPage() {
  const [search, setSearch] = useState('');
  const [activeCat, setActiveCat] = useState<'All' | FaqEntry['category']>('All');
  const [openIds, setOpenIds] = useState<string[]>([FAQ_ITEMS[0].id, FAQ_ITEMS[2].id]);

  const categories: ('All' | FaqEntry['category'])[] = [
    'All',
    'Sizing & Fit',
    'Products & Care',
    'Orders & Payment',
    'Shipping & Delivery',
    'Returns & Refunds',
    'Design Studio',
  ];

  const filteredFaqs = useMemo(() => {
    return FAQ_ITEMS.filter((item) => {
      if (activeCat !== 'All' && item.category !== activeCat) return false;
      if (search.trim()) {
        return `${item.question} ${item.answer} ${item.category}`
          .toLowerCase()
          .includes(search.trim().toLowerCase());
      }
      return true;
    });
  }, [activeCat, search]);

  const toggleId = (id: string) => {
    setOpenIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <span>Frequently Asked Questions</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <i /> STRAIGHT ANSWERS · NO SMALL PRINT
            </p>
            <h1 className="page-title">
              CLIENT <span>FAQ.</span>
            </h1>
          </div>
          <div className="space-y-3">
            <p className="page-lead">
              Everything you need to know about our 310 GSM jersey, piqué polo sizing, DDP global shipping, returns, and the Design Studio.
            </p>
            <div className="flex items-center gap-2.5 border border-[#c5c8bf] bg-[#fafaf7] px-3.5 py-2.5">
              <Search size={16} className="text-[var(--blue)]" />
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter questions (e.g. shrink, polo, duties, refund)..."
                className="w-full text-xs bg-transparent outline-none"
              />
            </div>
          </div>
        </div>
      </header>

      <div className="section-pad pt-10 max-w-5xl mx-auto space-y-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="category-tabs">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveCat(cat)}
                className={activeCat === cat ? 'active' : ''}
              >
                {cat}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() =>
              setOpenIds(
                openIds.length === filteredFaqs.length ? [] : filteredFaqs.map((f) => f.id)
              )
            }
            className="text-link"
          >
            {openIds.length === filteredFaqs.length ? 'Collapse all' : 'Expand all'}
          </button>
        </div>

        <div className="border-t border-[var(--line)]">
          {filteredFaqs.map((item) => {
            const isOpen = openIds.includes(item.id);
            return (
              <div key={item.id} className="border-b border-[var(--line)]">
                <button
                  type="button"
                  aria-expanded={isOpen}
                  onClick={() => toggleId(item.id)}
                  className="w-full py-5 flex items-start justify-between gap-4 text-left"
                >
                  <div>
                    <span className="mono text-[9px] text-[var(--blue)] block mb-1">
                      {item.category}
                    </span>
                    <strong className="text-base font-semibold tracking-tight">
                      {item.question}
                    </strong>
                  </div>
                  <ChevronDown
                    size={18}
                    className={`mt-1 shrink-0 transition-transform ${
                      isOpen ? 'rotate-180 text-[var(--blue)]' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="pb-6 pr-8 text-xs md:text-sm text-[#545a4e] leading-relaxed">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
          {filteredFaqs.length === 0 && (
            <div className="py-14 text-center text-sm text-[#60675a]">
              No questions matched &ldquo;{search}&rdquo;. Try clearing your search or contact our concierge below.
            </div>
          )}
        </div>

        {/* Escalation Card */}
        <div className="editorial-card is-dark flex flex-wrap items-center justify-between gap-6">
          <div className="space-y-1.5">
            <span className="eyebrow text-[var(--cyan)]">
              <MessageSquare size={13} /> NEED PERSONAL STYLING OR ORDER HELP?
            </span>
            <h2 className="text-2xl font-semibold">Speak directly with our Studio Concierge.</h2>
            <p className="text-xs text-[#b7bec8]">
              Available Monday–Saturday with under 4-hour turnaround.
            </p>
          </div>
          <Link to="/contact" className="button button-blue">
            Contact Concierge <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   19. SIZE GUIDE (/size-guide)
   ============================================================================ */
export function SizeGuidePage() {
  return (
    <div className="page-shell">
      <nav className="breadcrumb-bar" aria-label="Breadcrumb">
        <Link to="/">Home</Link>
        <ChevronRight size={11} />
        <Link to="/shop">Shop</Link>
        <ChevronRight size={11} />
        <span>Size Guide &amp; Fit Architecture</span>
      </nav>

      <header className="page-masthead">
        <div className="page-masthead-grid">
          <div>
            <p className="eyebrow">
              <i /> GARMENT SPEC SHEETS &amp; INTERACTIVE CALCULATOR
            </p>
            <h1 className="page-title">
              SIZE <span>GUIDE.</span>
            </h1>
          </div>
          <p className="page-lead">
            Every YOUR CHOICE garment is measured flat across the chest, shoulder, length, and sleeve. Use our Interactive Fit Finder below or compare against a piece you already love.
          </p>
        </div>
      </header>

      <div className="section-pad pt-10 space-y-14">
        <SizeGuideInteractive initialCategory="t-shirts" />

        {/* How to Measure Guide */}
        <section className="border-t border-[var(--line)] pt-12">
          <span className="eyebrow mb-6">
            <i /> HOW TO MEASURE YOUR REFERENCE GARMENT
          </span>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              {
                code: 'A · CHEST',
                desc: 'Lay your favorite T-shirt or polo flat. Measure straight across 2.5cm below the armhole seam and double the number.',
              },
              {
                code: 'B · SHOULDER',
                desc: 'Measure straight across the upper back from left shoulder seam to right shoulder seam.',
              },
              {
                code: 'C · LENGTH',
                desc: 'Measure vertically from the highest point of the collar rib beside the neck down to the bottom hem.',
              },
              {
                code: 'D · SLEEVE',
                desc: 'Measure from the outer shoulder seam down to the edge of the sleeve hem or rib cuff.',
              },
            ].map((m) => (
              <div key={m.code} className="editorial-card space-y-2">
                <strong className="mono text-xs text-[var(--blue)] block">{m.code}</strong>
                <p className="text-xs text-[#575d50] leading-relaxed">{m.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
