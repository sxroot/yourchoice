import React, { useMemo, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  Eye,
  EyeOff,
  KeyRound,
  LogOut,
  Mail,
  Package,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { OfficialLogoLockup } from '../components/BrandMarks';
import { useStore } from '../context/StoreContext';
import { formatPrice } from '../data/catalog';

function AuthBrandStage({
  eyebrow = 'INNER CIRCLE ACCESS',
  headline = 'NOT FOR EVERYONE. FOR YOU.',
  caption = 'Manage your saved rotation, track studio dispatches in real time, store fit preferences, and claim early access to Design Studio drops.',
}: {
  eyebrow?: string;
  headline?: string;
  caption?: string;
}) {
  return (
    <div className="auth-brand-stage">
      <div className="space-y-4">
        <span className="eyebrow text-[#8ea4ff]">
          <i /> {eyebrow}
        </span>
        <div className="py-4">
          <OfficialLogoLockup className="w-56 md:w-64 h-auto object-contain" />
        </div>
      </div>

      <div className="space-y-4 max-w-md">
        <h2 className="display-condensed text-5xl md:text-6xl leading-[0.9]">{headline}</h2>
        <p className="text-xs text-[#bec5d1] leading-relaxed">{caption}</p>

        <div className="grid grid-cols-2 gap-3 pt-4 border-t border-white/15 font-mono text-[10px] text-[#cfd5df]">
          <span>✓ INSTANT ORDER TELEMETRY</span>
          <span>✓ SAVED FIT ARCHITECTURE</span>
          <span>✓ CURATED WISHLIST SYNC</span>
          <span>✓ DESIGN STUDIO PRIORITY</span>
        </div>
      </div>

      <div className="flex items-center justify-between text-[10px] font-mono text-[#8b93a1] pt-6">
        <span>YOUR CHOICE® · ALWAYS THE BEST CHOICE</span>
        <span>VOL. 01</span>
      </div>
    </div>
  );
}

/* ============================================================================
   12. LOGIN (/login)
   ============================================================================ */
export function LoginPage() {
  const navigate = useNavigate();
  const { member, loginMember, logoutMember, orders, wishlistIds } = useStore();

  const [email, setEmail] = useState('member@yourchoice.studio');
  const [password, setPassword] = useState('Independent2026!');
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [previewSignInForm, setPreviewSignInForm] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginMember(email);
    setPreviewSignInForm(false);
  };

  if (member && !previewSignInForm) {
    return (
      <div className="page-shell">
        <div className="auth-split">
          <AuthBrandStage
            eyebrow="ACTIVE MEMBER SESSION"
            headline={`WELCOME BACK, ${member.name.split(' ')[0].toUpperCase()}.`}
            caption="Your personal YOUR CHOICE profile is active in this browser session."
          />

          <div className="auth-form-stage space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <span className="eyebrow">
                  <i /> INNER CIRCLE PROFILE
                </span>
                <h1 className="text-3xl font-semibold tracking-tight mt-1">{member.name}</h1>
                <p className="text-xs text-[#60675a] mt-0.5">
                  {member.email} · Joined {member.joinedAt}
                </p>
              </div>
              <button
                type="button"
                onClick={logoutMember}
                className="button button-outline !min-h-[38px] !px-3.5"
              >
                Sign Out <LogOut size={14} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Link
                to="/wishlist"
                className="editorial-card !p-4 hover:border-[var(--blue)] transition-colors"
              >
                <span className="mono text-[9px] text-[var(--blue)]">SAVED CURATION</span>
                <strong className="block text-2xl font-mono mt-1">{wishlistIds.length}</strong>
                <span className="text-xs text-[#60675a]">Pieces in Wishlist →</span>
              </Link>
              <Link
                to="/order-tracking"
                className="editorial-card !p-4 hover:border-[var(--blue)] transition-colors"
              >
                <span className="mono text-[9px] text-[var(--blue)]">RECENT DISPATCHES</span>
                <strong className="block text-2xl font-mono mt-1">{orders.length}</strong>
                <span className="text-xs text-[#60675a]">Tracked Orders →</span>
              </Link>
            </div>

            <div className="editorial-card space-y-3">
              <div className="flex items-center justify-between">
                <span className="mono text-[9px] text-[#60675a]">LATEST STUDIO ORDERS</span>
                <Link to="/order-tracking" className="text-link">
                  Track all <ArrowUpRight size={12} />
                </Link>
              </div>
              {orders.slice(0, 2).map((o) => (
                <Link
                  key={o.orderNumber}
                  to={`/order-tracking?order=${o.orderNumber}`}
                  className="flex items-center justify-between py-2 border-t border-[var(--line)] text-xs hover:text-[var(--blue)]"
                >
                  <span className="inline-flex items-center gap-2 font-mono">
                    <Package size={13} /> {o.orderNumber}
                  </span>
                  <span className="text-[#60675a]">{o.statusLabel.split('—')[0]}</span>
                  <strong className="font-mono">{formatPrice(o.total)}</strong>
                </Link>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <Link to="/shop" className="button button-blue">
                Explore Collection <ArrowRight size={16} />
              </Link>
              <button
                type="button"
                onClick={() => setPreviewSignInForm(true)}
                className="text-link"
              >
                Switch account / Preview login form
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-shell">
      <div className="auth-split">
        <AuthBrandStage />

        <div className="auth-form-stage space-y-6">
          <div>
            <span className="eyebrow">
              <i /> MEMBER SIGN IN
            </span>
            <h1 className="text-4xl font-semibold tracking-tight mt-2">Welcome back.</h1>
            <p className="text-xs text-[#60675a] mt-2">
              Sign in to access your saved rotation, measurements, and live order tracking.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="field-group">
              <label className="field-label" htmlFor="login-email">
                Email Address
              </label>
              <input
                id="login-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@domain.com"
                className="field-input"
              />
            </div>

            <div className="field-group">
              <div className="flex items-center justify-between">
                <label className="field-label" htmlFor="login-pw">
                  Password
                </label>
                <Link
                  to="/forgot-password"
                  className="text-[11px] underline text-[var(--blue)]"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <input
                  id="login-pw"
                  type={showPw ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="field-input pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  aria-label={showPw ? 'Hide password' : 'Show password'}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#60675a]"
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <label className="inline-flex items-center gap-2 text-xs text-[#4b5145] cursor-pointer">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                className="accent-[var(--blue)]"
              />
              Keep me signed in on this device
            </label>

            <button type="submit" className="button button-blue w-full">
              Sign In to YOUR CHOICE <ArrowRight size={17} />
            </button>
          </form>

          <div className="border-t border-[var(--line)] pt-5 flex flex-wrap items-center justify-between gap-3 text-xs">
            <span className="text-[#60675a]">New to YOUR CHOICE?</span>
            <Link to="/register" className="text-link font-semibold text-[#18191a]">
              Create Inner Circle Account <ArrowUpRight size={14} />
            </Link>
          </div>

          <button
            type="button"
            onClick={() => {
              loginMember('alex.mercer@yourchoice.studio', 'Alex Mercer');
              navigate('/login');
            }}
            className="w-full py-2.5 px-3 border border-dashed border-[#a6aba0] text-[11px] font-mono text-[#555b4f] hover:border-[var(--blue)] hover:text-[var(--blue)] flex items-center justify-center gap-2"
          >
            <Sparkles size={13} /> One-Click Demo Member Sign-In
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   13. REGISTRATION (/register)
   ============================================================================ */
export function RegisterPage() {
  const navigate = useNavigate();
  const { loginMember } = useStore();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [silhouette, setSilhouette] = useState('T-Shirts & Modern Polos');
  const [newsletter, setNewsletter] = useState(true);
  const [agreed, setAgreed] = useState(true);

  const strength = useMemo(() => {
    let s = 0;
    if (password.length >= 8) s += 1;
    if (/[A-Z]/.test(password)) s += 1;
    if (/[0-9]/.test(password)) s += 1;
    if (/[^A-Za-z0-9]/.test(password)) s += 1;
    return s;
  }, [password]);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreed) return;
    loginMember(email, `${firstName} ${lastName}`.trim(), silhouette);
    navigate('/login');
  };

  return (
    <div className="page-shell">
      <div className="auth-split">
        <AuthBrandStage
          eyebrow="JOIN THE INNER CIRCLE"
          headline="DESIGN IT. WEAR IT. EARN FROM IT."
          caption="Create your YOUR CHOICE identity for priority Vol. 01 drops, saved fit recommendations, and early creator access."
        />

        <div className="auth-form-stage space-y-6">
          <div>
            <span className="eyebrow">
              <i /> CREATE ACCOUNT
            </span>
            <h1 className="text-4xl font-semibold tracking-tight mt-2">Make it yours.</h1>
            <p className="text-xs text-[#60675a] mt-1.5">
              Independent expression starts with your personal studio profile.
            </p>
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-3.5">
              <div className="field-group">
                <label className="field-label" htmlFor="reg-first">
                  First Name *
                </label>
                <input
                  id="reg-first"
                  type="text"
                  required
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="Alex"
                  className="field-input"
                />
              </div>
              <div className="field-group">
                <label className="field-label" htmlFor="reg-last">
                  Last Name *
                </label>
                <input
                  id="reg-last"
                  type="text"
                  required
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="Mercer"
                  className="field-input"
                />
              </div>
            </div>

            <div className="field-group">
              <label className="field-label" htmlFor="reg-email">
                Email Address *
              </label>
              <input
                id="reg-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="alex@studio.com"
                className="field-input"
              />
            </div>

            <div className="field-group">
              <label className="field-label" htmlFor="reg-pw">
                Create Password *
              </label>
              <div className="relative">
                <input
                  id="reg-pw"
                  type={showPw ? 'text' : 'password'}
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 8 characters"
                  className="field-input pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  aria-label="Toggle password visibility"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#60675a]"
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {/* 4-bar strength indicator */}
              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {[1, 2, 3, 4].map((bar) => (
                  <div
                    key={bar}
                    className={`h-1 transition-colors ${
                      strength >= bar ? 'bg-[var(--blue)]' : 'bg-[#d5d8cf]'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="field-group">
              <label className="field-label" htmlFor="reg-fit">
                Primary Wardrobe Focus
              </label>
              <select
                id="reg-fit"
                value={silhouette}
                onChange={(e) => setSilhouette(e.target.value)}
                className="field-select"
              >
                <option>T-Shirts &amp; Modern Polos</option>
                <option>320 GSM Heavyweight Tees</option>
                <option>Tailored Knit &amp; Piqué Polos</option>
                <option>Sculptural Outerwear &amp; Fleece</option>
                <option>Design Studio Creator Editions</option>
              </select>
            </div>

            <div className="space-y-2 pt-1 text-xs text-[#4b5145]">
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newsletter}
                  onChange={(e) => setNewsletter(e.target.checked)}
                  className="mt-0.5 accent-[var(--blue)]"
                />
                <span>Receive early access to Vol. 01 capsule releases &amp; Design Studio invites.</span>
              </label>
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                  className="mt-0.5 accent-[var(--blue)]"
                />
                <span>
                  I agree to the{' '}
                  <Link to="/terms-conditions" className="underline">
                    Terms &amp; Conditions
                  </Link>{' '}
                  and{' '}
                  <Link to="/privacy-policy" className="underline">
                    Privacy Policy
                  </Link>
                  .
                </span>
              </label>
            </div>

            <button type="submit" className="button button-blue w-full">
              Create YOUR CHOICE Account <ArrowRight size={17} />
            </button>
          </form>

          <div className="border-t border-[var(--line)] pt-4 flex items-center justify-between text-xs">
            <span className="text-[#60675a]">Already a member?</span>
            <Link to="/login" className="text-link font-semibold text-[#18191a]">
              Sign In <ArrowUpRight size={14} />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   14. FORGOT PASSWORD (/forgot-password)
   ============================================================================ */
export function ForgotPasswordPage() {
  const [email, setEmail] = useState('member@yourchoice.studio');
  const [dispatched, setDispatched] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setDispatched(true);
  };

  return (
    <div className="page-shell">
      <div className="auth-split">
        <AuthBrandStage
          eyebrow="ACCOUNT RECOVERY"
          headline="RESTORE ACCESS IN SECONDS."
          caption="We will send a single-use encrypted recovery link to reset your Inner Circle password."
        />

        <div className="auth-form-stage space-y-6">
          <Link to="/login" className="text-link self-start">
            <ArrowLeft size={14} /> Back to Sign In
          </Link>

          {!dispatched ? (
            <>
              <div>
                <span className="eyebrow">
                  <Mail size={13} className="text-[var(--blue)]" /> PASSWORD RECOVERY
                </span>
                <h1 className="text-4xl font-semibold tracking-tight mt-2">Forgot password?</h1>
                <p className="text-xs text-[#60675a] mt-2 leading-relaxed">
                  Enter the email address associated with your YOUR CHOICE account and we’ll generate a secure reset token.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="field-group">
                  <label className="field-label" htmlFor="forgot-email">
                    Registered Email Address *
                  </label>
                  <input
                    id="forgot-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@domain.com"
                    className="field-input"
                  />
                </div>

                <button type="submit" className="button button-blue w-full">
                  Send Recovery Link <ArrowRight size={17} />
                </button>
              </form>
            </>
          ) : (
            <div className="editorial-card space-y-5">
              <div className="w-11 h-11 bg-[var(--blue)] text-white grid place-items-center">
                <CheckCircle2 size={22} />
              </div>
              <div className="space-y-2">
                <span className="mono text-[9px] text-[var(--blue)]">DISPATCH CONFIRMED</span>
                <h2 className="text-2xl font-semibold tracking-tight">
                  Check your inbox.
                </h2>
                <p className="text-xs text-[#555b4f] leading-relaxed">
                  If an account exists for <strong>{email}</strong>, a password reset link valid for 30 minutes has been sent.
                </p>
              </div>

              <div className="pt-2 space-y-2.5">
                <Link
                  to={`/reset-password?email=${encodeURIComponent(email)}&token=yc-recovery-8841`}
                  className="button button-blue w-full"
                >
                  Simulate Opening Reset Link <ArrowUpRight size={16} />
                </Link>
                <button
                  type="button"
                  onClick={() => setDispatched(false)}
                  className="button button-outline w-full"
                >
                  Try a different email address
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   15. RESET PASSWORD (/reset-password)
   ============================================================================ */
export function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const targetEmail = searchParams.get('email') || 'member@yourchoice.studio';
  const token = searchParams.get('token') || 'yc-verified-session';

  const [password, setPassword] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [completed, setCompleted] = useState(false);

  const checks = {
    len: password.length >= 8,
    upper: /[A-Z]/.test(password),
    numOrSym: /[0-9]|[^A-Za-z0-9]/.test(password),
    match: password.length > 0 && password === confirmPw,
  };

  const canSubmit = checks.len && checks.upper && checks.numOrSym && checks.match;

  const handleReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setCompleted(true);
  };

  return (
    <div className="page-shell">
      <div className="auth-split">
        <AuthBrandStage
          eyebrow="CREDENTIAL UPDATE"
          headline="SET YOUR NEW CREDENTIALS."
          caption="Choose a strong, unique password to protect your YOUR CHOICE Inner Circle profile."
        />

        <div className="auth-form-stage space-y-6">
          {!completed ? (
            <>
              <div>
                <span className="eyebrow">
                  <KeyRound size={13} className="text-[var(--blue)]" /> TOKEN VERIFIED · {token}
                </span>
                <h1 className="text-4xl font-semibold tracking-tight mt-2">Reset password.</h1>
                <p className="text-xs text-[#60675a] mt-1.5">
                  Updating credentials for <strong>{targetEmail}</strong>
                </p>
              </div>

              <form onSubmit={handleReset} className="space-y-4">
                <div className="field-group">
                  <label className="field-label" htmlFor="rst-pw">
                    New Password *
                  </label>
                  <div className="relative">
                    <input
                      id="rst-pw"
                      type={showPw ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter new password"
                      className="field-input pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPw((v) => !v)}
                      aria-label="Toggle password visibility"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#60675a]"
                    >
                      {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <div className="field-group">
                  <label className="field-label" htmlFor="rst-confirm">
                    Confirm New Password *
                  </label>
                  <input
                    id="rst-confirm"
                    type={showPw ? 'text' : 'password'}
                    required
                    value={confirmPw}
                    onChange={(e) => setConfirmPw(e.target.value)}
                    placeholder="Re-enter new password"
                    className="field-input"
                  />
                </div>

                {/* Live Validation Rules */}
                <div className="editorial-card !p-4 space-y-2 text-xs">
                  <span className="mono text-[9px] text-[#60675a] block">
                    SECURITY REQUIREMENTS
                  </span>
                  {[
                    { ok: checks.len, label: 'At least 8 characters' },
                    { ok: checks.upper, label: 'Contains an uppercase letter (A–Z)' },
                    { ok: checks.numOrSym, label: 'Contains a number or symbol' },
                    { ok: checks.match, label: 'Confirmation matches new password' },
                  ].map((r) => (
                    <div
                      key={r.label}
                      className={`flex items-center gap-2 ${
                        r.ok ? 'text-[#1f6f43] font-medium' : 'text-[#6c7365]'
                      }`}
                    >
                      <Check size={13} />
                      <span>{r.label}</span>
                    </div>
                  ))}
                </div>

                <button
                  type="submit"
                  disabled={!canSubmit}
                  className="button button-blue w-full"
                >
                  Save New Password <ShieldCheck size={17} />
                </button>
              </form>
            </>
          ) : (
            <div className="editorial-card space-y-5">
              <div className="w-11 h-11 bg-[#1f6f43] text-white grid place-items-center">
                <Check size={22} />
              </div>
              <div className="space-y-2">
                <span className="mono text-[9px] text-[var(--blue)]">PASSWORD UPDATED</span>
                <h2 className="text-2xl font-semibold tracking-tight">
                  Your password has been reset.
                </h2>
                <p className="text-xs text-[#555b4f] leading-relaxed">
                  Your new credentials for <strong>{targetEmail}</strong> are active. You may now sign in to your account.
                </p>
              </div>
              <Link to="/login" className="button button-blue w-full">
                Return to Sign In <ArrowRight size={17} />
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
