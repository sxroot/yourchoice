import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  AlignCenter, AlignLeft, AlignRight, ArrowDown, ArrowLeft, ArrowRight, ArrowUp, ArrowUpRight,
  Bold, Check, ChevronDown, ChevronLeft, Circle, Copy, Download, Eye, EyeOff, FileImage, Grid3X3,
  Image, Italic, Layers, Lock, Maximize, Minus, MousePointer2, Palette, Plus, Redo2, RotateCw,
  Save, Shapes, Shirt, ShoppingBag, Sparkles, Square, Trash2, Type, Undo2, Unlock, Upload, X,
} from 'lucide-react';
import { MARKETPLACE_DESIGNS, STUDIO_PRODUCTS } from '../data/phase2';
import { useEcosystem } from '../context/EcosystemContext';
import { useStore } from '../context/StoreContext';
import { GarmentIllustration } from '../components/Phase2UI';
import { Wordmark } from '../components/BrandMarks';

type LayerType = 'text' | 'image' | 'shape';
type ViewSide = 'front' | 'back';
interface StudioLayer {
  id: string; type: LayerType; name: string; x: number; y: number; width: number; height: number;
  rotation: number; opacity: number; color: string; visible: boolean; locked: boolean;
  text?: string; src?: string; fontFamily?: string; fontSize?: number; fontWeight?: number;
  align?: 'left' | 'center' | 'right'; letterSpacing?: number; shape?: 'rectangle' | 'circle' | 'star';
}
interface StudioProject {
  id: string; name: string; productId: number; color: string; views: Record<ViewSide, StudioLayer[]>;
}
type Tool = 'select' | 'text' | 'image' | 'shape' | 'upload' | 'garment';

const ARTWORK_LIBRARY = ['/art/chrome-wings.png','/art/cobalt-bloom.png','/art/solar-eclipse.png','/art/signal-terrain.png'];
const uid = (prefix = 'layer') => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,6)}`;
const textLayer = (text = 'YOUR CHOICE'): StudioLayer => ({ id:uid('text'),type:'text',name:text || 'Text',text,x:175,y:390,width:250,height:74,rotation:0,opacity:100,color:'#f5f5f1',visible:true,locked:false,fontFamily:'Barlow Condensed',fontSize:42,fontWeight:800,align:'center',letterSpacing:2 });
const imageLayer = (src: string): StudioLayer => ({ id:uid('image'),type:'image',name:src.split('/').pop()?.split('.')[0].replaceAll('-',' ') || 'Artwork',src,x:210,y:175,width:180,height:180,rotation:0,opacity:100,color:'#2349ed',visible:true,locked:false });
const shapeLayer = (shape: StudioLayer['shape']): StudioLayer => ({ id:uid('shape'),type:'shape',name:`${shape} shape`,shape,x:220,y:210,width:160,height:160,rotation:0,opacity:100,color:'#2349ed',visible:true,locked:false });

function defaultProject(productId = 2, color = '#18191b', designSlug?: string | null): StudioProject {
  const design = MARKETPLACE_DESIGNS.find((d) => d.slug === designSlug);
  const artwork = design?.artwork || ARTWORK_LIBRARY[0];
  const initialText = textLayer(design ? design.title.toUpperCase() : 'NOT FOR EVERYONE.');
  initialText.color = color === '#edece6' ? '#18191b' : '#f5f5f1';
  return { id:uid('project'),name:design ? `${design.title} / Remix` : 'Untitled expression 01',productId,color,views:{front:[imageLayer(artwork),initialText],back:[]} };
}

function isStudioProject(value: unknown): value is StudioProject {
  return Boolean(value && typeof value === 'object' && 'views' in value && 'productId' in value);
}

function LayerGraphic({ layer }: { layer: StudioLayer }) {
  if (layer.type === 'image') return <image href={layer.src} width={layer.width} height={layer.height} preserveAspectRatio="xMidYMid meet"/>;
  if (layer.type === 'text') {
    const anchor = layer.align === 'left' ? 'start' : layer.align === 'right' ? 'end' : 'middle';
    const x = layer.align === 'left' ? 0 : layer.align === 'right' ? layer.width : layer.width/2;
    return <text x={x} y={layer.height/2} textAnchor={anchor} dominantBaseline="middle" fill={layer.color} fontFamily={layer.fontFamily} fontSize={layer.fontSize} fontWeight={layer.fontWeight} letterSpacing={layer.letterSpacing} style={{ userSelect:'none' }}>{layer.text}</text>;
  }
  if (layer.shape === 'circle') return <ellipse cx={layer.width/2} cy={layer.height/2} rx={layer.width/2} ry={layer.height/2} fill={layer.color}/>;
  if (layer.shape === 'star') { const cx=layer.width/2,cy=layer.height/2,outer=Math.min(cx,cy),inner=outer*.42;const points=Array.from({length:10},(_,i)=>{const angle=-Math.PI/2+i*Math.PI/5,r=i%2===0?outer:inner;return `${cx+Math.cos(angle)*r},${cy+Math.sin(angle)*r}`;}).join(' ');return <polygon points={points} fill={layer.color}/>; }
  return <rect width={layer.width} height={layer.height} rx="2" fill={layer.color}/>;
}

interface DragState { id:string; mode:'move'|'resize'|'rotate'; startX:number; startY:number; original:StudioLayer }
function StudioCanvas({ project, view, selectedId, setSelectedId, interactive = true, checkpoint, mutateLayer, canvasRef, showBoundary = true }: {
  project:StudioProject; view:ViewSide; selectedId?:string|null; setSelectedId?:(id:string|null)=>void; interactive?:boolean;
  checkpoint?:()=>void; mutateLayer?:(id:string,recipe:(layer:StudioLayer)=>StudioLayer)=>void; canvasRef?:React.RefObject<SVGSVGElement|null>; showBoundary?:boolean;
}) {
  const localRef=useRef<SVGSVGElement>(null);
  const svgRef=canvasRef||localRef;
  const drag=useRef<DragState|null>(null);
  const product=STUDIO_PRODUCTS.find((p)=>p.id===project.productId)||STUDIO_PRODUCTS[0];
  const layers=project.views[view];
  const point=(e:React.PointerEvent)=>{const svg=svgRef.current;if(!svg)return{x:0,y:0};const pt=svg.createSVGPoint();pt.x=e.clientX;pt.y=e.clientY;const matrix=svg.getScreenCTM();return matrix?pt.matrixTransform(matrix.inverse()):{x:0,y:0};};
  const begin=(e:React.PointerEvent,layer:StudioLayer,mode:DragState['mode'])=>{
    if(!interactive)return;e.preventDefault();e.stopPropagation();setSelectedId?.(layer.id);if(layer.locked)return;
    const p=point(e);drag.current={id:layer.id,mode,startX:p.x,startY:p.y,original:{...layer}};checkpoint?.();svgRef.current?.setPointerCapture(e.pointerId);
  };
  const move=(e:React.PointerEvent)=>{
    const current=drag.current;if(!current||!mutateLayer)return;const p=point(e);const dx=p.x-current.startX,dy=p.y-current.startY,o=current.original;
    mutateLayer(current.id,(layer)=>{
      if(current.mode==='move')return{...layer,x:Math.max(-80,Math.min(580-o.width,o.x+dx)),y:Math.max(80,Math.min(660-o.height,o.y+dy))};
      if(current.mode==='resize'){const w=Math.max(30,Math.min(450,o.width+dx));const h=e.shiftKey?w*(o.height/o.width):Math.max(30,Math.min(480,o.height+dy));return{...layer,width:w,height:h};}
      const angle=Math.atan2(p.y-(o.y+o.height/2),p.x-(o.x+o.width/2))*180/Math.PI+90;return{...layer,rotation:Math.round(angle)};
    });
  };
  return <svg ref={svgRef} className={`studio-design-canvas ${interactive?'is-interactive':'is-preview'}`} viewBox="0 0 600 700" onPointerMove={move} onPointerUp={()=>{drag.current=null;}} onPointerCancel={()=>{drag.current=null;}} onPointerDown={()=>{if(interactive)setSelectedId?.(null);}}>
    <GarmentIllustration color={project.color} productType={product.type} view={view}/>
    {showBoundary&&<g className="print-boundary editor-only" data-editor-only="true"><rect x="160" y="140" width="280" height="350" rx="4"/><text x="160" y="130">PRINT AREA · 32 × 40 CM</text></g>}
    {layers.filter((layer)=>layer.visible).map((layer)=>{const selected=interactive&&selectedId===layer.id;return <g key={layer.id} data-layer={layer.id} transform={`translate(${layer.x} ${layer.y}) rotate(${layer.rotation} ${layer.width/2} ${layer.height/2})`} opacity={layer.opacity/100} className={`canvas-layer ${selected?'selected':''} ${layer.locked?'locked':''}`} onPointerDown={(e)=>begin(e,layer,'move')}>
      <LayerGraphic layer={layer}/>
      {selected&&<g className="selection-controls editor-only" data-editor-only="true" opacity={100/layer.opacity}><rect x="-5" y="-5" width={layer.width+10} height={layer.height+10}/><line x1={layer.width/2} y1="-5" x2={layer.width/2} y2="-34"/><circle className="rotate-handle" cx={layer.width/2} cy="-40" r="9" onPointerDown={(e)=>begin(e,layer,'rotate')}/><circle className="resize-handle" cx={layer.width} cy={layer.height} r="9" onPointerDown={(e)=>begin(e,layer,'resize')}/><rect className="layer-label-bg" x="-5" y="-29" width={Math.max(90,layer.name.length*7+20)} height="20"/><text className="layer-label" x="3" y="-15">{layer.locked?'LOCKED · ':''}{layer.name.toUpperCase()}</text></g>}
    </g>})}
  </svg>;
}

export default function Studio2DPage() {
  const [params]=useSearchParams();
  const {savedDesigns,saveStudioDesign}=useEcosystem();
  const {showToast,addToBag}=useStore();
  const navigate=useNavigate();
  const [project,setProject]=useState<StudioProject>(()=>{
    const saved=savedDesigns.find((d)=>d.id===params.get('project'));
    if(saved&&isStudioProject(saved.project))return saved.project;
    const productId=Number(params.get('product'))||saved?.productId||2;
    const color=params.get('color')||saved?.color||'#18191b';
    if(!params.get('design')&&!params.get('product')&&!params.get('project')){try{const auto=localStorage.getItem('yc-phase02-studio-autosave');if(auto){const parsed=JSON.parse(auto);if(isStudioProject(parsed))return parsed;}}catch{/* start fresh */}}
    return defaultProject(productId,color,params.get('design'));
  });
  const projectRef=useRef(project);projectRef.current=project;
  const [past,setPast]=useState<StudioProject[]>([]);
  const [future,setFuture]=useState<StudioProject[]>([]);
  const [view,setView]=useState<ViewSide>('front');
  const [selectedId,setSelectedId]=useState<string|null>(null);
  const [tool,setTool]=useState<Tool>('select');
  const [zoom,setZoom]=useState(1);
  const [grid,setGrid]=useState(true);
  const [saveState,setSaveState]=useState<'saved'|'saving'>('saved');
  const [preview,setPreview]=useState(false);
  const [previewView,setPreviewView]=useState<ViewSide>('front');
  const [rightTab,setRightTab]=useState<'properties'|'layers'>('properties');
  const [size,setSize]=useState('L');
  const canvasRef=useRef<SVGSVGElement>(null);
  const uploadRef=useRef<HTMLInputElement>(null);
  const product=STUDIO_PRODUCTS.find((p)=>p.id===project.productId)||STUDIO_PRODUCTS[0];
  const layers=project.views[view];
  const selected=layers.find((layer)=>layer.id===selectedId)||null;

  const checkpoint=()=>{setPast((items)=>[...items.slice(-49),projectRef.current]);setFuture([]);};
  const mutate=(recipe:(current:StudioProject)=>StudioProject)=>{setProject((current)=>{const next=recipe(current);projectRef.current=next;return next;});};
  const commit=(recipe:(current:StudioProject)=>StudioProject)=>{checkpoint();mutate(recipe);};
  const updateLayers=(next:StudioLayer[],history=true)=>{const action=(current:StudioProject)=>({...current,views:{...current.views,[view]:next}});if(history)commit(action);else mutate(action);};
  const mutateLayer=(id:string,recipe:(layer:StudioLayer)=>StudioLayer,history=false)=>{const action=(current:StudioProject)=>({...current,views:{...current.views,[view]:current.views[view].map((layer)=>layer.id===id?recipe(layer):layer)}});if(history)commit(action);else mutate(action);};
  const updateSelected=(patch:Partial<StudioLayer>,history=true)=>{if(selectedId)mutateLayer(selectedId,(layer)=>({...layer,...patch}),history);};
  const addLayer=(layer:StudioLayer)=>{commit((current)=>({...current,views:{...current.views,[view]:[...current.views[view],layer]}}));setSelectedId(layer.id);setRightTab('properties');};
  const deleteLayer=(id=selectedId)=>{if(!id)return;updateLayers(layers.filter((layer)=>layer.id!==id));setSelectedId(null);};
  const duplicateLayer=(id=selectedId)=>{const original=layers.find((layer)=>layer.id===id);if(!original)return;addLayer({...original,id:uid(original.type),name:`${original.name} copy`,x:original.x+18,y:original.y+18});};
  const reorder=(id:string,direction:-1|1)=>{const index=layers.findIndex((l)=>l.id===id);const target=index+direction;if(index<0||target<0||target>=layers.length)return;const next=[...layers];[next[index],next[target]]=[next[target],next[index]];updateLayers(next);};
  const undo=()=>{if(!past.length)return;const current=projectRef.current,previous=past[past.length-1];setFuture((items)=>[current,...items]);setPast((items)=>items.slice(0,-1));projectRef.current=previous;setProject(previous);setSelectedId(null);};
  const redo=()=>{if(!future.length)return;const current=projectRef.current,next=future[0];setPast((items)=>[...items,current]);setFuture((items)=>items.slice(1));projectRef.current=next;setProject(next);setSelectedId(null);};

  useEffect(()=>{setSaveState('saving');const timer=setTimeout(()=>{try{localStorage.setItem('yc-phase02-studio-autosave',JSON.stringify(project));}catch{/* local save unavailable */}setSaveState('saved');},650);return()=>clearTimeout(timer);},[project]);
  useEffect(()=>{const handler=(e:KeyboardEvent)=>{const target=e.target as HTMLElement;if(['INPUT','TEXTAREA','SELECT'].includes(target.tagName))return;if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='z'){e.preventDefault();e.shiftKey?redo():undo();}else if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='d'){e.preventDefault();duplicateLayer();}else if((e.key==='Delete'||e.key==='Backspace')&&selectedId){e.preventDefault();deleteLayer();}else if(e.key==='Escape'){setSelectedId(null);setPreview(false);}};window.addEventListener('keydown',handler);return()=>window.removeEventListener('keydown',handler);});

  const saveNow=()=>{const id=saveStudioDesign({id:project.id,name:project.name||'Untitled expression',productName:product.name,productId:product.id,color:project.color,project:{...project,id:project.id}});if(id!==project.id)mutate((current)=>({...current,id}));showToast('Design saved to your customer design shelf.');setSaveState('saved');return id;};
  const exportSvg=()=>{const svg=canvasRef.current;if(!svg)return;const clone=svg.cloneNode(true) as SVGSVGElement;clone.querySelectorAll('[data-editor-only]').forEach((el)=>el.remove());clone.setAttribute('xmlns','http://www.w3.org/2000/svg');clone.setAttribute('width','1200');clone.setAttribute('height','1400');const blob=new Blob([new XMLSerializer().serializeToString(clone)],{type:'image/svg+xml'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`${project.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')}-${view}.svg`;a.click();URL.revokeObjectURL(url);showToast(`${view} garment exported as an editable SVG.`);};
  const upload=(file?:File)=>{if(!file)return;if(!file.type.startsWith('image/')||file.size>3*1024*1024){showToast('Choose an image under 3 MB for this local studio.');return;}const reader=new FileReader();reader.onload=()=>addLayer(imageLayer(String(reader.result)));reader.readAsDataURL(file);};

  const tools:[Tool,string,React.ReactNode][]=[['select','Select',<MousePointer2 size={19}/>],['text','Text',<Type size={19}/>],['image','Artwork',<Image size={19}/>],['shape','Shapes',<Shapes size={19}/>],['upload','Upload',<Upload size={19}/>],['garment','Garment',<Shirt size={19}/>]];
  return <div className="studio-workspace studio-2d-workspace">
    <header className="studio-editor-header"><div className="editor-brand"><Link to="/studio"><Wordmark/></Link><span>2D<br/>STUDIO</span></div><div className="editor-document"><Link to="/studio/products?mode=2d" title="Change garment"><Shirt size={15}/>{product.name}<ChevronDown size={13}/></Link><input value={project.name} onChange={(e)=>mutate((current)=>({...current,name:e.target.value}))} aria-label="Design project name"/></div><div className="editor-history"><button onClick={undo} disabled={!past.length} title="Undo (Ctrl+Z)"><Undo2 size={17}/></button><button onClick={redo} disabled={!future.length} title="Redo (Ctrl+Shift+Z)"><Redo2 size={17}/></button><span className={`save-state ${saveState}`}><i/>{saveState==='saving'?'Saving locally…':'All changes saved'}</span></div><div className="editor-header-actions"><button onClick={exportSvg} title="Download SVG"><Download size={16}/><span>Export</span></button><button onClick={()=>setPreview(true)}><Eye size={16}/><span>Preview</span></button><button className="editor-save" onClick={saveNow}><Save size={16}/><span>Save design</span></button></div></header>
    <div className="studio-editor-body">
      <aside className="studio-tool-rail">{tools.map(([id,label,icon])=><button key={id} className={tool===id?'active':''} onClick={()=>{setTool(id);if(id==='upload')uploadRef.current?.click();}} title={label}>{icon}<span>{label}</span></button>)}<input ref={uploadRef} type="file" hidden accept="image/*" onChange={(e)=>upload(e.target.files?.[0])}/><div/><button onClick={()=>setGrid(!grid)} className={grid?'active-subtle':''} title="Toggle canvas grid"><Grid3X3 size={19}/><span>Grid</span></button></aside>
      <aside className="studio-tool-panel"><div className="tool-panel-title"><span>{tools.find(([id])=>id===tool)?.[1]}</span><small>{tool==='select'?'CANVAS TOOL':'ADD TO '+view.toUpperCase()}</small></div>
        {tool==='select'&&<div className="tool-panel-content"><div className="tool-tip"><MousePointer2 size={20}/><p>Select any layer on the garment to move, resize or rotate it.</p></div><div className="shortcut-list"><span>Undo <kbd>Ctrl Z</kbd></span><span>Duplicate <kbd>Ctrl D</kbd></span><span>Delete layer <kbd>Del</kbd></span><span>Constrain resize <kbd>Shift</kbd></span></div><button className="tool-primary" onClick={()=>setRightTab('layers')}><Layers size={16}/> Manage {layers.length} layers <ArrowRight size={15}/></button><div className="canvas-document-info"><span>Document</span><dl><div><dt>Canvas</dt><dd>600 × 700</dd></div><div><dt>Print zone</dt><dd>32 × 40 cm</dd></div><div><dt>View</dt><dd>{view}</dd></div><div><dt>Colour mode</dt><dd>RGB preview</dd></div></dl></div></div>}
        {tool==='text'&&<div className="tool-panel-content"><p className="tool-description">Add an independent text layer, then tune its typeface, colour and spacing.</p>{['YOUR CHOICE','NOT FOR EVERYONE.','INDEPENDENT BY DESIGN'].map((text)=><button className="text-preset" key={text} onClick={()=>addLayer(textLayer(text))}><span style={{fontFamily:text==='INDEPENDENT BY DESIGN'?'IBM Plex Mono':'Barlow Condensed'}}>{text}</span><Plus size={15}/></button>)}<button className="tool-primary" onClick={()=>addLayer(textLayer('YOUR WORDS HERE'))}><Type size={16}/> Add custom text</button></div>}
        {tool==='image'&&<div className="tool-panel-content"><p className="tool-description">Transparent artwork studies from the YOUR CHOICE creative library.</p><div className="studio-art-library">{ARTWORK_LIBRARY.map((art,i)=><button key={art} onClick={()=>addLayer(imageLayer(art))}><img src={art} alt={`Artwork study ${i+1}`}/><span>0{i+1}</span><Plus size={14}/></button>)}</div><button className="tool-primary" onClick={()=>uploadRef.current?.click()}><Upload size={16}/> Upload your artwork</button><small className="tool-footnote">PNG, JPG, WEBP or SVG · max 3 MB local preview</small></div>}
        {tool==='shape'&&<div className="tool-panel-content"><p className="tool-description">Build compositions with simple vector forms. Every shape stays editable.</p><div className="shape-library"><button onClick={()=>addLayer(shapeLayer('rectangle'))}><Square size={36}/><span>Rectangle</span></button><button onClick={()=>addLayer(shapeLayer('circle'))}><Circle size={36}/><span>Circle</span></button><button onClick={()=>addLayer(shapeLayer('star'))}><Sparkles size={36}/><span>Star</span></button></div></div>}
        {tool==='upload'&&<div className="tool-panel-content"><button className="studio-upload-zone" onClick={()=>uploadRef.current?.click()}><Upload size={26}/><strong>Upload your artwork</strong><span>Transparent PNG works best.<br/>Max 3 MB in this local preview.</span></button><div className="p2-info-strip"><Check size={17}/><div><strong>Your file stays here.</strong><span>No upload or external processing takes place.</span></div></div></div>}
        {tool==='garment'&&<div className="tool-panel-content"><p className="tool-description">Change the atelier blank colour. Your artwork layers remain exactly where they are.</p><div className="studio-garment-colors">{product.colors.map((color)=><button key={color} className={project.color===color?'active':''} onClick={()=>commit((current)=>({...current,color}))}><i style={{background:color}}/>{project.color===color&&<Check size={14}/>}</button>)}</div><label className="custom-color">Custom garment colour<input type="color" value={project.color} onChange={(e)=>commit((current)=>({...current,color:e.target.value}))}/></label><div className="garment-spec-card"><Shirt size={23}/><strong>{product.name}</strong><span>{product.material}</span><small>{product.fit}</small><Link to="/studio/products?mode=2d">Change blank <ArrowUpRight size={13}/></Link></div></div>}
      </aside>
      <main className={`studio-canvas-stage ${grid?'has-grid':''}`}>
        <div className="canvas-top-controls"><div className="canvas-view-switch">{(['front','back'] as const).map((side)=><button key={side} className={view===side?'active':''} onClick={()=>{setView(side);setSelectedId(null);}}>{side==='front'?'01 Front':'02 Back'}<span>{project.views[side].length}</span></button>)}</div><div className="canvas-zoom-controls"><button onClick={()=>setZoom(Math.max(.6,zoom-.1))} aria-label="Zoom out"><Minus size={15}/></button><button className="zoom-value" onClick={()=>setZoom(1)}>{Math.round(zoom*100)}%</button><button onClick={()=>setZoom(Math.min(1.5,zoom+.1))} aria-label="Zoom in"><Plus size={15}/></button><button onClick={()=>setZoom(1)} title="Fit canvas"><Maximize size={15}/></button></div></div>
        <div className="canvas-scroll-area"><div className="canvas-scaler" style={{width:`${zoom*100}%`}}><StudioCanvas canvasRef={canvasRef} project={project} view={view} selectedId={selectedId} setSelectedId={setSelectedId} checkpoint={checkpoint} mutateLayer={mutateLayer}/></div></div>
        <div className="canvas-bottom-status"><span><MousePointer2 size={13}/>{selected?`${selected.name} selected`:'Select a layer to edit'}</span><span>RGB · {product.material} · {view.toUpperCase()}</span></div>
      </main>
      <aside className="studio-inspector"><div className="inspector-tabs"><button className={rightTab==='properties'?'active':''} onClick={()=>setRightTab('properties')}>Properties</button><button className={rightTab==='layers'?'active':''} onClick={()=>setRightTab('layers')}>Layers <span>{layers.length}</span></button></div>
        {rightTab==='properties'?<div className="inspector-content">{selected?<><div className="selected-layer-heading"><span>{selected.type==='text'?<Type size={17}/>:selected.type==='image'?<Image size={17}/>:<Shapes size={17}/>}</span><div><strong>{selected.name}</strong><small>{selected.type.toUpperCase()} LAYER · {view.toUpperCase()}</small></div><button onClick={()=>deleteLayer()} title="Delete layer"><Trash2 size={16}/></button></div>
          {selected.type==='text'&&<div className="property-section"><label>Text content<textarea rows={3} value={selected.text} onChange={(e)=>updateSelected({text:e.target.value,name:e.target.value||'Text'})}/></label><label>Typeface<select value={selected.fontFamily} onChange={(e)=>updateSelected({fontFamily:e.target.value})}><option>Barlow Condensed</option><option>DM Sans</option><option>IBM Plex Mono</option><option>Georgia</option><option>Arial</option></select></label><div className="property-grid two"><label>Size<input type="number" min="8" max="180" value={selected.fontSize} onChange={(e)=>updateSelected({fontSize:Number(e.target.value)})}/></label><label>Weight<select value={selected.fontWeight} onChange={(e)=>updateSelected({fontWeight:Number(e.target.value)})}>{[400,500,600,700,800,900].map((weight)=><option key={weight} value={weight}>{weight}</option>)}</select></label></div><div className="text-align-controls"><button className={selected.align==='left'?'active':''} onClick={()=>updateSelected({align:'left'})}><AlignLeft size={16}/></button><button className={selected.align==='center'?'active':''} onClick={()=>updateSelected({align:'center'})}><AlignCenter size={16}/></button><button className={selected.align==='right'?'active':''} onClick={()=>updateSelected({align:'right'})}><AlignRight size={16}/></button><button className={selected.fontWeight===800?'active':''} onClick={()=>updateSelected({fontWeight:selected.fontWeight===800?400:800})}><Bold size={16}/></button></div><label>Letter spacing <span>{selected.letterSpacing}px</span><input type="range" min="-4" max="20" step=".5" value={selected.letterSpacing} onChange={(e)=>updateSelected({letterSpacing:Number(e.target.value)},false)}/></label></div>}
          {selected.type!=='image'&&<div className="property-section"><label>Layer colour</label><div className="property-color-row">{['#f5f5f1','#18191b','#2349ed','#57dbf3','#f04e2f','#d8d4c8'].map((color)=><button key={color} className={selected.color===color?'active':''} style={{background:color}} onClick={()=>updateSelected({color})} aria-label={`Layer colour ${color}`}/>)}<input type="color" value={selected.color} onChange={(e)=>updateSelected({color:e.target.value},false)} title="Custom colour"/></div></div>}
          {selected.type==='image'&&<div className="property-section"><div className="image-property-preview"><img src={selected.src} alt="Selected artwork"/></div><button className="inspector-action" onClick={()=>uploadRef.current?.click()}><Upload size={14}/> Add a different image</button></div>}
          <div className="property-section"><span className="property-section-title">Transform</span><div className="property-grid two"><label>X position<input type="number" value={Math.round(selected.x)} onChange={(e)=>updateSelected({x:Number(e.target.value)})}/></label><label>Y position<input type="number" value={Math.round(selected.y)} onChange={(e)=>updateSelected({y:Number(e.target.value)})}/></label><label>Width<input type="number" min="30" value={Math.round(selected.width)} onChange={(e)=>updateSelected({width:Number(e.target.value)})}/></label><label>Height<input type="number" min="30" value={Math.round(selected.height)} onChange={(e)=>updateSelected({height:Number(e.target.value)})}/></label></div><label>Rotation <span>{selected.rotation}°</span><input type="range" min="-180" max="180" value={selected.rotation} onChange={(e)=>updateSelected({rotation:Number(e.target.value)},false)}/></label><label>Opacity <span>{selected.opacity}%</span><input type="range" min="5" max="100" value={selected.opacity} onChange={(e)=>updateSelected({opacity:Number(e.target.value)},false)}/></label></div>
          <div className="property-section layer-action-grid"><button onClick={()=>duplicateLayer()}><Copy size={14}/> Duplicate</button><button onClick={()=>updateSelected({locked:!selected.locked})}>{selected.locked?<Unlock size={14}/>:<Lock size={14}/>} {selected.locked?'Unlock':'Lock'}</button><button onClick={()=>reorder(selected.id,-1)} disabled={layers[0].id===selected.id}><ArrowDown size={14}/> Backward</button><button onClick={()=>reorder(selected.id,1)} disabled={layers[layers.length-1].id===selected.id}><ArrowUp size={14}/> Forward</button></div>
        </>:<div className="no-layer-selected"><MousePointer2 size={28}/><h3>Nothing selected.</h3><p>Choose a layer on the canvas or from the Layers tab to edit its properties.</p><button onClick={()=>setRightTab('layers')}>Browse layers <ArrowRight size={14}/></button></div>}</div>:<div className="inspector-content layers-panel"><div className="layers-panel-head"><span>{view.toUpperCase()} / {layers.length} LAYERS</span><button onClick={()=>setTool('text')} title="Add layer"><Plus size={16}/></button></div>{layers.length===0&&<div className="no-layer-selected"><Layers size={28}/><h3>This side is blank.</h3><p>Add text, artwork or a shape to begin the {view} composition.</p><button onClick={()=>setTool('image')}>Add artwork <Plus size={14}/></button></div>}{[...layers].reverse().map((layer)=><div key={layer.id} className={`layer-row ${selectedId===layer.id?'active':''}`}><button className="layer-select" onClick={()=>{setSelectedId(layer.id);setRightTab('properties');}}><span>{layer.type==='text'?<Type size={15}/>:layer.type==='image'?<Image size={15}/>:<Shapes size={15}/>}</span><div><strong>{layer.name}</strong><small>{layer.type} · {Math.round(layer.width)} × {Math.round(layer.height)}</small></div></button><button onClick={()=>mutateLayer(layer.id,(l)=>({...l,visible:!l.visible}),true)} aria-label={layer.visible?'Hide layer':'Show layer'}>{layer.visible?<Eye size={14}/>:<EyeOff size={14}/>}</button><button onClick={()=>mutateLayer(layer.id,(l)=>({...l,locked:!l.locked}),true)} aria-label={layer.locked?'Unlock layer':'Lock layer'}>{layer.locked?<Lock size={14}/>:<Unlock size={14}/>}</button></div>)}<div className="layer-panel-tip"><Lock size={14}/><span>Locked layers stay visible but cannot be moved on the canvas.</span></div></div>}
      </aside>
    </div>
    <AnimatePresence>{preview&&<motion.div className="studio-preview-modal" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}><div className="studio-preview-top"><div><Wordmark/><span>DESIGN PREVIEW / {project.name}</span></div><button onClick={()=>setPreview(false)}><X size={20}/> Close preview</button></div><div className="studio-preview-main"><div className="preview-canvas-wrap"><div className="preview-view-tabs">{(['front','back'] as const).map((side)=><button className={previewView===side?'active':''} key={side} onClick={()=>setPreviewView(side)}>{side}</button>)}</div><motion.div key={previewView} initial={{opacity:0,rotateY:-15}} animate={{opacity:1,rotateY:0}}><StudioCanvas project={project} view={previewView} interactive={false} showBoundary={false}/></motion.div><span>{product.name} · {product.material}</span></div><aside className="preview-order-panel"><span className="p2-kicker">Your one-of-one choice</span><h2>{project.name}</h2><p>A custom {product.name.toLowerCase()} with {project.views.front.length+project.views.back.length} independent design {project.views.front.length+project.views.back.length===1?'layer':'layers'} across front and back.</p><div className="preview-spec-list"><span><Check size={14}/>{product.material}</span><span><Check size={14}/>{product.fit}</span><span><Check size={14}/>Print-on-demand preview</span></div><label>Select size</label><div className="size-select-row">{['XS','S','M','L','XL','XXL'].map((item)=><button className={size===item?'active':''} key={item} onClick={()=>setSize(item)}>{item}</button>)}</div><div className="preview-price"><span>Custom garment from</span><strong>${product.price}</strong><small>Final print pricing is illustrative in this frontend preview.</small></div><button className="p2-button cyan full" onClick={()=>{saveNow();addToBag(product.id,size,1,false);showToast(`${project.name} saved and its ${product.name} base added to your bag.`);navigate('/bag');}}><ShoppingBag size={17}/> Save & add base to bag</button><button className="p2-button studio-ghost full" onClick={()=>{saveNow();setPreview(false);}}><Save size={16}/> Save & keep creating</button><Link to={`/studio/3d?product=${product.id}&color=${encodeURIComponent(project.color)}`} className="preview-3d-link">Explore this blank in 3D <ArrowUpRight size={15}/></Link></aside></div></motion.div>}</AnimatePresence>
  </div>;
}
