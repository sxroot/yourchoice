import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, useReducedMotion, useScroll, useTransform, MotionValue } from 'framer-motion';
import { ArrowDown, ArrowDownUp, ArrowRight, ArrowUpRight } from 'lucide-react';
import { Product, formatPrice } from '../data/catalog';
import { useStore } from '../context/StoreContext';
import { Reveal, SubscribeForm } from '../components/BrandMarks';
import { ProductCard } from '../components/ProductCard';

function OrbitCard({
  product,
  index,
  progress,
  onSelect,
}: {
  product: Product;
  index: number;
  progress: MotionValue<number>;
  onSelect: (p: Product) => void;
}) {
  const reduced = useReducedMotion();
  const x = useTransform(
    progress,
    (g) => `${Math.cos((index * Math.PI) / 3 + g * 1.8 - 0.8) * 44}vw`
  );
  const y = useTransform(
    progress,
    (g) => `${Math.sin((index * Math.PI) / 3 + g * 1.8 - 0.8) * 36}svh`
  );
  const rotate = useTransform(progress, (g) => Math.sin(index * 2 + g * 3) * 13);
  const scale = useTransform(
    progress,
    (g) => 0.8 + Math.sin((index * Math.PI) / 3 + g * 1.8) * 0.17
  );

  return (
    <motion.button
      type="button"
      className={`orbit-card orbit-${index}`}
      style={reduced ? undefined : { x, y, rotate, scale }}
      onClick={() => onSelect(product)}
      aria-label={`Explore ${product.name}`}
    >
      <img src={product.image} alt="" loading="lazy" />
      <span>
        {product.name}
        <ArrowUpRight size={12} />
      </span>
    </motion.button>
  );
}

function OrbitSection({
  products,
  onSelect,
}: {
  products: Product[];
  onSelect: (p: Product) => void;
}) {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end end'] });
  const scale = useTransform(scrollYProgress, [0, 1], [0.9, 1.1]);
  const reduced = useReducedMotion();

  return (
    <section
      className="orbit-section"
      ref={ref}
      id="movement"
      aria-label="The expression orbit"
    >
      <div className="orbit-sticky">
        <div className="orbit-ring ring-one" />
        <div className="orbit-ring ring-two" />
        <div className="orbit-ring ring-three" />

        <div className="section-corner">
          <span className="eyebrow">
            <i /> THE EXPRESSION ORBIT
          </span>
          <span className="mono">02 / NO FIXED DIRECTION</span>
        </div>

        <motion.div className="orbit-title" style={reduced ? {} : { scale }}>
          <p className="eyebrow">DIFFERENT BY CHOICE.</p>
          <h2>
            BUILT TO
            <br />
            <em>STAND OUT.</em>
          </h2>
          <p>Nothing ordinary. Everything you.</p>
        </motion.div>

        {products.length > 0 &&
          Array.from({ length: 6 }, (_, i) => (
            <OrbitCard
              key={i}
              index={i}
              product={products[i % products.length]}
              progress={scrollYProgress}
              onSelect={onSelect}
            />
          ))}

        <div className="orbit-bottom">
          <span className="mono">INDEPENDENT EXPRESSION, IN EVERY DIRECTION.</span>
          <span>
            Scroll to find your orbit <ArrowDown size={15} />
          </span>
        </div>

        <motion.div
          className="scene-progress orbit-scene-progress"
          aria-hidden="true"
          style={{ scaleX: reduced ? 1 : scrollYProgress }}
        />
      </div>
    </section>
  );
}

function ShutterStrip({ index, progress }: { index: number; progress: MotionValue<number> }) {
  const clipPath = useTransform(
    progress,
    [0.15 + index * 0.018, 0.39 + index * 0.018],
    ['inset(50% 0% 50% 0%)', 'inset(0% 0% 0% 0%)']
  );

  return (
    <motion.div
      className="shutter-strip"
      style={{
        top: `${(index * 100) / 12}%`,
        height: `${100 / 12 + 0.05}%`,
        clipPath,
      }}
    >
      <img
        src="/images/editorial.webp"
        alt=""
        style={{ top: `-${(index * 100) / 12}svh` }}
        loading="lazy"
      />
    </motion.div>
  );
}

function EditorialStorySection() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end end'] });
  const reduced = useReducedMotion();
  const scale = useTransform(scrollYProgress, [0, 1], [1.15, 1]);
  const width = useTransform(scrollYProgress, (v) => `${v * 100}%`);

  return (
    <section
      className="story-section"
      ref={ref}
      id="editorial"
      aria-label="The expression issue"
    >
      <div className="story-sticky">
        <motion.img
          className="story-base"
          src="/images/campaign.webp"
          alt="Independent fashion, expressed in sculptural black technical outerwear"
          style={reduced ? {} : { scale }}
          loading="lazy"
        />
        {!reduced && (
          <div className="shutter-layer" aria-hidden="true">
            {Array.from({ length: 12 }, (_, i) => (
              <ShutterStrip key={i} index={i} progress={scrollYProgress} />
            ))}
          </div>
        )}
        <div className="story-scrim" />
        <div className="story-top">
          <span>YOUR CHOICE — EDITORIAL 001</span>
          <Link to="/collections/expression-vol-01" className="hover:underline">
            THE EXPRESSION ISSUE ↗
          </Link>
        </div>
        <div className="story-copy">
          <p className="eyebrow">MORE THAN A LOOK. A POINT OF VIEW.</p>
          <h2>
            A DIFFERENT
            <br />
            KIND OF
            <br />
            <span>UNIFORM.</span>
          </h2>
          <Link className="round-link" to="/collections/expression-vol-01">
            Explore Vol. 01 Collection{' '}
            <span>
              <ArrowUpRight />
            </span>
          </Link>
        </div>
        <div className="story-bottom">
          <span>NO PERMISSION NEEDED.</span>
          <span>DESIGNED TO BE YOURS.</span>
        </div>
        <motion.div className="story-progress" style={{ width }} />
      </div>
    </section>
  );
}

function HorizontalRailSection({
  products,
  onSelect,
}: {
  products: Product[];
  onSelect: (p: Product) => void;
}) {
  const sectionRef = useRef<HTMLElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const [maxShift, setMaxShift] = useState(0);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start start', 'end end'],
  });
  const x = useTransform(scrollYProgress, [0, 1], [0, -maxShift]);

  useEffect(() => {
    const measure = () =>
      setMaxShift(Math.max(0, (trackRef.current?.scrollWidth || 0) - window.innerWidth + 96));
    measure();
    const ro = new ResizeObserver(measure);
    if (trackRef.current) ro.observe(trackRef.current);
    window.addEventListener('resize', measure);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, [products]);

  return (
    <section
      className="rail-section"
      ref={sectionRef}
      aria-label="Scroll-driven collection rail"
    >
      <div className="rail-sticky">
        <div className="rail-heading">
          <div>
            <p className="eyebrow">THE EVERYDAY, REDEFINED.</p>
            <h2>
              OFF THE RAIL.
              <br />
              <span>INTO YOUR ROTATION.</span>
            </h2>
          </div>
          <div className="rail-help mono">
            SCROLL TO EXPLORE <ArrowRight size={20} />
          </div>
        </div>

        <div className="rail-window">
          <motion.div className="rail-track" ref={trackRef} style={reduced ? {} : { x }}>
            {products.map((item, idx) => (
              <button
                type="button"
                key={item.id}
                className="rail-piece"
                onClick={() => onSelect(item)}
              >
                <span className="rail-index mono">
                  {String(idx + 1).padStart(2, '0')} — {item.category.toUpperCase()}
                </span>
                <img src={item.image} alt={item.name} loading="lazy" />
                <span className="rail-piece-title">
                  {item.name}
                  <ArrowUpRight />
                </span>
                <span className="rail-price mono">
                  {formatPrice(item.price)} / {item.color.toUpperCase()}
                </span>
              </button>
            ))}
          </motion.div>
        </div>

        <div className="rail-rule">
          <span className="mono">ESSENTIALS, NEVER ORDINARY.</span>
          <Link to="/shop" className="mono underline hover:text-[var(--blue)]">
            {String(products.length).padStart(2, '0')} CURATED ROTATION PIECES · VIEW FULL SHOP ↗
          </Link>
        </div>

        <motion.div
          className="scene-progress rail-scene-progress"
          aria-hidden="true"
          style={{ scaleX: reduced ? 1 : scrollYProgress }}
        />
      </div>
    </section>
  );
}

export function HomePage() {
  const { products, setStudioDrawerOpen } = useStore();
  const [activeCategory, setActiveCategory] = useState('All pieces');
  const [sortBy, setSortBy] = useState('featured');

  const navigate = useNavigate();
  const reduced = useReducedMotion();
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroPhotoY = useTransform(scrollYProgress, [0, 1], ['0%', '25%']);
  const heroCopyY = useTransform(scrollYProgress, [0, 1], [0, -100]);

  const categories = ['All pieces', 'T-Shirts', 'Polo Shirts', 'Essentials', 'Outerwear'];

  const homeCollection = useMemo(() => {
    const filtered = products.filter(
      (p) => activeCategory === 'All pieces' || p.category === activeCategory
    );
    const sorted = [...filtered].sort((a, b) =>
      sortBy === 'low'
        ? a.price - b.price
        : sortBy === 'high'
        ? b.price - a.price
        : a.position - b.position
    );
    return activeCategory === 'All pieces' ? sorted.slice(0, 6) : sorted.slice(0, 6);
  }, [products, activeCategory, sortBy]);

  const railPieces = useMemo(() => products.slice(0, 6), [products]);

  const openProduct = (product: Product) => {
    navigate(`/product/${product.slug}`);
  };

  const scrollToShop = () => {
    document.getElementById('shop')?.scrollIntoView({ behavior: reduced ? 'instant' : 'smooth' });
  };

  return (
    <>
      {/* HERO SECTION (EXACT REFERENCE FOUNDATION) */}
      <section className="hero" ref={heroRef}>
        <motion.img
          className="hero-photo"
          src="/images/campaign.webp"
          alt="Model in sculptural black outerwear — YOUR CHOICE expression collection"
          fetchPriority="high"
          width="1536"
          height="1024"
          style={reduced ? {} : { y: heroPhotoY }}
        />
        <div className="hero-grain" />

        <motion.div className="hero-copy" style={reduced ? {} : { y: heroCopyY }}>
          <motion.p
            className="eyebrow"
            initial={reduced ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.15 }}
          >
            <i /> THE EXPRESSION COLLECTION — VOL. 01
          </motion.p>

          <motion.h1
            initial={reduced ? false : { y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: 0.15 }}
          >
            NOT FOR
            <br />
            EVERYONE.
            <br />
            <span>FOR YOU.</span>
          </motion.h1>

          <motion.div
            initial={reduced ? false : { y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.45 }}
          >
            <p className="hero-description">
              Clothing for the ones who don’t fit in.
              <br />
              And have no intention of starting.
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <button type="button" className="button button-blue" onClick={scrollToShop}>
                Find your expression <ArrowUpRight size={19} />
              </button>
              <Link
                to="/shop"
                className="button button-outline !mt-[23px] bg-[#f5f5f1cc] backdrop-blur-sm"
              >
                Shop All ({products.length}) <ArrowRight size={16} />
              </Link>
            </div>
          </motion.div>
        </motion.div>

        <div className="hero-right">
          <div className="edition-label mono">
            <span>EST. FOR THE INDEPENDENT</span>
            <span>NO. 001 / UNRESTRICTED</span>
          </div>
          <Link
            to="/collections/expression-vol-01"
            className="hero-circle"
            aria-label="Explore Vol. 01 Collection"
          >
            <span>
              YOUR WORLD.
              <br />
              YOUR RULES.
            </span>
            <ArrowUpRight size={27} />
          </Link>
        </div>

        <div className="floating-label">
          <span className="blue-spark">✳</span>
          <span>
            100% YOURSELF.
            <br />
            <small>THAT’S THE ONLY DRESS CODE.</small>
          </span>
        </div>

        <div className="hero-bottom">
          <div className="hero-bottom-label">
            <span className="mono">DESIGNED FOR SELF-EXPRESSION.</span>
            <a href="#shop" className="scroll-cue">
              <ArrowDown size={14} /> SCROLL TO DISCOVER
            </a>
          </div>
          <div className="hero-wordmark" aria-hidden="true">
            YOUR CHOICE<span>®</span>
          </div>
        </div>

        <span className="hero-side mono">INDEPENDENT CULTURE / EVERYDAY EXPRESSION</span>
      </section>

      {/* MANIFESTO TICKER */}
      <div className="manifesto-ticker" aria-label="Design it. Wear it. Earn from it.">
        <div>
          <span>NO RULES. JUST YOU.</span>
          <span className="ticker-star">✳</span>
          <span>DESIGN IT. WEAR IT. EARN FROM IT.</span>
          <span className="ticker-star">✳</span>
          <span>YOUR CHOICE. ALWAYS THE BEST CHOICE.</span>
          <span className="ticker-star">✳</span>
          <span aria-hidden="true">NO RULES. JUST YOU.</span>
          <span className="ticker-star">✳</span>
        </div>
      </div>

      {/* 01 / THE COLLECTION */}
      <section className="collection-section section-pad" id="shop">
        <Reveal className="collection-intro">
          <p className="eyebrow section-number">01 / THE COLLECTION</p>
          <h2>
            Good clothes.
            <br />
            <span>No compromises.</span>
          </h2>
          <p>
            For the everyday. For the unexpected.
            <br />
            Considered T-shirts, modern polos, and sculptural layers.
            <br />
            Made to feel like you.
          </p>
        </Reveal>

        <div className="collection-toolbar">
          <div className="category-tabs" aria-label="Filter by category">
            {categories.map((cat) => (
              <button
                type="button"
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={activeCategory === cat ? 'active' : ''}
                aria-pressed={activeCategory === cat}
              >
                {cat}
                {cat === 'All pieces' && (
                  <sup>{products.length.toString().padStart(2, '0')}</sup>
                )}
              </button>
            ))}
          </div>

          <label className="sort-label">
            <ArrowDownUp size={14} />
            <select
              aria-label="Sort products"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="featured">Featured</option>
              <option value="low">Price: low to high</option>
              <option value="high">Price: high to low</option>
            </select>
          </label>
        </div>

        <div className="product-grid">
          {homeCollection.map((product, idx) => (
            <ProductCard key={product.id} product={product} index={idx} />
          ))}
        </div>

        <div className="collection-foot">
          <span className="mono">LESS NOISE. BETTER CHOICES.</span>
          <div className="flex flex-wrap items-center gap-6">
            <Link className="text-link" to="/collections/t-shirts">
              T-Shirt Collection <ArrowUpRight size={15} />
            </Link>
            <Link className="text-link" to="/collections/polo-shirts">
              Polo Shirt Collection <ArrowUpRight size={15} />
            </Link>
            <Link className="button button-dark" to="/shop">
              View All {products.length} Products <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* 02 / THE EXPRESSION ORBIT */}
      <OrbitSection products={railPieces} onSelect={openProduct} />

      {/* EDITORIAL 001 — SHUTTER STORY */}
      <EditorialStorySection />

      {/* SCROLL-DRIVEN HORIZONTAL RAIL */}
      <HorizontalRailSection products={railPieces} onSelect={openProduct} />

      {/* DESIGN STUDIO SECTION */}
      <section className="studio-section section-pad" id="studio">
        <Reveal className="studio-copy">
          <p className="eyebrow">
            <i /> YOUR NEXT CHAPTER
          </p>
          <h2>
            DON’T JUST
            <br />
            WEAR THE
            <br />
            <span>MOVEMENT.</span>
            <br />
            MAKE IT.
          </h2>
          <p>
            Your ideas deserve more than a moodboard.
            <br />
            A new space to design, create and earn.
            <br />
            The future is yours to make.
          </p>
          <button
            type="button"
            className="button button-dark"
            onClick={() => setStudioDrawerOpen(true)}
          >
            Meet the Design Studio <ArrowUpRight size={20} />
          </button>
          <span className="studio-status mono">IN THE MAKING. JOIN THE EARLY LIST.</span>
        </Reveal>

        <Reveal className="studio-art">
          <div className="studio-grid" />
          <span className="art-top mono">YOUR CHOICE / CREATIVE SYSTEM 001</span>
          <img
            src="/images/tee.webp"
            alt="Royal blue essential tee — a starting point for your expression"
            loading="lazy"
          />
          <span className="art-cross cross-one">+</span>
          <span className="art-cross cross-two">+</span>
          <span className="art-note mono">
            YOUR IDEA.
            <br />
            YOUR CANVAS.
          </span>
          <span className="art-tag">DESIGN IT. ↗</span>
          <div className="art-bottom mono">
            <span>START WITH A BLANK.</span>
            <span>MAKE SOMETHING THAT ISN’T.</span>
          </div>
        </Reveal>
      </section>

      {/* NEWSLETTER SECTION */}
      <section className="newsletter-section section-pad">
        <div>
          <p className="eyebrow">STAY IN YOUR ELEMENT.</p>
          <h2>
            Good things.
            <br />
            First to you.
          </h2>
        </div>
        <div className="newsletter-form">
          <p>
            New expressions. Fresh perspectives. Studio updates.
            <br />
            Join the YOUR CHOICE inner circle.
          </p>
          <SubscribeForm interest="homepage-newsletter" />
        </div>
      </section>
    </>
  );
}
