import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { formatMoney, type AdminCreator, type AdminCustomer } from '../../data/admin';
import { useAdmin } from '../AdminContext';
import { Avatar, Drawer, Empty, PageHead, Pagination, SearchField, Segmented, Skeleton, StatusBadge, usePaged } from '../AdminShared';

export function CustomersListPage() {
  const { ready, customers } = useAdmin();
  const [q, setQ] = useState('');
  const [seg, setSeg] = useState('All');

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return customers.filter((c) => {
      if (seg !== 'All' && c.segment !== seg) return false;
      if (!needle) return true;
      return `${c.name} ${c.email} ${c.city} ${c.country}`.toLowerCase().includes(needle);
    });
  }, [customers, q, seg]);
  const pager = usePaged(filtered, 8);

  if (!ready) return <Skeleton />;

  return (
    <div>
      <PageHead
        kicker="A06 / Directory"
        title="Customers"
        copy="Inner Circle members, guests, wholesale buyers and creators who also shop the catalogue."
      />
      <div className="admin-toolbar">
        <SearchField value={q} onChange={setQ} placeholder="Name, email, city…" />
        <Segmented options={['All', 'Inner Circle', 'Creator', 'Guest', 'Wholesale']} value={seg} onChange={setSeg} />
      </div>
      {filtered.length === 0 ? (
        <Empty title="No customers" copy="Nothing matches that segment." />
      ) : (
        <>
          <div className="admin-table-wrap">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Customer</th>
                  <th>Location</th>
                  <th>Segment</th>
                  <th>Orders</th>
                  <th>Spent</th>
                  <th>Status</th>
                  <th>Last order</th>
                </tr>
              </thead>
              <tbody>
                {pager.slice.map((c) => (
                  <tr key={c.id}>
                    <td>
                      <Link to={`/admin/customers/${c.id}`} className="admin-cell-user">
                        <Avatar name={c.name} hue={c.avatarHue} />
                        <div>
                          <strong>{c.name}</strong>
                          <span className="admin-muted" style={{ display: 'block' }}>
                            {c.email}
                          </span>
                        </div>
                      </Link>
                    </td>
                    <td>
                      {c.city}
                      <div className="admin-muted">{c.country}</div>
                    </td>
                    <td>
                      <StatusBadge status={c.segment} />
                    </td>
                    <td>{c.orders}</td>
                    <td>{formatMoney(c.spent)}</td>
                    <td>
                      <StatusBadge status={c.status} />
                    </td>
                    <td>{c.lastOrder}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={pager.page} pages={pager.pages} onPage={pager.setPage} total={pager.total} pageSize={pager.pageSize} />
        </>
      )}
    </div>
  );
}

export function CustomerDetailPage() {
  const { id } = useParams();
  const { customers, orders, updateCustomer } = useAdmin();
  const customer = customers.find((c) => c.id === id);
  const history = orders.filter((o) => o.customerId === id || o.email === customer?.email);
  const [notes, setNotes] = useState(customer?.notes || '');

  if (!customer) {
    return <Empty title="Customer not found" copy="This profile is not in the directory." action={<Link to="/admin/customers" className="admin-btn ghost sm">Directory</Link>} />;
  }

  return (
    <div>
      <Link to="/admin/customers" className="admin-muted" style={{ display: 'inline-flex', gap: 6, alignItems: 'center', marginBottom: 14 }}>
        <ArrowLeft size={14} /> Customers
      </Link>
      <PageHead
        kicker={customer.segment}
        title={customer.name}
        copy={`${customer.email} · joined ${customer.joined}`}
        actions={
          <select className="admin-select" style={{ width: 140 }} value={customer.status} onChange={(e) => updateCustomer(customer.id, { status: e.target.value as AdminCustomer['status'] })}>
            <option>Active</option>
            <option>Paused</option>
            <option>Flagged</option>
          </select>
        }
      />
      <div className="admin-kpis">
        <article className="admin-kpi"><header><span>Lifetime</span></header><strong>{formatMoney(customer.spent)}</strong><footer><span>{customer.orders} orders</span></footer></article>
        <article className="admin-kpi"><header><span>Last order</span></header><strong style={{ fontSize: 18 }}>{customer.lastOrder}</strong><footer><span>{customer.city}</span></footer></article>
        <article className="admin-kpi"><header><span>Phone</span></header><strong style={{ fontSize: 16 }}>{customer.phone}</strong><footer><span>{customer.country}</span></footer></article>
        <article className="admin-kpi"><header><span>Status</span></header><strong style={{ fontSize: 18 }}>{customer.status}</strong><footer><span>{customer.segment}</span></footer></article>
      </div>
      <div className="admin-split">
        <section className="admin-card">
          <div className="admin-card-head"><h2>Order history</h2></div>
          {history.length === 0 ? (
            <p className="admin-muted">No captured orders for this profile in the local ledger.</p>
          ) : (
            history.map((o) => (
              <Link key={o.id} to={`/admin/orders/${o.id}`} className="admin-cell-product" style={{ padding: '10px 0', borderTop: '1px solid #eef1ea' }}>
                <div style={{ flex: 1 }}>
                  <strong className="admin-mono">{o.orderNumber}</strong>
                  <span>
                    {o.placedStamp} · {o.items.length} items
                  </span>
                </div>
                <StatusBadge status={o.status} />
                <strong>{formatMoney(o.total)}</strong>
              </Link>
            ))
          )}
        </section>
        <section className="admin-card">
          <div className="admin-card-head"><h2>Profile notes</h2></div>
          <p className="admin-muted" style={{ marginBottom: 10 }}>
            {customer.city}, {customer.country}
          </p>
          <textarea className="admin-textarea" value={notes} onChange={(e) => setNotes(e.target.value)} />
          <button type="button" className="admin-btn primary sm" style={{ marginTop: 10 }} onClick={() => updateCustomer(customer.id, { notes })}>
            Save notes
          </button>
        </section>
      </div>
    </div>
  );
}

export function CreatorsPage() {
  const { ready, creators, applications, setApplicationStatus, updateCreator } = useAdmin();
  const [tab, setTab] = useState('Roster');
  const [q, setQ] = useState('');
  const [inspect, setInspect] = useState<AdminCreator | null>(null);

  const roster = creators.filter((c) => `${c.name} ${c.handle} ${c.location}`.toLowerCase().includes(q.trim().toLowerCase()));

  if (!ready) return <Skeleton />;

  return (
    <div>
      <PageHead
        kicker="A07 / Independents"
        title="Creator management"
        copy="Live roster, applications and performance. Approvals are local — they do not open a payout rail."
      />
      <div className="admin-toolbar">
        <Segmented options={['Roster', 'Applications']} value={tab} onChange={setTab} />
        {tab === 'Roster' && <SearchField value={q} onChange={setQ} placeholder="Name or handle…" />}
      </div>
      {tab === 'Roster' ? (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Creator</th>
                <th>Level</th>
                <th>Sales</th>
                <th>Pending</th>
                <th>Lifetime</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {roster.map((c) => (
                <tr key={c.handle}>
                  <td>
                    <Link to={`/admin/creators/${c.handle}`} className="admin-cell-user">
                      <Avatar name={c.name} src={c.avatar} />
                      <div>
                        <strong>{c.name}</strong>
                        <span className="admin-muted" style={{ display: 'block' }}>
                          @{c.handle} · {c.location}
                        </span>
                      </div>
                    </Link>
                  </td>
                  <td>L{c.level}</td>
                  <td>{c.totalSales.toLocaleString()}</td>
                  <td>{formatMoney(c.pendingBalance)}</td>
                  <td>{formatMoney(c.lifetimeEarnings)}</td>
                  <td>
                    <StatusBadge status={c.status} />
                  </td>
                  <td>
                    <button type="button" className="admin-btn ghost sm" onClick={() => setInspect(c)}>
                      Quick view
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="admin-grid-3">
          {applications.map((a) => (
            <article key={a.id} className="admin-card">
              <div className="admin-cell-user" style={{ marginBottom: 12 }}>
                <Avatar name={a.name} src={a.avatar} />
                <div>
                  <strong>{a.name}</strong>
                  <span className="admin-muted" style={{ display: 'block' }}>
                    {a.location} · {a.submittedAt}
                  </span>
                </div>
              </div>
              <StatusBadge status={a.status} />
              <p style={{ fontSize: 12, lineHeight: 1.6, margin: '12px 0' }}>{a.statement}</p>
              <p className="admin-muted">{a.specialty} · {a.portfolio}</p>
              {a.status === 'Pending' && (
                <div className="admin-actions" style={{ justifyContent: 'flex-start', marginTop: 14 }}>
                  <button type="button" className="admin-btn primary sm" onClick={() => setApplicationStatus(a.id, 'Approved')}>
                    Approve
                  </button>
                  <button type="button" className="admin-btn ghost sm" onClick={() => setApplicationStatus(a.id, 'Waitlisted')}>
                    Waitlist
                  </button>
                  <button type="button" className="admin-btn danger sm" onClick={() => setApplicationStatus(a.id, 'Declined')}>
                    Decline
                  </button>
                </div>
              )}
            </article>
          ))}
        </div>
      )}
      <Drawer open={!!inspect} title={inspect?.name || 'Creator'} onClose={() => setInspect(null)}>
        {inspect && (
          <div className="admin-form">
            <img src={inspect.cover} alt="" style={{ width: '100%', height: 120, objectFit: 'cover' }} />
            <p style={{ fontSize: 13, lineHeight: 1.6 }}>{inspect.bio}</p>
            <label>
              Status
              <select className="admin-select" value={inspect.status} onChange={(e) => {
                const status = e.target.value as AdminCreator['status'];
                setInspect({ ...inspect, status });
                updateCreator(inspect.handle, { status });
              }}>
                <option>Active</option>
                <option>Paused</option>
                <option>Suspended</option>
              </select>
            </label>
            <Link to={`/admin/creators/${inspect.handle}`} className="admin-btn ghost" onClick={() => setInspect(null)}>
              Open full profile
            </Link>
          </div>
        )}
      </Drawer>
    </div>
  );
}

export function CreatorDetailPage() {
  const { handle } = useParams();
  const { creators, moderation, payouts, rewardLedger, updateCreator } = useAdmin();
  const creator = creators.find((c) => c.handle === handle);
  const designs = moderation.filter((m) => m.creator === handle);
  const pays = payouts.filter((p) => p.creator === handle);
  const ledger = rewardLedger.filter((r) => r.creator === handle);

  if (!creator) {
    return <Empty title="Creator not found" copy="Unknown handle." action={<Link to="/admin/creators" className="admin-btn ghost sm">Roster</Link>} />;
  }

  return (
    <div>
      <Link to="/admin/creators" className="admin-muted" style={{ display: 'inline-flex', gap: 6, alignItems: 'center', marginBottom: 14 }}>
        <ArrowLeft size={14} /> Creators
      </Link>
      <div className="admin-hero-preview" style={{ marginBottom: 18 }}>
        <img src={creator.cover} alt="" />
        <div>
          <span className="admin-kicker" style={{ color: '#57dbf3' }}>
            L{creator.level} · {creator.role}
          </span>
          <h3>{creator.name}</h3>
          <p>{creator.statement}</p>
        </div>
      </div>
      <div className="admin-kpis">
        <article className="admin-kpi"><header><span>Followers</span></header><strong>{creator.followers.toLocaleString()}</strong><footer><span>{creator.rating} rating</span></footer></article>
        <article className="admin-kpi"><header><span>Units sold</span></header><strong>{creator.totalSales.toLocaleString()}</strong><footer><span>{creator.designsLive} live designs</span></footer></article>
        <article className="admin-kpi"><header><span>Pending</span></header><strong>{formatMoney(creator.pendingBalance)}</strong><footer><span>{creator.payoutMethod}</span></footer></article>
        <article className="admin-kpi"><header><span>Lifetime</span></header><strong>{formatMoney(creator.lifetimeEarnings)}</strong><footer><span>{creator.payoutLast4}</span></footer></article>
      </div>
      <div className="admin-split">
        <section className="admin-card">
          <div className="admin-card-head"><h2>Activity</h2></div>
          {designs.map((d) => (
            <div key={d.id} className="admin-cell-product" style={{ padding: '10px 0', borderTop: '1px solid #eef1ea' }}>
              <img src={d.artwork} alt="" style={{ objectFit: 'contain', background: '#111' }} />
              <div style={{ flex: 1 }}>
                <strong>{d.title}</strong>
                <span>{d.category} · {d.submittedAt}</span>
              </div>
              <StatusBadge status={d.status} />
            </div>
          ))}
        </section>
        <aside>
          <section className="admin-card" style={{ marginBottom: 14 }}>
            <div className="admin-card-head"><h2>Performance</h2></div>
            {ledger.map((r) => (
              <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderTop: '1px solid #eef1ea', fontSize: 12 }}>
                <span>{r.design}</span>
                <strong>{formatMoney(r.amount)}</strong>
              </div>
            ))}
          </section>
          <section className="admin-card">
            <div className="admin-card-head"><h2>Payouts</h2></div>
            {pays.map((p) => (
              <div key={p.id} style={{ padding: '8px 0', borderTop: '1px solid #eef1ea' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <strong>{formatMoney(p.amount)}</strong>
                  <StatusBadge status={p.status} />
                </div>
                <span className="admin-muted">{p.period}</span>
              </div>
            ))}
            <label style={{ marginTop: 12 }}>
              Account status
              <select className="admin-select" value={creator.status} onChange={(e) => updateCreator(creator.handle, { status: e.target.value as AdminCreator['status'] })}>
                <option>Active</option>
                <option>Paused</option>
                <option>Suspended</option>
              </select>
            </label>
          </section>
        </aside>
      </div>
    </div>
  );
}
