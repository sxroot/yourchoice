import { Link } from 'react-router-dom';
import { ArrowUpRight, Banknote, Package, Shirt, Sparkles } from 'lucide-react';
import { formatMoney, MONTHS, ORDERS_SERIES, REVENUE_SERIES } from '../../data/admin';
import { useAdmin } from '../AdminContext';
import { AreaChart, Kpi, PageHead, Skeleton, StatusBadge } from '../AdminShared';

export function DashboardPage() {
  const { ready, orders, customers, creators, products, inventory, activity, moderation, payouts, settings } = useAdmin();
  const paid = orders.filter((o) => o.paymentStatus === 'Paid');
  const revenue = paid.reduce((s, o) => s + o.total, 0);
  const openOrders = orders.filter((o) => !['Delivered', 'Cancelled', 'Returned'].includes(o.status)).length;
  const pendingMod = moderation.filter((m) => m.status === 'Pending' || m.status === 'Needs changes').length;
  const pendingPay = payouts.filter((p) => p.status === 'Pending' || p.status === 'Processing').reduce((s, p) => s + p.amount, 0);
  const low = inventory.filter((r) => r.onHand - r.reserved <= settings.lowStockThreshold).length;

  if (!ready) return <Skeleton rows={6} />;

  return (
    <div>
      <PageHead
        kicker="A01 / Command"
        title="Operations overview"
        copy="Live pulse across catalogue, orders, creators and settlement. All figures are local demo data for the YOUR CHOICE Vol. 01 atelier."
        actions={
          <Link to="/admin/reports" className="admin-btn ghost">
            Open reports <ArrowUpRight size={14} />
          </Link>
        }
      />
      <div className="admin-kpis">
        <Kpi label="Recognised revenue" value={formatMoney(36890)} delta="+12.4% vs Oct" bars={[40, 48, 44, 62, 58, 70, 66, 80]} icon={<Banknote size={16} />} />
        <Kpi label="Open orders" value={String(openOrders)} delta={`${orders.length} in ledger`} bars={[30, 42, 38, 55, 48, 60, 70, 64]} icon={<Package size={16} />} />
        <Kpi label="Active SKUs" value={String(products.filter((p) => p.status === 'Active').length)} delta={`${low} below reorder`} bars={[70, 68, 72, 60, 58, 55, 52, 48]} icon={<Shirt size={16} />} />
        <Kpi label="Creator balance" value={formatMoney(pendingPay)} delta={`${pendingMod} in review`} bars={[20, 28, 24, 40, 36, 52, 48, 64]} icon={<Sparkles size={16} />} />
      </div>

      <div className="admin-grid-2">
        <section className="admin-card">
          <div className="admin-card-head">
            <div>
              <span>FY 2026</span>
              <h2>Revenue trajectory</h2>
            </div>
            <span>USD · atelier + marketplace</span>
          </div>
          <AreaChart data={REVENUE_SERIES} labels={MONTHS} />
          <div className="admin-chart-legend">
            <span>
              <i style={{ background: '#2349ed' }} /> Revenue
            </span>
            <span>Peak {formatMoney(Math.max(...REVENUE_SERIES))} · Nov run-rate</span>
          </div>
        </section>
        <section className="admin-card">
          <div className="admin-card-head">
            <div>
              <span>Today</span>
              <h2>Recent activity</h2>
            </div>
            <Link to="/admin/orders" className="admin-muted">
              View orders
            </Link>
          </div>
          <ul className="admin-activity">
            {activity.slice(0, 7).map((a) => (
              <li key={a.id}>
                <i className={a.tone} />
                <div>
                  <strong>{a.actor}</strong> {a.verb} {a.target}
                </div>
                <small>{a.at}</small>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <div className="admin-grid-3" style={{ marginTop: 14 }}>
        <section className="admin-card">
          <div className="admin-card-head">
            <div>
              <span>Commerce</span>
              <h2>Orders in flight</h2>
            </div>
            <Link to="/admin/orders">All</Link>
          </div>
          <div className="admin-table-wrap" style={{ border: 0 }}>
            <table className="admin-table" style={{ minWidth: 0 }}>
              <tbody>
                {orders.slice(0, 5).map((o) => (
                  <tr key={o.id} className="row-link" onClick={() => (window.location.hash = '')}>
                    <td>
                      <Link to={`/admin/orders/${o.id}`} className="admin-mono">
                        {o.orderNumber}
                      </Link>
                      <div className="admin-muted">{o.customerName}</div>
                    </td>
                    <td>
                      <StatusBadge status={o.status} />
                    </td>
                    <td className="admin-right">{formatMoney(o.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
        <section className="admin-card">
          <div className="admin-card-head">
            <div>
              <span>People</span>
              <h2>Customers</h2>
            </div>
            <Link to="/admin/customers">Directory</Link>
          </div>
          <p style={{ fontSize: 28, letterSpacing: '-.05em', margin: '4px 0 12px' }}>{customers.length}</p>
          <p className="admin-muted" style={{ marginBottom: 14 }}>
            {customers.filter((c) => c.segment === 'Inner Circle').length} Inner Circle · {creators.filter((c) => c.status === 'Active').length} live creators
          </p>
          {customers.slice(0, 4).map((c) => (
            <Link key={c.id} to={`/admin/customers/${c.id}`} className="admin-cell-user" style={{ padding: '8px 0', borderTop: '1px solid #eef1ea' }}>
              <span className="admin-avatar" style={{ background: `hsl(${c.avatarHue} 42% 38%)` }}>
                {c.name.split(' ').map((p) => p[0]).join('').slice(0, 2)}
              </span>
              <div>
                <strong style={{ fontSize: 12 }}>{c.name}</strong>
                <span className="admin-muted" style={{ display: 'block' }}>
                  {c.city} · {formatMoney(c.spent)}
                </span>
              </div>
            </Link>
          ))}
        </section>
        <section className="admin-card">
          <div className="admin-card-head">
            <div>
              <span>Attention</span>
              <h2>Needs a decision</h2>
            </div>
          </div>
          <Link to="/admin/moderation" className="admin-note" style={{ marginBottom: 10 }}>
            <ShieldIcon />
            <div>
              <strong>{pendingMod} designs in the review lane</strong>
              <span>Approve, request changes or reject from Moderation.</span>
            </div>
          </Link>
          <Link to="/admin/payouts" className="admin-note" style={{ marginBottom: 10 }}>
            <Banknote size={16} />
            <div>
              <strong>{formatMoney(pendingPay)} waiting on payout</strong>
              <span>Sora and Mara have open settlement requests.</span>
            </div>
          </Link>
          <Link to="/admin/inventory" className="admin-note">
            <Shirt size={16} />
            <div>
              <strong>{low} SKUs below reorder point of {settings.lowStockThreshold}</strong>
              <span>Porto bins need a replenishment pass.</span>
            </div>
          </Link>
        </section>
      </div>

      <section className="admin-card" style={{ marginTop: 14 }}>
        <div className="admin-card-head">
          <div>
            <span>Volume</span>
            <h2>Order count by month</h2>
          </div>
        </div>
        <AreaChart data={ORDERS_SERIES} color="#57dbf3" labels={MONTHS} />
      </section>
    </div>
  );
}

function ShieldIcon() {
  return <Sparkles size={16} />;
}
