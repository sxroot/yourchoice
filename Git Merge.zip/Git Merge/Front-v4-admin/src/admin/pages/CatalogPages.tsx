import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';
import type { AdminCategory, AdminCollection } from '../../data/admin';
import { useAdmin } from '../AdminContext';
import { ConfirmDialog, Drawer, Empty, PageHead, Pagination, SearchField, Segmented, Skeleton, StatusBadge, Toggle, usePaged } from '../AdminShared';

export function CategoriesPage() {
  const { ready, categories, products, updateCategory, addCategory, deleteCategory } = useAdmin();
  const [editing, setEditing] = useState<AdminCategory | null>(null);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState({ name: '', description: '', banner: '/images/collection-tees-hero.webp' });
  const [pending, setPending] = useState<AdminCategory | null>(null);

  if (!ready) return <Skeleton />;

  return (
    <div>
      <PageHead
        kicker="A03 / Taxonomy"
        title="Categories"
        copy="Four merchandising families that drive the shop filters. Featured flags surface on the homepage rail."
        actions={
          <button type="button" className="admin-btn primary" onClick={() => setCreating(true)}>
            <Plus size={15} /> New category
          </button>
        }
      />
      <div className="admin-grid-3">
        {categories.map((c) => (
          <article key={c.id} className="admin-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ height: 140, overflow: 'hidden' }}>
              <img src={c.banner} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </div>
            <div style={{ padding: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span className="admin-kicker">{c.slug}</span>
                {c.featured && <StatusBadge status="Active" />}
              </div>
              <h2 style={{ fontSize: 22, margin: '8px 0' }}>{c.name}</h2>
              <p className="admin-muted" style={{ lineHeight: 1.5 }}>{c.description}</p>
              <p style={{ fontSize: 12, margin: '12px 0' }}>{products.filter((p) => p.category === c.name).length} products assigned</p>
              <div className="admin-actions" style={{ justifyContent: 'flex-start' }}>
                <button type="button" className="admin-btn ghost sm" onClick={() => setEditing(c)}>
                  Edit
                </button>
                <button type="button" className="admin-btn danger sm" onClick={() => setPending(c)}>
                  Remove
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
      <Drawer
        open={!!editing}
        title={editing?.name || 'Category'}
        onClose={() => setEditing(null)}
      >
        {editing && (
          <div className="admin-form">
            <label>
              Name
              <input className="admin-input" value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} />
            </label>
            <label>
              Description
              <textarea className="admin-textarea" value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} />
            </label>
            <label>
              Banner path
              <input className="admin-input" value={editing.banner} onChange={(e) => setEditing({ ...editing, banner: e.target.value })} />
            </label>
            <label className="admin-check">
              <input type="checkbox" checked={editing.featured} onChange={(e) => setEditing({ ...editing, featured: e.target.checked })} /> Featured on homepage
            </label>
            <button
              type="button"
              className="admin-btn primary"
              onClick={() => {
                updateCategory(editing.id, editing);
                setEditing(null);
              }}
            >
              Save category
            </button>
          </div>
        )}
      </Drawer>
      <Drawer open={creating} title="New category" onClose={() => setCreating(false)}>
        <div className="admin-form">
          <label>
            Name
            <input className="admin-input" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
          </label>
          <label>
            Description
            <textarea className="admin-textarea" value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} />
          </label>
          <button
            type="button"
            className="admin-btn primary"
            onClick={() => {
              if (!draft.name.trim()) return;
              addCategory({
                id: `cat-${Date.now()}`,
                name: draft.name,
                slug: draft.name.toLowerCase().replace(/\s+/g, '-'),
                description: draft.description,
                productCount: 0,
                featured: false,
                sortOrder: categories.length + 1,
                banner: draft.banner,
              });
              setDraft({ name: '', description: '', banner: '/images/collection-tees-hero.webp' });
              setCreating(false);
            }}
          >
            Create
          </button>
        </div>
      </Drawer>
      <ConfirmDialog
        open={!!pending}
        title={`Remove ${pending?.name}?`}
        copy="Products keep their category string. This only removes the merchandising card."
        danger
        confirmLabel="Remove"
        onCancel={() => setPending(null)}
        onConfirm={() => {
          if (pending) deleteCategory(pending.id);
          setPending(null);
        }}
      />
    </div>
  );
}

export function CollectionsPage() {
  const { ready, collections, products, updateCollection, setCollectionProducts } = useAdmin();
  const [active, setActive] = useState<AdminCollection | null>(null);

  if (!ready) return <Skeleton />;

  return (
    <div>
      <PageHead
        kicker="A03 / Chapters"
        title="Collections"
        copy="Editorial capsules with banners, essays and product assignments. Toggle publish to hide a chapter from the storefront directory."
      />
      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Collection</th>
              <th>Code</th>
              <th>Pieces</th>
              <th>Published</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {collections.map((c) => (
              <tr key={c.slug}>
                <td>
                  <div className="admin-cell-product">
                    <img src={c.heroImage} alt="" />
                    <div>
                      <strong>{c.shortTitle}</strong>
                      <span>{c.accentLabel}</span>
                    </div>
                  </div>
                </td>
                <td className="admin-mono">{c.code}</td>
                <td>{c.productIds.length}</td>
                <td>
                  <Toggle checked={c.published} onChange={(v) => updateCollection(c.slug, { published: v })} label={`Publish ${c.shortTitle}`} />
                </td>
                <td>
                  <button type="button" className="admin-btn ghost sm" onClick={() => setActive(c)}>
                    Merchandising
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Drawer open={!!active} title={active?.title || 'Collection'} onClose={() => setActive(null)}>
        {active && (
          <div className="admin-form">
            <div className="admin-hero-preview" style={{ minHeight: 120 }}>
              <img src={active.heroImage} alt="" />
              <div>
                <span className="admin-kicker" style={{ color: '#57dbf3' }}>{active.code}</span>
                <h3>{active.shortTitle}</h3>
              </div>
            </div>
            <label>
              Banner path
              <input className="admin-input" value={active.heroImage} onChange={(e) => setActive({ ...active, heroImage: e.target.value })} />
            </label>
            <label>
              Subtitle
              <textarea className="admin-textarea" value={active.subtitle} onChange={(e) => setActive({ ...active, subtitle: e.target.value })} />
            </label>
            <p className="admin-muted">Assign products</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 280, overflow: 'auto' }}>
              {products.map((p) => {
                const on = active.productIds.includes(p.id);
                return (
                  <label key={p.id} className="admin-check">
                    <input
                      type="checkbox"
                      checked={on}
                      onChange={() =>
                        setActive({
                          ...active,
                          productIds: on ? active.productIds.filter((id) => id !== p.id) : [...active.productIds, p.id],
                        })
                      }
                    />
                    {p.name}
                  </label>
                );
              })}
            </div>
            <button
              type="button"
              className="admin-btn primary"
              onClick={() => {
                updateCollection(active.slug, { heroImage: active.heroImage, subtitle: active.subtitle });
                setCollectionProducts(active.slug, active.productIds);
                setActive(null);
              }}
            >
              Save collection
            </button>
          </div>
        )}
      </Drawer>
    </div>
  );
}

export function InventoryPage() {
  const { ready, inventory, settings, updateInventory } = useAdmin();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('All');
  const [warehouse, setWarehouse] = useState('All');

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return inventory.filter((r) => {
      const available = r.onHand - r.reserved;
      if (filter === 'Low' && available > settings.lowStockThreshold) return false;
      if (filter === 'Incoming' && r.incoming === 0) return false;
      if (filter === 'Out' && available > 0) return false;
      if (warehouse !== 'All' && r.warehouse !== warehouse) return false;
      if (!needle) return true;
      return `${r.productName} ${r.sku} ${r.color} ${r.size}`.toLowerCase().includes(needle);
    });
  }, [inventory, q, filter, warehouse, settings.lowStockThreshold]);

  const pager = usePaged(rows, 12);
  const warehouses = ['All', ...Array.from(new Set(inventory.map((r) => r.warehouse)))];
  const lowCount = inventory.filter((r) => r.onHand - r.reserved <= settings.lowStockThreshold).length;
  const units = inventory.reduce((s, r) => s + r.onHand, 0);

  if (!ready) return <Skeleton />;

  return (
    <div>
      <PageHead
        kicker="A04 / Atelier stock"
        title="Inventory"
        copy={`${units.toLocaleString()} units on hand across Porto, Barcelos and Northern Italy. Reorder point is ${settings.lowStockThreshold}.`}
      />
      <div className="admin-kpis">
        <article className="admin-kpi">
          <header><span>On hand</span></header>
          <strong>{units}</strong>
          <footer><span>Across {inventory.length} SKUs</span></footer>
        </article>
        <article className="admin-kpi">
          <header><span>Below reorder</span></header>
          <strong>{lowCount}</strong>
          <footer><span className="down">Needs a cut ticket</span></footer>
        </article>
        <article className="admin-kpi">
          <header><span>Reserved</span></header>
          <strong>{inventory.reduce((s, r) => s + r.reserved, 0)}</strong>
          <footer><span>Open orders</span></footer>
        </article>
        <article className="admin-kpi">
          <header><span>Incoming</span></header>
          <strong>{inventory.reduce((s, r) => s + r.incoming, 0)}</strong>
          <footer><span>In production</span></footer>
        </article>
      </div>
      <div className="admin-toolbar">
        <SearchField value={q} onChange={setQ} placeholder="SKU, product, colour…" />
        <Segmented options={['All', 'Low', 'Incoming', 'Out']} value={filter} onChange={setFilter} />
        <select className="admin-select" style={{ width: 180 }} value={warehouse} onChange={(e) => setWarehouse(e.target.value)}>
          {warehouses.map((w) => (
            <option key={w}>{w}</option>
          ))}
        </select>
      </div>
      {rows.length === 0 ? (
        <Empty title="No matching SKUs" copy="Try another warehouse or clear the low-stock filter." />
      ) : (
        <>
          <div className="admin-table-wrap">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Variant</th>
                  <th>SKU</th>
                  <th>Size</th>
                  <th>On hand</th>
                  <th>Reserved</th>
                  <th>Incoming</th>
                  <th>Warehouse</th>
                </tr>
              </thead>
              <tbody>
                {pager.slice.map((r) => {
                  const available = r.onHand - r.reserved;
                  const low = available <= settings.lowStockThreshold;
                  return (
                    <tr key={r.id}>
                      <td>
                        <Link to={`/admin/products/${r.productId}`} className="admin-cell-product">
                          <img src={r.image} alt="" />
                          <div>
                            <strong>{r.productName}</strong>
                            <span>{r.color}</span>
                          </div>
                        </Link>
                      </td>
                      <td className="admin-mono">{r.sku}</td>
                      <td>{r.size}</td>
                      <td>
                        <input
                          className="admin-input"
                          style={{ width: 72 }}
                          type="number"
                          min={0}
                          value={r.onHand}
                          onChange={(e) => updateInventory(r.id, { onHand: Number(e.target.value) })}
                        />
                        {low && <div style={{ marginTop: 4 }}><StatusBadge status="Low" /></div>}
                      </td>
                      <td>{r.reserved}</td>
                      <td>{r.incoming}</td>
                      <td>{r.warehouse}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination page={pager.page} pages={pager.pages} onPage={pager.setPage} total={pager.total} pageSize={pager.pageSize} />
        </>
      )}
    </div>
  );
}
