import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { formatMoney, STATUS_FLOW, type OrderOpsStatus } from '../../data/admin';
import { useAdmin } from '../AdminContext';
import { Empty, PageHead, Pagination, SearchField, Segmented, Skeleton, StatusBadge, usePaged } from '../AdminShared';

export function OrdersListPage() {
  const { ready, orders } = useAdmin();
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('All');
  const [channel, setChannel] = useState('All');
  const navigate = useNavigate();

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return orders.filter((o) => {
      if (status !== 'All' && o.status !== status) return false;
      if (channel !== 'All' && o.channel !== channel) return false;
      if (!needle) return true;
      return `${o.orderNumber} ${o.customerName} ${o.email} ${o.trackingCode}`.toLowerCase().includes(needle);
    });
  }, [orders, q, status, channel]);

  const pager = usePaged(filtered, 8);
  const open = orders.filter((o) => !['Delivered', 'Cancelled', 'Returned'].includes(o.status)).length;
  const gmv = orders.filter((o) => o.paymentStatus === 'Paid').reduce((s, o) => s + o.total, 0);

  if (!ready) return <Skeleton />;

  return (
    <div>
      <PageHead
        kicker="A05 / Commerce"
        title="Order management"
        copy={`${open} open · ${formatMoney(gmv)} captured in this local ledger. Click a row for customer, delivery and timeline.`}
      />
      <div className="admin-toolbar">
        <SearchField value={q} onChange={setQ} placeholder="Order no, customer, tracking…" />
        <Segmented options={['All', 'Confirmed', 'Inspection', 'Packed', 'Dispatched', 'In Transit', 'Delivered']} value={status} onChange={setStatus} />
        <select className="admin-select" style={{ width: 160 }} value={channel} onChange={(e) => setChannel(e.target.value)}>
          <option>All</option>
          <option>Storefront</option>
          <option>Marketplace</option>
          <option>Studio</option>
        </select>
      </div>
      {filtered.length === 0 ? (
        <Empty title="No orders" copy="Nothing matches that combination of status and channel." />
      ) : (
        <>
          <div className="admin-table-wrap">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Customer</th>
                  <th>Placed</th>
                  <th>Channel</th>
                  <th>Status</th>
                  <th>Payment</th>
                  <th className="admin-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {pager.slice.map((o) => (
                  <tr key={o.id} className="row-link" onClick={() => navigate(`/admin/orders/${o.id}`)}>
                    <td>
                      <strong className="admin-mono">{o.orderNumber}</strong>
                      <div className="admin-muted">{o.items.length} item{o.items.length === 1 ? '' : 's'}</div>
                    </td>
                    <td>
                      {o.customerName}
                      <div className="admin-muted">{o.email}</div>
                    </td>
                    <td>{o.placedStamp}</td>
                    <td>{o.channel}</td>
                    <td>
                      <StatusBadge status={o.status} />
                    </td>
                    <td>
                      <StatusBadge status={o.paymentStatus} />
                    </td>
                    <td className="admin-right">{formatMoney(o.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={pager.page} pages={pager.pages} onPage={pager.setPage} total={pager.total} pageSize={pager.pageSize} />
        </>
      )}
    </div>
  );
}

export function OrderDetailPage() {
  const { id } = useParams();
  const { orders, setOrderStatus, updateOrderNotes } = useAdmin();
  const order = orders.find((o) => o.id === id);
  const [notes, setNotes] = useState(order?.notes || '');

  if (!order) {
    return (
      <Empty
        title="Order not found"
        copy="This identifier is not in the local ledger."
        action={
          <Link to="/admin/orders" className="admin-btn ghost sm">
            Back to orders
          </Link>
        }
      />
    );
  }

  const flowIndex = STATUS_FLOW.indexOf(order.status as (typeof STATUS_FLOW)[number]);

  return (
    <div>
      <Link to="/admin/orders" className="admin-muted" style={{ display: 'inline-flex', gap: 6, alignItems: 'center', marginBottom: 14 }}>
        <ArrowLeft size={14} /> Orders
      </Link>
      <PageHead
        kicker={order.channel}
        title={order.orderNumber}
        copy={`${order.customerName} · ${order.placedAt}`}
        actions={
          <select
            className="admin-select"
            style={{ width: 180 }}
            value={order.status}
            onChange={(e) => setOrderStatus(order.id, e.target.value as OrderOpsStatus)}
          >
            {(['Confirmed', 'Inspection', 'Packed', 'Dispatched', 'In Transit', 'Delivered', 'Cancelled', 'Returned'] as OrderOpsStatus[]).map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        }
      />

      <div className="admin-card" style={{ marginBottom: 14 }}>
        <div className="admin-stepper">
          {STATUS_FLOW.map((s, i) => (
            <div key={s} className={flowIndex >= i ? 'on' : ''}>
              <b>{i + 1}</b>
              <span>{s}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="admin-split">
        <div>
          <section className="admin-card" style={{ marginBottom: 14 }}>
            <div className="admin-card-head">
              <h2>Manifest</h2>
              <StatusBadge status={order.paymentStatus} />
            </div>
            {order.items.map((it) => (
              <div key={it.sku} className="admin-cell-product" style={{ padding: '10px 0', borderTop: '1px solid #eef1ea' }}>
                <img src={it.image} alt="" />
                <div style={{ flex: 1 }}>
                  <strong>{it.name}</strong>
                  <span>
                    {it.color} · {it.size} · qty {it.quantity}
                  </span>
                  <span className="admin-mono">{it.sku}</span>
                </div>
                <strong>{formatMoney(it.price * it.quantity)}</strong>
              </div>
            ))}
            <dl style={{ marginTop: 16 }}>
              {[
                ['Subtotal', order.subtotal],
                ['Discount', -order.discount],
                ['Shipping', order.shippingCost],
                ['Packaging', order.packagingCost],
                ['Tax', order.tax],
              ].map(([k, v]) => (
                <div key={String(k)} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: 12 }}>
                  <span className="admin-muted">{k}</span>
                  <span>{formatMoney(Number(v))}</span>
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 12, borderTop: '1px solid #d5d9d0', fontSize: 16, fontWeight: 700 }}>
                <span>Total</span>
                <span>{formatMoney(order.total)}</span>
              </div>
            </dl>
          </section>
          <section className="admin-card">
            <div className="admin-card-head">
              <h2>Status timeline</h2>
            </div>
            <div className="admin-timeline">
              {order.events.map((ev, i) => (
                <div key={i}>
                  <i className={i === 0 ? 'on' : ''} />
                  <div>
                    <strong>{ev.status}</strong>
                    <span>
                      {ev.date} · {ev.time} · {ev.location}
                    </span>
                    <span>{ev.detail}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
        <aside>
          <section className="admin-card" style={{ marginBottom: 14 }}>
            <div className="admin-card-head">
              <h2>Customer</h2>
            </div>
            <p>
              <Link to={`/admin/customers/${order.customerId}`}>
                <strong>{order.customerName}</strong>
              </Link>
            </p>
            <p className="admin-muted" style={{ margin: '6px 0' }}>
              {order.email}
              <br />
              {order.phone}
            </p>
            <p style={{ fontSize: 12, lineHeight: 1.7, marginTop: 12 }}>
              {order.shippingAddress.line1}
              <br />
              {order.shippingAddress.city} {order.shippingAddress.postalCode}
              <br />
              {order.shippingAddress.country}
            </p>
            <div style={{ borderTop: '1px solid #eef1ea', marginTop: 14, paddingTop: 12 }}>
              <span className="admin-muted">Carrier</span>
              <strong style={{ display: 'block', fontSize: 12, marginTop: 4 }}>{order.carrier}</strong>
              <span className="admin-mono">{order.trackingCode}</span>
              <p className="admin-muted" style={{ marginTop: 8 }}>
                {order.shippingMethod}
              </p>
              <p className="admin-muted">Payment · {order.paymentSummary}</p>
            </div>
          </section>
          <section className="admin-card">
            <div className="admin-card-head">
              <h2>Internal note</h2>
            </div>
            <textarea className="admin-textarea" value={notes} onChange={(e) => setNotes(e.target.value)} />
            <button type="button" className="admin-btn primary sm" style={{ marginTop: 10 }} onClick={() => updateOrderNotes(order.id, notes)}>
              Save note
            </button>
            {order.giftNote && <p className="admin-note" style={{ marginTop: 12 }}>Gift: {order.giftNote}</p>}
          </section>
        </aside>
      </div>
    </div>
  );
}
