import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Eye, Pencil, Plus, Trash2 } from 'lucide-react';
import type { AdminProduct, PrintArea } from '../../data/admin';
import { formatMoney } from '../../data/admin';
import { useAdmin } from '../AdminContext';
import {
  ConfirmDialog,
  Empty,
  PageHead,
  Pagination,
  SearchField,
  Segmented,
  Skeleton,
  StatusBadge,
  usePaged,
} from '../AdminShared';

const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

export function ProductsListPage() {
  const { ready, products, deleteProduct, setProductStatus } = useAdmin();
  const [params] = useSearchParams();
  const [q, setQ] = useState(params.get('q') || '');
  const [status, setStatus] = useState('All');
  const [cat, setCat] = useState('All');
  const [pendingDelete, setPendingDelete] = useState<AdminProduct | null>(null);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return products.filter((p) => {
      if (status !== 'All' && p.status !== status) return false;
      if (cat !== 'All' && p.category !== cat) return false;
      if (!needle) return true;
      return `${p.name} ${p.code} ${p.skuPrefix} ${p.color} ${p.category}`.toLowerCase().includes(needle);
    });
  }, [products, q, status, cat]);

  const pager = usePaged(filtered, 8);
  if (!ready) return <Skeleton />;

  return (
    <div>
      <PageHead
        kicker="A02 / Catalogue"
        title="Product management"
        copy="Fifteen atelier silhouettes plus anything you add. Search, filter, archive or open the editor for media, pricing, variants and print areas."
        actions={
          <Link to="/admin/products/new" className="admin-btn primary">
            <Plus size={15} /> Create product
          </Link>
        }
      />
      <div className="admin-toolbar">
        <SearchField value={q} onChange={setQ} placeholder="Search name, SKU, colour…" />
        <Segmented options={['All', 'Active', 'Draft', 'Archived']} value={status} onChange={setStatus} />
        <select className="admin-select" style={{ width: 180 }} value={cat} onChange={(e) => setCat(e.target.value)}>
          <option>All</option>
          <option>T-Shirts</option>
          <option>Polo Shirts</option>
          <option>Essentials</option>
          <option>Outerwear</option>
        </select>
      </div>
      {filtered.length === 0 ? (
        <Empty title="No products match" copy="Adjust filters or create a new silhouette for the Vol. 01 catalogue." action={<Link to="/admin/products/new" className="admin-btn primary sm">New product</Link>} />
      ) : (
        <>
          <div className="admin-table-wrap">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>SKU</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Stock</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {pager.slice.map((p) => {
                  const stock = Object.values(p.stockBySize).reduce((s, n) => s + n, 0);
                  return (
                    <tr key={p.id}>
                      <td>
                        <Link to={`/admin/products/${p.id}`} className="admin-cell-product">
                          <img src={p.image} alt="" />
                          <div>
                            <strong>{p.name}</strong>
                            <span>
                              {p.color} · {p.fit} · {p.gsm}
                            </span>
                          </div>
                        </Link>
                      </td>
                      <td className="admin-mono">{p.skuPrefix}</td>
                      <td>{p.category}</td>
                      <td>{formatMoney(p.price)}</td>
                      <td>
                        {stock}
                        <div className={`low-bar ${stock < 40 ? 'danger' : ''}`}>
                          <i style={{ width: `${Math.min(100, stock / 2)}%` }} />
                        </div>
                      </td>
                      <td>
                        <button type="button" onClick={() => setProductStatus(p.id, p.status === 'Active' ? 'Draft' : 'Active')}>
                          <StatusBadge status={p.status} />
                        </button>
                      </td>
                      <td>
                        <div className="admin-actions">
                          <Link to={`/product/${p.slug}`} className="admin-icon-tiny" aria-label="View storefront" target="_self">
                            <Eye size={14} />
                          </Link>
                          <Link to={`/admin/products/${p.id}`} className="admin-icon-tiny" aria-label="Edit">
                            <Pencil size={14} />
                          </Link>
                          <button type="button" className="admin-icon-tiny" aria-label="Delete" onClick={() => setPendingDelete(p)}>
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination page={pager.page} pages={pager.pages} onPage={pager.setPage} total={pager.total} pageSize={pager.pageSize} />
        </>
      )}
      <ConfirmDialog
        open={!!pendingDelete}
        title={`Remove ${pendingDelete?.name}?`}
        copy="This only affects the local admin catalogue. The Phase 01 storefront data file is not rewritten."
        confirmLabel="Remove"
        danger
        onCancel={() => setPendingDelete(null)}
        onConfirm={() => {
          if (pendingDelete) deleteProduct(pendingDelete.id);
          setPendingDelete(null);
        }}
      />
    </div>
  );
}

const emptyProduct = (nextId: number): AdminProduct => ({
  id: nextId,
  position: nextId,
  code: `YC / ${String(nextId).padStart(3, '0')}`,
  slug: 'new-atelier-piece',
  name: '',
  category: 'T-Shirts',
  subStyle: 'Oversized',
  collectionSlugs: ['t-shirts'],
  price: 48,
  image: '/images/tee-chalk.webp',
  lifestyleImage: '/images/editorial.webp',
  color: 'Warm Chalk',
  colorHex: '#edece6',
  variants: [{ label: 'Warm Chalk', hex: '#edece6', slug: 'new-atelier-piece', image: '/images/tee-chalk.webp' }],
  fit: 'Oversized',
  gsm: '320 GSM',
  sizes: ['S', 'M', 'L', 'XL'],
  description: '',
  editorialNote: '',
  material: '',
  care: ['Cold gentle wash'],
  origin: 'Porto, Portugal',
  modelNote: '',
  bestsellerRank: nextId,
  status: 'Draft',
  skuPrefix: `YC-${String(nextId).padStart(3, '0')}`,
  cost: 18,
  visible: true,
  stockBySize: { S: 12, M: 18, L: 18, XL: 10 },
  printAreas: [
    { id: 'front', name: 'Front chest', widthCm: 28, heightCm: 36, x: 50, y: 32, enabled: true },
    { id: 'back', name: 'Back panel', widthCm: 30, heightCm: 40, x: 50, y: 28, enabled: true },
    { id: 'left-chest', name: 'Left chest', widthCm: 10, heightCm: 10, x: 32, y: 28, enabled: false },
    { id: 'sleeve', name: 'Left sleeve', widthCm: 8, heightCm: 12, x: 12, y: 40, enabled: false },
  ],
  taxable: true,
  allowCustom: true,
});

const GALLERY = [
  '/images/tee.webp',
  '/images/tee-chalk.webp',
  '/images/tee-black.webp',
  '/images/tee-olive.webp',
  '/images/tee-longsleeve.webp',
  '/images/polo-black.webp',
  '/images/polo-blue.webp',
  '/images/polo-chalk.webp',
  '/images/polo-olive.webp',
  '/images/polo-slate.webp',
  '/images/hoodie.webp',
  '/images/jacket.webp',
  '/images/overshirt-black.webp',
  '/images/campaign.webp',
];

export function ProductEditorPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { products, upsertProduct } = useAdmin();
  const isNew = id === 'new' || !id;
  const existing = products.find((p) => String(p.id) === id);
  const [form, setForm] = useState<AdminProduct>(() => existing || emptyProduct(Math.max(0, ...products.map((p) => p.id)) + 1));
  const [error, setError] = useState('');
  const [previewView, setPreviewView] = useState<'front' | 'lifestyle'>('front');

  useEffect(() => {
    if (existing) setForm(existing);
  }, [id]);

  const patch = (p: Partial<AdminProduct>) => setForm((f) => ({ ...f, ...p }));

  const toggleSize = (size: string) => {
    const sizes = form.sizes.includes(size) ? form.sizes.filter((s) => s !== size) : [...form.sizes, size];
    const stockBySize = { ...form.stockBySize };
    if (!sizes.includes(size)) delete stockBySize[size];
    else if (stockBySize[size] == null) stockBySize[size] = 12;
    patch({ sizes, stockBySize });
  };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      setError('A product name is required.');
      return;
    }
    if (form.price <= 0) {
      setError('Price must be greater than zero.');
      return;
    }
    const slug = form.slug || form.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    upsertProduct({ ...form, slug, skuPrefix: form.skuPrefix || `YC-${String(form.id).padStart(3, '0')}` });
    navigate('/admin/products');
  };

  const setArea = (area: PrintArea) => {
    patch({ printAreas: form.printAreas.map((a) => (a.id === area.id ? area : a)) });
  };

  return (
    <div>
      <Link to="/admin/products" className="admin-muted" style={{ display: 'inline-flex', gap: 6, alignItems: 'center', marginBottom: 14 }}>
        <ArrowLeft size={14} /> Catalogue
      </Link>
      <PageHead
        kicker={isNew ? 'A02 / New' : form.code}
        title={isNew ? 'Create product' : form.name || 'Edit product'}
        copy="Media, pricing, variants, SKU, stock and print-area geometry. Saved locally in this admin session."
      />
      {error && <div className="admin-error">{error}</div>}
      <form className="admin-split" onSubmit={save}>
        <div className="admin-form">
          <section className="admin-card">
            <div className="admin-card-head">
              <h2>Identity</h2>
            </div>
            <div className="admin-form">
              <label>
                Name
                <input className="admin-input" value={form.name} onChange={(e) => patch({ name: e.target.value })} required />
              </label>
              <div className="admin-form-grid">
                <label>
                  Slug
                  <input className="admin-input" value={form.slug} onChange={(e) => patch({ slug: e.target.value })} />
                </label>
                <label>
                  SKU prefix
                  <input className="admin-input" value={form.skuPrefix} onChange={(e) => patch({ skuPrefix: e.target.value })} />
                </label>
              </div>
              <div className="admin-form-grid three">
                <label>
                  Category
                  <select className="admin-select" value={form.category} onChange={(e) => patch({ category: e.target.value as AdminProduct['category'] })}>
                    <option>T-Shirts</option>
                    <option>Polo Shirts</option>
                    <option>Essentials</option>
                    <option>Outerwear</option>
                  </select>
                </label>
                <label>
                  Fit
                  <select className="admin-select" value={form.fit} onChange={(e) => patch({ fit: e.target.value as AdminProduct['fit'] })}>
                    <option>Oversized</option>
                    <option>Boxy</option>
                    <option>Structured</option>
                    <option>Relaxed</option>
                  </select>
                </label>
                <label>
                  Status
                  <select className="admin-select" value={form.status} onChange={(e) => patch({ status: e.target.value as AdminProduct['status'] })}>
                    <option>Active</option>
                    <option>Draft</option>
                    <option>Archived</option>
                  </select>
                </label>
              </div>
              <label>
                Description
                <textarea className="admin-textarea" value={form.description} onChange={(e) => patch({ description: e.target.value })} />
              </label>
            </div>
          </section>

          <section className="admin-card">
            <div className="admin-card-head">
              <h2>Media gallery</h2>
              <span>Click to set hero</span>
            </div>
            <div className="admin-media-grid">
              {GALLERY.map((src) => (
                <button type="button" key={src} className={form.image === src ? 'active' : ''} onClick={() => patch({ image: src })}>
                  <img src={src} alt="" />
                </button>
              ))}
            </div>
            <label style={{ marginTop: 14 }}>
              Lifestyle image path
              <input className="admin-input" value={form.lifestyleImage} onChange={(e) => patch({ lifestyleImage: e.target.value })} />
            </label>
          </section>

          <section className="admin-card">
            <div className="admin-card-head">
              <h2>Pricing</h2>
            </div>
            <div className="admin-form-grid three">
              <label>
                Retail USD
                <input className="admin-input" type="number" min={0} value={form.price} onChange={(e) => patch({ price: Number(e.target.value) })} />
              </label>
              <label>
                Cost USD
                <input className="admin-input" type="number" min={0} value={form.cost} onChange={(e) => patch({ cost: Number(e.target.value) })} />
              </label>
              <label>
                Compare-at
                <input className="admin-input" type="number" min={0} value={form.compareAtPrice || ''} onChange={(e) => patch({ compareAtPrice: Number(e.target.value) || undefined })} />
              </label>
            </div>
            <p className="admin-muted" style={{ marginTop: 10 }}>
              Margin {form.price ? Math.round(((form.price - form.cost) / form.price) * 100) : 0}% · {formatMoney(form.price - form.cost)} per unit
            </p>
            <div className="admin-form-grid" style={{ marginTop: 12 }}>
              <label className="admin-check">
                <input type="checkbox" checked={form.taxable} onChange={(e) => patch({ taxable: e.target.checked })} /> Taxable
              </label>
              <label className="admin-check">
                <input type="checkbox" checked={form.allowCustom} onChange={(e) => patch({ allowCustom: e.target.checked })} /> Studio customisable
              </label>
              <label className="admin-check">
                <input type="checkbox" checked={form.visible} onChange={(e) => patch({ visible: e.target.checked })} /> Visible on storefront
              </label>
            </div>
          </section>

          <section className="admin-card">
            <div className="admin-card-head">
              <h2>Colour, sizes & stock</h2>
            </div>
            <div className="admin-form-grid">
              <label>
                Colour name
                <input className="admin-input" value={form.color} onChange={(e) => patch({ color: e.target.value })} />
              </label>
              <label>
                Hex
                <input className="admin-input" value={form.colorHex} onChange={(e) => patch({ colorHex: e.target.value })} />
              </label>
            </div>
            <div className="admin-swatches" style={{ margin: '12px 0' }}>
              {form.variants.map((v) => (
                <button type="button" key={v.slug} className={form.color === v.label ? 'active' : ''} style={{ background: v.hex }} onClick={() => patch({ color: v.label, colorHex: v.hex, image: v.image })} aria-label={v.label} />
              ))}
            </div>
            <div className="admin-seg" style={{ marginBottom: 12 }}>
              {SIZES.map((s) => (
                <button type="button" key={s} className={form.sizes.includes(s) ? 'active' : ''} onClick={() => toggleSize(s)}>
                  {s}
                </button>
              ))}
            </div>
            <div className="admin-form-grid three">
              {form.sizes.map((s) => (
                <label key={s}>
                  On-hand {s}
                  <input
                    className="admin-input"
                    type="number"
                    min={0}
                    value={form.stockBySize[s] ?? 0}
                    onChange={(e) => patch({ stockBySize: { ...form.stockBySize, [s]: Number(e.target.value) } })}
                  />
                </label>
              ))}
            </div>
            <label style={{ marginTop: 12 }}>
              GSM / fabric
              <input className="admin-input" value={form.gsm} onChange={(e) => patch({ gsm: e.target.value })} />
            </label>
          </section>

          <section className="admin-card">
            <div className="admin-card-head">
              <h2>Print areas</h2>
              <span>Studio geometry</span>
            </div>
            {form.printAreas.map((a) => (
              <div key={a.id} className="admin-setting-row">
                <div>
                  <strong>{a.name}</strong>
                  <span>
                    {a.widthCm} × {a.heightCm} cm · offset {a.x}% / {a.y}%
                  </span>
                </div>
                <label className="admin-check">
                  <input type="checkbox" checked={a.enabled} onChange={(e) => setArea({ ...a, enabled: e.target.checked })} /> Enabled
                </label>
              </div>
            ))}
          </section>

          <div className="admin-form-actions">
            <button type="button" className="admin-btn ghost" onClick={() => navigate('/admin/products')}>
              Cancel
            </button>
            <button type="submit" className="admin-btn primary">
              Save product
            </button>
          </div>
        </div>

        <aside className="admin-sticky">
          <section className="admin-card">
            <div className="admin-card-head">
              <h2>Preview</h2>
              <div className="admin-seg">
                <button type="button" className={previewView === 'front' ? 'active' : ''} onClick={() => setPreviewView('front')}>
                  Hero
                </button>
                <button type="button" className={previewView === 'lifestyle' ? 'active' : ''} onClick={() => setPreviewView('lifestyle')}>
                  Lifestyle
                </button>
              </div>
            </div>
            <div className="admin-print-board">
              <img src={previewView === 'front' ? form.image : form.lifestyleImage || form.image} alt="" />
              {previewView === 'front' &&
                form.printAreas.map((a) => (
                  <div
                    key={a.id}
                    className={`admin-print-area ${a.enabled ? '' : 'off'}`}
                    style={{
                      left: `${a.x - a.widthCm / 2}%`,
                      top: `${a.y}%`,
                      width: `${a.widthCm}%`,
                      height: `${a.heightCm * 0.7}%`,
                    }}
                  >
                    <span>{a.name}</span>
                  </div>
                ))}
            </div>
            <p style={{ marginTop: 12 }}>
              <strong>{form.name || 'Untitled silhouette'}</strong>
            </p>
            <p className="admin-muted">
              {form.skuPrefix} · {formatMoney(form.price)} · {form.status}
            </p>
          </section>
        </aside>
      </form>
    </div>
  );
}
