import { useMemo, useState } from 'react';
import { MONTHS, ORDERS_SERIES, REVENUE_SERIES, formatMoney, type ContentBlock } from '../../data/admin';
import { useAdmin } from '../AdminContext';
import { AreaChart, BarChart, PageHead, Segmented, Skeleton, StatusBadge, Toggle } from '../AdminShared';

export function ContentPage() {
  const { ready, content, upsertContent, deleteContent } = useAdmin();
  const [active, setActive] = useState<ContentBlock | null>(null);
  const [slot, setSlot] = useState('All');

  const list = content.filter((b) => slot === 'All' || b.slot === slot.toLowerCase());

  if (!ready) return <Skeleton />;

  const form = active;

  return (
    <div>
      <PageHead
        kicker="A11 / Homepages"
        title="Homepage & content"
        copy="Hero, ticker, banners, editorial and collection modules. Publishing here only updates this admin preview."
        actions={
          <button
            type="button"
            className="admin-btn primary"
            onClick={() =>
              setActive({
                id: `cb-${Date.now()}`,
                slot: 'banner',
                title: 'New banner',
                kicker: 'PROMO',
                body: '',
                cta: 'Shop now',
                ctaHref: '/shop',
                image: '/images/campaign.webp',
                published: false,
                sortOrder: content.length + 1,
              })
            }
          >
            New block
          </button>
        }
      />
      <div className="admin-toolbar">
        <Segmented options={['All', 'Hero', 'Ticker', 'Banner', 'Editorial', 'Collection']} value={slot} onChange={setSlot} />
      </div>
      <div className="admin-split">
        <div>
          {list.map((b) => (
            <article key={b.id} className="admin-card" style={{ marginBottom: 12, padding: 0, overflow: 'hidden' }}>
              <div className="admin-hero-preview" style={{ minHeight: 140 }}>
                {b.image && <img src={b.image} alt="" />}
                <div>
                  <span className="admin-kicker" style={{ color: '#57dbf3' }}>
                    {b.kicker} · {b.slot}
                  </span>
                  <h3>{b.title}</h3>
                  <p>{b.body}</p>
                </div>
              </div>
              <div style={{ padding: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
                <StatusBadge status={b.published ? 'Active' : 'Draft'} />
                <div className="admin-actions">
                  <button type="button" className="admin-btn ghost sm" onClick={() => setActive(b)}>
                    Edit
                  </button>
                  <Toggle checked={b.published} onChange={(v) => upsertContent({ ...b, published: v })} label={`Publish ${b.title}`} />
                </div>
              </div>
            </article>
          ))}
        </div>
        <aside className="admin-card admin-sticky">
          <div className="admin-card-head">
            <h2>{form ? 'Content editor' : 'Select a block'}</h2>
          </div>
          {form ? (
            <div className="admin-form">
              <label>
                Slot
                <select className="admin-select" value={form.slot} onChange={(e) => setActive({ ...form, slot: e.target.value as ContentBlock['slot'] })}>
                  <option value="hero">Hero</option>
                  <option value="ticker">Ticker</option>
                  <option value="banner">Banner</option>
                  <option value="editorial">Editorial</option>
                  <option value="collection">Collection</option>
                </select>
              </label>
              <label>Kicker<input className="admin-input" value={form.kicker} onChange={(e) => setActive({ ...form, kicker: e.target.value })} /></label>
              <label>Title<input className="admin-input" value={form.title} onChange={(e) => setActive({ ...form, title: e.target.value })} /></label>
              <label>Body<textarea className="admin-textarea" value={form.body} onChange={(e) => setActive({ ...form, body: e.target.value })} /></label>
              <div className="admin-form-grid">
                <label>CTA<input className="admin-input" value={form.cta} onChange={(e) => setActive({ ...form, cta: e.target.value })} /></label>
                <label>Href<input className="admin-input" value={form.ctaHref} onChange={(e) => setActive({ ...form, ctaHref: e.target.value })} /></label>
              </div>
              <label>Image path<input className="admin-input" value={form.image} onChange={(e) => setActive({ ...form, image: e.target.value })} /></label>
              <div className="admin-form-actions" style={{ border: 0, padding: 0 }}>
                <button type="button" className="admin-btn danger sm" onClick={() => { deleteContent(form.id); setActive(null); }}>Remove</button>
                <button type="button" className="admin-btn primary" onClick={() => { upsertContent(form); setActive(null); }}>Save block</button>
              </div>
            </div>
          ) : (
            <p className="admin-muted">Choose a module or create a new promotional banner.</p>
          )}
        </aside>
      </div>
    </div>
  );
}

export function SettingsPage() {
  const { ready, settings, updateSettings, resetDemo } = useAdmin();
  const [form, setForm] = useState(settings);
  const [confirmReset, setConfirmReset] = useState(false);

  if (!ready) return <Skeleton />;

  const patch = (p: Partial<typeof form>) => setForm((f) => ({ ...f, ...p }));

  return (
    <div>
      <PageHead
        kicker="A12 / House"
        title="Store settings"
        copy="Branding, language, currency, shipping zones and notification preferences. Saved in localStorage for this demo."
      />
      <div className="admin-split">
        <form
          className="admin-form"
          onSubmit={(e) => {
            e.preventDefault();
            updateSettings(form);
          }}
        >
          <section className="admin-card">
            <div className="admin-card-head"><h2>General</h2></div>
            <div className="admin-form">
              <label>Store name<input className="admin-input" value={form.storeName} onChange={(e) => patch({ storeName: e.target.value })} /></label>
              <label>Tagline<input className="admin-input" value={form.tagline} onChange={(e) => patch({ tagline: e.target.value })} /></label>
              <label>Concierge email<input className="admin-input" type="email" value={form.supportEmail} onChange={(e) => patch({ supportEmail: e.target.value })} /></label>
              <div className="admin-form-grid three">
                <label>Language
                  <select className="admin-select" value={form.language} onChange={(e) => patch({ language: e.target.value })}>
                    <option value="en">English</option>
                    <option value="fr">Français</option>
                    <option value="de">Deutsch</option>
                    <option value="ja">日本語</option>
                  </select>
                </label>
                <label>Currency
                  <select className="admin-select" value={form.currency} onChange={(e) => patch({ currency: e.target.value })}>
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                    <option value="GBP">GBP</option>
                  </select>
                </label>
                <label>Timezone
                  <select className="admin-select" value={form.timezone} onChange={(e) => patch({ timezone: e.target.value })}>
                    <option value="Europe/Lisbon">Europe/Lisbon</option>
                    <option value="Europe/London">Europe/London</option>
                    <option value="America/New_York">America/New_York</option>
                    <option value="Asia/Singapore">Asia/Singapore</option>
                  </select>
                </label>
              </div>
            </div>
          </section>
          <section className="admin-card">
            <div className="admin-card-head"><h2>Branding</h2></div>
            <div className="admin-form-grid">
              <label>Primary
                <input className="admin-input" value={form.brandPrimary} onChange={(e) => patch({ brandPrimary: e.target.value })} />
              </label>
              <label>Cyan
                <input className="admin-input" value={form.brandCyan} onChange={(e) => patch({ brandCyan: e.target.value })} />
              </label>
            </div>
            <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
              <span style={{ width: 48, height: 48, background: form.brandPrimary }} />
              <span style={{ width: 48, height: 48, background: form.brandCyan }} />
              <img src="/images/official-logo-transparent.webp" alt="Official logo" style={{ height: 48 }} />
              <img src="/images/official-emblem.webp" alt="Emblem" style={{ height: 48, background: '#111', padding: 6 }} />
            </div>
          </section>
          <section className="admin-card">
            <div className="admin-card-head"><h2>Commerce</h2></div>
            <div className="admin-form-grid three">
              <label>Free shipping over<input className="admin-input" type="number" value={form.freeShippingThreshold} onChange={(e) => patch({ freeShippingThreshold: Number(e.target.value) })} /></label>
              <label>Low-stock point<input className="admin-input" type="number" value={form.lowStockThreshold} onChange={(e) => patch({ lowStockThreshold: Number(e.target.value) })} /></label>
              <label>Default royalty %<input className="admin-input" type="number" value={form.defaultRoyalty} onChange={(e) => patch({ defaultRoyalty: Number(e.target.value) })} /></label>
            </div>
            <label className="admin-check" style={{ marginTop: 12 }}>
              <input type="checkbox" checked={form.taxInclusive} onChange={(e) => patch({ taxInclusive: e.target.checked })} /> Prices are tax-inclusive (DDP)
            </label>
          </section>
          <section className="admin-card">
            <div className="admin-card-head"><h2>Shipping zones</h2></div>
            {form.shippingZones.map((z, i) => (
              <div key={z.id} className="admin-form-grid three" style={{ marginBottom: 10 }}>
                <label>Zone<input className="admin-input" value={z.name} onChange={(e) => {
                  const shippingZones = form.shippingZones.map((x, idx) => idx === i ? { ...x, name: e.target.value } : x);
                  patch({ shippingZones });
                }} /></label>
                <label>ETA<input className="admin-input" value={z.eta} onChange={(e) => {
                  const shippingZones = form.shippingZones.map((x, idx) => idx === i ? { ...x, eta: e.target.value } : x);
                  patch({ shippingZones });
                }} /></label>
                <label>Rate USD<input className="admin-input" type="number" value={z.rate} onChange={(e) => {
                  const shippingZones = form.shippingZones.map((x, idx) => idx === i ? { ...x, rate: Number(e.target.value) } : x);
                  patch({ shippingZones });
                }} /></label>
              </div>
            ))}
          </section>
          <div className="admin-form-actions">
            <button type="submit" className="admin-btn primary">Save settings</button>
          </div>
        </form>
        <aside>
          <section className="admin-card" style={{ marginBottom: 14 }}>
            <div className="admin-card-head"><h2>Notifications</h2></div>
            {form.notifications.map((n) => (
              <div key={n.id} className="admin-setting-row">
                <div>
                  <strong>{n.label}</strong>
                  <span>{n.description}</span>
                </div>
                <Toggle
                  checked={n.enabled}
                  label={n.label}
                  onChange={(v) => patch({ notifications: form.notifications.map((x) => x.id === n.id ? { ...x, enabled: v } : x) })}
                />
              </div>
            ))}
          </section>
          <section className="admin-card">
            <div className="admin-card-head"><h2>Demo data</h2></div>
            <p className="admin-muted" style={{ marginBottom: 12, lineHeight: 1.5 }}>
              Restore the original Phase 03 sample ledger. Storefront Phase 01 / 02 files are never rewritten.
            </p>
            {!confirmReset ? (
              <button type="button" className="admin-btn danger" onClick={() => setConfirmReset(true)}>Reset admin data</button>
            ) : (
              <div className="admin-note" style={{ flexDirection: 'column', alignItems: 'flex-start' }}>
                <strong>This clears localStorage for the admin console.</strong>
                <div className="admin-actions" style={{ marginTop: 10 }}>
                  <button type="button" className="admin-btn ghost sm" onClick={() => setConfirmReset(false)}>Cancel</button>
                  <button type="button" className="admin-btn danger sm" onClick={() => { resetDemo(); setForm(settings); setConfirmReset(false); }}>Confirm reset</button>
                </div>
              </div>
            )}
          </section>
        </aside>
      </div>
    </div>
  );
}

export function ReportsPage() {
  const { ready, orders, products, customers, creators, inventory, settings } = useAdmin();
  const [range, setRange] = useState('YTD');

  const factor = range === '30d' ? 0.18 : range === '90d' ? 0.42 : 1;
  const revenue = Math.round(REVENUE_SERIES.reduce((s, n) => s + n, 0) * factor);
  const orderCount = Math.round(ORDERS_SERIES.reduce((s, n) => s + n, 0) * factor);

  const productPerf = useMemo(() => {
    const map = new Map<string, { name: string; units: number; revenue: number }>();
    orders.forEach((o) => {
      if (o.paymentStatus !== 'Paid') return;
      o.items.forEach((it) => {
        const cur = map.get(it.name) || { name: it.name, units: 0, revenue: 0 };
        cur.units += it.quantity;
        cur.revenue += it.price * it.quantity;
        map.set(it.name, cur);
      });
    });
    return [...map.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 8);
  }, [orders]);

  if (!ready) return <Skeleton />;

  const series = range === '30d' ? REVENUE_SERIES.slice(-3) : range === '90d' ? REVENUE_SERIES.slice(-6) : REVENUE_SERIES;
  const labels = range === '30d' ? MONTHS.slice(-3) : range === '90d' ? MONTHS.slice(-6) : MONTHS;

  return (
    <div>
      <PageHead
        kicker="A13 / Intelligence"
        title="Reports & analytics"
        copy="Revenue, product mix, customers and creator contribution. Date ranges rescale the FY 2026 demo series."
        actions={<Segmented options={['30d', '90d', 'YTD']} value={range} onChange={setRange} />}
      />
      <div className="admin-kpis">
        <article className="admin-kpi"><header><span>Revenue</span></header><strong>{formatMoney(revenue)}</strong><footer><span className="up">+12.4% vs prior</span></footer></article>
        <article className="admin-kpi"><header><span>Orders</span></header><strong>{orderCount}</strong><footer><span>AOV {formatMoney(Math.round(revenue / Math.max(orderCount, 1)))}</span></footer></article>
        <article className="admin-kpi"><header><span>Customers</span></header><strong>{customers.length}</strong><footer><span>{customers.filter((c) => c.segment === 'Inner Circle').length} Inner Circle</span></footer></article>
        <article className="admin-kpi"><header><span>Creator GMV share</span></header><strong>28%</strong><footer><span>{creators.length} independents</span></footer></article>
      </div>
      <div className="admin-grid-2">
        <section className="admin-card">
          <div className="admin-card-head"><h2>Revenue</h2><span>{range}</span></div>
          <AreaChart data={series} labels={labels} />
        </section>
        <section className="admin-card">
          <div className="admin-card-head"><h2>Orders</h2><span>{range}</span></div>
          <AreaChart data={range === '30d' ? ORDERS_SERIES.slice(-3) : range === '90d' ? ORDERS_SERIES.slice(-6) : ORDERS_SERIES} color="#57dbf3" labels={labels} />
        </section>
      </div>
      <div className="admin-grid-2" style={{ marginTop: 14 }}>
        <section className="admin-card">
          <div className="admin-card-head"><h2>Product performance</h2></div>
          <BarChart data={productPerf.map((p) => ({ label: p.name.split(' ').slice(0, 2).join(' '), value: p.revenue }))} />
          <div className="admin-table-wrap" style={{ border: 0, marginTop: 8 }}>
            <table className="admin-table" style={{ minWidth: 0 }}>
              <thead><tr><th>Product</th><th>Units</th><th>Revenue</th></tr></thead>
              <tbody>
                {productPerf.map((p) => (
                  <tr key={p.name}>
                    <td>{p.name}</td>
                    <td>{p.units}</td>
                    <td>{formatMoney(p.revenue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
        <section className="admin-card">
          <div className="admin-card-head"><h2>Customer mix</h2></div>
          <BarChart
            color="#1038dc"
            data={['Inner Circle', 'Creator', 'Guest', 'Wholesale'].map((seg) => ({
              label: seg.split(' ')[0],
              value: customers.filter((c) => c.segment === seg).reduce((s, c) => s + c.spent, 0),
            }))}
          />
          <div className="admin-card-head" style={{ marginTop: 20 }}><h2>Creator contribution</h2></div>
          {creators.map((c) => (
            <div key={c.handle} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderTop: '1px solid #eef1ea', fontSize: 12 }}>
              <span>{c.name}</span>
              <strong>{formatMoney(c.lifetimeEarnings)}</strong>
            </div>
          ))}
          <p className="admin-muted" style={{ marginTop: 12 }}>
            {inventory.filter((r) => r.onHand - r.reserved <= settings.lowStockThreshold).length} SKUs below reorder · {products.filter((p) => p.status === 'Active').length} live products
          </p>
        </section>
      </div>
    </div>
  );
}
