import { useMemo, useState } from 'react';
import { formatMoney, type DesignModerationStatus, type RewardRule } from '../../data/admin';
import { useAdmin } from '../AdminContext';
import { ConfirmDialog, Empty, PageHead, SearchField, Segmented, Skeleton, StatusBadge, Toggle } from '../AdminShared';

export function ModerationPage() {
  const { ready, moderation, moderateDesign } = useAdmin();
  const [filter, setFilter] = useState('Pending');
  const [q, setQ] = useState('');
  const [activeId, setActiveId] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [confirm, setConfirm] = useState<{ id: string; status: DesignModerationStatus } | null>(null);

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return moderation.filter((m) => {
      if (filter !== 'All' && m.status !== filter) return false;
      if (!needle) return true;
      return `${m.title} ${m.creatorName} ${m.category}`.toLowerCase().includes(needle);
    });
  }, [moderation, filter, q]);

  const active = moderation.find((m) => m.id === (activeId || list[0]?.id));

  if (!ready) return <Skeleton />;

  return (
    <div>
      <PageHead
        kicker="A08 / Review lane"
        title="Design moderation"
        copy="Approve, request changes or reject creator submissions. Previews are local — nothing is sent to print."
      />
      <div className="admin-toolbar">
        <SearchField value={q} onChange={setQ} placeholder="Title or creator…" />
        <Segmented options={['Pending', 'Needs changes', 'Approved', 'Rejected', 'All']} value={filter} onChange={setFilter} />
      </div>
      {list.length === 0 ? (
        <Empty title="Queue clear" copy="No submissions in this lane." />
      ) : (
        <div className="admin-split">
          <section className="admin-card" style={{ padding: 0 }}>
            {list.map((m) => (
              <button
                type="button"
                key={m.id}
                onClick={() => { setActiveId(m.id); setNotes(m.notes); }}
                className="admin-cell-product"
                style={{ width: '100%', padding: 12, borderBottom: '1px solid #eef1ea', background: active?.id === m.id ? '#e9edff' : 'transparent', textAlign: 'left' }}
              >
                <img src={m.artwork} alt="" style={{ objectFit: 'contain', background: '#151719' }} />
                <div style={{ flex: 1 }}>
                  <strong>{m.title}</strong>
                  <span>
                    {m.creatorName} · {m.category}
                  </span>
                </div>
                <StatusBadge status={m.status} />
              </button>
            ))}
          </section>
          {active && (
            <aside className="admin-card admin-sticky">
              <div className="admin-print-board" style={{ aspectRatio: '1', marginBottom: 14 }}>
                <img src={active.artwork} alt="" style={{ objectFit: 'contain', background: '#111' }} />
              </div>
              <h2 style={{ fontSize: 22 }}>{active.title}</h2>
              <p className="admin-muted" style={{ margin: '6px 0 12px' }}>
                {active.creatorName} · {active.productName} · {formatMoney(active.price)}
              </p>
              <p style={{ fontSize: 12 }}>Submitted {active.submittedAt}</p>
              <label style={{ marginTop: 14, display: 'block' }}>
                <span className="admin-muted">Moderator notes</span>
                <textarea className="admin-textarea" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Print-area, colour, rights…" />
              </label>
              <div className="admin-actions" style={{ justifyContent: 'flex-start', marginTop: 12 }}>
                <button type="button" className="admin-btn primary sm" onClick={() => setConfirm({ id: active.id, status: 'Approved' })}>
                  Approve
                </button>
                <button type="button" className="admin-btn ghost sm" onClick={() => moderateDesign(active.id, 'Needs changes', notes)}>
                  Request changes
                </button>
                <button type="button" className="admin-btn danger sm" onClick={() => setConfirm({ id: active.id, status: 'Rejected' })}>
                  Reject
                </button>
              </div>
              <div className="admin-timeline" style={{ marginTop: 20 }}>
                {active.history.map((h, i) => (
                  <div key={i}>
                    <i className={i === 0 ? 'on' : ''} />
                    <div>
                      <strong>{h.action}</strong>
                      <span>
                        {h.at} · {h.actor}
                      </span>
                      <span>{h.detail}</span>
                    </div>
                  </div>
                ))}
              </div>
            </aside>
          )}
        </div>
      )}
      <ConfirmDialog
        open={!!confirm}
        title={confirm?.status === 'Approved' ? 'Approve this design?' : 'Reject this design?'}
        copy={confirm?.status === 'Approved' ? 'It will appear as live in this admin ledger. No marketplace write is made.' : 'The creator will see a rejected status in this demo.'}
        confirmLabel={confirm?.status}
        danger={confirm?.status === 'Rejected'}
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          if (confirm) moderateDesign(confirm.id, confirm.status, notes);
          setConfirm(null);
        }}
      />
    </div>
  );
}

export function RewardsPage() {
  const { ready, rewardRules, rewardLedger, upsertRewardRule, deleteRewardRule, settings } = useAdmin();
  const [editing, setEditing] = useState<RewardRule | null>(null);
  const [pending, setPending] = useState<string | null>(null);

  if (!ready) return <Skeleton />;

  const form = editing || {
    id: `rw-${Date.now()}`,
    name: '',
    type: 'percentage' as const,
    value: settings.defaultRoyalty,
    appliesTo: 'all' as const,
    target: 'All marketplace designs',
    active: true,
    description: '',
  };

  return (
    <div>
      <PageHead
        kicker="A09 / Economics"
        title="Reward management"
        copy={`Default marketplace royalty is ${settings.defaultRoyalty}%. Configure percentage or fixed bonuses by product, category or creator level.`}
        actions={
          <button type="button" className="admin-btn primary" onClick={() => setEditing({
            id: `rw-${Date.now()}`,
            name: 'New rule',
            type: 'percentage',
            value: 15,
            appliesTo: 'all',
            target: 'All marketplace designs',
            active: true,
            description: '',
          })}>
            New rule
          </button>
        }
      />
      <div className="admin-split">
        <div>
          {rewardRules.map((r) => (
            <article key={r.id} className="admin-card" style={{ marginBottom: 12 }}>
              <div className="admin-card-head">
                <div>
                  <span>{r.appliesTo}</span>
                  <h2>{r.name}</h2>
                </div>
                <Toggle checked={r.active} onChange={(v) => upsertRewardRule({ ...r, active: v })} label={`Toggle ${r.name}`} />
              </div>
              <p style={{ fontSize: 28, letterSpacing: '-.04em' }}>
                {r.type === 'percentage' ? `${r.value}%` : formatMoney(r.value)}
              </p>
              <p className="admin-muted" style={{ margin: '8px 0 12px', lineHeight: 1.5 }}>
                {r.description} · {r.target}
              </p>
              <div className="admin-actions" style={{ justifyContent: 'flex-start' }}>
                <button type="button" className="admin-btn ghost sm" onClick={() => setEditing(r)}>Edit</button>
                <button type="button" className="admin-btn danger sm" onClick={() => setPending(r.id)}>Remove</button>
              </div>
            </article>
          ))}
        </div>
        <aside>
          <section className="admin-card" style={{ marginBottom: 14 }}>
            <div className="admin-card-head"><h2>{editing ? 'Edit rule' : 'Rule inspector'}</h2></div>
            <div className="admin-form">
              <label>Name<input className="admin-input" value={form.name} onChange={(e) => setEditing({ ...form, name: e.target.value })} /></label>
              <div className="admin-form-grid">
                <label>Type
                  <select className="admin-select" value={form.type} onChange={(e) => setEditing({ ...form, type: e.target.value as RewardRule['type'] })}>
                    <option value="percentage">Percentage</option>
                    <option value="fixed">Fixed USD</option>
                  </select>
                </label>
                <label>Value<input className="admin-input" type="number" value={form.value} onChange={(e) => setEditing({ ...form, value: Number(e.target.value) })} /></label>
              </div>
              <label>Applies to
                <select className="admin-select" value={form.appliesTo} onChange={(e) => setEditing({ ...form, appliesTo: e.target.value as RewardRule['appliesTo'] })}>
                  <option value="all">All designs</option>
                  <option value="product">Specific product</option>
                  <option value="category">Category</option>
                  <option value="creator-level">Creator level</option>
                </select>
              </label>
              <label>Target<input className="admin-input" value={form.target} onChange={(e) => setEditing({ ...form, target: e.target.value })} /></label>
              <label>Description<textarea className="admin-textarea" value={form.description} onChange={(e) => setEditing({ ...form, description: e.target.value })} /></label>
              <button type="button" className="admin-btn primary" onClick={() => { upsertRewardRule(form); setEditing(null); }}>Save rule</button>
            </div>
          </section>
          <section className="admin-card">
            <div className="admin-card-head"><h2>Creator ledger</h2></div>
            {rewardLedger.map((r) => (
              <div key={r.id} style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 8, padding: '8px 0', borderTop: '1px solid #eef1ea', fontSize: 12 }}>
                <div>
                  <strong>{r.creatorName}</strong>
                  <div className="admin-muted">{r.design} · {r.order}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <strong>{formatMoney(r.amount)}</strong>
                  <div><StatusBadge status={r.status} /></div>
                </div>
              </div>
            ))}
          </section>
        </aside>
      </div>
      <ConfirmDialog
        open={!!pending}
        title="Remove this reward rule?"
        copy="Existing accrued royalties in the ledger are not rewritten."
        danger
        confirmLabel="Remove"
        onCancel={() => setPending(null)}
        onConfirm={() => { if (pending) deleteRewardRule(pending); setPending(null); }}
      />
    </div>
  );
}

export function PayoutsPage() {
  const { ready, payouts, setPayoutStatus } = useAdmin();
  const [filter, setFilter] = useState('Pending');
  const [confirm, setConfirm] = useState<string | null>(null);

  const list = payouts.filter((p) => {
    if (filter === 'All') return true;
    if (filter === 'Pending') return p.status === 'Pending' || p.status === 'Processing';
    return p.status === filter;
  });
  const pendingSum = payouts.filter((p) => p.status === 'Pending' || p.status === 'Processing').reduce((s, p) => s + p.amount, 0);

  if (!ready) return <Skeleton />;

  return (
    <div>
      <PageHead
        kicker="A10 / Settlement"
        title="Payout management"
        copy={`${formatMoney(pendingSum)} currently queued. Presentation only — no money moves.`}
      />
      <div className="admin-kpis">
        <article className="admin-kpi"><header><span>Queued</span></header><strong>{formatMoney(pendingSum)}</strong><footer><span>Pending + processing</span></footer></article>
        <article className="admin-kpi"><header><span>Paid (demo)</span></header><strong>{formatMoney(payouts.filter((p) => p.status === 'Paid').reduce((s, p) => s + p.amount, 0))}</strong><footer><span>Oct–Nov</span></footer></article>
        <article className="admin-kpi"><header><span>Held</span></header><strong>{payouts.filter((p) => p.status === 'Held').length}</strong><footer><span>Chargeback window</span></footer></article>
        <article className="admin-kpi"><header><span>Requests</span></header><strong>{payouts.length}</strong><footer><span>All time in ledger</span></footer></article>
      </div>
      <div className="admin-toolbar">
        <Segmented options={['Pending', 'Paid', 'Held', 'All']} value={filter} onChange={setFilter} />
      </div>
      {list.length === 0 ? (
        <Empty title="Nothing in this lane" copy="Switch filter to see historical settlements." />
      ) : (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Creator</th>
                <th>Period</th>
                <th>Method</th>
                <th>Destination</th>
                <th>Sales</th>
                <th>Amount</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((p) => (
                <tr key={p.id}>
                  <td>
                    <strong>{p.creatorName}</strong>
                    <div className="admin-muted">{p.requestedAt}</div>
                  </td>
                  <td>{p.period}</td>
                  <td>{p.method}</td>
                  <td className="admin-mono">{p.destination}</td>
                  <td>{p.sales}</td>
                  <td>{formatMoney(p.amount)}</td>
                  <td><StatusBadge status={p.status} /></td>
                  <td>
                    {(p.status === 'Pending' || p.status === 'Processing') && (
                      <div className="admin-actions">
                        <button type="button" className="admin-btn primary sm" onClick={() => setConfirm(p.id)}>Mark paid</button>
                        <button type="button" className="admin-btn ghost sm" onClick={() => setPayoutStatus(p.id, 'Held', 'Held by operations')}>
                          Hold
                        </button>
                      </div>
                    )}
                    {p.notes && <div className="admin-muted">{p.notes}</div>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <ConfirmDialog
        open={!!confirm}
        title="Mark this payout as paid?"
        copy="Demo only. The creator balance is not actually transferred."
        confirmLabel="Mark paid"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          if (confirm) setPayoutStatus(confirm, 'Paid', 'Marked paid in admin console');
          setConfirm(null);
        }}
      />
    </div>
  );
}
