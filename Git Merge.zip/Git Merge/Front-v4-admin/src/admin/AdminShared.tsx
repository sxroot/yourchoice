import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangle, ChevronLeft, ChevronRight, Compass, Search, X } from 'lucide-react';

export function AdminKicker({ children }: { children: React.ReactNode }) {
  return <span className="admin-kicker">{children}</span>;
}

export function PageHead({
  kicker,
  title,
  copy,
  actions,
}: {
  kicker: string;
  title: string;
  copy?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="admin-page-head">
      <div>
        <AdminKicker>{kicker}</AdminKicker>
        <h1>{title}</h1>
        {copy && <p>{copy}</p>}
      </div>
      {actions && <div className="admin-head-actions">{actions}</div>}
    </div>
  );
}

export function Kpi({
  label,
  value,
  delta,
  bars,
  icon,
}: {
  label: string;
  value: string;
  delta?: string;
  bars?: number[];
  icon?: React.ReactNode;
}) {
  const up = delta?.startsWith('+');
  return (
    <article className="admin-kpi">
      <header>
        <span>{label}</span>
        {icon}
      </header>
      <strong>{value}</strong>
      <footer>
        {delta && <span className={up ? 'up' : delta.startsWith('-') ? 'down' : ''}>{delta}</span>}
        {bars && (
          <div className="admin-micro" aria-hidden="true">
            {bars.map((h, i) => (
              <i key={i} style={{ height: `${h}%` }} />
            ))}
          </div>
        )}
      </footer>
    </article>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const key = status.toLowerCase().replaceAll(' ', '-');
  return (
    <span className={`admin-pill st-${key}`}>
      <i />
      {status}
    </span>
  );
}

export function Avatar({ name, hue, src, size = 32 }: { name: string; hue?: number; src?: string; size?: number }) {
  const initials = name
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
  return (
    <span className="admin-avatar" style={{ width: size, height: size, background: `hsl(${hue ?? 220} 42% 38%)` }}>
      {src ? <img src={src} alt="" /> : initials}
    </span>
  );
}

export function AreaChart({ data, color = '#2349ed', labels }: { data: number[]; color?: string; labels?: string[] }) {
  const w = 640;
  const h = 180;
  const pad = 12;
  const max = Math.max(...data, 1);
  const pts = data.map((v, i) => {
    const x = pad + (i / Math.max(data.length - 1, 1)) * (w - pad * 2);
    const y = h - pad - (v / max) * (h - pad * 2);
    return [x, y] as const;
  });
  const line = pts.map((p) => p.join(',')).join(' ');
  const area = `M ${pad},${h - pad} L ${line} L ${w - pad},${h - pad} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="admin-chart" role="img" aria-label="Trend chart">
      <path d={area} fill={color} opacity="0.12" />
      <polyline points={line} fill="none" stroke={color} strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round" />
      {pts.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="3" fill={color} />
      ))}
      {labels &&
        labels.map((l, i) => (
          <text key={l} x={pts[i]?.[0] ?? 0} y={h - 1} textAnchor="middle" fontSize="9" fill="#7a8177" fontFamily="IBM Plex Mono, monospace">
            {l}
          </text>
        ))}
    </svg>
  );
}

export function BarChart({ data, color = '#2349ed' }: { data: { label: string; value: number }[]; color?: string }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  const w = 640;
  const h = 180;
  const gap = 10;
  const barW = (w - gap * (data.length + 1)) / data.length;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="admin-chart" role="img" aria-label="Bar chart">
      {data.map((d, i) => {
        const bh = (d.value / max) * 140;
        const x = gap + i * (barW + gap);
        const y = 150 - bh;
        return (
          <g key={d.label}>
            <rect x={x} y={y} width={barW} height={bh} fill={color} opacity={0.85} />
            <text x={x + barW / 2} y={168} textAnchor="middle" fontSize="8" fill="#7a8177" fontFamily="IBM Plex Mono, monospace">
              {d.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

export function SearchField({
  value,
  onChange,
  placeholder = 'Search',
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="admin-search">
      <Search size={15} color="#858d80" />
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
    </label>
  );
}

export function Segmented({
  options,
  value,
  onChange,
}: {
  options: string[];
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="admin-seg" role="tablist">
      {options.map((opt) => (
        <button key={opt} type="button" className={value === opt ? 'active' : ''} onClick={() => onChange(opt)}>
          {opt}
        </button>
      ))}
    </div>
  );
}

export function Empty({
  title,
  copy,
  action,
  icon,
}: {
  title: string;
  copy: string;
  action?: React.ReactNode;
  icon?: React.ReactNode;
}) {
  return (
    <div className="admin-empty">
      <span>{icon || <Compass size={28} />}</span>
      <h3>{title}</h3>
      <p>{copy}</p>
      {action}
    </div>
  );
}

export function Skeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="admin-skel" aria-hidden="true">
      {Array.from({ length: rows }).map((_, i) => (
        <i key={i} />
      ))}
    </div>
  );
}

export function Pagination({
  page,
  pages,
  onPage,
  total,
  pageSize,
}: {
  page: number;
  pages: number;
  onPage: (p: number) => void;
  total: number;
  pageSize: number;
}) {
  if (pages <= 1) return null;
  const start = (page - 1) * pageSize + 1;
  const end = Math.min(total, page * pageSize);
  const nums = Array.from({ length: pages }, (_, i) => i + 1).filter((n) => n === 1 || n === pages || Math.abs(n - page) <= 1);
  const withGaps: (number | 'gap')[] = [];
  nums.forEach((n, i) => {
    if (i && n - (nums[i - 1] as number) > 1) withGaps.push('gap');
    withGaps.push(n);
  });
  return (
    <div className="admin-pager">
      <span>
        {start}–{end} of {total}
      </span>
      <div>
        <button type="button" onClick={() => onPage(Math.max(1, page - 1))} disabled={page === 1} aria-label="Previous page">
          <ChevronLeft size={14} />
        </button>
        {withGaps.map((n, i) =>
          n === 'gap' ? (
            <span key={`g${i}`}>…</span>
          ) : (
            <button key={n} type="button" className={n === page ? 'active' : ''} onClick={() => onPage(n)}>
              {n}
            </button>
          ),
        )}
        <button type="button" onClick={() => onPage(Math.min(pages, page + 1))} disabled={page === pages} aria-label="Next page">
          <ChevronRight size={14} />
        </button>
      </div>
    </div>
  );
}

export function usePaged<T>(items: T[], pageSize = 8) {
  const [page, setPage] = useState(1);
  useEffect(() => setPage(1), [items, pageSize]);
  const pages = Math.max(1, Math.ceil(items.length / pageSize));
  const slice = useMemo(() => items.slice((page - 1) * pageSize, page * pageSize), [items, page, pageSize]);
  return { page, setPage, pages, slice, pageSize, total: items.length };
}

export function ConfirmDialog({
  open,
  title,
  copy,
  confirmLabel = 'Confirm',
  danger,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  title: string;
  copy: string;
  confirmLabel?: string;
  danger?: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCancel();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onCancel]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="admin-modal-back" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onCancel}>
          <motion.div
            className="admin-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="confirm-title"
            initial={{ y: 16, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 16, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
          >
            <AlertTriangle size={22} color={danger ? '#b23c31' : '#2349ed'} />
            <h2 id="confirm-title">{title}</h2>
            <p>{copy}</p>
            <div className="admin-modal-actions">
              <button type="button" className="admin-btn ghost sm" onClick={onCancel}>
                Cancel
              </button>
              <button type="button" className={`admin-btn sm ${danger ? 'danger' : 'primary'}`} onClick={onConfirm}>
                {confirmLabel}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function Drawer({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="admin-drawer-back" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
          <motion.aside
            className="admin-drawer"
            role="dialog"
            aria-modal="true"
            aria-label={title}
            initial={{ x: 40, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 40, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
          >
            <header>
              <div>
                <AdminKicker>Inspector</AdminKicker>
                <h2>{title}</h2>
              </div>
              <button type="button" className="admin-icon-tiny" onClick={onClose} aria-label="Close">
                <X size={16} />
              </button>
            </header>
            {children}
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} className={`admin-toggle ${checked ? 'is-on' : ''}`} onClick={() => onChange(!checked)}>
      <span />
    </button>
  );
}
