import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowLeft,
  Banknote,
  BarChart3,
  Bell,
  BookOpen,
  Box,
  LayoutDashboard,
  Layers,
  Menu,
  Package,
  Percent,
  Search,
  Settings,
  ShieldCheck,
  Shirt,
  Sparkles,
  Users,
  X,
} from 'lucide-react';
import { Wordmark } from '../components/BrandMarks';
import { ADMIN_NAV } from '../data/admin';
import { AdminProvider, useAdmin } from './AdminContext';
import './admin.css';

const ICONS: Record<string, ReactNode> = {
  layout: <LayoutDashboard size={16} />,
  chart: <BarChart3 size={16} />,
  shirt: <Shirt size={16} />,
  layers: <Layers size={16} />,
  book: <BookOpen size={16} />,
  box: <Box size={16} />,
  package: <Package size={16} />,
  users: <Users size={16} />,
  spark: <Sparkles size={16} />,
  shield: <ShieldCheck size={16} />,
  percent: <Percent size={16} />,
  bank: <Banknote size={16} />,
  settings: <Settings size={16} />,
};

const TITLES: Record<string, string> = {
  '/admin': 'Dashboard',
  '/admin/products': 'Products',
  '/admin/products/new': 'New product',
  '/admin/categories': 'Categories',
  '/admin/collections': 'Collections',
  '/admin/inventory': 'Inventory',
  '/admin/orders': 'Orders',
  '/admin/customers': 'Customers',
  '/admin/creators': 'Creators',
  '/admin/moderation': 'Design moderation',
  '/admin/rewards': 'Rewards',
  '/admin/payouts': 'Payouts',
  '/admin/content': 'Homepage content',
  '/admin/settings': 'Store settings',
  '/admin/reports': 'Reports & analytics',
};

export function AdminRoot() {
  return (
    <AdminProvider>
      <AdminLayout />
    </AdminProvider>
  );
}

export function AdminLayout() {
  const { toast, dismissToast, notifications, markNotificationRead, markAllNotificationsRead, moderation, payouts, inventory, settings } =
    useAdmin();
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifyOpen, setNotifyOpen] = useState(false);
  const [query, setQuery] = useState('');
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    setMenuOpen(false);
    setNotifyOpen(false);
  }, [location.pathname]);

  const pendingMod = moderation.filter((m) => m.status === 'Pending' || m.status === 'Needs changes').length;
  const pendingPay = payouts.filter((p) => p.status === 'Pending' || p.status === 'Processing').length;
  const lowStock = inventory.filter((r) => r.onHand - r.reserved <= (settings.lowStockThreshold || 8)).length;
  const unread = notifications.filter((n) => !n.read).length;

  const badges: Record<string, number> = {
    '/admin/moderation': pendingMod,
    '/admin/payouts': pendingPay,
    '/admin/inventory': lowStock,
  };

  const title =
    TITLES[location.pathname] ||
    (location.pathname.startsWith('/admin/products/')
      ? 'Edit product'
      : location.pathname.startsWith('/admin/orders/')
        ? 'Order details'
        : location.pathname.startsWith('/admin/customers/')
          ? 'Customer'
          : location.pathname.startsWith('/admin/creators/')
            ? 'Creator'
            : 'Admin');

  const jump = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return [];
    const routes = [
      { label: 'Dashboard', to: '/admin' },
      { label: 'Products', to: '/admin/products' },
      { label: 'New product', to: '/admin/products/new' },
      { label: 'Categories', to: '/admin/categories' },
      { label: 'Collections', to: '/admin/collections' },
      { label: 'Inventory', to: '/admin/inventory' },
      { label: 'Orders', to: '/admin/orders' },
      { label: 'Customers', to: '/admin/customers' },
      { label: 'Creators', to: '/admin/creators' },
      { label: 'Moderation', to: '/admin/moderation' },
      { label: 'Rewards', to: '/admin/rewards' },
      { label: 'Payouts', to: '/admin/payouts' },
      { label: 'Homepage', to: '/admin/content' },
      { label: 'Settings', to: '/admin/settings' },
      { label: 'Reports', to: '/admin/reports' },
    ];
    return routes.filter((r) => r.label.toLowerCase().includes(q)).slice(0, 6);
  }, [query]);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const first = jump[0];
    if (first) {
      navigate(first.to);
      setQuery('');
    } else if (query.trim()) {
      navigate(`/admin/products?q=${encodeURIComponent(query.trim())}`);
      setQuery('');
    }
  };

  return (
    <div className="admin-shell">
      <aside className={`admin-sidebar ${menuOpen ? 'is-open' : ''}`}>
        <div className="admin-brand">
          <Link to="/admin" aria-label="YOUR CHOICE admin home">
            <span className="admin-brand-mark">
              <img src="/images/official-emblem.webp" alt="" />
            </span>
            <Wordmark />
          </Link>
          <button type="button" onClick={() => setMenuOpen(false)} aria-label="Close menu">
            <X size={18} />
          </button>
        </div>
        <div className="admin-switcher">
          <span>
            <ShieldCheck size={16} />
          </span>
          <div>
            <small>YOUR CHOICE / OPS</small>
            <strong>Admin console</strong>
          </div>
        </div>
        <nav className="admin-nav" aria-label="Admin navigation">
          {ADMIN_NAV.map((group) => (
            <div key={group.label} className="admin-nav-group">
              <span>{group.label}</span>
              {group.items.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={'end' in item ? Boolean(item.end) : false}
                  className={({ isActive }) => (isActive ? 'active' : '')}
                  onClick={() => setMenuOpen(false)}
                >
                  {ICONS[item.icon]}
                  <span>{item.label}</span>
                  {badges[item.to] ? <b>{badges[item.to]}</b> : null}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="admin-sidebar-foot">
          <Link to="/">
            <ArrowLeft size={14} /> Back to storefront
          </Link>
          <div className="admin-member">
            <span>AC</span>
            <div>
              <strong>Avery Chen</strong>
              <small>Head of Operations</small>
            </div>
          </div>
        </div>
      </aside>
      {menuOpen && <button className="admin-scrim" aria-label="Close menu" onClick={() => setMenuOpen(false)} />}
      <div className="admin-main">
        <header className="admin-topbar">
          <button type="button" className="admin-menu-btn" onClick={() => setMenuOpen(true)} aria-label="Open menu">
            <Menu size={18} />
          </button>
          <div className="admin-topbar-title">
            <span>OPERATIONS / VOL. 01</span>
            <strong>{title}</strong>
          </div>
          <form className="admin-top-search" onSubmit={submitSearch}>
            <Search size={14} color="#858d80" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Jump to a workspace…"
              aria-label="Jump to admin page"
            />
            <kbd>/</kbd>
            {query.trim().length >= 2 && (
              <div className="admin-notify-pop" style={{ left: 0, right: 'auto', top: 42, width: '100%' }}>
                {jump.length === 0 ? (
                  <div className="admin-notify-item">No matching workspace</div>
                ) : (
                  jump.map((j) => (
                    <Link key={j.to} to={j.to} onClick={() => setQuery('')}>
                      <strong>{j.label}</strong>
                      <small>{j.to}</small>
                    </Link>
                  ))
                )}
              </div>
            )}
          </form>
          <div className="admin-top-actions">
            <div style={{ position: 'relative' }}>
              <button
                type="button"
                className="admin-icon-btn"
                aria-label="Notifications"
                onClick={() => setNotifyOpen((v) => !v)}
              >
                <Bell size={16} />
                {unread > 0 && <i />}
              </button>
              <AnimatePresence>
                {notifyOpen && (
                  <motion.div
                    className="admin-notify-pop"
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                  >
                    <header>
                      <span>Notifications</span>
                      <button type="button" onClick={markAllNotificationsRead}>
                        Mark all read
                      </button>
                    </header>
                    {notifications.map((n) => (
                      <Link
                        key={n.id}
                        to={n.href}
                        className={n.read ? '' : 'is-unread'}
                        onClick={() => markNotificationRead(n.id)}
                      >
                        <strong>{n.title}</strong>
                        <span>{n.body}</span>
                        <small>{n.at}</small>
                      </Link>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <Link to="/admin/products/new" className="admin-btn primary sm">
              New product
            </Link>
          </div>
        </header>
        <main className="admin-content">
          <Outlet />
        </main>
      </div>
      <AnimatePresence>
        {toast && (
          <motion.div className="admin-toast" role="status" initial={{ y: 12, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 12, opacity: 0 }}>
            <span>{toast}</span>
            <button type="button" onClick={dismissToast} aria-label="Dismiss">
              <X size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
