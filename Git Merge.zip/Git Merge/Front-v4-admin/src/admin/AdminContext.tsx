import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  seedActivity,
  seedApplications,
  seedCategories,
  seedCollections,
  seedContent,
  seedCreators,
  seedCustomers,
  seedInventory,
  seedModeration,
  seedNotifications,
  seedOrders,
  seedPayouts,
  seedProducts,
  seedRewardLedger,
  seedRewardRules,
  seedSettings,
  type ActivityItem,
  type AdminCategory,
  type AdminCollection,
  type AdminCreator,
  type AdminCustomer,
  type AdminNotification,
  type AdminOrder,
  type AdminProduct,
  type ContentBlock,
  type CreatorApplication,
  type DesignModerationStatus,
  type InventoryRow,
  type ModerationItem,
  type OrderOpsStatus,
  type PayoutRequest,
  type PayoutStatus,
  type RewardLedgerRow,
  type RewardRule,
  type StoreSettings,
} from '../data/admin';

const PREFIX = 'yc-admin-v1-';

function load<T>(key: string, fallback: () => T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    if (raw) return JSON.parse(raw) as T;
  } catch {
    /* ignore */
  }
  return fallback();
}

function save(key: string, value: unknown) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

interface AdminState {
  ready: boolean;
  toast: string;
  products: AdminProduct[];
  categories: AdminCategory[];
  collections: AdminCollection[];
  inventory: InventoryRow[];
  orders: AdminOrder[];
  customers: AdminCustomer[];
  creators: AdminCreator[];
  applications: CreatorApplication[];
  moderation: ModerationItem[];
  rewardRules: RewardRule[];
  rewardLedger: RewardLedgerRow[];
  payouts: PayoutRequest[];
  content: ContentBlock[];
  settings: StoreSettings;
  activity: ActivityItem[];
  notifications: AdminNotification[];
  pushToast: (message: string) => void;
  dismissToast: () => void;
  upsertProduct: (product: AdminProduct) => void;
  deleteProduct: (id: number) => void;
  setProductStatus: (id: number, status: AdminProduct['status']) => void;
  updateCategory: (id: string, patch: Partial<AdminCategory>) => void;
  addCategory: (cat: AdminCategory) => void;
  deleteCategory: (id: string) => void;
  updateCollection: (slug: string, patch: Partial<AdminCollection>) => void;
  setCollectionProducts: (slug: string, productIds: number[]) => void;
  updateInventory: (id: string, patch: Partial<InventoryRow>) => void;
  setOrderStatus: (id: string, status: OrderOpsStatus) => void;
  updateOrderNotes: (id: string, notes: string) => void;
  updateCustomer: (id: string, patch: Partial<AdminCustomer>) => void;
  updateCreator: (handle: string, patch: Partial<AdminCreator>) => void;
  setApplicationStatus: (id: string, status: CreatorApplication['status']) => void;
  moderateDesign: (id: string, status: DesignModerationStatus, notes?: string) => void;
  upsertRewardRule: (rule: RewardRule) => void;
  deleteRewardRule: (id: string) => void;
  setPayoutStatus: (id: string, status: PayoutStatus, notes?: string) => void;
  upsertContent: (block: ContentBlock) => void;
  deleteContent: (id: string) => void;
  updateSettings: (patch: Partial<StoreSettings>) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  resetDemo: () => void;
}

const AdminContext = createContext<AdminState | null>(null);

function logActivity(prev: ActivityItem[], verb: string, target: string, tone: ActivityItem['tone'] = 'blue'): ActivityItem[] {
  return [
    { id: `ac-${Date.now()}`, at: 'Just now', actor: 'Avery Chen', verb, target, tone },
    ...prev,
  ].slice(0, 24);
}

export function AdminProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [toast, setToast] = useState('');
  const [products, setProducts] = useState<AdminProduct[]>(() => load('products', seedProducts));
  const [categories, setCategories] = useState<AdminCategory[]>(() => load('categories', () => seedCategories(seedProducts())));
  const [collections, setCollections] = useState<AdminCollection[]>(() => load('collections', seedCollections));
  const [inventory, setInventory] = useState<InventoryRow[]>(() => load('inventory', () => seedInventory(seedProducts())));
  const [orders, setOrders] = useState<AdminOrder[]>(() => load('orders', seedOrders));
  const [customers, setCustomers] = useState<AdminCustomer[]>(() => load('customers', seedCustomers));
  const [creators, setCreators] = useState<AdminCreator[]>(() => load('creators', seedCreators));
  const [applications, setApplications] = useState<CreatorApplication[]>(() => load('applications', seedApplications));
  const [moderation, setModeration] = useState<ModerationItem[]>(() => load('moderation', seedModeration));
  const [rewardRules, setRewardRules] = useState<RewardRule[]>(() => load('rewards', seedRewardRules));
  const [rewardLedger, setRewardLedger] = useState<RewardLedgerRow[]>(() => load('ledger', seedRewardLedger));
  const [payouts, setPayouts] = useState<PayoutRequest[]>(() => load('payouts', seedPayouts));
  const [content, setContent] = useState<ContentBlock[]>(() => load('content', seedContent));
  const [settings, setSettings] = useState<StoreSettings>(() => load('settings', seedSettings));
  const [activity, setActivity] = useState<ActivityItem[]>(() => load('activity', seedActivity));
  const [notifications, setNotifications] = useState<AdminNotification[]>(() => load('notifications', seedNotifications));

  useEffect(() => {
    const t = window.setTimeout(() => setReady(true), 420);
    return () => window.clearTimeout(t);
  }, []);

  useEffect(() => save('products', products), [products]);
  useEffect(() => save('categories', categories), [categories]);
  useEffect(() => save('collections', collections), [collections]);
  useEffect(() => save('inventory', inventory), [inventory]);
  useEffect(() => save('orders', orders), [orders]);
  useEffect(() => save('customers', customers), [customers]);
  useEffect(() => save('creators', creators), [creators]);
  useEffect(() => save('applications', applications), [applications]);
  useEffect(() => save('moderation', moderation), [moderation]);
  useEffect(() => save('rewards', rewardRules), [rewardRules]);
  useEffect(() => save('ledger', rewardLedger), [rewardLedger]);
  useEffect(() => save('payouts', payouts), [payouts]);
  useEffect(() => save('content', content), [content]);
  useEffect(() => save('settings', settings), [settings]);
  useEffect(() => save('activity', activity), [activity]);
  useEffect(() => save('notifications', notifications), [notifications]);

  const pushToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 2600);
  }, []);
  const dismissToast = useCallback(() => setToast(''), []);

  const upsertProduct = useCallback((product: AdminProduct) => {
    setProducts((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      return exists ? prev.map((p) => (p.id === product.id ? product : p)) : [product, ...prev];
    });
    setInventory((prev) => {
      const others = prev.filter((r) => r.productId !== product.id);
      const next = product.sizes.map((size) => {
        const existing = prev.find((r) => r.productId === product.id && r.size === size);
        return (
          existing || {
            id: `${product.skuPrefix}-${size}`,
            productId: product.id,
            productName: product.name,
            image: product.image,
            sku: `${product.skuPrefix}-${product.color.slice(0, 3).toUpperCase()}-${size}`,
            size,
            color: product.color,
            onHand: product.stockBySize[size] ?? 0,
            reserved: 0,
            incoming: 0,
            reorderPoint: 8,
            warehouse: 'Porto Atelier',
          }
        );
      });
      return [...next, ...others];
    });
    setActivity((a) => logActivity(a, 'saved product', product.name, 'ok'));
    pushToast(`${product.name} saved.`);
  }, [pushToast]);

  const deleteProduct = useCallback((id: number) => {
    const name = products.find((p) => p.id === id)?.name || 'Product';
    setProducts((prev) => prev.filter((p) => p.id !== id));
    setInventory((prev) => prev.filter((r) => r.productId !== id));
    setActivity((a) => logActivity(a, 'archived', name, 'warn'));
    pushToast(`${name} removed from catalogue.`);
  }, [products, pushToast]);

  const setProductStatus = useCallback((id: number, status: AdminProduct['status']) => {
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, status } : p)));
    pushToast('Product status updated.');
  }, [pushToast]);

  const updateCategory = useCallback((id: string, patch: Partial<AdminCategory>) => {
    setCategories((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));
    pushToast('Category updated.');
  }, [pushToast]);

  const addCategory = useCallback((cat: AdminCategory) => {
    setCategories((prev) => [...prev, cat]);
    setActivity((a) => logActivity(a, 'created category', cat.name, 'blue'));
    pushToast(`${cat.name} added.`);
  }, [pushToast]);

  const deleteCategory = useCallback((id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
    pushToast('Category removed.');
  }, [pushToast]);

  const updateCollection = useCallback((slug: string, patch: Partial<AdminCollection>) => {
    setCollections((prev) => prev.map((c) => (c.slug === slug ? { ...c, ...patch } : c)));
    pushToast('Collection updated.');
  }, [pushToast]);

  const setCollectionProducts = useCallback((slug: string, productIds: number[]) => {
    setCollections((prev) => prev.map((c) => (c.slug === slug ? { ...c, productIds } : c)));
    pushToast('Collection merchandising saved.');
  }, [pushToast]);

  const updateInventory = useCallback((id: string, patch: Partial<InventoryRow>) => {
    setInventory((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
    if (typeof patch.onHand === 'number') {
      const row = inventory.find((r) => r.id === id);
      if (row) {
        setProducts((prev) =>
          prev.map((p) =>
            p.id === row.productId ? { ...p, stockBySize: { ...p.stockBySize, [row.size]: patch.onHand as number } } : p,
          ),
        );
      }
    }
    pushToast('Inventory adjusted.');
  }, [inventory, pushToast]);

  const setOrderStatus = useCallback((id: string, status: OrderOpsStatus) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== id) return o;
        const stepMap: Record<OrderOpsStatus, number> = {
          Confirmed: 1,
          Inspection: 2,
          Packed: 3,
          Dispatched: 4,
          'In Transit': 5,
          Delivered: 6,
          Cancelled: 1,
          Returned: 6,
        };
        const event: AdminOrder['events'][number] = {
          date: '17 Nov 2026',
          time: new Date().toISOString().slice(11, 16) + ' UTC',
          location: 'Operations console',
          status,
          detail: `Status moved to ${status} by Avery Chen.`,
        };
        return { ...o, status, statusStep: stepMap[status], events: [event, ...o.events] };
      }),
    );
    setActivity((a) => logActivity(a, `moved order to ${status}`, id.replace('ord-', ''), 'blue'));
    pushToast(`Order marked ${status}.`);
  }, [pushToast]);

  const updateOrderNotes = useCallback((id: string, notes: string) => {
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, notes } : o)));
    pushToast('Internal note saved.');
  }, [pushToast]);

  const updateCustomer = useCallback((id: string, patch: Partial<AdminCustomer>) => {
    setCustomers((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));
    pushToast('Customer record updated.');
  }, [pushToast]);

  const updateCreator = useCallback((handle: string, patch: Partial<AdminCreator>) => {
    setCreators((prev) => prev.map((c) => (c.handle === handle ? { ...c, ...patch } : c)));
    pushToast('Creator record updated.');
  }, [pushToast]);

  const setApplicationStatus = useCallback((id: string, status: CreatorApplication['status']) => {
    setApplications((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
    const app = applications.find((a) => a.id === id);
    setActivity((a) => logActivity(a, `${status.toLowerCase()} application`, app?.name || id, status === 'Approved' ? 'ok' : 'warn'));
    pushToast(`Application ${status.toLowerCase()}.`);
  }, [applications, pushToast]);

  const moderateDesign = useCallback((id: string, status: DesignModerationStatus, notes = '') => {
    setModeration((prev) =>
      prev.map((m) =>
        m.id === id
          ? {
              ...m,
              status,
              notes: notes || m.notes,
              history: [
                {
                  at: new Date().toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
                  actor: 'Avery Chen',
                  action: status,
                  detail: notes || `Marked ${status}.`,
                },
                ...m.history,
              ],
            }
          : m,
      ),
    );
    setActivity((a) => logActivity(a, status.toLowerCase(), 'design submission', status === 'Approved' ? 'ok' : 'warn'));
    pushToast(`Design ${status.toLowerCase()}.`);
  }, [pushToast]);

  const upsertRewardRule = useCallback((rule: RewardRule) => {
    setRewardRules((prev) => {
      const exists = prev.some((r) => r.id === rule.id);
      return exists ? prev.map((r) => (r.id === rule.id ? rule : r)) : [rule, ...prev];
    });
    pushToast('Reward rule saved.');
  }, [pushToast]);

  const deleteRewardRule = useCallback((id: string) => {
    setRewardRules((prev) => prev.filter((r) => r.id !== id));
    pushToast('Reward rule removed.');
  }, [pushToast]);

  const setPayoutStatus = useCallback((id: string, status: PayoutStatus, notes?: string) => {
    setPayouts((prev) => prev.map((p) => (p.id === id ? { ...p, status, notes: notes ?? p.notes } : p)));
    setActivity((a) => logActivity(a, `${status.toLowerCase()} payout`, id, status === 'Paid' ? 'ok' : 'cyan'));
    pushToast(`Payout ${status.toLowerCase()}.`);
  }, [pushToast]);

  const upsertContent = useCallback((block: ContentBlock) => {
    setContent((prev) => {
      const exists = prev.some((b) => b.id === block.id);
      return exists ? prev.map((b) => (b.id === block.id ? block : b)) : [...prev, block];
    });
    pushToast('Homepage block saved.');
  }, [pushToast]);

  const deleteContent = useCallback((id: string) => {
    setContent((prev) => prev.filter((b) => b.id !== id));
    pushToast('Block removed.');
  }, [pushToast]);

  const updateSettings = useCallback((patch: Partial<StoreSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
    pushToast('Store settings saved.');
  }, [pushToast]);

  const markNotificationRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const resetDemo = useCallback(() => {
    const p = seedProducts();
    setProducts(p);
    setCategories(seedCategories(p));
    setCollections(seedCollections());
    setInventory(seedInventory(p));
    setOrders(seedOrders());
    setCustomers(seedCustomers());
    setCreators(seedCreators());
    setApplications(seedApplications());
    setModeration(seedModeration());
    setRewardRules(seedRewardRules());
    setRewardLedger(seedRewardLedger());
    setPayouts(seedPayouts());
    setContent(seedContent());
    setSettings(seedSettings());
    setActivity(seedActivity());
    setNotifications(seedNotifications());
    Object.keys(localStorage)
      .filter((k) => k.startsWith(PREFIX))
      .forEach((k) => localStorage.removeItem(k));
    pushToast('Admin demo data restored.');
  }, [pushToast]);

  const value = useMemo<AdminState>(
    () => ({
      ready,
      toast,
      products,
      categories,
      collections,
      inventory,
      orders,
      customers,
      creators,
      applications,
      moderation,
      rewardRules,
      rewardLedger,
      payouts,
      content,
      settings,
      activity,
      notifications,
      pushToast,
      dismissToast,
      upsertProduct,
      deleteProduct,
      setProductStatus,
      updateCategory,
      addCategory,
      deleteCategory,
      updateCollection,
      setCollectionProducts,
      updateInventory,
      setOrderStatus,
      updateOrderNotes,
      updateCustomer,
      updateCreator,
      setApplicationStatus,
      moderateDesign,
      upsertRewardRule,
      deleteRewardRule,
      setPayoutStatus,
      upsertContent,
      deleteContent,
      updateSettings,
      markNotificationRead,
      markAllNotificationsRead,
      resetDemo,
    }),
    [
      ready, toast, products, categories, collections, inventory, orders, customers, creators, applications,
      moderation, rewardRules, rewardLedger, payouts, content, settings, activity, notifications,
      pushToast, dismissToast, upsertProduct, deleteProduct, setProductStatus, updateCategory, addCategory,
      deleteCategory, updateCollection, setCollectionProducts, updateInventory, setOrderStatus, updateOrderNotes,
      updateCustomer, updateCreator, setApplicationStatus, moderateDesign, upsertRewardRule, deleteRewardRule,
      setPayoutStatus, upsertContent, deleteContent, updateSettings, markNotificationRead, markAllNotificationsRead, resetDemo,
    ],
  );

  return <AdminContext.Provider value={value}>{children}</AdminContext.Provider>;
}

export function useAdmin() {
  const ctx = useContext(AdminContext);
  if (!ctx) throw new Error('useAdmin must be used within AdminProvider');
  return ctx;
}
