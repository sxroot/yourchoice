import { COLLECTIONS, PRODUCTS, SAMPLE_ORDERS, type CollectionItem, type Product } from './catalog';
import { CREATORS, MARKETPLACE_DESIGNS, type CreatorProfile, type MarketplaceDesign } from './phase2';

export type AdminProductStatus = 'Active' | 'Draft' | 'Archived';
export type OrderOpsStatus =
  | 'Confirmed'
  | 'Inspection'
  | 'Packed'
  | 'Dispatched'
  | 'In Transit'
  | 'Delivered'
  | 'Cancelled'
  | 'Returned';
export type DesignModerationStatus = 'Pending' | 'Approved' | 'Needs changes' | 'Rejected';
export type PayoutStatus = 'Pending' | 'Processing' | 'Paid' | 'Held';
export type CreatorApplicationStatus = 'Pending' | 'Approved' | 'Waitlisted' | 'Declined';
export type RewardType = 'percentage' | 'fixed';

export interface PrintArea {
  id: string;
  name: string;
  widthCm: number;
  heightCm: number;
  x: number;
  y: number;
  enabled: boolean;
}

export interface AdminProduct extends Product {
  status: AdminProductStatus;
  skuPrefix: string;
  cost: number;
  visible: boolean;
  stockBySize: Record<string, number>;
  printAreas: PrintArea[];
  taxable: boolean;
  allowCustom: boolean;
}

export interface AdminCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  productCount: number;
  featured: boolean;
  sortOrder: number;
  banner: string;
}

export interface AdminCollection extends CollectionItem {
  published: boolean;
  sortOrder: number;
  productIds: number[];
}

export interface InventoryRow {
  id: string;
  productId: number;
  productName: string;
  image: string;
  sku: string;
  size: string;
  color: string;
  onHand: number;
  reserved: number;
  incoming: number;
  reorderPoint: number;
  warehouse: string;
}

export interface AdminOrderItem {
  productId: number;
  slug: string;
  name: string;
  color: string;
  size: string;
  price: number;
  quantity: number;
  image: string;
  sku: string;
}

export interface AdminOrderEvent {
  date: string;
  time: string;
  location: string;
  status: string;
  detail: string;
}

export interface AdminOrder {
  id: string;
  orderNumber: string;
  placedAt: string;
  placedStamp: string;
  estimatedDelivery: string;
  status: OrderOpsStatus;
  statusStep: number;
  customerId: string;
  customerName: string;
  email: string;
  phone: string;
  shippingAddress: {
    line1: string;
    line2?: string;
    city: string;
    postalCode: string;
    country: string;
  };
  shippingMethod: string;
  carrier: string;
  trackingCode: string;
  paymentSummary: string;
  paymentStatus: 'Paid' | 'Pending' | 'Refunded' | 'Partial';
  subtotal: number;
  discount: number;
  shippingCost: number;
  packagingCost: number;
  tax: number;
  total: number;
  giftNote?: string;
  channel: 'Storefront' | 'Marketplace' | 'Studio';
  items: AdminOrderItem[];
  events: AdminOrderEvent[];
  notes: string;
}

export interface AdminCustomer {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  country: string;
  joined: string;
  orders: number;
  spent: number;
  segment: 'Inner Circle' | 'Creator' | 'Guest' | 'Wholesale';
  status: 'Active' | 'Paused' | 'Flagged';
  lastOrder: string;
  avatarHue: number;
  notes: string;
}

export interface AdminCreator extends CreatorProfile {
  status: 'Active' | 'Paused' | 'Suspended';
  level: number;
  pendingBalance: number;
  lifetimeEarnings: number;
  payoutMethod: string;
  payoutLast4: string;
  applicationStatus: CreatorApplicationStatus;
  designsLive: number;
}

export interface CreatorApplication {
  id: string;
  name: string;
  handle: string;
  email: string;
  location: string;
  specialty: string;
  statement: string;
  portfolio: string;
  submittedAt: string;
  status: CreatorApplicationStatus;
  avatar: string;
}

export interface ModerationItem {
  id: string;
  designId: string;
  title: string;
  creator: string;
  creatorName: string;
  artwork: string;
  category: string;
  submittedAt: string;
  status: DesignModerationStatus;
  notes: string;
  productName: string;
  price: number;
  history: { at: string; actor: string; action: string; detail: string }[];
}

export interface RewardRule {
  id: string;
  name: string;
  type: RewardType;
  value: number;
  appliesTo: 'all' | 'product' | 'category' | 'creator-level';
  target: string;
  active: boolean;
  description: string;
}

export interface RewardLedgerRow {
  id: string;
  date: string;
  creator: string;
  creatorName: string;
  design: string;
  order: string;
  type: string;
  amount: number;
  status: 'Accrued' | 'Paid' | 'Reversed';
}

export interface PayoutRequest {
  id: string;
  creator: string;
  creatorName: string;
  amount: number;
  method: string;
  destination: string;
  requestedAt: string;
  status: PayoutStatus;
  period: string;
  sales: number;
  notes: string;
}

export interface ContentBlock {
  id: string;
  slot: 'hero' | 'banner' | 'editorial' | 'collection' | 'ticker';
  title: string;
  kicker: string;
  body: string;
  cta: string;
  ctaHref: string;
  image: string;
  published: boolean;
  sortOrder: number;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  supportEmail: string;
  language: string;
  currency: string;
  timezone: string;
  taxInclusive: boolean;
  freeShippingThreshold: number;
  lowStockThreshold: number;
  defaultRoyalty: number;
  brandPrimary: string;
  brandCyan: string;
  shippingZones: { id: string; name: string; eta: string; rate: number; ddp: boolean }[];
  notifications: { id: string; label: string; description: string; enabled: boolean }[];
}

export interface ActivityItem {
  id: string;
  at: string;
  actor: string;
  verb: string;
  target: string;
  tone: 'blue' | 'cyan' | 'warn' | 'ok';
}

export interface AdminNotification {
  id: string;
  title: string;
  body: string;
  at: string;
  read: boolean;
  href: string;
}

export const formatMoney = (amount: number) =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: amount % 1 === 0 ? 0 : 2,
  }).format(amount);

export const formatCompact = (n: number) =>
  n >= 1000 ? `${(n / 1000).toFixed(n >= 10000 ? 0 : 1)}k` : String(n);

const defaultPrintAreas = (category: Product['category']): PrintArea[] => {
  const large = category === 'Essentials' || category === 'Outerwear';
  return [
    { id: 'front', name: 'Front chest', widthCm: large ? 30 : 28, heightCm: large ? 38 : 36, x: 50, y: 32, enabled: true },
    { id: 'back', name: 'Back panel', widthCm: large ? 32 : 30, heightCm: large ? 42 : 40, x: 50, y: 28, enabled: true },
    { id: 'left-chest', name: 'Left chest', widthCm: 10, heightCm: 10, x: 32, y: 28, enabled: category !== 'Polo Shirts' },
    { id: 'sleeve', name: 'Left sleeve', widthCm: 8, heightCm: 12, x: 12, y: 40, enabled: false },
  ];
};

export function seedProducts(): AdminProduct[] {
  return PRODUCTS.map((p) => {
    const stockBySize: Record<string, number> = {};
    p.sizes.forEach((size, i) => {
      const base = 18 + ((p.id * 7 + i * 5) % 46);
      stockBySize[size] = p.lowStockSizes?.includes(size) ? 3 + (p.id % 4) : base;
    });
    return {
      ...p,
      status: p.isNew ? 'Active' : p.badge === 'Studio Blank' ? 'Active' : 'Active',
      skuPrefix: `YC-${String(p.id).padStart(3, '0')}`,
      cost: Math.round(p.price * 0.37),
      visible: true,
      stockBySize,
      printAreas: defaultPrintAreas(p.category),
      taxable: true,
      allowCustom: p.badge === 'Studio Blank' || p.category === 'T-Shirts',
    };
  });
}

export function seedCategories(products: AdminProduct[]): AdminCategory[] {
  const banners: Record<string, string> = {
    'T-Shirts': '/images/collection-tees-hero.webp',
    'Polo Shirts': '/images/collection-polos-hero.webp',
    Essentials: '/images/hoodie.webp',
    Outerwear: '/images/jacket.webp',
  };
  const copy: Record<string, string> = {
    'T-Shirts': 'Architectural 295–320 GSM organic jersey. The daily uniform.',
    'Polo Shirts': 'Double-mercerized piqué, Johnny collars and half-zips.',
    Essentials: 'Heavy fleece hoodies and studio blanks for independent rotation.',
    Outerwear: 'Technical bombers and overshirts cut for layering.',
  };
  return (['T-Shirts', 'Polo Shirts', 'Essentials', 'Outerwear'] as const).map((name, i) => ({
    id: `cat-${i + 1}`,
    name,
    slug: name.toLowerCase().replace(/\s+/g, '-'),
    description: copy[name],
    productCount: products.filter((p) => p.category === name).length,
    featured: i < 3,
    sortOrder: i + 1,
    banner: banners[name],
  }));
}

export function seedCollections(): AdminCollection[] {
  return COLLECTIONS.map((c, i) => ({
    ...c,
    published: true,
    sortOrder: i + 1,
    productIds: PRODUCTS.filter((p) => p.collectionSlugs.includes(c.slug)).map((p) => p.id),
  }));
}

export function seedInventory(products: AdminProduct[]): InventoryRow[] {
  const rows: InventoryRow[] = [];
  products.forEach((p) => {
    p.sizes.forEach((size) => {
      const onHand = p.stockBySize[size] ?? 0;
      rows.push({
        id: `${p.skuPrefix}-${size}`,
        productId: p.id,
        productName: p.name,
        image: p.image,
        sku: `${p.skuPrefix}-${p.color.slice(0, 3).toUpperCase()}-${size}`,
        size,
        color: p.color,
        onHand,
        reserved: onHand > 10 ? Math.min(6, Math.floor(onHand / 8)) : onHand > 0 ? 1 : 0,
        incoming: p.lowStockSizes?.includes(size) ? 24 : 0,
        reorderPoint: 8,
        warehouse: p.origin.includes('Porto') ? 'Porto Atelier' : p.origin.includes('Barcelos') ? 'Barcelos Knit' : 'Northern Italy',
      });
    });
  });
  return rows;
}

const EXTRA_CUSTOMERS: AdminCustomer[] = [
  { id: 'cus-01', name: 'Alex Mercer', email: 'member@yourchoice.studio', phone: '+44 20 7946 0142', city: 'London', country: 'United Kingdom', joined: '12 Mar 2025', orders: 9, spent: 1486, segment: 'Inner Circle', status: 'Active', lastOrder: '16 Nov 2026', avatarHue: 220, notes: 'Prefers oversized L. Express shipping default.' },
  { id: 'cus-02', name: 'Sora Takahashi', email: 'sora.takahashi@studio.jp', phone: '+1 212 555 0194', city: 'New York', country: 'United States', joined: '04 Jun 2025', orders: 6, spent: 972, segment: 'Inner Circle', status: 'Active', lastOrder: '14 Nov 2026', avatarHue: 196, notes: 'Collects polo silhouettes. Gift packaging frequent.' },
  { id: 'cus-03', name: 'Leila Okonkwo', email: 'leila.okonkwo@andmore.co', phone: '+49 30 8876 221', city: 'Berlin', country: 'Germany', joined: '19 Jan 2026', orders: 4, spent: 512, segment: 'Guest', status: 'Active', lastOrder: '11 Nov 2026', avatarHue: 160, notes: '' },
  { id: 'cus-04', name: 'Jonah Reeve', email: 'jonah@reevestudio.com', phone: '+33 1 84 88 12 40', city: 'Paris', country: 'France', joined: '28 Aug 2025', orders: 11, spent: 2104, segment: 'Wholesale', status: 'Active', lastOrder: '09 Nov 2026', avatarHue: 18, notes: 'Atelier restock buyer. Net-15 terms on file.' },
  { id: 'cus-05', name: 'Mara Venn', email: 'studio@maravenn.com', phone: '+44 161 496 0288', city: 'London', country: 'United Kingdom', joined: '02 Mar 2025', orders: 7, spent: 844, segment: 'Creator', status: 'Active', lastOrder: '08 Nov 2026', avatarHue: 265, notes: 'Creator — botanical editions.' },
  { id: 'cus-06', name: 'Elena Voss', email: 'elena.voss@nightdesk.de', phone: '+31 20 244 0190', city: 'Amsterdam', country: 'Netherlands', joined: '15 Sep 2026', orders: 2, spent: 164, segment: 'Guest', status: 'Active', lastOrder: '03 Nov 2026', avatarHue: 40, notes: '' },
  { id: 'cus-07', name: 'Priya Raman', email: 'priya.raman@orbit.sg', phone: '+65 8123 4401', city: 'Singapore', country: 'Singapore', joined: '22 Apr 2026', orders: 5, spent: 688, segment: 'Inner Circle', status: 'Active', lastOrder: '12 Nov 2026', avatarHue: 200, notes: 'DDP Singapore. Prefers chalk palette.' },
  { id: 'cus-08', name: 'Mateo Cruz', email: 'mateo@cruzform.es', phone: '+34 91 374 2201', city: 'Madrid', country: 'Spain', joined: '07 Jul 2026', orders: 3, spent: 276, segment: 'Guest', status: 'Paused', lastOrder: '18 Oct 2026', avatarHue: 8, notes: 'Return on YC-2026-6120 — size exchange completed.' },
  { id: 'cus-09', name: 'Noah Oku', email: 'hello@noahoku.work', phone: '+44 161 234 8891', city: 'Manchester', country: 'United Kingdom', joined: '11 Aug 2025', orders: 8, spent: 1190, segment: 'Creator', status: 'Active', lastOrder: '16 Nov 2026', avatarHue: 230, notes: 'Creator — typography / wings.' },
  { id: 'cus-10', name: 'Hana Idris', email: 'hana.idris@atelier.ae', phone: '+971 4 437 1900', city: 'Dubai', country: 'United Arab Emirates', joined: '30 Oct 2025', orders: 4, spent: 540, segment: 'Inner Circle', status: 'Active', lastOrder: '05 Nov 2026', avatarHue: 280, notes: '' },
];

export function seedCustomers(): AdminCustomer[] {
  return EXTRA_CUSTOMERS;
}

const STATUS_FLOW: OrderOpsStatus[] = ['Confirmed', 'Inspection', 'Packed', 'Dispatched', 'In Transit', 'Delivered'];

function skuFor(productId: number, size: string, color: string) {
  return `YC-${String(productId).padStart(3, '0')}-${color.slice(0, 3).toUpperCase()}-${size}`;
}

export function seedOrders(): AdminOrder[] {
  const fromSample: AdminOrder[] = SAMPLE_ORDERS.slice(0, 4).map((o, i) => {
    const mappedStatus: OrderOpsStatus =
      o.statusStep >= 5 ? 'Delivered' : o.statusStep === 4 ? 'In Transit' : o.statusStep === 3 ? 'Dispatched' : o.statusStep === 2 ? 'Inspection' : 'Confirmed';
    const customer =
      EXTRA_CUSTOMERS.find((c) => c.email === o.email) || EXTRA_CUSTOMERS[i % EXTRA_CUSTOMERS.length];
    return {
      id: `ord-${o.orderNumber}`,
      orderNumber: o.orderNumber,
      placedAt: o.placedAt,
      placedStamp: o.placedAt.split('·')[0].trim(),
      estimatedDelivery: o.estimatedDelivery,
      status: mappedStatus,
      statusStep: o.statusStep,
      customerId: customer.id,
      customerName: o.customerName,
      email: o.email,
      phone: customer.phone,
      shippingAddress: o.shippingAddress,
      shippingMethod: o.shippingMethod,
      carrier: o.carrier,
      trackingCode: o.trackingCode,
      paymentSummary: o.paymentSummary,
      paymentStatus: 'Paid' as const,
      subtotal: o.subtotal,
      discount: o.discount,
      shippingCost: o.shippingCost,
      packagingCost: o.packagingCost,
      tax: 0,
      total: o.total,
      giftNote: o.giftNote,
      channel: i === 1 ? 'Marketplace' : 'Storefront',
      items: o.items.map((it) => ({
        ...it,
        sku: skuFor(it.productId, it.size, it.color),
      })),
      events: o.events,
      notes: '',
    };
  });

  const extras: AdminOrder[] = [
    {
      id: 'ord-YC-2026-9102',
      orderNumber: 'YC-2026-9102',
      placedAt: '17 Nov 2026 · 09:42 UTC',
      placedStamp: '17 Nov 2026',
      estimatedDelivery: '20 – 21 Nov 2026',
      status: 'Inspection',
      statusStep: 2,
      customerId: 'cus-07',
      customerName: 'Priya Raman',
      email: 'priya.raman@orbit.sg',
      phone: '+65 8123 4401',
      shippingAddress: { line1: '88 Club Street, #04-02', city: 'Singapore', postalCode: '069460', country: 'Singapore' },
      shippingMethod: 'Express Air Courier (2–3 Business Days)',
      carrier: 'DHL Express Carbon-Neutral',
      trackingCode: 'Pending allocation',
      paymentSummary: 'Mastercard •••• 3319',
      paymentStatus: 'Paid',
      subtotal: 132,
      discount: 0,
      shippingCost: 0,
      packagingCost: 8,
      tax: 0,
      total: 140,
      channel: 'Storefront',
      items: [
        { productId: 7, slug: 'chalk-mock-neck-tee', name: 'Chalk Studio Mock-Neck Tee', color: 'Warm Chalk', size: 'M', price: 48, quantity: 1, image: '/images/tee-chalk.webp', sku: skuFor(7, 'M', 'Warm Chalk') },
        { productId: 14, slug: 'atelier-edition-blank-tee', name: 'Atelier 320GSM Creator Blank Tee', color: 'Bone White', size: 'M', price: 44, quantity: 2, image: '/images/tee-chalk.webp', sku: skuFor(14, 'M', 'Bone White') },
      ],
      events: [
        { date: '17 Nov 2026', time: '10:05 UTC', location: 'Porto Atelier, PT', status: 'Quality inspection', detail: 'Garments pulled from chalk / bone bins. Measurement verification in progress.' },
        { date: '17 Nov 2026', time: '09:42 UTC', location: 'YOUR CHOICE Digital Storefront', status: 'Order Confirmed', detail: 'Paid in full. Collector box requested.' },
      ],
      notes: 'Collector box + handwritten card.',
    },
    {
      id: 'ord-YC-2026-9028',
      orderNumber: 'YC-2026-9028',
      placedAt: '16 Nov 2026 · 21:11 UTC',
      placedStamp: '16 Nov 2026',
      estimatedDelivery: '19 Nov 2026',
      status: 'Packed',
      statusStep: 3,
      customerId: 'cus-03',
      customerName: 'Leila Okonkwo',
      email: 'leila.okonkwo@andmore.co',
      phone: '+49 30 8876 221',
      shippingAddress: { line1: 'Köpenicker Str. 70', city: 'Berlin', postalCode: '10179', country: 'Germany' },
      shippingMethod: 'Standard Tracked (3–5 Business Days)',
      carrier: 'DHL Express Carbon-Neutral',
      trackingCode: 'DHL-110294883-YC',
      paymentSummary: 'Klarna · 4 parts',
      paymentStatus: 'Paid',
      subtotal: 78,
      discount: 0,
      shippingCost: 12,
      packagingCost: 0,
      tax: 0,
      total: 90,
      channel: 'Marketplace',
      items: [
        { productId: 5, slug: 'royal-johnny-collar-polo', name: 'Royal Tipped Johnny Polo', color: 'Royal Blue', size: 'S', price: 78, quantity: 1, image: '/images/polo-blue.webp', sku: skuFor(5, 'S', 'Royal Blue') },
      ],
      events: [
        { date: '17 Nov 2026', time: '08:20 UTC', location: 'Porto Atelier, PT', status: 'Packed', detail: 'Sealed in recycled dust bag. Awaiting evening courier sweep.' },
        { date: '16 Nov 2026', time: '21:11 UTC', location: 'Marketplace', status: 'Order Confirmed', detail: 'Marketplace drop — Signal Terrain companion polo.' },
      ],
      notes: '',
    },
    {
      id: 'ord-YC-2026-8890',
      orderNumber: 'YC-2026-8890',
      placedAt: '13 Nov 2026 · 16:04 UTC',
      placedStamp: '13 Nov 2026',
      estimatedDelivery: 'Delivered 16 Nov',
      status: 'Delivered',
      statusStep: 6,
      customerId: 'cus-04',
      customerName: 'Jonah Reeve',
      email: 'jonah@reevestudio.com',
      phone: '+33 1 84 88 12 40',
      shippingAddress: { line1: '14 Rue des Archives', city: 'Paris', postalCode: '75004', country: 'France' },
      shippingMethod: 'Express Air Courier (2–3 Business Days)',
      carrier: 'UPS Premier Studio Direct',
      trackingCode: '1Z999YC55102911',
      paymentSummary: 'Visa •••• 7712',
      paymentStatus: 'Paid',
      subtotal: 348,
      discount: 35,
      shippingCost: 0,
      packagingCost: 0,
      tax: 0,
      total: 313,
      channel: 'Storefront',
      items: [
        { productId: 3, slug: 'silver-state-bomber', name: 'Silver State Bomber', color: 'Liquid Silver', size: 'L', price: 145, quantity: 1, image: '/images/jacket.webp', sku: skuFor(3, 'L', 'Liquid Silver') },
        { productId: 1, slug: 'expression-zip-hoodie', name: 'Expression Zip Hoodie', color: 'Charcoal', size: 'L', price: 88, quantity: 1, image: '/images/hoodie.webp', sku: skuFor(1, 'L', 'Charcoal') },
        { productId: 11, slug: 'cobalt-architectural-longsleeve', name: 'Cobalt Architectural Long-Sleeve Tee', color: 'Cobalt Navy', size: 'L', price: 58, quantity: 2, image: '/images/tee-longsleeve.webp', sku: skuFor(11, 'L', 'Cobalt Navy') },
      ],
      events: [
        { date: '16 Nov 2026', time: '11:40 CET', location: 'Paris 4e', status: 'Delivered', detail: 'Signed for by J. Reeve. Photo on file.' },
        { date: '15 Nov 2026', time: '19:12 CET', location: 'Charles de Gaulle HUB', status: 'In Transit', detail: 'Out for morning delivery window.' },
        { date: '13 Nov 2026', time: '16:04 UTC', location: 'Storefront', status: 'Order Confirmed', detail: 'Wholesale restock — 10% atelier courtesy applied.' },
      ],
      notes: 'Wholesale courtesy 10%.',
    },
    {
      id: 'ord-YC-2026-8714',
      orderNumber: 'YC-2026-8714',
      placedAt: '10 Nov 2026 · 12:28 UTC',
      placedStamp: '10 Nov 2026',
      estimatedDelivery: '—',
      status: 'Returned',
      statusStep: 6,
      customerId: 'cus-08',
      customerName: 'Mateo Cruz',
      email: 'mateo@cruzform.es',
      phone: '+34 91 374 2201',
      shippingAddress: { line1: 'Calle de Piamonte 23', city: 'Madrid', postalCode: '28004', country: 'Spain' },
      shippingMethod: 'Standard Tracked (3–5 Business Days)',
      carrier: 'Correos Express',
      trackingCode: 'CX-44019283-YC',
      paymentSummary: 'Apple Pay •••• 1044',
      paymentStatus: 'Refunded',
      subtotal: 76,
      discount: 0,
      shippingCost: 12,
      packagingCost: 0,
      tax: 0,
      total: 88,
      channel: 'Storefront',
      items: [
        { productId: 12, slug: 'mineral-waffle-polo', name: 'Mineral Open-Collar Waffle Polo', color: 'Stone Olive', size: 'M', price: 76, quantity: 1, image: '/images/polo-olive.webp', sku: skuFor(12, 'M', 'Stone Olive') },
      ],
      events: [
        { date: '16 Nov 2026', time: '09:00 UTC', location: 'Porto Atelier, PT', status: 'Refund released', detail: 'Quality verified. Original tender refunded in 48h window.' },
        { date: '14 Nov 2026', time: '15:22 CET', location: 'Madrid', status: 'Return received', detail: 'Unworn, tags intact. Size exchange requested then cancelled by customer.' },
        { date: '10 Nov 2026', time: '12:28 UTC', location: 'Storefront', status: 'Order Confirmed', detail: 'Original sale.' },
      ],
      notes: 'RMA-4419 closed.',
    },
    {
      id: 'ord-YC-2026-8601',
      orderNumber: 'YC-2026-8601',
      placedAt: '08 Nov 2026 · 18:55 UTC',
      placedStamp: '08 Nov 2026',
      estimatedDelivery: 'Hold — awaiting reprint',
      status: 'Cancelled',
      statusStep: 1,
      customerId: 'cus-06',
      customerName: 'Elena Voss',
      email: 'elena.voss@nightdesk.de',
      phone: '+31 20 244 0190',
      shippingAddress: { line1: 'Prinsengracht 412', city: 'Amsterdam', postalCode: '1016 JC', country: 'Netherlands' },
      shippingMethod: 'Express Air Courier (2–3 Business Days)',
      carrier: '—',
      trackingCode: '—',
      paymentSummary: 'iDEAL',
      paymentStatus: 'Refunded',
      subtotal: 56,
      discount: 0,
      shippingCost: 12,
      packagingCost: 0,
      tax: 0,
      total: 68,
      channel: 'Marketplace',
      items: [
        { productId: 2, slug: 'signature-blue-tee', name: 'Signature Blue Tee', color: 'Royal Blue', size: 'XS', price: 42, quantity: 1, image: '/images/tee.webp', sku: skuFor(2, 'XS', 'Royal Blue') },
      ],
      events: [
        { date: '08 Nov 2026', time: '19:40 UTC', location: 'Operations', status: 'Cancelled', detail: 'Customer cancelled within 60-minute modification window. Full refund issued.' },
        { date: '08 Nov 2026', time: '18:55 UTC', location: 'Marketplace', status: 'Order Confirmed', detail: 'Night Bloom Study on Signature Blue Tee.' },
      ],
      notes: 'Cancelled inside SLA.',
    },
    {
      id: 'ord-YC-2026-8519',
      orderNumber: 'YC-2026-8519',
      placedAt: '05 Nov 2026 · 07:16 UTC',
      placedStamp: '05 Nov 2026',
      estimatedDelivery: 'Delivered 08 Nov',
      status: 'Delivered',
      statusStep: 6,
      customerId: 'cus-10',
      customerName: 'Hana Idris',
      email: 'hana.idris@atelier.ae',
      phone: '+971 4 437 1900',
      shippingAddress: { line1: 'Alserkal Avenue, Warehouse 89', city: 'Dubai', postalCode: '00000', country: 'United Arab Emirates' },
      shippingMethod: 'Priority Express Air',
      carrier: 'Emirates SkyCargo Studio',
      trackingCode: 'EK-YC-229184',
      paymentSummary: 'Amex •••• 1003',
      paymentStatus: 'Paid',
      subtotal: 162,
      discount: 0,
      shippingCost: 0,
      packagingCost: 8,
      tax: 0,
      total: 170,
      channel: 'Studio',
      items: [
        { productId: 15, slug: 'studio-heavy-fleece-hoodie', name: 'Studio Heavyweight Fleece Hoodie', color: 'Obsidian / Blue Tab', size: 'M', price: 94, quantity: 1, image: '/images/hoodie.webp', sku: skuFor(15, 'M', 'Obsidian') },
        { productId: 8, slug: 'alabaster-half-zip-polo', name: 'Alabaster Merino Half-Zip Polo', color: 'Warm Chalk', size: 'M', price: 86, quantity: 1, image: '/images/polo-chalk.webp', sku: skuFor(8, 'M', 'Warm Chalk') },
      ],
      events: [
        { date: '08 Nov 2026', time: '14:02 GST', location: 'Alserkal Avenue', status: 'Delivered', detail: 'Received at warehouse reception.' },
        { date: '05 Nov 2026', time: '07:16 UTC', location: 'Design Studio', status: 'Order Confirmed', detail: 'Custom studio print — Afterlight left-chest.' },
      ],
      notes: 'Studio custom. Print-ready file on submission d05.',
    },
  ];

  return [...fromSample, ...extras];
}

export function seedCreators(): AdminCreator[] {
  const extras = [
    { pendingBalance: 214.8, lifetimeEarnings: 18440, payoutMethod: 'Wise · GBP', payoutLast4: '4412', level: 3, designsLive: 2 },
    { pendingBalance: 156.2, lifetimeEarnings: 12880, payoutMethod: 'PayPal', payoutLast4: '8821', level: 3, designsLive: 2 },
    { pendingBalance: 312.4, lifetimeEarnings: 22190, payoutMethod: 'Wise · EUR', payoutLast4: '0194', level: 4, designsLive: 2 },
    { pendingBalance: 88.1, lifetimeEarnings: 6420, payoutMethod: 'Bank transfer · USD', payoutLast4: '7730', level: 2, designsLive: 2 },
  ];
  return CREATORS.map((c, i) => ({
    ...c,
    status: c.verified ? 'Active' : 'Active',
    applicationStatus: 'Approved' as const,
    ...extras[i],
  }));
}

export function seedApplications(): CreatorApplication[] {
  return [
    {
      id: 'app-01',
      name: 'Ivy Calder',
      handle: 'ivy-calder',
      email: 'ivy@calderpress.studio',
      location: 'Lisbon, PT',
      specialty: 'Risograph / editorial',
      statement: 'I want to put small-press colour on architectural blanks — editions of 40, numbered, then gone.',
      portfolio: 'calderpress.studio',
      submittedAt: '15 Nov 2026',
      status: 'Pending',
      avatar: '/creators/creator-designer.jpg',
    },
    {
      id: 'app-02',
      name: 'Kenji Mori',
      handle: 'kenji-mori',
      email: 'km@voidgrid.jp',
      location: 'Osaka, JP',
      specialty: 'Grid systems / type',
      statement: 'Civic letterforms, railway diagrams, and the quiet violence of a perfect grid.',
      portfolio: 'voidgrid.jp',
      submittedAt: '12 Nov 2026',
      status: 'Pending',
      avatar: '/creators/creator-artist.jpg',
    },
    {
      id: 'app-03',
      name: 'Amina Diop',
      handle: 'amina-diop',
      email: 'hello@aminadiop.work',
      location: 'Dakar, SN',
      specialty: 'Textile / indigo',
      statement: 'Contemporary indigo resist translated for 320 GSM jersey. Heritage, not costume.',
      portfolio: 'aminadiop.work',
      submittedAt: '02 Nov 2026',
      status: 'Waitlisted',
      avatar: '/creators/creator-streetwear.jpg',
    },
  ];
}

export function seedModeration(): ModerationItem[] {
  const pending: ModerationItem[] = [
    {
      id: 'mod-p1',
      designId: 'd-pending-1',
      title: 'Harbour Grid 04',
      creator: 'ivy-calder',
      creatorName: 'Ivy Calder',
      artwork: '/art/signal-terrain.png',
      category: 'Graphics',
      submittedAt: '16 Nov 2026 · 19:04',
      status: 'Pending',
      notes: '',
      productName: 'Signature Box Tee',
      price: 54,
      history: [{ at: '16 Nov 2026 19:04', actor: 'Ivy Calder', action: 'Submitted', detail: 'Front print, 32 × 40 cm, cobalt on chalk.' }],
    },
    {
      id: 'mod-p2',
      designId: 'd-pending-2',
      title: 'Night Indigo Field',
      creator: 'amina-diop',
      creatorName: 'Amina Diop',
      artwork: '/art/cobalt-bloom.png',
      category: 'Botanical',
      submittedAt: '14 Nov 2026 · 11:22',
      status: 'Pending',
      notes: '',
      productName: 'Atelier Piqué Polo',
      price: 68,
      history: [{ at: '14 Nov 2026 11:22', actor: 'Amina Diop', action: 'Submitted', detail: 'Chest placement. Waiting on colour-separation proof.' }],
    },
    {
      id: 'mod-p3',
      designId: 'd-pending-3',
      title: 'Osaka Transit Mark',
      creator: 'kenji-mori',
      creatorName: 'Kenji Mori',
      artwork: '/art/chrome-wings.png',
      category: 'Typography',
      submittedAt: '13 Nov 2026 · 08:40',
      status: 'Needs changes',
      notes: 'Reduce shoulder collision on XL. Provide 300dpi vector.',
      productName: 'Expression Hoodie',
      price: 96,
      history: [
        { at: '15 Nov 2026 10:12', actor: 'Avery Chen', action: 'Requested changes', detail: 'Print area overflow on XL hood drape. Please inset 12mm.' },
        { at: '13 Nov 2026 08:40', actor: 'Kenji Mori', action: 'Submitted', detail: 'Full-front metallic mark.' },
      ],
    },
  ];
  const live: ModerationItem[] = MARKETPLACE_DESIGNS.map((d) => ({
    id: `mod-${d.id}`,
    designId: d.id,
    title: d.title,
    creator: d.creator,
    creatorName: CREATORS.find((c) => c.handle === d.creator)?.name || d.creator,
    artwork: d.artwork,
    category: d.category,
    submittedAt: d.publishedAt,
    status: 'Approved' as const,
    notes: '',
    productName: PRODUCTS.find((p) => p.id === d.productId)?.name || 'Atelier blank',
    price: d.price,
    history: [{ at: d.publishedAt, actor: 'Moderation', action: 'Approved', detail: 'Live on marketplace.' }],
  }));
  return [...pending, ...live];
}

export function seedRewardRules(): RewardRule[] {
  return [
    { id: 'rw-01', name: 'Marketplace default royalty', type: 'percentage', value: 15, appliesTo: 'all', target: 'All marketplace designs', active: true, description: 'Standard creator share on every marketplace sale after garment cost.' },
    { id: 'rw-02', name: 'Level 4 accelerator', type: 'percentage', value: 18, appliesTo: 'creator-level', target: 'Level 4+', active: true, description: 'Sora Kline tier. Additional 3 points on cleared sales.' },
    { id: 'rw-03', name: 'Heavy fleece bonus', type: 'fixed', value: 6.5, appliesTo: 'category', target: 'Essentials', active: true, description: 'Flat bonus per hoodie / fleece unit sold with a live design.' },
    { id: 'rw-04', name: 'Signal Terrain hero', type: 'percentage', value: 20, appliesTo: 'product', target: 'signal-terrain-01', active: true, description: 'Limited hero-rate on the Vol. 01 featured drop.' },
    { id: 'rw-05', name: 'First 100 units', type: 'fixed', value: 4, appliesTo: 'all', target: 'New design launch', active: false, description: 'Launch incentive. Currently paused pending Q4 budget.' },
  ];
}

export function seedRewardLedger(): RewardLedgerRow[] {
  return [
    { id: 'rl-01', date: '17 Nov 2026', creator: 'sora-kline', creatorName: 'Sora Kline', design: 'Signal Terrain 01', order: 'YC-92741', type: 'Royalty 20%', amount: 24.8, status: 'Accrued' },
    { id: 'rl-02', date: '16 Nov 2026', creator: 'noah-oku', creatorName: 'Noah Oku', design: 'Afterlight Wings', order: 'YC-92688', type: 'Royalty 15%', amount: 8.7, status: 'Accrued' },
    { id: 'rl-03', date: '15 Nov 2026', creator: 'sora-kline', creatorName: 'Sora Kline', design: 'Signal Terrain 01', order: 'YC-92517', type: 'Royalty 20%', amount: 12.4, status: 'Paid' },
    { id: 'rl-04', date: '14 Nov 2026', creator: 'sora-kline', creatorName: 'Sora Kline', design: 'Contour Memory', order: 'YC-92390', type: 'Royalty 15%', amount: 26.4, status: 'Paid' },
    { id: 'rl-05', date: '12 Nov 2026', creator: 'mara-venn', creatorName: 'Mara Venn', design: 'Blue Hour Botanical', order: 'YC-92116', type: 'Royalty 15%', amount: 8.1, status: 'Paid' },
    { id: 'rl-06', date: '10 Nov 2026', creator: 'eli-morrow', creatorName: 'Eli Morrow', design: 'Zero Orbit', order: 'YC-91842', type: 'Royalty 15%', amount: 8.4, status: 'Paid' },
    { id: 'rl-07', date: '08 Nov 2026', creator: 'sora-kline', creatorName: 'Sora Kline', design: 'Signal Terrain 01', order: 'YC-91603', type: 'Hero 20%', amount: 37.2, status: 'Paid' },
    { id: 'rl-08', date: '06 Nov 2026', creator: 'sora-kline', creatorName: 'Sora Kline', design: 'Contour Memory', order: 'YC-91318', type: 'Royalty 15%', amount: 13.2, status: 'Reversed' },
  ];
}

export function seedPayouts(): PayoutRequest[] {
  return [
    { id: 'po-01', creator: 'sora-kline', creatorName: 'Sora Kline', amount: 312.4, method: 'Wise · EUR', destination: '•••• 0194 · DE89 **** 4412', requestedAt: '17 Nov 2026', status: 'Pending', period: '01–17 Nov 2026', sales: 14, notes: '' },
    { id: 'po-02', creator: 'mara-venn', creatorName: 'Mara Venn', amount: 214.8, method: 'Wise · GBP', destination: '•••• 4412 · GB29 **** 2201', requestedAt: '16 Nov 2026', status: 'Pending', period: '01–16 Nov 2026', sales: 9, notes: '' },
    { id: 'po-03', creator: 'noah-oku', creatorName: 'Noah Oku', amount: 156.2, method: 'PayPal', destination: 'hello@noahoku.work', requestedAt: '15 Nov 2026', status: 'Processing', period: '01–15 Nov 2026', sales: 7, notes: 'Held 24h for PayPal verification.' },
    { id: 'po-04', creator: 'eli-morrow', creatorName: 'Eli Morrow', amount: 88.1, method: 'ACH · USD', destination: '•••• 7730 · Chase', requestedAt: '12 Nov 2026', status: 'Paid', period: 'Oct 2026', sales: 5, notes: 'Cleared 14 Nov.' },
    { id: 'po-05', creator: 'sora-kline', creatorName: 'Sora Kline', amount: 640.0, method: 'Wise · EUR', destination: '•••• 0194', requestedAt: '31 Oct 2026', status: 'Paid', period: 'Oct 2026', sales: 28, notes: '' },
    { id: 'po-06', creator: 'mara-venn', creatorName: 'Mara Venn', amount: 410.5, method: 'Wise · GBP', destination: '•••• 4412', requestedAt: '31 Oct 2026', status: 'Paid', period: 'Oct 2026', sales: 18, notes: '' },
    { id: 'po-07', creator: 'noah-oku', creatorName: 'Noah Oku', amount: 190.0, method: 'PayPal', destination: 'hello@noahoku.work', requestedAt: '28 Oct 2026', status: 'Held', period: 'Oct 2026', sales: 6, notes: 'Chargeback review on YC-91318 companion — released after 7 days if clean.' },
  ];
}

export function seedContent(): ContentBlock[] {
  return [
    { id: 'cb-01', slot: 'hero', title: 'Independent by Design.', kicker: 'VOL. 01 — EXPRESSION', body: 'Not for everyone. For you. Architectural essentials in YC Royal, obsidian and chalk.', cta: 'Explore the catalogue', ctaHref: '/shop', image: '/images/campaign.webp', published: true, sortOrder: 1 },
    { id: 'cb-02', slot: 'ticker', title: 'Design it. Wear it. Earn from it.', kicker: 'STUDIO', body: 'A dedicated creative platform on 320 GSM Atelier blanks.', cta: 'Enter Studio', ctaHref: '/studio', image: '', published: true, sortOrder: 2 },
    { id: 'cb-03', slot: 'banner', title: 'Polo Shirt Collection', kicker: 'CHAPTER 02', body: 'Double-mercerized piqué, Johnny collars, half-zips. Structured, not stiff.', cta: 'Shop polos', ctaHref: '/collections/polo-shirts', image: '/images/collection-polos-hero.webp', published: true, sortOrder: 3 },
    { id: 'cb-04', slot: 'editorial', title: 'The Expression Collection', kicker: 'ESSAY', body: 'Uniforms usually ask you to disappear. We built the opposite — a modular wardrobe that sharpens presence.', cta: 'Read the chapter', ctaHref: '/collections/expression-vol-01', image: '/images/editorial.webp', published: true, sortOrder: 4 },
    { id: 'cb-05', slot: 'collection', title: 'T-Shirt Architecture', kicker: '295–320 GSM', body: 'High-recovery collars, sculptural drape, compact-spun organic yarns.', cta: 'Shop tees', ctaHref: '/collections/t-shirts', image: '/images/collection-tees-hero.webp', published: true, sortOrder: 5 },
    { id: 'cb-06', slot: 'banner', title: 'Creator Marketplace', kicker: 'LIVE', body: 'Independent marks on Atelier blanks. Royalties on every piece.', cta: 'Explore designs', ctaHref: '/marketplace', image: '/art/chrome-wings.png', published: false, sortOrder: 6 },
  ];
}

export function seedSettings(): StoreSettings {
  return {
    storeName: 'YOUR CHOICE',
    tagline: 'Independent by Design.',
    supportEmail: 'concierge@yourchoice.studio',
    language: 'en',
    currency: 'USD',
    timezone: 'Europe/Lisbon',
    taxInclusive: true,
    freeShippingThreshold: 150,
    lowStockThreshold: 8,
    defaultRoyalty: 15,
    brandPrimary: '#2349ed',
    brandCyan: '#57dbf3',
    shippingZones: [
      { id: 'z-eu', name: 'European Union', eta: '2–4 business days', rate: 0, ddp: true },
      { id: 'z-uk', name: 'United Kingdom', eta: '1–3 business days', rate: 0, ddp: true },
      { id: 'z-us', name: 'United States & Canada', eta: '3–5 business days', rate: 0, ddp: true },
      { id: 'z-mena', name: 'Gulf & Singapore', eta: '3–5 business days', rate: 18, ddp: true },
      { id: 'z-row', name: 'Rest of world', eta: '5–8 business days', rate: 28, ddp: false },
    ],
    notifications: [
      { id: 'n-orders', label: 'New order alerts', description: 'Ping operations when a paid order lands.', enabled: true },
      { id: 'n-low', label: 'Low-stock warnings', description: 'Daily digest when a SKU crosses the reorder point.', enabled: true },
      { id: 'n-mod', label: 'Design moderation queue', description: 'Notify when a creator submits work for review.', enabled: true },
      { id: 'n-pay', label: 'Payout requests', description: 'Alert finance when a creator requests settlement.', enabled: true },
      { id: 'n-app', label: 'Creator applications', description: 'Weekly roundup of pending applications.', enabled: false },
    ],
  };
}

export function seedActivity(): ActivityItem[] {
  return [
    { id: 'ac-01', at: '4 min ago', actor: 'System', verb: 'captured', target: 'YC-2026-9102 · Priya Raman · $140', tone: 'blue' },
    { id: 'ac-02', at: '22 min ago', actor: 'Ivy Calder', verb: 'submitted', target: 'Harbour Grid 04 for moderation', tone: 'cyan' },
    { id: 'ac-03', at: '1 hr ago', actor: 'Sora Kline', verb: 'requested payout', target: '$312.40 · Wise EUR', tone: 'warn' },
    { id: 'ac-04', at: '2 hr ago', actor: 'Porto Atelier', verb: 'packed', target: 'YC-2026-9028 · Johnny Polo / S', tone: 'ok' },
    { id: 'ac-05', at: '3 hr ago', actor: 'Avery Chen', verb: 'requested changes on', target: 'Osaka Transit Mark · XL overflow', tone: 'warn' },
    { id: 'ac-06', at: '5 hr ago', actor: 'DHL', verb: 'departed hub with', target: 'YC-2026-8841 · Leipzig → STN', tone: 'blue' },
    { id: 'ac-07', at: 'Yesterday', actor: 'Finance', verb: 'released refund for', target: 'YC-2026-8714 · RMA-4419', tone: 'ok' },
    { id: 'ac-08', at: 'Yesterday', actor: 'Kenji Mori', verb: 'applied as creator', target: 'voidgrid.jp · Grid systems', tone: 'cyan' },
  ];
}

export function seedNotifications(): AdminNotification[] {
  return [
    { id: 'nt-01', title: '3 designs awaiting review', body: 'Harbour Grid 04, Night Indigo Field and Osaka Transit Mark.', at: '12 min ago', read: false, href: '/admin/moderation' },
    { id: 'nt-02', title: 'Low stock · Expression Zip Hoodie XS', body: 'On-hand has crossed the reorder point of 8.', at: '40 min ago', read: false, href: '/admin/inventory' },
    { id: 'nt-03', title: 'Payout queue · $683.40 pending', body: 'Sora Kline and Mara Venn are waiting on settlement.', at: '1 hr ago', read: false, href: '/admin/payouts' },
    { id: 'nt-04', title: 'YC-2026-9102 entered inspection', body: 'Priya Raman · Collector box requested.', at: '2 hr ago', read: true, href: '/admin/orders/ord-YC-2026-9102' },
    { id: 'nt-05', title: 'Weekly creator applications', body: 'Ivy Calder and Kenji Mori are in the pending lane.', at: 'Yesterday', read: true, href: '/admin/creators' },
  ];
}

export const REVENUE_SERIES = [18400, 21240, 19880, 24110, 22640, 26890, 25420, 30110, 28740, 33480, 31220, 36890];
export const ORDERS_SERIES = [42, 48, 45, 61, 54, 70, 66, 79, 74, 88, 81, 96];
export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export const ADMIN_NAV = [
  {
    label: 'Overview',
    items: [
      { to: '/admin', label: 'Dashboard', end: true, icon: 'layout' },
      { to: '/admin/reports', label: 'Reports', icon: 'chart' },
    ],
  },
  {
    label: 'Catalogue',
    items: [
      { to: '/admin/products', label: 'Products', icon: 'shirt' },
      { to: '/admin/categories', label: 'Categories', icon: 'layers' },
      { to: '/admin/collections', label: 'Collections', icon: 'book' },
      { to: '/admin/inventory', label: 'Inventory', icon: 'box' },
    ],
  },
  {
    label: 'Commerce',
    items: [
      { to: '/admin/orders', label: 'Orders', icon: 'package' },
      { to: '/admin/customers', label: 'Customers', icon: 'users' },
    ],
  },
  {
    label: 'Creators',
    items: [
      { to: '/admin/creators', label: 'Creators', icon: 'spark' },
      { to: '/admin/moderation', label: 'Moderation', icon: 'shield' },
      { to: '/admin/rewards', label: 'Rewards', icon: 'percent' },
      { to: '/admin/payouts', label: 'Payouts', icon: 'bank' },
    ],
  },
  {
    label: 'House',
    items: [
      { to: '/admin/content', label: 'Homepage', icon: 'layout' },
      { to: '/admin/settings', label: 'Store settings', icon: 'settings' },
    ],
  },
] as const;

export function orderStepIndex(status: OrderOpsStatus) {
  const i = STATUS_FLOW.indexOf(status);
  return i === -1 ? (status === 'Cancelled' || status === 'Returned' ? 0 : 1) : i + 1;
}

export { STATUS_FLOW };
export type { MarketplaceDesign, CreatorProfile };
