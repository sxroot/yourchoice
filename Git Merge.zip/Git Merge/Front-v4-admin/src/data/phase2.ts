export type DesignCategory = 'Graphics' | 'Typography' | 'Abstract' | 'Botanical' | 'Streetwear' | 'Minimal';

export interface CreatorProfile {
  handle: string;
  name: string;
  location: string;
  avatar: string;
  cover: string;
  role: string;
  bio: string;
  statement: string;
  followers: number;
  following: number;
  totalSales: number;
  rating: number;
  joined: string;
  verified: boolean;
  specialties: string[];
  social: string;
}

export interface MarketplaceDesign {
  id: string;
  slug: string;
  title: string;
  creator: string;
  category: DesignCategory;
  artwork: string;
  productId: number;
  garmentColor: string;
  colorName: string;
  price: number;
  royalty: number;
  likes: number;
  sales: number;
  views: number;
  featured: boolean;
  trending: boolean;
  publishedAt: string;
  description: string;
  story: string;
  tags: string[];
  palette: string[];
  placement: { x: number; y: number; scale: number; rotation: number };
}

export const CREATORS: CreatorProfile[] = [
  {
    handle: 'mara-venn', name: 'Mara Venn', location: 'London, UK', avatar: '/creators/creator-portraits.jpg', cover: '/images/editorial.webp',
    role: 'Image maker & textile artist',
    bio: 'Building nocturnal worlds through saturated colour, organic forms and deliberate imperfection.',
    statement: 'I treat every garment as a moving print — something that changes with the person inside it.',
    followers: 12840, following: 184, totalSales: 2841, rating: 4.9, joined: 'March 2025', verified: true,
    specialties: ['Screen print', 'Botanical', 'Mixed media'], social: '@maravenn.studio',
  },
  {
    handle: 'noah-oku', name: 'Noah Oku', location: 'Manchester, UK', avatar: '/creators/creator-designer.jpg', cover: '/images/campaign.webp',
    role: 'Graphic designer & typographer',
    bio: 'Independent graphic practice exploring civic symbols, distorted grids and the visual language of movement.',
    statement: 'A strong graphic should feel inevitable from across the street and reward you when you get close.',
    followers: 9210, following: 96, totalSales: 1934, rating: 4.8, joined: 'August 2025', verified: true,
    specialties: ['Typography', 'Identity', 'Geometry'], social: '@noahoku.work',
  },
  {
    handle: 'sora-kline', name: 'Sora Kline', location: 'Berlin, DE', avatar: '/creators/creator-artist.jpg', cover: '/images/collection-tees-hero.webp',
    role: 'Digital artist & creative coder',
    bio: 'Turning field recordings, terrain data and natural systems into vivid, wearable signals.',
    statement: 'The work starts as data, but it only becomes alive when somebody chooses to wear it.',
    followers: 15302, following: 211, totalSales: 3208, rating: 5, joined: 'January 2025', verified: true,
    specialties: ['Generative art', 'Data', 'Gradients'], social: '@sora.signals',
  },
  {
    handle: 'eli-morrow', name: 'Eli Morrow', location: 'New York, US', avatar: '/creators/creator-streetwear.jpg', cover: '/images/collection-polos-hero.webp',
    role: 'Collage artist & night walker',
    bio: 'Photocopied astronomy, downtown ephemera and hand-cut forms composed after midnight.',
    statement: 'Imperfection is not a filter. It is the fingerprint of making something yourself.',
    followers: 6740, following: 305, totalSales: 1187, rating: 4.7, joined: 'November 2025', verified: false,
    specialties: ['Collage', 'Photocopy', 'Astronomy'], social: '@elimorrow.nyc',
  },
];

export const MARKETPLACE_DESIGNS: MarketplaceDesign[] = [
  {
    id: 'd01', slug: 'afterlight-wings', title: 'Afterlight Wings', creator: 'noah-oku', category: 'Streetwear', artwork: '/art/chrome-wings.png', productId: 2,
    garmentColor: '#17191c', colorName: 'Obsidian', price: 58, royalty: 8.7, likes: 1842, sales: 438, views: 24800, featured: true, trending: true,
    publishedAt: '08 Nov 2026', description: 'Liquid-metal wings cut with a cobalt afterimage. A study in independence, symmetry and forward motion.',
    story: 'Afterlight began as a series of ink gestures photographed under moving light. The final composition keeps the speed of those original marks while introducing a precise, almost architectural centre.',
    tags: ['chrome', 'wings', 'night', 'statement'], palette: ['#17191c', '#2349ed', '#a9c5ff'], placement: { x: 198, y: 190, scale: 0.94, rotation: 0 },
  },
  {
    id: 'd02', slug: 'blue-hour-botanical', title: 'Blue Hour Botanical', creator: 'mara-venn', category: 'Botanical', artwork: '/art/cobalt-bloom.png', productId: 3,
    garmentColor: '#ebe9df', colorName: 'Warm Chalk', price: 54, royalty: 8.1, likes: 1327, sales: 306, views: 18420, featured: true, trending: true,
    publishedAt: '02 Nov 2026', description: 'An impossible flower drawn at the moment daylight gives way to electric blue.',
    story: 'Mara pressed found petals into wet cobalt ink, then redrew their shadows from memory. The halftone edge is intentional: a record of pressure, paper and touch translated for garment printing.',
    tags: ['flower', 'cobalt', 'organic', 'halftone'], palette: ['#ebe9df', '#2349ed', '#57dbf3'], placement: { x: 220, y: 164, scale: 0.9, rotation: -4 },
  },
  {
    id: 'd03', slug: 'zero-orbit', title: 'Zero Orbit', creator: 'eli-morrow', category: 'Abstract', artwork: '/art/solar-eclipse.png', productId: 2,
    garmentColor: '#5b604f', colorName: 'Stone Olive', price: 56, royalty: 8.4, likes: 986, sales: 217, views: 13110, featured: false, trending: true,
    publishedAt: '29 Oct 2026', description: 'A vermilion eclipse with the raw edge of a late-night photocopy.',
    story: 'The source image is a hand-cut orange disc repeatedly copied until its edge broke apart. Zero Orbit is about finding a quiet centre inside noise.',
    tags: ['eclipse', 'orange', 'collage', 'cosmic'], palette: ['#5b604f', '#f04e2f', '#111214'], placement: { x: 218, y: 182, scale: 0.9, rotation: 3 },
  },
  {
    id: 'd04', slug: 'signal-terrain-01', title: 'Signal Terrain 01', creator: 'sora-kline', category: 'Graphics', artwork: '/art/signal-terrain.png', productId: 4,
    garmentColor: '#2349ed', colorName: 'YC Royal', price: 62, royalty: 9.3, likes: 2210, sales: 512, views: 31200, featured: true, trending: true,
    publishedAt: '12 Nov 2026', description: 'A topography generated from forty-eight hours of city sound. Wear the frequency.',
    story: 'Sora mapped ambient recordings from Berlin train platforms into contour lines. Peaks become crowds; quiet intervals become open space. Each line belongs to a real moment.',
    tags: ['generative', 'cyan', 'terrain', 'data'], palette: ['#2349ed', '#57dbf3', '#d9fbff'], placement: { x: 210, y: 174, scale: 0.94, rotation: 0 },
  },
  {
    id: 'd05', slug: 'freedom-in-metal', title: 'Freedom in Metal', creator: 'noah-oku', category: 'Minimal', artwork: '/art/chrome-wings.png', productId: 1,
    garmentColor: '#edece6', colorName: 'Studio White', price: 104, royalty: 15.6, likes: 714, sales: 129, views: 8910, featured: false, trending: false,
    publishedAt: '19 Oct 2026', description: 'The Afterlight mark reduced to a quiet left-chest placement on heavyweight fleece.',
    story: 'A more restrained reading of Noah’s wing study, scaled for the chest and separated from the noise of a full-front print.',
    tags: ['small print', 'chrome', 'hoodie', 'quiet'], palette: ['#edece6', '#17191c', '#2349ed'], placement: { x: 298, y: 205, scale: 0.44, rotation: 0 },
  },
  {
    id: 'd06', slug: 'night-bloom-study', title: 'Night Bloom Study', creator: 'mara-venn', category: 'Botanical', artwork: '/art/cobalt-bloom.png', productId: 2,
    garmentColor: '#151719', colorName: 'Soft Black', price: 56, royalty: 8.4, likes: 1104, sales: 265, views: 15480, featured: true, trending: false,
    publishedAt: '24 Oct 2026', description: 'Cobalt petals surface from soft black jersey in an oversized, off-centre composition.',
    story: 'A darker companion to Blue Hour Botanical. This edition crops closer to the stem and lets the flower break the conventional print boundary.',
    tags: ['botanical', 'black tee', 'oversized', 'blue'], palette: ['#151719', '#2349ed', '#57dbf3'], placement: { x: 190, y: 158, scale: 1.08, rotation: 6 },
  },
  {
    id: 'd07', slug: 'umbra-club', title: 'Umbra Club', creator: 'eli-morrow', category: 'Streetwear', artwork: '/art/solar-eclipse.png', productId: 2,
    garmentColor: '#edece6', colorName: 'Natural', price: 52, royalty: 7.8, likes: 832, sales: 184, views: 11045, featured: false, trending: false,
    publishedAt: '16 Oct 2026', description: 'An open invitation to the imaginary society of people who look up.',
    story: 'Eli’s eclipse mark is placed with the directness of a DIY club shirt: one colour story, no explanation, plenty of attitude.',
    tags: ['club', 'eclipse', 'natural', 'DIY'], palette: ['#edece6', '#f04e2f', '#17191c'], placement: { x: 218, y: 186, scale: 0.85, rotation: -3 },
  },
  {
    id: 'd08', slug: 'contour-memory', title: 'Contour Memory', creator: 'sora-kline', category: 'Abstract', artwork: '/art/signal-terrain.png', productId: 4,
    garmentColor: '#1b1d20', colorName: 'Midnight', price: 88, royalty: 13.2, likes: 1580, sales: 339, views: 20760, featured: true, trending: false,
    publishedAt: '06 Oct 2026', description: 'Fine cyan contours wrap a midnight piqué surface like a remembered landscape.',
    story: 'A second data drawing from the Signal Terrain sessions, composed specifically for the texture and structure of a knitted polo.',
    tags: ['polo', 'contour', 'cyan', 'knit'], palette: ['#1b1d20', '#57dbf3', '#2349ed'], placement: { x: 215, y: 172, scale: 0.88, rotation: 0 },
  },
];

export interface SaleRecord {
  id: string;
  date: string;
  designId: string;
  order: string;
  product: string;
  territory: string;
  quantity: number;
  gross: number;
  royalty: number;
  status: 'Cleared' | 'Pending' | 'Returned';
}

export const CREATOR_SALES: SaleRecord[] = [
  { id: 's01', date: '17 Nov 2026', designId: 'd04', order: 'YC-92741', product: 'Atelier Piqué Polo', territory: 'United Kingdom', quantity: 2, gross: 124, royalty: 18.6, status: 'Pending' },
  { id: 's02', date: '16 Nov 2026', designId: 'd01', order: 'YC-92688', product: 'Signature Box Tee', territory: 'Germany', quantity: 1, gross: 58, royalty: 8.7, status: 'Pending' },
  { id: 's03', date: '15 Nov 2026', designId: 'd04', order: 'YC-92517', product: 'Atelier Piqué Polo', territory: 'United States', quantity: 1, gross: 62, royalty: 9.3, status: 'Cleared' },
  { id: 's04', date: '14 Nov 2026', designId: 'd08', order: 'YC-92390', product: 'Midnight Knit Polo', territory: 'France', quantity: 2, gross: 176, royalty: 26.4, status: 'Cleared' },
  { id: 's05', date: '12 Nov 2026', designId: 'd04', order: 'YC-92116', product: 'Atelier Piqué Polo', territory: 'Japan', quantity: 1, gross: 62, royalty: 9.3, status: 'Cleared' },
  { id: 's06', date: '10 Nov 2026', designId: 'd08', order: 'YC-91842', product: 'Midnight Knit Polo', territory: 'Netherlands', quantity: 1, gross: 88, royalty: 13.2, status: 'Cleared' },
  { id: 's07', date: '08 Nov 2026', designId: 'd04', order: 'YC-91603', product: 'Atelier Piqué Polo', territory: 'United Kingdom', quantity: 3, gross: 186, royalty: 27.9, status: 'Cleared' },
  { id: 's08', date: '06 Nov 2026', designId: 'd08', order: 'YC-91318', product: 'Midnight Knit Polo', territory: 'Canada', quantity: 1, gross: 88, royalty: 13.2, status: 'Returned' },
  { id: 's09', date: '03 Nov 2026', designId: 'd04', order: 'YC-90942', product: 'Atelier Piqué Polo', territory: 'Spain', quantity: 2, gross: 124, royalty: 18.6, status: 'Cleared' },
  { id: 's10', date: '31 Oct 2026', designId: 'd08', order: 'YC-90551', product: 'Midnight Knit Polo', territory: 'United States', quantity: 1, gross: 88, royalty: 13.2, status: 'Cleared' },
  { id: 's11', date: '28 Oct 2026', designId: 'd04', order: 'YC-90120', product: 'Atelier Piqué Polo', territory: 'United Arab Emirates', quantity: 1, gross: 62, royalty: 9.3, status: 'Cleared' },
  { id: 's12', date: '24 Oct 2026', designId: 'd08', order: 'YC-89770', product: 'Midnight Knit Polo', territory: 'United Kingdom', quantity: 2, gross: 176, royalty: 26.4, status: 'Cleared' },
];

export const STUDIO_PRODUCTS = [
  { id: 2, slug: 'signature-box-tee', name: 'Signature Box Tee', type: 'T-Shirt', price: 42, image: '/images/tee-chalk.webp', fit: 'Oversized / drop shoulder', material: '310 GSM organic cotton jersey', print: 'Front & back · up to 32 × 40 cm', colors: ['#edece6', '#18191b', '#2349ed', '#555b4e', '#b9b4a7', '#a9b8c8'] },
  { id: 4, slug: 'atelier-pique-polo', name: 'Atelier Piqué Polo', type: 'Polo', price: 74, image: '/images/polo-chalk.webp', fit: 'Structured / open collar', material: '280 GSM organic cotton piqué', print: 'Chest & back · up to 28 × 36 cm', colors: ['#edece6', '#17191c', '#2349ed', '#4f594c', '#8f9dad'] },
  { id: 1, slug: 'expression-hoodie', name: 'Expression Hoodie', type: 'Hoodie', price: 88, image: '/images/hoodie.webp', fit: 'Oversized / double hood', material: '480 GSM brushed organic fleece', print: 'Front & back · up to 30 × 38 cm', colors: ['#1c1d20', '#e6e3d9', '#2349ed', '#626b58'] },
  { id: 6, slug: 'atelier-long-sleeve', name: 'Atelier Long Sleeve', type: 'Long Sleeve', price: 52, image: '/images/tee-longsleeve.webp', fit: 'Relaxed / extended cuff', material: '300 GSM combed cotton jersey', print: 'Front, back & sleeves', colors: ['#edece6', '#18191b', '#2349ed', '#6a7065'] },
];

export const PHASE2_GROUPS = ['Customer', 'Marketplace', 'Creator Studio', 'Design Studio'] as const;
export interface Phase2RouteEntry { number: string; title: string; path: string; group: typeof PHASE2_GROUPS[number]; note: string }

export const PHASE2_PAGES: Phase2RouteEntry[] = [
  { number: 'C01', title: 'Customer Dashboard', path: '/account', group: 'Customer', note: 'Order pulse, saved work, wishlist and account shortcuts' },
  { number: 'C02', title: 'Profile Management', path: '/account/profile', group: 'Customer', note: 'Editable identity, fit profile and preferences' },
  { number: 'C03', title: 'Address Book', path: '/account/addresses', group: 'Customer', note: 'Add, edit, remove and set a default delivery address' },
  { number: 'C04', title: 'Order History', path: '/account/orders', group: 'Customer', note: 'Searchable and filterable local order archive' },
  { number: 'C05', title: 'Order Details', path: '/account/orders/YC-2026-8841', group: 'Customer', note: 'Item manifest, delivery timeline, totals and reorder' },
  { number: 'C06', title: 'Saved Designs', path: '/account/designs', group: 'Customer', note: 'Resume, duplicate or remove locally saved studio projects' },
  { number: 'C07', title: 'Wishlist Overview', path: '/account/wishlist', group: 'Customer', note: 'Products and marketplace artwork in one curation board' },
  { number: 'C08', title: 'Account Settings', path: '/account/settings', group: 'Customer', note: 'Notifications, privacy, local data export and session controls' },
  { number: 'M01', title: 'Marketplace Landing', path: '/marketplace', group: 'Marketplace', note: 'Featured art, trending drop, categories and creator stories' },
  { number: 'M02', title: 'Explore Designs', path: '/marketplace/explore', group: 'Marketplace', note: 'Live search, filters, sorting and saved artwork' },
  { number: 'M03', title: 'Design Categories', path: '/marketplace/categories', group: 'Marketplace', note: 'Six authored creative territories with live design counts' },
  { number: 'M04', title: 'Design Details', path: '/marketplace/design/afterlight-wings', group: 'Marketplace', note: 'Artwork story, garment options, creator royalty and remix path' },
  { number: 'M05', title: 'Creator Profiles', path: '/marketplace/creator/sora-kline', group: 'Marketplace', note: 'Portfolio, profile statement, follow action and sales proof' },
  { number: 'M06', title: 'Become a Creator', path: '/marketplace/become-creator', group: 'Marketplace', note: 'Three-step local creator application and clear commercial model' },
  { number: 'M07', title: 'Trending Designs', path: '/marketplace/trending', group: 'Marketplace', note: 'Momentum-ranked designs with live discovery controls' },
  { number: 'R01', title: 'Creator Overview', path: '/creator', group: 'Creator Studio', note: 'Revenue, conversion, audience and submission pulse' },
  { number: 'R02', title: 'My Designs', path: '/creator/designs', group: 'Creator Studio', note: 'Portfolio management, search, status and performance' },
  { number: 'R03', title: 'Publish New Design', path: '/creator/publish', group: 'Creator Studio', note: 'Artwork upload, product selection, metadata and review submission' },
  { number: 'R04', title: 'Submission Status', path: '/creator/submissions', group: 'Creator Studio', note: 'Review pipeline, actionable feedback and local resubmission' },
  { number: 'R05', title: 'Earnings Overview', path: '/creator/earnings', group: 'Creator Studio', note: 'Data-driven revenue chart, royalty splits and period controls' },
  { number: 'R06', title: 'Sales History', path: '/creator/sales', group: 'Creator Studio', note: 'Searchable royalty ledger with territory and status filters' },
  { number: 'R07', title: 'Reward Details', path: '/creator/rewards', group: 'Creator Studio', note: 'Creator levels, milestones and claimable local rewards' },
  { number: 'R08', title: 'Payout Settings', path: '/creator/payout', group: 'Creator Studio', note: 'Simulated payout preferences with no financial connection' },
  { number: 'R09', title: 'Creator Profile Management', path: '/creator/profile', group: 'Creator Studio', note: 'Public profile, creative statement and specialty editor' },
  { number: 'S01', title: 'Studio Landing', path: '/studio', group: 'Design Studio', note: 'Immersive creative entry point with 2D and 3D routes' },
  { number: 'S02', title: 'Mode Selection', path: '/studio/mode', group: 'Design Studio', note: 'Guided 2D or spatial 3D workflow selection' },
  { number: 'S03', title: 'Product Selection', path: '/studio/products', group: 'Design Studio', note: 'Atelier blank comparison with material and print specifications' },
  { number: 'S04', title: '2D Professional Workspace', path: '/studio/2d', group: 'Design Studio', note: 'Layered front/back editor, typography, artwork, undo and export' },
  { number: 'S05', title: '3D Studio Workspace', path: '/studio/3d', group: 'Design Studio', note: 'Interactive garment orbit, camera, material, colour and artwork controls' },
];
