import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useStore } from './StoreContext';

export interface Address {
  id: string;
  label: string;
  name: string;
  line1: string;
  line2: string;
  city: string;
  postalCode: string;
  country: string;
  phone: string;
  isDefault: boolean;
}

export interface CustomerProfile {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  birthday: string;
  size: string;
  fit: string;
  bio: string;
}

export interface StudioDesignSummary {
  id: string;
  name: string;
  productName: string;
  productId: number;
  color: string;
  updatedAt: string;
  status: 'Draft' | 'Saved' | 'Ordered';
  project: unknown;
}

export interface CreatorSubmission {
  id: string;
  title: string;
  category: string;
  artwork: string;
  status: 'Live' | 'In review' | 'Needs changes' | 'Draft';
  updatedAt: string;
  products: string[];
  note?: string;
  sales: number;
  earnings: number;
}

export interface PayoutSettings {
  method: 'Bank transfer' | 'PayPal';
  email: string;
  accountName: string;
  schedule: 'Monthly' | 'When balance reaches $100';
  country: string;
  taxStatus: string;
}

interface EcosystemContextValue {
  profile: CustomerProfile;
  updateProfile: (patch: Partial<CustomerProfile>) => void;
  addresses: Address[];
  saveAddress: (address: Address) => void;
  deleteAddress: (id: string) => void;
  setDefaultAddress: (id: string) => void;
  settings: Record<string, boolean>;
  updateSetting: (key: string, value: boolean) => void;
  likedDesignIds: string[];
  toggleDesignLike: (id: string) => void;
  followedCreators: string[];
  toggleCreatorFollow: (handle: string) => void;
  savedDesigns: StudioDesignSummary[];
  saveStudioDesign: (payload: Omit<StudioDesignSummary, 'updatedAt' | 'status'> & { status?: StudioDesignSummary['status'] }) => string;
  duplicateStudioDesign: (id: string) => string | null;
  deleteStudioDesign: (id: string) => void;
  submissions: CreatorSubmission[];
  addSubmission: (payload: Omit<CreatorSubmission, 'id' | 'updatedAt' | 'sales' | 'earnings' | 'status'> & { status?: CreatorSubmission['status'] }) => string;
  updateSubmission: (id: string, patch: Partial<CreatorSubmission>) => void;
  payout: PayoutSettings;
  updatePayout: (patch: Partial<PayoutSettings>) => void;
  creatorProfile: { displayName: string; handle: string; location: string; role: string; bio: string; statement: string; specialties: string[]; availableForCommissions: boolean };
  updateCreatorProfile: (patch: Partial<EcosystemContextValue['creatorProfile']>) => void;
  claimedRewards: string[];
  claimReward: (id: string) => void;
  resetLocalData: () => void;
}

const EcosystemContext = createContext<EcosystemContextValue | null>(null);
const PREFIX = 'yc-phase02-';

function usePersistentState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const stored = localStorage.getItem(PREFIX + key);
      return stored ? JSON.parse(stored) as T : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try { localStorage.setItem(PREFIX + key, JSON.stringify(value)); } catch { /* local storage can be unavailable */ }
  }, [key, value]);
  return [value, setValue] as const;
}

const INITIAL_PROFILE: CustomerProfile = {
  firstName: 'Alex', lastName: 'Mercer', email: 'member@yourchoice.studio', phone: '+44 20 7946 0824',
  birthday: '1994-06-18', size: 'L', fit: 'Oversized', bio: 'Independent by design. Collecting useful things with a point of view.',
};

const INITIAL_ADDRESSES: Address[] = [
  { id: 'addr-home', label: 'Home', name: 'Alex Mercer', line1: '42 Redchurch Street', line2: 'Studio 4B', city: 'London', postalCode: 'E2 7DP', country: 'United Kingdom', phone: '+44 20 7946 0824', isDefault: true },
  { id: 'addr-studio', label: 'Studio', name: 'Alex Mercer', line1: '18 Willow Street', line2: 'Unit 7', city: 'London', postalCode: 'EC2A 4BH', country: 'United Kingdom', phone: '+44 20 7946 0824', isDefault: false },
];

const INITIAL_DESIGNS: StudioDesignSummary[] = [
  { id: 'local-afterlight', name: 'Afterlight / Personal 01', productName: 'Signature Box Tee', productId: 2, color: '#18191b', updatedAt: '16 Nov 2026 · 21:42', status: 'Saved', project: null },
  { id: 'local-terrain', name: 'Weekend Terrain Study', productName: 'Expression Hoodie', productId: 1, color: '#2349ed', updatedAt: '12 Nov 2026 · 10:18', status: 'Draft', project: null },
  { id: 'local-bloom', name: 'Blue Flower / Gift', productName: 'Atelier Piqué Polo', productId: 4, color: '#edece6', updatedAt: '04 Nov 2026 · 16:05', status: 'Ordered', project: null },
];

const INITIAL_SUBMISSIONS: CreatorSubmission[] = [
  { id: 'd04', title: 'Signal Terrain 01', category: 'Graphics', artwork: '/art/signal-terrain.png', status: 'Live', updatedAt: '12 Nov 2026', products: ['Signature Box Tee', 'Atelier Piqué Polo'], sales: 512, earnings: 4761.6 },
  { id: 'd08', title: 'Contour Memory', category: 'Abstract', artwork: '/art/signal-terrain.png', status: 'Live', updatedAt: '06 Oct 2026', products: ['Atelier Piqué Polo'], sales: 339, earnings: 4474.8 },
  { id: 'sub-frequency', title: 'Frequency Study 03', category: 'Graphics', artwork: '/art/cobalt-bloom.png', status: 'In review', updatedAt: '16 Nov 2026', products: ['Signature Box Tee', 'Expression Hoodie'], note: 'Standard review · estimated response by 19 Nov', sales: 0, earnings: 0 },
  { id: 'sub-soft-machine', title: 'Soft Machine', category: 'Typography', artwork: '/art/chrome-wings.png', status: 'Needs changes', updatedAt: '11 Nov 2026', products: ['Signature Box Tee'], note: 'Increase fine-line thickness to at least 1.5 mm at final print size.', sales: 0, earnings: 0 },
  { id: 'sub-afterimage', title: 'Afterimage Draft', category: 'Abstract', artwork: '/art/solar-eclipse.png', status: 'Draft', updatedAt: '09 Nov 2026', products: ['Expression Hoodie'], sales: 0, earnings: 0 },
];

export function EcosystemProvider({ children }: { children: React.ReactNode }) {
  const { showToast } = useStore();
  const [profile, setProfile] = usePersistentState<CustomerProfile>('profile', INITIAL_PROFILE);
  const [addresses, setAddresses] = usePersistentState<Address[]>('addresses', INITIAL_ADDRESSES);
  const [settings, setSettings] = usePersistentState<Record<string, boolean>>('settings', { orderUpdates: true, creatorDrops: true, studioNotes: false, newsletter: true, publicWishlist: false, personalizedEdits: true });
  const [likedDesignIds, setLikedDesignIds] = usePersistentState<string[]>('liked-designs', ['d01', 'd04', 'd06']);
  const [followedCreators, setFollowedCreators] = usePersistentState<string[]>('followed-creators', ['sora-kline']);
  const [savedDesigns, setSavedDesigns] = usePersistentState<StudioDesignSummary[]>('studio-designs', INITIAL_DESIGNS);
  const [submissions, setSubmissions] = usePersistentState<CreatorSubmission[]>('submissions', INITIAL_SUBMISSIONS);
  const [payout, setPayout] = usePersistentState<PayoutSettings>('payout', { method: 'Bank transfer', email: 'sora@yourchoice.studio', accountName: 'Sora Kline', schedule: 'Monthly', country: 'Germany', taxStatus: 'Self-employed creator' });
  const [creatorProfile, setCreatorProfile] = usePersistentState('creator-profile', { displayName: 'Sora Kline', handle: 'sora-kline', location: 'Berlin, DE', role: 'Digital artist & creative coder', bio: 'Turning field recordings, terrain data and natural systems into vivid, wearable signals.', statement: 'The work starts as data, but it only becomes alive when somebody chooses to wear it.', specialties: ['Generative art', 'Data', 'Gradients'], availableForCommissions: true });
  const [claimedRewards, setClaimedRewards] = usePersistentState<string[]>('rewards', ['sample-pack']);

  const updateProfile = (patch: Partial<CustomerProfile>) => {
    setProfile((prev) => ({ ...prev, ...patch }));
    showToast('Profile updated. Your choices, kept locally.');
  };
  const saveAddress = (address: Address) => {
    setAddresses((prev) => {
      const exists = prev.some((item) => item.id === address.id);
      const normalized = address.isDefault ? prev.map((item) => ({ ...item, isDefault: false })) : prev;
      return exists ? normalized.map((item) => item.id === address.id ? address : item) : [...normalized, address];
    });
    showToast('Address book updated.');
  };
  const deleteAddress = (id: string) => {
    setAddresses((prev) => prev.filter((item) => item.id !== id));
    showToast('Address removed.');
  };
  const setDefaultAddress = (id: string) => {
    setAddresses((prev) => prev.map((item) => ({ ...item, isDefault: item.id === id })));
    showToast('Default delivery address updated.');
  };
  const updateSetting = (key: string, value: boolean) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
    showToast('Preference saved on this device.');
  };
  const toggleDesignLike = (id: string) => {
    setLikedDesignIds((prev) => {
      const saved = prev.includes(id);
      showToast(saved ? 'Artwork removed from your wishlist.' : 'Artwork saved to your wishlist.');
      return saved ? prev.filter((item) => item !== id) : [id, ...prev];
    });
  };
  const toggleCreatorFollow = (handle: string) => {
    setFollowedCreators((prev) => {
      const following = prev.includes(handle);
      showToast(following ? 'Creator unfollowed.' : 'Creator added to your following list.');
      return following ? prev.filter((item) => item !== handle) : [handle, ...prev];
    });
  };
  const saveStudioDesign: EcosystemContextValue['saveStudioDesign'] = (payload) => {
    const id = payload.id || `studio-${Date.now()}`;
    const record: StudioDesignSummary = { ...payload, id, updatedAt: new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date()), status: payload.status || 'Saved' };
    setSavedDesigns((prev) => [record, ...prev.filter((item) => item.id !== id)]);
    return id;
  };
  const duplicateStudioDesign = (id: string) => {
    const original = savedDesigns.find((item) => item.id === id);
    if (!original) return null;
    const newId = `studio-${Date.now()}`;
    setSavedDesigns((prev) => [{ ...original, id: newId, name: `${original.name} / Copy`, status: 'Draft', updatedAt: 'Just now' }, ...prev]);
    showToast('Design duplicated as a new draft.');
    return newId;
  };
  const deleteStudioDesign = (id: string) => {
    setSavedDesigns((prev) => prev.filter((item) => item.id !== id));
    showToast('Saved design removed from this device.');
  };
  const addSubmission: EcosystemContextValue['addSubmission'] = (payload) => {
    const id = `sub-${Date.now()}`;
    setSubmissions((prev) => [{ ...payload, id, status: payload.status || 'In review', updatedAt: 'Just now', sales: 0, earnings: 0 }, ...prev]);
    return id;
  };
  const updateSubmission = (id: string, patch: Partial<CreatorSubmission>) => {
    setSubmissions((prev) => prev.map((item) => item.id === id ? { ...item, ...patch, updatedAt: 'Just now' } : item));
    showToast('Submission updated.');
  };
  const updatePayout = (patch: Partial<PayoutSettings>) => {
    setPayout((prev) => ({ ...prev, ...patch }));
    showToast('Demo payout preferences saved locally. No payment was initiated.');
  };
  const updateCreatorProfile = (patch: Partial<EcosystemContextValue['creatorProfile']>) => {
    setCreatorProfile((prev) => ({ ...prev, ...patch }));
    showToast('Creator profile updated.');
  };
  const claimReward = (id: string) => {
    if (claimedRewards.includes(id)) return;
    setClaimedRewards((prev) => [...prev, id]);
    showToast('Reward added to your local creator benefits.');
  };
  const resetLocalData = () => {
    Object.keys(localStorage).filter((key) => key.startsWith(PREFIX)).forEach((key) => localStorage.removeItem(key));
    setProfile(INITIAL_PROFILE); setAddresses(INITIAL_ADDRESSES); setLikedDesignIds(['d01', 'd04', 'd06']); setFollowedCreators(['sora-kline']); setSavedDesigns(INITIAL_DESIGNS); setSubmissions(INITIAL_SUBMISSIONS);
    showToast('Phase 02 sample data restored.');
  };

  const value = useMemo(() => ({
    profile, updateProfile, addresses, saveAddress, deleteAddress, setDefaultAddress,
    settings, updateSetting, likedDesignIds, toggleDesignLike, followedCreators, toggleCreatorFollow,
    savedDesigns, saveStudioDesign, duplicateStudioDesign, deleteStudioDesign,
    submissions, addSubmission, updateSubmission, payout, updatePayout, creatorProfile, updateCreatorProfile,
    claimedRewards, claimReward, resetLocalData,
  }), [profile, addresses, settings, likedDesignIds, followedCreators, savedDesigns, submissions, payout, creatorProfile, claimedRewards]);

  return <EcosystemContext.Provider value={value}>{children}</EcosystemContext.Provider>;
}

export function useEcosystem() {
  const value = useContext(EcosystemContext);
  if (!value) throw new Error('useEcosystem must be used within EcosystemProvider');
  return value;
}
