import React, { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  Compass,
  Heart,
  Menu,
  Minus,
  Plus,
  Search,
  ShoppingBag,
  User,
  X,
} from 'lucide-react';
import { STOREFRONT_PAGES, formatPrice } from '../data/catalog';
import { useStore } from '../context/StoreContext';
import { OfficialEmblem, SubscribeForm, Wordmark } from './BrandMarks';
import { SizeGuideInteractive } from './SizeGuideContent';
import { PHASE2_GROUPS, PHASE2_PAGES } from '../data/phase2';

let openDialogCount = 0;

export function DialogDrawer({
  children,
  onClose,
  title,
  wide = false,
}: {
  children: React.ReactNode;
  onClose: () => void;
  title: string;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);

  useEffect(() => {
    onCloseRef.current = onClose;
  }, [onClose]);

  useEffect(() => {
    const prevActive = document.activeElement as HTMLElement | null;
    openDialogCount += 1;
    document.body.style.overflow = 'hidden';
    ref.current?.focus();

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCloseRef.current();
    };
    window.addEventListener('keydown', handleKey);

    return () => {
      openDialogCount = Math.max(0, openDialogCount - 1);
      document.body.style.overflow = openDialogCount ? 'hidden' : '';
      window.removeEventListener('keydown', handleKey);
      if (!openDialogCount) prevActive?.focus?.();
    };
  }, []);

  return (
    <motion.div
      className="dialog-backdrop"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        ref={ref}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`dialog ${wide ? 'dialog-wide' : ''}`}
        initial={{ x: 80, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: 80, opacity: 0 }}
        transition={{ duration: 0.28 }}
        onClick={(e) => e.stopPropagation()}
      >
        <button className="close-dialog" onClick={onClose} aria-label="Close dialog">
          <X size={21} />
        </button>
        {children}
      </motion.div>
    </motion.div>
  );
}

export function StorefrontLayout({ children }: { children: React.ReactNode }) {
  const {
    products,
    bag,
    bagCount,
    bagSubtotal,
    updateBagQuantity,
    removeFromBag,
    wishlistIds,
    member,
    bagDrawerOpen,
    setBagDrawerOpen,
    searchDrawerOpen,
    setSearchDrawerOpen,
    studioDrawerOpen,
    setStudioDrawerOpen,
    sitemapDrawerOpen,
    setSitemapDrawerOpen,
    sizeGuideModalCategory,
    setSizeGuideModalCategory,
    toastMessage,
    dismissToast,
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [drawerQuery, setDrawerQuery] = useState('');

  const location = useLocation();
  const navigate = useNavigate();
  const reduced = useReducedMotion();
  const isHome = location.pathname === '/';
  const isImmersiveWorkspace = location.pathname.startsWith('/studio') || location.pathname.startsWith('/account') || location.pathname.startsWith('/creator') || location.pathname.startsWith('/admin');

  const { scrollY } = useScroll();
  const dockOpacity = useTransform(scrollY, [420, 620], [0, 1]);
  const dockY = useTransform(scrollY, [420, 620], [22, 0]);
  const dockPointer = useTransform(scrollY, (v) => (v > 500 ? 'auto' : 'none'));

  const drawerResults = products.filter((p) =>
    `${p.name} ${p.color} ${p.category} ${p.subStyle}`
      .toLowerCase()
      .includes(drawerQuery.trim().toLowerCase())
  );

  const freeShippingRemaining = Math.max(0, 150 - bagSubtotal);
  const freeShippingPct = Math.min(100, Math.round((bagSubtotal / 150) * 100));

  const submitDrawerSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = drawerQuery.trim();
    setSearchDrawerOpen(false);
    navigate(q ? `/search?q=${encodeURIComponent(q)}` : '/search');
  };

  if (isImmersiveWorkspace) {
    return (
      <>
        <a href="#main" className="skip-link">Skip to content</a>
        <main id="main" className="product-workspace-main">{children}</main>
        <AnimatePresence>
          {toastMessage && (
            <motion.div role="status" className="toast" initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }}>
              <Check size={17} /><span>{toastMessage}</span>
              <button type="button" aria-label="Dismiss notification" onClick={dismissToast}><X size={14} /></button>
            </motion.div>
          )}
        </AnimatePresence>
      </>
    );
  }

  return (
    <>
      <a href="#main" className="skip-link">
        Skip to content
      </a>

      {/* Top Announcement Bar */}
      <div className="announcement">
        <span>
          <i /> INDEPENDENT BY DESIGN.
        </span>
        <span>Design it. Wear it. Earn from it.</span>
        <Link to="/shop" className="announcement-right hover:text-white">
          SELF-EXPRESSION STARTS HERE <ArrowUpRight size={12} />
        </Link>
      </div>

      {/* Site Header */}
      <header className={`site-header ${isHome ? '' : 'is-subpage'}`}>
        <Link
          to="/"
          onClick={() => {
            if (isHome) {
              window.scrollTo({ top: 0, behavior: reduced ? 'instant' : 'smooth' });
            }
          }}
          className="brand-link"
        >
          {!isHome && (
            <span className="brand-crest-mini" aria-hidden="true">
              <img src="/images/official-emblem.webp" alt="" />
            </span>
          )}
          <Wordmark />
        </Link>

        <nav className="desktop-nav" aria-label="Main navigation">
          <NavLink to="/shop" className={({ isActive }) => (isActive ? 'is-active' : '')}>
            Shop <span>↗</span>
          </NavLink>
          <NavLink
            to="/collections/t-shirts"
            className={({ isActive }) => (isActive ? 'is-active' : '')}
          >
            T-Shirts
          </NavLink>
          <NavLink
            to="/collections/polo-shirts"
            className={({ isActive }) => (isActive ? 'is-active' : '')}
          >
            Polo Shirts
          </NavLink>
          <NavLink
            to="/collections/expression-vol-01"
            className={({ isActive }) => (isActive ? 'is-active' : '')}
          >
            Collections
          </NavLink>
          <NavLink to="/marketplace" className={({ isActive }) => (isActive ? 'is-active' : '')}>
            Marketplace <span>↗</span>
          </NavLink>
          <NavLink to="/studio" className={({ isActive }) => (isActive ? 'is-active' : '')}>
            Design Studio <span className="live-dot" />
          </NavLink>
        </nav>

        <div className="header-tools">
          <button
            type="button"
            className="pages-pill"
            onClick={() => setSitemapDrawerOpen(true)}
            title="Browse the complete YOUR CHOICE Phase 01 + Phase 02 ecosystem"
          >
            <Compass size={13} /> All Pages
          </button>

          <button
            type="button"
            aria-label="Search collection"
            className="icon-button"
            onClick={() => setSearchDrawerOpen(true)}
          >
            <Search size={18} />
          </button>

          <Link
            to="/wishlist"
            aria-label={`Wishlist, ${wishlistIds.length} saved pieces`}
            className="icon-button"
          >
            <Heart size={18} />
            {wishlistIds.length > 0 && <span className="icon-badge">{wishlistIds.length}</span>}
          </Link>

          <Link
            to="/account"
            aria-label={member ? `Member account: ${member.name}` : 'Open customer account'}
            className="icon-button"
          >
            <User size={18} />
            {member && <span className="icon-badge">✓</span>}
          </Link>

          <button type="button" className="bag-button" onClick={() => setBagDrawerOpen(true)}>
            Bag <span>({bagCount})</span>
            <ShoppingBag size={15} />
          </button>

          <button
            type="button"
            className="mobile-menu icon-button"
            aria-label="Open navigation"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu size={21} />
          </button>
        </div>
      </header>

      {/* Main Page Content */}
      <main id="main">{children}</main>

      {/* Site Footer */}
      <footer className="site-footer">
        <div className="footer-top">
          <div className="footer-brand-col">
            <div className="footer-crest-row">
              <OfficialEmblem className="footer-emblem" />
              <Link to="/" className="brand-link">
                <Wordmark />
              </Link>
            </div>
            <p className="footer-tagline">
              Design it. Wear it.
              <br />
              <span>Earn from it.</span>
            </p>
            <p className="mono text-[9px] text-[#8d949e]">
              ALWAYS THE BEST CHOICE · VOL. 01 STOREFRONT
            </p>
          </div>

          <div className="footer-links-col">
            <span className="footer-col-title">01 / Catalogue</span>
            <Link to="/shop">
              Shop All Products <ArrowUpRight size={13} />
            </Link>
            <Link to="/collections/t-shirts">
              T-Shirt Collection <ArrowUpRight size={13} />
            </Link>
            <Link to="/collections/polo-shirts">
              Polo Shirt Collection <ArrowUpRight size={13} />
            </Link>
            <Link to="/collections/expression-vol-01">
              Collection Details <ArrowUpRight size={13} />
            </Link>
            <Link to="/search">
              Search Catalogue <ArrowUpRight size={13} />
            </Link>
            <Link to="/size-guide">
              Size Guide & Fit Finder <ArrowUpRight size={13} />
            </Link>
          </div>

          <div className="footer-links-col">
            <span className="footer-col-title">02 / Client Care</span>
            <Link to="/order-tracking">
              Order Tracking <ArrowUpRight size={13} />
            </Link>
            <Link to="/shipping-delivery">
              Shipping & Delivery <ArrowUpRight size={13} />
            </Link>
            <Link to="/returns-refunds">
              Returns & Refunds <ArrowUpRight size={13} />
            </Link>
            <Link to="/faq">
              FAQ <ArrowUpRight size={13} />
            </Link>
            <Link to="/contact">
              Contact Concierge <ArrowUpRight size={13} />
            </Link>
          </div>

          <div className="footer-links-col">
            <span className="footer-col-title">03 / Account & House</span>
            <Link to="/about">
              About YOUR CHOICE <ArrowUpRight size={13} />
            </Link>
            <Link to="/wishlist">
              Saved Wishlist ({wishlistIds.length}) <ArrowUpRight size={13} />
            </Link>
            <Link to="/bag">
              Shopping Bag ({bagCount}) <ArrowUpRight size={13} />
            </Link>
            <Link to="/login">
              {member ? `Account (${member.name.split(' ')[0]})` : 'Login / Register'}{' '}
              <ArrowUpRight size={13} />
            </Link>
            <Link to="/privacy-policy">
              Privacy Policy <ArrowUpRight size={13} />
            </Link>
            <Link to="/terms-conditions">
              Terms & Conditions <ArrowUpRight size={13} />
            </Link>
          </div>

          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: reduced ? 'instant' : 'smooth' })}
            className="back-top"
            aria-label="Back to top"
          >
            <ArrowUpRight size={20} />
          </button>
        </div>

        <div className="footer-massive" aria-hidden="true">
          YOUR CHOICE<span>®</span>
        </div>

        <div className="footer-bottom mono">
          <span>© {new Date().getFullYear()} YOUR CHOICE. ALL YOURS.</span>
          <button
            type="button"
            onClick={() => setSitemapDrawerOpen(true)}
            className="underline hover:text-white transition-colors"
          >
            PHASE 01 + 02 — EXPLORE THE COMPLETE ECOSYSTEM ↗
          </button>
          <span>
            BUILT FOR WHAT’S NEXT. <i />
          </span>
        </div>
      </footer>

      {/* Floating Bag Trigger */}
      <button
        type="button"
        className="floating-bag"
        aria-label={`Open bag, ${bagCount} items`}
        onClick={() => setBagDrawerOpen(true)}
      >
        <ShoppingBag size={19} />
        <span>{bagCount}</span>
      </button>

      {/* Floating Dock Navigation */}
      <motion.nav
        className="floating-nav"
        aria-label="Quick navigation"
        style={{
          opacity: dockOpacity,
          y: dockY,
          pointerEvents: dockPointer as unknown as React.CSSProperties['pointerEvents'],
        }}
      >
        <Link to="/" className="dock-monogram" aria-label="Back to YOUR CHOICE">
          YC<sup>®</sup>
        </Link>
        <Link to="/shop">
          Shop all <ArrowUpRight size={13} />
        </Link>
        <button
          type="button"
          onClick={() => setSitemapDrawerOpen(true)}
          aria-label="Open all storefront pages directory"
        >
          <Menu size={17} />
        </button>
      </motion.nav>

      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            role="status"
            className="toast"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
          >
            <Check size={17} />
            <span>{toastMessage}</span>
            <button type="button" aria-label="Dismiss notification" onClick={dismissToast}>
              <X size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global Slide-Over Shopping Bag Drawer */}
      <AnimatePresence>
        {bagDrawerOpen && (
          <DialogDrawer title="Your shopping bag" onClose={() => setBagDrawerOpen(false)}>
            <div className="drawer-content">
              <p className="eyebrow">
                <i /> GOOD CHOICES, ALL YOURS.
              </p>
              <h2>
                Your bag <sup>({bagCount})</sup>
              </h2>

              {bag.length > 0 && (
                <div className="mb-5 p-3.5 bg-[#eaECE5] border border-[var(--line)]">
                  <div className="flex justify-between text-[11px] mb-2">
                    <span>
                      {freeShippingRemaining === 0
                        ? 'Complimentary Express Courier unlocked'
                        : `Add ${formatPrice(freeShippingRemaining)} for Free Express Delivery`}
                    </span>
                    <span className="font-mono text-[10px]">{freeShippingPct}%</span>
                  </div>
                  <div className="h-1.5 bg-[#d4d7ce] overflow-hidden">
                    <div
                      className="h-full bg-[var(--blue)] transition-all duration-300"
                      style={{ width: `${freeShippingPct}%` }}
                    />
                  </div>
                </div>
              )}

              {bag.length === 0 ? (
                <div className="bag-empty">
                  <ShoppingBag size={44} strokeWidth={1} />
                  <h3>A little room for expression.</h3>
                  <p>Your next good choice is waiting in the collection.</p>
                  <Link
                    to="/shop"
                    onClick={() => setBagDrawerOpen(false)}
                    className="button button-blue mt-4"
                  >
                    Explore all products <ArrowUpRight size={18} />
                  </Link>
                </div>
              ) : (
                <>
                  <div className="bag-list">
                    {bag.map((line) => {
                      const prod = products.find((p) => p.id === line.productId);
                      if (!prod) return null;
                      return (
                        <div className="bag-line" key={line.key}>
                          <Link
                            to={`/product/${prod.slug}`}
                            onClick={() => setBagDrawerOpen(false)}
                          >
                            <img src={prod.image} alt={prod.name} />
                          </Link>
                          <div>
                            <h3>
                              <Link
                                to={`/product/${prod.slug}`}
                                onClick={() => setBagDrawerOpen(false)}
                              >
                                {prod.name}
                              </Link>
                            </h3>
                            <p>
                              {prod.color} / Size {line.size}
                            </p>
                            <div className="quantity">
                              <button
                                type="button"
                                aria-label={`Decrease ${prod.name} quantity`}
                                onClick={() => updateBagQuantity(line.key, line.quantity - 1)}
                              >
                                <Minus size={12} />
                              </button>
                              <span className="font-mono">{line.quantity}</span>
                              <button
                                type="button"
                                aria-label={`Increase ${prod.name} quantity`}
                                disabled={line.quantity >= 10}
                                onClick={() => updateBagQuantity(line.key, line.quantity + 1)}
                              >
                                <Plus size={12} />
                              </button>
                            </div>
                            <div>
                              <button
                                type="button"
                                className="remove-item"
                                onClick={() => removeFromBag(line.key)}
                              >
                                Remove
                              </button>
                            </div>
                          </div>
                          <strong>{formatPrice(prod.price * line.quantity)}</strong>
                        </div>
                      );
                    })}
                  </div>

                  <div className="bag-total">
                    <span>Subtotal</span>
                    <strong className="font-mono">{formatPrice(bagSubtotal)}</strong>
                  </div>
                  <p className="text-[11px] text-[#60675a] mt-2 mb-5">
                    Duties & taxes included (DDP). Shipping & promo codes calculated in Bag or Checkout.
                  </p>

                  <div className="space-y-2.5">
                    <Link
                      to="/checkout"
                      onClick={() => setBagDrawerOpen(false)}
                      className="button button-blue w-full"
                    >
                      Proceed to Checkout <ArrowRight size={17} />
                    </Link>
                    <Link
                      to="/bag"
                      onClick={() => setBagDrawerOpen(false)}
                      className="button button-outline w-full"
                    >
                      View Full Shopping Bag <ArrowUpRight size={16} />
                    </Link>
                  </div>

                  <button
                    type="button"
                    className="text-link mt-5"
                    onClick={() => setBagDrawerOpen(false)}
                  >
                    <ArrowLeft size={14} /> Continue exploring
                  </button>
                </>
              )}
            </div>
          </DialogDrawer>
        )}
      </AnimatePresence>

      {/* Global Search Drawer */}
      <AnimatePresence>
        {searchDrawerOpen && (
          <DialogDrawer
            title="Search the collection"
            onClose={() => {
              setSearchDrawerOpen(false);
            }}
          >
            <div className="drawer-content">
              <p className="eyebrow">
                <i /> FIND YOUR NEXT EXPRESSION
              </p>
              <h2>What’s your choice?</h2>

              <form onSubmit={submitDrawerSearch}>
                <div className="search-input">
                  <Search size={19} />
                  <input
                    autoFocus
                    type="search"
                    value={drawerQuery}
                    onChange={(e) => setDrawerQuery(e.target.value)}
                    placeholder="Try polo, royal blue, heavyweight tee, bomber…"
                    aria-label="Search products"
                  />
                </div>
                <div className="flex items-center justify-between mt-3">
                  <span className="mono search-count !mt-0">
                    {drawerResults.length} PIECES MATCHING
                  </span>
                  <button type="submit" className="text-link">
                    Open full search page <ArrowRight size={13} />
                  </button>
                </div>
              </form>

              <div className="flex flex-wrap gap-1.5 mt-4">
                {['Royal Blue', 'Polo', 'Box Tee', 'Merino', 'Bomber'].map((chip) => (
                  <button
                    key={chip}
                    type="button"
                    onClick={() => setDrawerQuery(chip)}
                    className="px-2.5 py-1 border border-[#ccd0c5] text-[10px] font-mono hover:border-[var(--blue)] hover:text-[var(--blue)]"
                  >
                    {chip}
                  </button>
                ))}
              </div>

              <div className="search-results">
                {drawerResults.slice(0, 6).map((item) => (
                  <Link
                    key={item.id}
                    to={`/product/${item.slug}`}
                    onClick={() => setSearchDrawerOpen(false)}
                  >
                    <img src={item.image} alt={item.name} />
                    <span className="flex-1">
                      <strong className="font-medium block">{item.name}</strong>
                      <small>
                        {item.category} · {item.color}
                      </small>
                    </span>
                    <span className="font-mono text-xs">{formatPrice(item.price)}</span>
                    <ArrowUpRight size={16} />
                  </Link>
                ))}
                {drawerResults.length === 0 && (
                  <p className="py-10 text-sm text-[#60675a]">
                    No pieces match &ldquo;{drawerQuery}&rdquo;. Try searching T-Shirts, Polo Shirts, or Royal Blue.
                  </p>
                )}
              </div>
            </div>
          </DialogDrawer>
        )}
      </AnimatePresence>

      {/* Design Studio Early Access Drawer */}
      <AnimatePresence>
        {studioDrawerOpen && (
          <DialogDrawer title="Design Studio early access" onClose={() => setStudioDrawerOpen(false)}>
            <div className="drawer-content studio-drawer">
              <span className="blue-spark">✳</span>
              <p className="eyebrow">CURRENTLY IN THE MAKING</p>
              <h2>
                Your idea.
                <br />
                Your canvas.
                <br />
                <em>Your choice.</em>
              </h2>
              <p>Design it. Wear it. Earn from it.</p>
              <p>
                A dedicated creative platform built on our 320 GSM Atelier Blanks and Piqué silhouettes is taking shape. Join the early list for Design Studio creator access.
              </p>
              <SubscribeForm interest="studio-drawer" />
            </div>
          </DialogDrawer>
        )}
      </AnimatePresence>

      {/* Global Size Guide Modal (Triggered from PDP or anywhere) */}
      <AnimatePresence>
        {sizeGuideModalCategory && (
          <DialogDrawer
            title="Size Guide & Fit Architecture"
            wide
            onClose={() => setSizeGuideModalCategory(null)}
          >
            <div className="drawer-content">
              <p className="eyebrow">
                <i /> YOUR CHOICE FIT SYSTEM
              </p>
              <h2>Size Guide & Fit Finder</h2>
              <SizeGuideInteractive initialCategory={sizeGuideModalCategory} compact />
              <div className="mt-6 pt-4 border-t border-[var(--line)] flex justify-between items-center">
                <span className="mono text-[10px] text-[#60675a]">
                  PRE-SHRUNK ORGANIC FABRICS · ±1 CM TOLERANCE
                </span>
                <Link
                  to="/size-guide"
                  onClick={() => setSizeGuideModalCategory(null)}
                  className="text-link"
                >
                  Open full Size Guide page <ArrowUpRight size={14} />
                </Link>
              </div>
            </div>
          </DialogDrawer>
        )}
      </AnimatePresence>

      {/* Mobile Navigation Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <DialogDrawer title="Navigation" onClose={() => setMobileMenuOpen(false)}>
            <div className="drawer-content">
              <div className="flex items-center gap-3 mb-8">
                <OfficialEmblem className="w-10 h-7 object-contain bg-[#121416] p-1 rounded" />
                <Wordmark />
              </div>

              <nav aria-label="Mobile navigation" className="flex flex-col gap-4 border-b border-[var(--line)] pb-7">
                {[
                  { label: 'Homepage', to: '/' },
                  { label: 'Shop / All Products', to: '/shop' },
                  { label: 'T-Shirt Collection', to: '/collections/t-shirts' },
                  { label: 'Polo Shirt Collection', to: '/collections/polo-shirts' },
                  { label: 'Collection Details (Vol. 01)', to: '/collections/expression-vol-01' },
                  { label: `Wishlist (${wishlistIds.length})`, to: '/wishlist' },
                  { label: `Shopping Bag (${bagCount})`, to: '/bag' },
                  { label: 'Order Tracking', to: '/order-tracking' },
                  { label: 'Creator Marketplace', to: '/marketplace' },
                  { label: 'Design Studio', to: '/studio' },
                  { label: 'Creator Dashboard', to: '/creator' },
                  { label: member ? `Account (${member.name})` : 'Customer Account', to: '/account' },
                  { label: 'About YOUR CHOICE', to: '/about' },
                  { label: 'Size Guide', to: '/size-guide' },
                  { label: 'FAQ & Client Care', to: '/faq' },
                  { label: 'Contact Concierge', to: '/contact' },
                ].map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center justify-between text-xl font-medium tracking-tight hover:text-[var(--blue)]"
                  >
                    <span>{link.label}</span>
                    <ArrowUpRight size={18} />
                  </Link>
                ))}
              </nav>

              <div className="mt-6 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setSitemapDrawerOpen(true);
                  }}
                  className="button button-blue w-full"
                >
                  Browse the Complete Ecosystem <Compass size={17} />
                </button>
              </div>
            </div>
          </DialogDrawer>
        )}
      </AnimatePresence>

      {/* Complete Phase 01 + Phase 02 Ecosystem Directory */}
      <AnimatePresence>
        {sitemapDrawerOpen && (
          <DialogDrawer
            title="YOUR CHOICE complete ecosystem directory"
            wide
            onClose={() => setSitemapDrawerOpen(false)}
          >
            <div className="drawer-content">
              <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                <div>
                  <p className="eyebrow">
                    <i /> YOUR CHOICE — PHASE 01 DIRECTORY
                  </p>
                  <h2 className="!mb-1">The Complete YOUR CHOICE Ecosystem</h2>
                  <p className="text-xs text-[#60675a]">
                    Instant navigation across the original 24-page storefront and all Phase 02 customer, marketplace, creator and studio experiences.
                  </p>
                </div>
                <span className="px-3 py-1.5 bg-[var(--blue)] text-white font-mono text-[10px]">
                  {24 + PHASE2_PAGES.length} ECOSYSTEM ROUTES
                </span>
              </div>

              {(
                [
                  'Catalogue & Discovery',
                  'Bag & Checkout',
                  'Member Account',
                  'Brand, Fit & Policies',
                ] as const
              ).map((group) => (
                <div key={group} className="mb-7">
                  <h3 className="mono text-[10px] uppercase tracking-widest text-[#5c6355] border-b border-[var(--line)] pb-2 mb-3">
                    {group}
                  </h3>
                  <div className="grid sm:grid-cols-2 gap-2.5">
                    {STOREFRONT_PAGES.filter((p) => p.group === group).map((page) => {
                      const active = location.pathname === page.path.split('?')[0];
                      return (
                        <Link
                          key={page.number}
                          to={page.path}
                          onClick={() => setSitemapDrawerOpen(false)}
                          className={`p-3.5 border transition-all flex items-start justify-between gap-3 ${
                            active
                              ? 'border-[var(--blue)] bg-[#2349ed0d]'
                              : 'border-[#d6d8d1] bg-[#fafaf7] hover:border-[#18191a]'
                          }`}
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-[10px] text-[var(--blue)] font-semibold">
                                {page.number}
                              </span>
                              <span className="text-sm font-semibold tracking-tight">
                                {page.title}
                              </span>
                            </div>
                            <p className="text-[11px] text-[#60675a] mt-1">{page.note}</p>
                          </div>
                          <ArrowUpRight size={15} className="shrink-0 mt-0.5 text-[#6b7064]" />
                        </Link>
                      );
                    })}
                  </div>
                </div>
              ))}
              <div className="phase2-directory-heading">
                <span className="eyebrow"><i /> PHASE 02 / CONNECTED PRODUCTS</span>
                <span className="mono text-[10px] text-[#60675a]">{PHASE2_PAGES.length} CUSTOMER, CREATOR & STUDIO DESTINATIONS</span>
              </div>
              {PHASE2_GROUPS.map((group) => (
                <div key={group} className="mb-7">
                  <h3 className="mono text-[10px] uppercase tracking-widest text-[#5c6355] border-b border-[var(--line)] pb-2 mb-3">{group}</h3>
                  <div className="grid sm:grid-cols-2 gap-2.5">
                    {PHASE2_PAGES.filter((page) => page.group === group).map((page) => (
                      <Link key={page.number} to={page.path} onClick={() => setSitemapDrawerOpen(false)} className="p-3.5 border border-[#d6d8d1] bg-[#fafaf7] hover:border-[#2349ed] transition-all flex items-start justify-between gap-3">
                        <div><div className="flex items-center gap-2"><span className="font-mono text-[10px] text-[var(--blue)] font-semibold">{page.number}</span><span className="text-sm font-semibold tracking-tight">{page.title}</span></div><p className="text-[11px] text-[#60675a] mt-1">{page.note}</p></div>
                        <ArrowUpRight size={15} className="shrink-0 mt-0.5 text-[#6b7064]" />
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </DialogDrawer>
        )}
      </AnimatePresence>
    </>
  );
}
