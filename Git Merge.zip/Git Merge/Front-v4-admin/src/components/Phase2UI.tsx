import React, { useId, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, ArrowUpRight, BadgeCheck, Bell, Bookmark, Box, ChevronDown, CircleDollarSign,
  Compass, Copy, Download, Heart, LayoutDashboard, MapPin, Menu, Package, Palette, Plus, Settings,
  Shirt, ShoppingBag, Sparkles, Upload, User, Users, X, Zap,
} from 'lucide-react';
import { CREATORS, MARKETPLACE_DESIGNS, MarketplaceDesign, PHASE2_PAGES } from '../data/phase2';
import { useEcosystem } from '../context/EcosystemContext';
import { Wordmark } from './BrandMarks';

export function PageHeading({ eyebrow, title, copy, actions }: { eyebrow: string; title: string; copy?: string; actions?: React.ReactNode }) {
  return (
    <div className="p2-page-heading">
      <div>
        <span className="p2-kicker">{eyebrow}</span>
        <h1>{title}</h1>
        {copy && <p>{copy}</p>}
      </div>
      {actions && <div className="p2-heading-actions">{actions}</div>}
    </div>
  );
}

export function StatusPill({ status }: { status: string }) {
  const key = status.toLowerCase().replaceAll(' ', '-');
  return <span className={`status-pill status-${key}`}><i />{status}</span>;
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (value: boolean) => void; label: string }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} className={`yc-toggle ${checked ? 'is-on' : ''}`}><span /></button>;
}

export function StatCard({ label, value, delta, icon, bars, dark = false }: { label: string; value: string; delta?: string; icon?: React.ReactNode; bars?: number[]; dark?: boolean }) {
  return (
    <motion.article className={`stat-card ${dark ? 'is-dark' : ''}`} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}>
      <div className="stat-card-top"><span>{label}</span>{icon}</div>
      <strong>{value}</strong>
      <div className="stat-card-bottom">
        {delta && <span>{delta}</span>}
        {bars && <div className="micro-bars" aria-hidden="true">{bars.map((height, i) => <i key={i} style={{ height: `${height}%` }} />)}</div>}
      </div>
    </motion.article>
  );
}

const customerNav = [
  { to: '/account', label: 'Overview', icon: <LayoutDashboard size={17} />, end: true },
  { to: '/account/orders', label: 'Orders', icon: <Package size={17} /> },
  { to: '/account/designs', label: 'Saved designs', icon: <Palette size={17} /> },
  { to: '/account/wishlist', label: 'Wishlist', icon: <Heart size={17} /> },
  { to: '/account/addresses', label: 'Address book', icon: <MapPin size={17} /> },
  { to: '/account/profile', label: 'Profile', icon: <User size={17} /> },
  { to: '/account/settings', label: 'Settings', icon: <Settings size={17} /> },
];
const creatorNav = [
  { to: '/creator', label: 'Overview', icon: <LayoutDashboard size={17} />, end: true },
  { to: '/creator/designs', label: 'My designs', icon: <Palette size={17} /> },
  { to: '/creator/publish', label: 'Publish new', icon: <Upload size={17} /> },
  { to: '/creator/submissions', label: 'Submissions', icon: <Bookmark size={17} /> },
  { to: '/creator/earnings', label: 'Earnings', icon: <CircleDollarSign size={17} /> },
  { to: '/creator/sales', label: 'Sales history', icon: <Package size={17} /> },
  { to: '/creator/rewards', label: 'Rewards', icon: <Sparkles size={17} /> },
  { to: '/creator/payout', label: 'Payout settings', icon: <CircleDollarSign size={17} /> },
  { to: '/creator/profile', label: 'Public profile', icon: <User size={17} /> },
];

export function DashboardShell({ type }: { type: 'customer' | 'creator' }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [switcherOpen, setSwitcherOpen] = useState(false);
  const { profile, creatorProfile, savedDesigns, submissions } = useEcosystem();
  const location = useLocation();
  const nav = type === 'customer' ? customerNav : creatorNav;
  const name = type === 'customer' ? `${profile.firstName} ${profile.lastName}` : creatorProfile.displayName;
  const activeNav = nav.find((item) => item.end ? location.pathname === item.to : location.pathname.startsWith(item.to));

  return (
    <div className={`dashboard-shell dashboard-${type}`}>
      <aside className={`dashboard-sidebar ${menuOpen ? 'is-open' : ''}`}>
        <div className="dashboard-brand">
          <Link to="/"><Wordmark /></Link>
          <button type="button" onClick={() => setMenuOpen(false)} aria-label="Close dashboard menu"><X size={20} /></button>
        </div>
        <div className="product-switcher">
          <button type="button" onClick={() => setSwitcherOpen(!switcherOpen)} aria-expanded={switcherOpen}>
            <span className="switcher-icon">{type === 'customer' ? <User size={17} /> : <Zap size={17} />}</span>
            <span><small>YOUR CHOICE / {type === 'customer' ? 'PERSONAL' : 'CREATOR'}</small><strong>{type === 'customer' ? 'My account' : 'Creator Studio'}</strong></span>
            <ChevronDown size={15} />
          </button>
          <AnimatePresence>{switcherOpen && <motion.div className="switcher-menu" initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}>
            <Link to="/account" onClick={() => setSwitcherOpen(false)}><User size={15} /> Customer account</Link>
            <Link to="/creator" onClick={() => setSwitcherOpen(false)}><Zap size={15} /> Creator Studio</Link>
            <Link to="/studio" onClick={() => setSwitcherOpen(false)}><Palette size={15} /> Design Studio</Link>
            <Link to="/marketplace" onClick={() => setSwitcherOpen(false)}><Compass size={15} /> Marketplace</Link>
          </motion.div>}</AnimatePresence>
        </div>
        <nav className="dashboard-nav" aria-label={`${type} dashboard navigation`}>
          <span className="dashboard-nav-label">Workspace</span>
          {nav.map((item) => <NavLink key={item.to} to={item.to} end={item.end} onClick={() => setMenuOpen(false)} className={({ isActive }) => isActive ? 'active' : ''}>{item.icon}<span>{item.label}</span>{item.label === 'Saved designs' && <b>{savedDesigns.length}</b>}{item.label === 'Submissions' && <b>{submissions.filter((s) => s.status === 'In review').length}</b>}</NavLink>)}
        </nav>
        <div className="dashboard-sidebar-bottom">
          {type === 'creator' && <Link to="/studio/products" className="sidebar-create"><Plus size={16} /> Create in Studio <ArrowUpRight size={14} /></Link>}
          <Link to="/"><ArrowLeft size={15} /> Back to storefront</Link>
          <div className="sidebar-member"><span>{name.split(' ').map((part) => part[0]).join('').slice(0, 2)}</span><div><strong>{name}</strong><small>{type === 'customer' ? 'Inner Circle member' : 'Independent Creator · L3'}</small></div></div>
        </div>
      </aside>
      {menuOpen && <button className="dashboard-menu-scrim" aria-label="Close menu" onClick={() => setMenuOpen(false)} />}
      <div className="dashboard-main">
        <header className="dashboard-topbar">
          <button className="dashboard-menu-button" onClick={() => setMenuOpen(true)} aria-label="Open dashboard menu"><Menu size={20} /></button>
          <div><span>{type === 'customer' ? 'MY ACCOUNT' : 'CREATOR STUDIO'}</span><strong>{activeNav?.label || 'Dashboard'}</strong></div>
          <div className="dashboard-top-actions">
            <Link to="/marketplace/explore" className="topbar-explore">Explore marketplace <ArrowUpRight size={14} /></Link>
            <button aria-label="Notifications" className="dashboard-notification" onClick={() => window.dispatchEvent(new CustomEvent('yc-notification'))}><Bell size={18} /><i /></button>
            <Link to={type === 'customer' ? '/bag' : '/creator/publish'} className="dashboard-primary-action">{type === 'customer' ? <><ShoppingBag size={16} /> Bag</> : <><Plus size={16} /> New design</>}</Link>
          </div>
        </header>
        <main className="dashboard-content"><Outlet /></main>
      </div>
    </div>
  );
}

export function GarmentIllustration({ color = '#edece6', artwork, placement, productType = 'T-Shirt', view = 'front', text, className = '', material = 'jersey' }: {
  color?: string;
  artwork?: string;
  placement?: { x: number; y: number; scale: number; rotation: number };
  productType?: string;
  view?: 'front' | 'back';
  text?: string;
  className?: string;
  material?: string;
}) {
  const uid = useId().replaceAll(':', '');
  const p = placement || { x: 200, y: 184, scale: 1, rotation: 0 };
  const size = 200 * p.scale;
  return (
    <svg className={`garment-illustration ${className}`} viewBox="0 0 600 700" role="img" aria-label={`${view} view of ${productType} with selected artwork`}>
      <defs>
        <linearGradient id={`shade-${uid}`} x1="0" x2="1" y1="0" y2=".35"><stop offset="0" stopColor="#000" stopOpacity=".2"/><stop offset=".22" stopColor="#fff" stopOpacity=".18"/><stop offset=".55" stopColor="#fff" stopOpacity=".03"/><stop offset=".82" stopColor="#000" stopOpacity=".13"/><stop offset="1" stopColor="#000" stopOpacity=".24"/></linearGradient>
        <linearGradient id={`fold-${uid}`} x1="0" y1="0" x2="1" y2="0"><stop stopColor="#fff" stopOpacity="0"/><stop offset=".48" stopColor="#fff" stopOpacity=".12"/><stop offset=".52" stopColor="#000" stopOpacity=".13"/><stop offset="1" stopColor="#000" stopOpacity="0"/></linearGradient>
        <filter id={`shadow-${uid}`} x="-30%" y="-20%" width="160%" height="170%"><feDropShadow dx="0" dy="18" stdDeviation="16" floodColor="#000" floodOpacity=".24"/></filter>
        <filter id={`grain-${uid}`}><feTurbulence type="fractalNoise" baseFrequency=".8" numOctaves="2" seed="8" result="noise"/><feComposite in="noise" in2="SourceGraphic" operator="in" result="texture"/><feBlend in="SourceGraphic" in2="texture" mode="soft-light"/></filter>
        <clipPath id={`body-${uid}`}><path d="M180 90 L235 60 Q300 93 365 60 L420 90 L520 160 L455 255 L410 220 L410 610 Q300 645 190 610 L190 220 L145 255 L80 160 Z"/></clipPath>
        <clipPath id={`print-${uid}`}><rect x="165" y="130" width="270" height="350" rx="18"/></clipPath>
      </defs>
      <ellipse cx="300" cy="640" rx="176" ry="24" fill="#000" opacity=".12"/>
      <g filter={`url(#shadow-${uid})`}>
        {productType === 'Hoodie' && <path d="M217 107 Q204 20 300 18 Q396 20 383 107 L350 139 L250 139Z" fill={color} stroke="#101114" strokeOpacity=".25" strokeWidth="3"/>}
        <path d="M180 90 L235 60 Q300 93 365 60 L420 90 L520 160 L455 255 L410 220 L410 610 Q300 645 190 610 L190 220 L145 255 L80 160 Z" fill={color} stroke="#111" strokeOpacity=".22" strokeWidth="2.5" strokeLinejoin="round"/>
        <path d="M180 90 L235 60 Q300 93 365 60 L420 90 L520 160 L455 255 L410 220 L410 610 Q300 645 190 610 L190 220 L145 255 L80 160 Z" fill={`url(#shade-${uid})`}/>
        {material !== 'smooth' && <path d="M180 90 L235 60 Q300 93 365 60 L420 90 L520 160 L455 255 L410 220 L410 610 Q300 645 190 610 L190 220 L145 255 L80 160 Z" fill="#888" opacity=".07" filter={`url(#grain-${uid})`}/>} 
        <path d="M233 62 Q237 133 300 137 Q363 133 367 62 Q337 81 300 83 Q263 81 233 62Z" fill="#111" opacity={view === 'front' ? '.32' : '.18'}/>
        <path d={view === 'front' ? 'M229 61 Q235 145 300 148 Q365 145 371 61' : 'M232 62 Q300 108 368 62'} fill="none" stroke={color} strokeWidth="18"/>
        <path d={view === 'front' ? 'M229 61 Q235 145 300 148 Q365 145 371 61' : 'M232 62 Q300 108 368 62'} fill="none" stroke="#111" strokeOpacity=".28" strokeWidth="2"/>
        {productType === 'Polo' && view === 'front' && <><path d="M235 71 L285 142 L251 176 L213 96Z M365 71 L315 142 L349 176 L387 96Z" fill={color} stroke="#111" strokeOpacity=".28" strokeWidth="2"/><path d="M300 143 L300 230" stroke="#111" strokeOpacity=".32" strokeWidth="4"/><circle cx="309" cy="177" r="4" fill="#111" opacity=".45"/></>}
        {productType === 'Hoodie' && view === 'front' && <><path d="M245 89 Q248 165 300 176 Q352 165 355 89" fill="none" stroke="#111" strokeOpacity=".28" strokeWidth="3"/><path d="M273 143 L267 270 M327 143 L333 270" stroke="#ddd" strokeOpacity=".5" strokeWidth="3"/><path d="M232 426 Q300 395 368 426 L384 533 Q300 561 216 533Z" fill="none" stroke="#111" strokeOpacity=".22" strokeWidth="3"/></>}
        <path d="M190 220 L181 553 M410 220 L419 553 M196 601 Q300 625 404 601 M89 164 L151 245 M511 164 L449 245" fill="none" stroke="#fff" strokeOpacity=".18" strokeWidth="2"/>
        <path d="M230 165 Q213 343 233 594 M350 174 Q382 365 360 601 M289 153 Q277 333 291 614" fill="none" stroke={`url(#fold-${uid})`} strokeWidth="18" opacity=".48"/>
        {view === 'front' && artwork && <g clipPath={`url(#print-${uid})`}><g transform={`rotate(${p.rotation} ${p.x + size / 2} ${p.y + size / 2})`}><image href={artwork} x={p.x} y={p.y} width={size} height={size} preserveAspectRatio="xMidYMid meet" style={{ mixBlendMode: 'normal' }}/></g></g>}
        {view === 'front' && text && <text x="300" y="340" textAnchor="middle" fill="#f5f5f1" fontFamily="Barlow Condensed, sans-serif" fontWeight="800" fontSize="38" letterSpacing="3">{text}</text>}
        {view === 'back' && artwork && <g clipPath={`url(#print-${uid})`}><g transform={`rotate(${p.rotation} ${p.x + size / 2} ${p.y + size / 2})`}><image href={artwork} x={p.x} y={p.y} width={size} height={size} preserveAspectRatio="xMidYMid meet"/></g></g>}
      </g>
    </svg>
  );
}

export function DesignMockup({ design, view = 'front', className = '' }: { design: MarketplaceDesign; view?: 'front' | 'back'; className?: string }) {
  const productType = design.productId === 1 ? 'Hoodie' : design.productId === 4 ? 'Polo' : 'T-Shirt';
  return <div className={`design-mockup ${className}`} style={{ background: `linear-gradient(145deg, ${design.palette[0]}18, #dfe2df)` }}><span className="mockup-coordinate">YC / {design.id.toUpperCase()}</span><GarmentIllustration color={design.garmentColor} artwork={design.artwork} placement={design.placement} productType={productType} view={view}/><span className="mockup-view">{view === 'front' ? '01 / FRONT' : '02 / BACK'}</span></div>;
}

export function DesignCard({ design, index = 0, compact = false }: { design: MarketplaceDesign; index?: number; compact?: boolean }) {
  const { likedDesignIds, toggleDesignLike } = useEcosystem();
  const creator = CREATORS.find((c) => c.handle === design.creator)!;
  const liked = likedDesignIds.includes(design.id);
  return (
    <motion.article className={`market-design-card ${compact ? 'is-compact' : ''}`} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-30px' }} transition={{ delay: Math.min(index * .05, .25), duration: .55 }}>
      <div className="market-card-visual">
        <Link to={`/marketplace/design/${design.slug}`} aria-label={`View ${design.title}`}><DesignMockup design={design}/></Link>
        <div className="market-card-badges">{design.trending && <span><Zap size={11}/> Trending</span>}{design.featured && !design.trending && <span>Editor’s choice</span>}</div>
        <button className={`market-like ${liked ? 'is-liked' : ''}`} onClick={() => toggleDesignLike(design.id)} aria-label={liked ? `Remove ${design.title} from wishlist` : `Save ${design.title}`} aria-pressed={liked}><Heart size={17} fill={liked ? 'currentColor' : 'none'}/></button>
        <Link className="market-remix" to={`/studio/2d?design=${design.slug}`}>Remix in Studio <ArrowUpRight size={14}/></Link>
      </div>
      <div className="market-card-info">
        <div><span className="market-card-category">{design.category} / {design.colorName}</span><h3><Link to={`/marketplace/design/${design.slug}`}>{design.title}</Link></h3><Link to={`/marketplace/creator/${creator.handle}`} className="market-card-creator">by {creator.name} {creator.verified && <BadgeCheck size={12}/>}</Link></div>
        <div className="market-card-price"><strong>${design.price}</strong><span><Heart size={11}/>{design.likes.toLocaleString()}</span></div>
      </div>
    </motion.article>
  );
}

export function EmptyState({ icon = <Compass size={30}/>, title, copy, action }: { icon?: React.ReactNode; title: string; copy: string; action?: React.ReactNode }) {
  return <div className="p2-empty"><span>{icon}</span><h3>{title}</h3><p>{copy}</p>{action}</div>;
}

export function DownloadDataButton({ data, filename = 'your-choice-data.json', label = 'Export data' }: { data: unknown; filename?: string; label?: string }) {
  const download = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
  };
  return <button className="p2-button secondary" onClick={download}><Download size={15}/>{label}</button>;
}

export function RelatedDesigns({ current, count = 3 }: { current?: string; count?: number }) {
  return <div className="market-grid three">{MARKETPLACE_DESIGNS.filter((d) => d.id !== current).slice(0, count).map((d, i) => <DesignCard key={d.id} design={d} index={i}/>)}</div>;
}

export const phase2PageCount = PHASE2_PAGES.length;
