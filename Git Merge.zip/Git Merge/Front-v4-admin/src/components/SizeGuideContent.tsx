import React, { useMemo, useState } from 'react';
import { Check, Ruler, Sparkles } from 'lucide-react';
import { SIZE_CHARTS, SizeChartCategory } from '../data/catalog';

export function SizeGuideInteractive({
  initialCategory = 't-shirts',
  compact = false,
}: {
  initialCategory?: string;
  compact?: boolean;
}) {
  const normalizedInitial = useMemo<SizeChartCategory['key']>(() => {
    const c = initialCategory.toLowerCase();
    if (c.includes('polo')) return 'polo-shirts';
    if (c.includes('hood') || c.includes('essential') || c.includes('fleece')) return 'hoodies';
    if (c.includes('outer') || c.includes('jacket') || c.includes('bomber')) return 'outerwear';
    return 't-shirts';
  }, [initialCategory]);

  const [activeKey, setActiveKey] = useState<SizeChartCategory['key']>(normalizedInitial);
  const [unit, setUnit] = useState<'cm' | 'in'>('cm');

  // Interactive Fit Finder state
  const [heightCm, setHeightCm] = useState(179);
  const [weightKg, setWeightKg] = useState(74);
  const [drapePref, setDrapePref] = useState<'closer' | 'signature' | 'oversized'>('signature');

  const activeChart = SIZE_CHARTS.find((c) => c.key === activeKey) || SIZE_CHARTS[0];

  const recommendedSize = useMemo(() => {
    let score = (heightCm - 158) * 0.055 + (weightKg - 52) * 0.065;
    if (drapePref === 'closer') score -= 0.75;
    if (drapePref === 'oversized') score += 0.75;

    if (score < 1.1) return 'XS';
    if (score < 2.1) return 'S';
    if (score < 3.15) return 'M';
    if (score < 4.2) return 'L';
    if (score < 5.2) return 'XL';
    return 'XXL';
  }, [heightCm, weightKg, drapePref]);

  const convert = (cmVal: number) =>
    unit === 'cm' ? `${cmVal} cm` : `${(cmVal / 2.54).toFixed(1)} in`;

  return (
    <div className="space-y-8">
      {/* Category & Unit Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[var(--line)] pb-4">
        <div className="category-tabs" role="tablist" aria-label="Garment category">
          {SIZE_CHARTS.map((chart) => (
            <button
              key={chart.key}
              type="button"
              role="tab"
              aria-selected={activeKey === chart.key}
              className={activeKey === chart.key ? 'active' : ''}
              onClick={() => setActiveKey(chart.key)}
            >
              {chart.label.split(' (')[0]}
            </button>
          ))}
        </div>

        <div className="inline-flex border border-[#c5c8bf] bg-[#fafaf7]">
          <button
            type="button"
            onClick={() => setUnit('cm')}
            className={`px-3.5 py-1.5 font-mono text-[10px] uppercase ${
              unit === 'cm' ? 'bg-[#18191a] text-white' : 'text-[#5b6154]'
            }`}
          >
            CM
          </button>
          <button
            type="button"
            onClick={() => setUnit('in')}
            className={`px-3.5 py-1.5 font-mono text-[10px] uppercase ${
              unit === 'in' ? 'bg-[#18191a] text-white' : 'text-[#5b6154]'
            }`}
          >
            INCHES
          </button>
        </div>
      </div>

      {/* Interactive Fit Finder + Measurement Schematic */}
      <div className={`grid gap-6 ${compact ? 'grid-cols-1' : 'lg:grid-cols-12'}`}>
        <div className={`${compact ? '' : 'lg:col-span-7'} editorial-card space-y-5`}>
          <div className="flex items-center justify-between">
            <span className="eyebrow">
              <i /> INTERACTIVE FIT FINDER
            </span>
            <span className="mono text-[9px] text-[#5b6154]">INSTANT STUDIO RECOMMENDATION</span>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="field-group">
              <label className="field-label" htmlFor="fit-height">
                Height: <strong>{heightCm} cm</strong> ({Math.floor(heightCm / 30.48)}&apos;
                {Math.round((heightCm % 30.48) / 2.54)}&quot;)
              </label>
              <input
                id="fit-height"
                type="range"
                min={155}
                max={202}
                value={heightCm}
                onChange={(e) => setHeightCm(Number(e.target.value))}
                className="w-full accent-[var(--blue)]"
              />
            </div>

            <div className="field-group">
              <label className="field-label" htmlFor="fit-weight">
                Weight: <strong>{weightKg} kg</strong> ({Math.round(weightKg * 2.205)} lbs)
              </label>
              <input
                id="fit-weight"
                type="range"
                min={48}
                max={118}
                value={weightKg}
                onChange={(e) => setWeightKg(Number(e.target.value))}
                className="w-full accent-[var(--blue)]"
              />
            </div>
          </div>

          <div className="field-group">
            <span className="field-label">Preferred Silhouette Drape</span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'closer', label: 'Closer / Tailored' },
                { id: 'signature', label: 'Signature Studio' },
                { id: 'oversized', label: 'Extra Oversized' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setDrapePref(opt.id as typeof drapePref)}
                  className={`py-2.5 px-2 border text-[11px] font-medium transition-colors ${
                    drapePref === opt.id
                      ? 'bg-[#18191a] text-white border-[#18191a]'
                      : 'bg-[#fafaf7] border-[#c8cbc2] text-[#494f43]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 bg-[#141619] text-[#f5f5f1] p-4">
            <div className="flex items-center gap-3">
              <Sparkles size={18} className="text-[var(--cyan)] shrink-0" />
              <div>
                <p className="font-mono text-[9px] uppercase tracking-wider text-[#9ba3b0]">
                  Recommended {activeChart.label.split(' (')[0]} Size
                </p>
                <p className="text-sm mt-0.5">
                  Highlighted in the garment spec table below for effortless comparison.
                </p>
              </div>
            </div>
            <div className="px-5 py-2 bg-[var(--blue)] font-mono text-lg font-semibold tracking-tight">
              SIZE {recommendedSize}
            </div>
          </div>
        </div>

        {!compact && (
          <div className="lg:col-span-5 editorial-card flex flex-col justify-between">
            <div className="flex items-center justify-between mb-3">
              <span className="eyebrow">
                <Ruler size={13} className="text-[var(--blue)]" /> GARMENT ARCHITECTURE
              </span>
              <span className="mono text-[9px] text-[#60675a]">FLAT-LAY SPEC</span>
            </div>

            {/* Clean Architectural Garment SVG Diagram */}
            <svg
              viewBox="0 0 280 210"
              className="w-full max-h-44 mx-auto my-2"
              aria-label="Garment measurement points A Chest, B Shoulder, C Length, D Sleeve"
            >
              <path
                d="M95 28 C112 40 168 40 185 28 L244 58 L224 104 L196 92 L196 188 L84 188 L84 92 L56 104 L36 58 Z"
                fill="#e2e5de"
                stroke="#18191a"
                strokeWidth="1.6"
              />
              {/* B Shoulder */}
              <line x1="82" y1="38" x2="198" y2="38" stroke="#2349ed" strokeWidth="1.5" strokeDasharray="4 3" />
              <circle cx="140" cy="38" r="8" fill="#2349ed" />
              <text x="140" y="41" textAnchor="middle" fill="#fff" fontSize="8" fontFamily="IBM Plex Mono">
                B
              </text>
              {/* A Chest */}
              <line x1="84" y1="98" x2="196" y2="98" stroke="#2349ed" strokeWidth="1.5" />
              <circle cx="140" cy="98" r="8" fill="#2349ed" />
              <text x="140" y="101" textAnchor="middle" fill="#fff" fontSize="8" fontFamily="IBM Plex Mono">
                A
              </text>
              {/* C Length */}
              <line x1="166" y1="32" x2="166" y2="188" stroke="#18191a" strokeWidth="1.3" strokeDasharray="3 3" />
              <circle cx="166" cy="148" r="8" fill="#18191a" />
              <text x="166" y="151" textAnchor="middle" fill="#fff" fontSize="8" fontFamily="IBM Plex Mono">
                C
              </text>
              {/* D Sleeve */}
              <line x1="198" y1="42" x2="238" y2="82" stroke="#18191a" strokeWidth="1.3" />
              <circle cx="220" cy="63" r="8" fill="#18191a" />
              <text x="220" y="66" textAnchor="middle" fill="#fff" fontSize="8" fontFamily="IBM Plex Mono">
                D
              </text>
            </svg>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[var(--line)] text-[11px] text-[#555b4f]">
              <span>
                <strong className="font-mono text-[var(--blue)]">A</strong> Chest Circumference
              </span>
              <span>
                <strong className="font-mono text-[var(--blue)]">B</strong> Shoulder Seam-to-Seam
              </span>
              <span>
                <strong className="font-mono">C</strong> High-Point Shoulder Length
              </span>
              <span>
                <strong className="font-mono">D</strong> Outer Sleeve Length
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Measurement Data Table */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-lg font-semibold tracking-tight">{activeChart.label}</h3>
          <p className="text-xs text-[#60675a]">{activeChart.fitSummary}</p>
        </div>

        <div className="overflow-x-auto border border-[var(--line)]">
          <table className="data-table">
            <thead>
              <tr>
                <th>YC Size</th>
                <th>A · Chest</th>
                <th>B · Shoulder</th>
                <th>C · Body Length</th>
                <th>D · Sleeve</th>
                <th>Fit Match</th>
              </tr>
            </thead>
            <tbody>
              {activeChart.rowsCm.map((row) => {
                const isRec = row.size === recommendedSize;
                return (
                  <tr key={row.size} className={isRec ? 'is-highlighted' : ''}>
                    <td className="font-mono font-semibold">{row.size}</td>
                    <td className="font-mono">{convert(row.chest)}</td>
                    <td className="font-mono">{convert(row.shoulder)}</td>
                    <td className="font-mono">{convert(row.length)}</td>
                    <td className="font-mono">{convert(row.sleeve)}</td>
                    <td>
                      {isRec ? (
                        <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase text-[var(--blue)]">
                          <Check size={13} /> Recommended
                        </span>
                      ) : (
                        <span className="font-mono text-[10px] text-[#7a8073]">Standard Spec</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
