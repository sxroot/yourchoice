# YOUR CHOICE Backend Capability and Architecture Audit

**Audit type:** Backend capability audit  
**Mode:** Read only  
**Repository:** `D:\Antigravity\Your Choice`  
**Audit date:** 2026-11-18 (Asia/Dhaka)  
**Evidence basis:** checked-in source, schemas, migrations, tests, configuration, and documentation. No application was started and no tests or database operations were run. Source locations below are repository relative; line numbers were omitted where a stable named declaration is more useful.

## 1. Executive summary

This is a pnpm TypeScript monorepo. The executable backend is an Express 5 API in `apps/api`, with Drizzle ORM over MariaDB/MySQL and schema/migrations in `database`. The runtime mounts `/api/v1` by default (`API_PREFIX` is configurable). There is substantial implementation for session authentication, profiles and addresses, catalog administration, guest/authenticated carts, checkout/order management, payment webhook verification, shipping quotes, design assets/design records/print exports, health checks, and audit event recording.

The repository also contains clear scope boundaries. Creator functionality is one workspace marker endpoint; there are no creator profile, marketplace listing, submission/approval, earnings, rewards, or payout tables/services. There is no production workflow, QC, fulfillment/shipment tracking, coupon, review, CMS, SEO, analytics, or notification subsystem in executable backend code. Product stock is stored on variants but no stock reservation/deduction workflow is apparent in checkout repositories. Payment gateway implementations cover webhook validation and status settlement, not payment initiation. The runtime selects `LocalDiskStorageService` regardless of `STORAGE_DRIVER`; S3 settings are parsed but no S3 adapter is wired.

Tests exist across API, validation, utilities, and browser E2E suites. They were not executed as part of this read-only audit. Accordingly endpoint statuses in the inventory use `IMPLEMENTED_NOT_TESTED` unless explicit test files are listed; none are called `IMPLEMENTED_AND_TESTED` based on this audit alone.

## 2. Actual repository architecture

```text
apps/api       Express API, modules/routes/services/repositories/middleware
apps/web       Vite/React storefront and admin/creator-facing UI
packages/      shared-types, validation (Zod), shared-utils, UI
database/      Drizzle schema, SQL migrations, scripts, seeds
infrastructure/ Docker Compose for MariaDB
e2e/           Playwright browser tests
docs/          architecture, API intent, phase plans, deployment docs
```

`apps/api/src/server.ts` constructs the environment, logger, MariaDB pool and app, listens, checks DB health after listening, and handles SIGINT/SIGTERM shutdown. `apps/api/src/app.ts` wires middleware and dependency-injected services/repositories, registers health separately and all API modules under the configured prefix, then not-found/error handlers. Repository interfaces have Drizzle implementations and test/in-memory substitutes. If a DB repository is not configured in app construction, unavailable repository implementations throw service-unavailable errors.

### Technology stack

| Concern | Observed implementation |
|---|---|
| Runtime/language | Node.js `>=20.19.0`, TypeScript 5.9, ESM; pnpm 10 workspace |
| API | Express 5, Zod 4 validation, Helmet, CORS, express-rate-limit, Pino/pino-http |
| Database | MariaDB/MySQL via mysql2 and Drizzle ORM/Drizzle Kit; 5 SQL migrations in migration journal |
| Web | React/Vite (see `apps/web/package.json`), TypeScript |
| Image processing | Sharp, `file-type`; server design rasterizer |
| Upload parsing/storage | Multer memory upload; local disk storage service |
| Tests | Vitest API/package tests; Supertest; Playwright E2E |
| Jobs/cache | No queue or job runner found. Redis env schema exists but no Redis client/consumer found. |
| Deployment | Docker Compose MariaDB; deployment/production docs; no API/web Dockerfile or deployment workflow identified in repository file inventory. |

Evidence: root and app `package.json`, `pnpm-workspace.yaml`, `apps/api/src/server.ts`, `apps/api/src/app.ts`, `apps/api/src/config/env.ts`, `database/drizzle.config.ts`, `database/migrations/meta/_journal.json`, `infrastructure/docker/docker-compose.mariadb.yml`.

## 3. Complete backend feature inventory

Status vocabulary follows the request. “Implemented, not tested” means executable source exists; it is not a claim of runtime health. Evidence names are relative paths.

| Feature ID | Module / feature | What it does and implementation evidence | Tables / APIs | Roles, dependencies, status / tests |
|---|---|---|---|---|
| BE-001 | Health and readiness | Liveness, DB health/readiness via `modules/health/{health.routes,health.controller,health.service}.ts`, `database/health.ts` | none; `/api/v1/health[/{live,ready}]` | public; DB for ready; IMPLEMENTED_NOT_TESTED; `tests/health.test.ts` |
| BE-002 | Authentication / sessions | Registration, login, current session, logout, logout all; password hashing and opaque hashed session tokens in `modules/auth/*` | users, user_profiles, roles, permissions, role_permissions, user_roles, sessions; `/auth/*` | public/login then authenticated; auth.test.ts |
| BE-003 | CSRF, auth guards, rate limiting | Session attachment; role/permission/ownership checks; CSRF/origin on stateful routes; auth limiters | sessions; middleware/auth.ts, csrf.ts, rate-limit.ts | route-specific; IMPLEMENTED_NOT_TESTED; auth-rbac E2E/auth tests |
| BE-004 | Profile and user lookup | Own profile read/update and public-ID lookup guarded by owner/admin | users, user_profiles; `/users/me`, `/users/:userPublicId` | authenticated; auth service; auth.test.ts |
| BE-005 | Address book | List/create/update/soft-delete own addresses; ownership enforced in service/repository | user_addresses; `/users/me/addresses*` | customer/creator/staff/etc own profile permission; addresses.test.ts |
| BE-006 | Role assignment/admin overview | Small user sample overview and super-admin role replacement | identity/RBAC tables; `/admin/overview`, `/admin/users/:id/roles` | admin/super_admin; auth.test.ts |
| BE-007 | Catalog browse | Active categories and product listing/detail with localized metadata, variants, images, print areas | product_categories, products, product_variants, product_images, product_print_areas; `/categories`, `/products` | public; catalog.test.ts; search/list filters schema bounded |
| BE-008 | Catalog administration | Category/product CRUD-like operations; image/variant/print-area management, audit calls | catalog tables; `/admin/categories*`, `/admin/products*` | admin/super_admin via `catalog:write`; catalog.test.ts |
| BE-009 | Cart | Guest cookie token hash or authenticated cart, add/update/remove/clear and merge after login | carts, cart_items; `/cart*` | guest or authenticated; catalog/pricing; commerce.test.ts |
| BE-010 | Checkout and orders | Checkout from cart, address/shipping/payment validation, order snapshot, customer list/detail/cancel and admin status transitions | orders, order_items, order_status_history, payment_transactions, carts/cart_items, user_addresses | guest checkout and customer; staff/admin order actions; commerce.test.ts |
| BE-011 | Shipping rates | Zone listing and quote with threshold behavior | shipping_zones; `/shipping/zones`, `/shipping/quote` | public; commerce.test.ts |
| BE-012 | Payment webhook verification | bKash/Nagad/SSLCommerz webhook signature/payload verification and idempotent update path | payment_transactions/orders; `/payments/webhooks/:gateway` | provider signature; payment.service.ts, payment-gateway.ts; commerce tests |
| BE-013 | Design studio persistence | Owner-scoped asset upload/list, design CRUD/soft delete, version/history, print export rasterization | design_assets, designs, design_versions, design_print_exports; `/designs*` | authenticated; sharp/rasterizer/catalog/cart/storage; designs.test.ts |
| BE-014 | Creator workspace | Returns caller identity/roles/capabilities and fixed `studioStatus: ready-for-phase-2` | no creator tables; `/creator/workspace` | creator/admin/super_admin + permission; route is a marker, PARTIALLY_IMPLEMENTED; no dedicated tests found |
| BE-015 | Audit log writes | Append event records; catalog/order services call audit service | audit_logs; indirect | DB optional; audit service/repository; no read API discovered; IMPLEMENTED_NOT_TESTED |
| BE-016 | Admin orders | Search/list/detail/status update/COD settlement | commerce tables; `/admin/orders*` | staff/admin/super_admin with permissions; commerce.test.ts |
| BE-017 | Storage | Local disk asset persistence and retrieval metadata; upload path uses Multer and file-type/size checks | design_assets (metadata), filesystem blobs | authenticated design routes; IMPLEMENTED_NOT_TESTED; storage lifecycle/remote storage absent |
| BE-018 | Seed/config data | RBAC, settings, catalog, shipping seed scripts | identity, settings, catalog, shipping tables | operational scripts, not public API; seed execution not verified |

Areas investigated but not implemented in executable code: creator profiles/marketplace/approval, rewards/commission/creator earnings/payout, inventory ledger/reservation, production/DTF/heat press/QC/packaging, shipment tracking, refunds, notifications, reviews, coupons, CMS, SEO, analytics/reporting, system settings administration, audit-log querying. Some appear in docs or role/permission seeds only; classify as DOCUMENTED_ONLY where there is a matching design statement, otherwise NOT_IMPLEMENTED. See section 17.

## 4. Complete API endpoint inventory

Default base prefix `/api/v1`; deployments can override `API_PREFIX`. Every listed endpoint is registered by `apps/api/src/app.ts` except webhook routes, which are mounted at `${API_PREFIX}/payments/webhooks` before the common API router. Endpoint schema names are defined in `packages/validation/src/*.ts`. Success responses use `sendSuccess` envelope; error envelope is implemented by middleware. Request query/body fields are summarized as schema names and principal concepts to avoid duplicating the schema catalog. All are `IMPLEMENTED_NOT_TESTED` unless a named test supports source-level test coverage; no test suite was executed.

| API ID | Method / path | Handler; request validation | Auth / roles | Operation / status; test evidence |
|---|---|---|---|---|
| API-001 | GET `/api/v1/health` | health controller; none | public | service + DB status; tests/health.test.ts |
| API-002 | GET `/api/v1/health/live` | health controller | public | liveness; tests/health.test.ts |
| API-003 | GET `/api/v1/health/ready` | health controller | public | readiness DB ping; tests/health.test.ts |
| API-004 | GET `/api/v1/auth/csrf` | auth router | public | CSRF token/cookie; tests/auth.test.ts |
| API-005 | GET `/api/v1/auth/me` | auth router | optional session | current identity; tests/auth.test.ts |
| API-006 | POST `/api/v1/auth/register` | `registerRequestSchema` | public, rate limited | registration; tests/auth.test.ts |
| API-007 | POST `/api/v1/auth/login` | `loginSchema` | public, rate limited | login/session; tests/auth.test.ts |
| API-008 | POST `/api/v1/auth/logout` | none | authenticated | revoke current session; tests/auth.test.ts |
| API-009 | POST `/api/v1/auth/logout-all` | none | authenticated | revoke all sessions; tests/auth.test.ts |
| API-010 | GET `/api/v1/users/me` | none | auth + `profile:read:own` | own profile; tests/auth.test.ts |
| API-011 | PATCH `/api/v1/users/me` | `updateProfileSchema` | auth + `profile:write:own` | update profile; tests/auth.test.ts |
| API-012 | GET `/api/v1/users/me/addresses` | none | auth + own read | list addresses; tests/addresses.test.ts |
| API-013 | POST `/api/v1/users/me/addresses` | `createAddressSchema` | auth + own write | create; tests/addresses.test.ts |
| API-014 | PATCH `/api/v1/users/me/addresses/:addressPublicId` | params + `updateAddressSchema` | auth + own write | update; tests/addresses.test.ts |
| API-015 | DELETE `/api/v1/users/me/addresses/:addressPublicId` | params | auth + own write | soft-delete; tests/addresses.test.ts |
| API-016 | GET `/api/v1/users/:userPublicId` | `userPublicIdParamSchema` | auth; owner or admin/super_admin | user DTO; tests/auth.test.ts |
| API-017 | GET `/api/v1/categories` | none | public | active categories; tests/catalog.test.ts |
| API-018 | GET `/api/v1/products` | `catalogQuerySchema` | public | product list/query; tests/catalog.test.ts |
| API-019 | GET `/api/v1/products/:slug` | `productSlugParamSchema` | public | product detail; tests/catalog.test.ts |
| API-020 | GET `/api/v1/shipping/zones` | none | public | active zones; tests/commerce.test.ts |
| API-021 | GET `/api/v1/shipping/quote` | `shippingQuoteQuerySchema` (division, subtotal) | public | quote; tests/commerce.test.ts |
| API-022 | GET `/api/v1/cart` | cookie/session context | guest or auth | read cart; tests/commerce.test.ts |
| API-023 | POST `/api/v1/cart/items` | `addCartItemSchema` | guest or auth | add/merge line; tests/commerce.test.ts |
| API-024 | PATCH `/api/v1/cart/items/:itemId` | `cartItemIdParamSchema` + `updateCartItemSchema` | guest or auth | set quantity; tests/commerce.test.ts |
| API-025 | DELETE `/api/v1/cart/items/:itemId` | `cartItemIdParamSchema` | guest or auth | remove line; tests/commerce.test.ts |
| API-026 | DELETE `/api/v1/cart` | none | guest or auth | clear cart; tests/commerce.test.ts |
| API-027 | GET `/api/v1/designs/assets` | optional query | auth | owner asset list; tests/designs.test.ts |
| API-028 | POST `/api/v1/designs/assets/upload` | multipart file; upload limiter | auth | image validation/storage; tests/designs.test.ts |
| API-029 | GET `/api/v1/designs/assets/:assetId/preview` | `designAssetIdParamSchema` | auth; owner/admin/fulfillment policy in service | downscaled private preview; tests/designs.test.ts |
| API-030 | GET `/api/v1/designs/exports/:exportId/download` | `designExportParamSchema` | auth; owner/admin/fulfillment policy in service | protected print master download; tests/designs.test.ts |
| API-031 | GET `/api/v1/designs` | `designListQuerySchema` | auth | owner designs; tests/designs.test.ts |
| API-032 | POST `/api/v1/designs` | `createDesignSchema` | auth | create design/version; tests/designs.test.ts |
| API-033 | GET `/api/v1/designs/:designId` | ID schema | auth | owned detail; tests/designs.test.ts |
| API-034 | PUT `/api/v1/designs/:designId` | ID + update schema | auth | update/version; tests/designs.test.ts |
| API-035 | DELETE `/api/v1/designs/:designId` | ID schema | auth | soft-delete; tests/designs.test.ts |
| API-036 | GET `/api/v1/designs/:designId/surfaces/:surfaceKey/preview` | `designSurfaceExportParamSchema` | auth; owner/admin/fulfillment policy in service | downscaled rendered preview; tests/designs.test.ts |
| API-037 | POST `/api/v1/designs/:designId/surfaces/:surfaceKey/export-print-master` | `designSurfaceExportParamSchema` | auth; rate limited; service role policy | generate 300 DPI print master; tests/designs.test.ts |
| API-038 | POST `/api/v1/designs/:designId/add-to-cart` | cart/customization schema | auth | design/cart integration; tests/designs.test.ts |
| API-039 | GET `/api/v1/checkout/options` | none | public | shipping/payment choices; tests/commerce.test.ts |
| API-040 | GET `/api/v1/orders` | `paginationQuerySchema` | auth | own paginated order list; tests/commerce.test.ts |
| API-041 | POST `/api/v1/orders` | `createOrderSchema`; limiter | optional auth | checkout, guest receipt cookie; tests/commerce.test.ts |
| API-042 | GET `/api/v1/orders/:orderNumber` | order number | owner/guest receipt/admin checks in service | detail; tests/commerce.test.ts |
| API-043 | POST `/api/v1/orders/:orderNumber/cancel` | cancel schema | auth owner | cancel only allowed states; tests/commerce.test.ts |
| API-044 | POST `/api/v1/payments/webhooks/:gateway` | gateway + payload schemas, signature header | provider signature, no browser CSRF | verify and settle webhook; tests/commerce.test.ts |
| API-045 | GET `/api/v1/creator/workspace` | none | creator/admin/super_admin + `creator:studio:access` | capability marker only; no dedicated test |
| API-046 | GET `/api/v1/admin/overview` | none | admin/super_admin + `users:read` | recent users sample; tests/auth.test.ts |
| API-047 | PATCH `/api/v1/admin/users/:userPublicId/roles` | params + `updateUserRolesSchema` | super_admin + `roles:manage` | role replacement; tests/auth.test.ts |
| API-048 | GET `/api/v1/admin/categories` | none | staff/admin/super_admin + `catalog:read` | category management list; tests/catalog.test.ts |
| API-049 | POST `/api/v1/admin/categories` | category create schema | admin + catalog permission | create; tests/catalog.test.ts |
| API-050 | PATCH `/api/v1/admin/categories/:categoryPublicId` | params/body schema | admin + catalog permission | update; tests/catalog.test.ts |
| API-051 | GET `/api/v1/admin/products` | admin list query | admin + catalog permission | internal list; tests/catalog.test.ts |
| API-052 | GET `/api/v1/admin/products/:productPublicId` | params | admin + catalog permission | internal detail; tests/catalog.test.ts |
| API-053 | POST `/api/v1/admin/products` | product create schema | admin + catalog permission | create; tests/catalog.test.ts |
| API-054 | PATCH `/api/v1/admin/products/:productPublicId` | params/body schema | admin + catalog permission | update; tests/catalog.test.ts |
| API-055 | DELETE `/api/v1/admin/products/:productPublicId` | params | admin + catalog permission | soft-delete; tests/catalog.test.ts |
| API-056 | POST `/api/v1/admin/products/:productPublicId/images` | image schema | admin + catalog permission | image metadata; tests/catalog.test.ts |
| API-057 | DELETE `/api/v1/admin/products/:productPublicId/images/:imagePublicId` | params | admin + catalog permission | delete image record; tests/catalog.test.ts |
| API-058 | POST `/api/v1/admin/products/:productPublicId/variants` | variant schema | admin + catalog permission | create variant; tests/catalog.test.ts |
| API-059 | PATCH `/api/v1/admin/products/:productPublicId/variants/:variantPublicId` | params/body schema | admin + catalog permission | update variant/stock quantity; tests/catalog.test.ts |
| API-060 | DELETE `/api/v1/admin/products/:productPublicId/variants/:variantPublicId` | params | admin + catalog permission | soft-delete; tests/catalog.test.ts |
| API-061 | PUT `/api/v1/admin/products/:productPublicId/print-areas` | print area schema | admin + catalog permission | create/replace/upsert print areas; tests/catalog.test.ts |
| API-062 | PATCH `/api/v1/admin/products/:productPublicId/print-areas/:printAreaPublicId` | params/body schema | admin + catalog permission | update; tests/catalog.test.ts |
| API-063 | DELETE `/api/v1/admin/products/:productPublicId/print-areas/:printAreaPublicId` | params | admin + catalog permission | delete; tests/catalog.test.ts |
| API-064 | GET `/api/v1/admin/orders` | `adminOrderListQuerySchema` | staff/admin/super_admin + `orders:read:all` | filtered/paginated admin list; tests/commerce.test.ts |
| API-065 | GET `/api/v1/admin/orders/:orderNumber` | order number | staff/admin/super_admin + read all | detail; tests/commerce.test.ts |
| API-066 | PATCH `/api/v1/admin/orders/:orderNumber/status` | status schema | staff/admin/super_admin + `orders:write` | transition and audit; tests/commerce.test.ts |
| API-067 | POST `/api/v1/admin/orders/:orderNumber/payment-settlement` | COD settlement schema | staff/admin/super_admin + `orders:write` | mark COD payment; tests/commerce.test.ts |

**Coverage notes:** Design versions are stored and surfaced through design data, but no standalone versions-list endpoint is registered. API-027–038 exact request contract details reside in `packages/validation/src/designs.ts`; API-048–063 in `admin-catalog.routes.ts` and `packages/validation/src/catalog.ts`. The route inventory includes no password reset/email verification, role CRUD, audit query, settings, creator marketplace, payout, refund, shipment, production, or inventory movement endpoints. Similar route concepts in `docs/API.md` are proposals/planned groups, not registered endpoints.

### API quality and frontend linkage

The web app has dedicated API clients for auth, catalog, commerce, addresses, design studio, and health (`apps/web/src/features/*/*.api.ts`, `apps/web/src/services/*`). Admin order/catalog panels are present. This is evidence of consumers for those modules; absence of a located consumer is marked unknown rather than unused. Common success envelope comes from `apps/api/src/utils/api-response.ts`. Validation is centralized in `middleware/validate.ts`. Pagination is present for orders/admin orders and catalog query, but route coverage is not uniformly paginated (e.g. addresses/assets/design versions and categories). Search/filter/sort breadth is module-specific. Guest cart and checkout responses include cookie side effects; checkout option and shipping reads are public.

## 5. Database table inventory

All current table declarations are in `database/schema/*.ts`; Drizzle migrations journal contains five SQL migrations (`0000`–`0004`). This inventory reports declared keys and links at a functional level. Exact field definitions, index names, deletion policy, and defaults are authoritative in the cited schema source. The schema has no dedicated creator/marketplace/reward/payout/inventory-ledger/production/shipment/refund/review/coupon/CMS tables.

| Table | Purpose / key facts | Foreign-key relations | Application use / feature |
|---|---|---|---|
| users | identity, email/password hash, state, public ID | parent of profiles, user-role, sessions, addresses, carts/orders/designs/assets/audit actor | active identity |
| user_profiles | profile name/phone/localization fields | user_id → users | active profile |
| roles | role code/name | role_permissions, user_roles | active RBAC |
| permissions | permission code/module | role_permissions | active RBAC |
| role_permissions | role-permission join | roles, permissions | seeded and read for effective auth |
| user_roles | user-role join | users, roles | active auth/admin |
| sessions | hashed token, expiry/revocation/client metadata | user_id → users | active auth |
| user_addresses | Bangladesh address records, soft delete/default | user_id → users | active address/checkout |
| product_categories | hierarchy, bilingual category, soft-delete | self parent; products | active catalog |
| products | product metadata/pricing/status | category_id; variants/images/print areas/order item snapshots | active catalog/admin/commerce |
| product_variants | SKU, size/color, price override, stock_quantity | product_id; images/cart items/order item snapshot relation | active; stock field not a stock ledger |
| product_images | URL, view, alt text, primary order | product_id, optional variant_id | active catalog |
| product_print_areas | 2D bounds, physical dims, DPI, UV metadata, surcharge | product_id | active catalog/design export |
| shipping_zones | divisions, fees, thresholds, estimates | none | active quote/checkout |
| carts | user or guest token hash, expiry | optional user_id; cart_items | active cart |
| cart_items | variant, quantity, price and design snapshot | cart_id, variant_id; optional design public ID is not declared FK | active cart/checkout |
| orders | number, buyer, address/shipping/payment/status/amount snapshots | optional user, shipping zone; order_items/history/payment transactions | active checkout/admin |
| order_items | product/variant/design snapshots, quantity and production spec JSON | order_id; optional catalog references (check exact schema declaration) | active order |
| order_status_history | state transition/audit actor/reason | order_id, optional actor | active order service |
| payment_transactions | provider reference/status/amount/idempotency/payload metadata | order_id | active webhook/COD settlement |
| design_assets | owner, MIME/size/hash/storage key and metadata | owner user; designs/versions may refer by IDs/public IDs per schema | active upload/design |
| designs | owner, title/state/current document and soft deletion | owner user; versions/exports | active design service |
| design_versions | immutable-ish numbered document/version snapshots | design_id, actor; linked assets via JSON/reference fields as declared | active versioning |
| design_print_exports | design/version export config and print asset metadata/status | design/version, owner per schema | active export record |
| audit_logs | append-only action/entity/actor/request metadata | nullable actor user | active writer; no read endpoint found |
| system_settings | key/value/config settings | no declared user relation | table and seed exist; no runtime settings API identified |

The above list is 26 declared tables. Confirm exact index/unique/FK declarations directly in `database/schema/{identity,catalog,commerce,designs,audit,system-settings}.ts`; migration journal establishes migrations exist, but this read-only review did not compare every generated SQL statement against each declaration or apply migrations.

## 6. Entity relationship diagram

```mermaid
erDiagram
  USERS ||--o| USER_PROFILES : profile
  USERS ||--o{ USER_ROLES : has
  ROLES ||--o{ USER_ROLES : assigned
  ROLES ||--o{ ROLE_PERMISSIONS : grants
  PERMISSIONS ||--o{ ROLE_PERMISSIONS : included
  USERS ||--o{ SESSIONS : authenticates
  USERS ||--o{ USER_ADDRESSES : owns
  PRODUCT_CATEGORIES ||--o{ PRODUCT_CATEGORIES : parent_of
  PRODUCT_CATEGORIES ||--o{ PRODUCTS : classifies
  PRODUCTS ||--o{ PRODUCT_VARIANTS : offers
  PRODUCTS ||--o{ PRODUCT_IMAGES : displays
  PRODUCT_VARIANTS o|--o{ PRODUCT_IMAGES : variant_images
  PRODUCTS ||--o{ PRODUCT_PRINT_AREAS : configures
  USERS o|--o{ CARTS : owns
  CARTS ||--|{ CART_ITEMS : contains
  PRODUCT_VARIANTS ||--o{ CART_ITEMS : selected
  USERS o|--o{ ORDERS : places
  SHIPPING_ZONES o|--o{ ORDERS : quotes
  ORDERS ||--|{ ORDER_ITEMS : contains
  ORDERS ||--o{ ORDER_STATUS_HISTORY : records
  ORDERS ||--o{ PAYMENT_TRANSACTIONS : paid_by
  USERS ||--o{ DESIGNS : authors
  USERS ||--o{ DESIGN_ASSETS : uploads
  DESIGNS ||--o{ DESIGN_VERSIONS : versions
  DESIGNS ||--o{ DESIGN_PRINT_EXPORTS : exports
  DESIGN_VERSIONS o|--o{ DESIGN_PRINT_EXPORTS : source_version
  USERS o|--o{ AUDIT_LOGS : actor
  %% cart_items.design_public_id and design/asset JSON references are logical references where no FK is declared.
  %% system_settings has no declared relation.
```

## 7. Business logic and workflow inventory

| Workflow ID | Event and sequence | APIs/services/data | Permissions, failure/rollback, status |
|---|---|---|---|
| WF-BE-001 | Register: validate input → hash password → create user/profile/default role/session → set cookie | POST auth/register; AuthService/identity repo; identity tables | public, limiter; DB write errors propagate; tests/auth.test.ts exists; IMPLEMENTED_NOT_TESTED |
| WF-BE-002 | Login/session: validate credentials → verify password → create session with token hash → cookie; attached middleware resolves active session; logout revokes | auth endpoints; AuthService/tokens | public or authenticated; sessions; IMPLEMENTED_NOT_TESTED |
| WF-BE-003 | Guest cart: cookie token hash locates/creates cart → validate active variant and quantity → price snapshot/merge line; login merge is invoked from auth flow | cart and auth; CartService/commerce repo | guest/auth; cart tables; transaction behavior in repo; IMPLEMENTED_NOT_TESTED |
| WF-BE-004 | Checkout: validate body/cart/address/shipping/payment options → calculate totals → transactionally snapshot order/items and clear cart; guest receives signed receipt cookie | POST orders; OrderService, Cart/Shipping/Payment/Address services; order tables | guest/auth; transactional repository implementation; no independent refund/stock reserve; IMPLEMENTED_NOT_TESTED |
| WF-BE-005 | Gateway confirmation: verify provider HMAC/signature and payload → map reference → idempotently apply payment status/order update | payment webhook; PaymentService/adapters/repository | provider secret; invalid signatures rejected; tests/commerce.test.ts; IMPLEMENTED_NOT_TESTED |
| WF-BE-006 | COD settlement/admin status: role+permission check → validate transition/settlement → transaction/history/audit | admin order endpoints; OrderService | staff/admin/super_admin; transactional; tests/commerce.test.ts |
| WF-BE-007 | Catalog admin: validate request → service checks references/business constraints → Drizzle writes category/product/image/variant/print area → audit event | `/admin/*`; CatalogService/repository/AuditService | catalog write; mutation mostly implemented; tests/catalog.test.ts |
| WF-BE-008 | Design upload/create/update/export: authenticated multipart upload validation → local storage and DB metadata → design/version persistence → print-area-based raster export and recorded output | `/designs/*`; DesignService/rasterizer/storage | auth + ownership; cleanup/compensation path should be checked per each service method; tests/designs.test.ts |
| WF-BE-009 | Address CRUD: authenticated user ID scopes list/find/update/delete; deletion is soft | `/users/me/addresses*`; AddressService/repository | own profile permissions; tests/addresses.test.ts |

No executable evidence found for marketplace submission/approval, cancellation-to-refund, production queue, inventory reservation/deduction, creator rewards/payout, shipment fulfillment, QC, or notification workflow. Product stock can be edited as a variant attribute; that alone does not implement inventory management.

## 8. Authentication, authorization, and role matrix

Sessions use opaque random browser tokens; only token hashes are persisted (`modules/auth/tokens.ts`, `identity` schema). Cookies, expiry, logout and active session resolution are handled by auth service/repository. Stateful router applies CSRF/origin middleware before attaching auth; webhook router is separately mounted and uses provider signature verification. Common stack: request ID/context, Pino request log, Helmet, credentialed allowlist CORS, JSON/urlencoded parsers, validation, not-found/error handlers. `requireRoles`, `requirePermissions`, `requireOwnershipOrRole` live in `middleware/auth.ts`.

Default seeded roles/permission definitions are in `database/rbac-catalog.ts`; actual checks on routes are explicit. Role names alone do not imply an operation.

| Role | Backend-enforced capabilities evidenced | Not evidenced |
|---|---|---|
| guest | public catalog/shipping/checkout options; guest cart/checkout; guest receipt access | profile, designs, order list/cancel, creator/admin operations |
| customer | own profile/address, authenticated cart/orders/designs; order cancellation for owned order | admin catalog/order management |
| creator | customer own-account actions plus gated `/creator/workspace`, design APIs | creator profile/listing/submission approval/earnings/payout APIs |
| staff | admin order list/detail/status/COD settlement; role grants include users read | catalog write route access (route permission requires catalog:write; default staff does not get it) |
| admin | catalog write, overview, order operations, user read/manage as route permits, audit write side effects | role assignment (super_admin only); no audit read API found |
| super_admin | all default permissions; role replacement route | no settings/audit query route despite permissions/table |

Role/permission CRUD APIs are absent; seeds and a super-admin role replacement endpoint exist. Suspensions are described by permission catalog but no user suspension route was found.

## 9. File storage and upload architecture

`modules/designs/designs.routes.ts` uses Multer memory handling and per-route limiter, then validation/service logic. `modules/storage/storage.service.ts` implements `LocalDiskStorageService`; app wiring always defaults to it with `STORAGE_LOCAL_ROOT`. Design records store asset/export metadata and storage references. Sharp and `file-type` dependencies support image handling/rasterization. `STORAGE_DRIVER=s3` and S3 env values are validated in `config/env.ts`, but `app.ts` has no S3 provider selection and no S3 implementation/import. Public products’ image URLs are stored as URL strings; no image upload API for catalog images was found (catalog admin accepts image metadata/URLs).

## 10. External integrations

- MariaDB/MySQL is the only implemented infrastructure service integration.
- bKash, Nagad and SSLCommerz are named payment gateways and webhook adapters. The implemented surface is incoming webhook verification/settlement; outbound payment initiation/redirect/session creation is not found.
- S3 is configuration intent only; no wired storage adapter found.
- Redis is optional configuration intent only; no Redis dependency/client/job queue found.
- No shipping carrier, email/SMS, analytics, marketplace, or notification provider integration found.

## 11. Admin, customer, and creator capabilities

**Admin:** user overview sample and role assignment (super-admin); catalog/category/product/variant/image/print-area management; admin order listing/details/status and COD settlement. Audit writes occur, but no audit query UI/API was found. No settings API or broader dashboard analytics found.

**Customer:** register/login, own profile/address, browse products, cart, checkout, orders/list/detail/cancel, design studio APIs and print export. Guest checkout is also present. Refunds are not.

**Creator:** role/permission seed and one gated workspace response. Creator-specific persistence, marketplace endpoints, submission/approval, creator dashboard/earnings/payout are absent. Design studio is shared auth-gated capability; no creator ownership model beyond user-owned design records identified.

## 12. Frontend integration readiness

Frontend API clients found: `apps/web/src/features/auth/auth.api.ts`, `catalog/catalog.api.ts`, `commerce/commerce.api.ts`, `addresses/addresses.api.ts`, `design-studio/design-studio.api.ts`, and `services/health.service.ts`. Pages/routes include shop/product, cart/checkout/orders, account/login/register, studio, admin overview, creator workspace. E2E files exercise foundation, auth/RBAC, storefront catalog, commerce checkout, design studio 2D/3D. These files establish known consumers, but this audit did not compare every runtime call to every backend response.

| Module | API available / auth | Data and operations | Gaps / consumer status |
|---|---|---|---|
| Identity/profile | auth public/session; users authenticated | session, profile, address CRUD, role assignment | no password reset/email verification; frontend consumers known |
| Catalog | public read; admin write | category/product/variant/image URL/print area | no catalog-media upload API; query controls per schema; consumers known |
| Cart/checkout/orders | guest/auth; admin guarded | cart CRUD, checkout, order list/detail/cancel, admin status | no refund or stock reservation; consumers known |
| Design studio | auth | assets/designs/versions/print exports/add to cart | local storage contract; consumer in design-studio API/pages; no marketplace operations |
| Shipping/payment | public quote/options; webhook provider-only | local zones/quote; incoming webhook settlement | checkout UI known; no payment initiation / carrier integration |
| Creator | creator role/permission | one workspace capability response | consumer page exists; backend is a marker, no creator data |
| Audit/system | indirect audit writes | audit/settings stored | no read/config API located; no known frontend consumer |

Unknown frontend consumer status is used for backend functionality not directly traced to UI calls; lack of a match is not proof of non-use.

## 13. Missing or incomplete capabilities

1. Payment initiation is absent: adapters are webhook verifiers/settlers.
2. Inventory is only variant stock quantity and admin editing; checkout reservation/deduction/ledger not found.
3. Shipping covers fixed configured zones/quotes, not label purchase or carrier tracking.
4. Creator route is a static capability/status response; no creator-specific entities or workflows.
5. Design “versioning” persists design versions, but marketplace submission/moderation/public distribution is absent.
6. Refund endpoint/workflow absent; order cancel is distinct and has no provider refund handling.
7. Local disk is the only wired storage backend despite S3 config surface; no lifecycle cleanup job found.
8. No password recovery or email/phone verification flow.
9. System settings and audit log have schemas/seed/write paths but no read/manage API identified.
10. Docs list planned routes such as marketplace, rewards, production, inventory and admin reports that are not registered in `app.ts`.
11. No background queue/worker found for asynchronous exports, notifications, cleanup, or payment reconciliation.

## 14. Backend-only capabilities and consumer status

Potential backend-only/unknown capabilities include the three health probes, payment webhook intake, guest receipt verification, audit event writes, role assignment endpoint, and local design asset content endpoint. Some have frontend setup/operational consumers likely, but code search did not establish a direct UI caller for all; status is **UNKNOWN consumer** rather than unused. The API-045 creator marker has a corresponding creator page in the web app.

## 15. Test coverage and verification evidence

API tests: `apps/api/tests/{health,env,database-schema,auth,addresses,catalog,commerce,designs,garment-glb-assets}.test.ts` (9 listed API suites; note additional helpers are not suites). Package tests: `packages/validation/tests/validation.test.ts`, `packages/shared-utils/tests/money.test.ts`. Browser E2E: `e2e/{foundation,auth-rbac,storefront-catalog,commerce-checkout,design-system,design-studio-2d,design-studio-3d}.spec.ts`. The test scripts exist in root/app manifests. Tests were not run; no status is reported as execution-verified. In-memory repository helpers suggest many route/service tests use substitutes rather than proving live DB migration/runtime behavior.

## 16. Technical dependencies and risks

- Production depends on MariaDB configuration and migrations; connection health is logged after server starts, with health endpoint exposing DB status.
- Env schema includes development defaults; strict staging/production guards require non-default session secret and DB credentials. Never expose values.
- DB migrations are present but were not applied or compared against a live DB in this audit.
- `STORAGE_DRIVER=s3` config is not connected to a runtime adapter.
- Redis flags have no observed consumer; enabling it only validates URL.
- Monetary values are decimal BDT strings; pricing helper and DB snapshots need consistent minor-unit handling.
- No backend queue/worker is visible; long exports are request-bound unless implementation delegates internally (no queue found).
- Do not infer that documentation route groups are runtime capabilities.

## 17. Questions and unknowns

- Which deployment target and API prefix are used in production? Source default is `/api/v1`.
- Are S3/Redis or gateway outbound flows implemented outside this repository? No evidence here.
- Are all five migrations applied to the intended database? Not verifiable without querying it.
- Which phase-specific docs remain authoritative? Documentation contains future route groups not registered in the app.
- Are `design_public_id` and design/asset references intentionally application-level references without foreign keys? Schema/code should be treated as authoritative; ER diagram marks them as logical where applicable.
- Does frontend invoke payment gateway flows via another service? No outbound integration is present in this backend tree.

## 18. Machine-readable inventory

See [BACKEND_CAPABILITY_AUDIT.json](BACKEND_CAPABILITY_AUDIT.json). It records stable feature/API IDs, status, evidence, dependencies, schema objects, workflows, role definitions, integrations, tests, backend-only capability candidates, missing features, and unknowns. For full field-level Zod constraints, consult the validation source files referenced by each route rather than infer request data from documentation.

## Evidence index

- Runtime and registration: `apps/api/src/{server.ts,app.ts,config/env.ts}`
- Middleware: `apps/api/src/middleware/*.ts`
- Backend modules: `apps/api/src/modules/*`
- Schema: `database/schema/*.ts`; migrations `database/migrations/*.sql` and `meta/_journal.json`
- RBAC: `database/rbac-catalog.ts`, `database/seeds/rbac.seed.ts`
- Validation/shared contracts: `packages/validation/src/*.ts`, `packages/shared-types/src/*.ts`
- Consumers: `apps/web/src/features/*/*.api.ts`, `apps/web/src/pages/*`, `e2e/*.spec.ts`
- Intent documentation (not proof of implementation): `docs/API.md`, `docs/architecture/*`, `docs/decisions/*`
