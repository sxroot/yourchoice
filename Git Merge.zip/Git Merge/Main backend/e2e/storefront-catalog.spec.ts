import { expect, test } from '@playwright/test';
import type {
  CustomerAddressDTO,
  ProductCategoryDTO,
  ProductDetailDTO,
  ProductSummaryDTO,
} from '@your-choice/shared-types';

function createSeedCatalogState() {
  const categories: ProductCategoryDTO[] = [
    {
      id: '11111111-1111-4111-8111-111111111101',
      slug: 't-shirts',
      parentId: null,
      nameEn: 'T-Shirts',
      nameBn: 'টি-শার্ট',
      descriptionEn: 'Combed cotton jersey blanks tailored for custom studio printing.',
      descriptionBn: 'কাস্টম স্টুডিও প্রিন্টের জন্য প্রিমিয়াম কটন টি-শার্ট ব্ল্যাঙ্কস।',
      sortOrder: 0,
      isActive: true,
      productCount: 1,
    },
    {
      id: '11111111-1111-4111-8111-111111111102',
      slug: 'polo-shirts',
      parentId: null,
      nameEn: 'Polo Shirts',
      nameBn: 'পলো শার্ট',
      descriptionEn: 'Structured cotton pique polo blanks with crest & back zones.',
      descriptionBn: 'কটন পিকে পলো শার্ট — লেফট চেস্ট ও ব্যাক প্রিন্ট জোনসহ।',
      sortOrder: 1,
      isActive: true,
      productCount: 1,
    },
  ];

  const products: ProductDetailDTO[] = [
    {
      id: '22222222-2222-4222-8222-222222222201',
      slug: 'dhaka-heavyweight-crew-tee',
      skuPrefix: 'YC-TEE-220',
      category: {
        id: categories[0]!.id,
        slug: 't-shirts',
        nameEn: 'T-Shirts',
        nameBn: 'টি-শার্ট',
      },
      nameEn: 'Dhaka Heavyweight Crew Tee',
      nameBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট',
      subtitleEn: '220 GSM Combed Ring-Spun Jersey',
      subtitleBn: '২২০ জিএসএম কম্বড রিং-স্পান জার্সি',
      descriptionEn: 'Engineered for crisp DTF and screen prints with breathable everyday drape.',
      descriptionBn: 'নিখুঁত ডিটিএফ ও স্ক্রিন প্রিন্টের জন্য তৈরি আরামদায়ক কটন টি-শার্ট।',
      fabricSpecEn: '100% Combed Ring-Spun Cotton · Bio-Washed',
      fabricSpecBn: '১০০% কম্বড রিং-স্পান কটন · বায়ো-ওয়াশড',
      gsm: 220,
      fitType: 'Boxy Studio Fit',
      basePrice: '690.00',
      minPrice: '690.00',
      maxPrice: '740.00',
      currencyCode: 'BDT',
      isCustomizable: true,
      status: 'active',
      featuredOrder: 1,
      primaryImage: {
        id: '33333333-3333-4333-8333-333333333301',
        variantId: null,
        viewType: 'front',
        url: '/catalog/tee-front.svg',
        altTextEn: 'Dhaka Heavyweight Crew Tee front view',
        altTextBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট সামনের দৃশ্য',
        sortOrder: 0,
        isPrimary: true,
      },
      images: [
        {
          id: '33333333-3333-4333-8333-333333333301',
          variantId: null,
          viewType: 'front',
          url: '/catalog/tee-front.svg',
          altTextEn: 'Dhaka Heavyweight Crew Tee front view',
          altTextBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট সামনের দৃশ্য',
          sortOrder: 0,
          isPrimary: true,
        },
        {
          id: '33333333-3333-4333-8333-333333333302',
          variantId: null,
          viewType: 'back',
          url: '/catalog/tee-back.svg',
          altTextEn: 'Dhaka Heavyweight Crew Tee back view',
          altTextBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট পিছনের দৃশ্য',
          sortOrder: 1,
          isPrimary: false,
        },
      ],
      variants: [
        {
          id: '44444444-4444-4444-8444-444444444401',
          sku: 'YC-TEE-220-OBS-M',
          colorNameEn: 'Obsidian Black',
          colorNameBn: 'অবসিডিয়ান কালো',
          colorHex: '#0F172A',
          sizeCode: 'M',
          priceOverride: null,
          effectivePrice: '690.00',
          currencyCode: 'BDT',
          stockQuantity: 35,
          inStock: true,
          isActive: true,
        },
        {
          id: '44444444-4444-4444-8444-444444444402',
          sku: 'YC-TEE-220-ROY-L',
          colorNameEn: 'Royal Cobalt',
          colorNameBn: 'রয়্যাল কোবাল্ট',
          colorHex: '#1D4ED8',
          sizeCode: 'L',
          priceOverride: '740.00',
          effectivePrice: '740.00',
          currencyCode: 'BDT',
          stockQuantity: 18,
          inStock: true,
          isActive: true,
        },
      ],
      printAreas: [
        {
          id: '55555555-5555-4555-8555-555555555501',
          surfaceKey: 'front',
          labelEn: 'Front Chest Canvas',
          labelBn: 'সামনের চেস্ট ক্যানভাস',
          physicalWidthMm: 280,
          physicalHeightMm: 340,
          targetDpi: 300,
          safeInsetMm: 12,
          coordinateSpace: 'normalized_0_1',
          mockupBounds: { x: 0.28, y: 0.24, width: 0.44, height: 0.46, rotationDeg: 0 },
          uvRegion: {
            islandKey: 'front_torso',
            meshTarget: 'tee_body',
            uMin: 0.1,
            uMax: 0.9,
            vMin: 0.1,
            vMax: 0.9,
          },
          printMethods: ['dtf', 'screen_print'],
          surchargeAmount: '0.00',
          currencyCode: 'BDT',
          isDefault: true,
          isActive: true,
          sortOrder: 0,
        },
        {
          id: '55555555-5555-4555-8555-555555555502',
          surfaceKey: 'back',
          labelEn: 'Full Back Canvas',
          labelBn: 'পিছনের ফুল ক্যানভাস',
          physicalWidthMm: 320,
          physicalHeightMm: 400,
          targetDpi: 300,
          safeInsetMm: 15,
          coordinateSpace: 'normalized_0_1',
          mockupBounds: { x: 0.26, y: 0.2, width: 0.48, height: 0.52, rotationDeg: 0 },
          uvRegion: {
            islandKey: 'back_torso',
            meshTarget: 'tee_body',
            uMin: 0.1,
            uMax: 0.9,
            vMin: 0.1,
            vMax: 0.9,
          },
          printMethods: ['dtf', 'screen_print'],
          surchargeAmount: '120.00',
          currencyCode: 'BDT',
          isDefault: false,
          isActive: true,
          sortOrder: 1,
        },
      ],
      availableSizes: ['M', 'L'],
      availableColors: [
        { colorNameEn: 'Obsidian Black', colorNameBn: 'অবসিডিয়ান কালো', colorHex: '#0F172A' },
        { colorNameEn: 'Royal Cobalt', colorNameBn: 'রয়্যাল কোবাল্ট', colorHex: '#1D4ED8' },
      ],
      printSurfaces: ['front', 'back'],
      totalStock: 53,
      variantCount: 2,
      createdAt: '2026-11-15T00:00:00.000Z',
      updatedAt: '2026-11-15T00:00:00.000Z',
    },
    {
      id: '22222222-2222-4222-8222-222222222202',
      slug: 'executive-pique-polo',
      skuPrefix: 'YC-POLO-240',
      category: {
        id: categories[1]!.id,
        slug: 'polo-shirts',
        nameEn: 'Polo Shirts',
        nameBn: 'পলো শার্ট',
      },
      nameEn: 'Executive Cotton Pique Polo',
      nameBn: 'এক্সিকিউটিভ কটন পিকে পলো',
      subtitleEn: '240 GSM Breathable Pique Knit',
      subtitleBn: '২৪০ জিএসএম ব্রিদেবল পিকে নিট',
      descriptionEn: 'Clean structured collar polo with calibrated left-chest crest placement.',
      descriptionBn: 'স্টাইলিশ কলারযুক্ত প্রিমিয়াম পলো শার্ট — লেফট চেস্ট ক্রেস্ট জোনসহ।',
      fabricSpecEn: '100% Double-Lacoste Pique Cotton',
      fabricSpecBn: '১০০% ডাবল-লাকোস্টে পিকে কটন',
      gsm: 240,
      fitType: 'Tailored Collar Fit',
      basePrice: '980.00',
      minPrice: '980.00',
      maxPrice: '980.00',
      currencyCode: 'BDT',
      isCustomizable: true,
      status: 'active',
      featuredOrder: 2,
      primaryImage: {
        id: '33333333-3333-4333-8333-333333333303',
        variantId: null,
        viewType: 'front',
        url: '/catalog/polo-front.svg',
        altTextEn: 'Executive Cotton Pique Polo front view',
        altTextBn: 'এক্সিকিউটিভ পলো শার্ট সামনের দৃশ্য',
        sortOrder: 0,
        isPrimary: true,
      },
      images: [
        {
          id: '33333333-3333-4333-8333-333333333303',
          variantId: null,
          viewType: 'front',
          url: '/catalog/polo-front.svg',
          altTextEn: 'Executive Cotton Pique Polo front view',
          altTextBn: 'এক্সিকিউটিভ পলো শার্ট সামনের দৃশ্য',
          sortOrder: 0,
          isPrimary: true,
        },
        {
          id: '33333333-3333-4333-8333-333333333304',
          variantId: null,
          viewType: 'back',
          url: '/catalog/polo-back.svg',
          altTextEn: 'Executive Cotton Pique Polo back view',
          altTextBn: 'এক্সিকিউটিভ পলো শার্ট পিছনের দৃশ্য',
          sortOrder: 1,
          isPrimary: false,
        },
      ],
      variants: [
        {
          id: '44444444-4444-4444-8444-444444444403',
          sku: 'YC-POLO-240-SLV-M',
          colorNameEn: 'Arctic Silver',
          colorNameBn: 'আর্কটিক সিলভার',
          colorHex: '#E2E8F0',
          sizeCode: 'M',
          priceOverride: null,
          effectivePrice: '980.00',
          currencyCode: 'BDT',
          stockQuantity: 22,
          inStock: true,
          isActive: true,
        },
      ],
      printAreas: [
        {
          id: '55555555-5555-4555-8555-555555555503',
          surfaceKey: 'left_chest',
          labelEn: 'Left Chest Crest',
          labelBn: 'বাম চেস্ট ক্রেস্ট',
          physicalWidthMm: 100,
          physicalHeightMm: 100,
          targetDpi: 300,
          safeInsetMm: 8,
          coordinateSpace: 'normalized_0_1',
          mockupBounds: { x: 0.56, y: 0.27, width: 0.18, height: 0.18, rotationDeg: 0 },
          uvRegion: {
            islandKey: 'left_chest',
            meshTarget: 'polo_body',
            uMin: 0.5,
            uMax: 0.75,
            vMin: 0.55,
            vMax: 0.75,
          },
          printMethods: ['dtf', 'embroidery_ready'],
          surchargeAmount: '0.00',
          currencyCode: 'BDT',
          isDefault: true,
          isActive: true,
          sortOrder: 0,
        },
      ],
      availableSizes: ['M'],
      availableColors: [
        { colorNameEn: 'Arctic Silver', colorNameBn: 'আর্কটিক সিলভার', colorHex: '#E2E8F0' },
      ],
      printSurfaces: ['left_chest'],
      totalStock: 22,
      variantCount: 1,
      createdAt: '2026-11-15T00:00:00.000Z',
      updatedAt: '2026-11-15T00:00:00.000Z',
    },
  ];

  const toSummary = (p: ProductDetailDTO): ProductSummaryDTO => {
    const colorsMap = new Map<
      string,
      { colorNameEn: string; colorNameBn: string; colorHex: string }
    >();
    const sizesSet = new Set(p.variants.filter((v) => v.isActive).map((v) => v.sizeCode));
    let totalStock = 0;
    for (const v of p.variants) {
      if (!v.isActive) continue;
      totalStock += v.stockQuantity;
      colorsMap.set(v.colorHex, {
        colorNameEn: v.colorNameEn,
        colorNameBn: v.colorNameBn,
        colorHex: v.colorHex,
      });
    }
    return {
      ...p,
      availableSizes: Array.from(sizesSet),
      availableColors: Array.from(colorsMap.values()),
      printSurfaces: p.printAreas.filter((pa) => pa.isActive).map((pa) => pa.surfaceKey),
      totalStock,
      variantCount: p.variants.filter((v) => v.isActive).length,
    };
  };

  return { categories, products, toSummary };
}

test.describe('Phase 1B Bilingual Storefront, Address Book & Admin Catalogue Journeys', () => {
  test('Supports EN/BN switching, /shop filtering, /product print-area inspection, and mobile overflow safety', async ({
    page,
  }) => {
    const { categories, products, toSummary } = createSeedCatalogState();

    await page.route('**/api/**', async (route) => {
      const req = route.request();
      const url = new URL(req.url());
      const path = url.pathname;

      if (path === '/api/health') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            status: 'healthy',
            environment: 'test',
            version: '1.0.0',
            checks: { database: { status: 'up', latencyMs: 4 } },
          }),
        });
        return;
      }

      if (path === '/api/v1/auth/me') {
        await route.fulfill({
          status: 401,
          contentType: 'application/json',
          body: JSON.stringify({
            success: false,
            error: { code: 'UNAUTHORIZED', message: 'Not authenticated' },
          }),
        });
        return;
      }

      if (path === '/api/v1/categories') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { categories } }),
        });
        return;
      }

      if (path === '/api/v1/products') {
        const cat = url.searchParams.get('category');
        const size = url.searchParams.get('size');
        const filtered = products
          .filter((p) => p.status === 'active')
          .filter((p) => !cat || p.category.slug === cat)
          .filter((p) => !size || p.variants.some((v) => v.sizeCode === size))
          .map(toSummary);

        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              products: filtered,
              pagination: { page: 1, pageSize: 12, totalItems: filtered.length, totalPages: 1 },
              facets: {
                sizes: ['M', 'L'],
                colors: [
                  {
                    colorNameEn: 'Obsidian Black',
                    colorNameBn: 'অবসিডিয়ান কালো',
                    colorHex: '#0F172A',
                  },
                  { colorNameEn: 'Royal Cobalt', colorNameBn: 'রয়্যাল কোবাল্ট', colorHex: '#1D4ED8' },
                ],
              },
            },
          }),
        });
        return;
      }

      if (path.startsWith('/api/v1/products/')) {
        const slug = path.split('/').pop()!;
        const found = products.find((p) => p.slug === slug && p.status === 'active');
        await route.fulfill({
          status: found ? 200 : 404,
          contentType: 'application/json',
          body: JSON.stringify(
            found
              ? { success: true, data: { product: found } }
              : { success: false, error: { code: 'NOT_FOUND', message: 'Not found' } }
          ),
        });
        return;
      }

      await route.continue();
    });

    await page.goto('/');
    await expect(page.getByTestId('home-orbit').getByRole('link', { name: /Dhaka Heavyweight Crew Tee/ })).toBeVisible();

    await page.setViewportSize({ width: 390, height: 844 });
    const homeOverflow = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      innerWidth: window.innerWidth,
    }));
    expect(homeOverflow.scrollWidth).toBeLessThanOrEqual(homeOverflow.innerWidth);
    await page.setViewportSize({ width: 1280, height: 720 });

    // Bilingual toggle EN -> BN -> EN
    await page.getByTestId('locale-switcher').click();
    await expect(page.locator('html')).toHaveAttribute('lang', 'bn');
    await expect(page.getByTestId('home-orbit').getByRole('link', { name: /ঢাকা হেভিওয়েট ক্রু টি-শার্ট/ })).toBeVisible();

    await page.getByTestId('locale-switcher').click();
    await expect(page.locator('html')).toHaveAttribute('lang', 'en');

    // Navigate to /shop and filter by T-Shirts
    await page.getByRole('link', { name: 'Explore the collection' }).click();
    await expect(page).toHaveURL(/\/shop$/);
    await expect(page.getByRole('heading', { name: 'Dhaka Heavyweight Crew Tee' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Executive Cotton Pique Polo' })).toBeVisible();

    await page.locator('nav[aria-label="Product categories"] a[href="/shop/t-shirts"]').click();
    await expect(page).toHaveURL(/\/shop\/t-shirts$/);
    await expect(page.getByRole('heading', { name: 'Dhaka Heavyweight Crew Tee' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Executive Cotton Pique Polo' })).toHaveCount(0);

    // Open PDP and inspect configurable print zones & variants
    await page.getByRole('link', { name: 'Dhaka Heavyweight Crew Tee' }).first().click();
    await expect(page).toHaveURL(/\/product\/dhaka-heavyweight-crew-tee$/);

    const overlay = page.getByTestId('print-area-overlay');
    await expect(overlay).toBeVisible();
    await expect(overlay).toContainText('280×340mm');

    // Switch surface tab to Full Back Canvas
    await page.getByRole('tab', { name: 'Full Back Canvas' }).click();
    await expect(overlay).toContainText('320×400mm');

    // Toggle Print Zone Guide off & back on
    await page.getByRole('button', { name: 'Hide Print Zone Guide' }).click();
    await expect(overlay).toHaveCount(0);
    await page.getByRole('button', { name: 'Show Print Zone Guide' }).click();
    await expect(overlay).toBeVisible();

    // Switch colorway swatch -> Royal Cobalt L -> BDT 740.00
    await page.getByRole('button', { name: /Royal Cobalt/ }).click();
    await expect(page.getByText('YC-TEE-220-ROY-L')).toBeVisible();
    await expect(page.getByText('BDT 740.00')).toBeVisible();

    // Mobile overflow check at 390x844
    await page.setViewportSize({ width: 390, height: 844 });
    const pdpOverflow = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      innerWidth: window.innerWidth,
    }));
    expect(pdpOverflow.scrollWidth).toBeLessThanOrEqual(pdpOverflow.innerWidth);
  });

  test('Manages Bangladesh delivery addresses on /account and executes Admin product/variant/print-area/publish workflow', async ({
    page,
  }) => {
    const { categories, products, toSummary } = createSeedCatalogState();
    const addresses: CustomerAddressDTO[] = [];

    const adminUser = {
      id: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
      email: 'admin@yourchoice.com.bd',
      fullName: 'Platform Admin',
      phone: '+8801711111111',
      preferredLocale: 'en' as const,
      status: 'active' as const,
      emailVerified: true,
      roles: ['customer', 'admin', 'super_admin'],
      permissions: ['users:read', 'catalog:read', 'catalog:write', 'profile:write:own'],
      createdAt: '2026-11-15T00:00:00.000Z',
    };

    await page.route('**/api/**', async (route) => {
      const req = route.request();
      const url = new URL(req.url());
      const path = url.pathname;
      const method = req.method();

      if (path === '/api/v1/auth/me') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              authenticated: true,
              user: adminUser,
              session: {
                id: 'sess-e2e-admin',
                expiresAt: '2026-11-30T00:00:00.000Z',
              },
              csrfToken: 'csrf-e2e',
            },
          }),
        });
        return;
      }

      if (path === '/api/v1/auth/csrf') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { csrfToken: 'csrf-e2e' } }),
        });
        return;
      }

      if (path === '/api/v1/users/me/addresses' && method === 'GET') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { addresses } }),
        });
        return;
      }

      if (path === '/api/v1/users/me/addresses' && method === 'POST') {
        const body = req.postDataJSON() as Omit<
          CustomerAddressDTO,
          'id' | 'createdAt' | 'updatedAt'
        >;
        if (body.isDefault) {
          for (const a of addresses) a.isDefault = false;
        }
        const created: CustomerAddressDTO = {
          id: `66666666-6666-4666-8666-66666666660${addresses.length + 1}`,
          label: body.label,
          recipientName: body.recipientName,
          phone: body.phone,
          division: body.division,
          district: body.district,
          area: body.area,
          addressLine: body.addressLine,
          postalCode: body.postalCode ?? null,
          isDefault: Boolean(body.isDefault),
          createdAt: '2026-11-15T00:00:00.000Z',
          updatedAt: '2026-11-15T00:00:00.000Z',
        };
        addresses.push(created);
        await route.fulfill({
          status: 201,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { address: created } }),
        });
        return;
      }

      if (path.startsWith('/api/v1/users/me/addresses/') && method === 'PATCH') {
        const id = path.split('/').pop()!;
        const body = req.postDataJSON() as Partial<CustomerAddressDTO>;
        if (body.isDefault) {
          for (const a of addresses) a.isDefault = false;
        }
        const target = addresses.find((a) => a.id === id)!;
        Object.assign(target, body);
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { address: target } }),
        });
        return;
      }

      if (path.startsWith('/api/v1/users/me/addresses/') && method === 'DELETE') {
        const id = path.split('/').pop()!;
        const idx = addresses.findIndex((a) => a.id === id);
        if (idx >= 0) addresses.splice(idx, 1);
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { deletedId: id } }),
        });
        return;
      }

      if (path === '/api/v1/admin/overview') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              actorId: adminUser.id,
              actorRoles: adminUser.roles,
              userCountSampled: 1,
              users: [
                {
                  id: adminUser.id,
                  email: adminUser.email,
                  fullName: adminUser.fullName,
                  roles: adminUser.roles,
                },
              ],
            },
          }),
        });
        return;
      }

      if (path === '/api/v1/admin/categories' || path === '/api/v1/categories') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { categories } }),
        });
        return;
      }

      if (path === '/api/v1/admin/products' && method === 'GET') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              products: products.map(toSummary),
              pagination: { page: 1, pageSize: 30, totalItems: products.length, totalPages: 1 },
              facets: { sizes: ['M', 'L'], colors: [] },
            },
          }),
        });
        return;
      }

      if (path === '/api/v1/admin/products' && method === 'POST') {
        const body = req.postDataJSON() as Record<string, unknown>;
        const cat = categories.find((c) => c.id === body.categoryId) ?? categories[0]!;
        const created: ProductDetailDTO = {
          id: '22222222-2222-4222-8222-222222222299',
          slug: String(body.slug),
          skuPrefix: String(body.skuPrefix).toUpperCase(),
          category: { id: cat.id, slug: cat.slug, nameEn: cat.nameEn, nameBn: cat.nameBn },
          nameEn: String(body.nameEn),
          nameBn: String(body.nameBn),
          subtitleEn: (body.subtitleEn as string | null) ?? null,
          subtitleBn: (body.subtitleBn as string | null) ?? null,
          descriptionEn: String(body.descriptionEn),
          descriptionBn: String(body.descriptionBn),
          fabricSpecEn: null,
          fabricSpecBn: null,
          gsm: typeof body.gsm === 'number' ? body.gsm : 220,
          fitType: (body.fitType as string | null) ?? null,
          basePrice: String(body.basePrice),
          minPrice: String(body.basePrice),
          maxPrice: String(body.basePrice),
          currencyCode: 'BDT',
          isCustomizable: Boolean(body.isCustomizable),
          status: 'draft',
          featuredOrder: null,
          primaryImage: {
            id: '33333333-3333-4333-8333-333333333399',
            variantId: null,
            viewType: 'front',
            url: '/catalog/tee-front.svg',
            altTextEn: String(body.nameEn),
            altTextBn: String(body.nameBn),
            sortOrder: 0,
            isPrimary: true,
          },
          images: [],
          variants: [],
          printAreas: [],
          availableSizes: [],
          availableColors: [],
          printSurfaces: [],
          totalStock: 0,
          variantCount: 0,
          createdAt: '2026-11-15T00:00:00.000Z',
          updatedAt: '2026-11-15T00:00:00.000Z',
        };
        products.push(created);
        await route.fulfill({
          status: 201,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { product: created } }),
        });
        return;
      }

      if (path.startsWith('/api/v1/admin/products/') && method === 'GET') {
        const id = path.split('/').pop()!;
        const found = products.find((p) => p.id === id)!;
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { product: found } }),
        });
        return;
      }

      if (path.endsWith('/variants') && method === 'POST') {
        const productId = path.split('/')[5]!;
        const product = products.find((p) => p.id === productId)!;
        const body = req.postDataJSON() as Record<string, unknown>;
        const variant = {
          id: '44444444-4444-4444-8444-444444444499',
          sku: String(body.sku).toUpperCase(),
          colorNameEn: String(body.colorNameEn),
          colorNameBn: String(body.colorNameBn),
          colorHex: String(body.colorHex).toUpperCase(),
          sizeCode: body.sizeCode as ProductDetailDTO['variants'][number]['sizeCode'],
          priceOverride: (body.priceOverride as string | null) ?? null,
          effectivePrice: String(body.priceOverride ?? product.basePrice),
          currencyCode: 'BDT',
          stockQuantity: Number(body.stockQuantity ?? 0),
          inStock: Number(body.stockQuantity ?? 0) > 0,
          isActive: true,
        };
        product.variants.push(variant);
        await route.fulfill({
          status: 201,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { variant } }),
        });
        return;
      }

      if (path.endsWith('/print-areas') && method === 'PUT') {
        const productId = path.split('/')[5]!;
        const product = products.find((p) => p.id === productId)!;
        const body = req.postDataJSON() as Record<string, unknown>;
        const area = {
          id: '55555555-5555-4555-8555-555555555599',
          surfaceKey: body.surfaceKey as ProductDetailDTO['printAreas'][number]['surfaceKey'],
          labelEn: String(body.labelEn),
          labelBn: String(body.labelBn),
          physicalWidthMm: Number(body.physicalWidthMm),
          physicalHeightMm: Number(body.physicalHeightMm),
          targetDpi: Number(body.targetDpi),
          safeInsetMm: Number(body.safeInsetMm),
          coordinateSpace: 'normalized_0_1' as const,
          mockupBounds: body.mockupBounds as ProductDetailDTO['printAreas'][number]['mockupBounds'],
          uvRegion: (body.uvRegion as ProductDetailDTO['printAreas'][number]['uvRegion']) ?? null,
          printMethods: ['dtf'],
          surchargeAmount: String(body.surchargeAmount ?? '0.00'),
          currencyCode: 'BDT',
          isDefault: Boolean(body.isDefault),
          isActive: true,
          sortOrder: 0,
        };
        product.printAreas.push(area);
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { printArea: area } }),
        });
        return;
      }

      if (path.startsWith('/api/v1/admin/products/') && method === 'PATCH') {
        const productId = path.split('/').pop()!;
        const product = products.find((p) => p.id === productId)!;
        const body = req.postDataJSON() as Record<string, unknown>;
        if (body.status === 'active' && product.variants.length === 0) {
          await route.fulfill({
            status: 400,
            contentType: 'application/json',
            body: JSON.stringify({
              success: false,
              error: {
                code: 'CATALOG_PUBLISH_REQUIRES_VARIANT',
                message: 'Add at least one active variant before publishing.',
              },
            }),
          });
          return;
        }
        Object.assign(product, body);
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { product } }),
        });
        return;
      }

      await route.continue();
    });

    // 1) Customer Address Book CRUD on /account
    await page.goto('/account');
    await expect(
      page.getByRole('heading', { name: 'Bangladesh Delivery Addresses' })
    ).toBeVisible();

    await page.getByRole('button', { name: 'Add New Address' }).first().click();
    await page.fill('#address-label', 'Home');
    await page.fill('#address-recipient', 'Tariqul Islam');
    await page.fill('#address-phone', '+8801712345678');
    await page.fill('#address-district', 'Dhaka');
    await page.fill('#address-area', 'Dhanmondi');
    await page.fill('#address-postal', '1209');
    await page.fill('#address-line', 'House 14, Road 6/A');
    await page.getByRole('button', { name: 'Save Address' }).click();

    const homeCard = page.getByTestId('address-card-Home');
    await expect(homeCard).toBeVisible();
    await expect(homeCard).toContainText('Default');

    // Add second address and promote to Default
    await page.getByRole('button', { name: 'Add New Address' }).first().click();
    await page.fill('#address-label', 'Office');
    await page.fill('#address-recipient', 'Tariqul Islam');
    await page.fill('#address-phone', '+8801812345678');
    await page.fill('#address-district', 'Chattogram');
    await page.fill('#address-area', 'Nasirabad');
    await page.fill('#address-line', 'Plot 8, CDA Avenue');
    await page.getByRole('button', { name: 'Save Address' }).click();

    const officeCard = page.getByTestId('address-card-Office');
    await expect(officeCard).toBeVisible();
    await officeCard.getByRole('button', { name: 'Set Default' }).click();
    await expect(officeCard).toContainText('Default');

    await homeCard.getByRole('button', { name: 'Delete' }).click();
    await expect(homeCard).toHaveCount(0);

    // 2) Admin Catalogue Create -> Variant -> Print Area -> Publish Flow
    await page.goto('/admin');
    await expect(
      page.getByRole('heading', { name: 'Identity & Operations Overview' })
    ).toBeVisible();

    await page.getByRole('tab', { name: 'Apparel Catalogue' }).click();
    await page.getByRole('button', { name: 'New Apparel Product' }).click();

    await page.fill('#create-slug', 'sylhet-organic-tee');
    await page.fill('#create-sku-prefix', 'YC-SYL');
    await page.fill('#create-name-en', 'Sylhet Organic Tee');
    await page.fill('#create-name-bn', 'সিলেট অর্গানিক টি-শার্ট');
    await page.fill(
      '#create-desc-en',
      'Breathable combed cotton tee knitted in Bangladesh for studio printing.'
    );
    await page.fill('#create-desc-bn', 'বাংলাদেশে তৈরি কম্বড কটন টি-শার্ট, স্টুডিও প্রিন্টের জন্য আদর্শ।');
    await page.getByRole('button', { name: 'Create' }).click();

    // Workspace dialog opens for newly created draft product
    await expect(page.getByText('SKU Variants (Size · Color · Stock) (0)')).toBeVisible();
    await page.fill('#var-sku', 'YC-SYL-BLK-M');
    await page.getByRole('button', { name: 'Add Variant SKU' }).click();
    await expect(page.getByText('YC-SYL-BLK-M')).toBeVisible();

    await page.getByRole('button', { name: 'Save Print Area' }).click();
    await expect(page.getByText('Print area (front) saved.')).toBeVisible();

    await page.getByRole('button', { name: 'Close dialog' }).click();

    const createdRow = page.getByTestId('admin-product-row-sylhet-organic-tee');
    await expect(createdRow).toContainText('DRAFT');
    await createdRow.getByRole('button', { name: 'Publish Live' }).click();
    await expect(createdRow).toContainText('ACTIVE');
  });
});
