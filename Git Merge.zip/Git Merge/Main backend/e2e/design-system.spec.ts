import { expect, test } from '@playwright/test';

const VIEWPORTS = [
  { name: 'desktop-1440', width: 1440, height: 900, mobile: false },
  { name: 'laptop-1280', width: 1280, height: 800, mobile: false },
  { name: 'tablet-768', width: 768, height: 1024, mobile: false },
  { name: 'mobile-390', width: 390, height: 844, mobile: true },
  { name: 'small-mobile-360', width: 360, height: 800, mobile: true },
] as const;

test.describe('Phase A & B Design System & Responsive Shell QA', () => {
  for (const vp of VIEWPORTS) {
    test(`Renders / and /design-system cleanly at ${vp.name} (${vp.width}x${vp.height})`, async ({
      page,
    }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });

      for (const route of ['/', '/design-system']) {
        await page.goto(route);

        // Zero horizontal overflow
        const overflow = await page.evaluate(() => ({
          scrollWidth: document.documentElement.scrollWidth,
          innerWidth: window.innerWidth,
        }));
        expect(overflow.scrollWidth).toBeLessThanOrEqual(overflow.innerWidth);

        // Legible body typography >= 14px
        const bodyFontSize = await page.evaluate(() =>
          Number.parseFloat(getComputedStyle(document.body).fontSize)
        );
        expect(bodyFontSize).toBeGreaterThanOrEqual(14);

        // Official logo integrity: loaded, non-zero, 1:1 square aspect ratio
        const logoMetrics = await page
          .locator('header img[src="/brand/your-choice-logo.png"]')
          .evaluate((img) => {
            const rect = img.getBoundingClientRect();
            const imageEl = img as HTMLImageElement;
            return {
              complete: imageEl.complete,
              naturalWidth: imageEl.naturalWidth,
              ratio: rect.height > 0 ? rect.width / rect.height : 0,
            };
          });
        expect(logoMetrics.complete).toBe(true);
        expect(logoMetrics.naturalWidth).toBeGreaterThan(0);
        expect(logoMetrics.ratio).toBeGreaterThan(0.95);
        expect(logoMetrics.ratio).toBeLessThan(1.05);
      }

      // On /design-system, verify mobile input font-size >= 16px and scroll reveals resolve to opacity 1
      if (vp.mobile) {
        const inputFontSize = await page
          .locator('input')
          .first()
          .evaluate((el) => Number.parseFloat(getComputedStyle(el).fontSize));
        expect(inputFontSize).toBeGreaterThanOrEqual(16);
      }

      await page.locator('footer').scrollIntoViewIfNeeded();
      await expect(page.getByText('Reveal Wrapper Check')).toBeVisible();
      await expect
        .poll(async () =>
          page
            .getByText('Reveal Wrapper Check')
            .locator('..')
            .locator('..')
            .locator('..')
            .evaluate((el) => getComputedStyle(el).opacity)
        )
        .toBe('1');
    });
  }

  test('Interactive overlays, tabs, select, and mobile drawer support keyboard and pointer control', async ({
    page,
  }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto('/');

    // Mobile drawer open + Escape close + reopen navigation
    const menuTrigger = page.getByRole('button', { name: 'Open navigation menu' });
    await expect(menuTrigger).toBeVisible();
    await menuTrigger.click();
    await expect(page.getByRole('navigation', { name: 'Mobile navigation' })).toBeVisible();

    await page.keyboard.press('Escape');
    await expect(page.getByRole('navigation', { name: 'Mobile navigation' })).toBeHidden();

    await menuTrigger.click();
    await page
      .getByRole('navigation', { name: 'Mobile navigation' })
      .getByRole('link', { name: 'Design System' })
      .click();
    await expect(page).toHaveURL(/\/design-system$/);

    // Tabs switching
    await page.getByRole('tab', { name: 'Accessibility' }).click();
    await expect(page.getByText(/Focus rings render with 2px Electric Blue/i)).toBeVisible();

    // Select component interaction
    await page.getByRole('combobox', { name: 'Base apparel template' }).click();
    await page.getByRole('option', { name: 'Tech Pique Polo Shirt' }).click();
    await page.getByRole('tab', { name: 'Token Specs' }).click();
    await expect(page.getByText('pique-polo')).toBeVisible();

    // Dialog open + Escape close
    await page.getByRole('button', { name: 'Open Modal Dialog' }).click();
    await expect(page.getByRole('heading', { name: 'Confirm Print Specification' })).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(page.getByRole('heading', { name: 'Confirm Print Specification' })).toBeHidden();

    // Side Drawer + Bottom Sheet toggle
    await page.getByRole('button', { name: 'Open Side Drawer' }).click();
    await expect(page.getByRole('heading', { name: 'Side Inspection Panel' })).toBeVisible();
    await page.getByRole('button', { name: 'Done Inspecting' }).click();
    await expect(page.getByRole('heading', { name: 'Side Inspection Panel' })).toBeHidden();

    await page.getByRole('button', { name: 'Open Bottom Sheet' }).click();
    await expect(page.getByRole('heading', { name: 'Mobile Tool & Filter Sheet' })).toBeVisible();
    await page.getByRole('button', { name: 'Apply & Close' }).click();
    await expect(page.getByRole('heading', { name: 'Mobile Tool & Filter Sheet' })).toBeHidden();
  });

  test('Respects prefers-reduced-motion: reduce without hiding sections', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.setViewportSize({ width: 1280, height: 800 });
    await page.goto('/design-system');

    await expect(
      page.getByRole('heading', { name: /YOUR CHOICE Design System & Component Foundation/i })
    ).toBeVisible();
    await expect(page.getByText('Reveal Wrapper Check')).toBeVisible();
  });
});
