import { expect, type Page, test } from '@playwright/test';
import type {
  CanonicalDesignDocument,
  CartDTO,
  DesignDetailDTO,
  ProductCategoryDTO,
  ProductDetailDTO,
} from '@your-choice/shared-types';

const CAT_TEES: ProductCategoryDTO = {
  id: '11111111-1111-4111-8111-111111111001',
  slug: 't-shirts',
  parentId: null,
  nameEn: 'T-Shirts',
  nameBn: 'টি-শার্ট',
  descriptionEn: 'Combed cotton tees',
  descriptionBn: null,
  sortOrder: 1,
  isActive: true,
  productCount: 1,
};

const CAT_POLO: ProductCategoryDTO = {
  id: '11111111-1111-4111-8111-111111111002',
  slug: 'polo-shirts',
  parentId: null,
  nameEn: 'Polo Shirts',
  nameBn: 'পলো শার্ট',
  descriptionEn: 'Pique knit polo shirts',
  descriptionBn: null,
  sortOrder: 2,
  isActive: true,
  productCount: 1,
};

const PRODUCT_TEE: ProductDetailDTO = {
  id: '22222222-2222-4222-8222-222222222001',
  slug: 'signature-heavyweight-tee',
  skuPrefix: 'YC-TEE',
  nameEn: 'Signature Heavyweight Tee',
  nameBn: 'সিগনেচার হেভিওয়েট টি-শার্ট',
  subtitleEn: '220 GSM Studio Ready Tee',
  subtitleBn: '২২০ জিএসএম টি-শার্ট',
  descriptionEn: 'Premium studio blank.',
  descriptionBn: 'প্রিমিয়াম স্টুডিও ব্ল্যাঙ্ক।',
  fabricSpecEn: '100% Combed Ring-Spun Cotton',
  fabricSpecBn: '১০০% কম্বড কটন',
  basePrice: '850.00',
  minPrice: '850.00',
  maxPrice: '850.00',
  currencyCode: 'BDT',
  gsm: 220,
  fitType: 'regular',
  isCustomizable: true,
  status: 'active',
  featuredOrder: 1,
  primaryImage: null,
  availableSizes: ['L'],
  availableColors: [
    { colorNameEn: 'Obsidian Black', colorNameBn: 'কালো', colorHex: '#111827' },
    { colorNameEn: 'Midnight Navy', colorNameBn: 'নেভি', colorHex: '#172554' },
  ],
  printSurfaces: ['front', 'back'],
  totalStock: 43,
  variantCount: 2,
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z',
  category: {
    id: CAT_TEES.id,
    slug: CAT_TEES.slug,
    nameEn: CAT_TEES.nameEn,
    nameBn: CAT_TEES.nameBn,
  },
  images: [],
  variants: [
    {
      id: '33333333-3333-4333-8333-333333333001',
      sku: 'YC-TEE-OBS-L',
      colorNameEn: 'Obsidian Black',
      colorNameBn: 'কালো',
      colorHex: '#111827',
      sizeCode: 'L',
      priceOverride: null,
      effectivePrice: '850.00',
      currencyCode: 'BDT',
      stockQuantity: 25,
      inStock: true,
      isActive: true,
    },
    {
      id: '33333333-3333-4333-8333-333333333002',
      sku: 'YC-TEE-NVY-L',
      colorNameEn: 'Midnight Navy',
      colorNameBn: 'নেভি',
      colorHex: '#172554',
      sizeCode: 'L',
      priceOverride: null,
      effectivePrice: '850.00',
      currencyCode: 'BDT',
      stockQuantity: 18,
      inStock: true,
      isActive: true,
    },
  ],
  printAreas: [
    {
      id: '44444444-4444-4444-8444-444444444001',
      surfaceKey: 'front',
      labelEn: 'Front Chest',
      labelBn: 'সামনের বুক',
      physicalWidthMm: 280,
      physicalHeightMm: 360,
      targetDpi: 300,
      safeInsetMm: 10,
      coordinateSpace: 'normalized_0_1',
      mockupBounds: { x: 0.3, y: 0.23, width: 0.4, height: 0.48, rotationDeg: 0 },
      uvRegion: {
        islandKey: 'garment_front',
        meshTarget: 'garment_front',
        uMin: 0.1,
        uMax: 0.9,
        vMin: 0.1,
        vMax: 0.9,
      },
      printMethods: ['dtf'],
      surchargeAmount: '120.00',
      currencyCode: 'BDT',
      isDefault: true,
      isActive: true,
      sortOrder: 0,
    },
    {
      id: '44444444-4444-4444-8444-444444444002',
      surfaceKey: 'back',
      labelEn: 'Full Back',
      labelBn: 'পেছনের অংশ',
      physicalWidthMm: 300,
      physicalHeightMm: 400,
      targetDpi: 300,
      safeInsetMm: 12,
      coordinateSpace: 'normalized_0_1',
      mockupBounds: { x: 0.28, y: 0.21, width: 0.44, height: 0.5, rotationDeg: 0 },
      uvRegion: {
        islandKey: 'garment_back',
        meshTarget: 'garment_back',
        uMin: 0.1,
        uMax: 0.9,
        vMin: 0.1,
        vMax: 0.9,
      },
      printMethods: ['dtf'],
      surchargeAmount: '150.00',
      currencyCode: 'BDT',
      isDefault: false,
      isActive: true,
      sortOrder: 1,
    },
  ],
};

const PRODUCT_POLO: ProductDetailDTO = {
  id: '22222222-2222-4222-8222-222222222002',
  slug: 'executive-knit-polo',
  skuPrefix: 'YC-POLO',
  nameEn: 'Executive Knit Polo',
  nameBn: 'এক্সিকিউটিভ নিট পলো',
  subtitleEn: '230 GSM Pique Polo',
  subtitleBn: '২৩০ জিএসএম পলো',
  descriptionEn: 'Pique knit polo ready for 3D customization.',
  descriptionBn: '৩ডি কাস্টমাইজেশনের জন্য প্রস্তুত পলো।',
  fabricSpecEn: '100% Cotton Pique Knit',
  fabricSpecBn: '১০০% কটন পিকে নিট',
  basePrice: '1150.00',
  minPrice: '1150.00',
  maxPrice: '1150.00',
  currencyCode: 'BDT',
  gsm: 230,
  fitType: 'tailored',
  isCustomizable: true,
  status: 'active',
  featuredOrder: 2,
  primaryImage: null,
  availableSizes: ['L'],
  availableColors: [{ colorNameEn: 'Alabaster White', colorNameBn: 'সাদা', colorHex: '#f8fafc' }],
  printSurfaces: ['left_chest', 'back'],
  totalStock: 20,
  variantCount: 1,
  createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-01T00:00:00.000Z',
  category: {
    id: CAT_POLO.id,
    slug: CAT_POLO.slug,
    nameEn: CAT_POLO.nameEn,
    nameBn: CAT_POLO.nameBn,
  },
  images: [],
  variants: [
    {
      id: '33333333-3333-4333-8333-333333333003',
      sku: 'YC-POLO-WHT-L',
      colorNameEn: 'Alabaster White',
      colorNameBn: 'সাদা',
      colorHex: '#f8fafc',
      sizeCode: 'L',
      priceOverride: null,
      effectivePrice: '1150.00',
      currencyCode: 'BDT',
      stockQuantity: 20,
      inStock: true,
      isActive: true,
    },
  ],
  printAreas: [
    {
      id: '44444444-4444-4444-8444-444444444003',
      surfaceKey: 'left_chest',
      labelEn: 'Left Chest',
      labelBn: 'বাঁ বুক',
      physicalWidthMm: 95,
      physicalHeightMm: 95,
      targetDpi: 300,
      safeInsetMm: 6,
      coordinateSpace: 'normalized_0_1',
      mockupBounds: { x: 0.54, y: 0.25, width: 0.16, height: 0.16, rotationDeg: 0 },
      uvRegion: {
        islandKey: 'polo_left_chest',
        meshTarget: 'garment_front',
        uMin: 0.54,
        uMax: 0.72,
        vMin: 0.55,
        vMax: 0.72,
      },
      printMethods: ['dtf'],
      surchargeAmount: '90.00',
      currencyCode: 'BDT',
      isDefault: true,
      isActive: true,
      sortOrder: 0,
    },
    {
      id: '44444444-4444-4444-8444-444444444004',
      surfaceKey: 'back',
      labelEn: 'Upper Back',
      labelBn: 'পেছনে',
      physicalWidthMm: 280,
      physicalHeightMm: 340,
      targetDpi: 300,
      safeInsetMm: 10,
      coordinateSpace: 'normalized_0_1',
      mockupBounds: { x: 0.29, y: 0.22, width: 0.42, height: 0.48, rotationDeg: 0 },
      uvRegion: {
        islandKey: 'garment_back',
        meshTarget: 'garment_back',
        uMin: 0.1,
        uMax: 0.9,
        vMin: 0.1,
        vMax: 0.9,
      },
      printMethods: ['dtf'],
      surchargeAmount: '140.00',
      currencyCode: 'BDT',
      isDefault: false,
      isActive: true,
      sortOrder: 1,
    },
  ],
};

function setupStudio3DApiMock(page: Page, savedDocsCollector: CanonicalDesignDocument[]) {
  const designs = new Map<string, DesignDetailDTO>();
  const cart: CartDTO = {
    id: '99999999-9999-4999-8999-999999999903',
    items: [],
    itemCount: 0,
    subtotal: '0.00',
    currencyCode: 'BDT',
    hasUnavailableItems: false,
    expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
  };

  const toSummary = (p: ProductDetailDTO) => ({
    id: p.id,
    slug: p.slug,
    skuPrefix: p.skuPrefix,
    nameEn: p.nameEn,
    nameBn: p.nameBn,
    subtitleEn: p.subtitleEn,
    subtitleBn: p.subtitleBn,
    basePrice: p.basePrice,
    minPrice: p.minPrice,
    maxPrice: p.maxPrice,
    currencyCode: p.currencyCode,
    gsm: p.gsm,
    fitType: p.fitType,
    isCustomizable: p.isCustomizable,
    status: p.status,
    featuredOrder: p.featuredOrder,
    category: p.category,
    primaryImage: p.primaryImage,
    availableSizes: p.availableSizes,
    availableColors: p.availableColors,
    printSurfaces: p.printSurfaces,
    totalStock: p.totalStock,
    variantCount: p.variantCount,
    createdAt: p.createdAt,
    updatedAt: p.updatedAt,
  });

  return page.route('**/api/v1/**', async (route) => {
    const req = route.request();
    const url = new URL(req.url());
    const pathname = url.pathname.replace(/^\/api\/v1/, '');
    const method = req.method();

    if (pathname === '/auth/csrf') {
      await route.fulfill({
        status: 200,
        json: { success: true, data: { csrfToken: 'studio-3d-csrf' } },
      });
      return;
    }

    if (pathname === '/auth/me') {
      await route.fulfill({
        status: 200,
        json: {
          success: true,
          data: {
            authenticated: true,
            user: {
              id: 'usr-3d-1',
              email: 'studio3d@yourchoice.test',
              fullName: 'Tariq Ahmed',
              phone: '+8801712345679',
              preferredLocale: 'en',
              status: 'active',
              roles: ['customer'],
              permissions: ['designs:read:own', 'designs:write:own', 'catalog:read'],
            },
            session: {
              expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
              lastSeenAt: new Date().toISOString(),
            },
            csrfToken: 'studio-3d-csrf',
          },
        },
      });
      return;
    }

    if (pathname === '/categories') {
      await route.fulfill({
        status: 200,
        json: { success: true, data: { categories: [CAT_TEES, CAT_POLO] } },
      });
      return;
    }

    if (pathname === '/products') {
      await route.fulfill({
        status: 200,
        json: {
          success: true,
          data: {
            products: [toSummary(PRODUCT_TEE), toSummary(PRODUCT_POLO)],
            pagination: { page: 1, pageSize: 20, total: 2, totalPages: 1 },
            facets: { sizes: ['L'], colors: [] },
          },
        },
      });
      return;
    }

    if (pathname === `/products/${PRODUCT_TEE.slug}`) {
      await route.fulfill({ status: 200, json: { success: true, data: { product: PRODUCT_TEE } } });
      return;
    }

    if (pathname === `/products/${PRODUCT_POLO.slug}`) {
      await route.fulfill({
        status: 200,
        json: { success: true, data: { product: PRODUCT_POLO } },
      });
      return;
    }

    if (pathname === '/cart' && method === 'GET') {
      await route.fulfill({ status: 200, json: { success: true, data: { cart } } });
      return;
    }

    if (pathname === '/designs/assets' && method === 'GET') {
      await route.fulfill({ status: 200, json: { success: true, data: { assets: [] } } });
      return;
    }

    if (pathname === '/designs' && method === 'POST') {
      const body = req.postDataJSON() as { title: string; document: CanonicalDesignDocument };
      savedDocsCollector.push(body.document);
      const id = '77777777-7777-4777-8777-777777777301';
      const detail: DesignDetailDTO = {
        id,
        title: body.title,
        productId: body.document.productId,
        productSlug: PRODUCT_POLO.slug,
        productNameEn: PRODUCT_POLO.nameEn,
        productNameBn: PRODUCT_POLO.nameBn,
        productVariantId: body.document.productVariantId,
        variantSku: 'YC-POLO-WHT-L',
        variantColorNameEn: 'Alabaster White',
        variantColorNameBn: 'সাদা',
        variantColorHex: '#f8fafc',
        variantSizeCode: 'L',
        preferredMode: body.document.preferredMode,
        status: 'saved',
        currentVersionNumber: 1,
        customizedSurfaces: ['left_chest'],
        isValidForPrint: true,
        estimatedCustomizationFee: '90.00',
        currencyCode: 'BDT',
        previewUrl: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        document: { ...body.document, designId: id },
        validation: {
          isValidForPrint: true,
          activePrintSurfaces: ['left_chest'],
          issues: [],
        },
        exports: [],
      };
      designs.set(id, detail);
      await route.fulfill({ status: 201, json: { success: true, data: { design: detail } } });
      return;
    }

    if (pathname.startsWith('/designs/') && method === 'GET') {
      const id = pathname.split('/')[2] ?? '';
      const existing = designs.get(id);
      if (existing) {
        await route.fulfill({ status: 200, json: { success: true, data: { design: existing } } });
        return;
      }
    }

    await route.fulfill({
      status: 200,
      json: { success: true, data: {} },
    });
  });
}

test.describe('Phase 3 Interactive 3D Apparel Design Studio', () => {
  test('supports PDP -> 3D Studio, GLB model & variant switching, camera presets, 2D<->3D parity, saving preferredMode="3d", and mobile layout', async ({
    page,
  }) => {
    test.setTimeout(90_000);

    const pageErrors: string[] = [];
    page.on('pageerror', (err) => pageErrors.push(err.message));

    const savedDocs: CanonicalDesignDocument[] = [];
    await setupStudio3DApiMock(page, savedDocs);

    // 1. Open PDP and launch directly into 3D Studio via "Preview in 3D Studio"
    await page.goto(`/product/${PRODUCT_TEE.slug}`);
    await page.getByTestId('pdp-open-studio-3d').click();
    await expect(page).toHaveURL(/\/studio\?product=signature-heavyweight-tee.*mode=3d/);

    // 3D Stage renders cleanly and displays Heavyweight Crewneck controls
    await expect(page.getByTestId('studio-3d-stage')).toBeVisible({ timeout: 25_000 });
    await expect(page.getByRole('button', { name: 'Back', exact: true })).toBeVisible();

    // 2. Add a text layer while in 3D Studio and switch variant color
    await page.getByRole('button', { name: 'Add Text Layer' }).click();
    await page.getByRole('button', { name: /^Layers/i }).click();
    await expect(page.getByText('Layer Stack (1)')).toBeVisible();

    await page.getByRole('button', { name: 'Product', exact: true }).click();
    await page.getByRole('button', { name: /Midnight Navy/i }).click();

    // 3. Switch garment blank to Executive Knit Polo -> switches GLB to Pique Polo + Left Chest preset
    await page.getByRole('button', { name: /Executive Knit Polo/i }).click();
    await expect(page.getByRole('tab', { name: /Left Chest/i })).toBeVisible();

    // Add a layer on Left Chest while in 3D Studio, then toggle to 2D Editor and verify parity
    await page.getByRole('button', { name: 'Text', exact: true }).click();
    await page.getByRole('button', { name: 'Add Text Layer' }).click();
    await page.getByTestId('studio-mode-2d').click();
    await expect(page).toHaveURL(/mode=2d/);
    await page.getByRole('button', { name: /^Layers/i }).click();
    await expect(page.getByText('Layer Stack (1)')).toBeVisible();

    await page.getByTestId('studio-mode-3d').click();
    await expect(page).toHaveURL(/mode=3d/);
    await expect(page.getByTestId('studio-3d-stage')).toBeVisible();

    // 5. Save design and verify canonical preferredMode='3d' persisted to backend
    await page.getByRole('button', { name: 'Save', exact: true }).click();
    await expect(page.getByText('Design saved (v1)')).toBeVisible();
    expect(savedDocs.length).toBeGreaterThan(0);
    expect(savedDocs[savedDocs.length - 1]?.preferredMode).toBe('3d');

    // 6. Verify mobile layout has zero horizontal overflow
    await page.setViewportSize({ width: 375, height: 812 });
    const overflowPx = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth
    );
    expect(overflowPx).toBeLessThanOrEqual(1);
    expect(pageErrors).toEqual([]);
  });

  test('degrades gracefully to accessible fallback garment preview when WebGL is disabled', async ({
    page,
  }) => {
    await page.addInitScript(() => {
      const originalGetContext = HTMLCanvasElement.prototype.getContext;
      HTMLCanvasElement.prototype.getContext = function patchedGetContext(
        type: string,
        ...rest: unknown[]
      ) {
        if (type === 'webgl2' || type === 'webgl' || type === 'experimental-webgl') {
          return null;
        }
        return originalGetContext.apply(this, [type, ...(rest as [])]);
      } as typeof HTMLCanvasElement.prototype.getContext;
    });

    await setupStudio3DApiMock(page, []);
    await page.goto(`/studio?product=${PRODUCT_TEE.slug}&mode=3d`);

    await expect(page.getByTestId('studio-3d-fallback')).toBeVisible({ timeout: 20_000 });
    await expect(page.getByText('Interactive 3D Preview Unavailable')).toBeVisible();

    // Clicking Switch to 2D Editor smoothly recovers the interactive Fabric.js editor
    await page.getByRole('button', { name: 'Switch to 2D Editor' }).click();
    await expect(page).toHaveURL(/mode=2d/);
    await expect(page.getByLabel('2D Apparel Design Canvas')).toBeVisible();
  });
});
