import { expect, test } from '@playwright/test';
import type {
  CanonicalDesignDocument,
  CartDTO,
  DesignAssetDTO,
  DesignDetailDTO,
  DesignPrintExportDTO,
  DesignSummaryDTO,
  ProductCategoryDTO,
  ProductDetailDTO,
} from '@your-choice/shared-types';

// Minimal valid 1x1 transparent PNG
const ONE_BY_ONE_PNG_BASE64 =
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

const STUDIO_CATEGORY: ProductCategoryDTO = {
  id: '11111111-1111-4111-8111-111111111101',
  slug: 't-shirts',
  parentId: null,
  nameEn: 'T-Shirts',
  nameBn: 'টি-শার্ট',
  descriptionEn: 'Combed cotton jersey blanks tailored for custom studio printing.',
  descriptionBn: 'কাস্টম স্টুডিও প্রিন্টের জন্য প্রিমিয়াম কটন টি-শার্ট ব্ল্যাঙ্কস।',
  sortOrder: 0,
  isActive: true,
  productCount: 1,
};

const STUDIO_PRODUCT: ProductDetailDTO = {
  id: '22222222-2222-4222-8222-222222222201',
  slug: 'dhaka-heavyweight-crew-tee',
  skuPrefix: 'YC-TEE-220',
  category: {
    id: STUDIO_CATEGORY.id,
    slug: STUDIO_CATEGORY.slug,
    nameEn: STUDIO_CATEGORY.nameEn,
    nameBn: STUDIO_CATEGORY.nameBn,
  },
  nameEn: 'Dhaka Heavyweight Crew Tee',
  nameBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট',
  subtitleEn: '220 GSM Combed Ring-Spun Jersey',
  subtitleBn: '২২০ জিএসএম কম্বড রিং-স্পান জার্সি',
  descriptionEn: 'Engineered for crisp DTF and screen prints with breathable everyday drape.',
  descriptionBn: 'নিখুঁত ডিটিএফ ও স্ক্রিন প্রিন্টের জন্য তৈরি আরামদায়ক কটন টি-শার্ট।',
  fabricSpecEn: '100% Combed Ring-Spun Cotton · Bio-Washed',
  fabricSpecBn: '১০০% কম্বড রিং-স্পান কটন · বায়ো-ওয়াশড',
  gsm: 220,
  fitType: 'Boxy Studio Fit',
  basePrice: '850.00',
  minPrice: '850.00',
  maxPrice: '850.00',
  currencyCode: 'BDT',
  isCustomizable: true,
  status: 'active',
  featuredOrder: 1,
  primaryImage: {
    id: '33333333-3333-4333-8333-333333333301',
    variantId: null,
    viewType: 'front',
    url: '/catalog/tee-front.svg',
    altTextEn: 'Dhaka Heavyweight Crew Tee front view',
    altTextBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট সামনের দৃশ্য',
    sortOrder: 0,
    isPrimary: true,
  },
  images: [
    {
      id: '33333333-3333-4333-8333-333333333301',
      variantId: null,
      viewType: 'front',
      url: '/catalog/tee-front.svg',
      altTextEn: 'Dhaka Heavyweight Crew Tee front view',
      altTextBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট সামনের দৃশ্য',
      sortOrder: 0,
      isPrimary: true,
    },
  ],
  variants: [
    {
      id: '44444444-4444-4444-8444-444444444401',
      sku: 'YC-TEE-220-OBS-M',
      colorNameEn: 'Obsidian Black',
      colorNameBn: 'অবসিডিয়ান কালো',
      colorHex: '#0F172A',
      sizeCode: 'M',
      priceOverride: null,
      effectivePrice: '850.00',
      currencyCode: 'BDT',
      stockQuantity: 15,
      isActive: true,
      inStock: true,
    },
    {
      id: '44444444-4444-4444-8444-444444444402',
      sku: 'YC-TEE-220-RYL-L',
      colorNameEn: 'Royal Blue',
      colorNameBn: 'রয়্যাল নীল',
      colorHex: '#1D4ED8',
      sizeCode: 'L',
      priceOverride: null,
      effectivePrice: '850.00',
      currencyCode: 'BDT',
      stockQuantity: 12,
      isActive: true,
      inStock: true,
    },
  ],
  availableColors: [
    { colorNameEn: 'Obsidian Black', colorNameBn: 'অবসিডিয়ান কালো', colorHex: '#0F172A' },
    { colorNameEn: 'Royal Blue', colorNameBn: 'রয়্যাল নীল', colorHex: '#1D4ED8' },
  ],
  availableSizes: ['M', 'L'],
  printSurfaces: ['front', 'back'],
  totalStock: 27,
  variantCount: 2,
  createdAt: '2026-11-15T10:00:00.000Z',
  updatedAt: '2026-11-15T10:00:00.000Z',
  printAreas: [
    {
      id: '55555555-5555-4555-8555-555555555501',
      surfaceKey: 'front',
      labelEn: 'Front Chest',
      labelBn: 'সামনের চেস্ট',
      physicalWidthMm: 280,
      physicalHeightMm: 360,
      targetDpi: 300,
      safeInsetMm: 10,
      coordinateSpace: 'normalized_0_1',
      mockupBounds: { x: 0.3, y: 0.24, width: 0.4, height: 0.48, rotationDeg: 0 },
      uvRegion: null,
      printMethods: ['dtf'],
      surchargeAmount: '120.00',
      currencyCode: 'BDT',
      isDefault: true,
      isActive: true,
      sortOrder: 0,
    },
    {
      id: '55555555-5555-4555-8555-555555555502',
      surfaceKey: 'back',
      labelEn: 'Back Full Print',
      labelBn: 'পিছনের পূর্ণ প্রিন্ট',
      physicalWidthMm: 300,
      physicalHeightMm: 400,
      targetDpi: 300,
      safeInsetMm: 12,
      coordinateSpace: 'normalized_0_1',
      mockupBounds: { x: 0.28, y: 0.2, width: 0.44, height: 0.54, rotationDeg: 0 },
      uvRegion: null,
      printMethods: ['dtf'],
      surchargeAmount: '150.00',
      currencyCode: 'BDT',
      isDefault: false,
      isActive: true,
      sortOrder: 1,
    },
  ],
};

test.describe('Phase 2 Professional 2D Apparel Design Studio', () => {
  test('supports PDP -> /studio workflow, text/shape/graphic/upload layers, undo/redo, JSON edit, save, 300 DPI export, custom cart add, and mobile overflow safety', async ({
    page,
  }) => {
    const assets: DesignAssetDTO[] = [];
    const designs = new Map<string, DesignDetailDTO>();
    const exportsList: DesignPrintExportDTO[] = [];

    let cart: CartDTO = {
      id: '99999999-9999-4999-8999-999999999901',
      items: [],
      itemCount: 0,
      subtotal: '0.00',
      currencyCode: 'BDT',
      hasUnavailableItems: false,
      expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
    };

    await page.route('**/api/v1/**', async (route) => {
      const req = route.request();
      const url = new URL(req.url());
      const path = url.pathname.replace(/^\/api\/v1/, '');
      const method = req.method();

      if (path === '/auth/csrf') {
        await route.fulfill({
          status: 200,
          json: { success: true, data: { csrfToken: 'studio-e2e-csrf' } },
        });
        return;
      }

      if (path === '/auth/me') {
        await route.fulfill({
          status: 200,
          json: {
            success: true,
            data: {
              authenticated: true,
              user: {
                id: 'usr-studio-1',
                email: 'designer@yourchoice.test',
                fullName: 'Nadia Karim',
                phone: '+8801712345678',
                preferredLocale: 'en',
                status: 'active',
                roles: ['customer'],
                permissions: ['designs:read:own', 'designs:write:own', 'catalog:read'],
              },
              session: {
                expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
                lastSeenAt: new Date().toISOString(),
              },
              csrfToken: 'studio-e2e-csrf',
            },
          },
        });
        return;
      }

      if (path === '/categories') {
        await route.fulfill({
          status: 200,
          json: { success: true, data: { categories: [STUDIO_CATEGORY] } },
        });
        return;
      }

      if (path === '/products') {
        await route.fulfill({
          status: 200,
          json: {
            success: true,
            data: {
              products: [STUDIO_PRODUCT],
              pagination: { page: 1, pageSize: 20, total: 1, totalPages: 1 },
              facets: { sizes: ['M', 'L'], colors: STUDIO_PRODUCT.availableColors },
            },
          },
        });
        return;
      }

      if (path === `/products/${STUDIO_PRODUCT.slug}`) {
        await route.fulfill({
          status: 200,
          json: { success: true, data: { product: STUDIO_PRODUCT } },
        });
        return;
      }

      if (path === '/cart' && method === 'GET') {
        await route.fulfill({ status: 200, json: { success: true, data: { cart } } });
        return;
      }

      if (path === '/designs/assets' && method === 'GET') {
        await route.fulfill({ status: 200, json: { success: true, data: { assets } } });
        return;
      }

      if (path === '/designs/assets/upload' && method === 'POST') {
        const asset: DesignAssetDTO = {
          id: '66666666-6666-4666-8666-666666666601',
          originalFilename: 'studio-crest.png',
          mimeType: 'image/png',
          byteSize: 2480,
          widthPx: 1800,
          heightPx: 1800,
          sha256: 'a'.repeat(64),
          previewUrl: '/api/v1/designs/assets/66666666-6666-4666-8666-666666666601/preview',
          createdAt: new Date().toISOString(),
        };
        assets.unshift(asset);
        await route.fulfill({ status: 201, json: { success: true, data: { asset } } });
        return;
      }

      if (path.startsWith('/designs/assets/') && path.endsWith('/preview')) {
        await route.fulfill({
          status: 200,
          contentType: 'image/png',
          body: Buffer.from(ONE_BY_ONE_PNG_BASE64, 'base64'),
        });
        return;
      }

      if (path === '/designs' && method === 'GET') {
        const summaries: DesignSummaryDTO[] = Array.from(designs.values());
        await route.fulfill({
          status: 200,
          json: {
            success: true,
            data: {
              designs: summaries,
              pagination: { page: 1, pageSize: 20, total: summaries.length, totalPages: 1 },
            },
          },
        });
        return;
      }

      if (path === '/designs' && method === 'POST') {
        const payload = req.postDataJSON() as {
          title: string;
          document: CanonicalDesignDocument;
        };
        const designId = '77777777-7777-4777-8777-777777777701';
        const variant =
          STUDIO_PRODUCT.variants.find((v) => v.id === payload.document.productVariantId) ??
          STUDIO_PRODUCT.variants[0]!;
        const detail: DesignDetailDTO = {
          id: designId,
          title: payload.title,
          productId: STUDIO_PRODUCT.id,
          productSlug: STUDIO_PRODUCT.slug,
          productNameEn: STUDIO_PRODUCT.nameEn,
          productNameBn: STUDIO_PRODUCT.nameBn,
          productVariantId: variant.id,
          variantSku: variant.sku,
          variantColorNameEn: variant.colorNameEn,
          variantColorNameBn: variant.colorNameBn,
          variantColorHex: variant.colorHex,
          variantSizeCode: variant.sizeCode,
          preferredMode: '2d',
          currentVersionNumber: 1,
          status: 'saved',
          customizedSurfaces: ['front'],
          estimatedCustomizationFee: '120.00',
          currencyCode: 'BDT',
          isValidForPrint: true,
          previewUrl: `/api/v1/designs/${designId}/surfaces/front/preview`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          document: { ...payload.document, designId },
          validation: {
            isValidForPrint: true,
            errorCount: 0,
            warningCount: 0,
            activePrintSurfaces: ['front'],
            issues: [],
          },
          exports: [],
        };
        designs.set(designId, detail);
        await route.fulfill({ status: 201, json: { success: true, data: { design: detail } } });
        return;
      }

      const designDetailMatch = path.match(/^\/designs\/([^/]+)$/);
      if (designDetailMatch && method === 'GET') {
        const detail = designs.get(designDetailMatch[1]!);
        if (!detail) {
          await route.fulfill({
            status: 404,
            json: { success: false, error: { code: 'NOT_FOUND', message: 'Design not found' } },
          });
          return;
        }
        await route.fulfill({ status: 200, json: { success: true, data: { design: detail } } });
        return;
      }

      if (designDetailMatch && method === 'PUT') {
        const existing = designs.get(designDetailMatch[1]!);
        const payload = req.postDataJSON() as {
          title?: string;
          document: CanonicalDesignDocument;
        };
        if (existing) {
          const updated: DesignDetailDTO = {
            ...existing,
            title: payload.title ?? existing.title,
            currentVersionNumber: existing.currentVersionNumber + 1,
            document: payload.document,
            updatedAt: new Date().toISOString(),
          };
          designs.set(existing.id, updated);
          await route.fulfill({ status: 200, json: { success: true, data: { design: updated } } });
          return;
        }
      }

      const exportMatch = path.match(
        /^\/designs\/([^/]+)\/surfaces\/([^/]+)\/export-print-master$/
      );
      if (exportMatch && method === 'POST') {
        const createdExport: DesignPrintExportDTO = {
          id: '88888888-8888-4888-8888-888888888801',
          designId: exportMatch[1]!,
          designVersionNumber: 1,
          surfaceKey: 'front',
          widthPx: 3307,
          heightPx: 4252,
          dpi: 300,
          byteSize: 184320,
          sha256: 'f'.repeat(64),
          downloadUrl: '/api/v1/designs/exports/88888888-8888-4888-8888-888888888801/download',
          createdAt: new Date().toISOString(),
        };
        exportsList.unshift(createdExport);
        const target = designs.get(exportMatch[1]!);
        if (target) {
          target.exports = [...exportsList];
        }
        await route.fulfill({
          status: 201,
          json: { success: true, data: { printExport: createdExport } },
        });
        return;
      }

      const addCartMatch = path.match(/^\/designs\/([^/]+)\/add-to-cart$/);
      if (addCartMatch && method === 'POST') {
        const target = designs.get(addCartMatch[1]!)!;
        cart = {
          id: cart.id,
          itemCount: 1,
          subtotal: '970.00',
          currencyCode: 'BDT',
          hasUnavailableItems: false,
          expiresAt: cart.expiresAt,
          items: [
            {
              id: 'cart-item-custom-1',
              variantId: target.productVariantId,
              productId: target.productId,
              productSlug: target.productSlug,
              productNameEn: target.productNameEn,
              productNameBn: target.productNameBn,
              sku: target.variantSku,
              colorNameEn: target.variantColorNameEn,
              colorNameBn: target.variantColorNameBn,
              colorHex: target.variantColorHex,
              sizeCode: 'M',
              primaryImageUrl: '/catalog/tee-front.svg',
              quantity: 1,
              availableStock: 15,
              isVariantAvailable: true,
              unitPrice: '850.00',
              customizationFee: '120.00',
              lineTotal: '970.00',
              currencyCode: 'BDT',
              designPublicId: target.id,
              customizationMeta: {
                designTitle: target.title,
                designVersionNumber: target.currentVersionNumber,
                preferredMode: '2d',
                surfaces: [
                  {
                    surfaceKey: 'front',
                    labelEn: 'Front Chest',
                    labelBn: 'সামনের চেস্ট',
                    surchargeAmount: '120.00',
                  },
                ],
              },
            },
          ],
        };
        await route.fulfill({ status: 200, json: { success: true, data: { cart } } });
        return;
      }

      await route.fulfill({ status: 200, json: { success: true, data: {} } });
    });

    // 1. Navigate from PDP -> "Customize in 2D Studio"
    await page.goto(`/product/${STUDIO_PRODUCT.slug}`);
    const openStudioBtn = page.getByTestId('pdp-open-studio');
    await expect(openStudioBtn).toBeVisible();
    await openStudioBtn.click();

    await expect(page).toHaveURL(/\/studio\?product=dhaka-heavyweight-crew-tee/);
    await expect(page.locator('#yc-studio-2d-canvas')).toBeVisible();
    await expect(page.getByText('280×360mm · 3307×4252px @ 300 DPI')).toBeVisible();

    // 2. Rename design + add Text layer + switch to Graphics and add Star + Varsity Shield
    const titleInput = page.getByLabel('Design title');
    await titleInput.fill('Dhaka Studio Drop 01');

    await page.getByRole('button', { name: 'Add Text Layer' }).click();
    await page.getByRole('button', { name: 'Graphics' }).click();
    await page.getByRole('button', { name: 'star', exact: true }).click();
    await page.getByRole('button', { name: 'Varsity Shield' }).click();

    // 3. Upload a PNG artwork and verify layer appears in Layer Stack
    await page.getByRole('button', { name: 'Upload' }).click();
    const fileInput = page.locator('input[type="file"]');
    await fileInput.setInputFiles({
      name: 'studio-crest.png',
      mimeType: 'image/png',
      buffer: Buffer.from(ONE_BY_ONE_PNG_BASE64, 'base64'),
    });

    await page.getByRole('button', { name: 'Layers' }).click();
    await expect(page.getByText('Layer Stack (4)')).toBeVisible();

    // 4. Undo & Redo layer count check
    await page.getByRole('button', { name: 'Undo' }).click();
    await expect(page.getByText('Layer Stack (3)')).toBeVisible();
    await page.getByRole('button', { name: 'Redo' }).click();
    await expect(page.getByText('Layer Stack (4)')).toBeVisible();

    // 5. Inspect & Apply Editable JSON dialog
    await page.getByRole('button', { name: 'JSON' }).click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await page.getByRole('button', { name: 'Apply Validated JSON' }).click();

    // 6. Save Design -> switches to /studio/:designId with v1 badge
    await page.getByRole('button', { name: 'Save' }).click();
    await expect(page).toHaveURL(/\/studio\/77777777-7777-4777-8777-777777777701/);
    await expect(page.getByText('Design saved (v1)')).toBeVisible();

    // 7. Export protected 300 DPI transparent PNG print master
    await page.getByRole('button', { name: '300 DPI PNG' }).click();
    await expect(page.getByText('3307 × 4252 px · RGBA Transparent PNG')).toBeVisible();
    await page.getByRole('button', { name: 'Generate 300 DPI PNG' }).click();
    await expect(page.getByRole('link', { name: 'Download PNG' })).toBeVisible();
    await page.getByRole('button', { name: 'Close', exact: true }).click();

    // 8. Add Custom Design to Cart -> Cart Drawer & /cart verify surcharge & title
    await page.getByRole('button', { name: /Add Custom to Cart/i }).click();
    await expect(page.getByText('Dhaka Studio Drop 01')).toBeVisible();
    await page.getByRole('link', { name: 'Review Full Cart' }).click();
    await expect(page).toHaveURL('/cart');
    await expect(page.getByText(/Custom Studio:\s*Dhaka Studio Drop 01/i)).toBeVisible();
    await expect(page.getByText(/970/).first()).toBeVisible();

    // 9. Verify mobile studio viewport has zero horizontal overflow
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/studio/77777777-7777-4777-8777-777777777701');
    await expect(page.locator('#yc-studio-2d-canvas')).toBeVisible();
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - window.innerWidth
    );
    expect(overflow).toBeLessThanOrEqual(2);
  });
});
