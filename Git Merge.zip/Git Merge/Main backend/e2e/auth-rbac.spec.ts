import { expect, test } from '@playwright/test';

test.describe('Phase 1A Identity, Authentication & RBAC UI Journeys', () => {
  test('Redirects unauthenticated users from protected routes and validates login/register forms cleanly on mobile & desktop', async ({
    page,
  }) => {
    // Unauthenticated guard redirects /account -> /login?redirect=%2Faccount
    await page.goto('/account');
    await expect(page).toHaveURL(/\/login\?redirect=%2Faccount$/);

    // Client-side Zod validation feedback on empty login submission
    await page.getByRole('button', { name: 'Sign In' }).click();
    await expect(page.getByText('Email address is required')).toBeVisible();
    await expect(page.getByText('Password is required')).toBeVisible();

    // Password visibility toggle works cleanly
    const toggleBtn = page.getByRole('button', { name: 'Show password' });
    await toggleBtn.click();
    await expect(page.getByRole('button', { name: 'Hide password' })).toBeVisible();

    // Mobile viewport check on /register: no horizontal overflow & >= 16px inputs
    await page.setViewportSize({ width: 390, height: 844 });
    await page.getByRole('link', { name: 'Create an account' }).click();
    await expect(page).toHaveURL(/\/register\?redirect=%2Faccount$/);

    const overflow = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      innerWidth: window.innerWidth,
    }));
    expect(overflow.scrollWidth).toBeLessThanOrEqual(overflow.innerWidth);

    const emailFontSize = await page
      .locator('#register-email')
      .evaluate((el) => Number.parseFloat(getComputedStyle(el).fontSize));
    expect(emailFontSize).toBeGreaterThanOrEqual(16);

    // Mismatched confirmPassword caught cleanly by RHF + Zod v4 resolver
    await page.fill('#register-full-name', 'Sadia Rahman');
    await page.fill('#register-email', 'sadia@example.com');
    await page.fill('#register-password', 'StrongPass123');
    await page.fill('#register-confirm-password', 'MismatchPass123');
    await page.getByRole('button', { name: 'Create Account' }).click();
    await expect(page.getByText('Passwords do not match')).toBeVisible();
  });

  test('Executes registration, session bootstrap, profile update, role-aware nav, 403 restriction, and admin access', async ({
    page,
  }) => {
    let activeUser: {
      id: string;
      email: string;
      fullName: string;
      phone: string | null;
      preferredLocale: 'en' | 'bn';
      status: 'active';
      emailVerified: boolean;
      roles: ('customer' | 'creator' | 'admin' | 'super_admin')[];
      permissions: string[];
      createdAt: string;
    } | null = null;

    await page.route('**/api/v1/**', async (route) => {
      const req = route.request();
      const url = new URL(req.url());
      const path = url.pathname;
      const meta = { requestId: 'req_playwright', timestamp: new Date().toISOString() };

      if (path === '/api/v1/auth/csrf') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { csrfToken: 'pw-csrf.sig' }, meta }),
        });
        return;
      }

      if (path === '/api/v1/auth/me') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              authenticated: Boolean(activeUser),
              user: activeUser,
              session: activeUser
                ? {
                    id: 'sess-pw-1',
                    expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
                    lastSeenAt: new Date().toISOString(),
                  }
                : null,
              csrfToken: 'pw-csrf.sig',
            },
            meta,
          }),
        });
        return;
      }

      if (path === '/api/v1/auth/register' && req.method() === 'POST') {
        const body = req.postDataJSON() as {
          fullName: string;
          email: string;
          phone?: string | null;
        };
        activeUser = {
          id: '11111111-1111-4111-8111-111111111111',
          email: body.email,
          fullName: body.fullName,
          phone: body.phone ?? null,
          preferredLocale: 'en',
          status: 'active',
          emailVerified: false,
          roles: ['customer'],
          permissions: ['catalog:read', 'profile:read:own', 'profile:write:own'],
          createdAt: new Date().toISOString(),
        };
        await route.fulfill({
          status: 201,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              user: activeUser,
              session: {
                id: 'sess-pw-1',
                expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
                lastSeenAt: new Date().toISOString(),
              },
              csrfToken: 'pw-csrf.sig',
            },
            meta,
          }),
        });
        return;
      }

      if (path === '/api/v1/users/me' && req.method() === 'PATCH' && activeUser) {
        const body = req.postDataJSON() as { fullName?: string; phone?: string | null };
        activeUser = {
          ...activeUser,
          ...(body.fullName ? { fullName: body.fullName } : {}),
          ...(body.phone !== undefined ? { phone: body.phone } : {}),
        };
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { user: activeUser }, meta }),
        });
        return;
      }

      if (path === '/api/v1/auth/logout' && req.method() === 'POST') {
        activeUser = null;
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ success: true, data: { revoked: true }, meta }),
        });
        return;
      }

      if (path === '/api/v1/auth/login' && req.method() === 'POST') {
        activeUser = {
          id: '22222222-2222-4222-8222-222222222222',
          email: 'admin@allyourchoice.com',
          fullName: 'Platform Admin',
          phone: null,
          preferredLocale: 'en',
          status: 'active',
          emailVerified: true,
          roles: ['admin'],
          permissions: [
            'audit:read',
            'catalog:read',
            'catalog:write',
            'creator:studio:access',
            'profile:read:own',
            'profile:write:own',
            'users:manage',
            'users:read',
          ],
          createdAt: new Date().toISOString(),
        };
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              user: activeUser,
              session: {
                id: 'sess-pw-admin',
                expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
                lastSeenAt: new Date().toISOString(),
              },
              csrfToken: 'pw-csrf.sig',
            },
            meta,
          }),
        });
        return;
      }

      if (path === '/api/v1/admin/overview' && activeUser?.roles.includes('admin')) {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            success: true,
            data: {
              actorId: activeUser.id,
              actorRoles: activeUser.roles,
              userCountSampled: 1,
              users: [activeUser],
            },
            meta,
          }),
        });
        return;
      }

      await route.continue();
    });

    await page.setViewportSize({ width: 1280, height: 800 });
    await page.goto('/register');

    await page.fill('#register-full-name', 'Tariqul Islam');
    await page.fill('#register-email', 'tariqul@example.com');
    await page.fill('#register-password', 'StrongPass123');
    await page.fill('#register-confirm-password', 'StrongPass123');
    await page.getByRole('button', { name: 'Create Account' }).click();

    await expect(page).toHaveURL(/\/account$/);
    await expect(page.getByRole('heading', { name: 'Tariqul Islam' })).toBeVisible();
    await expect(page.getByRole('link', { name: 'Admin', exact: true })).toBeHidden();

    // Update customer profile via CSRF-protected PATCH
    await page.fill('#account-full-name', 'Tariqul Updated');
    await page.getByRole('button', { name: 'Save Profile' }).click();
    await expect(page.getByText('Profile details updated.')).toBeVisible();

    // Attempting to visit /admin as customer displays Access Restricted UI
    await page.goto('/admin');
    await expect(page.getByRole('heading', { name: 'Access Restricted' })).toBeVisible();

    // Sign out clears session and switches nav back to guest state
    await page.getByRole('button', { name: 'Sign Out' }).click();
    await expect(page).toHaveURL(/\/$/);
    await expect(page.getByRole('link', { name: 'Sign In' })).toBeVisible();

    // Sign in as admin -> unlocks role-aware Creator Hub & Admin Console
    await page.getByRole('link', { name: 'Sign In' }).click();
    await page.fill('#login-email', 'admin@allyourchoice.com');
    await page.fill('#login-password', 'AdminPass123');
    await page.getByRole('button', { name: 'Sign In' }).click();

    await expect(page).toHaveURL(/\/account$/);
    await expect(page.getByRole('link', { name: 'Admin', exact: true })).toBeVisible();
    await page.getByRole('link', { name: 'Admin', exact: true }).click();
    await expect(
      page.getByRole('heading', { name: 'Identity & Operations Overview' })
    ).toBeVisible();
    await expect(page.locator('#main-content').getByText('Platform Admin')).toBeVisible();
  });
});
