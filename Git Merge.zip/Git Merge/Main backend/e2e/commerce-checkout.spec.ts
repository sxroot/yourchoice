import { expect, test } from '@playwright/test';
import type {
  CartDTO,
  CustomerAddressDTO,
  OrderDetailDTO,
  OrderSummaryDTO,
  PaymentProviderAvailabilityDTO,
  ProductCategoryDTO,
  ProductDetailDTO,
  ShippingZoneDTO,
} from '@your-choice/shared-types';

const TEST_CATEGORY: ProductCategoryDTO = {
  id: '11111111-1111-4111-8111-111111111101',
  slug: 't-shirts',
  parentId: null,
  nameEn: 'T-Shirts',
  nameBn: 'টি-শার্ট',
  descriptionEn: 'Combed cotton jersey blanks tailored for custom studio printing.',
  descriptionBn: 'কাস্টম স্টুডিও প্রিন্টের জন্য প্রিমিয়াম কটন টি-শার্ট ব্ল্যাঙ্কস।',
  sortOrder: 0,
  isActive: true,
  productCount: 1,
};

const TEST_PRODUCT: ProductDetailDTO = {
  id: '22222222-2222-4222-8222-222222222201',
  slug: 'dhaka-heavyweight-crew-tee',
  skuPrefix: 'YC-TEE-220',
  category: {
    id: TEST_CATEGORY.id,
    slug: TEST_CATEGORY.slug,
    nameEn: TEST_CATEGORY.nameEn,
    nameBn: TEST_CATEGORY.nameBn,
  },
  nameEn: 'Dhaka Heavyweight Crew Tee',
  nameBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট',
  subtitleEn: '220 GSM Combed Ring-Spun Jersey',
  subtitleBn: '২২০ জিএসএম কম্বড রিং-স্পান জার্সি',
  descriptionEn: 'Engineered for crisp DTF and screen prints with breathable everyday drape.',
  descriptionBn: 'নিখুঁত ডিটিএফ ও স্ক্রিন প্রিন্টের জন্য তৈরি আরামদায়ক কটন টি-শার্ট।',
  fabricSpecEn: '100% Combed Ring-Spun Cotton · Bio-Washed',
  fabricSpecBn: '১০০% কম্বড রিং-স্পান কটন · বায়ো-ওয়াশড',
  gsm: 220,
  fitType: 'Boxy Studio Fit',
  basePrice: '850.00',
  minPrice: '850.00',
  maxPrice: '850.00',
  currencyCode: 'BDT',
  isCustomizable: true,
  status: 'active',
  featuredOrder: 1,
  primaryImage: {
    id: '33333333-3333-4333-8333-333333333301',
    variantId: null,
    viewType: 'front',
    url: '/catalog/tee-front.svg',
    altTextEn: 'Dhaka Heavyweight Crew Tee front view',
    altTextBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট সামনের দৃশ্য',
    sortOrder: 0,
    isPrimary: true,
  },
  images: [
    {
      id: '33333333-3333-4333-8333-333333333301',
      variantId: null,
      viewType: 'front',
      url: '/catalog/tee-front.svg',
      altTextEn: 'Dhaka Heavyweight Crew Tee front view',
      altTextBn: 'ঢাকা হেভিওয়েট ক্রু টি-শার্ট সামনের দৃশ্য',
      sortOrder: 0,
      isPrimary: true,
    },
  ],
  variants: [
    {
      id: '44444444-4444-4444-8444-444444444401',
      sku: 'YC-TEE-220-OBS-M',
      colorNameEn: 'Obsidian Black',
      colorNameBn: 'অবসিডিয়ান কালো',
      colorHex: '#0F172A',
      sizeCode: 'M',
      priceOverride: null,
      effectivePrice: '850.00',
      currencyCode: 'BDT',
      stockQuantity: 15,
      isActive: true,
      inStock: true,
    },
  ],
  availableColors: [
    {
      colorNameEn: 'Obsidian Black',
      colorNameBn: 'অবসিডিয়ান কালো',
      colorHex: '#0F172A',
    },
  ],
  availableSizes: ['M'],
  printAreas: [],
};

const SHIPPING_ZONES: ShippingZoneDTO[] = [
  {
    id: '77777777-7777-4777-8777-777777777101',
    code: 'dhaka_metro',
    nameEn: 'Dhaka Division Express',
    nameBn: 'ঢাকা বিভাগ এক্সপ্রেস ডেলিভারি',
    divisions: ['Dhaka'],
    flatFee: '70.00',
    freeShippingThreshold: '2500.00',
    estimatedDaysMin: 1,
    estimatedDaysMax: 2,
    currencyCode: 'BDT',
    isActive: true,
  },
  {
    id: '77777777-7777-4777-8777-777777777102',
    code: 'nationwide_bd',
    nameEn: 'Nationwide Courier (Outside Dhaka Division)',
    nameBn: 'সারা বাংলাদেশ কুরিয়ার (ঢাকা বিভাগের বাইরে)',
    divisions: ['Chattogram', 'Rajshahi', 'Khulna', 'Barishal', 'Sylhet', 'Rangpur', 'Mymensingh'],
    flatFee: '130.00',
    freeShippingThreshold: '3000.00',
    estimatedDaysMin: 3,
    estimatedDaysMax: 5,
    currencyCode: 'BDT',
    isActive: true,
  },
];

const PAYMENT_PROVIDERS: PaymentProviderAvailabilityDTO[] = [
  {
    method: 'cod',
    labelEn: 'Cash on Delivery',
    labelBn: 'ক্যাশ অন ডেলিভারি (COD)',
    descriptionEn: 'Pay in cash when your courier delivers across Bangladesh.',
    descriptionBn: 'বাংলাদেশের যেকোনো স্থানে ডেলিভারির সময় কুরিয়ারকে নগদ পরিশোধ করুন।',
    enabled: true,
    configured: true,
    mode: 'offline_settlement',
    unavailableReasonEn: null,
    unavailableReasonBn: null,
  },
  {
    method: 'bkash',
    labelEn: 'bKash Payment',
    labelBn: 'বিকাশ পেমেন্ট',
    descriptionEn: 'Official bKash Tokenized Checkout (webhook verified).',
    descriptionBn: 'অফিশিয়াল বিকাশ টোকেনাইজড চেকআউট।',
    enabled: false,
    configured: false,
    mode: 'redirect_webhook',
    unavailableReasonEn: 'Requires merchant webhook credentials before activation.',
    unavailableReasonBn: 'চালু করার আগে মার্চেন্ট ওয়েবহুক সেটিংস প্রয়োজন।',
  },
];

function computeQuote(division: ShippingZoneDTO['divisions'][number], subtotalStr: string) {
  const zone = SHIPPING_ZONES.find((z) => z.divisions.includes(division)) ?? SHIPPING_ZONES[1]!;
  const subtotalNum = Number(subtotalStr);
  const threshold = Number(zone.freeShippingThreshold ?? '0');
  const qualified = threshold > 0 && subtotalNum >= threshold;
  const feeNum = qualified ? 0 : Number(zone.flatFee);
  return {
    division,
    zone,
    subtotal: subtotalNum.toFixed(2),
    shippingFee: feeNum.toFixed(2),
    freeShippingQualified: qualified,
    amountRemainingForFreeShipping: qualified
      ? null
      : Math.max(0, threshold - subtotalNum).toFixed(2),
    estimatedTotal: (subtotalNum + feeNum).toFixed(2),
    currencyCode: 'BDT',
  };
}

test.describe('Phase 1C Cart, Checkout, Order Lifecycle & Admin Fulfillment', () => {
  test('supports PDP Add to Cart -> Cart Drawer -> /cart estimator -> /checkout COD -> order confirmation & self-cancel -> admin status & COD settlement + mobile layout', async ({
    page,
  }) => {
    const addresses: CustomerAddressDTO[] = [
      {
        id: '88888888-8888-4888-8888-888888888801',
        label: 'Home Studio',
        recipientName: 'Tanvir Hasan',
        phone: '+8801712345678',
        division: 'Dhaka',
        district: 'Dhaka',
        area: 'Banani',
        addressLine: 'House 12, Road 4, Banani',
        postalCode: '1213',
        isDefault: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];

    let cart: CartDTO = {
      id: '99999999-9999-4999-8999-999999999901',
      items: [],
      itemCount: 0,
      subtotal: '0.00',
      currencyCode: 'BDT',
      hasUnavailableItems: false,
      expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
    };

    const orders: OrderDetailDTO[] = [];

    const recalcCart = () => {
      let totalCents = 0;
      let count = 0;
      for (const item of cart.items) {
        const line = Number(item.unitPrice) * item.quantity;
        item.lineTotal = line.toFixed(2);
        totalCents += line;
        count += item.quantity;
      }
      cart.subtotal = totalCents.toFixed(2);
      cart.itemCount = count;
    };

    await page.route('**/api/v1/**', async (route) => {
      const req = route.request();
      const url = new URL(req.url());
      const path = url.pathname.replace(/^\/api\/v1/, '');
      const method = req.method();

      if (path === '/auth/csrf') {
        await route.fulfill({
          status: 200,
          json: { success: true, data: { csrfToken: 'e2e-csrf' } },
        });
        return;
      }

      if (path === '/auth/me') {
        await route.fulfill({
          status: 200,
          json: {
            success: true,
            data: {
              authenticated: true,
              user: {
                id: 'usr-e2e-1',
                email: 'tanvir@yourchoice.test',
                fullName: 'Tanvir Hasan',
                phone: '+8801712345678',
                preferredLocale: 'en',
                status: 'active',
                roles: ['customer', 'admin'],
                permissions: ['orders:read:all', 'orders:write', 'catalog:read', 'users:read'],
              },
              session: {
                expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
                lastSeenAt: new Date().toISOString(),
              },
              csrfToken: 'e2e-csrf',
            },
          },
        });
        return;
      }

      if (path === '/admin/overview') {
        await route.fulfill({
          status: 200,
          json: {
            success: true,
            data: {
              actorId: 'usr-e2e-1',
              userCountSampled: 1,
              users: [
                {
                  id: 'usr-e2e-1',
                  fullName: 'Tanvir Hasan',
                  email: 'tanvir@yourchoice.test',
                  roles: ['admin'],
                },
              ],
            },
          },
        });
        return;
      }

      if (path === '/categories') {
        await route.fulfill({
          status: 200,
          json: { success: true, data: { categories: [TEST_CATEGORY] } },
        });
        return;
      }

      if (path === '/products') {
        await route.fulfill({
          status: 200,
          json: {
            success: true,
            data: {
              products: [TEST_PRODUCT],
              pagination: { page: 1, pageSize: 12, totalItems: 1, totalPages: 1 },
            },
          },
        });
        return;
      }

      if (path === `/products/${TEST_PRODUCT.slug}`) {
        await route.fulfill({
          status: 200,
          json: { success: true, data: { product: TEST_PRODUCT } },
        });
        return;
      }

      if (path === '/users/me/addresses') {
        await route.fulfill({ status: 200, json: { success: true, data: { addresses } } });
        return;
      }

      if (path === '/shipping/zones') {
        await route.fulfill({
          status: 200,
          json: { success: true, data: { zones: SHIPPING_ZONES } },
        });
        return;
      }

      if (path === '/shipping/quote') {
        const division = (url.searchParams.get('division') ??
          'Dhaka') as ShippingZoneDTO['divisions'][number];
        const subtotal = url.searchParams.get('subtotal') ?? '0.00';
        await route.fulfill({
          status: 200,
          json: { success: true, data: { quote: computeQuote(division, subtotal) } },
        });
        return;
      }

      if (path === '/checkout/options') {
        await route.fulfill({
          status: 200,
          json: {
            success: true,
            data: { shippingZones: SHIPPING_ZONES, paymentProviders: PAYMENT_PROVIDERS },
          },
        });
        return;
      }

      if (path === '/cart' && method === 'GET') {
        await route.fulfill({ status: 200, json: { success: true, data: { cart } } });
        return;
      }

      if (path === '/cart/items' && method === 'POST') {
        const body = req.postDataJSON() as { variantId: string; quantity: number };
        const variant = TEST_PRODUCT.variants[0]!;
        const existing = cart.items.find((i) => i.variantId === body.variantId);
        if (existing) {
          existing.quantity += body.quantity;
        } else {
          cart.items.push({
            id: '55555555-5555-4555-8555-555555555501',
            variantId: variant.id,
            productId: TEST_PRODUCT.id,
            productSlug: TEST_PRODUCT.slug,
            productNameEn: TEST_PRODUCT.nameEn,
            productNameBn: TEST_PRODUCT.nameBn,
            sku: variant.sku,
            colorNameEn: variant.colorNameEn,
            colorNameBn: variant.colorNameBn,
            colorHex: variant.colorHex,
            sizeCode: variant.sizeCode,
            primaryImageUrl: TEST_PRODUCT.primaryImage?.url ?? null,
            quantity: body.quantity,
            availableStock: variant.stockQuantity,
            isVariantAvailable: true,
            unitPrice: variant.effectivePrice,
            customizationFee: '0.00',
            lineTotal: (Number(variant.effectivePrice) * body.quantity).toFixed(2),
            currencyCode: 'BDT',
            designPublicId: null,
            customizationMeta: null,
          });
        }
        recalcCart();
        await route.fulfill({ status: 201, json: { success: true, data: { cart } } });
        return;
      }

      if (path.startsWith('/cart/items/') && method === 'PATCH') {
        const itemId = path.split('/').pop()!;
        const body = req.postDataJSON() as { quantity: number };
        const item = cart.items.find((i) => i.id === itemId);
        if (item) {
          item.quantity = body.quantity;
          recalcCart();
        }
        await route.fulfill({ status: 200, json: { success: true, data: { cart } } });
        return;
      }

      if (path === '/orders' && method === 'POST') {
        const quote = computeQuote(addresses[0]!.division, cart.subtotal);
        const orderNumber = `YC-20261115-E2E${String(orders.length + 1).padStart(3, '0')}`;
        const created: OrderDetailDTO = {
          id: `66666666-6666-4666-8666-66666666660${orders.length + 1}`,
          orderNumber,
          customerEmail: 'tanvir@yourchoice.test',
          customerPhone: addresses[0]!.phone,
          shippingDivision: addresses[0]!.division,
          shippingZoneCode: quote.zone.code,
          shippingZoneName: quote.zone.nameEn,
          paymentMethod: 'cod',
          paymentStatus: 'unpaid',
          orderStatus: 'pending',
          subtotalAmount: quote.subtotal,
          shippingAmount: quote.shippingFee,
          discountAmount: '0.00',
          totalAmount: quote.estimatedTotal,
          currencyCode: 'BDT',
          itemCount: cart.itemCount,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          shippingAddress: {
            label: addresses[0]!.label,
            recipientName: addresses[0]!.recipientName,
            phone: addresses[0]!.phone,
            division: addresses[0]!.division,
            district: addresses[0]!.district,
            area: addresses[0]!.area,
            addressLine: addresses[0]!.addressLine,
            postalCode: addresses[0]!.postalCode,
          },
          customerNote: null,
          cancelledAt: null,
          cancellationReason: null,
          canCustomerCancel: true,
          allowedNextStatuses: ['confirmed', 'cancelled'],
          items: cart.items.map((item) => ({
            id: item.id,
            productSlug: item.productSlug,
            productNameEn: item.productNameEn,
            productNameBn: item.productNameBn,
            sku: item.sku,
            colorNameEn: item.colorNameEn,
            colorNameBn: item.colorNameBn,
            colorHex: item.colorHex,
            sizeCode: item.sizeCode,
            primaryImageUrl: item.primaryImageUrl,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            customizationFee: item.customizationFee,
            lineTotal: item.lineTotal,
            currencyCode: item.currencyCode,
            designPublicId: null,
            designTitle: null,
            productionSpec: null,
          })),
          statusHistory: [
            {
              id: 1,
              fromStatus: null,
              toStatus: 'pending',
              actorRole: 'customer',
              note: 'Order placed via checkout',
              createdAt: new Date().toISOString(),
            },
          ],
          paymentTransactions: [
            {
              id: '77777777-0000-4000-8000-000000000001',
              gateway: 'cod',
              transactionRef: `COD-${orderNumber}`,
              providerPaymentId: null,
              amount: quote.estimatedTotal,
              currencyCode: 'BDT',
              status: 'unpaid',
              verificationSource: 'cod_promise',
              verifiedAt: null,
              createdAt: new Date().toISOString(),
            },
          ],
        };
        orders.unshift(created);
        cart = { ...cart, items: [], itemCount: 0, subtotal: '0.00' };
        await route.fulfill({ status: 201, json: { success: true, data: { order: created } } });
        return;
      }

      if (path === '/orders' && method === 'GET') {
        const summaries: OrderSummaryDTO[] = orders.map((o) => ({ ...o }));
        await route.fulfill({
          status: 200,
          json: {
            success: true,
            data: {
              orders: summaries,
              pagination: { page: 1, pageSize: 15, totalItems: summaries.length, totalPages: 1 },
            },
          },
        });
        return;
      }

      if (path.startsWith('/orders/') && path.endsWith('/cancel') && method === 'POST') {
        const orderNumber = path.split('/')[2]!;
        const target = orders.find((o) => o.orderNumber === orderNumber)!;
        target.orderStatus = 'cancelled';
        target.canCustomerCancel = false;
        target.allowedNextStatuses = [];
        target.cancelledAt = new Date().toISOString();
        target.statusHistory.push({
          id: target.statusHistory.length + 1,
          fromStatus: 'pending',
          toStatus: 'cancelled',
          actorRole: 'customer',
          note: 'Cancelled by customer',
          createdAt: new Date().toISOString(),
        });
        await route.fulfill({ status: 200, json: { success: true, data: { order: target } } });
        return;
      }

      if (path.startsWith('/orders/') && method === 'GET') {
        const orderNumber = path.split('/')[2]!;
        const target = orders.find((o) => o.orderNumber === orderNumber);
        if (!target) {
          await route.fulfill({
            status: 404,
            json: { success: false, error: { code: 'NOT_FOUND', message: 'Not found' } },
          });
          return;
        }
        await route.fulfill({ status: 200, json: { success: true, data: { order: target } } });
        return;
      }

      if (path === '/admin/orders' && method === 'GET') {
        await route.fulfill({
          status: 200,
          json: {
            success: true,
            data: {
              orders,
              pagination: { page: 1, pageSize: 25, totalItems: orders.length, totalPages: 1 },
            },
          },
        });
        return;
      }

      if (path.startsWith('/admin/orders/') && path.endsWith('/status') && method === 'PATCH') {
        const orderNumber = path.split('/')[3]!;
        const body = req.postDataJSON() as {
          toStatus: OrderDetailDTO['orderStatus'];
          note: string | null;
        };
        const target = orders.find((o) => o.orderNumber === orderNumber)!;
        const fromStatus = target.orderStatus;
        target.orderStatus = body.toStatus;
        target.canCustomerCancel = body.toStatus === 'pending' || body.toStatus === 'confirmed';
        target.allowedNextStatuses =
          body.toStatus === 'confirmed' ? ['processing', 'cancelled'] : [];
        target.statusHistory.push({
          id: target.statusHistory.length + 1,
          fromStatus,
          toStatus: body.toStatus,
          actorRole: 'admin',
          note: body.note,
          createdAt: new Date().toISOString(),
        });
        await route.fulfill({ status: 200, json: { success: true, data: { order: target } } });
        return;
      }

      if (
        path.startsWith('/admin/orders/') &&
        path.endsWith('/payment-settlement') &&
        method === 'POST'
      ) {
        const orderNumber = path.split('/')[3]!;
        const body = req.postDataJSON() as { transactionRef: string };
        const target = orders.find((o) => o.orderNumber === orderNumber)!;
        target.paymentStatus = 'paid';
        target.paymentTransactions[0]!.status = 'paid';
        target.paymentTransactions[0]!.transactionRef = body.transactionRef;
        await route.fulfill({ status: 200, json: { success: true, data: { order: target } } });
        return;
      }

      if (path.startsWith('/admin/orders/') && method === 'GET') {
        const orderNumber = path.split('/')[3]!;
        const target = orders.find((o) => o.orderNumber === orderNumber);
        await route.fulfill({ status: 200, json: { success: true, data: { order: target } } });
        return;
      }

      await route.fulfill({ status: 200, json: { success: true, data: {} } });
    });

    // 1. PDP -> Add to Cart -> Slide-over Cart Drawer opens with badge 1
    await page.goto(`/product/${TEST_PRODUCT.slug}`);
    await page.getByTestId('pdp-add-to-cart').click();
    await expect(page.getByTestId('cart-drawer')).toBeVisible();
    await expect(page.getByTestId('cart-badge-count')).toHaveText('1');

    // 2. Visit /cart, increase quantity to 2 (1700 + 70 Dhaka = 1770), switch estimator to Chattogram (130), proceed to checkout
    await page.getByRole('link', { name: 'Review Full Cart' }).click();
    await expect(page).toHaveURL('/cart');
    await page.getByLabel('Increase quantity').first().click();
    await expect(page.getByTestId('cart-estimated-total')).toContainText('1770.00');

    await page.getByTestId('cart-proceed-checkout').click();
    await expect(page).toHaveURL('/checkout');

    // Verify bKash is honestly marked unavailable/disabled and COD is selectable
    await expect(page.getByTestId('payment-option-bkash')).toBeDisabled();
    await expect(page.getByTestId('payment-option-cod')).toBeEnabled();
    await expect(page.getByTestId('checkout-total-amount')).toContainText('1770.00');

    // Place COD order -> lands on /orders/:orderNumber?placed=1
    await page.getByTestId('place-order-button').click();
    await expect(page.getByTestId('order-confirmation-banner')).toBeVisible();
    const orderNum1 = (await page.getByTestId('order-number-heading').innerText()).trim();
    expect(orderNum1).toMatch(/^YC-\d{8}-/);

    // 3. Cancel first order self-service
    await page.getByTestId('cancel-order-button').click();
    await expect(page.getByTestId('cancel-order-button')).toBeHidden();

    // 4. Place a second order, then open /admin Orders tab to confirm + settle COD
    await page.goto(`/product/${TEST_PRODUCT.slug}`);
    await page.getByTestId('pdp-add-to-cart').click();
    await page.getByRole('link', { name: 'Checkout' }).click();
    await page.getByTestId('place-order-button').click();
    const orderNum2 = (await page.getByTestId('order-number-heading').innerText()).trim();

    await page.goto('/admin');
    await page.getByRole('tab', { name: 'Orders & Payments' }).click();
    await page.getByTestId(`admin-manage-order-${orderNum2}`).click();
    await page.getByTestId('admin-transition-confirmed').click();
    await page.getByLabel('Courier / Receipt Reference').fill('STEADFAST-COD-9901');
    await page.getByTestId('admin-settle-cod-button').click();
    await expect(page.getByRole('dialog').getByText('Paid')).toBeVisible();
    await page.getByRole('button', { name: 'Close', exact: true }).click();

    // 5. Verify mobile responsiveness (390px) and zero horizontal overflow on /cart and /checkout
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto('/cart');
    const hasCartOverflow = await page.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth + 1
    );
    expect(hasCartOverflow).toBe(false);

    // Language switch to Bangla
    await page.getByTestId('locale-switcher').click();
    await expect(page.locator('html')).toHaveAttribute('lang', 'bn');
    await expect(page.getByRole('heading', { name: 'শপিং ব্যাগ', exact: true })).toBeVisible();
    await page.getByTestId('locale-switcher').click();
  });
});
