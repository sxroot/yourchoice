import { expect, test } from '@playwright/test';

test.describe('Phase 0 Foundation Smoke', () => {
  test('API /api/health returns safe runtime status', async ({ request }) => {
    const response = await request.get('http://localhost:4000/api/health');
    expect(response.status()).toBe(200);

    const payload = (await response.json()) as {
      success: boolean;
      data: {
        status: string;
        service: string;
        checks: { database: { dialect: string; status: string } };
      };
    };

    expect(payload.success).toBe(true);
    expect(payload.data.service).toBe('YOUR CHOICE');
    expect(['healthy', 'degraded']).toContain(payload.data.status);
    expect(payload.data.checks.database.dialect).toBe('mariadb');
  });

  test('Frontend application shell renders and queries health status', async ({ page }) => {
    await page.goto('/');

    await expect(page.getByRole('heading', { name: /Make it yours/i })).toBeVisible();
    await expect(page.getByText('Design it. Wear it. Earn from it.').first()).toBeVisible();
    await page.locator('.home-status summary').click();
    await expect(page.locator('.home-status__content')).toContainText(/API HEALTHY|UNAVAILABLE/);
  });
});
