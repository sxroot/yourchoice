# Infrastructure Foundation

This directory stores deployment, containerization, and reverse-proxy templates for **YOUR CHOICE**.

## Contents

- [`docker/docker-compose.mariadb.yml`](docker/docker-compose.mariadb.yml): Optional local MariaDB 10.11 container for development when a local Windows/Linux MariaDB service is not installed.
- `nginx/` (queued for Phase 7): Production reverse-proxy and TLS configuration templates.
