import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(currentDir, '..');
const envPath = path.join(rootDir, '.env');
const examplePath = path.join(rootDir, '.env.example');

if (!fs.existsSync(examplePath)) {
  console.error('[check:env] Missing .env.example at repository root.');
  process.exit(1);
}

if (!fs.existsSync(envPath)) {
  console.warn(
    '[check:env] No .env file found at repository root. Copy .env.example to .env before starting API or running DB migrations.'
  );
  process.exit(0);
}

console.info('[check:env] Root .env file is present.');
