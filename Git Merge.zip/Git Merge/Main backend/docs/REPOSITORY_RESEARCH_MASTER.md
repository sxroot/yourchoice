# YOUR CHOICE — Master Repository Research Report

> **Scope Completed:** Phase 0 (Architecture & Development Foundation) and Phase 2 (Premium UI/UX Design System)  
> **Scope Queued Next:** Phase 1 (eCommerce), Phases 3–4 (Design Studio & Mockup Rendering), Phases 5–6 (Creator Marketplace & Rewards), Phases 7–10 (Payments, Production, Shipping, Admin), Phases 11–13 (SEO, Security/Performance, Testing/Deployment)  
> **Methodology:** Weighted scoring (`1–10`) across Maintainability (`20%`), Security (`20%`), Compatibility (`15%`), Documentation (`15%`), Customization (`10%`), Performance (`10%`), and Community/Maintenance (`10%`). Any metric not directly verified during live research is explicitly labeled `unverified`.

---

## 1. Phase 0 — Architecture & Development Foundation Research

### 1.1 Candidate Repository Profiles

#### 1. `expressjs/express`

- **GitHub URL:** `https://github.com/expressjs/express`
- **Official Docs URL:** `https://expressjs.com/`
- **Main Purpose:** Minimalist, unopinionated HTTP web framework for Node.js REST APIs.
- **Technology Stack:** Node.js, JavaScript/TypeScript (`@types/express`).
- **Licence:** **MIT**
- **Latest Known Release / Activity:** 160+ releases; npm latest verified `^5.3.0` (`Express 5`).
- **Stars / Community:** ~70k+ stars.
- **Advantages:** Matches master architecture; Express 5 includes native async error propagation; massive middleware ecosystem (`helmet`, `cors`, `express-rate-limit`).
- **Limitations:** Unopinionated structure requires disciplined modular boundaries, explicit Zod validation, and centralized error handling.
- **Integration Complexity:** Low (already bootstrapped in `apps/api`).
- **Compatibility with YOUR CHOICE:** Full.
- **Weighted Score:** `8.95 / 10` (`M:9 S:8 Comp:10 D:9 Cust:9 P:8 Comm:10`)
- **Recommendation:** **USE**

#### 2. `drizzle-team/drizzle-orm`

- **GitHub URL:** `https://github.com/drizzle-team/drizzle-orm`
- **Official Docs URL:** `https://orm.drizzle.team`
- **Main Purpose:** Type-safe SQL-first TypeScript ORM and schema migration toolkit (`drizzle-kit`).
- **Technology Stack:** TypeScript, `mysql2` dialect (`drizzle-orm/mysql2`) supporting MariaDB 10.11+.
- **Licence:** **Apache-2.0**
- **Latest Known Release / Activity:** `0.45.4` (actively iterating toward `v1.0.0-rc`).
- **Stars / Community:** ~36.3k stars.
- **Advantages:** Zero hidden query-engine binary overhead, transparent SQL migrations, strong TypeScript inference, explicit transaction control for inventory/reward ledgers.
- **Limitations:** Pre-1.0 API surface occasionally evolves between minor releases; MariaDB connects through MySQL wire dialect (`mysql2`), requiring careful verification of MariaDB-specific SQL defaults.
- **Integration Complexity:** Low (already configured in `database/`).
- **Compatibility with YOUR CHOICE:** Full.
- **Weighted Score:** `9.25 / 10` (`M:9 S:9 Comp:10 D:9 Cust:9 P:10 Comm:9`)
- **Recommendation:** **USE**

#### 3. `sidorares/node-mysql2` vs `mariadb-corporation/mariadb-connector-nodejs`

- **`sidorares/node-mysql2`**:
  - **GitHub URL:** `https://github.com/sidorares/node-mysql2` | **Docs URL:** `unverified` separate domain (npm/README)
  - **Licence:** **MIT** | **Stars:** ~4.4k | **Latest Release:** npm `3.24.6` observed (GitHub tag date `unverified`)
  - **Advantages:** Native Drizzle ORM primary driver (`drizzle-orm/mysql2`), permissive MIT license, connection pooling, prepared statements.
  - **Limitations:** Targets MySQL wire protocol rather than MariaDB-only extensions.
  - **Weighted Score:** `8.70 / 10` (`M:8 S:9 Comp:10 D:8 Cust:8 P:9 Comm:9`) -> **USE**
- **`mariadb-corporation/mariadb-connector-nodejs`**:
  - **GitHub URL:** `https://github.com/mariadb-corporation/mariadb-connector-nodejs` | **Docs URL:** `mariadb.com` (exact sub-URL `unverified`)
  - **Licence:** **LGPL-2.1 (or later)** | **Stars:** ~410+ | **Latest Release:** `unverified`
  - **Limitations & Licence Risk:** Copyleft **LGPL-2.1** introduces linking/bundling compliance obligations if bundled into proprietary artifacts, and Drizzle's first-party MySQL/MariaDB driver is `mysql2` rather than `mariadb`.
  - **Weighted Score:** `7.85 / 10` (`M:8 S:9 Comp:7 D:8 Cust:7 P:9 Comm:6`) -> **AVOID**

#### 4. Authentication Foundation: `better-auth/better-auth` vs `lucia-auth/lucia` vs Custom `argon2` + MariaDB Sessions

- **`better-auth/better-auth`**:
  - **GitHub URL:** `https://github.com/better-auth/better-auth` | **Docs URL:** `https://better-auth.com`
  - **Purpose:** Comprehensive TypeScript authentication framework with first-party `@better-auth/drizzle-adapter` supporting MySQL/MariaDB and Express (`toNodeHandler`, `fromNodeHeaders`).
  - **Licence:** **MIT** | **Stars:** ~30.7k+ | **Latest Release:** `v1.7.x` line (active patch cadence including `v1.7.16` / `v1.8.x` notes).
  - **Critical Security & Limitation Findings:** Research surfaced multiple 2025–2026 CVEs (`CVE-2025-61928` API key bypass pre-`1.3.26`, `CVE-2026-67337` cookieCache 2FA bypass pre-`1.4.9`, `CVE-2026-69570` verification context reuse fixed in `1.7.7`, `CVE-2026-80192` SSO domain race pre-`1.6.27`), plus Express caveats: requires explicit `baseURL` (prevents host-header injection), requires `fromNodeHeaders` header mapping, and lacks built-in global concurrent-session limits without custom hooks.
  - **Integration Complexity:** Medium.
  - **Weighted Score:** `7.95 / 10` (`M:8 S:7 Comp:8 D:9 Cust:7 P:8 Comm:9`) -> **CUSTOMIZE / REFERENCE** (or evaluate against lean custom MariaDB session auth in Phase 1 before finalizing).
- **`lucia-auth/lucia`**:
  - **GitHub URL:** `https://github.com/lucia-auth/lucia` | **Docs URL:** `https://lucia-auth.com`
  - **Licence:** **MIT** | **Stars:** ~10.4k | **Status:** **Deprecated (early 2025)**.
  - **Weighted Score:** `6.00 / 10` (`M:2 S:7 Comp:6 D:8 Cust:9 P:9 Comm:3`) -> **AVOID** as package; **REFERENCE** session-token hashing concepts.
- **`ranisalt/node-argon2`**:
  - **GitHub URL:** `https://github.com/ranisalt/node-argon2` | **Docs URL:** `https://www.npmjs.com/package/argon2`
  - **Licence:** **MIT** | **Stars:** ~2.2k+ | **Releases:** 60+ releases.
  - **Purpose:** OWASP-recommended Argon2id password hashing bindings for Node.js.
  - **Weighted Score:** `8.65 / 10` (`M:8 S:10 Comp:9 D:8 Cust:8 P:9 Comm:8`) -> **USE** (if using lean custom session auth or custom password flows).

#### 5. Validation, Logging, Monorepo & Testing Core

- **`colinhacks/zod`** (`https://github.com/colinhacks/zod` | `https://zod.dev`) — **MIT**, ~44.2k stars, `v4.6.7` verified: `9.25 / 10` -> **USE**
- **`pinojs/pino`** (`https://github.com/pinojs/pino` | `https://getpino.io`) — **MIT**, ~18.3k stars, `v10.4.0` verified: `9.15 / 10` -> **USE**
- **`pnpm/pnpm`** (`https://github.com/pnpm/pnpm` | `https://pnpm.io`) — **MIT**, ~37k+ stars: `9.15 / 10` -> **USE**
- **`vitest-dev/vitest`** (`https://github.com/vitest-dev/vitest` | `https://vitest.dev/`) — **MIT**, ~17k+ stars, 450+ releases (`5.1.0` verified): `9.25 / 10` -> **USE**
- **`microsoft/playwright`** (`https://github.com/microsoft/playwright` | `https://playwright.dev/`) — **Apache-2.0**, ~82k+ stars: `9.25 / 10` -> **USE**
- **`helmetjs/helmet`** (`https://github.com/helmetjs/helmet`) — **MIT**, ~11k stars: **USE**
- **`expressjs/cors`** (`https://github.com/expressjs/cors`) — **MIT**, ~6.2k stars: **USE**
- **`express-rate-limit/express-rate-limit`** (`https://github.com/express-rate-limit/express-rate-limit`) — **MIT**, ~3.3k stars: **USE** (add in Phase 1 auth/API endpoints)
- **`vercel/turborepo`** (`https://github.com/vercel/turborepo` | docs `unverified`) — **MIT**, ~31.3k stars: `8.65 / 10` -> **REFERENCE** (defer until workspace build caching justifies additional tooling).

#### 6. Architecture Starter References

- **`alan2207/bulletproof-react`** (`https://github.com/alan2207/bulletproof-react`) — **MIT**, ~36k+ stars, Vite + React + Vitest + Playwright + shadcn/ui architecture: `8.70 / 10` -> **REFERENCE** (feature-slice organization).
- **`edwinhern/express-typescript`** (`https://github.com/edwinhern/express-typescript`) — **MIT**, ~1.2k stars, release `unverified`: `7.90 / 10` -> **REFERENCE**.
- **`goldbergyoni/nodebestpractices`** (`https://github.com/goldbergyoni/nodebestpractices`) — **CC-BY-SA-4.0**, ~105.7k stars: `8.65 / 10` -> **REFERENCE** (checklist only; ShareAlike license prevents copying source/text directly into MIT/commercial code).
- **`seanpmaxwell/express5-typescript-template`** (`https://github.com/seanpmaxwell/express5-typescript-template`) — **No formal license file**, ~32 stars: `6.40 / 10` -> **AVOID** (unlicensed code cannot be safely adopted commercially).

---

## 2. Phase 2 — Premium UI/UX Design System Research

### 2.1 Candidate Repository Profiles

#### 1. `shadcn-ui/ui` + `radix-ui/primitives` + `tailwindlabs/tailwindcss` (v4)

- **`shadcn-ui/ui`**: `https://github.com/shadcn-ui/ui` | Docs: `https://ui.shadcn.com` | **MIT** | ~128k+ stars | Continuous changeset releases.
- **`radix-ui/primitives`**: `https://github.com/radix-ui/primitives` | Docs: `https://www.radix-ui.com` | **MIT** | ~19.5k+ stars | Regular component patches.
- **`tailwindlabs/tailwindcss`**: `https://github.com/tailwindlabs/tailwindcss` | Docs: `unverified` exact doc URL via search (`v4.3.5` npm verified) | **MIT** | ~98.6k stars.
- **Advantages:** Full code ownership in `apps/web/src/components/ui`, WAI-ARIA keyboard/focus/screen-reader accessibility out-of-the-box via Radix Primitives, Tailwind CSS v4 native CSS tokens, works across both consumer storefront and creator/admin dashboards with distinct density skins.
- **Limitations:** Requires maintaining copied component files internally and manually assembling complex data/analytics screens (solved cleanly by pairing with TanStack Table & Query).
- **Weighted Scores:** `shadcn-ui/ui`: `9.35 / 10` (**USE / CUSTOMIZE**), `radix-ui/primitives`: `9.15 / 10` (**USE**).

#### 2. `adobe/react-spectrum` (React Aria Components)

- **GitHub URL:** `https://github.com/adobe/react-spectrum` | **Docs URL:** `https://react-aria.adobe.com`
- **Licence:** **Apache-2.0** | **Stars:** ~15.9k+ | **Latest Release:** `unverified` exact tag.
- **Advantages:** Best-in-class WAI-ARIA rigor, 30+ locale i18n/RTL support, and low-level hooks for specialized Color Pickers / Sliders / Grids.
- **Limitations:** Mixing React Aria and Radix across basic dialogs/selects adds redundant bundle/API surface.
- **Weighted Score:** `8.85 / 10` (`M:9 S:9 Comp:8 D:9 Cust:9 P:9 Comm:9`) -> **REFERENCE** (candidate supporting primitive ONLY if Design Studio color/range controls in Phase 3 require React Aria hooks).

#### 3. `mui/base-ui` & `tailwindlabs/headlessui`

- **`mui/base-ui`**: `https://github.com/mui/base-ui` | Docs: `https://base-ui.com/` | **MIT** | ~11.4k stars -> `8.55 / 10` (**REFERENCE**; emerging alternative primitive engine supported by shadcn).
- **`tailwindlabs/headlessui`**: `https://github.com/tailwindlabs/headlessui` | Docs: `unverified` | **MIT** | ~28.8k+ stars -> `8.45 / 10` (**AVOID** as primary; narrower primitive catalog than Radix/shadcn).

#### 4. Heavy Pre-Styled Suites: `mantinedev/mantine` & `ant-design/ant-design`

- **`mantinedev/mantine`**: `https://github.com/mantinedev/mantine` | Docs: `https://mantine.dev` | **MIT** | ~31.9k+ stars | `v9.x` -> `7.75 / 10` (**AVOID** — CSS Modules architecture duplicates Tailwind CSS v4).
- **`ant-design/ant-design`**: `https://github.com/ant-design/ant-design` | Docs: `unverified` | **MIT** | ~96.6k+ stars | `v6.x` -> `7.25 / 10` (**AVOID** — opinionated enterprise aesthetic conflicts with premium apparel storefront identity).

#### 5. Animation, Icons, Marketing Blocks & Dashboard Templates

- **`motiondivision/motion`** (`https://github.com/motiondivision/motion` | `https://motion.dev`) — **MIT**, ~35.2k stars: `8.90 / 10` -> **USE** (supporting micro-interactions, cart drawer, modal sheets; enforce `prefers-reduced-motion`).
- **`lucide-icons/lucide`** (`https://github.com/lucide-icons/lucide` | `https://lucide.dev`) — **ISC**, ~25.8k stars: `9.15 / 10` -> **USE**.
- **`magicuidesign/magicui`** (`https://github.com/magicuidesign/magicui` | docs `unverified`) — **MIT**, ~23.3k stars: `8.15 / 10` -> **CUSTOMIZE** selectively for hero/editorial landing sections only.
- **Aceternity UI** (`https://ui.aceternity.com/licensing`) — Hybrid free snippets + commercial **Aceternity License** for Pro blocks (prohibits UI kit/template redistribution); no unified MIT package repo: `7.05 / 10` -> **AVOID**.
- **`satnaing/shadcn-admin`** (`https://github.com/satnaing/shadcn-admin` | Demo: `https://shadcn-admin.netlify.app/`) — **MIT**, ~16.7k+ stars, `v2.2.1`+: `8.70 / 10` -> **REFERENCE / CUSTOMIZE** (matches Vite + React + TypeScript + shadcn/ui!).
- **`Kiranism/next-shadcn-dashboard-starter`** (`https://github.com/Kiranism/next-shadcn-dashboard-starter`) — **MIT**, stars `unverified`, Next.js + Clerk coupled: `7.60 / 10` -> **REFERENCE** (layout patterns only).
- **`TanStack/table`** (`https://github.com/TanStack/table` | `v9.x` / `~28.5k` / **MIT**) -> `9.25 / 10` **USE**.
- **`TanStack/query`** (`https://github.com/TanStack/query` | `v5.x` / `~50.6k` / **MIT**) -> `9.25 / 10` **USE**.
- **`remix-run/react-router`** (`https://github.com/remix-run/react-router` | `v7/v8` / `~56.6k+` / **MIT**) -> `9.15 / 10` **USE**.
- **`TanStack/router`** (`https://github.com/TanStack/router` | `v1.160+` / `~15.3k+` / **MIT**) -> `8.90 / 10` **REFERENCE**.
- **`vercel/commerce`** (`https://github.com/vercel/commerce` | **MIT** | ~14.3k | **Archived**) & **`medusajs/nextjs-starter-medusa`** (**MIT** | ~2.8k | **Deprecated**) -> **AVOID** (unmaintained/deprecated Next.js templates).
- **`tremorlabs/tremor`** (`https://github.com/tremorlabs/tremor` | `https://www.tremor.so/` | **Apache-2.0** | ~3.7k core) -> **REFERENCE** for admin/creator KPI card visuals.
- **`ariakit/ariakit`** (`https://github.com/ariakit/ariakit` | `https://ariakit.org/` | Dual: MIT packages + proprietary Ariakit Plus | ~8.6k) -> **REFERENCE** only (watch dual licensing).
