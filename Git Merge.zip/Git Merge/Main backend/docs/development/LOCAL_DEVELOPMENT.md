# Local Development & Environment Setup Guide

This guide covers provisioning, running, migrating, and verifying the **YOUR CHOICE** modular monolith locally on Windows or Unix-like systems.

---

## 1. Prerequisites

- **Node.js:** `>= 20.19.0` (verified on `v24.14.0`)
- **pnpm:** `>= 10.0.0` (verified on `10.33.0`)
- **MariaDB:** `10.11+` (via Docker Compose in `infrastructure/docker/docker-compose.mariadb.yml` or local MariaDB installation)
- **Git:** Recommended for version control and baseline safety before Phase 1 development

---

## 2. Initial Workspace Setup

### Step 1: Install Workspace Dependencies

```powershell
pnpm install
```

### Step 2: Configure Environment Variables

Copy `.env.example` to `.env` at the repository root and update database/session values before running migrations or Phase 1+ APIs:

```powershell
Copy-Item .env.example .env
pnpm check:env
```

> **Note (`NODE_ENV=development`):** `@your-choice/api` supplies safe fallback defaults for `/api/health` and unit tests even before `.env` is created, but `pnpm db:migrate` and `pnpm db:seed` expect your configured local MariaDB credentials in `.env` (matching `.env.example`).

### Step 3: Build Shared Workspace Packages

```powershell
pnpm build:packages
```

---

## 3. Provision MariaDB 10.11+ & Apply Migrations

### Option A — Docker Compose (Recommended)

```powershell
docker compose -f infrastructure/docker/docker-compose.mariadb.yml up -d
```

### Option B — Native Local MariaDB 10.11+ Instance

Create the local database and user matching `.env`:

```sql
CREATE DATABASE IF NOT EXISTS your_choice_dev
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'your_choice_dev'@'localhost'
  IDENTIFIED BY 'change_me_local_dev_password';

GRANT ALL PRIVILEGES ON your_choice_dev.* TO 'your_choice_dev'@'localhost';
FLUSH PRIVILEGES;
```

### Apply Migrations & Initial Seed

```powershell
pnpm db:migrate
pnpm db:seed
```

To generate new SQL migrations after editing `database/schema/*.ts`:

```powershell
pnpm db:generate
```

---

## 4. Running Frontend & Backend

### Start Both Concurrently (`web` + `api`)

```powershell
pnpm dev
```

### Start Services Independently

- **Backend API (`http://localhost:4000`):**

  ```powershell
  pnpm --filter @your-choice/api dev
  ```

- **Frontend Web (`http://localhost:5173`, proxies `/api/*` -> `http://localhost:4000`):**

  ```powershell
  pnpm --filter @your-choice/web dev
  ```

### Health-Check Endpoints

- `GET http://localhost:4000/api/health` — Returns `200` (`healthy` when MariaDB is connected, `degraded` when offline) with safe runtime metadata.
- `GET http://localhost:4000/api/health/live` — Process liveness probe (`200`).
- `GET http://localhost:4000/api/health/ready` — Readiness probe (`200` when MariaDB is up, `503` when unreachable).
- `GET http://localhost:4000/api/v1/health` (plus `/live` and `/ready`) — Versioned API aliases.

> **Troubleshooting Port `4000` on Windows:** If Playwright or `pnpm dev` behaves unexpectedly against stale code, check whether a prior Node process is bound to `127.0.0.1:4000`:
> `Get-NetTCPConnection -LocalPort 4000 -ErrorAction SilentlyContinue`

---

## 5. Verification Commands

```powershell
pnpm check:env      # Verify root .env presence
pnpm format:check   # Prettier code formatting check
pnpm typecheck      # Strict TypeScript check across all 7 workspace projects
pnpm lint           # ESLint flat config across workspace
pnpm test           # Vitest unit & Supertest API test suites
pnpm build          # Full production build (packages + api + web)
pnpm test:e2e       # Playwright Chromium E2E checks across 5 viewports & health endpoints
```

If Playwright Chromium has not been installed on a fresh machine:

```powershell
pnpm exec playwright install chromium
```
