# Implemented Technology Stack (Current Baseline)

This document records the exact technologies, workspace packages, and versions **currently installed and verified** in the **YOUR CHOICE** repository (updated after Phase A/B UI & Prompt 04A reconciliation).

---

## Runtime & Package Management

- **Node.js:** `>= 20.19.0` (verified on `v24.14.0`)
- **pnpm:** `>= 10.0.0` (verified on `10.33.0`, workspace monorepo)
- **TypeScript:** `^5.9.3` (strict mode enabled via `tsconfig.base.json`)

---

## Frontend (`apps/web`)

| Dependency                               | Version    | Purpose                                                                                                       |
| :--------------------------------------- | :--------- | :------------------------------------------------------------------------------------------------------------ |
| `react` / `react-dom`                    | `^19.3.1`  | Core UI runtime                                                                                               |
| `react-router-dom`                       | `^7.18.5`  | Client-side routing (`createBrowserRouter`, `async lazy()`, `RouteErrorPage`, `*` 404 fallback)               |
| `vite`                                   | `^8.3.8`   | Dev server (`/api` proxy -> `localhost:4000`) and Rolldown chunk-split production bundler                     |
| `tailwindcss` / `@tailwindcss/vite`      | `^4.3.5`   | Utility-first styling with CSS-first `@theme` tokens (`tokens.css` -> `index.css`)                            |
| `motion`                                 | `^14.14.0` | UI motion layer (`MotionProvider` wrapping `LazyMotion` `domAnimation` + `MotionConfig reducedMotion="user"`) |
| `lucide-react`                           | `^1.73.0`  | Accessible stroke SVG iconography                                                                             |
| `@fontsource-variable/plus-jakarta-sans` | `^5.3.0`   | Self-hosted variable UI & body sans font                                                                      |
| `@fontsource-variable/space-grotesk`     | `^5.3.0`   | Self-hosted variable display headline font                                                                    |
| `@fontsource-variable/jetbrains-mono`    | `^5.3.0`   | Self-hosted monospace font (SKUs, hex tokens, health telemetry)                                               |
| `@fontsource/hind-siliguri`              | `^5.3.0`   | Self-hosted Bangla UI/display font (`400`, `600`, `700`)                                                      |
| `zod`                                    | `^4.6.7`   | Client environment variable validation (`VITE_API_BASE_URL`, `VITE_APP_NAME`)                                 |

---

## Shared UI & Workspace Packages (`packages/*`)

| Package                     | Key Dependencies                                                                                                                                                                                                                                                  | Purpose                                                                                                                                                                                                                           |
| :-------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `@your-choice/ui`           | `@radix-ui/react-dialog` (`^1.3.1`), `@radix-ui/react-select` (`^2.4.1`), `@radix-ui/react-slot` (`^1.5.0`), `@radix-ui/react-tabs` (`^1.2.1`), `class-variance-authority` (`^0.7.1`), `clsx` (`^2.1.1`), `lucide-react` (`^1.73.0`), `tailwind-merge` (`^3.7.0`) | 15 accessible `shadcn/ui`-patterned Radix primitives (`Badge`, `Button`, `IconButton`, `Card`, `Container`, `Section`, `Input`, `Textarea`, `Select`, `Tabs`, `Dialog`, `Drawer`, `Skeleton`, `LoadingState`, `EmptyState`, `cn`) |
| `@your-choice/shared-types` | None                                                                                                                                                                                                                                                              | Framework-agnostic API envelope, health, role, and setting types                                                                                                                                                                  |
| `@your-choice/validation`   | `zod` (`^4.6.7`), `@your-choice/shared-types`                                                                                                                                                                                                                     | Shared Zod schemas usable cleanly in browser and Node                                                                                                                                                                             |
| `@your-choice/shared-utils` | None                                                                                                                                                                                                                                                              | Deterministic formatting helpers and exact `BigInt` minor-unit money math (`BDT` / `paisa`)                                                                                                                                       |

---

## Backend (`apps/api`)

| Dependency               | Version               | Purpose                                                                                |
| :----------------------- | :-------------------- | :------------------------------------------------------------------------------------- |
| `express`                | `^5.3.0`              | HTTP server and modular REST API router with native async error propagation            |
| `zod`                    | `^4.6.7`              | Environment validation (`src/config/env.ts`) and request validation middleware         |
| `pino` / `pino-http`     | `^10.4.0` / `^11.0.0` | Structured JSON request/app logging with secret redaction & `x-request-id` correlation |
| `cors`                   | `^2.8.6`              | Explicit multi-origin CORS allowlist returning `403 CORS_ORIGIN_DENIED`                |
| `helmet`                 | `^8.3.0`              | Baseline HTTP security headers                                                         |
| `dotenv`                 | `^18.0.10`            | Loads root `.env` when present                                                         |
| `drizzle-orm` / `mysql2` | `^0.45.4` / `^3.24.6` | Connection pool management (UTC/UTF8MB4) and MariaDB `SELECT 1` health checks          |
| `supertest`              | `^7.3.2`              | HTTP integration testing in Vitest                                                     |

---

## Database Layer (`database/`)

| Dependency    | Version    | Purpose                                                         |
| :------------ | :--------- | :-------------------------------------------------------------- |
| `drizzle-orm` | `^0.45.4`  | Type-safe SQL schema (`mysqlTable`) and query/migration runtime |
| `mysql2`      | `^3.24.6`  | **MIT**-licensed MariaDB-compatible MySQL wire protocol driver  |
| `drizzle-kit` | `^0.31.11` | SQL migration generator (`dialect: 'mysql'`)                    |
| `tsx`         | `^4.23.15` | TypeScript execution for migration and seed scripts             |

---

## Quality & Testing Tooling (Root)

- **ESLint (`^10.15.0`) + `typescript-eslint` (`^8.72.2`)**: Flat config enforcing strict TS and React Refresh/Hooks rules.
- **Prettier (`^3.10.1`)**: Consistent repository formatting.
- **Vitest (`^5.1.0`)**: Unit and API integration tests (`packages/shared-utils`, `packages/validation`, `apps/api`).
- **Playwright (`^1.65.1`)**: Full-stack browser + API smoke and 5-viewport responsive accessibility verification (`e2e/foundation.spec.ts`, `e2e/design-system.spec.ts`).
