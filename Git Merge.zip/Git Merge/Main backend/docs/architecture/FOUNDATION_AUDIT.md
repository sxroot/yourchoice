# Foundation Stabilization & Architecture Audit

> **Milestone:** Prompt 02 — Foundation Stabilization & Architecture Alignment  
> **Source of Truth:** Direct inspection of the workspace files, runtime configuration, schema DDL, and build/test execution results  
> **Scope Boundary:** Foundation hardening and architecture alignment only; no business modules (Auth, Catalog, Cart, Checkout, Design Studio UI, Marketplace, Rewards, Admin) implemented in this milestone.

---

## 1. Repository & Monorepo Workspace Audit

| Area                             | Verified Implementation State                                                                                                                                                                                                                                                                                                                              | Status   |
| :------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------- |
| **Package Manager & Workspace**  | `pnpm@10.33.0`, Node `v24.14.0`, [pnpm-workspace.yaml](../../pnpm-workspace.yaml) linking `apps/*`, `packages/*`, and `database`                                                                                                                                                                                                                           | Verified |
| **TypeScript Configuration**     | [tsconfig.base.json](../../tsconfig.base.json) enables `strict: true`, `noImplicitAny`, `strictNullChecks`, `noUncheckedIndexedAccess`, `noImplicitOverride`, `isolatedModules`; project references compile cleanly via `tsc -b`                                                                                                                           | Verified |
| **Package Boundaries**           | `@your-choice/web` imports only browser-safe workspace packages (`shared-types`, `validation`, `shared-utils`, `ui`); `@your-choice/api` does not import React/browser modules; `database/` isolates Drizzle schema and SQL migrations                                                                                                                     | Verified |
| **Frontend (`apps/web`)**        | React `19.3.1`, Vite `8.3.8`, React Router `7.18.5`, Tailwind CSS `v4.3.5` (`@source '../../../packages/ui/src'`), `@/*` path aliases, Zod client env validation, [HomePage](../../apps/web/src/pages/HomePage.tsx) health check, [NotFoundPage](../../apps/web/src/pages/NotFoundPage.tsx), [RouteErrorPage](../../apps/web/src/pages/RouteErrorPage.tsx) | Verified |
| **Backend (`apps/api`)**         | Express `5.3.0` ESM, Zod `v4.6.7` env + middleware validation, Pino `10.4.0` + `pino-http` logging, `helmet`, `cors`, `requestContextMiddleware`, `ApiError` + centralized `error-handler.ts`, `/api/health`, `/api/v1/health`, `/live`, `/ready`                                                                                                          | Verified |
| **Tooling & Quality Gates**      | ESLint `10.15.0` flat config + `typescript-eslint@8.72.2`, Prettier `3.10.1`, Vitest `5.1.0`, Playwright `1.65.1` + headless Chromium                                                                                                                                                                                                                      | Verified |
| **Version Control & Host Tools** | `git`, `mysql`/`mariadb` CLI, and `docker` are not installed on host `PATH`; TCP `127.0.0.1:3306` is closed                                                                                                                                                                                                                                                | Host Gap |

---

## 2. Issues Discovered & Stabilized During Audit

1. **CORS Rejection Returned HTTP `500` Instead of `403` (`apps/api/src/app.ts`):**
   - **Finding:** Disallowed browser origins passed a generic `Error` to `cors` callback, causing `error-handler.ts` to log an unhandled `500 INTERNAL_SERVER_ERROR` and expose the origin message in non-production.
   - **Correction:** Replaced with `new ApiError(403, 'CORS_ORIGIN_DENIED', 'Origin is not allowed by CORS')` and added integration test verification in [health.test.ts](../../apps/api/tests/health.test.ts).
2. **Incomplete Secret Redaction Paths (`apps/api/src/config/logger.ts`):**
   - **Finding:** Pino redaction lacked header keys (`x-api-key`, `x-csrf-token`) and storage credential properties (`*.apiKey`, `*.accessKeyId`, `*.secretAccessKey`, `*.credentials`).
   - **Correction:** Expanded `redact.paths` proactively prior to Phase 1 auth and S3 storage integration.
3. **Unvalidated `STORAGE_DRIVER=s3` Variables (`apps/api/src/config/env.ts`):**
   - **Finding:** `.env.example` listed `S3_*` variables, but `apiEnvSchema` omitted optional `S3_*` fields and did not require `S3_BUCKET`, `S3_ACCESS_KEY_ID`, and `S3_SECRET_ACCESS_KEY` when `STORAGE_DRIVER=s3`.
   - **Correction:** Added explicit Zod validation and test coverage in [env.test.ts](../../apps/api/tests/env.test.ts).
4. **Missing Explicit UTC & UTF8MB4 Driver Options (`apps/api/src/database/client.ts` & `database/scripts/connection.ts`):**
   - **Finding:** `mysql2` pool/connection omitted explicit `timezone: 'Z'` and `charset: 'utf8mb4'`, risking OS-local timezone drift (`+06:00`) when reading/writing `DATETIME(3)` UTC timestamps.
   - **Correction:** Set `timezone: 'Z'` and `charset: 'utf8mb4'` across both API pools and DB migration/seed connections.
5. **Frontend API Client Response Validation (`apps/web/src/services/api-client.ts`):**
   - **Finding:** `apiGet()` called `response.json()` directly without checking `response.ok` or content-type, risking raw `SyntaxError` on non-JSON proxy errors.
   - **Correction:** Safely inspects JSON content-type and throws structured `ApiClientError` instances on HTTP or malformed responses.
6. **Local Storage Directory Exclusion (`.gitignore`):**
   - **Finding:** `.gitignore` excluded `uploads/`, but omitted `storage/` matching `STORAGE_LOCAL_ROOT=./storage` in `.env.example`.
   - **Correction:** Added `storage/` to `.gitignore`.
7. **Conflicting / Stale Research Notes (`docs/`):**
   - **Finding:** Multiple overlapping architecture/setup documents existed across `docs/`, and `docs/research/DESIGN_STUDIO_TECHNOLOGY_DECISIONS.md` contained two stale statements (`#b83b14` terracotta accent instead of actual `#7c3aed` violet tokens in `apps/web/src/index.css`, and `Phase 8+` 3D deferral conflicting with the approved Dual-Mode 2D+3D addendum).
   - **Correction:** Added canonical Prompt 02 docs, cross-linked specs cleanly, and aligned the stale notes in `docs/research/DESIGN_STUDIO_TECHNOLOGY_DECISIONS.md`.

---

## 3. Database Foundation Audit Findings (Drizzle + MariaDB 10.11+)

- **Dialect & Driver:** `drizzle-orm/mysql2` + `mysql2@^3.24.6` (**MIT**, avoiding LGPL-2.1 `mariadb-connector-nodejs`), `drizzle-kit@^0.31.11` with `dialect: 'mysql'` ([drizzle.config.ts](../../database/drizzle.config.ts)).
- **Pool & Health Timeout:** Bounded `connectTimeout: 2000` and `SELECT 1 AS ok` timeout (`2500ms`) keep `/api/health` and `/api/health/live` non-blocking when MariaDB is offline.
- **Schema & Migration Conventions Verified in [system-settings.ts](../../database/schema/system-settings.ts) & [0000_living_toro.sql](../../database/migrations/0000_living_toro.sql):**
  - **Timestamps:** `DATETIME(3)` UTC (`CURRENT_TIMESTAMP(3)` / `ON UPDATE CURRENT_TIMESTAMP(3)`).
  - **Indexing:** Explicit B-tree index names (`idx_<table>_<column>`).
  - **Financial Precision Standard (Phase 1+ Rule):** Persist monetary columns as `DECIMAL(12, 2)` in MariaDB (or integer minor units + currency column) alongside deterministic `BigInt` math helpers in `@your-choice/shared-utils` — never floating-point `FLOAT`/`DOUBLE`.
  - **Foreign Keys & Delete Rules (Phase 1+ Rule):** Explicit foreign keys with `ON DELETE RESTRICT` on commercial/ledger entities (`orders`, `order_items`, `order_designs`, `creator_reward_ledger`, `payments`) and `ON DELETE CASCADE` strictly for tightly owned ephemeral sub-records.
  - **Migration Safety:** Zero business tables created in Phase 0; always inspect generated SQL in `database/migrations/` for MariaDB 10.11+ compatibility before running `pnpm db:migrate`.
- **Unverified Runtime Item:** Live execution of `pnpm db:migrate` and `pnpm db:seed` against an active MariaDB 10.11+ engine could not be tested on this host due to the absence of MariaDB/Docker (`127.0.0.1:3306` closed).

---

## 4. Official Brand Identity Audit

- **Logo Asset Verified:** [your-choice-logo.png](../../apps/web/public/brand/your-choice-logo.png) exists and depicts a `1:1` soaring circuit-wing emblem and geometric `YOUR CHOICE` wordmark.
- **Observed Logo Palette:** Pure black (`#000000`), charcoal, metallic silver/white, royal blue (`#1d4ed8`), electric blue (`#2563eb` / `#3b82f6`), and luminous cyan (`#38bdf8` / `#22d3ee`).
- **Resolved in Prompt 03 (`apps/web/src/index.css`):** Replaced all placeholder violet accents (`#7c3aed`, `#6d28d9`, `#1f1636`, `#c4b5fd`) with contrast-verified **Royal Blue / Electric Blue / Cyan / Black / Charcoal / Silver** tokens and complete semantic design-system variables ([DESIGN_SYSTEM.md](DESIGN_SYSTEM.md)).
- **Remaining Scope:** [RootLayout.tsx](../../apps/web/src/layouts/RootLayout.tsx) retains its placeholder navbar badge until UI layout coordination is ready to embed the `1:1` logo safely.

---

## 5. Remaining Technical Risks & Deferred Work

1. **No Live MariaDB Execution Yet:** SQL compatibility and upserts (`VALUES(col)`) are statically reviewed against MariaDB 10.11+ syntax but require live verification once MariaDB or Docker is provisioned.
2. **Rate Limiting & Session Auth Deferred:** `express-rate-limit`, CSRF tokens, HTTP-only session storage, and ownership RBAC middleware must land cleanly in the Auth/Security phase before any mutating or upload endpoint ships.
3. **Host Version Control:** `git init` and initial baseline commit must run once `git` is installed on this machine.
