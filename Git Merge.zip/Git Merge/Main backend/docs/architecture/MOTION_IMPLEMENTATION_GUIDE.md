# YOUR CHOICE — Motion Implementation Guide

**Status:** Phase B Motion Primitives Implemented  
**Library:** `motion` (`motion/react` with `LazyMotion` + `domAnimation`)  
**Source Directory:** `apps/web/src/components/motion/`

---

## 1. Architecture & Bundle Hygiene

The platform uses `MotionProvider` (`apps/web/src/components/motion/MotionProvider.tsx`) mounted at the application root (`apps/web/src/app/App.tsx`):

- Wraps `<RouterProvider>` in `<LazyMotion features={domAnimation} strict>` and `<MotionConfig reducedMotion="user">`.
- Components import lightweight `m` from `motion/react` rather than full `motion`, keeping initial bundle overhead minimal and enforcing `strict` mode (any accidental full `motion.*` import throws immediately in development).
- Central timing constants live in `apps/web/src/components/motion/motion-tokens.ts` (`MOTION_DURATION` and `MOTION_EASE_OUT_EXPO` / `MOTION_EASE_SNAPPY`) to comply with ESLint `react-refresh/only-export-components`.

---

## 2. Available Primitives (`@/components/motion`)

| Component                          | Trigger                                               | Properties Animated                                  | Intended Usage                                                |
| :--------------------------------- | :---------------------------------------------------- | :--------------------------------------------------- | :------------------------------------------------------------ |
| `FadeIn`                           | Mount (`initial -> animate`)                          | `opacity` (`0 -> 1`)                                 | Hero badges, headers, panels above the fold                   |
| `SlideIn`                          | Mount (`initial -> animate`)                          | `opacity`, `transform` (`x`/`y` offset `18px`)       | Above-the-fold hero headings, media frames                    |
| `Reveal`                           | Viewport (`whileInView`, `once: true`, `amount: 0.1`) | `opacity`, `translateY` (`20px -> 0`)                | Editorial homepage and showcase section blocks below the fold |
| `StaggerContainer` + `StaggerItem` | Viewport (`whileInView`, `once: true`, `amount: 0.1`) | Child stagger `0.06s`, item `opacity` + `translateY` | Bounded bento grids (3–6 cards max, e.g. platform pillars)    |

---

## 3. Mandatory Performance & Accessibility Rules

1. **GPU-Composited Properties Only**
   - Animate only `transform` (`x`, `y`, `scale`, `rotate`) and `opacity`.
   - Never animate layout properties (`width`, `height`, `top`, `left`, `margin`, `padding`) or blur filters inside scroll loops.
2. **Reduced Motion Guarantee (`prefers-reduced-motion: reduce`)**
   - `MotionConfig reducedMotion="user"` respects OS preferences globally.
   - Each motion wrapper also checks `useReducedMotion()` and renders a static `<div>` cleanly without initial hidden opacity when reduced motion is active.
   - `apps/web/src/index.css` includes a CSS safety fallback collapsing transition and animation durations to `0.01ms` under `@media (prefers-reduced-motion: reduce)`.
3. **Scroll & Jump-Link Safety (No Stuck Invisible Sections)**
   - Never gate above-the-fold hero sections behind `whileInView` (use `FadeIn` or `SlideIn` on mount instead).
   - Set `viewport={{ once: true, amount: 0.1 }}` on `Reveal` and `StaggerContainer` so short viewports (`360×800`) and fast jump scrolling never trap tall sections at `opacity: 0`.
4. **When NOT to Animate**
   - Do **not** wrap Fabric.js canvas elements, WebGL canvases, form validation errors, critical price/stock badges, or `404`/error boundaries in delayed scroll animations.
   - Keep staggered groups small (`<= 6` items) so lists remain responsive for keyboard and screen reader users.
