# Dual-Mode Design Studio Architecture (2D + 3D)

> **Status:** Implemented across Phase 2 (`2D Studio` + `300 DPI` Export) and Phase 3 (`3D Studio`, see `../decisions/PHASE_2_2D_DESIGN_STUDIO.md` & `../decisions/PHASE_3_3D_DESIGN_STUDIO.md`)  
> **Mode A (2D Studio):** `fabricjs/fabric.js` (`v6/v7`, MIT) — lazy-loaded client island  
> **Mode B (3D Studio):** `mrdoob/three.js` + `@react-three/fiber` (`v9`) + `@react-three/drei` (MIT) — glTF 2.0 / GLB + Draco/KTX2  
> **Server Print Rasterizer:** `lovell/sharp` (Apache-2.0, `300 DPI` transparent PNG production masters)  
> **Companion Specs:** [RENDERING_AND_IP_PROTECTION.md](RENDERING_AND_IP_PROTECTION.md) · [DESIGN_STUDIO_TECHNOLOGY_DECISIONS.md](../decisions/DESIGN_STUDIO_TECHNOLOGY_DECISIONS.md)

---

## 1. Dual-Mode System Overview

YOUR CHOICE provides two selectable studio views built inside `apps/web/src/features/design-studio/` (loaded dynamically only when entering the studio so core storefront bundles stay lean), backed by one shared canonical design document stored on `apps/api`:

```text
                CanonicalDesignDocument (MariaDB + Private S3 Assets)
                                     │
                 ┌───────────────────┴───────────────────┐
                 ▼                                       ▼
     Mode A — 2D Print Editor                Mode B — 3D Garment Studio
 (Fabric.js v6/v7 Direct Manipulation)   (Three.js + R3F v9 Interactive Preview)
  - Pixel/inch print-area precision       - glTF 2.0 / GLB T-Shirt & Polo models
  - Text, fonts, curves, alignment        - 360° orbit, front/back/side camera presets
  - Layers, grouping, snapping guides     - MeshPhysicalMaterial sheen + cloth normals
  - Undo/redo + normalized JSON patches   - CanvasTexture bound to print-zone UV islands
                 │                                       │
                 └───────────────────┬───────────────────┘
                                     ▼
                Server-Side Validation & Print Master Pipeline
         (Magic bytes -> Print bounds -> Sharp 300 DPI PNG in private storage)
```

Customers and creators can build in **Mode A (2D)** for flat typographic/graphic accuracy and toggle into **Mode B (3D)** to inspect silhouette wrap, colorway contrast, collar/sleeve fit, and camera angles—or position/tune surface placements interactively in 3D against canonical normalized print-area coordinates.

---

## 2. Mode A — 2D Design Studio

### 2.1 Core Capabilities

- **Text & Typography:** Multilingual English + Bangla font presets self-hosted via `@fontsource` (`SIL OFL 1.1` / `MIT`, matching client browser fonts and server print worker fonts identically), weight/size/alignment/line-height/letter-spacing/stroke/fill controls.
- **Image Uploads & Manipulation:** Authenticated uploads checked by binary magic bytes (`file-type`), stored immutably in private object storage, inserted cleanly with non-destructive transform/crop coordinates, opacity, flip/rotate, and real-time **effective DPI warnings** computed from source pixel resolution vs. physical print inches (`product_print_areas`).
- **Shapes & Graphic Packs:** Built-in geometric shapes, paths, badges, and curated curated vector packs cleared for commercial POD usage (`MIT` / `CC0`).
- **Layers & Grouping:** Layer stack reordering, group/ungroup, lock/hide, alignment/distribution tools, smart safe-zone guides (`bleed` / `safe area`).
- **Front & Back Garment Views:** Multi-surface tabbing (`front`, `back`, plus configurable `pocket` / `sleeve` areas loaded dynamically from MariaDB `product_print_areas` per product/variant).
- **History, JSON & Print Export:** Deterministic immutable undo/redo command stack over canonical normalized surface deltas; emits serialized design JSON and lightweight raster previews while final `300 DPI` transparent PNG export executes strictly server-side.

### 2.2 React 19 Integration Architecture

- Hold the imperative Fabric `Canvas` inside `useRef<Canvas | null>(null)` initialized inside `useEffect` and torn down with `canvas.dispose()` on unmount/remount (safe under React 19 Strict Mode).
- Keep Fabric's mutable scene graph out of React `useState`; sync throttled `object:modified` / `selection:*` events into a lightweight studio UI store for layer panels, inspectors, and dirty-state tracking.
- Wait for `document.fonts.ready` before mounting/measuring `FabricText` objects so character bounding boxes remain consistent across sessions and match the headless server renderer.

---

## 3. Mode B — 3D Design Studio

### 3.1 Why Generic 3D Viewers Fail Apparel Customization

Embeddable viewers such as Google `<model-viewer>` perform whole-material texture swapping and target AR/product display. They do **not** provide per-object multi-layer composition synced to a 2D print editor, interactive raycast-to-UV print-zone mapping, dual-mode canonical state synchronization, or fine multi-layer fabric shading (`MeshPhysicalMaterial` cloth sheen + normal maps blended cleanly beneath/above customer ink).

### 3.2 3D Garment Pipeline (T-Shirts & Polo Shirts)

1. **Authoring & Binary Delivery Format:**
   - Sculpt/model clean quad-dominant Crewneck T-Shirt and Collared Polo Shirt meshes in **Blender** (< 60k–80k triangles per garment) and export as **glTF 2.0 binary (`.glb`)**.
   - Optimize geometry using `donmccurdy/glTF-Transform` (**Draco** mesh compression + quantized attributes) and pack static fabric micro-weave textures (normal, roughness, ambient occlusion, sheen map) using **KTX2 / Basis Universal** (`KTX2Loader`) to prevent mobile WebGL out-of-memory crashes.
2. **Garment PBR Material & Lighting Rig:**
   - Fabric surfaces use Three.js `MeshPhysicalMaterial` (`KHR_materials_sheen`): `metalness: 0.0`, calibrated cotton/pique roughness (`0.72–0.88`), tileable knit `normalMap`, baked UV ambient occlusion, and calibrated micro-fiber `sheen` + `sheenRoughness`.
   - Separate sub-meshes/material slots for Polo collar ribs, placket, buttons, and inner neck label permit independent colorway tinting.
   - Studio lighting uses a neutral local HDRI environment + key/rim directional lights (preventing black garments from crushing into flat silhouettes) and `<ContactShadows>`.
3. **Camera & Responsive Interaction:**
   - Damped `OrbitControls` with min/max zoom, clamped vertical polar angles, and animated camera transitions for **Front**, **Back**, **Left Side**, **Right Side**, **Collar Detail**, and **360° Reset**.
   - Cap pixel ratio (`dpr={[1, 2]}`), use `frameloop="demand"` when idle on mobile devices, and explicitly `.dispose()` geometries/materials/textures when closing the 3D view.

---

## 4. Shared Design Domain Model (`CanonicalDesignDocument`)

### 4.1 Separation of Domain Data vs. Mode Engine State

Persistent design records (`designs`, `design_versions`) must **never** persist raw Fabric.js internal runtime flags (`_controlsVisibility`, UI selection handles) or Three.js camera/matrix state. Both modes hydrate from and emit normalized `[0..1]` domain state:

```ts
export interface CanonicalDesignDocument {
  schemaVersion: 1;
  designId: string;
  productId: string;
  productVariantId: string; // Blank colorway SKU
  preferredMode: '2d' | '3d';
  version: number;
  surfaces: Record<
    string, // e.g., 'front' | 'back' | 'left_chest'
    {
      printAreaId: string;
      physicalWidthMm: number;
      physicalHeightMm: number;
      targetDpi: number; // Server print spec (e.g., 300)
      objects: CanonicalDesignObject[]; // Normalized x/y/width/height in [0..1]
    }
  >;
  previews: {
    thumbnailAssetKey?: string;
    surfacePreviewKeys: Record<string, string>;
  };
  updatedAt: string;
}
```

Image objects store private immutable `assetId` / object keys (never inline base64 strings inside JSON).

---

## 5. 2D-to-3D Artwork Mapping Strategy

```text
CanonicalDesignDocument (Normalized [0..1] Print-Area Coordinates)
        │
        ├──► Mode A (2D Fabric.js):
        │      Maps [0..1] * canvasWidth/Height inside product_print_areas clip box
        │
        └──► Mode B (3D Three.js):
               Renders surfaces onto offscreen 2D Canvas -> THREE.CanvasTexture (SRGBColorSpace)
               Binds CanvasTexture onto flat-unwrapped print-zone UV island ('front' / 'back')
               Maps 3D pointer raycast UV hits back into normalized [0..1] surface coordinates
```

### 5.1 Dedicated UV-Island `CanvasTexture` vs. `DecalGeometry`

- **Primary Strategy — Dedicated Print-Zone UV Islands + `CanvasTexture`:** Each `.glb` garment reserves dedicated, distortion-minimized flat UV islands (`front_print`, `back_print`, `left_chest`) with exact physical aspect ratio matching `product_print_areas`. Painting surface artwork onto an offscreen canvas (`THREE.CanvasTexture`, `needsUpdate = true`) keeps Mode A 2D placements, Mode B 3D previews, and server flat print exports aligned **1:1 inside printable boundaries** without mesh slicing overhead or Z-fighting.
- **Secondary Fallback — `@react-three/drei` `<Decal>` (`DecalGeometry`):** Unsuitable as the primary shirt print engine because orthogonal projection stretches heavily across curved chest folds, tears across UV seams, and produces visual layouts misaligned from flat DTF heat-press transfers. Reserve `<Decal>` strictly for rigid accessories later (mugs, caps, tags) if flat UVs are unavailable.

### 5.2 Honest Non-Lossless Caveats

1. **Product/Variant Switching:** Switching from a full-front T-Shirt (`12" x 16"`) to a Polo chest pocket (`4" x 4"`) alters physical aspect ratios; fit/scale re-normalization must warn the user rather than claiming lossless equivalence.
2. **Curvature vs. Flat Press Reality:** Mode B displays draped 3D cloth lighting and curvature over the torso; physical production prints onto a flat platen. Safe-zone clipping bounds MUST be enforced deterministically in canonical `[0..1]` space across both modes.
3. **Preview Resolution vs. Master Export:** Client 2D/3D previews run at `1024–2048px` textures for responsive WebGL FPS; final `3600 x 4800 px` (`300 DPI`) transparent PNGs render exclusively on the backend.

---

## 6. Brand Identity Correction Notice (Logo Audit)

Inspecting the primary asset [your-choice-logo.png](../../apps/web/public/brand/your-choice-logo.png) confirms the official **YOUR CHOICE** visual palette:

- **Base Surfaces:** Pure Black (`#000000`), Deep Charcoal (`#0b0c10`), Graphite (`#14161c` / `#1c1f27`)
- **Primary Accents:** Royal Blue (`#1d4ed8`), Electric Blue (`#2563eb` / `#3b82f6`), Luminous Cyan (`#38bdf8` / `#22d3ee`)
- **Supporting Tones:** Metallic Silver / Cool Slate (`#a6adbb`, `#f3f4f6`)
- **Logo Form & Proportion:** `1:1` square soaring circuit-wing eagle emblem with `YOUR CHOICE` wordmark.

> **Brand Token Status (Resolved in Phase A/B & Prompt 04A):** Phase 0 placeholder violet accents in `apps/web/src/index.css` were replaced with the calibrated **Royal Blue / Electric Blue / Cyan / Obsidian / Charcoal / Alabaster** system (`>= 4.5:1` WCAG AA contrast), and `1:1` logo aspect ratios (`width="56" height="56"` / `aspect-square`) are preserved across `@your-choice/ui` and `apps/web`.
