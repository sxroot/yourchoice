# YOUR CHOICE — Motion Design System & Technical Architecture

> **Status:** Active Specification — Tier 1–2 `MotionProvider` primitives implemented in Phase B (`@your-choice/ui`); Tier 3 Studio/3D motion primitives activate in **Phase 2 (2D)** and **Phase 3 (Mode B 3D)**.  
> **Brand Identity:** **YOUR CHOICE** (`allyourchoice.com`) — _Design it. Wear it. Earn from it._  
> **Official Brand Palette:** Royal Blue (`#1D4ED8` / `#1E40AF`), Electric Blue (`#2563EB` / `#3B82F6`), Cyan (`#06B6D4` / `#22D3EE`), Black (`#06080D`), Charcoal (`#111622` / `#1A2232`), Silver (`#CBD5E1` / `#94A3B8`), Crisp White (`#F8FAFC` / `#FFFFFF`). **No purple/violet primary accents.**  
> **Official Logo Asset:** `apps/web/public/brand/your-choice-logo.png` (preserved unaltered).

---

## 1. Motion Philosophy & Intensity Tiers

Motion in **YOUR CHOICE** communicates **precision engineering meets streetwear energy**—crisp, snappy, GPU-composited, and strictly subordinate to task clarity.

| Intensity Tier                         | Platform Areas                                                                                                    | Motion Character                                                                                                                                 | Target Budget                                 |
| :------------------------------------- | :---------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------- | :-------------------------------------------- |
| **Tier 1 — Expressive Storytelling**   | Homepage (`/`), Drop Lookbooks, "How It Works", Footer Brand Signature                                            | Paced scroll reveals, subtle blue-cyan grid/light sweeps, interactive product showcase transitions                                               | `350–650 ms` reveals; `60fps` GPU-only        |
| **Tier 2 — Crisp Commerce Conversion** | Product Listing (`/shop`), Product Detail (`/product/:slug`), Marketplace (`/marketplace`), Cart Drawer, Checkout | Snappy micro-interactions, instant swatch/view crossfades, smooth slide-over drawers, zero scroll hijacking                                      | `150–260 ms` transitions                      |
| **Tier 3 — High-Precision Tooling**    | **2D Design Studio** (`/design-studio/:productId`, Phase 2), **3D Viewer** (Phase 3 Mode B)                       | **Zero decorative scroll/layout motion** competing with pointer/canvas events; instant tool feedback (`100–150 ms` CSS), smooth 3D orbit damping | `<= 16.6 ms` frame budget for Fabric.js & R3F |
| **Tier 4 — High-Productivity Ops**     | Creator Dashboard (`/creator/*`), Admin Dashboard (`/admin/*`), Production & QC Queues                            | Minimal CSS state transitions only (`100–150 ms`); zero entrance staggers on data tables                                                         | Instantaneous                                 |

---

## 2. Recommended Motion Stack & Evaluation

### 2.1 Selected Stack (Lean & Permissive)

| Layer                                  | Selected Tool                                                                      | GitHub / Docs                                                                         | License & Commercial Status                       | Integration Complexity | Target Phase         |
| :------------------------------------- | :--------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------ | :------------------------------------------------ | :--------------------: | :------------------- |
| **Primary UI & Scroll Motion**         | **`motiondivision/motion`** (`motion/react` + `LazyMotion`)                        | `https://github.com/motiondivision/motion` \| `https://motion.dev/`                   | **MIT** — Full commercial SaaS use                |          Low           | **Phase 1–7**        |
| **Swipe & Horizontal Storytelling**    | **`davidjerleke/embla-carousel`** (`embla-carousel-react`)                         | `https://github.com/davidjerleke/embla-carousel` \| `https://www.embla-carousel.com/` | **MIT** — Full commercial SaaS use (~8.5k+ stars) |          Low           | **Phase 1–2**        |
| **Micro-Transitions & Reduced Motion** | **Tailwind CSS v4 Transitions + Native CSS `@keyframes` + `IntersectionObserver`** | `https://tailwindcss.com/`                                                            | **MIT** — Zero extra JS payload                   |          Zero          | **Phase 0–8**        |
| **3D Preview Motion (Mode B Studio)**  | **`mrdoob/three.js` (`r187`) + `@react-three/fiber@9` + `@react-three/drei`**      | `https://github.com/pmndrs/react-three-fiber` \| `https://r3f.docs.pmndrs.org/`       | **MIT** — Full commercial SaaS use                |         Medium         | **Phase 3 (Mode B)** |

### 2.2 Evaluated & Explicitly Rejected / Deferred Tools

| Tool                                   | GitHub / Docs                                                           | License                                  | Decision                | Rationale                                                                                                                                                                                            |
| :------------------------------------- | :---------------------------------------------------------------------- | :--------------------------------------- | :---------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **`greensock/GSAP` + `ScrollTrigger`** | `https://github.com/greensock/GSAP` \| `https://gsap.com/`              | **Custom No-Charge License (Webflow)**   | **AVOID**               | Webflow's license prohibits using GSAP inside competing visual/no-code design builders; adds risk alongside our Design Studio and duplicates `motion`.                                               |
| **`darkroomengineering/lenis`**        | `https://github.com/darkroomengineering/lenis`                          | **MIT**                                  | **AVOID**               | Global smooth-scroll hijacking conflicts with Design Studio canvas wheel zoom, native scrollbar expectations, and `scrollIntoView` anchors.                                                          |
| **`airbnb/lottie-web`**                | `https://github.com/airbnb/lottie-web` \| `https://airbnb.io/lottie/`   | **MIT** (player) / **Per-Asset License** | **DEFER / CONDITIONAL** | Unnecessary ~60KB runtime unless custom in-house vector animations are commissioned; never embed third-party LottieFiles JSONs without commercial clearance.                                         |
| **`rive-app/rive-react`**              | `https://github.com/rive-app/rive-react` \| `https://rive.app/`         | **MIT** (runtime)                        | **DEFER**               | Requires WASM bundle (~150KB+) and external Rive authoring; not justified for MVP.                                                                                                                   |
| **`theatre-js/theatre`**               | `https://github.com/theatre-js/theatre` \| `https://www.theatrejs.com/` | **Apache-2.0**                           | **OPTIONAL / POST-MVP** | Useful only if scripted multi-shot 3D garment launch sequences are added beyond MVP (`Phase 3` Mode B uses standard `OrbitControls` + camera preset lerps); strip `@theatre/studio` from production. |

---

## 3. Motion Tokens & Timing Curves

Define standardized motion tokens so all storefront, studio, and portal components share cohesive physics:

| Token                  | Value                                                        | Use Case                                                      |
| :--------------------- | :----------------------------------------------------------- | :------------------------------------------------------------ |
| `--ease-out-expo`      | `cubic-bezier(0.16, 1, 0.3, 1)`                              | Hero entrances, section reveals, drawer slide-ins             |
| `--ease-in-out-snappy` | `cubic-bezier(0.4, 0, 0.2, 1)`                               | Tab indicator glides, accordion height/opacity, pill switches |
| `--spring-tactile`     | `{ type: 'spring', stiffness: 380, damping: 32, mass: 0.9 }` | Cart drawer, quick-view modal, hover card lift                |
| `--dur-micro`          | `150 ms`                                                     | Button hover, focus ring, swatch border, tooltip              |
| `--dur-panel`          | `240 ms`                                                     | Cart drawer, mobile nav drawer, filter sheet, dropdown        |
| `--dur-reveal`         | `500 ms`                                                     | Section entrance (`opacity: 0 -> 1`, `y: 20px -> 0`)          |

---

## 4. Technique Cookbook by Interaction Pattern

| Pattern                             | Recommended Implementation                                                                                                                                                                   | Guardrails (Learned from Live Reference)                                                                                                           |
| :---------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Scroll-Triggered Reveals**        | `motion` `whileInView` with `viewport={{ once: true, amount: 0.15 }}`                                                                                                                        | **Never leave jumped sections stuck at `opacity: 0`**. Animate `opacity` + `translateY(16px–24px)` only (`transform`/`opacity`), and trigger once. |
| **Smooth Section Transitions**      | Alternating dark-tech (`#06080D` / `#111622`) and crisp editorial light (`#F8FAFC` / `#FFFFFF`) bands with subtle CSS gradient hairlines (`Royal Blue -> Cyan`)                              | Avoid heavy full-viewport pixel canvas dividers above the fold; reserve canvas texture/grid polish for hero ambient or footer signature.           |
| **Parallax Movement**               | `motion` `useScroll({ target })` + `useTransform` on `translateY` (`-24px` to `+24px` max)                                                                                                   | Desktop `(min-width: 1024px)` only; disable on mobile & `prefers-reduced-motion` to prevent touch jitter.                                          |
| **Text Reveal Animations**          | Line/word clip reveal using `overflow-hidden` wrapper + `translateY(100%) -> 0` on Hero `h1` only                                                                                            | Do not split body paragraphs into hundreds of DOM spans (`<span>`), which hurts screen readers and layout speed.                                   |
| **Image Transitions**               | Crossfade (`opacity 200ms`) between Front/Back/Detail garment views; CSS `transform: scale(1.03)` (`300ms`) on card hover                                                                    | Pre-size image containers with explicit `aspect-ratio` (`aspect-[4/5]`) to guarantee **CLS = 0**.                                                  |
| **Sticky & Pinned Sections**        | Pure CSS `position: sticky; top: 5rem;` (e.g., How-It-Works step visual alongside scrolling copy, PDP gallery alongside variant selector)                                                    | Ensure ancestor containers do **not** use `overflow: hidden` (use `overflow-x: clip`), or `sticky` silently breaks.                                |
| **Horizontal Storytelling / Rail**  | **`embla-carousel-react`** (`dragFree` + snap points + keyboard arrow buttons) for Featured Drops & Garment Base Rail                                                                        | Always render full garment front/back silhouettes (never edge-on clipped garments like the reference rail!) and visible Prev/Next controls.        |
| **Animated Navigation**             | Sticky header (`backdrop-blur-md`, `bg-surface/90`), `200–300ms` hover-intent mega menu with `AnimatePresence`, active pill `layoutId`                                                       | Keep top-level nav `<= 6` links (`Shop`, `Design Studio`, `Marketplace`, `Creators`, `How It Works`); provide full keyboard `Esc` / arrow support. |
| **Interactive Cards**               | `1px` Electric Blue/Cyan border highlight + subtle `translateY(-3px)` lift + quick "Customize / Quick View" bar reveal                                                                       | On touch devices, keep primary action visible without requiring hover.                                                                             |
| **Page Transitions**                | Instant route mount + lightweight `opacity` crossfade (`150ms`) on main content outlet; never block navigation with full-screen splash loaders                                               | Keep URL synchronized on Quick-View / PDP transitions so links remain shareable.                                                                   |
| **Loading Animations**              | `animate-pulse` neutral skeleton cards matching exact card `aspect-ratio`; deterministic progress bar for 300 DPI PNG export                                                                 | Never lock the UI with a multi-second fake splash preloader.                                                                                       |
| **Cursor / Canvas Brand Signature** | Optional footer `<canvas>` interactive **YOUR CHOICE Cyan/Blue Tech-Grid / Wing-Scan** gated by `IntersectionObserver` (`only runs when visible` + `prefers-reduced-motion` static fallback) | Strictly footer or isolated hero accent; zero custom cursor replacement (`cursor: none` hurts accessibility & Design Studio precision).            |
| **Responsive Motion**               | Wrap app root in `<MotionConfig reducedMotion="user">` + `<LazyMotion features={domAnimation}>`; downgrade parallax/multi-axis hover to tap states below `1024px`                            | Match `docs/architecture/MOTION_DESIGN_SYSTEM.md` GPU rules.                                                                                       |

---

## 5. Original YOUR CHOICE Brand Design Direction

To differentiate completely from the monochrome luxury reference (`Orvante`) while achieving equal or higher polish:

1. **Identity Theme — "Precision Apparel Lab meets Streetwear Drops":**
   - **Hero Composition:** Deep Obsidian/Charcoal dark-tech hero (`#06080D` -> `#111622`) featuring a subtle glowing Royal Blue / Electric Blue (`#2563EB`) & Cyan (`#22D3EE`) technical print-grid backdrop, the preserved wing monogram ([your-choice-logo.png](file:///d:/Antigravity/Your%20Choice/apps/web/public/brand/your-choice-logo.png)) anchored cleanly in the sticky navbar, bold `Space Grotesk` headline (**"Design it. Wear it. Earn from it."**), **dual conversion CTAs** (**Customize a Blank** primary gradient blue pill + **Shop Creator Drops** outline silver pill), and an interactive live **T-Shirt / Polo Front–Back Studio Preview Card** showing real-time colorway & graphic swap!
2. **Storefront & Marketplace Contrast Rhythm:**
   - Use **Dark Tech Mode** (`#06080D` / `#111622`) for Hero, Design Studio workbench, and Brand Proof Bento sections, paired with **Crisp Light Gallery Mode** (`#F8FAFC` / `#FFFFFF`) or high-contrast Charcoal cards (`#151C28` with `#E2E8F0` / `#94A3B8` silver text >= `4.5:1`) for high-conversion product reading—explicitly avoiding the reference's unreadable dark-gray-on-pure-black metadata.
3. **Interactive "Customize This Base" Garment Rail (Original Upgrade):**
   - Adapt the reference's horizontal clothing rail into a **YOUR CHOICE Blank Selector Rail** (`Embla Carousel`) showing **full front-view Crewneck T-Shirts and Polo Shirts** across core colorways (`Obsidian Black`, `Royal Blue`, `Charcoal`, `Heather Silver`, `Crisp White`), where clicking any piece immediately launches `/design-studio/:productId?color=...`.
4. **Signature Footer Tech-Canvas:**
   - Replace the reference's generic pixel name sheet with an original **YOUR CHOICE Blueprint Coordinate Footer** (`IntersectionObserver`-gated `<canvas>` subtle cyan/blue dot-matrix + wing scanline pulse on hover/click, static clean render under `prefers-reduced-motion`).

---

## 6. Application Across All 10 YOUR CHOICE Platform Areas

| Area                                                  | Motion Tier  | Key Recommended Interaction Patterns                                                                                                                               |
| :---------------------------------------------------- | :----------: | :----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **1. Homepage (`/`)**                                 |  **Tier 1**  | Hero staggered `Space Grotesk` reveal, live T-Shirt/Polo preview card, `Embla` Blank Selector Rail, Creator Earnings bento counter cards, Blueprint Footer canvas. |
| **2. Product Listing (`/shop`)**                      |  **Tier 2**  | Sticky facet filter sidebar (Desktop) / `AnimatePresence` slide-over filter sheet (Mobile), URL-synced chip transitions, hover Front/Back image swap.              |
| **3. Product Detail (`/product/:slug`)**              |  **Tier 2**  | Sticky left gallery with thumbnail crossfade, instant Colorway swatch tint preview, Size matrix tactile pills, prominent **Customize in Studio** CTA.              |
| **4. Design Studio Mode Selection**                   |  **Tier 2**  | Fast modal/page cards comparing **Mode A — 2D Studio** vs **Mode B — 3D Studio** (`Phase 2–3`) vs **Remix Template** with crisp blue focus border states.          |
| **5. 2D Design Studio (`/design-studio/:productId`)** |  **Tier 3**  | Zero decorative page motion; instantaneous CSS panel collapses, live DPI gauge bar, crisp snap-guide highlights on Fabric.js canvas.                               |
| **6. 3D Design Studio (Phase 3 Mode B)**              |  **Tier 3**  | Lazy-loaded R3F canvas (`View in 3D` toggle), smooth `OrbitControls` damping, front/back camera preset lerp transitions.                                           |
| **7. Marketplace (`/marketplace`)**                   |  **Tier 2**  | Trending/New tab underline `layoutId` glide, creator attribution pill hover, garment-base switcher (`Tee` <-> `Polo`) on design detail page.                       |
| **8. Creator Profiles (`/creators/:username`)**       | **Tier 1–2** | Compact verified creator banner with subtle blue-cyan accent line + clean filterable approved-design grid.                                                         |
| **9. Customer Dashboard (`/account/*`)**              | **Tier 2–4** | Clean tab transitions, order fulfillment stepper (`Pending -> Printing -> QC -> Shipped`), saved draft quick-reopen cards.                                         |
| **10. Admin Dashboard (`/admin/*`)**                  |  **Tier 4**  | Instant TanStack Table sorting/pagination, slide-over Moderation & Production QC inspection drawers (`150ms`), zero decorative motion.                             |

---

## 7. Performance, GPU & Accessibility Non-Negotiables

1. **Compositor-Only Animation:** Animate **only** `transform` (`translate3d`, `scale`, `rotate`) and `opacity`. Never animate `width`, `height`, `top`, `left`, `margin`, `padding`, or `background-size` in scroll loops.
2. **`prefers-reduced-motion` Enforcement:** Wrap root in `<MotionConfig reducedMotion="user">` AND retain the CSS media query in `apps/web/src/index.css` so all transitions/animations collapse to instant state changes for motion-sensitive users.
3. **Zero Layout Shifts (`CLS = 0`):** Every product card, gallery thumbnail, and skeleton loader must declare explicit `aspect-ratio` and dimensions; self-host `@fontsource` fonts with `font-display: swap`.
4. **Canvas & RAF Lifecycle Cleanup:** Any interactive `<canvas>` (Footer blueprint canvas, Fabric.js, R3F) must pause `requestAnimationFrame` via `IntersectionObserver` when scrolled out of view and invoke `.dispose()` / `cancelAnimationFrame` on unmount.
5. **Lazy-Load Heavy Modules:** `fabric`, `three`, `@react-three/fiber`, and below-the-fold images must never sit in the initial storefront entry bundle.
6. **Keyboard & Contrast Accessibility:** Every animated trigger (`button`, tab, drawer, modal, carousel prev/next) must expose visible `2px` Electric Blue/Cyan `:focus-visible` outlines, full `Tab`/`Enter`/`Escape` navigation, and `>= 4.5:1` text contrast.
