# YOUR CHOICE — Inspection-Driven UI/UX Implementation Roadmap

> **Brand Identity:** **YOUR CHOICE** (`allyourchoice.com`) — _Design it. Wear it. Earn from it._  
> **Primary References:**
>
> - [`UI_UX_LIVE_REFERENCE_ANALYSIS.md`](../research/UI_UX_LIVE_REFERENCE_ANALYSIS.md)
> - [`MOTION_DESIGN_SYSTEM.md`](MOTION_DESIGN_SYSTEM.md)
> - [`RESPONSIVE_INTERACTION_GUIDELINES.md`](../research/RESPONSIVE_INTERACTION_GUIDELINES.md)
> - [`DESIGN_STUDIO_TECHNOLOGY_DECISIONS.md`](../decisions/DESIGN_STUDIO_TECHNOLOGY_DECISIONS.md)  
>   **Preserved Official Logo:** `apps/web/public/brand/your-choice-logo.png`

---

## Current Milestone Separation

| Execution Boundary                     | Phases                                                                                                                                                                                                                | Status                                    |
| :------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :---------------------------------------- |
| **Implement Now (Current Milestone)**  | **Phase A** (Design Foundation) + **Phase B** (Global UI Shell, Reusable `@your-choice/ui` Components, Motion Utilities, `/design-system` Internal Preview Route)                                                     | **Active Scope**                          |
| **Wait for Product & Backend Modules** | **Phase C** (Editorial Marketing Homepage), **Phase D** (Commerce / PDP / Cart / Checkout), **Phase E** (Creator Marketplace), **Phase F** (2D/3D Design Studio), **Phase G** (Customer / Creator / Admin Dashboards) | **Deferred to Respective Feature Phases** |

---

## Phase A — Design Foundation _(Completed — Phase A / Prompt 03 & Reconciled in Prompt 04A)_

- **Scope:** Replaced Phase 0 placeholder accents (`#7c3aed` violet / `#b83b14` draft terracotta) and established the official **YOUR CHOICE** brand palette (**Royal Blue**, **Electric Blue**, **Cyan**, **Black**, **Charcoal**, **Silver**, **Crisp White** — zero violet/purple). Established CSS custom properties and Tailwind CSS v4 `@theme` tokens for colors, surfaces, typography (`clamp()` scales), spacing, radii, elevation shadows, z-index layers, breakpoints, motion durations/easings, and accessibility focus rings.
- **Dependencies:** `@tailwindcss/vite`, `tailwindcss` (already installed); `@fontsource-variable/space-grotesk`, `@fontsource-variable/plus-jakarta-sans`, `@fontsource/hind-siliguri`, `@fontsource-variable/jetbrains-mono`.
- **Components Required:** Global stylesheet (`apps/web/src/index.css`) + semantic CSS token layers (`tokens.css` imported before Tailwind utilities).
- **Relevant Interactions & Animation Requirements:** Define `--dur-micro` (`150ms`), `--dur-panel` (`240ms`), `--dur-reveal` (`500ms`), `--ease-out-expo`, `--ease-snappy`, and strict `@media (prefers-reduced-motion: reduce)` collapse rules.
- **Responsive Requirements:** Eliminate un-clamped `vw` root scaling (preventing the `7.47px` tablet defect seen in reference); guarantee `>= 14px` body (`16px` default prose) and `>= 16px` mobile inputs; use `overflow-x: clip` to preserve `position: sticky`.
- **Acceptance Criteria:** Zero violet/purple tokens; `--color-accent-ink` resolved; `>= 4.5:1` contrast across light and dark tech surfaces; `tsc` and Vite build pass.
- **Testing Requirements:** Playwright computed-style check verifying `body` >= `14px` across `360px`–`1440px`, `0px` horizontal overflow, and `prefers-reduced-motion` toggle.

---

## Phase B — Global UI Foundation & Motion System _(Implement Now)_

- **Scope:** Upgrade `@your-choice/ui` primitives, build responsive `RootLayout` (sticky header with desktop navigation + animated mobile navigation drawer + responsive footer preserving `apps/web/public/brand/your-choice-logo.png`), implement reusable `motion` utilities, and expose an internal `/design-system` preview route while keeping Phase 0 `HomePage` health diagnostics intact.
- **Dependencies:** `motion` (`motiondivision/motion`, MIT) in `apps/web`; `@radix-ui/react-dialog`, `@radix-ui/react-tabs`, `@radix-ui/react-select` (MIT) in `packages/ui`; `lucide-react` (ISC, already installed).
- **Components Required:**
  - `@your-choice/ui`: `Button`, `IconButton`, `Container`, `Section`, `Card` (+ compound subcomponents), `Badge`, `Input`, `Textarea`, `Select`, `Dialog`, `Drawer`, `Tabs`, `Skeleton`, `EmptyState`, `LoadingState`.
  - `apps/web` Motion Utilities: `MotionProvider` (`MotionConfig` + `LazyMotion`), `Reveal`, `FadeIn`, `SlideIn`, `StaggerContainer`, `StaggerItem`, `useReducedMotion`.
  - `apps/web` Shell & Preview: `SiteHeader`, `MobileNavDrawer`, `SiteFooter`, `DesignSystemPage` (`/design-system`).
- **Relevant Interactions & Animation Requirements:** Drawer slide-in (`240ms`), modal scale/fade (`200ms`), scroll-triggered `Reveal` with `viewport={{ once: true }}` (never leaving jump-scrolled sections at `opacity: 0`), `transform`/`opacity` GPU properties only.
- **Responsive Requirements:** `>= 44×44px` tap targets; touch-friendly mobile drawer; `>= 16px` input font size on mobile; zero clipped/overlapping elements across `1440×900`, `1280×800`, `768×1024`, `390×844`, `360×800`.
- **Acceptance Criteria:** Existing Phase 0 `HomePage` + health probe still works; keyboard `Tab` / `Escape` navigation works on Dialog/Drawer/Tabs/Select; logo aspect ratio intact (`object-contain` without distortion).
- **Testing Requirements:** `pnpm format:check`, `pnpm lint`, `pnpm typecheck`, `pnpm test`, `pnpm build`, plus Playwright responsive & accessibility smoke suite across all 5 viewports.

---

## Phase C — Marketing Experience _(Wait for Phase 1 Content/Catalog Routes)_

- **Scope:** Transform `HomePage` into the editorial **YOUR CHOICE** landing experience: dark-tech Hero ("Design it. Wear it. Earn from it.") with dual CTAs (**Customize a Blank** / **Shop Creator Drops**), trust/statistics bento cards, horizontal Blank Base Selector Rail (T-Shirts & Polo Shirts), creator spotlight, and `IntersectionObserver`-gated Blueprint Footer canvas.
- **Dependencies:** Phase A–B complete + `embla-carousel-react` (MIT) + owned blank garment photography.
- **Components Required:** `HeroShowcase`, `BentoStatGrid`, `GarmentRailCarousel`, `CategoryBentoCards`, `CreatorSpotlightStrip`, `BlueprintCanvasFooter`.
- **Relevant Interactions & Animation Requirements:** Tier 1 expressive storytelling (`350–650ms`), Embla touch-swipe + prev/next controls, desktop-only subtle `useScroll` parallax (`<= 24px`).
- **Responsive Requirements:** Above-the-fold headline + dual CTAs on mobile; horizontal swipe rail shows `15–20%` next-card peek; canvas loops disabled `< 768px` and under reduced motion.
- **Acceptance Criteria:** LCP `< 2.5s`, CLS `= 0`, dual paths functional, zero content stuck at `opacity: 0` on jump links.
- **Testing Requirements:** Lighthouse mobile/desktop performance & accessibility audit + Playwright visual/scroll tests.

---

## Phase D — Commerce Experience _(Wait for Phase 1 Backend Products & Cart)_

- **Scope:** Implement `/shop`, `/shop/:category`, `/product/:slug`, slide-over Cart Drawer, and linear `/checkout` (bKash, Nagad, SSLCommerz, COD).
- **Dependencies:** Express `/api/v1/products`, `/categories`, `/cart`, `/orders` modules + `@tanstack/react-query`.
- **Components Required:** `FacetFilterSidebar`, `MobileFilterSheet`, `ProductCard` (with Front/Back view toggle), `ProductQuickViewModal`, `ProductGallery`, `VariantSwatchMatrix`, `StickyPurchaseBar`, `CartDrawer`, `CheckoutStepper`.
- **Relevant Interactions & Animation Requirements:** Tier 2 crisp commerce transitions (`150–240ms`), URL-synced filter updates, `AnimatePresence` Cart Drawer, `aria-live` cart badge updates.
- **Responsive Requirements:** Facets move into Radix bottom/side `Drawer` on `< 1024px`; sticky bottom CTA bar on PDP/Checkout; zero hover-only controls.
- **Acceptance Criteria:** Full keyboard checkout flow, `>= 4.5:1` contrast on charcoal & light product cards, zero layout shift on variant image swaps.
- **Testing Requirements:** Playwright E2E cart/filter/checkout flows across Desktop & Mobile.

---

## Phase E — Creator Marketplace _(Wait for Phase 4 Backend Marketplace Module)_

- **Scope:** Implement `/marketplace`, `/marketplace/:designSlug`, `/creators/:username`, and `/collections/:slug` with Trending/New discovery, verified creator badges, and multi-garment base switching (T-Shirt ↔ Polo).
- **Dependencies:** Phase D + Creator & Marketplace moderation APIs.
- **Components Required:** `MarketplaceFeed`, `CreatorAttributionBadge`, `CreatorProfileHeader`, `GarmentBaseSwitcher`, `CollectionBanner`.
- **Relevant Interactions & Animation Requirements:** Tier 2 `layoutId` tab indicator glide, fast artwork-on-base preview crossfade (`200ms`).
- **Responsive Requirements:** 2-column mobile / 4-column desktop grid; swipeable tag chips without whole-page horizontal overflow.
- **Acceptance Criteria:** Only admin-approved designs appear; shareable creator URLs resolve cleanly.
- **Testing Requirements:** Playwright marketplace discovery & base-switching tests.

---

## Phase F — Dual-Mode Design Studio Experience _(Wait for Phase 2–3 Studio & Sharp Backend)_

- **Scope:** Implement 2D/3D mode selector, lazy-loaded Fabric.js v7 Front/Back Design Studio (`/design-studio/:productId`), pre-upload image crop modal, asset/font library (EN + Bangla), live DPI warnings, save/export states, and lazy-loaded Phase 3 Mode B 3D preview (`Three.js` + `@react-three/fiber@9` + `@react-three/drei`) synced from the shared `CanonicalDesignDocument`.
- **Dependencies:** `fabric` (`v7.4+`), `ValentinH/react-easy-crop`, `@fontsource` display fonts, `Sharp` + `fabric/node` 300 DPI backend pipeline (Phase 2); `three` + `@react-three/fiber@9` + `@react-three/drei` (Phase 3).
- **Components Required:** `StudioWorkbenchShell`, `FabricCanvasController`, `ToolRailDesktop`, `ThumbZoneToolSheetsMobile`, `LayerPanel`, `DpiStatusMeter`, `CropUploadModal`, `ExportProgressDialog`, `Garment3DModal` (Phase 3 Mode B).
- **Relevant Interactions & Animation Requirements:** **Tier 3 strict 60fps isolation** — zero decorative Framer Motion wrappers around `<canvas>`; instantaneous CSS panel collapses (`100–150ms`); `touch-action: none` scoped strictly to canvas stage.
- **Responsive Requirements:** 3-pane workbench on desktop (`>= 1024px`); center canvas (`60–65%` height) + bottom thumb-zone `Drawer` sheets on mobile (`>= 44×44px` transform handles).
- **Acceptance Criteria:** Accurate `clipPath` print-area containment, immutable original uploads, server 300 DPI transparent PNG generation verified.
- **Testing Requirements:** Unit tests for print-area coordinate math + Playwright Studio upload/text/save E2E.

---

## Phase G — Dashboard Experience _(Wait for Phase 1, 4, 5, 6 Backend Modules)_

- **Scope:** Implement Customer Dashboard (`/account/*`), Creator Dashboard (`/creator/*` earnings ledger, payout requests, moderation status), and Admin Dashboard (`/admin/*` catalog, design moderation queue, DTF/heat-press/QC production workflow, payouts, audit logs).
- **Dependencies:** Auth/RBAC APIs + `@tanstack/react-table` + `satnaing/shadcn-admin` layout patterns.
- **Components Required:** `PortalSidebarShell`, `KpiMetricCard`, `DataTableToolbar`, `ModerationReviewDrawer`, `ProductionQcChecklistDrawer`, `PayoutLedgerTable`.
- **Relevant Interactions & Animation Requirements:** **Tier 4 high-productivity** — minimal `100–150ms` CSS state transitions only; zero staggered table entrances.
- **Responsive Requirements:** Collapsible sidebar drawer `< 1024px`; card-list or horizontal scroll wrapper (`overflow-x-auto`) with sticky first column on small screens.
- **Acceptance Criteria:** Keyboard-navigable tables, accessible status badges (`4.5:1`), strict role-gated routes.
- **Testing Requirements:** Vitest component tests + Playwright RBAC/moderation/QC flows.
