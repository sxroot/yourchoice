# YOUR CHOICE — Design System Specification

**Status:** Phase A & B Implemented  
**Domain:** `allyourchoice.com`  
**Tagline:** _Design it. Wear it. Earn from it._  
**Preview Route:** `/design-system`

---

## 1. Official Brand Identity & Palette

All UI surfaces and brand components derive from the official YOUR CHOICE wing-shaped technology monogram and dark-tech streetwear identity. Purple and violet tones are excluded from primary brand tokens.

### Brand & Surface Color Tokens (`apps/web/src/index.css`, `apps/web/src/styles/tokens.css`)

| Token / CSS Variable                              | Hex Value             | Visual Role & Contrast Pairing                                                             |
| :------------------------------------------------ | :-------------------- | :----------------------------------------------------------------------------------------- |
| `--color-accent` (`--yc-royal`)                   | `#1d4ed8`             | **Royal Blue** — Primary CTAs, active indicators, white text on accent (`>= 4.5:1`)        |
| `--color-accent-hover` (`--yc-royal-deep`)        | `#1e40af`             | **Deep Royal** — Primary hover state & `--color-accent-ink` (`>= 7.5:1` on light surfaces) |
| `--color-accent-electric` (`--yc-electric`)       | `#2563eb`             | **Electric Blue** — Interactive focus rings (`focus-visible`), electric CTA variant        |
| `--color-accent-cyan` (`--yc-cyan`)               | `#0891b2`             | **Cyan** — Studio highlights & secondary gradient anchor                                   |
| `--color-accent-cyan-ink` (`--yc-cyan-deep`)      | `#0e7490`             | **Deep Cyan Ink** — Accessible cyan text on light surfaces (`>= 4.7:1` WCAG AA)            |
| `--color-accent-cyan-bright` (`--yc-cyan-bright`) | `#22d3ee`             | **Bright Cyan** — High-contrast accent labels on dark obsidian/charcoal surfaces           |
| `--color-accent-soft`                             | `#eff6ff`             | Soft tint for active navigation pills, icon containers, and accent badges                  |
| `--color-surface-dark` (`--yc-black`)             | `#06080d`             | **Obsidian Black** — Brand hero backgrounds, official logo plate, footer depth             |
| `--color-surface-charcoal` (`--yc-charcoal`)      | `#111622`             | **Charcoal** — Dark editorial storytelling bands and Design Studio chrome                  |
| `--color-surface-charcoal-elevated`               | `#1a2232`             | Elevated card surface inside dark charcoal sections                                        |
| `--color-ink-silver` (`--yc-silver`)              | `#cbd5e1`             | **Silver** — Secondary body copy & metadata on `#06080d` / `#111622` (`>= 10:1` contrast)  |
| `--color-surface` (`--yc-white`)                  | `#ffffff`             | **Crisp White** — Primary storefront card surface                                          |
| `--color-canvas`                                  | `#f8fafc`             | Cool alabaster page background                                                             |
| `--color-surface-muted`                           | `#eef2f7`             | Recessed containers, tab tracks, subtle surface shifts                                     |
| `--color-ink`                                     | `#0a0f1c`             | Primary body copy on light surfaces                                                        |
| `--color-ink-muted`                               | `#475569`             | Secondary copy on light surfaces (`>= 4.5:1` WCAG AA)                                      |
| `--color-border` / `--color-border-dark`          | `#d7e0ec` / `#253248` | Crisp 1px structural borders on light and dark sections                                    |

### Selective Brand Gradients

- **`.bg-brand-gradient`**: `linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #06b6d4 100%)` — Reserved for selective high-impact callout surfaces and active visual dividers.
- **`.bg-dark-tech`**: Radial electric blue (`rgba(37, 99, 235, 0.22)`) and cyan (`rgba(34, 211, 238, 0.14)`) atmospheric glows over `#06080d -> #111622`.

---

## 2. Official Logo Preservation Rules

- **Asset Path:** `apps/web/public/brand/your-choice-logo.png` (`1024x1024`, square `1:1` aspect ratio).
- **Never** redraw, replace, recolor, distort aspect ratio, or crop the wing-shaped technology monogram.
- Always render inside an `object-contain` square frame with explicit `width` and `height` attributes and `bg-surface-dark` (`#06080d`) + `border-border-dark` so the dark background integrates cleanly on both light headers and dark footers.

---

## 3. Typography System

Loaded locally via `@fontsource-variable/*` and `@fontsource/*` in `apps/web/src/main.tsx` (zero blocking external font network dependencies):

| Family Token     | Fonts                                                      | Purpose                                                     |
| :--------------- | :--------------------------------------------------------- | :---------------------------------------------------------- |
| `--font-display` | `Space Grotesk Variable`, `Hind Siliguri`, `system-ui`     | Hero headlines, section titles, display metrics             |
| `--font-sans`    | `Plus Jakarta Sans Variable`, `Hind Siliguri`, `system-ui` | UI copy, navigation, bilingual English + Bangla prose       |
| `--font-mono`    | `JetBrains Mono Variable`, `ui-monospace`                  | Print DPI specs, hex tokens, ledger IDs, system diagnostics |

### Fluid Responsive Scale (`clamp()`)

Defined in `apps/web/src/styles/tokens.css` so typography scales proportionally without collapsing on tablet (`768px`) or overflowing narrow mobile (`360px`) viewports:

- `--text-display`: `clamp(2.125rem, 4.5vw, 3.75rem)` (`34px` -> `60px`)
- `--text-h1`: `clamp(1.875rem, 3.4vw, 2.875rem)` (`30px` -> `46px`)
- `--text-h2`: `clamp(1.375rem, 2.2vw, 2rem)` (`22px` -> `32px`)
- `--text-h3`: `clamp(1.125rem, 1.4vw, 1.375rem)` (`18px` -> `22px`)
- Form fields (`input`, `textarea`, `select`): Locked to `1rem` (`16px`) below `640px` to prevent automatic iOS Safari input zoom, stepping to `0.875rem` on desktop.

---

## 4. Layout, Spacing, Elevation & Z-Index Scale

- **Container (`@your-choice/ui`)**: Max width `max-w-7xl` (`80rem`), horizontal padding `px-4 sm:px-6 lg:px-8`.
- **Section Cadence**: `--section-space-sm` (`clamp(2rem, 4vw, 3rem)`), `--section-space-md` (`clamp(3rem, 5.5vw, 4.5rem)`), `--section-space-lg` (`clamp(4rem, 7vw, 6rem)`).
- **Horizontal Overflow Prevention**: `html` and `body` enforce `overflow-x: clip` (preserving `position: sticky` functionality unlike `overflow-x: hidden`).
- **Z-Index Layers**: `--z-sticky: 30`, `--z-header: 40`, `--z-drawer: 50`, `--z-modal: 60`, `--z-toast: 70`.
- **Tested Viewport Matrix**: `1440×900`, `1280×800`, `768×1024`, `390×844`, `360×800`.

---

## 5. `@your-choice/ui` Component Catalog

All shared UI primitives reside in `packages/ui/src/components/` and compile via `pnpm build:packages`:

| Component                                                                          | Key Variants / Features                                                                                                                                                                                |
| :--------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Button` / `IconButton`                                                            | `primary`, `electric`, `secondary`, `outline`, `dark`, `ghost`, `danger`; sizes `sm` (`40px`), `md` (`44px`), `lg` (`48px`); `IconButton` enforces `>= 44x44px` touch target and requires `aria-label` |
| `Badge`                                                                            | `neutral`, `accent`, `cyan`, `cyan-dark`, `dark`, `success`, `warning`, `danger`                                                                                                                       |
| `Card` (`CardHeader`, `CardTitle`, `CardDescription`, `CardContent`, `CardFooter`) | Crisp border, `--shadow-card`, dark-mode-ready overrides                                                                                                                                               |
| `Container` & `Section`                                                            | `Section` tones: `canvas`, `surface`, `muted`, `dark`, `charcoal`; spacing `none`, `sm`, `md`, `lg`                                                                                                    |
| `Input`, `Textarea`, `Select`                                                      | Native validation (`invalid` prop / `aria-invalid`), Radix `Select`, mobile `16px` font sizing                                                                                                         |
| `Dialog`                                                                           | Accessible Radix modal dialog (`z-60`) with focus trap and `Escape` dismissal                                                                                                                          |
| `Drawer`                                                                           | Accessible Radix slide-over (`left`, `right`) and mobile bottom sheet (`bottom`) (`z-50`)                                                                                                              |
| `Tabs`                                                                             | Accessible Radix keyboard-navigated tabs (`TabsList`, `TabsTrigger`, `TabsContent`)                                                                                                                    |
| `Skeleton`, `LoadingState`, `EmptyState`                                           | Live-region status (`role="status"`), inline spinner, card grid skeletons, actionable empty states                                                                                                     |
