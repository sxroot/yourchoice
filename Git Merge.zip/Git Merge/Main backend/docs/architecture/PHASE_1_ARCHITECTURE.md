# Phase 1 Implementation Architecture — Identity, RBAC & Core Apparel Commerce

> **Status:** Phase 1A (Identity & RBAC) + Phase 1B (Addresses, Apparel Catalogue, Print Areas, Bilingual Storefront) + Phase 1C (Persistent Cart, Bangladesh Shipping, Server-Validated Checkout, COD + Honest Gateway Architecture, Order Lifecycle & Admin Operations) Implemented & Verified via Workspace Build/Vitest/Playwright (Pending Host MariaDB 10.11+ Provisioning for Live `pnpm db:migrate && pnpm db:seed`)  
> **Architectural Baseline:** Modular Monolith (`apps/web`, `apps/api`, `packages/*`, `database/`)  
> **Governing ADRs:** `ADR-001`..`ADR-014` in [ARCHITECTURE_DECISIONS.md](../decisions/ARCHITECTURE_DECISIONS.md)

---

## 1. Phase 1 Scope & Boundaries

Phase 1 delivers end-to-end **Authentication, Session & RBAC Security, Configurable Apparel Catalog (T-Shirts & Polo Shirts), Variant & Print-Area Configuration, Storefront Browse/PDP, Cart & Checkout (Cash on Delivery baseline), EN/BN Foundation, and Admin Catalog Operations**, without pulling Phase 2–3 Design Studio engines (`fabric`, `three`) or Phase 4–6 Marketplace/Rewards/Production engines in prematurely.

### Included in Phase 1

- **Identity & RBAC:** Registration, email/password sign-in, sign-out, current session bootstrap (`/auth/me`), password change, customer profile & saved Bangladesh delivery addresses, role assignments (`guest`, `customer`, `creator`, `staff`, `admin`, `super_admin`), CSRF protection, and login/registration rate limiting.
- **Core Apparel Catalog:** Hierarchical categories (`T-Shirts`, `Polo Shirts`), products (`products`), gallery media (`product_images`), SKU variants (`product_variants` across sizes `S`–`XXL` & brand colorways), and **configurable print-area templates (`product_print_areas`)** (`front`, `back`, `left_chest` dimensions in inches/mm + safe-zone ratios consumed later by Phase 2–3 Design Studio).
- **Storefront Commerce & BDT Pricing:** `/shop`, `/shop/:category`, `/product/:slug`, slide-over Cart Drawer (`carts` / `cart_items` supporting anonymous guest session token -> seamless merge on login), and linear `/checkout` creating server-validated `orders`, `order_items`, `order_status_history`, and initial `payment_transactions` (`COD` method active; bKash/Nagad/SSLCommerz gateway adapters deferred cleanly to Phase 7).
- **Multilingual Foundation (EN + Bangla):** `react-i18next` + `i18next` with English (`en`) and Bangla (`bn`) locale bundles, persistent language switcher, dynamic `<html lang>` toggling, and `@fontsource/noto-sans-bengali` alongside `@fontsource/hind-siliguri`.
- **Admin Foundation (`/admin/*`):** Protected admin shell for managing categories, products, variants, prices, stock quantities, and print areas + baseline audit logging (`audit_logs`).

### Intentionally Deferred to Phases 2–7

- **Phase 2:** Fabric.js 2D Studio UI, customer image upload (`StorageService` + `file-type` + `Sharp`), and `300 DPI` PNG export.
- **Phase 3:** Three.js / R3F v9 3D Garment Studio (`Mode B`), custom `order_designs` checkout snapshots, and customization pricing.
- **Phase 4–5:** Creator onboarding opt-in, marketplace moderation queue, and `creator_reward_ledger`.
- **Phase 6–7:** Freesub heat-press / DTF `production_jobs`, QC gates, atomic fulfillment stock movements, bKash/Nagad/SSLCommerz webhooks, and public catalog SSR (`@react-router/express`).

---

## 2. Phase 1 Technology & Security Selection

| Layer                     | Package / Pattern                                                                    | License               | Rationale & Verification Notes                                                                                                                                                                                                                                                                                                                  |
| :------------------------ | :----------------------------------------------------------------------------------- | :-------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Password Hashing**      | **Node.js `node:crypto` native Argon2id** (`RFC 9106`, OpenSSL `3.5`)                | **Built-in**          | Standard PHC Argon2id (`m=19456, t=2, p=1`, 16-byte nonce, 32-byte tag) directly via Node 24 OpenSSL 3.5 — avoids Windows `vcruntime140.dll` MSVC binary failures observed with `@node-rs/argon2` and removes third-party native addon fragility.                                                                                               |
| **Session Auth**          | **Custom MariaDB Session Auth** (`sessions` + `crypto.randomBytes(32)`)              | **Built-in**          | Rejects `better-auth` for MVP due to recent CVE cadence (`v1.7.16` multi-vuln patch, DB rate-limit race `CVE-2026-110861`, MySQL serial leak `GHSA-48c2-w96j-mv3m`) and tight Express/Drizzle peer coupling. Stores **SHA-256 hash** of opaque session token in MariaDB; cookie holds raw token (`HttpOnly`, `SameSite=Lax`, `Secure` in prod). |
| **Rate Limiting**         | **`express-rate-limit` (`^8.x`)**                                                    | **MIT**               | Express 5 middleware compatible; protects `/auth/*`, `/orders`, and future upload routes from brute-force and burst abuse.                                                                                                                                                                                                                      |
| **CSRF Defense**          | **Origin Check + Double-Submit Cookie/Header** (`X-CSRF-Token`)                      | **Built-in**          | Stateful cookie routes verify `Origin`/`Referer` allowlist + matching double-submit token when `CSRF_ENABLED=true`.                                                                                                                                                                                                                             |
| **ORM Safety**            | **`drizzle-orm` (`^0.45.4` already installed)**                                      | **Apache-2.0**        | Version `>=0.45.2` patches `CVE-2026-39356` identifier injection; additionally **forbid** passing unvalidated query params into `sql.identifier()` or dynamic column maps (use explicit strict Zod allowlists).                                                                                                                                 |
| **Frontend Server State** | **`@tanstack/react-query` (`^5.x`)**                                                 | **MIT**               | Verified React 19 compatible; request deduplication, cache invalidation (`cart`, `auth/me`, `products`), optimistic quantity updates.                                                                                                                                                                                                           |
| **Client UI/Cart State**  | **`zustand` (`^5.x`)**                                                               | **MIT**               | Verified React 19 compatible; lightweight UI state (Cart Drawer open state, guest cart ID/merge coordination, active filters).                                                                                                                                                                                                                  |
| **Forms & Validation**    | **`react-hook-form` (`^7`) + `@hookform/resolvers` (`^5`)**                          | **MIT**               | `@hookform/resolvers@^5` resolves Zod v4 schema incompatibilities (`zod@^4.6.7` already installed in `@your-choice/validation`).                                                                                                                                                                                                                |
| **EN + Bangla i18n**      | **`i18next` + `react-i18next` (`>=15.4` / `^16`) + `@fontsource/noto-sans-bengali`** | **MIT / SIL OFL 1.1** | React 19 compatible; keeps English and Bangla storefront labels consistent without external CDN font fetches.                                                                                                                                                                                                                                   |

---

## 3. Database Schema & Relationship Blueprint (`database/schema/`)

All Phase 1 tables follow `ADR-009`..`ADR-011`:

- **PK/FK:** `BIGINT UNSIGNED AUTO_INCREMENT` internal `id` + `public_id` `CHAR(36)` UUID where exposed via API/ownership checks.
- **Money:** `DECIMAL(12, 2)` + `currency_code CHAR(3) NOT NULL DEFAULT 'BDT'` (never `FLOAT`/`DOUBLE`).
- **Timestamps:** `created_at` & `updated_at` `DATETIME(3)` UTC (`CURRENT_TIMESTAMP(3)`).
- **Soft Delete:** `deleted_at DATETIME(3) NULL` on `users`, `user_addresses`, `product_categories`, `products`, `product_variants`; **never** on `orders`, `order_items`, `order_status_history`, `payment_transactions`, `audit_logs` (`ON DELETE RESTRICT` on commercial/audit parents).

```mermaid
erDiagram
    users ||--o| user_profiles : has
    users ||--o{ user_addresses : owns
    users ||--o{ sessions : holds
    users ||--o{ user_roles : assigned
    roles ||--o{ user_roles : grants
    roles ||--o{ role_permissions : maps
    permissions ||--o{ role_permissions : defines

    product_categories ||--o{ products : categorizes
    products ||--o{ product_images : displays
    products ||--o{ product_variants : offers
    products ||--o{ product_print_areas : configures

    users ||--o{ carts : owns
    carts ||--o{ cart_items : contains
    product_variants ||--o{ cart_items : references

    users ||--o{ orders : places
    orders ||--o{ order_items : snaps
    product_variants ||--o{ order_items : references
    orders ||--o{ order_status_history : logs
    orders ||--o{ payment_transactions : tracks
    users ||--o{ audit_logs : performs
```

### Key Table Groups

1. **Identity & RBAC (`identity.ts`):**
   - `users`: `id`, `public_id` (UUID unique), `email` (unique, lowercased), `password_hash`, `status` (`active` | `suspended` | `deleted`), `email_verified_at`, `created_at`, `updated_at`, `deleted_at`.
   - `user_profiles`: `user_id` (PK/FK -> `users.id`), `full_name`, `phone`, `preferred_locale` (`en` | `bn`), `created_at`, `updated_at`.
   - `user_addresses`: `id`, `public_id`, `user_id` (FK), `label`, `recipient_name`, `phone`, `division`, `district`, `area`, `address_line`, `postal_code`, `is_default`, `deleted_at`, timestamps.
   - `sessions`: `id`, `user_id` (FK `ON DELETE CASCADE`), `token_hash` (`CHAR(64)` SHA-256 unique), `ip_address`, `user_agent`, `expires_at`, `revoked_at`, `created_at`, `last_seen_at`.
   - `roles` (`code`: `guest`, `customer`, `creator`, `staff`, `admin`, `super_admin`), `permissions` (`code`: e.g. `catalog:write`, `orders:manage`, `users:manage`, `audit:read`), `role_permissions`, `user_roles`.
2. **Apparel Catalog & Print Areas (`catalog.ts`):**
   - `product_categories`: `id`, `parent_id` (self-FK nullable), `slug` (unique), `name_en`, `name_bn`, `sort_order`, `is_active`, `deleted_at`, timestamps. Seed baseline: `t-shirts`, `polo-shirts`.
   - `products`: `id`, `public_id`, `category_id` (FK), `slug` (unique), `sku_prefix`, `name_en`, `name_bn`, `description_en`, `description_bn`, `base_price` (`DECIMAL(12,2)`), `currency_code` (`CHAR(3)` `'BDT'`), `is_customizable` (`BOOLEAN`), `status` (`draft` | `active` | `archived`), `deleted_at`, timestamps.
   - `product_images`: `id`, `product_id` (FK), `variant_id` (nullable FK), `view_type` (`front` | `back` | `detail` | `flat_lay`), `object_key`, `alt_text_en`, `alt_text_bn`, `sort_order`, timestamps.
   - `product_variants`: `id`, `public_id`, `product_id` (FK), `sku` (unique), `color_name_en`, `color_name_bn`, `color_hex` (`CHAR(7)`), `size_code` (`XS`..`3XL`), `price_override` (`DECIMAL(12,2)` nullable), `currency_code`, `stock_quantity` (`INT UNSIGNED`), `is_active`, `deleted_at`, timestamps.
   - `product_print_areas`: `id`, `product_id` (FK), `surface_key` (`front` | `back` | `left_chest` | `sleeve`), `label_en`, `label_bn`, `physical_width_mm` (`INT UNSIGNED`), `physical_height_mm` (`INT UNSIGNED`), `target_dpi` (`INT UNSIGNED DEFAULT 300`), `mockup_bounds_json` (normalized `[0..1]` overlay coordinates on blank garment photo), `surcharge_amount` (`DECIMAL(12,2) DEFAULT '0.00'`), `currency_code`, `is_active`, timestamps.
3. **Cart, Checkout & Audit (`commerce.ts` + `audit.ts`):**
   - `carts`: `id`, `public_id`, `user_id` (nullable FK), `guest_token_hash` (nullable unique `CHAR(64)`), `currency_code`, `expires_at`, timestamps.
   - `cart_items`: `id`, `cart_id` (FK `ON DELETE CASCADE`), `variant_id` (FK), `quantity` (`INT UNSIGNED`), `unit_price_snapshot` (`DECIMAL(12,2)`), `created_at`, `updated_at` (unique index on `(cart_id, variant_id)` for Phase 1 standard variants; Phase 3 adds nullable `design_version_id` without breaking table layout).
   - `orders`: `id`, `public_id`, `order_number` (unique `YC-YYYYMMDD-XXXXXX`), `user_id` (nullable FK -> `users.id` `ON DELETE RESTRICT`), `customer_email`, `customer_phone`, `shipping_address_json`, `payment_method` (`cod` in Ph 1), `payment_status` (`unpaid` | `pending` | `paid` | `failed` | `refunded`), `order_status` (`pending` | `confirmed` | `processing` | `cancelled` ...), `subtotal_amount`, `shipping_amount`, `discount_amount`, `total_amount` (`DECIMAL(12,2)`), `currency_code`, `customer_note`, `created_at`, `updated_at`.
   - `order_items`: `id`, `order_id` (FK `ON DELETE RESTRICT`), `variant_id` (FK `ON DELETE RESTRICT`), `product_name_snapshot`, `sku_snapshot`, `color_snapshot`, `size_snapshot`, `quantity`, `unit_price`, `line_total`, `currency_code`, `created_at`.
   - `order_status_history`: `id`, `order_id` (FK), `from_status`, `to_status`, `changed_by_user_id` (nullable FK), `note`, `created_at`.
   - `payment_transactions`: `id`, `public_id`, `order_id` (FK), `gateway` (`cod` | ...), `transaction_ref`, `amount`, `currency_code`, `status`, `raw_payload_json`, `created_at`, `updated_at`.
   - `audit_logs`: `id`, `actor_user_id` (nullable FK), `action` (e.g. `product.updated`, `order.status_changed`, `auth.login_failed`), `entity_type`, `entity_public_id`, `metadata_json`, `ip_address`, `request_id`, `created_at`.

---

## 4. API & Shared Contract Boundaries (`/api/v1/*`)

- **Shared Validation & Types:**
  - `@your-choice/shared-types`: User, SessionUser, Role/Permission types, CategoryDTO, ProductSummaryDTO, ProductDetailDTO, ProductPrintAreaDTO, CartDTO, OrderDTO, PaginationMeta.
  - `@your-choice/validation`: Zod v4 schemas (`registerSchema`, `loginSchema`, `addressSchema`, `productQuerySchema`, `cartItemMutationSchema`, `createOrderSchema`, `adminProductUpsertSchema`, `adminPrintAreaSchema`).
- **Backend Module Layout (`apps/api/src/modules/`):**
  - `auth/`: `POST /register`, `POST /login`, `POST /logout`, `GET /me`, `GET /csrf` (rate-limited, timing-safe login verification).
  - `users/`: `GET/PATCH /me/profile`, `GET/POST/PATCH/DELETE /me/addresses`.
  - `categories/`: `GET /categories` (tree + active counts).
  - `products/`: `GET /products` (validated sort/filter allowlist: `newest`, `price_asc`, `price_desc`; facet filtering; pagination), `GET /products/:slug` (full gallery, variants, `product_print_areas` summary).
  - `cart/`: `GET /cart`, `POST /cart/items`, `PATCH /cart/items/:itemId`, `DELETE /cart/items/:itemId`, internal `mergeGuestCartOnAuth(userId, guestToken)`.
  - `orders/`: `POST /orders` (single MariaDB transaction: lock variant stock -> verify active product/variant -> recompute totals authoritatively via `BigInt` minor units -> decrement `stock_quantity` or reserve -> create `orders` + `order_items` + `order_status_history` + `cod` `payment_transactions` -> clear active cart), `GET /orders` (owner-scoped), `GET /orders/:orderNumber`.
  - `admin/`: RBAC-guarded (`admin` | `super_admin` | `staff` scoped) `/admin/categories`, `/admin/products`, `/admin/variants`, `/admin/print-areas`, `/admin/orders`, `/admin/audit-logs`.

---

## 5. Frontend Module Architecture (`apps/web/src/`)

- **Routes (`apps/web/src/app/routes.tsx` via `async lazy()`):**
  - **Public & Customer Storefront:** `/`, `/shop`, `/shop/:category`, `/product/:slug`, `/cart` (full cart page complementing slide-over `CartDrawer`), `/checkout`, `/orders` (authenticated history), `/orders/:orderNumber` (order detail & signed guest receipt access).
  - **Auth & Account:** `/login`, `/register`, `/account` (Profile, Saved Bangladesh Delivery Addresses, Order History shortcut — gated by auth guard).
  - **Admin Console:** `/admin` (lazy-loaded separate chunk, role-gated `admin`/`super_admin`, Identity + Catalog + Orders & COD Settlement tabs).
  - Internal QA Route: `/design-system` (restricted to `import.meta.env.DEV` or behind explicit feature flag once storefront nav activates).
- **UI Architecture Rules (`ADR-014`):**
  - All shared primitives live in `@your-choice/ui` (`Checkbox`, `Radio`, `Toast`/feedback added there cleanly as needed — never duplicated inside `apps/web`).
  - Maintain `MotionProvider` (`LazyMotion strict`), `clamp()` typography (`>= 16px` mobile inputs), `overflow-x: clip`, `44x44px` mobile hit targets, and **Royal Blue / Electric Blue / Cyan / Obsidian Black / Charcoal / Silver** identity blended with `Orvante`-inspired editorial contrast pacing.
  - Keep `CartDrawer` (`Drawer`) + `ProductQuickViewModal` (`Dialog`) keyboard-accessible (`Escape`, focus return) and strictly non-blocking (`CLS = 0`).

---

## 6. Phase 1 Security & Verification Gate

- **Security Checklist:**
  1. Never trust client-submitted prices, totals, shipping fees, or role claims — recompute all money server-side in `orders.service.ts` transactionally.
  2. Enforce atomic stock guard in MariaDB checkout (`UPDATE product_variants SET stock_quantity = stock_quantity - ? WHERE id = ? AND stock_quantity >= ?`) to prevent overselling under concurrent checkouts.
  3. Scope all `/me/*`, `/cart/*`, and `/orders/*` queries strictly by authenticated `req.auth.userId` (or hashed guest cart cookie), returning `404` / `403` cleanly against IDOR probing.
  4. Apply `express-rate-limit` to `/api/v1/auth/*` and `/api/v1/orders` and log failed logins / admin mutations to `audit_logs` + Pino (no passwords/tokens logged).
- **Phase 1 Exit Criteria:** Live `pnpm db:migrate && pnpm db:seed` against MariaDB 10.11+, Vitest unit + Supertest integration coverage for auth/RBAC/cart/checkout concurrency, and Playwright Desktop + Mobile E2E verifying registration/login, bilingual toggle, `/shop` facet filtering, variant add-to-cart drawer, and COD checkout.
