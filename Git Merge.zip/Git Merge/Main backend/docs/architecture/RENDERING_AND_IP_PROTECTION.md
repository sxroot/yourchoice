# Rendering Boundaries, Asset Protection & Server-Side IP Architecture

> **Status:** Security & Hybrid Rendering Specification (_Planned across Phases 1–7; not implemented in Phase 0_)  
> **Guiding Principle:** Render where UX and SEO gain value; keep pricing authority, commission rules, moderation, production files, and asset authorization strictly inside `apps/api` and private storage.

---

## 1. Hybrid SSR & Client-Side Rendering Boundaries

### 1.1 Critical Security Reality

**Server-Side Rendering (SSR) is NOT an IP-hiding or DRM layer.** Any HTML, serialized route loader payload, JavaScript chunk, SVG, texture bitmap, or `.glb` geometry sent to the browser is readable by the client via DevTools and network inspection. Therefore:

- SSR exists strictly for **SEO indexability, social OpenGraph metadata, and fast First Contentful Paint** on public catalog/marketplace pages.
- Proprietary algorithms, margins, secrets, private drafts, and unwatermarked production masters must **never** be serialized into SSR HTML, loader props, or client bundles.

### 1.2 Surface-by-Surface Rendering Architecture

| Surface / Route Group                                                                        | Rendering Strategy                                                                                                         | Security & Bundle Boundary                                                                                                    |
| :------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------- |
| Public Storefront, Category Catalog, Product Pages, Marketplace Listings, Creator Profiles   | **SSR / Pre-Rendered Public Routes** (`@react-router/express` when SEO phase activates, reading sanitized public API DTOs) | Only public catalog metadata + watermarked/low-res preview URLs allowed in SSR payloads                                       |
| **Mode A (2D Studio — Fabric.js)** & **Mode B (3D Studio — Three.js/R3F)**                   | **Client-Only Dynamic Islands** (`React.lazy` + `<ClientOnly>` mount guard)                                                | Browser `<canvas>` and WebGL throw during Node SSR (`window is not defined`); lazy-splitting prevents bloating storefront FCP |
| Customer Cart, Checkout, Account, Creator Dashboard, Admin Moderation & Fulfillment Consoles | **Client SPA Routes** calling authenticated `/api/v1/*` APIs                                                               | Never indexed, never cached publicly; strictly session-gated                                                                  |
| `300 DPI` Print Master Rasterization, Image Sanitization, Watermarking                       | **Backend Processing Pipeline (`apps/api` + `Sharp` / async worker)**                                                      | Reads private assets directly; outputs to locked `private/print-masters/` prefix                                              |

### 1.3 Practical React Router v7 Hybrid Path

Because `apps/web` already runs React Router v7 and `apps/api` runs Express 5:

1. Wrap interactive Studio 2D/3D routes behind a thin `<ClientOnly fallback={...}>` guard (`useEffect` mount flag) + `React.lazy()` dynamic imports (`fabric`, `three`, `@react-three/*`).
2. Keep business authority inside `apps/api` modular services rather than mixing DB access into frontend loaders.
3. In the SEO phase (Phase 7), integrate **React Router v7 Framework Mode** (`@react-router/express` `createRequestHandler`) cleanly inside the same Express/Nginx deployment topology for public catalog/marketplace routes, consuming sanitized public REST responses from `apps/api`.

---

## 2. Server-Side Intellectual Property & Business Logic Boundaries

Every sensitive domain computation lives exclusively inside `apps/api/src/modules/*`:

| Operation                                                | Server-Side Mandate & Rationale                                                                                                                                                                                  |
| :------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Product Pricing, Variant Surcharges, Tax & Discounts** | Client UI requests quotes and renders totals, but cart/checkout prices, promo codes, shipping fees, and print-zone surcharges are recomputed authoritatively inside MariaDB checkout transactions (`apps/api`).  |
| **Creator Commissions & Reward Formulas**                | Reward tiers, fixed/percentage splits, holding periods, and payout eligibility stay strictly inside `rewards` server modules and `creator_reward_ledger` tables—never leaked in JS bundles or public API fields. |
| **Payment Verification**                                 | Gateway callbacks (`bKash`, `Nagad`, `SSLCommerz`) require cryptographic/server-to-server status verification and idempotency keys before transitioning orders to `PAID`.                                        |
| **Design Ownership & Access Control**                    | Draft designs, upload assets, and payout views validate `session.userId === resource.ownerId` (or explicit `ADMIN` / `PRODUCTION_STAFF` RBAC role).                                                              |
| **Marketplace Moderation Approval**                      | Creator submissions enter `PENDING_REVIEW`; only verified `ADMIN` mutations expose items publicly.                                                                                                               |
| **Print-Area Bounds & Resolution Checks**                | Server re-validates normalized `[0..1]` object rects, active font allowlist, and minimum print DPI against `product_print_areas` prior to checkout/approval.                                                     |
| **High-Resolution Print Master Generation**              | Server workers read `private/uploads/` + verified `CanonicalDesignDocument` and generate `300 DPI` transparent PNGs + print manifests inside `private/print-masters/`.                                           |
| **Production & Fulfillment Metadata**                    | DTF/screen-press instructions, QC notes, supplier costs, and customer delivery PII remain restricted to authenticated `PRODUCTION_STAFF` / `ADMIN` routes.                                                       |

**Strictly Never Exposed to Clients:** Database credentials, S3 access/secret keys, `SESSION_SECRET`, payment merchant keys, internal fraud/moderation heuristics, wholesale COGS, internal authorization matrix source rules, or direct URLs to clean high-res creator artwork masters.

---

## 3. Private Object Storage, Presigned Delivery & Honest Browser Limits

### 3.1 Storage Partitioning (S3-Compatible: AWS S3 / Cloudflare R2 / MinIO)

| Bucket Prefix              | Access Policy               | Contents & Protection Level                                                                                  |
| :------------------------- | :-------------------------- | :----------------------------------------------------------------------------------------------------------- |
| `public/catalog/`          | Public CDN                  | Owned blank garment shots & **watermarked / downscaled (`<= 1200px`)** marketplace mockups                   |
| `public/garments-3d/`      | Public CDN                  | Draco-compressed `.glb` blank T-Shirt/Polo meshes & KTX2 fabric weave textures (no creator artwork embedded) |
| `private/uploads/`         | Private Bucket              | Immutable user/creator raw raster uploads (checksummed, EXIF-stripped, magic-byte verified)                  |
| `private/creator-masters/` | Private Bucket              | Approved creator artwork masters used only by backend thumbnailing & print rendering pipelines               |
| `private/print-masters/`   | Private (Staff/Worker Only) | Final `300 DPI` transparent PNG production files (`order_designs` snapshots) — **zero public/buyer access**  |

### 3.2 Authenticated Presigned Delivery Flow & Asset Versioning

1. **Uploads (`PutObject` Presigned URL, `60–120s` TTL):** Authenticated user requests upload slot -> backend validates RBAC/quotas -> issues key-scoped presigned PUT -> post-upload verification inspects magic bytes (`file-type`), rejects polyglots/oversized images (`Sharp` pixel limits), strips EXIF, and records SHA-256 + `asset_version` in `design_assets`.
2. **Reads (`GetObject` Presigned URL, `120–300s` TTL):**
   - Design owners editing drafts receive short-lived preview-resolution URLs (`<= 2048px`).
   - Marketplace visitors and shoppers NEVER receive links to `private/creator-masters/` or `private/print-masters/`; 2D/3D product previews display either pre-composited watermarked mockups or low/medium-resolution garment-clipped preview textures.
3. **Immutable Versioning:** Store object keys with explicit version segments (`/v1`, `/v2`) or SHA-256 content hashes so order snapshots remain reproducible forever and stale CDN caches never bleed into revised designs.

### 3.3 Honest Limits of Browser Asset Protection

- **Cannot Make Browser Assets Uncopyable:** Any texture bitmap, preview image, or blank `.glb` mesh loaded by a browser to render a 2D `<canvas>` or Three.js WebGL scene exists in client memory and GPU framebuffers and **can** be captured or extracted by determined users.
- **Real Security Goal:** Ensure **unwatermarked creator high-resolution source artwork and `300 DPI` production PNGs never touch buyer browsers at all**, keep draft URLs ephemeral (`<= 5 min`), watermark public artwork textures, and maintain tamper-evident audit logs for enforcement.

---

## 4. Required Security Controls Checklist

| Control                           | Implementation Requirement                                                                                                                                                                                                              |
| :-------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Authentication & Sessions**     | `HttpOnly`, `Secure` (prod), `SameSite=Lax` cookies; CSRF origin/header verification; server-side session revocation                                                                                                                    |
| **RBAC & Ownership**              | Express middleware verifying role (`CUSTOMER`, `CREATOR`, `PRODUCTION_STAFF`, `ADMIN`) + per-query `owner_id` scoping to prevent IDOR                                                                                                   |
| **Rate Limiting**                 | Tiered `express-rate-limit` thresholds on auth routes, upload/presign endpoints, export jobs, and checkout webhooks                                                                                                                     |
| **Request Validation**            | Strict Zod schemas (`validate.ts`) on params, query strings, and JSON bodies                                                                                                                                                            |
| **Upload & Magic-Byte Safety**    | Verify binary signatures via `file-type`; cap pixel counts (`limitInputPixels` in Sharp) against zip/decompression bombs; strip EXIF; reject unsafe `<svg>` (`<script>`, `onload`, `<foreignObject>`) or rasterize securely server-side |
| **Signed URL Hygiene**            | Minimal IAM permissions, `<= 120s` upload TTL, `<= 300s` read TTL, `Content-Disposition` / MIME pinning                                                                                                                                 |
| **Audit & Sensitive Access Logs** | Structured immutable audit events for marketplace reviews, reward rate edits, payout approvals, access to `private/print-masters/`, and `401`/`403` bursts                                                                              |
| **Financial & Ledger Integrity**  | Single MariaDB transactions with row locks, verified gateway webhooks + idempotency keys, append-only `creator_reward_ledger` entries                                                                                                   |
