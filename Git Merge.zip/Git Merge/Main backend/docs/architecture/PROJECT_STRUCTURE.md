# Project Structure & Package Boundaries

```text
your-choice/
├── apps/
│   ├── web/                     # @your-choice/web — React 19 + Vite + Tailwind CSS v4 + React Router
│   └── api/                     # @your-choice/api — Express 5 REST API modular monolith
├── packages/
│   ├── shared-types/            # @your-choice/shared-types — API envelopes, health contracts, user roles
│   ├── validation/              # @your-choice/validation — Browser-safe Zod schemas
│   ├── ui/                      # @your-choice/ui — Reusable shadcn/ui + Radix UI + Tailwind primitives
│   └── shared-utils/            # @your-choice/shared-utils — Exact BigInt money math, slug/CORS helpers
├── database/                    # @your-choice/database — Drizzle schema, SQL migrations, seed scripts
│   ├── schema/
│   ├── migrations/
│   ├── seeds/
│   └── scripts/
├── infrastructure/              # Local MariaDB Docker Compose & future deployment configs
├── docs/
│   ├── architecture/            # DESIGN_SYSTEM.md, UI_UX_IMPLEMENTATION_ROADMAP.md, UI_INTEGRATION_AUDIT.md, MOTION_DESIGN_SYSTEM.md, MOTION_IMPLEMENTATION_GUIDE.md, FOUNDATION_AUDIT.md, DESIGN_STUDIO_ARCHITECTURE.md, RENDERING_AND_IP_PROTECTION.md, PHASE_1_ARCHITECTURE.md, PROJECT_STRUCTURE.md, TECHNOLOGY_STACK.md
│   ├── decisions/               # ARCHITECTURE_DECISIONS.md, DESIGN_STUDIO_TECHNOLOGY_DECISIONS.md, TECHNOLOGY_DECISIONS.md
│   ├── development/             # LOCAL_DEVELOPMENT.md
│   └── research/                # Master creative asset, responsive guidelines, and component resource catalogs
├── e2e/                         # Playwright end-to-end foundation smoke suite
├── scripts/                     # Workspace CLI helpers (env preflight check)
├── .env.example
├── package.json
├── playwright.config.ts
├── pnpm-workspace.yaml
└── README.md
```

---

## Package Responsibilities & Dependency Rules

| Package / App                   | Responsibility                                                    | Allowed Imports                                                              | Forbidden Imports                                    |
| :------------------------------ | :---------------------------------------------------------------- | :--------------------------------------------------------------------------- | :--------------------------------------------------- |
| **`@your-choice/shared-types`** | Pure TypeScript interfaces and role constants                     | None (zero runtime deps)                                                     | Node built-ins, `react`, `express`, `drizzle-orm`    |
| **`@your-choice/validation`**   | Shared Zod request/entity schemas                                 | `@your-choice/shared-types`, `zod`                                           | Server secrets, `mysql2`, `node:*`                   |
| **`@your-choice/shared-utils`** | Pure deterministic formatting & exact `BigInt` decimal money math | Pure JS/TS                                                                   | DOM APIs, Node `fs`/`net`, server libs               |
| **`@your-choice/ui`**           | Accessible reusable UI primitives (Radix + CVA + Tailwind)        | `react`, `@radix-ui/*`, `class-variance-authority`, `clsx`, `tailwind-merge` | API clients, server packages                         |
| **`@your-choice/database`**     | Drizzle MariaDB schema, migrations, seeds                         | `drizzle-orm`, `mysql2`, `dotenv`                                            | Frontend React packages                              |
| **`@your-choice/api`**          | Express 5 HTTP server, middleware, modular domains                | All `@your-choice/*` except `@your-choice/ui`                                | React / DOM libraries                                |
| **`@your-choice/web`**          | React SPA shell, layouts, routes, feature slices                  | `@your-choice/shared-types`, `validation`, `shared-utils`, `ui`              | `@your-choice/database`, `express`, `mysql2`, `pino` |
