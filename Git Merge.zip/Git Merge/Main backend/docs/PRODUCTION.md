# Production, Inventory & Fulfillment Blueprint (Phase 6 Scope)

> **Status:** Planned for Phase 6 — _Not implemented in Phase 0_  
> **Initial Equipment Profile:** Freesub 16x24 flat heat press + outsourced DTF transfer printing + blank garment sourcing + manual QC.

---

## 1. Operational Invariants

1. **Separated Status Lifecycles**:
   - **Payment Status**: `Unpaid`, `Pending`, `Paid`, `Failed`, `Partially Refunded`, `Refunded`.
   - **Order / Fulfillment Status**: `Pending`, `Confirmed`, `Processing`, `In Production`, `Quality Check`, `Ready to Ship`, `Shipped`, `Delivered`, `Cancelled`, `Returned`.
2. **Transactional Stock Reservation**: Blank garment SKUs (`inventory_items`) use atomic database transactions (`stock_quantity`, `reserved_quantity`, `available_quantity`, `stock_movements`) on order confirmation so inventory cannot be oversold.
3. **Quality Control Gate**: Every `production_jobs` item must pass explicit `quality_checks` (print alignment, print quality, color consistency, fabric condition, pressing defects) before an order may transition to `Ready to Ship`.
4. **Courier Abstraction**: Shipping providers are isolated behind a courier adapter layer separate from core order domain logic.
