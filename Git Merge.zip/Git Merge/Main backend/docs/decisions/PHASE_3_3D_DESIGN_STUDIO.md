# Phase 3 Decision Record: Interactive 3D Apparel Design Studio

**Status:** Implemented (`@your-choice/web` + GLB Pipeline)  
**Primary Stack:** `three` + `@react-three/fiber@^9` + `@react-three/drei@^10` (MIT License)

---

## 1. Architecture & Rendering Decisions

1. **Lazy-Loaded Client Island & Chunk Isolation**
   - `StudioStage3D` and `GarmentModel3D` are loaded dynamically via `React.lazy` inside `DesignStudioPage` only when entering `mode=3d` (or opening a saved design whose `preferredMode === '3d'`).
   - `apps/web/vite.config.ts` isolates `three`, `@react-three/fiber`, `@react-three/drei`, `three-stdlib`, `troika-*`, and `maath` into the `three-vendor` manual chunk so standard storefront routes (`HomePage`, `ShopPage`, `ProductDetailPage`, `CheckoutPage`) remain unaffected.

2. **Asset Provenance & Reproducible In-House GLB Generation (CC0)**
   - External copyrighted apparel mockups and third-party marketplace scrapes are excluded.
   - `apps/web/scripts/generate-garment-glb.mjs` (`pnpm --filter @your-choice/web generate:models`) procedurally constructs tailored glTF 2.0 binary garments directly into `apps/web/public/models/`:
     - `crew-tshirt.glb` (~292 KB): Tailored crewneck torso + angled cuffed sleeves + ribbed crew collar + dark interior neck cavity lining + dedicated curved UV print islands (`garment_front`, `garment_back`).
     - `pique-polo.glb` (~311 KB): Tailored polo torso + folded polo collar + chest button placket + 3 beveled buttons + dark interior neck cavity + dedicated curved UV print islands (`polo_left_chest`, `garment_back`).
   - Model selection maps deterministically via `resolveGarmentModelSpec`: polo categories/slugs load `pique-polo.glb` with pique weave bump maps; heavyweight & oversized crew tees load `crew-tshirt.glb` with jersey weave bump maps (`widthScale = 1.07` for oversized box tees).

3. **Dedicated UV Print Islands + `CanvasTexture` (No `DecalGeometry`)**
   - `apps/web/src/features/design-studio/three/canvas-texture-bridge.ts` paints each active `CanonicalDesignSurface` (`text`, `shape`, `graphic`, `image`, `group`) onto an offscreen canvas proportional to `physicalWidthMm : physicalHeightMm` (up to `1280px` on desktop, `896px` on low-power devices).
   - Generated `THREE.CanvasTexture` instances explicitly set `colorSpace = THREE.SRGBColorSpace` and `flipY = false` to match glTF 2.0 `TEXCOORD_0` origin rules (`(0,0)` top-left), avoiding inverted/mirrored prints.
   - Print island meshes bind transparent overlay materials using `polygonOffset` (`polygonOffsetFactor: -2`) directly over matching garment contour regions (`garment_front`, `garment_back`, `polo_left_chest`), avoiding the stretching and UV seam tearing common with `DecalGeometry`.
   - Clicking a printed region on the 3D garment switches `activeSurfaceKey` and animates the camera smoothly to inspect that surface (`Front`, `Back`, `Left Chest`).

4. **Materials, Studio Lighting & Offline Environment**
   - Garment bodies apply `THREE.MeshPhysicalMaterial` (`metalness: 0`, calibrated roughness `0.82–0.90`, `sheen: 0.46`, `sheenRoughness: 0.72`) paired with procedural micro-weave jersey/pique bump maps (`procedural-fabric-maps.ts`) tinted dynamically to `variant.colorHex`.
   - Studio lighting uses a local procedural `<Environment resolution={128}>` with `<Lightformer>` panels, warm key directional light, cool fill, calibrated cyan rim light, and `<ContactShadows>` — requiring **zero external `.hdr` network requests**.

5. **WebGL Capability Probe, Disposal & Graceful Fallback**
   - `detectWebGLCapability()` probes WebGL2/WebGL1 support safely, releases the probe context immediately (`WEBGL_lose_context`), and adapts `dpr` and shadow map resolution for narrow/low-core devices.
   - Cloned geometries, materials, and `CanvasTexture` instances are explicitly `.dispose()`d whenever replaced or unmounted.
   - `Studio3DErrorBoundary` + `webglcontextlost` handling render an accessible static 2D garment preview fallback (`data-testid="studio-3d-fallback"`) with one-click recovery back to Mode A (`2D Editor`).

6. **Two-Track Print Master Separation**
   - Mode B 3D previews and optional safe-zone guides are strictly customer visualization aids. All `300 DPI` transparent RGBA print masters continue to execute server-side in `@your-choice/api` (`sharp`) from validated `CanonicalDesignDocument` coordinates.

---

## 2. Honest Limitations & Future Refinement

- **Parametric vs. Sculpted Cloth Folds:** The current CC0 `.glb` garments are clean parametric torso/sleeve/collar meshes (< 320 KB each) with subtle hem drape; future Phase 3B artist-sculpted Marvelous Designer / Blender garments can drop directly into `public/models/` provided they retain the mesh names `garment_body`, `garment_collar`, `garment_front`, `garment_back`, and `polo_left_chest`.
- **Direct 3D Mesh Dragging:** Complex typography alignment, multi-select grouping, and precise image cropping remain anchored in Mode A (2D Fabric.js editor), while Inspector controls (`x/y/scale/rotation/color`) update Mode B 3D textures live.
