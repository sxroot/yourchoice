# Phase 2 — Professional 2D Apparel Design Studio Architecture

**Status:** Implemented (Phase 2)  
**Primary Routes:** `/studio`, `/studio/:designId`, `/api/v1/designs/*`  
**Brand Stack:** React 19 + TypeScript, Fabric.js v7.4.0, `@fontsource/*`, `react-easy-crop`, `zustand`, Express 5, `multer`, `file-type`, `sharp` v0.35.5, MariaDB 10.11+ via Drizzle ORM

---

## 1. Architecture Overview

Phase 2 delivers an interactive browser-based 2D apparel customization workbench directly coupled with the Phase 1B `products`, `product_variants`, and `product_print_areas` models and Phase 1C `cart_items` / `order_items` snapshots:

1. **Canonical Coordinate Document (`@your-choice/shared-types` & `@your-choice/validation`)**:
   - Every design stores normalized center-anchored coordinates (`x`, `y`, `width`, `height` in `[0..1]`, `rotationDeg` around object center) inside `CanonicalDesignDocument` keyed by garment `surfaceKey` (`front`, `back`, `left_chest`, etc.).
   - Supported node types: `text`, `shape` (`rect`, `circle`, `triangle`, `star`, `hexagon`, `line`), commercial-safe vector `graphic` (`STUDIO_GRAPHIC_PACK`), `image` (`assetId` + `cropRect`), and nested `group`.
   - Switching garments/variants preserves artwork per matching `surfaceKey` and surfaces an explicit warning in the UI when physical `physicalWidthMm / physicalHeightMm` proportions differ by more than 8%.

2. **Browser Editing Canvas (`apps/web/src/features/design-studio/`)**:
   - **Fabric.js v7 (`MIT`)** renders strictly inside browser `<canvas>` elements mounted via `useRef` + `useEffect` disposal inside lazy-loaded `/studio` chunks (no SSR/Node canvas coupling).
   - Features include surface switching (`front` / `back` / `left_chest`), variant color garment vector backdrop aligned 1:1 to `mockupBounds`, live zoom (`50%–240%`), safe-margin & optional grid overlays, center snap guides, EN + BN typography (`Outfit`, `Bebas Neue`, `Barlow Condensed`, `Syne`, `Noto Sans Bengali`, `Baloo Da 2`, `Hind Siliguri`, `Space Grotesk`, `Plus Jakarta Sans`, `JetBrains Mono`), uploaded artwork pre-crop (`react-easy-crop`, `MIT`), multi-select `Group`/`Ungroup`, z-order layer stack with visibility/lock controls, undo/redo history, local debounced draft recovery, editable JSON dialog, and live print preflight DPI/boundary validation.

3. **Server-Side Binary Upload Validation, Preview vs Protected 300 DPI Print Masters**:
   - Customer uploads (`/api/v1/designs/assets/upload`) are limited to `15 MB` in memory via `multer`, inspected via `file-type` binary magic bytes (`image/png`, `image/jpeg`, `image/webp` only; SVG upload is excluded to avoid script/XXE attack vectors), stripped of EXIF metadata with `sharp`, deduplicated/hashed with `sha256`, and saved in private `private/` storage (`STORAGE_LOCAL_ROOT`).
   - Preview endpoints (`/designs/assets/:assetId/preview` and `/designs/:designId/surfaces/:surfaceKey/preview`) serve bounded web previews (`<= 900px`) restricted to the resource owner or staff/admin roles (`IDOR` protected).
   - **300 DPI Transparent RGBA PNG Print Masters** (`/designs/:designId/surfaces/:surfaceKey/export-print-master` & `/exports/:exportId/download`) are rasterized server-side with `sharp` from canonical JSON at exact millimeter dimensions `round((physicalWidthMm / 25.4) * targetDpi)` × `round((physicalHeightMm / 25.4) * targetDpi)` with `density: targetDpi` metadata — never trusting client canvas `toDataURL()` buffers as production masters.

4. **Commerce Integration (`cart_items` & `order_items`)**:
   - Adding a custom design to cart (`POST /api/v1/designs/:designId/add-to-cart`) validates preflight readiness, calculates per-surface `surchargeAmount` server-side from configured `product_print_areas`, writes `design_public_id` + `customization_meta_json` into `cart_items` under a unique customization `itemKey`, and preserves `design_public_id`, `design_title_snapshot`, and `production_spec_json` on `order_items` at checkout.

---

## 2. Database & Migration

Added via `database/schema/designs.ts` & `database/migrations/0004_yellow_puma.sql`:

- `design_assets` (owner-isolated uploaded raster assets + preview keys + `sha256`)
- `designs` (design summary, `current_version_number`, `product_id`, `product_variant_id`, `status`)
- `design_versions` (immutable JSON snapshots + preflight validation summary)
- `design_print_exports` (protected 300 DPI RGBA PNG export records + `sha256` checksums)

---

## 3. Known Caveats & Operational Notes

- **Server Font Rendering Dependency**: Server-side SVG/Sharp text rasterization relies on OS/Fontconfig fallback fonts installed on the host Linux/Windows image for `.ttf`/`.woff2` text shaping inside librsvg (`sharp`). Installing `@fontsource` fonts into the container font directory improves exact metric parity with Chrome Fabric.js text previews.
- **Fabric Node Dependency Avoidance**: `fabric@7.4.0` declares `canvas` and `jsdom` as runtime dependencies in npm for optional Node testing, which are excluded cleanly from the Express API runtime because server rasterization uses `sharp` (`Apache-2.0` prebuilt native binaries) exclusively.
