# Phase 1C Architecture Decision & Commerce Specification

> **Status:** Implemented & Verified (`@your-choice/database`, `@your-choice/shared-types`, `@your-choice/validation`, `@your-choice/api`, `@your-choice/web`, Playwright E2E)
> **Follows:** [PHASE_1_ARCHITECTURE.md](../architecture/PHASE_1_ARCHITECTURE.md) & `ADR-001`..`ADR-014`

---

## 1. Persistent Cart & Guest-to-Account Merge Model

1. **Dual Identity:**
   - **Authenticated Users:** `carts.user_id` bound directly to `users.id` (`ON DELETE CASCADE`).
   - **Anonymous Shoppers:** `yc_cart` (`HttpOnly`, `SameSite=Lax`) cookie stores a 32-byte cryptographically random token whose SHA-256 hash (`carts.guest_token_hash`) identifies the guest cart row cleanly for `CART_TTL_DAYS` (default 14 days).
2. **MariaDB Unique Key Safety:**
   - Because MariaDB/MySQL allows multiple rows with `NULL` inside composite unique constraints `(cart_id, variant_id, design_public_id)`, `cart_items.item_key` stores a normalized deterministic key (`variant:<variantId>` for standard blanks; ready for `variant:<variantId>:design:<designPublicId>` in Phase 2/3) indexed by `UNIQUE (cart_id, item_key)`.
3. **Auth Boundary Merge:**
   - `POST /api/v1/auth/register` and `POST /api/v1/auth/login` automatically invoke `cartService.mergeGuestCartForAuthenticatedUser()` if `yc_cart` is present, combining line quantities up to live variant stock caps and clearing the stale `yc_cart` cookie.

---

## 2. Server-Authoritative Pricing & Bangladesh Shipping Rules

- All line totals, subtotals, free-shipping thresholds, and order totals are computed exclusively on the API using exact `BigInt` minor units (`decimalToMinorUnits` / `minorUnitsToDecimal`) from live DB variant prices (`priceOverride ?? basePrice`) and active `shipping_zones`.
- **Seeded Bangladesh Zones (`database/shipping-seed-data.ts`):**
  - `dhaka_metro`: Covers `Dhaka` division — BDT `70.00` flat fee, free delivery at BDT `2,500.00+` (1–2 days).
  - `nationwide_bd`: Covers `Chattogram`, `Rajshahi`, `Khulna`, `Barishal`, `Sylhet`, `Rangpur`, `Mymensingh` — BDT `130.00` flat fee, free delivery at BDT `3,000.00+` (3–5 days).
- Client-supplied prices, shipping fees, totals, or payment states are never accepted by `createOrderSchema` or `OrderService`.

---

## 3. Transactional Orders, Inventory Concurrency & Immutable Snapshots

- **Atomic Checkout Transaction (`DrizzleCommerceRepository.placeOrderTransactionally`):**
  1. Validates active variant + product + `stockQuantity >= quantity` via conditional SQL update (`SET stock_quantity = stock_quantity - qty WHERE id = ? AND stock_quantity >= ?`).
  2. Any zero-row update rolls back the entire transaction with `409 INSUFFICIENT_STOCK`.
  3. Persists immutable point-in-time commercial records in `orders` (`shipping_address_json`, `shipping_zone_name_snapshot`, totals) and `order_items` (`product_name_en_snapshot`, `product_name_bn_snapshot`, `sku_snapshot`, `color_name_en_snapshot`, `color_hex_snapshot`, `size_code_snapshot`, `unit_price`, `customization_fee`, `line_total`, plus nullable future custom design/production columns `design_public_id`, `design_title_snapshot`, `production_spec_json`).
  4. Subsequent catalogue edits or price changes do not mutate historical order records.
- **Guest Receipt Protection:** Guest checkout sets a short-lived HMAC-SHA256 `HttpOnly` cookie (`yc_order_receipt`) scoped to that `orderNumber`. Anonymous requests without matching owner session, admin permission (`orders:read:all`), or valid signed `yc_order_receipt` receive `401 Unauthorized`, preventing `GET /orders/:orderNumber` IDOR enumeration.
- **Self-Service Cancellation:** Customers can cancel `pending` or `confirmed` orders (`CUSTOMER_CANCELLABLE_STATUSES`), restoring reserved `product_variants.stock_quantity` atomically inside a transaction.

---

## 4. Honest Bangladesh Payment Architecture & Signed Webhooks

- `cod` (**Cash on Delivery / ক্যাশ অন ডেলিভারি**) is always `enabled: true, configured: true` (`payment_status = 'unpaid'` at placement, settled by staff via `POST /api/v1/admin/orders/:orderNumber/payment-settlement` with receipt/courier proof).
- Digital Bangladesh gateways (`bkash`, `nagad`, `sslcommerz_card`) inspect server configuration secrets (`BKASH_WEBHOOK_SECRET`, `NAGAD_WEBHOOK_SECRET`, `SSLCOMMERZ_STORE_PASSWD`):
  - When unconfigured, `/api/v1/checkout/options` exposes `enabled: false, configured: false` with bilingual diagnostic reasons, and checkout attempts reject with `400 PAYMENT_PROVIDER_NOT_CONFIGURED`. Fake payments are never simulated.
  - When configured, `POST /api/v1/payments/webhooks/:gateway` (mounted outside browser CSRF double-submit) verifies timing-safe HMAC-SHA256 `X-Webhook-Signature`, confirms amount + currency match against the stored order, updates `payment_transactions` & `orders.payment_status` transactionally, auto-confirms `pending -> confirmed`, and treats duplicate `(gateway, transaction_ref)` deliveries as idempotent replays.
