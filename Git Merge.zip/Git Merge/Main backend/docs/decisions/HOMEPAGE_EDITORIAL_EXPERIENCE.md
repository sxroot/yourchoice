# YOUR CHOICE Homepage Experience

## Direction

The homepage takes cues from the supplied references: a single photographic campaign frame, oversized editorial type, quiet numbered section markers, generous negative space, a horizontal product edit, and a dark studio story. The composition and copy are original to YOUR CHOICE and use its Royal Blue, Electric Blue, Cyan, Black, Charcoal, Silver, and Alabaster palette. The official logo asset remains unchanged.

## Motion and interaction

- The existing `motion` package and `@/components/motion` primitives handle above-the-fold fades and once-only section reveals. Motion is already installed and documented in the workspace as MIT licensed, so this change adds no animation dependency.
- The hero uses one `useScroll`/`useTransform` value to move its image by up to 40 px. It animates only a compositor-friendly transform. The effect is disabled by `prefers-reduced-motion` and on narrow touch layouts.
- Product discovery uses a native overflow rail with CSS scroll snapping, touch scrolling, and previous/next buttons. It does not intercept vertical scrolling and does not require a carousel package.
- Category cards use brief image scale and arrow feedback on hover-capable pointers. Focus remains on the existing shop and product links.

## Responsive and performance decisions

- The campaign hero keeps the model on the right and the headline on the left at desktop widths. On mobile the photograph is reframed behind the copy, the studio badge is removed, and text/actions remain in a single column.
- Product rails are swipeable on touch screens and show a partial next card as a discovery cue. Category cards stack on narrow screens; the existing global mobile navigation and cart drawer remain active.
- The hero campaign JPEG is 1680 × 952 and approximately 85 KB, loaded eagerly at high priority. Below-the-fold product and category images are lazy-loaded with intrinsic dimensions to reserve layout space.
- No animation changes layout dimensions. Existing app-wide reduced-motion CSS remains the safety fallback.

## Commerce and current studio boundary

The featured rail and category cards still use the public catalog APIs, localized product fields, prices, image URLs, and existing product/shop routes. Cart, authentication, checkout, and API health behavior are untouched. The health panel remains available as a collapsed status detail near the bottom of the page.

The homepage calls out the existing 2D and 3D Design Studio and links directly to `/studio?product=<slug>` for the first featured customizable product. If featured products are unavailable, the link opens `/studio`, which can select from its live customizable catalog. The studio route, product selection, and editor remain owned by the existing design-studio feature.

## Verification

- `pnpm typecheck` passed for all workspace packages and apps.
- `pnpm build` passed for shared packages, the API, and the web app; the final `pnpm --filter @your-choice/web build` also passed after the studio CTA update.
- Focused ESLint and Prettier checks passed for the changed web files.
- Local HTTP checks returned 200 for `/`, the transformed homepage module, and the 85 KB campaign JPEG.
- Full `pnpm lint` reports 9 errors and 1 warning in unrelated design-studio files (`DesignJsonModal.tsx`, `StudioCanvasStage.tsx`, and `DesignStudioPage.tsx`); the changed homepage, header, product card, and translations are not among the reported files.
- A live desktop/tablet/mobile screenshot pass was not completed because the desktop browser bridge expired before opening the local preview.
