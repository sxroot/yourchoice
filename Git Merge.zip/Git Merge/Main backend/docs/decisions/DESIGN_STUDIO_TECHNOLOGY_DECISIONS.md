# Design Studio & IP Protection Technology Decisions

> **Status:** Locked Architecture & Research Reference (_Packages install when Phase 2 and Phase 3 begin_)  
> **Companion Specs:** [DESIGN_STUDIO_ARCHITECTURE.md](../architecture/DESIGN_STUDIO_ARCHITECTURE.md) · [RENDERING_AND_IP_PROTECTION.md](../architecture/RENDERING_AND_IP_PROTECTION.md) · [DESIGN_STUDIO_AND_CREATIVE_RESOURCE_LIBRARY.md](../research/DESIGN_STUDIO_AND_CREATIVE_RESOURCE_LIBRARY.md)

---

## 1. Selected Architecture & Technology Matrix

| Domain                            | Selected Choice                                                                       | Evaluated Alternatives                                                    | License                  | Target Phase           | Rationale                                                                                                                                                                                                                                    |
| :-------------------------------- | :------------------------------------------------------------------------------------ | :------------------------------------------------------------------------ | :----------------------- | :--------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Mode A (2D Studio)**            | `fabricjs/fabric.js` (`v7.4+`)                                                        | `konvajs/react-konva` (**MIT** backup), `excalidraw`, `tldraw`, `polotno` | **MIT**                  | **Phase 2**            | Native TS (`v6/v7` — do **not** install `@types/fabric`), built-in text (`IText`/`Textbox`), shapes, groups, `clipPath` print zones, JSON serialization, and headless `fabric/node` parity; avoids commercial SDK fees (`tldraw`, `polotno`) |
| **Image Pre-Crop Modal**          | `ValentinH/react-easy-crop`                                                           | `fengyuanchen/cropperjs`                                                  | **MIT**                  | **Phase 2**            | Touch-friendly zoom/crop returning non-destructive `croppedAreaPixels` while raw uploads remain immutable                                                                                                                                    |
| **Mode B (3D Engine & Bridge)**   | `mrdoob/three.js` (`r187+`) + `pmndrs/react-three-fiber` (`^9`) + `pmndrs/drei`       | `google/model-viewer`, `BabylonJS`, Spline                                | **MIT**                  | **Phase 3**            | R3F `v9` targets React 19; full WebGL control over print-zone UV `CanvasTexture`, `MeshPhysicalMaterial` cloth sheen (`KHR_materials_sheen`), damped orbit camera presets, and `.dispose()` cleanup                                          |
| **Garment Surface Mapping**       | Dedicated Flat UV Print Islands + `THREE.CanvasTexture`                               | `DecalGeometry`, whole-body UV repaint                                    | **MIT** (Three.js)       | **Phase 3**            | Eliminates `DecalGeometry` cloth-wrinkle stretching and seam tearing; aligns Mode B 3D preview 1:1 with flat `300 DPI` heat-press exports                                                                                                    |
| **3D Asset Optimization**         | `donmccurdy/glTF-Transform` (GLB + Draco + KTX2)                                      | Raw `.obj`/`.fbx`, uncompressed PNGs                                      | **MIT**                  | **Phase 3**            | Compresses Crewneck T-Shirt and Collared Polo `.glb` assets (`< 5 MB`) and GPU-compressed fabric textures (`KTX2Loader`)                                                                                                                     |
| **Embeddable Viewer**             | `google/model-viewer`                                                                 | Three.js + R3F                                                            | **Apache-2.0**           | **AVOID (for Studio)** | Cannot synchronize multi-layer custom 2D `CanonicalDesignDocument` edits or raycast UV print coordinates                                                                                                                                     |
| **Server Print & Image Pipeline** | `lovell/sharp` + `fabric/node` (`StaticCanvas`)                                       | `@resvg/resvg-js` (**MPL-2.0**), client `toDataURL()` trust               | **Apache-2.0** / **MIT** | **Phase 1–2**          | High-speed `libvips` validation (`limitInputPixels`), EXIF stripping, `300 DPI` transparent PNG export, and `<50ms` layered 2D mockups; optional `ag-psd` offline only                                                                       |
| **Magic-Byte Verification**       | `sindresorhus/file-type`                                                              | Extension / HTTP header trust                                             | **MIT**                  | **Phase 1–2**          | Verifies real binary signatures (`png`, `jpeg`, `webp`) before persisting or rendering uploads                                                                                                                                               |
| **Private Object Storage**        | `@aws-sdk/client-s3` + `@aws-sdk/s3-request-presigner` (behind `StorageService` port) | Public upload directories                                                 | **Apache-2.0**           | **Phase 1–2**          | S3 / Cloudflare R2 / MinIO compatible; enforces short-lived signed PUT (`60–120s`) and GET (`120–300s`) URLs                                                                                                                                 |
| **Hybrid SEO SSR**                | React Router v7 (`@react-router/express`) + `<ClientOnly>` Studio Islands             | Next.js migration, pure unindexed SPA                                     | **MIT**                  | **Phase 7**            | Keeps public catalog crawler-friendly while isolating browser-only Fabric `<canvas>` and WebGL R3F chunks cleanly                                                                                                                            |

---

## 2. Two-Track Rendering & Print Production Architecture

### 2.1 Mode A (`2D`) + Mode B (`3D`) -> Server Print Pipeline

1. **Browser Interactive Studio (`apps/web/src/features/design-studio/`, `React.lazy`):**
   - **Mode A (`Fabric.js` v7):** Viewport-scaled canvas inside `useRef`, synced into `CanonicalDesignDocument` normalized `[0..1]` coordinates clipped to `product_print_areas`. Displays real-time DPI resolution warnings based on original upload pixel dimensions vs. print area inches.
   - **Mode B (`Three.js` + `R3F v9`):** Lazy-loaded garment viewer hydrating the exact same `CanonicalDesignDocument` surfaces onto an offscreen `1024–2048px` `THREE.CanvasTexture` (`SRGBColorSpace`, `flipY = false`) mapped to flat-unwrapped chest/back/pocket UV islands, draped under CC0 `normalMap` / `roughnessMap` and `KHR_materials_sheen`.
2. **Server Rasterization & IP Protection (`apps/api` + Async Worker):**
   - Never trust browser `toDataURL()` blobs as final production art.
   - Backend hydrates `CanonicalDesignDocument` + unaltered `private/uploads/` source images into headless `StaticCanvas` using matching self-hosted `@fontsource` font binaries, renders a transparent `RGBA` PNG at `widthInches * 300` x `heightInches * 300` px (e.g., `3600 x 4800 px` for `12" x 16"`), stamps `density: 300` and `sRGB` via `Sharp`, saves into `private/print-masters/`, and always calls `staticCanvas.dispose()` in `finally`.

### 2.2 In-House Layered 2D Garment Mockup Compositor

Instead of third-party smart-object PSD APIs (or Printful/Freepik templates whose SaaS licenses prohibit multi-user customizer embedding), build an in-house 3-layer compositor in `Sharp` (backend previews) and HTML5 Canvas/CSS (fast storefront previews) from **100% owned garment photography** + **CC0** fabric overlays (`ambientCG` / `Poly Haven`):

1. **Base Silhouette Mask (`base-mask.png`):** Separates cloth body from collars/buttons/tags for dynamic colorway HEX tinting.
2. **Print Region (`product_print_areas`):** Exact normalized bounding coordinates where customer transparent artwork renders.
3. **Shading & Fabric Realism (`shadows-highlights.png` + CC0 knit/pique shading):** Composited _above_ artwork via `multiply` (folds) and subtle `screen`/`overlay` (fabric nap) so printed graphics sit naturally inside cotton/pique weave.

---

## 3. UI Motion, Bilingual Typography & Brand Alignment

- **Brand Token Status (Reconciled in Phase A/B & Prompt 04A):** Phase 0 placeholder violet tokens are completely removed. [tokens.css](../../apps/web/src/styles/tokens.css) and [index.css](../../apps/web/src/index.css) define the official **YOUR CHOICE** palette (**Royal Blue `#1d4ed8`**, **Electric Blue `#2563eb`**, **Cyan `#0891b2`/`#0e7490`/`#22d3ee`**, **Obsidian Black `#06080d`**, **Charcoal `#111622`**, **Silver `#cbd5e1`**, **Alabaster `#f8fafc`**), and `your-choice-logo.png` is preserved `1:1`.
- **Animation Isolation Rules (`motiondivision/motion` MIT):**
  - _Storefront / Marketplace:_ `LazyMotion` (`domAnimation`) + `<MotionConfig reducedMotion="user">` + CSS transitions (`150–260ms`).
  - _Mode A (2D Studio):_ Tailwind CSS panel transitions (`100–150ms`) only; zero Framer Motion wrappers around `<canvas>` containers so Fabric pointer interactions maintain `60fps`.
  - _Mode B (3D Studio):_ R3F `useFrame` lerp + damped `OrbitControls`; optional `theatre-js` core evaluated only if scripted camera launches are added (never bundle `@theatre/studio`).
  - _Admin / Creator Consoles:_ Minimal CSS state transitions only (`120–150ms`); no staggered data tables.
- **Self-Hosted Bilingual Fonts (`@fontsource`, `SIL OFL 1.1`):**
  - _Storefront & UI Core:_ `Space Grotesk`, `Plus Jakarta Sans`, `Hind Siliguri` (already installed), plus `Noto Sans Bengali` (queued for Phase 1) and `JetBrains Mono`.
  - _Design Studio Apparel Presets (Phase 2):_ English (`Space Grotesk`, `Plus Jakarta Sans`, `Outfit`, `Barlow Condensed`, `Bebas Neue`, `Anton`, `Syne`, `JetBrains Mono`) and Bangla (`Noto Sans Bengali`, `Hind Siliguri`, `Anek Bangla`, `Baloo Da 2`, `Tiro Bangla`). Exclude proprietary/non-commercial `SutonnyMJ` and `Lipighor` downloads.

---

## 4. Commercial Licensing & Phased Install Guardrails

| Classification                                                                | Approved / Blocked Tools                                                                                                                                                                                                                          | Policy                                                                                                 |
| :---------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | :----------------------------------------------------------------------------------------------------- |
| **Approved Commercial + SaaS (`MIT` / `Apache-2.0` / `ISC` / `CC0` / `OFL`)** | `fabric.js`, `react-easy-crop`, `three`, `@react-three/fiber@9`, `@react-three/drei`, `gltf-transform`, `sharp`, `file-type`, `@aws-sdk/client-s3`, `motion`, `lucide-react`, `ambientCG`, `Poly Haven`, `@fontsource/*`, `satnaing/shadcn-admin` | Cleared for commercial SaaS, customer Design Studio exports, and 300 DPI fulfillment                   |
| **Conditional UI/Marketing Only**                                             | `unDraw`, `ManyPixels`, `DrawKit`, `Texturelabs`, `FFFuel`, `Hero Patterns`, `Unsplash`/`Pexels`                                                                                                                                                  | Storefront/marketing backdrops only — **never** expose inside Design Studio clipart or mockup builders |
| **Prohibited (`AVOID`)**                                                      | `tldraw`, `Polotno`, `IMG.LY`, `GSAP` (Webflow builder clause), `lenis`, `Freepik`/`Storyset` free tiers, `Printful`/`Printify` mockups, `SutonnyMJ`, `Lipighor` free, `Aceternity` Pro, unlicensed repos                                         | Never install or copy into the codebase                                                                |

### Dependency Install Gate

- **Phase 1 (Auth, Catalog & Secure Uploads):** `@node-rs/argon2`, `express-rate-limit` (`^8`), `@tanstack/react-query` (`^5`), `zustand` (`^5`), `react-hook-form`, `@hookform/resolvers` (`^5` for Zod v4), `react-i18next` + `i18next`, `@fontsource/noto-sans-bengali`, `file-type`, `sharp`, `@aws-sdk/client-s3`, `@aws-sdk/s3-request-presigner`.
- **Phase 2 (Mode A — 2D Studio + Print Engine):** `fabric` (`v7.4+`, no `@types/fabric`), `react-easy-crop`, `@fontsource/*` Studio font packs (`ag-psd` offline dev tool only if needed).
- **Phase 3 (Mode B — 3D Garment Studio):** `three`, `@types/three`, `@react-three/fiber@^9`, `@react-three/drei` (+ offline `glTF-Transform` CLI).
- **Phase 4–6:** `@tanstack/react-table` (`^8`/`^9`), payment & courier adapters (`Redis`/`BullMQ` when async queue workers activate).
- **Phase 7:** `@react-router/express` hybrid SSR evaluation for public catalog SEO.
