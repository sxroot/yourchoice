# Phase 1B Decision & Architecture Record: Customer Addresses, Apparel Catalogue & Bilingual Storefront

> **Phase:** Phase 1B  
> **Scope:** Customer Bangladesh Address Book, T-Shirt & Polo Shirt Catalogue, Variant Matrix, Editor-Agnostic Print Areas, Admin Catalogue Management, and Bilingual (`EN` / `বাংলা`) Storefront

---

## 1. Key Architectural Decisions

### 1.1 Editor-Agnostic Configurable Print Areas (`product_print_areas`)

To guarantee zero lock-in between Phase 1B product configuration and future Mode A (2D Fabric.js) and Mode B (3D Three.js / React Three Fiber) studios:

- Every configurable zone (`front`, `back`, `left_chest`, `right_sleeve`, `left_sleeve`) stores:
  1. **Physical Production Print Spec:** `physicalWidthMm`, `physicalHeightMm`, `targetDpi` (default `300`), and `safeInsetMm`.
  2. **Normalized `[0..1]` 2D Stage Overlay (`mockupBounds`):** `{ x, y, width, height, rotationDeg }` verified via Zod (`x + width <= 1`, `y + height <= 1`). Storefront previews and 2D Fabric.js canvases project directly into stage coordinates without assuming canvas pixel resolution.
  3. **Optional 3D UV Region Mapping (`uvRegion`):** `{ islandKey, meshTarget, uMin, uMax, vMin, vMax }` so 3D glTF apparel meshes bind deterministically to the same print surface contract without storing Three.js-specific scene graphs in the catalogue table.

### 1.2 Authoritative `BDT` Money Computation (`BigInt` Minor Units)

- Database columns store prices and surcharges in `DECIMAL(12, 2)` paired with explicit `currency_code CHAR(3) DEFAULT 'BDT'` (`ADR-010`).
- Services compute `effectivePrice` (`variant.priceOverride ?? product.basePrice`) and min/max price ranges in integer poisha (`BigInt` minor units) via `@your-choice/shared-utils`, eliminating floating-point rounding drift.

### 1.3 Publish Safety Guard & RBAC Split

- Newly created garments start in `draft` status. Transitioning a product to `active` (`status: 'active'`) enforces at least **one active SKU variant** (`CATALOG_PUBLISH_REQUIRES_VARIANT`, `400`).
- RBAC separation in `admin-catalog.routes.ts`:
  - `GET /api/v1/admin/*` permits `staff`, `admin`, and `super_admin` (`catalog:read`).
  - `POST` / `PATCH` / `PUT` / `DELETE /api/v1/admin/*` require `admin` or `super_admin` (`catalog:write`).
- All administrative catalog/variant/print-area mutations record structured entries in `audit_logs` via `AuditService`.

### 1.4 Customer Address Ownership & Default Invariant (`/api/v1/users/me/addresses`)

- All queries and mutations derive `userId` exclusively from `req.auth.userId` (no IDOR risk; cross-user `publicId` lookups return `404`).
- Enforces Bangladesh administrative division enum (`BANGLADESH_DIVISIONS`: 8 divisions) and Bangladesh phone format validation.
- Limits saved addresses per customer (max 20 active addresses) and maintains atomically at most one `isDefault = true` address per user, promoting the next newest address automatically if the default is deleted.

### 1.5 Bilingual `EN` / `বাংলা` Foundation (`i18next` + `react-i18next`)

- Database rows store explicit bilingual fields (`name_en`/`name_bn`, `subtitle_en`/`subtitle_bn`, `description_en`/`description_bn`, `fabric_spec_en`/`fabric_spec_bn`, `color_name_en`/`color_name_bn`, `label_en`/`label_bn`, `alt_text_en`/`alt_text_bn`).
- Frontend `useAppLocale()` persists `yc_locale` in `localStorage`, updates `<html lang="en|bn">`, and picks Bengali fallback typography (`Hind Siliguri`).

---

## 2. Schema, Migration & Seed Summary

- **Drizzle Schemas:**
  - `database/schema/identity.ts`: Added `userAddresses` (`user_addresses`).
  - `database/schema/catalog.ts`: Added `productCategories`, `products`, `productImages`, `productVariants`, `productPrintAreas`.
  - `database/schema/audit.ts`: Added `auditLogs`.
- **Migration:** `database/migrations/0002_tidy_silverclaw.sql` (generated cleanly with `drizzle-kit generate`).
- **Seed Data:** `database/catalog-seed-data.ts` + `database/seeds/catalog.seed.ts` seeding `t-shirts` and `polo-shirts` categories and 4 bilingual products with SKU matrices and front/back/left-chest print zones.

---

## 3. Environment Note & Next Milestone

- **Host Provisioning Dependency:** Local environment currently has Node/pnpm without a running MariaDB 10.11+ service or `.env` provisioned; live execution of `pnpm db:migrate && pnpm db:seed` against MariaDB remains to be executed once the database instance is available.
- **Recommended Next Milestone (Phase 1C):** Anonymous + Authenticated **Cart (`carts`, `cart_items`), Guest Cart Merge on Login, and Transactional Cash-on-Delivery (`COD`) Checkout (`orders`, `order_items`, `order_status_history`)** with atomic MariaDB variant stock decrementing (`UPDATE product_variants SET stock_quantity = stock_quantity - ? WHERE id = ? AND stock_quantity >= ?`).
