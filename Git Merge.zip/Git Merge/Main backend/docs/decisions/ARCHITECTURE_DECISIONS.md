# Architecture Decisions (Phase 0 Baseline & Pre-Phase 1 Locks)

This document captures the foundational and pre-Phase 1 architectural decisions governing the **YOUR CHOICE** codebase.

---

## ADR-001: Modular Monolith in a `pnpm` Workspace

- **Decision:** Organize the platform as a TypeScript `pnpm` workspace containing independent `apps/web` and `apps/api` applications, shared packages under `packages/*`, and a dedicated `database/` workspace package (`@your-choice/database`).
- **Rationale:** Enables shared compile-time contracts (`@your-choice/shared-types`, `@your-choice/validation`, `@your-choice/shared-utils`) while preserving clear domain boundaries inside `apps/api/src/modules/*` and preventing microservice overhead before domain scale justifies extraction.
- **Boundary Rule:** `@your-choice/web` may import only browser-safe workspace packages (`shared-types`, `validation`, `shared-utils`, `ui`) and must never import `@your-choice/database`, `mysql2`, `express`, or `pino`.

## ADR-002: Express 5 + Zod + Pino API Baseline

- **Decision:** Standardize backend HTTP handling on Express `5.3.0`, Zod `v4` environment and request validation, and `pino` + `pino-http` structured JSON logging with `x-request-id` correlation.
- **Rationale:** Express 5 forwards rejected async route promises directly to the centralized error middleware (`error-handler.ts`), eliminating manual `try/catch` boilerplate while guaranteeing sanitized responses without secret leakage.

## ADR-003: MariaDB 10.11+ via `mysql2` and Drizzle ORM

- **Decision:** Connect to MariaDB `10.11+` using `drizzle-orm/mysql2`, `mysql2` (**MIT** license), and `drizzle-kit` configured with `dialect: 'mysql'`, explicit `charset: 'utf8mb4'`, and `timezone: 'Z'`. Timestamp columns use `DATETIME(3)` with `CURRENT_TIMESTAMP(3)` UTC precision.
- **Rationale:** Avoids LGPL-2.1 obligations of `mariadb-connector-nodejs` while matching Drizzle ORM's tested MariaDB dialect path. A single `system_settings` table (`0000_living_toro.sql`) establishes live migration mechanics cleanly before Phase 1 tables.
- **Non-Blocking Startup Probe:** Initial `pingDatabase()` runs inside `app.listen()` with `connectTimeout: 2000` so `/api/health` (`healthy` / `degraded`) and `/api/health/live` respond immediately even if MariaDB is restarting.

## ADR-004: Tailwind CSS v4 Workspace Scanning & Design Token Architecture

- **Decision:** Use Tailwind CSS v4 (`@tailwindcss/vite`) with raw hex values centralized once in [apps/web/src/styles/tokens.css](../../apps/web/src/styles/tokens.css), mapped into Tailwind `@theme` variables in [apps/web/src/index.css](../../apps/web/src/index.css), and `@source '../../../packages/ui/src';` workspace scanning.
- **Rationale:** Prevents Tailwind v4 from missing utility classes inside `@your-choice/ui`, maintains a single source of truth for **Royal Blue / Electric Blue / Cyan / Obsidian Black / Charcoal / Silver** brand tokens, enforces `overflow-x: clip`, `clamp()` font scaling, and `>= 4.5:1` WCAG AA contrast.

## ADR-005: Exact `BigInt` Minor-Unit Currency Handling

- **Decision:** Represent runtime currency arithmetic in [packages/shared-utils/src/money.ts](../../packages/shared-utils/src/money.ts) using integer minor units (`paisa` for `BDT`) and `BigInt` helpers instead of IEEE-754 floating-point math.
- **Rationale:** Eliminates rounding drift in cart subtotals, tax/shipping totals, checkout validation, and append-only creator reward ledgers.

## ADR-006: Dual-Mode Design Studio Domain Separation (Phases 2–3)

- **Decision:** Support both **Mode A (2D Fabric.js v7)** and **Mode B (3D Three.js + R3F v9)** inside Phases 2–3, backed by one normalized `[0..1]` `CanonicalDesignDocument` and server-side `Sharp` `300 DPI` transparent PNG export.
- **Rationale:** Decouples persisted domain artwork and private assets from ephemeral Fabric/Three.js internals and maps 3D textures via `THREE.CanvasTexture` over distortion-controlled flat UV print islands rather than `DecalGeometry` chest projections.

## ADR-007: Hybrid SSR Boundaries & Server-Side IP Protection Authority

- **Decision:** Keep all business authority (pricing, commissions, payment verification, moderation, `300 DPI` exports, signed asset delivery) strictly inside `apps/api`; evaluate `@react-router/express` SSR in Phase 7 strictly for public catalog/SEO routes while keeping Mode A/B studios isolated as `<ClientOnly>` lazy client chunks.
- **Rationale:** Browser assets (HTML, textures, `.glb`) can always be inspected client-side; real IP protection keeps unwatermarked creator masters and `300 DPI` print files exclusively in private server storage (`private/print-masters/`).

## ADR-008: Official Brand Identity Alignment (Implemented in Phase A/B & Prompt 04A)

- **Decision:** Preserve [your-choice-logo.png](../../apps/web/public/brand/your-choice-logo.png) (`1024x1024`, `1:1` proportions, never redrawn/cropped) across header, mobile drawer, footer, and favicon, paired with contrast-verified **Royal Blue / Electric Blue / Cyan / Black / Charcoal / Silver** tokens.
- **Status:** Implemented and verified in `SiteHeader`, `MobileNavDrawer`, `SiteFooter`, `DesignSystemPage`, `@your-choice/ui` (15 primitives), and `e2e/design-system.spec.ts`. `/design-system` remains temporarily reachable during foundation work and will be dev/admin-gated prior to Phase 1 public storefront navigation rollout.

---

## Pre-Phase 1 Locked Architectural Decisions (`ADR-009`..`ADR-014`)

## ADR-009: Hybrid Internal Primary Keys + Public Identifiers

- **Decision:** Use `BIGINT UNSIGNED AUTO_INCREMENT` primary keys and foreign keys internally across domain tables, paired with non-guessable `public_id` (`CHAR(36)` UUID) columns on user-scoped/operational entities (`users`, `user_addresses`, `designs`, `design_assets`, `orders`, `payouts`), SEO `slug` identifiers (`products`, `categories`, `marketplace_listings`, `creators`), and formatted `order_number` (`YC-YYYYMMDD-XXXXXX`).
- **Trade-offs & Rationale:** Internal `BIGINT` PKs keep MariaDB InnoDB clustered indexes and multi-table join indexes compact and fast, avoiding UUID random B-tree page-splitting overhead on writes, while exposing only `public_id` / `slug` / `order_number` externally eliminates sequential ID enumeration and complements strict session ownership checks.

## ADR-010: Single-Currency `BDT` MVP with Multi-Currency-Ready Schema

- **Decision:** Operate MVP commerce, pricing, payments, and creator rewards in **`BDT`**, while storing all monetary columns as `DECIMAL(12, 2)` (rates as `DECIMAL(5, 2)`) alongside an explicit `currency_code CHAR(3) NOT NULL DEFAULT 'BDT'` column on prices, carts, orders, payments, reward rules, and ledger entries.
- **Trade-offs & Rationale:** Avoids premature FX complexity and gateway settlement ambiguity for Bangladesh (`bKash`, `Nagad`, `SSLCommerz`, `COD`) while avoiding destructive column additions if multi-currency pricing or per-order locked FX rates are enabled later. Never use `FLOAT` or `DOUBLE`.

## ADR-011: Selective Soft Deletion, `ON DELETE RESTRICT` & Historical Immutability

- **Decision:** Add `deleted_at DATETIME(3) NULL` only to mutable catalog/identity entities (`users`, `user_addresses`, `product_categories`, `products`, `product_variants`, `designs`, `creator_profiles`, `marketplace_listings`). **Never** soft-delete or mutate commercial/financial/audit records (`orders`, `order_items`, `order_designs`, `payment_transactions`, `creator_reward_ledger`, `audit_logs`); bind foreign keys on referenced catalog/user tables with `ON DELETE RESTRICT`.
- **Identifier Reuse Rule:** Soft-deleted `products.slug` and `marketplace_listings.slug` remain reserved (`deleted` suffix/tombstone only on explicit admin archive) so old links and invoices never resolve to unrelated items. Soft-deleted user accounts anonymize PII cleanly if requested rather than permitting ambiguous email reuse.

## ADR-012: Local & Containerized MariaDB Development Strategy

- **Decision:** Treat Docker Compose MariaDB `10.11` ([docker-compose.mariadb.yml](../../infrastructure/docker/docker-compose.mariadb.yml)) and native Windows MariaDB `10.11+` identically through `.env` (`DB_*` or `DATABASE_URL`). Keep `apps/api` startup resilient when MariaDB is temporarily unreachable (`/api/health` returns `degraded`; `/api/health/ready` returns `503`), while enforcing live `pnpm db:migrate && pnpm db:seed` execution as an explicit **Phase 1 start gate**.
- **Rationale:** Zero vendor lock-in between Docker and native DB installs; never substitute SQLite or PostgreSQL for local dev because Drizzle dialects, `DATETIME(3)`, JSON columns, and `ON DUPLICATE KEY UPDATE` must be tested on real MariaDB 10.11+.

## ADR-013: Private Asset Storage Strategy (`local` -> `S3/MinIO` Port)

- **Decision:** Route all file storage through a backend `StorageService` interface supporting `STORAGE_DRIVER=local` (for local development outside `apps/web/public/` under gitignored `./storage/`) and `STORAGE_DRIVER=s3` (`@aws-sdk/client-s3` + `@aws-sdk/s3-request-presigner` targeting MinIO, Cloudflare R2, or AWS S3). Maintain identical prefix separation (`public/catalog/`, `public/garments-3d/`, `private/uploads/`, `private/creator-masters/`, `private/print-masters/`).
- **Rationale:** Allows frictionless local uploads in Phase 1–2 without requiring S3 credentials on day one while guaranteeing `private/*` files are never placed inside static `public/` directories and require authenticated signed tokens/URLs (`60–120s` upload, `120–300s` read).

## ADR-014: Preserved UI Foundation, Motion Discipline & Visual Reference Balance

- **Decision:** Keep `@your-choice/ui` (Radix Primitives + CVA + Tailwind CSS v4) as the single UI primitive package and `MotionProvider` (`LazyMotion strict` + `MotionConfig reducedMotion="user"`) as the animation architecture. Preserve the reconciled light-first storefront canvas (`#f8fafc` / `#ffffff`) balanced with obsidian/charcoal tech bands (`#06080d` / `#111622`) and **Royal Blue / Electric Blue / Cyan / Silver** tokens.
- **Rationale:** Translates the editorial visual cadence, quick-view responsiveness, and tactile apparel polish inspired by `https://business.azryno.com/Orvante/` into YOUR CHOICE's distinctive futuristic apparel-tech identity without discarding verified Phase A/B accessibility & bundle optimizations (`index` chunk `~69 kB`).
