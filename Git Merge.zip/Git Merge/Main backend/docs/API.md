# REST API Specification

> **Base Prefix:** `/api/v1`  
> **Content Type:** `application/json`  
> **Validation:** Zod (`@your-choice/validation`)

---

## 1. Standard Response Envelope

All API endpoints return a consistent JSON structure with a correlation `requestId`:

### Success Envelope

```json
{
  "success": true,
  "data": {},
  "meta": {
    "requestId": "req_...",
    "timestamp": "2026-11-15T10:45:00.000Z"
  }
}
```

### Error Envelope

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Request validation failed",
    "details": []
  },
  "meta": {
    "requestId": "req_...",
    "timestamp": "2026-11-15T10:45:00.000Z"
  }
}
```

---

## 2. Phase 0 Endpoints

| Method | Path                   | Purpose                                          | Status Codes                                   |
| :----- | :--------------------- | :----------------------------------------------- | :--------------------------------------------- |
| `GET`  | `/api/v1/health`       | Full service + MariaDB connectivity health check | `200` (healthy), `503` (degraded/unhealthy DB) |
| `GET`  | `/api/v1/health/live`  | Process liveness probe (no DB check)             | `200`                                          |
| `GET`  | `/api/v1/health/ready` | Readiness probe verifying DB connectivity        | `200` (ready), `503` (not ready)               |

---

## 3. Planned Route Groups (Phases 1–6)

> **Phase 1 Detailed Contracts:** Full endpoint table, request/response rules, custom MariaDB cookie-session auth (`HttpOnly`, `SameSite=Lax`, CSRF protection), and Zod validation boundaries for Identity, Catalog, Cart, and Orders live in [`PHASE_1_ARCHITECTURE.md`](architecture/PHASE_1_ARCHITECTURE.md).

- `/api/v1/auth` — Registration, login, logout, current session, verification, password reset (`ADR-003` + custom MariaDB sessions)
- `/api/v1/users` — Profile, address book, role upgrades
- `/api/v1/products`, `/api/v1/categories` — Catalog, variants, print areas
- `/api/v1/designs` — Native Design Studio drafts, versions, submissions, print exports
- `/api/v1/marketplace`, `/api/v1/creators` — Public listings, creator profiles, earnings, payout requests
- `/api/v1/cart`, `/api/v1/checkout`, `/api/v1/orders`, `/api/v1/payments` — Commerce & verified payment gateways
- `/api/v1/rewards`, `/api/v1/production`, `/api/v1/inventory`, `/api/v1/shipping` — Fulfillment & creator ledger
- `/api/v1/admin` — Moderation, payouts, settings, reports, audit logs
