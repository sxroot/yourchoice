# YOUR CHOICE — UI/UX Live Experience Reference Analysis

> **Reference Studied:** `https://business.azryno.com/Orvante/` (`Orvante — Clothing`, portfolio showcase by Azryno)  
> **Inspection Method:** Live headless Chromium inspection via `@playwright/test` (v2026 local Playwright Chromium `1255`) across 5 viewports after Chrome DevTools remote-debugging (`DevToolsActivePort`) was unavailable on host.  
> **Scope & Guardrail:** Research and experience analysis ONLY. **Zero source code, copy, imagery, illustrations, or layouts are copied.** Observed facts are strictly separated from YOUR CHOICE architectural recommendations.

---

## 1. Inspection Coverage & Limitations

### 1.1 Inspection Conditions

- **HTTP Status / Final URL:** `200 OK` -> `https://business.azryno.com/Orvante/`
- **Runtime Errors:** `0` uncaught `pageerror` exceptions observed.
- **Viewports Inspected:**
  - Desktop: `1440 × 900`
  - Laptop: `1280 × 800`
  - Tablet: `768 × 1024`
  - Mobile: `390 × 844`
  - Small Mobile: `360 × 800`
- **Limitations / Unverified Observations:**
  - The Chrome DevTools `browser` subagent could not attach because `DevToolsActivePort` was not active on host Chrome; live browser inspection was performed via Playwright Chromium instead.
  - Because `window.gsap`, `window.ScrollTrigger`, `window.Lenis`, `window.THREE`, and `window.lottie` were all `false`, animations are implemented in custom modular vanilla scripts (`main.js`, `shop.js`, `footer.js`, `tunnel.js`, `loader.js`, `gallery.js`); exact internal JS easing curve equations inside minified/custom canvas loops (`tunnel.js`, `footer.js`) that are not exposed on CSS `getComputedStyle` are marked **`UNVERIFIED`** rather than guessed.
  - Clicking `ORVANTE` floating pill and clicking a product card (`Column Dress`) were both tested live; `Column Dress` opened an interactive quick-view modal, while the exact hover state of every individual hanger on the 10-item horizontal clothing rail was inspected visually rather than scrubbed pointer-by-pointer.

---

## 2. Observed Desktop & Laptop Experience (`1440×900` & `1280×800`)

### 2.1 Initial Page Loading & Typography

- **Load Timing (`1440×900`):** `domcontentloaded` measured **`5,078 ms`**, `networkidle` measured **`7,097 ms`**. At `+150 ms`, body text length was already `4,000` chars with `17` active Web Animations running (`hasPreloaderLike: false`).
- **Palette & Surfaces:** Strictly monochrome alternating bands — light stone-gray (`rgb(218, 218, 218)`), near-black (`rgb(12, 12, 12)` / `rgb(5, 5, 5)` / `rgb(0, 0, 0)`), and charcoal footer (`rgb(16, 15, 14)`), paired with off-white ink (`rgb(244, 244, 244)`).
- **Typography Scale:**
  - Display `h1` (`PURE DESIGN`): `Archivo`, `90px / 77.4px` (`weight 640`) at `1440px`; `80px` at `1280px`.
  - Body text: `"Inter Tight", "Avenir Next", "Segoe UI", sans-serif`, `14px / 19.6px` at `1440px`.
- **Total Page Height:** `16,999 px` at `1440×900` (`15,214 px` at `1280×800`), `0 px` horizontal overflow.

### 2.2 Navigation & Persistent Controls

- **Top Header (`relative`, height `938 px` hero-wrapper):**
  - Top-left floating white pill bar containing 5 items (`Home` active black pill, `Arrivals`, `Shop`, `Shoes`, `Studio`) with `transition: color 0.3s`.
  - Top-right schedule/status pill (`Sunday 17.06 – 27 June 2026`) and dark `Contact Us ↗` pill (`transition: transform 0.25s`).
  - **Scroll Behavior:** Because the top header is `position: relative`, it scrolls off-screen immediately (`headerTop: -3740` at `3740px` scroll), leaving only a **fixed bottom-right circular Bag FAB** with item count badge (`0`).
- **Mid-Hero Brand Pill:** Centered dark glass bar (`ORVANTE` + minimal `=` trigger) overlaid across the hero portrait, anchored above a dark glass ticker pill (`Lumon · Paperfold · Northwind`).

### 2.3 Section-by-Section Walkthrough (Desktop `1440×900`)

1. **Hero (`y: 0–938`):** Asymmetric 3-zone composition on `#DADADA`: left editorial headline + `(ABOUT)` pill + `Book A Call ↗` + bottom-left dual dark bento trust widget (`400+ Trusted Partner` + `230+ Projects`); center grayscale editorial portrait; right status pills (`True Growth`, `We're available • for you`) + media preview card (`Out Now Q Industrial [2025]`).
2. **3D Corridor (`"Into the cut."`, `y: 938`, height `2,520 px`, `#0C0C0C`):** Dotted dark canvas with concentric dashed rings and CSS 3D-perspective floating garment cards (`matrix3d` with negative `translateZ` depth, e.g., `-1685.6px`) responding to scroll progress and subtle Z-shift on hover.
3. **New Arrivals & Brand Grid (`#arrivals`, `y: 3458`, `#DADADA`):** 4-column studio garment cards (`Night Coat`, `Column Dress`, `Atelier Overcoat`, `Wide Trouser`) with sold-out and strikethrough sale prices, followed by a 5-card `Shop by brand` strip.
4. **Sticky Lookbook (`#featured`, `y: 4605`, height `5,454 px`, `#000000`):** Full-bleed editorial photography with a horizontal translucent frosted band (`Featured | Dossier 09 | Explore`).
5. **Dark-Mode Storefront (`#shop` "The rack", `y: 10059`, height `2,552 px`, `#000000`):** Left facet filter column (Category checkboxes + counts, dual-handle `$0–$800` Price range slider, Colour swatches, `In stock only` toggle, Rating radios) alongside a 3-column product grid with `-17%` / `-19%` discount badges and `Bag 0` + `Featured` sort bar.
   - **Product Quick-View Modal:** Clicking a product (`Column Dress`) opens a split modal: left white photo stage with circular `<` / `>` image navigation buttons; right dark spec panel (`Neck`, `Cloth`, `Length`), circular pill Size selector (`XS–XL`), `- 1 +` quantity stepper, payment badges, and `Add to bag` / `Buy now` buttons.
6. **Interactive Clothing Rail (`y: 12611`, height `636 px`, `#DADADA`):** `"A clothing rail you can handle, right on the page."` Horizontal metallic bar displaying 10 hanging garments on wooden hangers with angled price tags (`$48`–`$96`) and active selection caption (`Knit cardigan · Olive · $96`).
7. **Footwear Grid (`#shoes`, `y: 13248`, height `1,146 px`, `#050505`):** 4×2 dark-studio shoe cards (`Track Runner`, `Court Low`, `High Court`, `Mesh Pace`).
8. **Manifesto & Partners (`#studio` & `#works`, `y: 14505`, `#000000`):** Centered editorial philosophy quote followed by `"Growing Business"` horizontal/bento metric cards (`54M+ Global Collaborations`, `Best Growth Partner 2026`).
9. **Interactive Canvas Footer (`#contact`, `y: 16099`, height `900 px`, `#100F0E`):**
   - **Dithered Portrait Transition (`canvas.whf-dither`, `1440×560`):** Pixel-dithered wave dissolving from the gray portrait into charcoal.
   - **Subtle Grain Layer (`canvas.whf-grain`, `1440×900`):** Full-bleed procedural surface grain.
   - **Interactive Pixel Wordmark (`canvas.whf-word`, `1240×300`):** Grid-indexed (`A1`–`F6`) block-pixel wordmark reacting to pointer hover and click ("Move across the sheet. Click it and a scan line runs down"), framed by rotated side metadata, 4 link columns (`SHOP`, `STUDIO`, `HOUSE`, `VISIT`), and `↑ BACK TO TOP`.

---

## 3. Observed Tablet & Mobile Experience (`768×1024`, `390×844`, `360×800`)

| Viewport                     | `scrollWidth / innerWidth` | Horizontal Overflow | Total Height | `h1` Font Size |  `body` Font Size   | Key Observation                                                                               |
| :--------------------------- | :------------------------: | :-----------------: | :----------: | :------------: | :-----------------: | :-------------------------------------------------------------------------------------------- |
| **Desktop (`1440×900`)**     |       `1440 / 1440`        |       `0 px`        | `16,999 px`  |    `90 px`     |       `14 px`       | Balanced 3-zone editorial hero                                                                |
| **Laptop (`1280×800`)**      |       `1280 / 1280`        |       `0 px`        | `15,214 px`  |    `80 px`     |     `12.44 px`      | Linear `vw` scaling already drops body below `14 px`                                          |
| **Tablet (`768×1024`)**      |        `768 / 768`         |       `0 px`        | `14,574 px`  |    `48 px`     | **`7.47 px` (BUG)** | **Critical readability defect:** un-clamped `vw` root scaling shrinks body text to `7.47 px`! |
| **Mobile (`390×844`)**       |        `390 / 390`         |       `0 px`        | `18,034 px`  |   `68.25 px`   |       `14 px`       | Dedicated mobile breakpoint restores `14 px` body; stacked hero + bento cards                 |
| **Small Mobile (`360×800`)** |        `360 / 360`         |       `0 px`        | `17,038 px`  |    `63 px`     |     `12.92 px`      | Slightly below `14 px` again due to `vw` scaling; `0 px` overflow                             |

### Mobile (`390×844`) Specific Observations

- **Header Reflow:** Top pill bar (`Home | Arrivals | Shop | Shoes | Studio`) stays horizontal alongside a circular `↗` button; date pill stacks neatly below.
- **Hero Reflow:** Display title, `('25)` badge, `(ABOUT)` pill, `Book A Call ↗` CTA, and centered portrait + `ORVANTE =` bar stack vertically above the bento trust cards (`400+` / `230+`) and `Q Industrial` preview card.
- **Bag Modal:** Clicking the floating bottom-right Bag FAB opens a centered dark translucent modal (`BAG / Your bag is empty.`) with a large `44px+` `×` close button.

---

## 4. Interaction Inventory (Observed Facts)

|  #  | Component / Section                                | Trigger                                         | Visual Behavior                                                                   | Animation Type                                    | Duration (Measured / Est.)                               | Easing                                     | Purpose                                         | Desktop Behavior                     | Mobile (`390×844`)                                        | Performance / UX Note                                                 |
| :-: | :------------------------------------------------- | :---------------------------------------------- | :-------------------------------------------------------------------------------- | :------------------------------------------------ | :------------------------------------------------------- | :----------------------------------------- | :---------------------------------------------- | :----------------------------------- | :-------------------------------------------------------- | :-------------------------------------------------------------------- |
|  1  | **Top Nav Links**                                  | Hover / Click                                   | Text color & active pill switch                                                   | CSS `color` transition                            | `0.3s` (`300ms`)                                         | CSS default `ease`                         | Section anchoring (`#arrivals`, `#shop`, etc.)  | Horizontal pill bar top-left         | Compact horizontal pill bar                               | Smooth, low-cost                                                      |
|  2  | **CTA Pill Buttons** (`Contact Us`, `Book A Call`) | Hover / Click                                   | Subtle scale/translate feedback                                                   | CSS `transform`                                   | `0.25s` (`250ms`)                                        | CSS default `ease`                         | Emphasize primary conversion action             | Hover micro-lift                     | Tap active state                                          | GPU-composited (`transform`)                                          |
|  3  | **Footer Text Links**                              | Hover                                           | Background underline sweep + opacity fade                                         | CSS `opacity` + `background-size`                 | `0.25s` + `0.35s`                                        | `cubic-bezier(0.65, 0, 0.2, 1)`            | Tactile editorial link polish                   | Underline expands horizontally       | Tap only                                                  | `background-size` causes minor paint; prefer `scaleX`                 |
|  4  | **Bag FAB & Modal**                                | Click                                           | Opens centered dark blurred bag overlay                                           | Overlay fade + card scale (`UNVERIFIED` exact ms) | `~200–300ms` (visual)                                    | `ease-out` (`UNVERIFIED` exact curve)      | Persistent cart access without header           | Fixed bottom-right circle w/ badge   | Same fixed FAB, centered card                             | Great pattern; add `Esc` + focus trap                                 |
|  5  | **3D Corridor (`Into the cut.`)**                  | Scroll + Hover                                  | Cards travel along Z-axis (`matrix3d`, `-1685.6px` -> `-1700px` on hover)         | Scroll-linked CSS 3D `transform`                  | Continuous scroll-scrubbed (`tunnel.js`)                 | Linear scroll scrub (`UNVERIFIED` damping) | Immersive collection depth storytelling         | Full-screen orbital corridor         | Stacked / lighter depth (`UNVERIFIED` exact mobile scrub) | Deep negative `translateZ` can flicker or look empty mid-scroll       |
|  6  | **Sticky Lookbook (`Dossier 09`)**                 | Scroll                                          | Translucent bar holds across tall portraits                                       | `position: sticky` + scroll progression           | Continuous                                               | Native scroll                              | Editorial lookbook pacing                       | Full-bleed vertical scroll           | Full-bleed vertical                                       | Zero JS overhead when pure CSS `sticky`                               |
|  7  | **Shop Facet Filters**                             | Click / Drag                                    | Live grid filtering (category, price, color, stock, rating)                       | Instant DOM re-filter + slider drag               | Immediate                                                | N/A                                        | Fast multi-attribute catalog narrowing          | Sticky left sidebar                  | Collapsible/stacked (`UNVERIFIED` drawer)                 | High conversion utility; fix contrast                                 |
|  8  | **Product Card -> Quick-View Modal**               | Click                                           | Opens split-pane image carousel + spec table + Size pills                         | Modal open + `<` / `>` slide switch               | `~200–300ms` (`UNVERIFIED` exact ms)                     | `UNVERIFIED`                               | Inspect details & add to bag without route jump | Split 2-column modal                 | Vertical stacked modal                                    | Needs URL sync for shareable PDP links                                |
|  9  | **Interactive Clothing Rail**                      | Hover / Click / Drag (`UNVERIFIED` touch swipe) | 10 garments hang on rod; active item highlights + updates price/label             | Horizontal rail item focus + tag tilt             | `UNVERIFIED` exact ms                                    | `UNVERIFIED`                               | Tactile browsing of capsule drop                | Horizontal 10-piece rail             | Compact / stacked                                         | Several garments look too thin/clipped edge-on                        |
| 10  | **Manifesto & Section Reveals**                    | Scroll (IntersectionObserver)                   | Sections fade from `opacity: 0` to `opacity: 1`                                   | Opacity reveal                                    | `UNVERIFIED` exact ms                                    | `UNVERIFIED`                               | Paced narrative reveals                         | Reveals as viewport enters           | Same                                                      | **Bug observed:** sections `#7/#8` stayed `opacity: 0` on jump-scroll |
| 11  | **Footer Pixel Dither & Wordmark**                 | Scroll + Pointer Move + Click                   | Dissolving dither wave (`whf-dither`) + interactive pixel brand grid (`whf-word`) | HTML5 `<canvas>` 2D procedural loop               | `60fps` RAF while in viewport (`UNVERIFIED` pause logic) | Procedural physics (`UNVERIFIED`)          | Memorable signature brand craft                 | Interactive cursor ripple + scanline | Touch tap/drag                                            | Heavy if active off-screen; gate with IntersectionObserver            |

---

## 5. Strengths vs. Critical Defects Found on Reference

### What Works Exceptionally Well (Adapt Conceptually for YOUR CHOICE)

1. **High-Contrast Editorial Pacing:** Alternating light gallery sections and deep dark studio bands makes apparel silhouettes and studio details pop.
2. **Modular Pill & Bento Information Architecture:** Scannable pill tags (`(ABOUT)`, `('25)`) and compact 2-column bento proof cards (`400+` / `230+`) communicate trust quickly without prose walls.
3. **Interactive Product Quick-View + Inline Facet Filters:** Frictionless size/variant inspection right inside the shopping flow.
4. **Tactile Apparel Metaphor (Clothing Rail Concept):** Physically grounded browsing metaphor that fits custom apparel naturally.
5. **Signature Canvas Brand Moment in Footer:** Placing creative canvas delight in the footer (not blocking above-the-fold conversion) creates a memorable closing impression.

### Real Usability & Engineering Defects Observed (Must NOT Repeat)

1. **Unclamped `vw` Font Scaling Breaks Tablet (`7.47 px` body at `768px`):** Always use CSS `clamp()` with a hard `14px`–`16px` body floor.
2. **WCAG Contrast Failures on `#000000` Shop Cards:** Dark gray subtitles (`Ships in 2–4 days`, rating counts) on pure black are nearly illegible. YOUR CHOICE must enforce `>= 4.5:1` contrast (use `#11161F` / `#181F2C` charcoal surfaces with `#B8C4D9` silver-slate secondary text).
3. **Scroll-Jump `opacity: 0` Trap:** Jumping via anchor links or fast scrolling left intermediate sections invisible (`opacity: 0`). Never hide core content at `opacity: 0` without immediate fallback visibility and `viewport={{ once: true }}` / anchor-safe reveals.
4. **Slow Cold Load (`7.1s`):** Large hero media & 3 canvases delay `networkidle`. Lazy-load below-the-fold media and canvas effects.
5. **No Sticky Navigation Bar:** Top nav disappears immediately on scroll, hurting multi-page eCommerce navigation (`Shop`, `Design Studio`, `Marketplace`, `Cart`, `Account`).
6. **Overlapping Floating Element (`Growing Business`):** Floating `::` icon collided directly with headline text.
7. **Clipped / Edge-On Rail Silhouettes:** Some garments on the rail were invisible/edge-on until hovered, hiding product identity.

---

## 6. Original YOUR CHOICE Adaptation Summary

YOUR CHOICE is **not** a monochrome luxury couture house—it is a **futuristic creative-technology custom apparel & creator marketplace** (`Royal Blue`, `Electric Blue`, `Cyan`, `Black`, `Charcoal`, `Silver`, `White` + wing-shaped tech monogram in [your-choice-logo.png](file:///d:/Antigravity/Your%20Choice/apps/web/public/brand/your-choice-logo.png)).

- **Adopt the craft:** Expressive dark/light contrast cadence, crisp bento proof cards, live facet sidebar + slide-over/quick-view flows, tactile apparel preview transitions, and an optional subtle tech-grid/scanline canvas signature in the hero/footer.
- **Upgrade the usability:** Sticky accessible top navigation with <=6 links, `clamp()` typography (`>= 16px` mobile inputs), guaranteed `>= 4.5:1` silver-on-charcoal contrast, dual primary storefront paths (**Customize a Blank** vs **Shop Creator Drops**), and zero scroll-blocking animations inside the Fabric.js Design Studio.
