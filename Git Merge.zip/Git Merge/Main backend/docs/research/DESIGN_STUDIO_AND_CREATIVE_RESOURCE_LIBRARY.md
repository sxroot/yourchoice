# YOUR CHOICE — Master Design Studio & Creative Resource Library

> **Scope:** Phase 2–8 Creative Technology, 2D/3D Graphics, Animation, Asset, Mockup, Font, and Template Research Catalogue  
> **Project:** **YOUR CHOICE** (`allyourchoice.com`) — _Design it. Wear it. Earn from it._  
> **Research Date:** November 2026  
> **Rule:** Every repository, URL, license, release, and metric listed below was verified during live research; any metric not directly verified is explicitly labeled **`UNVERIFIED`**. Do not install any library from this catalog until its corresponding implementation phase is approved.

---

## Evaluation Methodology & Scoring Formula

Serious technical candidates are scored on a `1–10` scale using the mandatory weighted formula:

$$\text{Weighted Score} = 0.15(\text{Maint}) + 0.15(\text{Sec}) + 0.15(\text{Compat}) + 0.10(\text{Doc}) + 0.15(\text{Cust}) + 0.10(\text{Perf}) + 0.15(\text{Lic}) + 0.05(\text{Comm})$$

| Criterion                            | Weight | Meaning for YOUR CHOICE                                                                    |
| :----------------------------------- | :----: | :----------------------------------------------------------------------------------------- |
| **Maintainability (`Maint`)**        |  15%   | Clean codebase, active commits, TypeScript types, sustainable upgrade path                 |
| **Security (`Sec`)**                 |  15%   | Clean dependency surface, safe browser/server execution, absence of risky runtime patterns |
| **Compatibility (`Compat`)**         |  15%   | Native fit with React 19, TypeScript, Vite, Tailwind CSS v4, Node.js, Express 5, Sharp     |
| **Documentation (`Doc`)**            |  10%   | Official guides, migration docs, TypeScript examples                                       |
| **Customization (`Cust`)**           |  15%   | Print-area constraints, custom controls, JSON schema ownership, headless rendering         |
| **Performance (`Perf`)**             |  10%   | Canvas frame rate, bundle size/lazy-loading, server memory footprint                       |
| **Commercial Licensing (`Lic`)**     |  15%   | Permissive commercial SaaS + customer preview generation without royalties or builder bans |
| **Community & Maintenance (`Comm`)** |   5%   | Ecosystem adoption, stars, issue resolution                                                |

> **Hard Policy Gate:** A high weighted score **never** overrides a restrictive license or serious security problem.

---

## 1. 2D Editor Repositories

### 1.1 Candidate Profiles

#### 1. `fabricjs/fabric.js` — **USE (Primary 2D Design Studio Engine)**

1. **Name:** Fabric.js (`fabric`)
2. **Direct GitHub URL:** `https://github.com/fabricjs/fabric.js`
3. **Official Documentation:** `https://fabricjs.com/`
4. **Main Purpose:** Interactive HTML5 `<canvas>` object model, SVG-to-canvas parser, JSON serialization, and Node.js headless rendering for custom 2D design editors.
5. **Technology Stack:** TypeScript (v6/v7 native TS rewrite), HTML5 Canvas 2D, optional Node.js `canvas` (`node-canvas`) backend (`fabric/node`).
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted for commercial SaaS, client customization tools, and server-side print exports; requires preserving MIT copyright notice.
8. **Latest Verifiable Release / Maintenance:** **v7.4.0** (v7 modular ESM rewrite active in 2026).
9. **Community Activity & Stars:** ~31.5k–31.6k GitHub stars.
10. **Advantages:** Built-in selection handles, rotation, scaling, grouping, multi-layer z-ordering, rich text (`Textbox` / `IText`), `clipPath` support for exact garment print-area boundaries, native `toJSON()`/`loadFromJSON()`, SVG export/import, and headless `StaticCanvas` in Node.js for 300 DPI print rendering.
11. **Limitations:** Imperative canvas API requires disciplined React lifecycle/ref isolation; large 300 DPI exports in Node consume significant RAM if `canvas.dispose()` is omitted; v7 introduces breaking changes from v5/v6 blog snippets.
12. **Compatibility with YOUR CHOICE:** **High** — aligns directly with `docs/DESIGN-STUDIO.md` (`React 19` lazy-loaded studio shell + Express/worker print pipeline).
13. **Integration Difficulty:** Medium (wrap imperative canvas instance inside a dedicated `features/design-studio` controller with Zustand/React state sync).
14. **Security or Dependency Concerns:** Server-side `node-canvas` relies on native Cairo/Pango binaries in Linux/Docker/Windows; sanitize SVG uploads and validate image magic bytes before loading into Fabric.
15. **Recommended Usage & Phase:** **USE** as primary 2D Design Studio canvas engine (**Phase 2–3**).

#### 2. `konvajs/konva` + `konvajs/react-konva` — **REFERENCE / BACKUP**

1. **Name:** Konva.js & React Konva
2. **Direct GitHub URL:** `https://github.com/konvajs/konva` | `https://github.com/konvajs/react-konva`
3. **Official Documentation:** `https://konvajs.org/`
4. **Main Purpose:** 2D scene-graph canvas framework with declarative React bindings (`<Stage>`, `<Layer>`, `<Transformer>`).
5. **Technology Stack:** TypeScript, HTML5 Canvas, React (`react-konva@19` specifically matches React 19.3+).
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted without fees or license keys.
8. **Latest Verifiable Release / Maintenance:** Core v9 / v10 ecosystem active; `react-konva` `v19.3.0+` verified for React 19 compatibility.
9. **Community Activity & Stars:** ~15k stars (`konvajs/konva`); `react-konva` stars `UNVERIFIED`.
10. **Advantages:** Superior idiomatic React declarative model (`react-konva@19`), fast multi-layer hit-graph performance, crisp `<Transformer>` resizing/snapping.
11. **Limitations:** Lacks Fabric.js's built-in interactive canvas text editing (`IText`/`Textbox` inline typing — requires DOM `<textarea>` overlay hacks), weaker built-in SVG import/export compared to Fabric, and no official Canva-like JSON schema standard without building one from scratch.
12. **Compatibility with YOUR CHOICE:** **High** (`react-konva@19` matches `react@^19.3.1`), though requires custom text-edit overlays and custom serialization.
13. **Integration Difficulty:** Medium.
14. **Security or Dependency Concerns:** Low in browser; Node rendering requires `konva` + `canvas` (`node-canvas`).
15. **Recommended Usage & Phase:** **REFERENCE / BACKUP** if Fabric.js v7 hits specific mobile performance bottlenecks (**Phase 2** evaluation backup).

#### 3. `ValentinH/react-easy-crop` — **USE (Customer Image Crop Modal)**

1. **Name:** react-easy-crop
2. **Direct GitHub URL:** `https://github.com/ValentinH/react-easy-crop`
3. **Official Documentation:** `https://valentinh.github.io/react-easy-crop/`
4. **Main Purpose:** Touch-friendly React component for pre-upload / asset-drawer image cropping, zooming, and rotation.
5. **Technology Stack:** React, TypeScript.
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** `v6.x` series actively maintained.
9. **Community Activity & Stars:** ~2.8k GitHub stars.
10. **Advantages:** Tiny bundle, effortless touch/pinch gestures on mobile, outputs exact pixel crop coordinates (`croppedAreaPixels`) so original uploaded assets remain **immutable** while Sharp/Canvas crops non-destructively.
11. **Limitations:** Crop/zoom/rotate only (not a multi-layer editor).
12. **Compatibility with YOUR CHOICE:** **High** (lightweight React component; verify React 19 peer range on install).
13. **Integration Difficulty:** Low.
14. **Security or Dependency Concerns:** Negligible.
15. **Recommended Usage & Phase:** **USE** for customer artwork/avatar cropping modal (**Phase 2–3**, optional Phase 1 avatar crop).

#### 4. `fengyuanchen/cropperjs` — **REFERENCE / ALTERNATIVE**

1. **Name:** Cropper.js
2. **Direct GitHub URL:** `https://github.com/fengyuanchen/cropperjs`
3. **Official Documentation:** `https://fengyuanchen.github.io/cropperjs/`
4. **Main Purpose:** Framework-agnostic web-component/JS image cropper with aspect-ratio locking and free-form selection.
5. **Technology Stack:** TypeScript, Web Components (v2.x).
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** **v2.3.1** (active v2.x branch).
9. **Community Activity & Stars:** ~13.9k GitHub stars.
10. **Advantages:** Mature, aspect-ratio locking for print-area ratios, Web Components architecture in v2.
11. **Limitations:** More imperative DOM integration in React than `react-easy-crop`.
12. **Compatibility with YOUR CHOICE:** Medium-High.
13. **Integration Difficulty:** Low–Medium.
14. **Security or Dependency Concerns:** Negligible.
15. **Recommended Usage & Phase:** **REFERENCE / ALTERNATIVE** if advanced free-edge crop handles are needed over `react-easy-crop` (**Phase 2**).

#### 5. `svgdotjs/svg.js` — **REFERENCE**

1. **Name:** SVG.js
2. **Direct GitHub URL:** `https://github.com/svgdotjs/svg.js`
3. **Official Documentation:** `https://svgjs.dev/`
4. **Main Purpose:** Lightweight programmatic SVG DOM manipulation and animation library.
5. **Technology Stack:** JavaScript/TypeScript.
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** **v3.2.8** (~August 2026).
9. **Community Activity & Stars:** ~11.9k GitHub stars.
10. **Advantages:** Clean SVG vector manipulation, small footprint.
11. **Limitations:** Not an interactive print-design editor (no built-in multi-select transformer, raster export pipeline, or print-DPI layer controls out of the box).
12. **Compatibility with YOUR CHOICE:** Medium.
13. **Integration Difficulty:** Medium–High for full editor UX.
14. **Security or Dependency Concerns:** Raw SVG rendering always requires strict XSS sanitization (DOMPurify) on user-uploaded SVGs.
15. **Recommended Usage & Phase:** **REFERENCE** only for lightweight SVG badge/utility tooling if needed (**Phase 2+**).

#### 6. `daybrush/moveable` — **REFERENCE**

1. **Name:** Moveable (`react-moveable`)
2. **Direct GitHub URL:** `https://github.com/daybrush/moveable`
3. **Official Documentation:** `https://daybrush.com/moveable/`
4. **Main Purpose:** DOM/SVG transform gizmos (drag, resize, scale, rotate, warp, snap, group).
5. **Technology Stack:** TypeScript, DOM/CSS transforms (`react-moveable`).
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** `v0.53.0+` active monorepo releases.
9. **Community Activity & Stars:** Popular monorepo; exact star count `UNVERIFIED`.
10. **Advantages:** Rich snapping, warp/pinch, CSS-DOM fidelity.
11. **Limitations:** Operates on DOM nodes rather than `<canvas>`; exporting DOM layouts to 300 DPI transparent print PNGs with pixel-exact parity is fragile across browsers/OS font renderers compared to Fabric.js + Node `StaticCanvas`.
12. **Compatibility with YOUR CHOICE:** Medium (React wrapper available, but mismatches canvas-to-print architecture).
13. **Integration Difficulty:** Medium–High.
14. **Security or Dependency Concerns:** Low.
15. **Recommended Usage & Phase:** **REFERENCE** for UI gizmo ergonomics; do not use as primary garment print canvas.

#### 7. `taye/interact.js` — **AVOID (for Design Studio)**

1. **Name:** interact.js
2. **Direct GitHub URL:** `https://github.com/taye/interact.js`
3. **Official Documentation:** `https://interactjs.io/`
4. **Main Purpose:** Low-level drag-and-drop, resize, and multi-touch gesture primitives with inertia.
5. **Technology Stack:** JavaScript/TypeScript.
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** **v1.10.28**.
9. **Community Activity & Stars:** ~12.9k GitHub stars.
10. **Advantages:** Rock-solid gesture math and snapping.
11. **Limitations:** Low-level interaction library only — lacks canvas rendering, rotation handles, text editing, serialization, and PNG export.
12. **Compatibility with YOUR CHOICE:** Low–Medium for apparel editor.
13. **Integration Difficulty:** High (must build entire editor around it).
14. **Security or Dependency Concerns:** Negligible.
15. **Recommended Usage & Phase:** **AVOID** for Design Studio (Fabric.js handles selection/drag/rotate natively).

#### 8. `excalidraw/excalidraw` — **AVOID (for Apparel Studio)**

1. **Name:** Excalidraw
2. **Direct GitHub URL:** `https://github.com/excalidraw/excalidraw`
3. **Official Documentation:** `https://docs.excalidraw.com/`
4. **Main Purpose:** Infinite-canvas hand-drawn collaborative whiteboard and diagramming app.
5. **Technology Stack:** React, TypeScript, Rough.js, HTML5 Canvas.
6. **License:** **MIT** (`@excalidraw/excalidraw` package).
7. **Commercial Usage Permission:** Permitted under MIT.
8. **Latest Verifiable Release / Maintenance:** Actively updated ESM releases.
9. **Community Activity & Stars:** ~135k–136k GitHub stars.
10. **Advantages:** Polished whiteboard UX, undo/redo, React integration.
11. **Limitations:** Aesthetic is hand-drawn sketchy diagrams on an infinite canvas — completely wrong mental model for constrained physical garment print zones (`12" x 16"`), custom streetwear typography, raster filters, and 300 DPI production PNGs.
12. **Compatibility with YOUR CHOICE:** Low for apparel POD.
13. **Integration Difficulty:** High to strip whiteboard assumptions.
14. **Security or Dependency Concerns:** Low.
15. **Recommended Usage & Phase:** **AVOID** for apparel Design Studio.

#### 9. `tldraw/tldraw` — **AVOID (Licensing Restriction)**

1. **Name:** tldraw SDK
2. **Direct GitHub URL:** `https://github.com/tldraw/tldraw`
3. **Official Documentation:** `https://tldraw.dev/`
4. **Main Purpose:** Infinite canvas / diagramming SDK for React.
5. **Technology Stack:** React, TypeScript, HTML/SVG/CSS canvas.
6. **License:** **Custom Source-Available (`tldraw SDK License`)** — NOT MIT/Apache.
7. **Commercial Usage Permission:** **RESTRICTED** — Free only for local/non-commercial use or with visible watermark; commercial production deployment **requires a paid commercial license key**.
8. **Latest Verifiable Release / Maintenance:** `v5.1.x+` active releases.
9. **Community Activity & Stars:** ~51.4k GitHub stars.
10. **Advantages:** Smooth infinite-canvas UX.
11. **Limitations:** Commercial license fee + infinite whiteboard model unsuitable for garment print zones.
12. **Compatibility with YOUR CHOICE:** **Fail (License Gate)**.
13. **Integration Difficulty:** Low technically, blocked legally.
14. **Security or Dependency Concerns:** License-key enforcement / telemetry check.
15. **Recommended Usage & Phase:** **AVOID**.

#### 10. `SVG-Edit/svgedit` — **REFERENCE ONLY**

1. **Name:** SVG-Edit
2. **Direct GitHub URL:** `https://github.com/SVG-Edit/svgedit`
3. **Official Documentation:** `https://svgedit.netlify.app/` (`UNVERIFIED` official standalone docs domain)
4. **Main Purpose:** Standalone browser SVG vector drawing editor.
5. **Technology Stack:** JavaScript, SVG DOM.
6. **License:** **MIT** (dual/MIT open-source; exact historical file header `UNVERIFIED` per version).
7. **Commercial Usage Permission:** Permitted.
8. **Latest Verifiable Release / Maintenance:** `v7.3.3` observed.
9. **Community Activity & Stars:** ~7.8k+ GitHub stars.
10. **Advantages:** Pure vector path tools.
11. **Limitations:** Legacy monolithic UI/architecture; poor fit for raster photo uploads, streetwear text styling, and React 19 Tailwind shell.
12. **Compatibility with YOUR CHOICE:** Low.
13. **Integration Difficulty:** High.
14. **Security or Dependency Concerns:** SVG script/XSS surface if user SVGs are not sanitized.
15. **Recommended Usage & Phase:** **REFERENCE ONLY** if vector pen/path tools are ever explored post-MVP.

#### 11. `pixijs/pixijs` — **AVOID (for 2D Print Editor)**

1. **Name:** PixiJS
2. **Direct GitHub URL:** `https://github.com/pixijs/pixijs`
3. **Official Documentation:** `https://pixijs.com/`
4. **Main Purpose:** High-FPS 2D WebGL/WebGPU sprite & shader rendering engine (games, effects).
5. **Technology Stack:** TypeScript, WebGL2 / WebGPU.
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** **v8.23.0** (November 2026).
9. **Community Activity & Stars:** ~48.7k GitHub stars.
10. **Advantages:** Blazing-fast GPU rendering and shader effects.
11. **Limitations:** Game renderer, not a graphic-design editor — no built-in selection gizmos, rich text input, SVG parser, or headless Node 300 DPI print pipeline.
12. **Compatibility with YOUR CHOICE:** Low for editor; could only assist specialized GPU filters.
13. **Integration Difficulty:** High.
14. **Security or Dependency Concerns:** WebGL context limits on mobile browsers.
15. **Recommended Usage & Phase:** **AVOID** for Design Studio.

#### 12. `lovell/sharp` — **USE (Server Print & Mockup Compositing Engine)**

1. **Name:** Sharp
2. **Direct GitHub URL:** `https://github.com/lovell/sharp`
3. **Official Documentation:** `https://sharp.pixelplumbing.com/`
4. **Main Purpose:** High-speed Node.js raster processing (`libvips`) for resizing, format conversion, metadata inspection, color/blend compositing, and 300 DPI PNG metadata tagging.
5. **Technology Stack:** Node.js, C++ (`libvips` prebuilt binaries).
6. **License:** **Apache-2.0**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** `v0.35.x` active releases.
9. **Community Activity & Stars:** ~32.7k+ GitHub stars.
10. **Advantages:** Orders-of-magnitude faster and lower-memory than pure JS image libs; reads uploaded image dimensions/DPI/ICC profiles; composites artwork onto 2D garment mockups using `multiply` / `overlay` blend modes; stamps exact `300` DPI density metadata onto production PNGs.
11. **Limitations:** Not a vector/font layout engine on its own (pair with Fabric `StaticCanvas` or SVG rasterization for text+layer flattening).
12. **Compatibility with YOUR CHOICE:** **Full** (already earmarked in `docs/DESIGN-STUDIO.md` for `apps/api`).
13. **Integration Difficulty:** Low.
14. **Security or Dependency Concerns:** Validate image dimensions/pixel limits (`limitInputPixels`) to prevent decompression-bomb DoS attacks on user uploads.
15. **Recommended Usage & Phase:** **USE** in `apps/api` for upload sanitization, thumbnail generation, 2D mockup compositing, and 300 DPI print-file finalization (**Phase 1–3**).

#### 13. `Agamnentzar/ag-psd` — **REFERENCE / BUILD-TIME TOOL**

1. **Name:** ag-psd
2. **Direct GitHub URL:** `https://github.com/Agamnentzar/ag-psd`
3. **Official Documentation:** `https://github.com/Agamnentzar/ag-psd#readme`
4. **Main Purpose:** Pure JS/TS Photoshop `.psd` parser and writer.
5. **Technology Stack:** TypeScript / JavaScript.
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** `v34.x` active updates.
9. **Community Activity & Stars:** ~740+ GitHub stars.
10. **Advantages:** Can inspect or extract layers/masks/shadows from downloaded `.psd` garment mockups cleanly into PNG layer assets (`base`, `shadow`, `highlight`, `print-mask`) during admin onboarding.
11. **Limitations:** Does **not** execute Photoshop Smart Object 3D/mesh warps or complex adjustment layers at runtime.
12. **Compatibility with YOUR CHOICE:** High as an offline/build-time conversion utility.
13. **Integration Difficulty:** Low–Medium.
14. **Security or Dependency Concerns:** Never accept arbitrary user-uploaded PSDs in production endpoints.
15. **Recommended Usage & Phase:** **REFERENCE / INTERNAL TOOL** for converting curated PSD mockups into layered PNG templates (**Phase 2–3**).

#### 14. Commercial SDKs to **AVOID** (`imgly/cesdk-js` & `Polotno`)

- **`imgly/cesdk-js`** (`https://github.com/imgly/cesdk-js`): Proprietary commercial product (`@cesdk/cesdk-js`), evaluation watermarks without paid license key. **AVOID**.
- **Polotno** (`https://polotno.com/`): Built on Konva, but core SDK is proprietary paid software (30-day trial, enterprise fee). **AVOID**.

### 1.2 Weighted Evaluation — 2D Graphic Design Editor

| Candidate                           | Maint (15%) | Sec (15%) | Compat (15%) | Doc (10%) | Cust (15%) | Perf (10%) | Lic (15%) | Comm (5%) | **Total** | Verdict                       |
| :---------------------------------- | :---------: | :-------: | :----------: | :-------: | :--------: | :--------: | :-------: | :-------: | :-------: | :---------------------------- |
| **`fabricjs/fabric.js` (v7)**       |      9      |     8     |      9       |     9     |     10     |     8      |    10     |     9     | **9.05**  | **USE (Primary)**             |
| **`lovell/sharp`**                  |      9      |     9     |      10      |     9     |     8      |     10     |    10     |     9     | **9.25**  | **USE (Server Print/Mockup)** |
| **`ValentinH/react-easy-crop`**     |      8      |     9     |      9       |     8     |     7      |     9      |    10     |     7     | **8.45**  | **USE (Crop Modal)**          |
| **`konvajs/konva` + `react-konva`** |      9      |     9     |      9       |     8     |     8      |     9      |    10     |     8     | **8.85**  | **REFERENCE / BACKUP**        |
| **`fengyuanchen/cropperjs`**        |      8      |     9     |      8       |     8     |     8      |     9      |    10     |     8     | **8.50**  | **REFERENCE**                 |
| **`daybrush/moveable`**             |      8      |     9     |      7       |     8     |     8      |     8      |    10     |     7     | **8.20**  | **REFERENCE**                 |
| **`svgdotjs/svg.js`**               |      8      |     8     |      7       |     8     |     7      |     8      |    10     |     8     | **7.95**  | **REFERENCE**                 |
| **`excalidraw/excalidraw`**         |      9      |     9     |      7       |     8     |     4      |     8      |    10     |    10     | **7.85**  | **AVOID (Wrong Domain)**      |
| **`tldraw/tldraw`**                 |      9      |     8     |      7       |     9     |     5      |     8      |   **1**   |     9     | **6.75**  | **AVOID (Paid Key Req.)**     |
| **Polotno / CE.SDK**                |      8      |     8     |      8       |     8     |     7      |     8      |   **1**   |     6     | **6.60**  | **AVOID (Proprietary)**       |

---

## 2. 3D Rendering Repositories

### 2.1 Critical Technical Finding: 3D Garment Artwork Mapping Reality

A generic 3D viewer (`<model-viewer>` or basic `GLTFLoader`) **cannot** automatically place customer artwork onto a T-shirt or Polo shirt accurately for print production. Two distinct techniques exist:

1. **UV-Mapped `THREE.CanvasTexture` (Recommended for Garment Customizers):**
   - The `.glb` garment mesh must be authored with **clean, non-overlapping UV islands** in `[0, 1]` UV space (dedicated islands for Front Chest, Back, Left/Right Sleeves).
   - The 2D Design Studio (Fabric.js) exports or renders the print-area canvas onto an offscreen UV texture canvas matching the garment's UV layout, assigns it as `material.map = new THREE.CanvasTexture(canvas)` (with `THREE.SRGBColorSpace` and `flipY = false` per glTF standard), and keeps fabric weave normal/roughness maps (`normalMap`, `roughnessMap`) intact.
   - Guarantees **1:1 alignment** between 2D print zones and 3D garment preview!
2. **`DecalGeometry` (`three/addons/geometries/DecalGeometry.js`):**
   - Projects a sticker/badge onto arbitrary mesh triangles via raycast position + normal orientation.
   - **Limitation on Apparel:** Folds, collar ribbing, sleeve seams, and steep curvature cause UV stretching and triangle clipping; decals do **not** map cleanly back to a flat `12" x 16"` rectangular DTF print file. Useful only for small chest crests/badges if a UV-mapped canvas isn't used.

### 2.2 Candidate Profiles

#### 1. `mrdoob/three.js` — **USE (Post-MVP 3D Core Engine)**

1. **Name:** Three.js
2. **Direct GitHub URL:** `https://github.com/mrdoob/three.js` (also mirrored locally at `C:/Users/ADMiN/.gemini/antigravity/three.js/`)
3. **Official Documentation:** `https://threejs.org/docs/`
4. **Main Purpose:** Industry-standard WebGL / WebGPU 3D scene graph, glTF/GLB loader, PBR `MeshStandardMaterial`, `CanvasTexture`, `DecalGeometry`, lighting, and shadows.
5. **Technology Stack:** JavaScript / TypeScript (`@types/three`), WebGL2, WebGPU/TSL.
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** **r187** (`0.187.0`, late October 2026).
9. **Community Activity & Stars:** ~118k+ GitHub stars.
10. **Advantages:** Complete control over UV `CanvasTexture` updates, PBR fabric roughness/normal maps, DRACO/Meshopt compressed `.glb` garment loading, studio HDRI lighting, and dynamic color tinting.
11. **Limitations:** Imperative 3D API; heavy bundle (~600KB+ minified; MUST be dynamically imported / route-split); requires custom-authored UV-clean `.glb` T-shirt & Polo models.
12. **Compatibility with YOUR CHOICE:** Full via React Three Fiber v9 when dynamically loaded.
13. **Integration Difficulty:** Medium–High (asset authoring of UV-unwrapped `.glb` garments is the primary bottleneck, not code).
14. **Security or Dependency Concerns:** WebGL GPU context loss on low-end mobile devices; dispose geometries/textures/renderers on unmount to prevent memory leaks.
15. **Recommended Usage & Phase:** **USE in Phase 3 (Mode B)** Dual-Mode 3D Garment Studio (lazy-loaded on mode switch / `View in 3D`).

#### 2. `pmndrs/react-three-fiber` (v9) + `pmndrs/drei` — **USE (Phase 3 Mode B React 3D Layer)**

1. **Name:** React Three Fiber (`@react-three/fiber`) & Drei (`@react-three/drei`)
2. **Direct GitHub URL:** `https://github.com/pmndrs/react-three-fiber` | `https://github.com/pmndrs/drei`
3. **Official Documentation:** `https://r3f.docs.pmndrs.org/` | `https://drei.docs.pmndrs.org/`
4. **Main Purpose:** Declarative React reconciler for Three.js (`v9` built specifically for React 19) + ready-made helpers (`OrbitControls`, `Environment`, `ContactShadows`, `useGLTF`, `Decal`).
5. **Technology Stack:** React 19 (`@react-three/fiber@^9`), TypeScript, Three.js.
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** `@react-three/fiber@9` active line; exact minor tag `UNVERIFIED`.
9. **Community Activity & Stars:** ~33.7k+ stars (`react-three-fiber`); ~10.2k+ stars (`drei`).
10. **Advantages:** Native React 19 StrictMode & JSX compatibility in v9, declarative state binding from Design Studio store, effortless OrbitControls / studio lighting presets via Drei.
11. **Limitations:** Must use `v9` (v8 fails on React 19); keeping state updates outside React render ticks (via Zustand refs / direct `CanvasTexture.needsUpdate`) is mandatory to avoid 60fps re-render jank.
12. **Compatibility with YOUR CHOICE:** **High** with `react@^19.3.1` when pinned to `@react-three/fiber@9`.
13. **Integration Difficulty:** Medium.
14. **Security or Dependency Concerns:** Keep `three` and `@react-three/fiber` versions synchronized; lazy-load on user click ("View in 3D").
15. **Recommended Usage & Phase:** **USE in Phase 3 (Mode B)** 3D garment viewer & customizer preview.

#### 3. `google/model-viewer` — **REFERENCE (Static 3D Showcase Only)**

1. **Name:** `<model-viewer>`
2. **Direct GitHub URL:** `https://github.com/google/model-viewer`
3. **Official Documentation:** `https://modelviewer.dev/`
4. **Main Purpose:** Drop-in Web Component for viewing static `.glb`/`.usdz` 3D models with built-in AR and orbit controls.
5. **Technology Stack:** Web Components, TypeScript, Three.js under the hood.
6. **License:** **Apache-2.0**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** Active GitHub releases; exact latest tag `UNVERIFIED`.
9. **Community Activity & Stars:** ~8.3k+ GitHub stars.
10. **Advantages:** Zero-boilerplate viewer + AR Quick Look for static pre-baked products.
11. **Limitations:** Poor fit for real-time dynamic Fabric.js artwork UV mapping compared to direct R3F/Three.js `CanvasTexture` pipelines.
12. **Compatibility with YOUR CHOICE:** Medium (Web Component).
13. **Integration Difficulty:** Low for static models, High for live canvas sync.
14. **Security or Dependency Concerns:** Low.
15. **Recommended Usage & Phase:** **REFERENCE** for future static AR product showcase only; not for live customizer.

#### 4. `BabylonJS/Babylon.js` — **AVOID (Redundant Heavy Engine)**

1. **Name:** Babylon.js
2. **Direct GitHub URL:** `https://github.com/BabylonJS/Babylon.js`
3. **Official Documentation:** `https://doc.babylonjs.com/`
4. **Main Purpose:** Full WebGL/WebGPU 3D game & simulation engine.
5. **Technology Stack:** TypeScript, WebGL / WebGPU.
6. **License:** **Apache-2.0**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** `v8.0 / v9.0` major cadence active.
9. **Community Activity & Stars:** ~23k+ GitHub stars.
10. **Advantages:** Enterprise-grade PBR, Microsoft-backed.
11. **Limitations:** Game-engine scale is overkill for an apparel previewer, lacks R3F's native React 19 declarative integration, and we already have official Three.js expertise/resources locally.
12. **Compatibility with YOUR CHOICE:** Medium-Low.
13. **Integration Difficulty:** High.
14. **Security or Dependency Concerns:** Large bundle size.
15. **Recommended Usage & Phase:** **AVOID** (Three.js + R3F v9 is lighter and more React-idiomatic).

#### 5. Open-Source 3D T-Shirt Customizer Reference Repositories

> **Important Note:** These community repositories use `DecalGeometry` or basic texture replacement on single generic `.glb` shirts. Study them as **architectural references**, NOT production codebases.

| Repository                                  | GitHub URL                                                 | Stack                                    | License      |    Stars     | Limitation / Intended Use                                                                               |
| :------------------------------------------ | :--------------------------------------------------------- | :--------------------------------------- | :----------- | :----------: | :------------------------------------------------------------------------------------------------------ |
| **`Starklord17/threejs-t-shirt`**           | `https://github.com/Starklord17/threejs-t-shirt`           | React, Vite, R3F, Drei, Valtio, Tailwind | **MIT**      | `UNVERIFIED` | Tutorial-derived decal demo; lacks UV print-zone math & 300 DPI export. **REFERENCE** (Phase 3 Mode B). |
| **`AriyanMLZM/threejs-react-TDesigner`**    | `https://github.com/AriyanMLZM/threejs-react-TDesigner`    | TypeScript, React, R3F, Tailwind, GSAP   | `UNVERIFIED` | `UNVERIFIED` | Study TypeScript R3F shader/color binding; verify license before copying anything. **REFERENCE**.       |
| **`Kewlkaka/ai-threejs-tshirt-customiser`** | `https://github.com/Kewlkaka/ai-threejs-tshirt-customiser` | React, Three.js, R3F, Drei               | `UNVERIFIED` | `UNVERIFIED` | Pattern reference for Decal + file upload only. **REFERENCE**.                                          |
| **`ArunRawat404/3D-T-Shirt-Customization`** | `https://github.com/ArunRawat404/3D-T-Shirt-Customization` | React, R3F, Node/Express, Tailwind       | `UNVERIFIED` | `UNVERIFIED` | Reference for full-texture vs logo toggle. **REFERENCE**.                                               |

#### 6. 3D Garment Model Asset Sources

- **Poly Pizza (`https://poly.pizza/`):** Low-poly models mostly **CC0** or **CC-BY** (must check per-model tag; stylized low-poly only — not photorealistic apparel).
- **Sketchfab (`https://sketchfab.com/`):** Filterable by **CC0** / **CC-BY** `.glb` downloads. **Warning:** Default Sketchfab Standard License is **not** royalty-free commercial redistribution; always verify per-asset CC0/CC-BY badge and UV island layout in Blender before use!
- **KhronosGroup/glTF-Sample-Assets (`https://github.com/KhronosGroup/glTF-Sample-Assets`):** **CC0 / MIT / CC-BY** reference PBR glTF assets (`MaterialsVariantsShoe`, fabric sheen extensions) — **REFERENCE** for PBR cloth shader testing (e.g., `KHR_materials_sheen` for cotton/pique!).

### 2.3 Weighted Evaluation — 3D Rendering

| Candidate                                      | Maint (15%) | Sec (15%) | Compat (15%) | Doc (10%) | Cust (15%) | Perf (10%) | Lic (15%) | Comm (5%) | **Total** | Verdict                              |
| :--------------------------------------------- | :---------: | :-------: | :----------: | :-------: | :--------: | :--------: | :-------: | :-------: | :-------: | :----------------------------------- |
| **`mrdoob/three.js` (`r187`)**                 |     10      |     9     |      9       |     9     |     10     |     9      |    10     |    10     | **9.50**  | **USE (Phase 3 Mode B 3D Core)**     |
| **`pmndrs/react-three-fiber` (`v9`) + `drei`** |      9      |     9     |      9       |     9     |     9      |     8      |    10     |     9     | **9.05**  | **USE (Phase 3 Mode B React Layer)** |
| **`google/model-viewer`**                      |      8      |     9     |      7       |     9     |     4      |     8      |    10     |     8     | **7.75**  | **REFERENCE (Static AR Only)**       |
| **`BabylonJS/Babylon.js`**                     |      9      |     9     |      6       |     9     |     9      |     8      |    10     |     8     | **8.50**  | **AVOID (Overkill vs Three/R3F)**    |

---

## 3. Animation Libraries

### 3.1 Candidate Profiles

#### 1. `motiondivision/motion` — **USE (Primary Platform Animation Engine)**

1. **Name:** Motion (formerly Framer Motion; incorporates Motion One web APIs)
2. **Direct GitHub URL:** `https://github.com/motiondivision/motion`
3. **Official Documentation:** `https://motion.dev/`
4. **Main Purpose:** Declarative React animations, layout transitions, spring physics, drawers/modals (`AnimatePresence`), scroll reveals, and hardware-accelerated WAAPI (`motion/mini`).
5. **Technology Stack:** React, TypeScript, WAAPI / JS spring engine.
6. **License:** **MIT**
7. **Commercial Usage Permission:** Fully permitted without restrictions.
8. **Latest Verifiable Release / Maintenance:** Active `v12+`/`v14+` rolling releases (`UNVERIFIED` exact latest tag); already approved in `docs/TECHNOLOGY_SELECTION.md`.
9. **Community Activity & Stars:** ~31k–35k+ GitHub stars.
10. **Advantages:** First-class React 19 ergonomics, native `<MotionConfig reducedMotion="user">` global accessibility support, `AnimatePresence` for cart slide-over drawers and studio panels, single dependency covers both storefront & studio UI.
11. **Limitations:** Wrap root with `LazyMotion` (`domAnimation`) to keep initial bundle lean (~15–18KB vs full ~34KB).
12. **Compatibility with YOUR CHOICE:** **Full**.
13. **Integration Difficulty:** Low.
14. **Security or Dependency Concerns:** Negligible.
15. **Recommended Usage & Phase:** **USE** across Storefront, Product Reveal, Cart Drawer, Design Studio panels, and subtle Admin drawers (**Phase 1–7**).

#### 2. `greensock/GSAP` — **AVOID (Licensing Restriction for Visual Builders)**

1. **Name:** GSAP (GreenSock Animation Platform)
2. **Direct GitHub URL:** `https://github.com/greensock/GSAP`
3. **Official Documentation:** `https://gsap.com/docs/`
4. **Main Purpose:** Imperative timeline animation, ScrollTrigger, MorphSVG, SplitText.
5. **Technology Stack:** JavaScript / TypeScript.
6. **License:** **Custom Proprietary ("Standard No Charge License" under Webflow)** — NOT MIT/Apache.
7. **Commercial Usage Permission:** Free for standard commercial websites/apps following Webflow's acquisition, **HOWEVER** the license explicitly **prohibits using GSAP in competing no-code/visual design or animation builder tools** that rival Webflow's market.
8. **Latest Verifiable Release / Maintenance:** **v3.15.1**.
9. **Community Activity & Stars:** ~30.6k GitHub stars.
10. **Advantages:** Powerful imperative timelines.
11. **Limitations:** Legal gray area / license exclusion because YOUR CHOICE includes a browser-based visual Design Studio; also creates a second animation runtime alongside `motion`.
12. **Compatibility with YOUR CHOICE:** Imperative API clashes with declarative React UI unless carefully wrapped.
13. **Integration Difficulty:** Medium.
14. **Security or Dependency Concerns:** Proprietary license compliance audit risk.
15. **Recommended Usage & Phase:** **AVOID** (Motion + CSS transitions cover all platform needs under clean MIT license).

#### 3. `airbnb/lottie-web` + `LottieFiles/lottie-react` — **CONDITIONAL (Bespoke Empty-State / Order-Success Micro-Graphics Only)**

1. **Name:** Lottie Web
2. **Direct GitHub URL:** `https://github.com/airbnb/lottie-web`
3. **Official Documentation:** `https://airbnb.io/lottie/`
4. **Main Purpose:** Playback of exported After Effects vector JSON animations.
5. **Technology Stack:** JavaScript, SVG/Canvas renderer.
6. **License:** **MIT**
7. **Commercial Usage Permission:** Permitted for engine; **each `.json` Lottie file has its own creator license** (many LottieFiles community downloads require attribution or paid Pro!).
8. **Latest Verifiable Release / Maintenance:** Mature (`UNVERIFIED` latest tag).
9. **Community Activity & Stars:** ~32.4k GitHub stars.
10. **Advantages:** Crisp complex vector illustrations (e.g., DTF printing step animation).
11. **Limitations:** Heavy player (~60KB+ gzipped for `lottie-web`; `dotlottie` / `lottie-light` reduces size), requires After Effects workflow to author custom assets.
12. **Compatibility with YOUR CHOICE:** Medium (lazy-load only if bespoke vector animations are created).
13. **Integration Difficulty:** Low–Medium.
14. **Security or Dependency Concerns:** Never load untrusted third-party Lottie JSON expressions (`eval`/expression execution risk in full `lottie-web` if `expressions` enabled — use SVG/light player or sanitized self-hosted JSON only).
15. **Recommended Usage & Phase:** **REFERENCE / CONDITIONAL** — defer unless custom brand Lottie assets are authored (**Phase 1/4** optional).

#### 4. `rive-app/rive-react` — **REFERENCE (Interactive Brand Hero / Masoct Future Only)**

1. **Name:** Rive React Runtime
2. **Direct GitHub URL:** `https://github.com/rive-app/rive-react`
3. **Official Documentation:** `https://rive.app/docs/`
4. **Main Purpose:** State-machine-driven interactive 2D vector animations rendered via WASM/Canvas.
5. **Technology Stack:** React, TypeScript, WebAssembly (`@rive-app/canvas` / `wasm`).
6. **License:** **MIT** (runtime); Rive Editor SaaS has free/paid tiers.
7. **Commercial Usage Permission:** Runtime MIT; self-authored `.riv` files commercially usable.
8. **Latest Verifiable Release / Maintenance:** Active (`UNVERIFIED` exact latest tag).
9. **Community Activity & Stars:** ~1.2k stars (`rive-react`).
10. **Advantages:** Interactive state machines, tiny `.riv` binary payloads.
11. **Limitations:** Requires WASM runtime (~150KB+) and Rive Editor authoring skill.
12. **Compatibility with YOUR CHOICE:** Medium.
13. **Integration Difficulty:** Medium.
14. **Security or Dependency Concerns:** WASM CSP (`wasm-unsafe-eval` or strict MIME handling) on deployment servers.
15. **Recommended Usage & Phase:** **REFERENCE** only; unnecessary for Phase 0–6.

#### 5. `theatre-js/theatre` — **REFERENCE (Optional Post-MVP 3D Camera Choreography)**

1. **Name:** Theatre.js
2. **Direct GitHub URL:** `https://github.com/theatre-js/theatre`
3. **Official Documentation:** `https://www.theatrejs.com/docs/latest`
4. **Main Purpose:** Keyframe timeline studio & runtime for Three.js/R3F camera & product reveal choreography.
5. **Technology Stack:** TypeScript, React, Three.js / R3F (`@theatre/r3f`).
6. **License:** **Apache-2.0**
7. **Commercial Usage Permission:** Fully permitted.
8. **Latest Verifiable Release / Maintenance:** Active (`UNVERIFIED` latest tag).
9. **Community Activity & Stars:** ~13k GitHub stars.
10. **Advantages:** Visual timeline keyframing directly inside Three.js scenes; strip `@theatre/studio` out of production bundles so only tiny `@theatre/core` ships.
11. **Limitations:** Overkill for 2D UI and Phase 3 Mode B OrbitControls presets; only justified for scripted cinematic 3D launch sequences.
12. **Compatibility with YOUR CHOICE:** High when paired with R3F in Mode B 3D Studio.
13. **Integration Difficulty:** Medium.
14. **Security or Dependency Concerns:** Ensure `@theatre/studio` is dev-only / excluded from production build.
15. **Recommended Usage & Phase:** **DEFER beyond Phase 3 Mode B** unless scripted multi-shot 3D launch sequences are requested.

#### 6. `juliangarnier/anime` (Anime.js) & `formkit/auto-animate` & `darkroomengineering/lenis`

- **`juliangarnier/anime`** (`https://github.com/juliangarnier/anime`, **MIT**, ~73k+ stars): Strong imperative SVG/DOM engine, **AVOID** to prevent duplicating `motiondivision/motion`.
- **`formkit/auto-animate`** (`https://github.com/formkit/auto-animate`, **MIT**, ~14k+ stars, `v0.10.x`): Tiny ~3KB zero-config list-reorder animation helper; **REFERENCE** for simple list transitions if Motion's `<AnimatePresence>` isn't already imported on a route.
- **`darkroomengineering/lenis`** (`https://github.com/darkroomengineering/lenis`, **MIT**, ~17.3k+ stars, `v1.3.x`): Smooth scroll hijacking; **AVOID** in Design Studio & Admin (interferes with canvas wheel zoom, native accessibility, and scroll-to-anchor behavior).

### 3.2 Animation Context Mapping

1. **Storefront interactions:** `motiondivision/motion` (`LazyMotion` + CSS transitions) for hero staggered reveal, mega-menu open/close, cart drawer slide-over, filter pills.
2. **Design Studio interactions:** **Pure CSS/Tailwind transitions** for tool rails/sliders (zero frame-drop contention with Fabric.js pointer events) + `motion` only for modal/export drawers.
3. **Product presentation:** `motion` shared-layout / gallery crossfade + CSS `transform` hover zoom.
4. **3D product previews (Phase 3 Mode B):** R3F `useFrame` lerp damping + `OrbitControls` damping; optional `theatre-js` core only if scripted hero turntables are added later.
5. **Admin interface animations:** **Minimal Tailwind CSS transitions only** (fast 120–150ms state feedback; zero decorative motion in high-density TanStack Tables and QC queues).

### 3.3 Weighted Evaluation — Animation Libraries

| Candidate                   | Maint (15%) | Sec (15%) | Compat (15%) | Doc (10%) | Cust (15%) | Perf (10%) | Lic (15%) | Comm (5%) | **Total** | Verdict                    |
| :-------------------------- | :---------: | :-------: | :----------: | :-------: | :--------: | :--------: | :-------: | :-------: | :-------: | :------------------------- |
| **`motiondivision/motion`** |      9      |     9     |      10      |     9     |     9      |     8      |    10     |     9     | **9.20**  | **USE (Primary UI)**       |
| **`formkit/auto-animate`**  |      8      |     9     |      9       |     8     |     5      |     10     |    10     |     8     | **8.35**  | **REFERENCE**              |
| **`theatre-js/theatre`**    |      8      |     9     |      8       |     8     |     9      |     8      |    10     |     8     | **8.50**  | **OPTIONAL (Post-MVP 3D)** |
| **`airbnb/lottie-web`**     |      8      |     7     |      8       |     8     |     7      |     7      |    10     |     9     | **8.00**  | **CONDITIONAL**            |
| **`rive-app/rive-react`**   |      8      |     8     |      8       |     8     |     8      |     9      |    10     |     7     | **8.25**  | **REFERENCE**              |
| **`juliangarnier/anime`**   |      8      |     9     |      7       |     8     |     8      |     9      |    10     |     9     | **8.40**  | **AVOID (Redundant)**      |
| **`greensock/GSAP`**        |      9      |     9     |      7       |    10     |     9      |     9      |   **3**   |     9     | **7.70**  | **AVOID (Builder Clause)** |

---

## 4. Icon Libraries

> **Interface Rule:** YOUR CHOICE already uses **`lucide-react`** (`^1.73.0`) in `apps/web`. Never mix multiple stroke/fill icon families inside the same UI surface.

| Library                            | GitHub URL                                        | Docs                             | License        |         Stars         |        Latest         | Commercial Use  | Verdict & Phase                                                                                                          |
| :--------------------------------- | :------------------------------------------------ | :------------------------------- | :------------- | :-------------------: | :-------------------: | :-------------- | :----------------------------------------------------------------------------------------------------------------------- |
| **`lucide-icons/lucide`**          | `https://github.com/lucide-icons/lucide`          | `https://lucide.dev/`            | **ISC**        |        ~25.8k         | `^1.73.0` (installed) | Yes, permissive | **USE (Primary Platform Icons — Phase 0–8)**                                                                             |
| **`tabler/tabler-icons`**          | `https://github.com/tabler/tabler-icons`          | `https://tabler.io/icons`        | **MIT**        |        ~22.6k         |     `UNVERIFIED`      | Yes             | **REFERENCE** (Only if Design Studio needs specialized CAD/alignment symbols missing in Lucide; normalize `strokeWidth`) |
| **`phosphor-icons/core`**          | `https://github.com/phosphor-icons/core`          | `https://phosphoricons.com/`     | **MIT**        | ~4k core / ~7.7k home |     `UNVERIFIED`      | Yes             | **REFERENCE** (Multi-weight; avoid mixing with Lucide)                                                                   |
| **`tailwindlabs/heroicons`**       | `https://github.com/tailwindlabs/heroicons`       | `https://heroicons.com/`         | **MIT**        |        ~23.8k         |     `UNVERIFIED`      | Yes             | **AVOID** (Smaller icon set for Design Studio tools than Lucide)                                                         |
| **`iconoir-icons/iconoir`**        | `https://github.com/iconoir-icons/iconoir`        | `https://iconoir.com/`           | **MIT**        |         ~4.6k         |     `UNVERIFIED`      | Yes             | **AVOID** (Smaller ecosystem, redundant with Lucide)                                                                     |
| **`google/material-design-icons`** | `https://github.com/google/material-design-icons` | `https://fonts.google.com/icons` | **Apache-2.0** |         ~45k+         |     `UNVERIFIED`      | Yes             | **AVOID** (Aesthetic diverges from sleek tech-streetwear stroke system)                                                  |

### Weighted Evaluation — Icon Libraries

- **`lucide-icons/lucide`**: Maint `9`, Sec `10`, Compat `10`, Doc `9`, Cust `8`, Perf `9`, Lic `10`, Comm `9` -> **`9.30 / 10` (USE)**
- **`tabler/tabler-icons`**: Maint `9`, Sec `10`, Compat `9`, Doc `8`, Cust `8`, Perf `9`, Lic `10`, Comm `9` -> **`9.05 / 10` (REFERENCE)**
- **`tailwindlabs/heroicons`**: Maint `9`, Sec `10`, Compat `9`, Doc `8`, Cust `6`, Perf `9`, Lic `10`, Comm `9` -> **`8.75 / 10` (AVOID — narrow studio coverage)**

---

## 5. Illustration Collections

> **Usage Note:** Illustrations belong selectively in **empty states** (empty cart, empty saved designs, onboarding) and **How It Works** graphics — NEVER as unmoderated Design Studio clipart unless explicitly cleared for POD merchandise resale!

| Resource               | Official URL                        | License                          |  Commercial UI Use  |                POD Merchandise Safe?                |    Attribution?     | Verdict & Phase                                         |
| :--------------------- | :---------------------------------- | :------------------------------- | :-----------------: | :-------------------------------------------------: | :-----------------: | :------------------------------------------------------ |
| **Open Peeps**         | `https://www.openpeeps.com/`        | **CC0 1.0**                      |         Yes         |                 Yes (Public Domain)                 |         No          | **USE (Creator/Avatar Empty States — Phase 1/4)**       |
| **Humaaans**           | `https://www.humaaans.com/`         | **CC0 1.0**                      |         Yes         |                 Yes (Public Domain)                 |         No          | **REFERENCE (Editorial Onboarding — Phase 1)**          |
| **unDraw**             | `https://undraw.co/`                | **Custom Permissive**            |         Yes         | **No** (no asset-pack/competing use or AI training) |         No          | **USE selectively for UI Empty States Only (Phase 1+)** |
| **ManyPixels**         | `https://www.manypixels.co/gallery` | **Custom Permissive**            |         Yes         |        **No** (UI use only; no pack resale)         |         No          | **REFERENCE for UI Empty States**                       |
| **DrawKit**            | `https://www.drawkit.com/`          | **Custom Commercial (Free/Pro)** |         Yes         |   **No** (no unflattened templates / AI training)   |         No          | **REFERENCE**                                           |
| **Storyset (Freepik)** | `https://storyset.com/`             | **Freepik License**              | Free w/ attribution |          **No** (POD limits on free tier)           | **YES (Free tier)** | **AVOID** (attribution burden + POD limits)             |

---

## 6. Texture Resources

Textures serve two distinct purposes in YOUR CHOICE:

1. **Mockup & Fabric Realism (Phase 2–3):** Subtle cotton/pique weave bump/multiply overlays and wrinkle shading for 2D/3D T-Shirt & Polo previews.
2. **UI & Studio Graphic Assets (Phase 1–3):** Subtle dark-mode tech grids, noise grain, and geometric SVG backdrops matching the Royal Blue / Black / Silver YOUR CHOICE brand.

| Resource                 | Official URL                           | Asset Types                                                                    | License                                          | Commercial & Preview Use                                                              |       Attribution?       | Verdict & Phase                                                                        |
| :----------------------- | :------------------------------------- | :----------------------------------------------------------------------------- | :----------------------------------------------- | :------------------------------------------------------------------------------------ | :----------------------: | :------------------------------------------------------------------------------------- |
| **ambientCG**            | `https://ambientcg.com/`               | Seamless PBR fabric, cotton, knit, weave, roughness, normal maps (up to 4K/8K) | **CC0 1.0**                                      | **Full commercial + modification + 2D/3D previews**                                   |            No            | **USE (Primary Cotton & Pique Polo Fabric Textures — Phase 2–8)**                      |
| **Poly Haven**           | `https://polyhaven.com/textures`       | Seamless PBR fabric/cloth textures & studio HDRIs (for 3D lighting)            | **CC0 1.0**                                      | **Full commercial + modification + 2D/3D previews**                                   |            No            | **USE (Studio HDRIs & Fabric PBR — Phase 2–8)**                                        |
| **Kenney.nl**            | `https://kenney.nl/assets`             | CC0 UI textures, particle sprites, basic 3D props                              | **CC0 1.0**                                      | **Full commercial**                                                                   |            No            | **REFERENCE (CC0 utility textures)**                                                   |
| **Texturelabs**          | `https://texturelabs.org/`             | High-res grunge, halftone, paper, ink distress overlays                        | **Custom Free Commercial**                       | Permitted inside derivative works (mockups/banners); **never redistribute raw files** |            No            | **USE carefully in flattened/composited UI & merchant promo banners only (Phase 1–2)** |
| **FFFuel**               | `https://www.fffuel.co/`               | SVG noise, grain, mesh gradients, abstract geometric tech patterns             | **Custom Free Commercial**                       | Permitted in web UI/brand visuals; **never redistribute standalone generators/packs** |            No            | **USE (Storefront & Dark Studio Tech Backdrops — Phase 1–2)**                          |
| **Hero Patterns**        | `https://heropatterns.com/`            | Lightweight repeatable CSS/SVG geometric backgrounds                           | **Custom Free Digital**                          | Permitted in commercial websites; **no competing pattern pack**                       |            No            | **REFERENCE (Subtle CSS backgrounds — Phase 1)**                                       |
| **Haikei**               | `https://haikei.app/`                  | Procedural SVG waves, blobs, grids                                             | **Custom / CC BY 4.0** (varies by tool)          | Permitted for web designs; no competing generator                                     | Appreciated / check tool | **REFERENCE (Static SVG waves — Phase 1)**                                             |
| **Transparent Textures** | `https://www.transparenttextures.com/` | Tiny seamless PNG noise/weave overlays                                         | **Free Pattern Repo** (Subtle Patterns heritage) | Web design OK; verify individual pattern notice                                       |       Appreciated        | **REFERENCE**                                                                          |
| **SVGBackgrounds.com**   | `https://www.svgbackgrounds.com/`      | Vector background patterns                                                     | **Mixed Free/Paid**                              | Verify per-background free vs paid tier                                               |          Varies          | **AVOID** (prefer `fffuel` / `Hero Patterns`)                                          |

> **Design Studio Clipart Warning:** Do **NOT** preload Texturelabs or FFFuel textures directly as redistributable "free customer sticker packs" inside the Design Studio unless CC0 (`ambientCG`, `Poly Haven`, `Kenney.nl`). Customer-exported print graphics must not violate raw-asset redistribution clauses.

---

## 7. Apparel Mockup Resources

> **Why This Category Requires Extreme Care:** Many "free T-shirt mockup" sites allow a solo designer to export a static JPEG for their shop, **but prohibit embedding their templates inside an automated multi-user SaaS mockup generator!**

### 7.1 Open-Source Mockup Generator & Compositor Repositories

| Repository                                    | GitHub URL                                                   | Stack                               | License                                                |      Stars      | Capabilities & Verdict                                                                                                                                                                        |
| :-------------------------------------------- | :----------------------------------------------------------- | :---------------------------------- | :----------------------------------------------------- | :-------------: | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **`Agamnentzar/ag-psd` + `lovell/sharp`**     | `https://github.com/Agamnentzar/ag-psd`                      | TypeScript + libvips                | **MIT** / **Apache-2.0**                               | ~740+ / ~32.7k+ | **USE (Internal Asset Prep + Runtime Compositor):** Extract curated PSD layers offline into `[base-mask, shadow, highlight]` PNGs, then composite live artwork cleanly in `Sharp` at runtime. |
| **`zyadhajaji/threadforge`**                  | `https://github.com/zyadhajaji/threadforge`                  | TS, Next.js 14, Fabric.js, Tailwind | Open Source (verify repo file; exact tag `UNVERIFIED`) |       ~10       | **REFERENCE:** Study Fabric.js apparel canvas + collection builder UX.                                                                                                                        |
| **`Raj-Srikar/Custom-Mockup-Generator`**      | `https://github.com/Raj-Srikar/Custom-Mockup-Generator`      | JS, Photoshop / Photopea layer spec | **MIT**                                                |       ~16       | **REFERENCE:** Useful layer naming pattern (`Design`, luminosity shadow/highlight masks) for internal mockup templates.                                                                       |
| **`submarinejuice/Custom-Mock-Up-Generator`** | `https://github.com/submarinejuice/Custom-Mock-Up-Generator` | JS, Fabric.js                       | Open Source (exact file `UNVERIFIED`)                  |  `UNVERIFIED`   | **REFERENCE:** Basic Printful-style drag-and-drop template UX.                                                                                                                                |
| **`rafaelrmagalhaes/mockup-generator`**       | `https://github.com/rafaelrmagalhaes/mockup-generator`       | React                               | Open Source (exact file `UNVERIFIED`)                  |  `UNVERIFIED`   | **REFERENCE:** Simple React artwork-on-shirt overlay example.                                                                                                                                 |
| **`CTDave001/automated_mockups`**             | `https://github.com/CTDave001/automated_mockups`             | Python, Pillow                      | Open Source (exact file `UNVERIFIED`)                  |       ~76       | **REFERENCE:** Batch coordinate placement reference (we use Node + Sharp instead of Python).                                                                                                  |
| **`moizkamran/etsy-mockup-generator`**        | `https://github.com/moizkamran/etsy-mockup-generator`        | Python                              | `UNVERIFIED`                                           |  `UNVERIFIED`   | **AVOID:** Simple script; Python stack mismatch.                                                                                                                                              |

### 7.2 Free Downloadable Apparel Mockup Sources — Commercial & SaaS Audit

| Source                                                | Official URL                                                                       | Available Formats                                            |                       Commercial Store Use                       | Modification & Color Swap |                                          Use Inside YOUR CHOICE Automated Generator?                                           | Attribution? | Verdict                                                                                                 |
| :---------------------------------------------------- | :--------------------------------------------------------------------------------- | :----------------------------------------------------------- | :--------------------------------------------------------------: | :-----------------------: | :----------------------------------------------------------------------------------------------------------------------------: | :----------: | :------------------------------------------------------------------------------------------------------ |
| **In-House Studio Photography / Commissioned Blanks** | Internal (`apps/web/public` / S3)                                                  | High-res PNG layers (Front, Back, Flat-lay, Ghost Mannequin) |                          **100% Owned**                          |         **Full**          |                                                   **YES — Zero legal risk**                                                    |      No      | **USE (Primary Production Mockups — Phase 1–3)**                                                        |
| **Mr. Mockup (Freebies)**                             | `https://mrmockup.com/freebies/`                                                   | Layered PSD (Smart Objects)                                  |                  Yes (royalty-free commercial)                   |            Yes            | **LEGAL REVIEW** — Raw PSD must never be exposed; check whether automated customer preview SaaS exceeds standard freebie EULA  |      No      | **CONDITIONAL (Static catalog shots OK; verify before SaaS embedding)**                                 |
| **Mockups-Design**                                    | `https://mockups-design.com/`                                                      | Layered PSD                                                  |                 Yes (flattened PNG/JPG exports)                  |            Yes            |                         **LEGAL REVIEW** — Confirm automated SaaS rendering vs manual designer export                          |      No      | **CONDITIONAL (Static store promos OK)**                                                                |
| **Unblast / GraphicBurger / Pixeden (Free)**          | `https://unblast.com/` / `https://graphicburger.com/` / `https://www.pixeden.com/` | PSD (Smart Objects)                                          |             Yes (personal & commercial client work)              |            Yes            |                              **LEGAL REVIEW** — Never redistribute PSDs; verify per-item license                               |  Usually No  | **CONDITIONAL (Use for static marketing banners, not SaaS templates without verification)**             |
| **LS.Graphics (Freebies)**                            | `https://www.ls.graphics/free-mockups`                                             | PSD / Figma                                                  |                               Yes                                |            Yes            |                                          **LEGAL REVIEW** (No source redistribution)                                           |      No      | **CONDITIONAL**                                                                                         |
| **MockupWorld**                                       | `https://www.mockupworld.co/`                                                      | Directory linking to third-party PSDs                        |                   Varies per external creator!                   |          Varies           |                      **DO NOT ASSUME** — Must audit destination creator license on every single download                       |    Varies    | **REFERENCE DIRECTORY ONLY**                                                                            |
| **Unsplash / Pexels / Pixabay**                       | `https://unsplash.com/` / `https://www.pexels.com/`                                | Lifestyle JPG/PNG photos                                     |                Yes (marketing & store backdrops)                 |            Yes            | **RESTRICTED (Unsplash)** — Prohibits compiling images into a competing mockup-generator service; no implied model endorsement |      No      | **USE ONLY for Hero/Lifestyle Editorial Photography — NOT as Design Studio mockup generator templates** |
| **Freepik (Free Tier)**                               | `https://www.freepik.com/`                                                         | PSD / JPG / Vector                                           |                Attribution required + POD limits                 |            Yes            |                                         **NO** (attribution required + POD/SaaS traps)                                         |   **YES**    | **AVOID**                                                                                               |
| **Printful / Printify / Gelato Mockups**              | `https://www.printful.com/` / `https://printify.com/`                              | PNG                                                          | Strictly limited to selling items fulfilled by Printful/Printify |            No             |                                     **STRICTLY PROHIBITED** for independent POD platforms                                      |     N/A      | **AVOID (Platform-Locked)**                                                                             |

---

## 8. Font Collections (English & Bangla Dual-Script Support)

> **Critical Engineering Rule:** Every font offered inside the **YOUR CHOICE Design Studio** MUST be self-hosted via **`@fontsource`** (or verified SIL OFL `.ttf`/`.woff2` files in private/CDN storage) so that **Browser Fabric.js Canvas** and **Node.js `StaticCanvas` / Sharp 300 DPI Print Exporter** render **pixel-identical typography and line breaks**!

### 8.1 Font Delivery & Licensing Infrastructure

- **`fontsource/fontsource`** (`https://github.com/fontsource/fontsource`, `https://fontsource.org/`): **MIT** packaging around **SIL OFL 1.1** open-source fonts. ~6.2k–6.3k GitHub stars, `core-v0.6.1`. Eliminates external Google CDN latency/outages and supplies local `.woff2` + `.ttf` files for server-side print rendering. **USE (Phase 1–3)**.

### 8.2 Recommended English Typography Collection (SIL OFL 1.1 — Free Commercial & Web Embedding)

| Font Family           | Package (`@fontsource/*`)                | Category                       | Intended YOUR CHOICE Usage                                    | License         |
| :-------------------- | :--------------------------------------- | :----------------------------- | :------------------------------------------------------------ | :-------------- |
| **Space Grotesk**     | `@fontsource-variable/space-grotesk`     | Futuristic Geometric Tech Sans | Brand headings, Storefront Hero, Tech-Streetwear Studio font  | **SIL OFL 1.1** |
| **Plus Jakarta Sans** | `@fontsource-variable/plus-jakarta-sans` | Clean Modern Geometric Sans    | Primary Storefront, Marketplace, Creator & Admin UI body font | **SIL OFL 1.1** |
| **Outfit**            | `@fontsource-variable/outfit`            | Rounded Geometric Sans         | Clean contemporary apparel typography & UI alternative        | **SIL OFL 1.1** |
| **Barlow Condensed**  | `@fontsource/barlow-condensed`           | Bold Condensed Grotesque       | Athletic, streetwear drop badges, Design Studio preset        | **SIL OFL 1.1** |
| **Bebas Neue**        | `@fontsource/bebas-neue`                 | All-Caps Condensed Display     | High-impact T-shirt & Polo back/chest poster typography       | **SIL OFL 1.1** |
| **Anton**             | `@fontsource/anton`                      | Ultra-Heavy Impact Display     | Bold streetwear block lettering in Design Studio              | **SIL OFL 1.1** |
| **Syne**              | `@fontsource-variable/syne`              | Avant-Garde Editorial Display  | Limited creator drop titles & fashion-forward Studio text     | **SIL OFL 1.1** |
| **JetBrains Mono**    | `@fontsource-variable/jetbrains-mono`    | Technical Monospace            | SKU codes, 300 DPI coordinates, techwear apparel prints       | **SIL OFL 1.1** |

### 8.3 Recommended Bangla (Bengali) Typography Collection

| Font Family                   | Package / Source                                         | Style                               | Intended YOUR CHOICE Usage                                                                 | License & Embedding Rights                                                                                                   | Verdict                              |
| :---------------------------- | :------------------------------------------------------- | :---------------------------------- | :----------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------- | :----------------------------------- |
| **Noto Sans Bengali**         | `@fontsource-variable/noto-sans-bengali`                 | Clean Unicode Sans                  | Primary Bangla UI, checkout, product descriptions, clean Studio text                       | **SIL OFL 1.1** — Full commercial & web/print embedding                                                                      | **USE (Primary Bangla UI & Studio)** |
| **Hind Siliguri**             | `@fontsource/hind-siliguri`                              | Humanist Geometric Bangla + Latin   | Bilingual UI headings, clean streetwear Bangla T-shirt typography                          | **SIL OFL 1.1** — Full commercial & web/print embedding                                                                      | **USE (Primary Bilingual Pairing)**  |
| **Anek Bangla**               | `@fontsource-variable/anek-bangla`                       | Variable-Width Contemporary Display | Expressive Bangla headlines, bold/condensed T-shirt typography                             | **SIL OFL 1.1** — Full commercial & web/print embedding                                                                      | **USE (Design Studio Display)**      |
| **Baloo Da 2**                | `@fontsource/baloo-da-2`                                 | Friendly Rounded Display            | Casual streetwear, youth/gift collections, playful Bangla prints                           | **SIL OFL 1.1** — Full commercial & web/print embedding                                                                      | **USE (Design Studio Casual)**       |
| **Tiro Bangla**               | `@fontsource/tiro-bangla`                                | Literary Editorial Serif            | Heritage/poetic Bangla quotes on apparel & editorial pages                                 | **SIL OFL 1.1** — Full commercial & web/print embedding                                                                      | **USE (Design Studio Serif)**        |
| **Kalpurush / SolaimanLipi**  | OmicronLab / Open Bangla (`https://www.omicronlab.com/`) | Classic Unicode Bangla              | Optional classic Bangla print option (verify exact repo `.ttf` hash before bundling)       | **SIL OFL**                                                                                                                  | **REFERENCE**                        |
| **Siyam Rupali**              | OmicronLab                                               | Classic Unicode Bangla              | Optional fallback only                                                                     | **GPL v2+ with Font Exception** (allows document embedding without viral GPL, but prefer OFL fonts for simpler SaaS hygiene) | **REFERENCE (Prefer OFL above)**     |
| **SutonnyMJ**                 | Ananda Computers (Bijoy)                                 | Legacy ANSI Bangla                  | **BANNED** — Proprietary commercial license, legacy non-Unicode encoding                   | **Proprietary**                                                                                                              | **AVOID**                            |
| **Lipighor (Free Downloads)** | `https://lipighor.com/`                                  | Decorative Bangla                   | **BANNED unless commercial license purchased** — Free tier is personal/non-commercial only | **Proprietary / Non-Commercial Free**                                                                                        | **AVOID**                            |

> **Recommended English + Bangla Pairing:** Pair **Space Grotesk** (Display) + **Plus Jakarta Sans** (UI Body) with **Hind Siliguri** (Bangla Display/UI) + **Noto Sans Bengali** (Bangla Body) for balanced x-height, weight harmony, and seamless bilingual rendering.

---

## 9. UI Templates (Storefront, Marketplace, Creator & Admin)

> **Alignment Rule:** All templates serve purely as **structural/layout references** adapted into `apps/web/src/components/ui/` (Tailwind CSS v4 + Radix + `shadcn/ui`). Never install competing UI kits (Mantine, Ant Design).

| Template / Resource                                      | Repo / URL                                                         | Stack                                                        | License Tier                                           |      Commercial Use       | Verdict & Phase                                                               |
| :------------------------------------------------------- | :----------------------------------------------------------------- | :----------------------------------------------------------- | :----------------------------------------------------- | :-----------------------: | :---------------------------------------------------------------------------- |
| **`satnaing/shadcn-admin`**                              | `https://github.com/satnaing/shadcn-admin`                         | React, Vite, TypeScript, Tailwind, shadcn/ui, TanStack Table | **Fully Free (MIT)** (~16.7k+ stars, `v2.2.1+`)        |            Yes            | **USE / CUSTOMIZE (Admin & Creator Dashboard Shell — Phase 4–6)**             |
| **`shadcn-ui/ui` Official Blocks**                       | `https://github.com/shadcn-ui/ui`                                  | React, Tailwind CSS, Radix                                   | **Fully Free (MIT)** (~128k+ stars)                    |            Yes            | **USE / CUSTOMIZE (Storefront, Auth, Settings, Sidebar — Phase 1–6)**         |
| **`TailAdmin/free-react-tailwind-admin-dashboard`**      | `https://github.com/TailAdmin/free-react-tailwind-admin-dashboard` | React, Tailwind CSS                                          | **Free Tier (MIT)** (~1.3k+ stars) / Pro Paid          |       MIT tier Yes        | **REFERENCE** (Prefer `satnaing/shadcn-admin` for Radix/shadcn parity)        |
| **Flowbite**                                             | `https://flowbite.com/`                                            | Tailwind CSS, React                                          | **Freemium** (Core MIT / Pro Paid EULA)                |    Core Yes / Pro Paid    | **REFERENCE (MIT blocks only)**                                               |
| **Cruip**                                                | `https://cruip.com/`                                               | React / Tailwind                                             | **Freemium** (Lite GPL / Pro Paid)                     | Lite GPL risks / Pro Paid | **AVOID** (GPL/paid licensing mismatch)                                       |
| **Tailwind UI / Tailwind Plus**                          | `https://tailwindcss.com/plus`                                     | React, Tailwind                                              | **Paid Commercial EULA**                               |         Paid only         | **AVOID** (Not free)                                                          |
| **Figma Community Files**                                | `https://www.figma.com/community`                                  | Figma                                                        | **Free with Attribution (`CC-BY-4.0` default)** / Paid |   Yes with Attribution    | **REFERENCE** (Visual inspiration only; never copy copyrighted brand imagery) |
| **`vercel/commerce` & `medusajs/nextjs-starter-medusa`** | GitHub                                                             | Next.js                                                      | MIT (**Archived / Deprecated**)                        |            Yes            | **AVOID** (Next.js coupled & unmaintained)                                    |

---

## 10. Design Studio Starter Projects

| Repository                             | GitHub URL                                            | Tech Stack                          | License     | Stars  |       Latest       | Verdict & Intended Use                                                                                                                                                                             |
| :------------------------------------- | :---------------------------------------------------- | :---------------------------------- | :---------- | :----: | :----------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **`salgum1114/react-design-editor`**   | `https://github.com/salgum1114/react-design-editor`   | React, Fabric.js, Ant Design        | **MIT**     | ~1.7k+ |      `v0.2.1`      | **REFERENCE (Phase 2):** Study React-to-Fabric controller wrapping, object handler registry, undo/redo history stack, and JSON serialization. **Do NOT copy Ant Design UI.**                       |
| **`ikuaitu/vue-fabric-editor`**        | `https://github.com/ikuaitu/vue-fabric-editor`        | Vue 3, Fabric.js                    | **MIT**     | ~8.0k+ |       Active       | **REFERENCE (Phase 2):** Best open-source reference for Fabric.js plugin architecture, alignment/snap guidelines, font loader, ruler, and print-template JSON patterns. Port pure TS plugins only. |
| **`scaleflex/filerobot-image-editor`** | `https://github.com/scaleflex/filerobot-image-editor` | JS / React wrapper, Konva.js        | **MIT**     | ~1.9k+ | `v4.x / v5.0-beta` | **REFERENCE (Phase 2):** Study photo-filter, brightness/contrast, and crop modal UX patterns.                                                                                                      |
| **`nhn/tui.image-editor`**             | `https://github.com/nhn/tui.image-editor`             | JS, Fabric.js                       | **MIT**     | ~7.7k+ |  Mature (slowing)  | **REFERENCE (Phase 2):** Legacy reference for Fabric filter presets; outdated UI/tooling.                                                                                                          |
| **`zyadhajaji/threadforge`**           | `https://github.com/zyadhajaji/threadforge`           | Next.js 14, Fabric.js, TS, Tailwind | Open Source |  ~10   |    `UNVERIFIED`    | **REFERENCE (Phase 2–3):** Lightweight Fabric.js streetwear mockup preview pattern.                                                                                                                |

---

## 11. Useful Tutorials and Official Documentation

- **Fabric.js v7 Official Docs & Node SSR:** `https://fabricjs.com/` (modular ESM `StaticCanvas`, `FabricImage`, `Textbox`, `clipPath`)
- **Sharp High-Performance Image Processing:** `https://sharp.pixelplumbing.com/` (compositing, ICC/DPI density metadata, streaming)
- **Konva & React Konva Docs:** `https://konvajs.org/docs/react/`
- **Three.js Manual & Examples:** `https://threejs.org/docs/` and `https://threejs.org/manual/` (`CanvasTexture`, `GLTFLoader`, `DecalGeometry`)
- **React Three Fiber v9 Migration & Docs:** `https://r3f.docs.pmndrs.org/`
- **Drei Helpers:** `https://drei.docs.pmndrs.org/`
- **Motion Documentation:** `https://motion.dev/docs` (`LazyMotion`, `AnimatePresence`, `MotionConfig`)
- **Lucide Icons:** `https://lucide.dev/icons/`
- **Fontsource Self-Hosting Guides:** `https://fontsource.org/docs/getting-started/install`
- **SIL Open Font License 1.1 FAQ:** `https://openfontlicense.org/`
- **Tailwind CSS v4 Theme Tokens:** `https://tailwindcss.com/docs` (`UNVERIFIED` exact sub-path; verified v4 installed)
- **Drizzle ORM (`mysql2` / MariaDB):** `https://orm.drizzle.team/`

---

## 12. Licensing Warnings & Commercial Compliance Audit

| License / Term                                            | Example Resources                                                                                                                |          Commercial SaaS Allowed?          |           Modify Allowed?            |                    Attribution Required?                    |                                Safe for Customer-Generated Previews & Print Exports?                                 | Legal / Engineering Action                                                                           |
| :-------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------: | :----------------------------------: | :---------------------------------------------------------: | :------------------------------------------------------------------------------------------------------------------: | :--------------------------------------------------------------------------------------------------- |
| **MIT / ISC / BSD-3**                                     | Fabric.js, Konva, Sharp, Three.js, R3F, Motion, Lucide, shadcn-admin, ag-psd                                                     |                  **YES**                   |               **YES**                |  Preserve copyright/license in bundle (`LICENSE` notices)   |                                                       **YES**                                                        | **Approved**                                                                                         |
| **Apache-2.0**                                            | Sharp, Drizzle ORM, model-viewer, Theatre.js                                                                                     |                  **YES**                   |               **YES**                |      Preserve `NOTICE`/license + patent grant included      |                                                       **YES**                                                        | **Approved**                                                                                         |
| **CC0 1.0 (Public Domain)**                               | ambientCG, Poly Haven, Kenney.nl, Open Peeps, Humaaans                                                                           |                  **YES**                   |               **YES**                |                           **NO**                            |                                                       **YES**                                                        | **Approved (Ideal for textures & clipart)**                                                          |
| **SIL OFL 1.1**                                           | Google Fonts (`Space Grotesk`, `Plus Jakarta Sans`, `Noto Sans Bengali`, `Hind Siliguri`, `Anek Bangla`, etc.), Fontsource fonts |                  **YES**                   |      **YES** (under OFL rules)       | Keep OFL copyright/notice; cannot sell standalone font file |                   **YES** (Web embedding + flattened 300 DPI raster print output fully permitted)                    | **Approved**                                                                                         |
| **GPL v2+ with Font Exception**                           | Siyam Rupali                                                                                                                     |                  **YES**                   | **YES** (if modified font stays GPL) |                             Yes                             |                        **YES** (Embedding exception prevents viral GPL on exported documents)                        | **Conditional** — Prefer SIL OFL fonts (`Noto Sans Bengali`, `Hind Siliguri`) to avoid any ambiguity |
| **CC-BY-4.0**                                             | Figma Community free files (default), some Sketchfab/Poly Pizza models                                                           |                  **YES**                   |               **YES**                |                     **YES (Mandatory)**                     |           **Conditional** — Must credit creator in-app/credits; avoid for automated customer print exports           | **Flag for Legal/Attribution Ledger**                                                                |
| **Custom Permissive (No Raw Resale / No Competing Tool)** | unDraw, ManyPixels, DrawKit, Texturelabs, FFFuel                                                                                 |     **YES (App UI / Brand Marketing)**     |               **YES**                |                    No (except Storyset)                     | **NO** — Do NOT offer inside Design Studio as downloadable/customizable customer clipart or standalone texture packs | **UI & Merchant Banners Only**                                                                       |
| **GSAP Standard No-Charge License**                       | `greensock/GSAP`                                                                                                                 |              **Conditional**               |         No (custom license)          |                             Yes                             |                         **RISK** — Explicitly bars competing visual/animation builder tools                          | **AVOID**                                                                                            |
| **Source-Available / Commercial Key**                     | `tldraw/tldraw`                                                                                                                  |         **NO (without paid key)**          |              Restricted              |                             Yes                             |                                                        **NO**                                                        | **AVOID**                                                                                            |
| **Proprietary Paid / Non-Commercial**                     | Polotno, IMG.LY CE.SDK, Tailwind UI/Plus, SutonnyMJ, Lipighor (free), Freepik Free                                               | **NO** (without paid/enterprise agreement) |                **NO**                |                           Varies                            |                                                        **NO**                                                        | **AVOID**                                                                                            |
| **Platform-Locked / Service-Locked**                      | Printful/Printify mockups, Unsplash (for mockup-builder compilation)                                                             |                   **NO**                   |                 N/A                  |                             N/A                             |                                                        **NO**                                                        | **AVOID**                                                                                            |
| **Unlicensed (`No LICENSE file`)**                        | Unlicensed GitHub snippets/starters                                                                                              |    **NO (Default All Rights Reserved)**    |                **NO**                |                             N/A                             |                                                        **NO**                                                        | **AVOID**                                                                                            |

---

## 13. Recommended Technology Mapping & Development-Phase Guide

### 13.1 Capability-to-Tool Mapping

| Capability                            | Recommended Tool / Source                                                                                                                                                                                     | License          | When to Use                                                                                |
| :------------------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | :--------------- | :----------------------------------------------------------------------------------------- |
| **2D Editor Canvas**                  | `fabricjs/fabric.js` (`v7`, lazy-loaded)                                                                                                                                                                      | MIT              | Design Studio front/back garment customization (**Phase 2–3**)                             |
| **Object Transformation**             | Fabric.js native controls + `clipPath` print zones                                                                                                                                                            | MIT              | Selection, rotation, scaling, alignment inside `product_print_areas` (**Phase 2–3**)       |
| **Image Cropping**                    | `ValentinH/react-easy-crop`                                                                                                                                                                                   | MIT              | Customer upload pre-crop / aspect-ratio modal (**Phase 2–3**)                              |
| **Server Print & Mockup Compositing** | `lovell/sharp` + `fabric/node` (`StaticCanvas`)                                                                                                                                                               | Apache-2.0 / MIT | 300 DPI transparent PNG print files + layered 2D product mockups (**Phase 2–3**)           |
| **PSD Prep Utility (Offline)**        | `Agamnentzar/ag-psd`                                                                                                                                                                                          | MIT              | Admin/dev script to split licensed PSDs into PNG base/shadow/highlight masks (**Phase 2**) |
| **3D Rendering (Mode B Studio)**      | `mrdoob/three.js` + `pmndrs/react-three-fiber@9` + `drei`                                                                                                                                                     | MIT              | Interactive 3D T-shirt/Polo Mode B Studio via UV `CanvasTexture` (**Phase 3**)             |
| **UI Animation**                      | `motiondivision/motion` (`LazyMotion`)                                                                                                                                                                        | MIT              | Storefront drawers, modals, transitions, `prefers-reduced-motion` (**Phase 1–7**)          |
| **Icons**                             | `lucide-icons/lucide` (`lucide-react`, installed)                                                                                                                                                             | ISC              | Unified stroke icon set across Storefront, Studio, Creator & Admin (**Phase 0–8**)         |
| **Empty-State Illustrations**         | `Open Peeps` / `Humaaans` (CC0) + `unDraw` (UI only)                                                                                                                                                          | CC0 / Custom     | Empty cart, empty saved drafts, onboarding (**Phase 1–4**)                                 |
| **Fabric Textures & Tech Backdrops**  | `ambientCG` & `Poly Haven` (CC0) + `FFFuel` (UI backdrops)                                                                                                                                                    | CC0 / Custom     | Cotton/pique weave overlays, studio lighting HDRI, dark-blue tech UI grids (**Phase 1–8**) |
| **Apparel Mockups**                   | Owned in-house blank photography + CC0 `ambientCG` fabric overlays                                                                                                                                            | 100% Owned / CC0 | T-shirt & Polo front/back/color-tint previews (**Phase 1–3**)                              |
| **Fonts (EN + BN)**                   | `@fontsource/*`: `Space Grotesk`, `Plus Jakarta Sans`, `Barlow Condensed`, `Bebas Neue`, `Anton`, `Syne`, `JetBrains Mono` + `Noto Sans Bengali`, `Hind Siliguri`, `Anek Bangla`, `Baloo Da 2`, `Tiro Bangla` | SIL OFL 1.1      | Storefront, Marketplace, Design Studio & Server 300 DPI Print Parity (**Phase 1–3**)       |
| **Admin / Creator UI Reference**      | `satnaing/shadcn-admin` + `shadcn-ui/ui` + `TanStack/table`                                                                                                                                                   | MIT              | Creator Dashboard & Admin Moderation/Production/Payout portals (**Phase 4–6**)             |

### 13.2 Development-Phase Usage Guide

| Phase                                         | What to Use / Implement                                                                                                                                                                                                                                                                                | What to Keep Out / Defer                                                             |
| :-------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------- |
| **Phase 0 (Completed Baseline)**              | `lucide-react`, `motion` (`^14.14.0`), Tailwind CSS v4 tokens, `@fontsource` UI fonts, `@your-choice/ui`, `apps/web/public/brand/your-choice-logo.png` preserved                                                                                                                                       | Keep `fabric`, `sharp`, and `three` uninstalled until Phase 2–3                      |
| **Phase 1 (eCommerce Core & Auth)**           | Complete EN + BN i18n (`react-i18next`), `@tanstack/react-query`, `zustand`, `react-hook-form`, `@node-rs/argon2`, `Open Peeps`/`unDraw` empty states, owned T-Shirt/Polo catalog photos                                                                                                               | Defer Fabric.js, 3D engines, and PSD parsers                                         |
| **Phase 2 (2D Design Studio & Mockups)**      | `fabricjs/fabric.js` v7 (lazy chunk), `ValentinH/react-easy-crop`, `lovell/sharp` + `fabric/node` 300 DPI export, `@fontsource` Studio display fonts (`Bebas Neue`, `Anton`, `Barlow Condensed`, `Anek Bangla`, `Baloo Da 2`, `Tiro Bangla`), `ambientCG` cotton/pique overlays for 2D layered mockups | Keep 3D (`three`, `r3f`) gated for Phase 3; do not embed third-party Freepik mockups |
| **Phase 3 (Mode B — 3D Garment Studio)**      | Dynamically imported `three` (`r187`) + `@react-three/fiber@9` + `@react-three/drei` + clean-UV `.glb` T-shirt/Polo models + `Poly Haven` CC0 studio HDRI + real-time UV `CanvasTexture` sync                                                                                                          | Never run 3D inside main storefront landing bundle                                   |
| **Phase 4–5 (Marketplace & Creator Rewards)** | `satnaing/shadcn-admin` layout patterns + `TanStack/table` + `lucide-react` moderation/ledger views; immutable `Sharp` thumbnail previews                                                                                                                                                              | Do not load heavy animation libraries into Admin tables                              |
| **Phase 6–7 (Production, Payments & SEO)**    | `Sharp` production-ready 300 DPI PNG verification & archival; Fontsource local `.woff2` preloading for Core Web Vitals; `MotionConfig reducedMotion="user"` audit                                                                                                                                      | No unverified external CDNs                                                          |
