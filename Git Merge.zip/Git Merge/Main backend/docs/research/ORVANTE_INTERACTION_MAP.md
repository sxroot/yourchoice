# Orvante reference interaction map

**Reference:** [Orvante — Clothing](https://business.azryno.com/Orvante/)  
**Observed:** live browser inspection on desktop and a narrow mobile viewport; the repository's earlier [full viewport analysis](./UI_UX_LIVE_REFERENCE_ANALYSIS.md) records Playwright measurements at 1440×900, 1280×800, 768×1024, 390×844 and 360×800. The attached screenshots are preserved in [`orvante-reference/`](./orvante-reference/). They are supplied reference captures, not screenshots taken by the local verification browser.

## What the page does

| Scene | Observed behavior | YOUR CHOICE implementation |
|---|---|---|
| Hero | Asymmetric full-screen fashion portrait, oversized stacked title, floating pill navigation, smaller status and campaign cards, persistent bag count. On mobile the headline and portrait stack vertically and the nav condenses. | Dark photographic campaign hero with the official YOUR CHOICE logo in the existing site header, the exact tagline “Design it. Wear it. Earn from it.”, working Shop and Studio actions, and mobile-safe overlay cards. The existing authentication, locale and cart controls remain in the shared header. |
| Orbital corridor | A black, dotted, full-screen scene stays pinned while the scroll advances product cards around concentric rings. Product cards open the selected garment. | A pinned, scroll-progress-driven orbit uses Motion values for rotation, counter-rotation and halo scale. Cards link to live product or category routes. When catalog data is unavailable, the orbit presents named apparel shapes that link to the corresponding category rather than inventing product names or prices. |
| Arrivals | Four large product cards lead into a row of brand cards. Selecting a product opens a detailed quick-view with image navigation, sizes, quantity and commerce actions. | A horizontally scrollable editorial product rail uses `ProductCard` and the existing catalog DTOs. Each card links to the current product detail route. The site’s existing commerce/cart architecture owns purchase actions. A local quick-view was not added because the current storefront already has canonical PDP and cart flows. |
| Featured lookbook | A tall, pinned image story uses a translucent text band. Horizontal black shutter strips move away in alternating directions as the page scrolls and expose the image. | An original local campaign image is held in a pinned scene and uncovered by eleven alternating GPU transforms tied to section scroll progress. The shop link remains available while the image is revealed. |
| Shop grid | Dark product grid, category/price/colour/stock/rating filters, sort menu, discounts, review metadata and image hover states. On mobile filters open in a drawer and cards use two columns. Product selection opens the product detail quick-view. | The home experience previews actual catalog products and routes to the existing Shop filters, product pages and cart. No mock filters or sale metadata are generated on the homepage. |
| Garment rail | A light studio scene has a metal clothing rail. Selecting a hanging garment enlarges it and updates its name, colour and price. The rail is horizontally scrollable. | A real keyboard-operable selection rail is populated from the current catalog. Selecting an item updates the larger preview and its existing product/category link; previous/next buttons and native horizontal touch scrolling remain available. The shown price is taken from the product DTO. |
| Lower page | Footwear grid, studio/manifesto sections, partner content and a full-screen interactive footer follow the product scenes. | The YOUR CHOICE-specific category edit, working 2D/3D Studio route, health-status disclosure and existing global footer complete the page. No copied partner, review or footwear data is fabricated. |

## Evidence and limits

- The live reference was scrolled from the hero through orbit, arrivals, product detail, shop, garment rail and footwear. Product details opened and closed; the category filter reduced the observed result count from 15 to 3 and Clear All restored it; changing sort to price ascending reordered the first results. A garment selection changed the large rail preview and caption.
- The supplied five captures show hero, shop grid, shutter reveal, orbital cards and garment rail. Files are retained as reference-only evidence; none is shipped as a storefront asset.
- The live reference's exact scroll distances, easing equations and internal animation library were not established. Do not treat screenshot timing or the implementation choices below as claims about Orvante's source code.
- The local reference session was resized to a narrow viewport and verified to collapse to two-column catalog cards, compact navigation, full-width drawer filters and a swipeable rack. The existing viewport analysis documents additional device sizes. It reports a severe 7.47px text-size defect at 768px; YOUR CHOICE keeps its root font fixed and uses bounded `clamp()` scales.
- The observed product quick-view includes commerce actions. We did not submit a purchase or contact action on the reference.

## REA setup review

The official [REA repository](https://github.com/morluto/rea), [installation guide](https://github.com/morluto/rea/blob/main/docs/getting-started/installation.md) and [browser observation guide](https://github.com/morluto/rea/blob/main/docs/browser-observation.md) were reviewed. REA `6.9.0` was installed in a temporary directory only; no package, source code or configuration was added to YOUR CHOICE. The documented Node range is `^22.23.4 || ^24.22.1 || >=26.12.1`. The default Node was `v24.14.0`; the bundled `v24.22.1` runtime was used for REA's setup preview and browser captures.

REA's official `setup --client codex --dry-run --json` returned a plan with no applied actions. The plan contains two changes outside this repository:

1. Update `C:\Users\ADMiN\.codex\config.toml` to register REA as a Codex MCP server, preserving existing environment overrides and writing a backup at `C:\Users\ADMiN\.codex\config.toml.rea.backup`. The proposed command uses bundled Node `v24.22.1` and the script under `C:\Users\ADMiN\AppData\Local\Temp\rea-codex-preview-20261116\node_modules\rea-agents\scripts\rea.mjs`. That executable path is temporary, so this preview must not be applied as-is; a durable official installation and a fresh dry-run are needed first.
2. Install or update the bundled REA skill and references at `C:\Users\ADMiN\.agents\skills\reverse-engineer-anything`.

Neither change was applied. The Codex MCP registration and skill path are pending the user's review and approval; the project does not require either change to run.

REA's `capture-browser-scenario` capability was used with an isolated Chromium `157.0.8103.78` session at `1440×900`, with reduced motion disabled for the observation. It captured the reference hero, accessibility tree and DOM, then four successive PageDown states through the pinned corridor. Network request/response bodies and header values were not retained. The REA evidence IDs are `ev_15f783d02b2e2a6476d556bdad521131bdd29e27be2ff6a1fe71631da17a8ce8` (hero) and `ev_07b0c340bee6d6a06adfc4b1648ceab735063fe13f4c347394a0c872c94b46a1` (scroll sequence). Reproducible scenario inputs are in [`evidence/`](./evidence/).

## Motion and asset decisions

- Reuse the installed `motion` 14 package (MIT) and the existing `MotionProvider`; no animation dependency was added. Scroll scenes use Motion `useScroll`/`useTransform`; card reveals use the existing `Reveal` component; the product rail uses native overflow, scroll snap and transform-only selection states.
- Pinned orbit and shutter sections use compositor-friendly rotation, scale and translation. There is no scroll-event state update loop and no new WebGL renderer on the storefront. The real Three.js garment viewer remains lazy-loaded in the Design Studio where it adds actual value.
- The hero and shutter use the existing local campaign image at `apps/web/public/campaign/your-choice-hero.jpg`; below-fold campaign, product and catalog images load lazily. Product content and prices come from API DTOs. When the database is offline, category silhouettes are explicit entry points to Shop, not fake SKUs.
- Reduced-motion preference disables the pinned scroll progression and the shutter transition, leaving the complete scenes available as static content. Narrow screens reduce orbit card size, retain native touch scrolling on the garment rail, and avoid hover-only controls.
- No REA source, Orvante source, product photography or proprietary assets were copied into the application.

## Verification record

The reference interaction is evidenced by the supplied captures and the REA desktop screenshots below. The local implementation was then inspected in the running React/Vite app at `http://localhost:5173/`, with its Express API at port `4000`.

- `pnpm --filter @your-choice/web typecheck` and full `pnpm typecheck` passed.
- `pnpm lint` passed with one existing warning in `apps/web/src/features/design-studio/three/GarmentModel3D.tsx:241` about the `invalidate` dependency.
- `pnpm build` passed (`vite` completed in 4.54s). The build reports the lazy Three.js vendor chunk at about `1.06 MB`; the homepage does not initialize WebGL or load that chunk.
- Focused Chromium Playwright checks for `e2e/foundation.spec.ts` and `e2e/storefront-catalog.spec.ts` passed 4/4. The separate 390×844 responsive assertion also passed.
- Manual browser checks at desktop `1440×900` and mobile `390×844` confirmed the hero, tagline and primary links; scrolling through the orbit and alternating shutter reveal; changing the active garment in the rail (including its selected state, preview and `/shop/polo-shirts` link); and opening the mobile navigation. The measured mobile document width was `375px` in a `390px` viewport. The nav and product links load the existing app routes.
- The full home app and API were reachable (`5173` returned 200; `/api/v1/health` returned `degraded`). The catalog API returned 503 because MariaDB is down with `ECONNREFUSED`; the home therefore shows its explicit unavailable state/category shapes instead of live product cards. Opening `/studio` reaches the existing route, but its editor stays on “Preparing 2D Apparel Design Studio…” while the catalog query cannot complete. Real product/checkout flows and the live Design Studio editor could not be verified until MariaDB is running and seeded.
- No Lighthouse or frame-rate profile was run. The implementation adds no dependency, scroll scenes map scroll progress to Motion transforms, the rail uses native overflow, below-fold imagery is lazy, and the real Three.js viewer remains lazy inside the existing Studio route.

### Screenshot evidence

The supplied Orvante images are retained as reference-only files in [`orvante-reference/`](./orvante-reference/). REA added a live hero capture and four desktop scroll frames. These screenshots document the reference; they are not YOUR CHOICE assets.

| Reference scene | Supplied capture | REA live capture |
|---|---|---|
| Hero | [01](./orvante-reference/01-hero.png) | [06](./orvante-reference/06-rea-hero.png) |
| Orbit, first scroll | [04](./orvante-reference/04-orbital-products.png) | [08](./orvante-reference/08-rea-scroll-02.png) |
| Orbit, product cards moving | — | [09](./orvante-reference/09-rea-scroll-03.png), [10](./orvante-reference/10-rea-scroll-04.png) |
| Shutter / featured image | [03](./orvante-reference/03-shutter-reveal.png) | — |
| Product grid and clothing rail | [02](./orvante-reference/02-shop-grid.png), [05](./orvante-reference/05-garment-rail.png) | [07](./orvante-reference/07-rea-scroll-01.png) |

![REA live capture of the Orvante hero at 1440×900](./orvante-reference/06-rea-hero.png)

![REA live capture showing product cards moving around the pinned orbital corridor](./orvante-reference/09-rea-scroll-03.png)
