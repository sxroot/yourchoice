# Creator Marketplace & Reward Architecture (Phases 4–5 Scope)

> **Status:** Planned for Phases 4–5 — _Not implemented in Phase 0_

---

## 1. Marketplace Publication Workflow

1. Customer opts into Creator role on the same account (no duplicate user account required).
2. Creator selects eligible products, confirms artwork ownership/commercial license, accepts creator terms, and submits the design.
3. **Mandatory Admin Moderation**: Designs default to pending moderation and are **never** published automatically. Admin may approve, reject with feedback, request changes, suspend, or remove reported listings.

## 2. Configurable Reward & Immutable Ledger Model

1. **Configurable Rules (`creator_reward_rules`)**: Supports fixed reward, percentage commission, product-specific overrides, or hybrid rules configured via admin/database — never hardcoded rates.
2. **Eligibility Lifecycle**:
   `Pending` -> `Order Paid` -> `Order Fulfilled` -> `Return/Refund Window Elapsed` -> `Approved Reward` -> `Payable` -> `Paid`.
3. **Append-Only Ledger (`creator_reward_ledger`)**: Historical entries are immutable. Refunds, cancellations, disputes, or fraud reversals record compensating adjustment rows rather than mutating past entries.
4. **Payout Control**: Payout approval and execution require explicit admin review.
