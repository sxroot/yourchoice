# YOUR CHOICE — System Architecture & Master Source of Truth

> **Status:** Foundation & Phase A/B UI Shell Verified · **Phase 1 Ready (Pending Host Git + MariaDB Provisioning)**  
> **Architectural Style:** Modular Monolith (`apps/web` + `apps/api` + `packages/*` + `database/`) inside a `pnpm` TypeScript Workspace  
> **Brand Identity:** **YOUR CHOICE** (`allyourchoice.com`) — _Design it. Wear it. Earn from it._  
> **Target Market:** Bangladesh (`BDT` primary currency; English + Bangla multilingual support)  
> **Official Specs:** [ARCHITECTURE_DECISIONS.md](decisions/ARCHITECTURE_DECISIONS.md) · [TECHNOLOGY_SELECTION.md](TECHNOLOGY_SELECTION.md) · [TECHNOLOGY_STACK.md](architecture/TECHNOLOGY_STACK.md) · [PHASE_1_ARCHITECTURE.md](architecture/PHASE_1_ARCHITECTURE.md)

---

## 1. Initial Repository Audit & Current Baseline (`d:\Antigravity\Your Choice`)

| Audit Dimension            | Current State (`2026-11-15`)                                                                                                                          |
| :------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Monorepo Workspace**     | `pnpm@10.33.0`, Node `v24.14.0`, TypeScript `5.9.3` strict mode (`noUncheckedIndexedAccess`, `tsc -b` project references)                             |
| **Frontend (`apps/web`)**  | React `19.3.1`, Vite `8.3.8`, React Router `7.18.5`, Tailwind CSS v4 (`tokens.css` + `@theme`), `@your-choice/ui` (15 Radix primitives), `motion` v14 |
| **Backend (`apps/api`)**   | Express `5.3.0` ESM, Zod `4.6.7` env/middleware validation, Pino `10.4.0` + `pino-http` redaction, `helmet`, `cors`, `/api/health`, `/api/v1/health`  |
| **Database (`database/`)** | Drizzle ORM `0.45.4` (`drizzle-orm/mysql2`) + `mysql2` `3.24.6` (**MIT**), `system_settings` schema + `0000_living_toro.sql` migration + seed script  |
| **Host Prerequisites Gap** | `git`, `mysql`/`mariadb`, and `docker` missing from `PATH`; `.git` and `.env` absent; `127.0.0.1:3306` closed (live DB migrations still unverified)   |
| **Business Domains**       | 16 backend modules (`apps/api/src/modules/*`) and 8 frontend features (`apps/web/src/features/*`) intentionally staged as `.gitkeep` scaffolds        |

---

## 2. Core Architectural Principles

1. **Modular Monolith Backend (`apps/api`):** All business domains reside inside one deployable Express 5 application under `apps/api/src/modules/<domain>/` with explicit TypeScript service interfaces. Cross-module invariants (e.g., order confirmation + inventory reservation + immutable `order_designs` snapshot + payment verification + append-only reward ledger entries) execute inside single MariaDB transactions without microservice complexity.
2. **Independent Frontend & Backend Applications:** `apps/web` (React + Vite) and `apps/api` (Express 5) build, test, and run independently (`pnpm --filter @your-choice/web dev` and `pnpm --filter @your-choice/api dev`).
3. **Strict Client/Server Boundary:**
   - `packages/shared-types`, `packages/validation`, `packages/shared-utils`, and `packages/ui` MUST remain strictly browser-safe and never import server-only dependencies (`mysql2`, `node:fs`, `pino`, `dotenv`, secrets).
   - Database schemas live in `database/schema/` (`@your-choice/database`) and are imported only by `apps/api` and CLI migration/seed scripts.
4. **Configurable Business Rules:** Platform rules (base currency, studio default DPI, moderation policy, commission/reward rules, shipping/tax rules) live in database tables (`system_settings`, `creator_reward_rules`) rather than hardcoded constants.
5. **Security & IP Protection by Design:** Authoritative pricing, RBAC/ownership checks, private raw asset keys, watermarked preview derivation, and server-side `300 DPI` print generation stay exclusively in `apps/api` and private storage ([RENDERING_AND_IP_PROTECTION.md](architecture/RENDERING_AND_IP_PROTECTION.md)).

---

## 3. Runtime Topology & MariaDB Compatibility

```text
Browser (apps/web — React 19 + Vite 8 + Tailwind CSS v4 + @your-choice/ui + MotionProvider)
   │  HTTP / REST JSON (/api/v1/*)
   ▼
Express 5 API (apps/api — TypeScript ESM Modular Monolith)
   ├─ Middleware: requestContext -> pino-http -> helmet -> cors -> express.json -> rateLimit (Ph 1+) -> zod validate -> auth/rbac (Ph 1+) -> errorHandler
   ├─ Active Module (Phase 0): health (/api/health, /api/v1/health, /live, /ready)
   ├─ Planned Modules (Phases 1–6): auth, users, categories, products, cart, orders,
   │                                designs, marketplace, creators, payments, rewards,
   │                                production, inventory, shipping, notifications, admin
   └─ Persistence: Drizzle ORM (drizzle-orm/mysql2) + mysql2 Pool (UTF8MB4 / UTC) ──► MariaDB 10.11+
                                                                                       ├─ StorageService (local -> S3/MinIO)
                                                                                       └─ Redis + BullMQ (async print/jobs, Ph 2+)
```

### MariaDB 10.11+ Connection & Dialect Guardrails

- **Driver Choice:** Use `drizzle-orm/mysql2` + `mysql2` (**MIT** license), avoiding `mariadb-connector-nodejs` (**LGPL-2.1**). Configure `charset: 'utf8mb4'` and `timezone: 'Z'` consistently across `apps/api` and `database/scripts/`.
- **Non-Blocking Startup Probe:** Initial `pingDatabase()` runs inside `app.listen()` with `connectTimeout: 2000` so `/api/health` (`degraded` / `healthy`) and `/api/health/live` respond immediately even if MariaDB is restarting.
- **SQL Compatibility:** `drizzle-kit` targets `dialect: 'mysql'`; inspect generated SQL in `database/migrations/` before `pnpm db:migrate`. Use MariaDB-compatible `DATETIME(3)` UTC defaults, explicit `idx_<table>_<col>` B-tree indexes, and `VALUES(col)` in `onDuplicateKeyUpdate` (avoiding MySQL-8-only syntax).

---

## 4. Reconciled Phased Development Sequence

> **Synchronization Rule:** Dual-Mode Design Studio (`Mode A: 2D Fabric.js` + `Mode B: 3D Three.js/R3F`) is unified across **Phases 2–3** per [DESIGN_STUDIO_ARCHITECTURE.md](architecture/DESIGN_STUDIO_ARCHITECTURE.md). No stale "Phase 8+" 3D deferrals remain in active architecture plans. Frontend feature UI rolls out **strictly alongside** its corresponding backend module.

| Phase                | Backend & Data Scope                                                                                                                                    | Frontend & UX Scope                                                                                                  | Key Architecture Guardrails                                                           |
| :------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------ | :------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------ |
| **Phase 0 + A/B**    | Workspace, Express 5 + Pino + Zod, Drizzle + `system_settings` (`0000` SQL + seed), `/health`                                                           | Brand tokens (`tokens.css` + `index.css`), `@your-choice/ui` (15 primitives), `MotionProvider`, shell, QA Playwright | **Done** (`npm` / `pnpm` checks pass; live DB execution pending MariaDB provisioning) |
| **Phase 1**          | Custom MariaDB session auth (`@node-rs/argon2` + RBAC + CSRF + rate limit), categories, T-Shirts & Polo Shirts, variants, print areas, cart, COD orders | Auth flows, EN/BN i18n, editorial Storefront `/`, `/shop`, `/product/:slug`, Cart Drawer, `/checkout`, Admin Catalog | Blueprint in [PHASE_1_ARCHITECTURE.md](architecture/PHASE_1_ARCHITECTURE.md)          |
| **Phase 2 (Mode A)** | Private upload security (`file-type`, Sharp EXIF/bounds, StorageService), `CanonicalDesignDocument`, `designs` / `design_versions`, `300 DPI` PNG       | Lazy-loaded Fabric.js v7 2D Studio (`/design-studio/:productId`), crop modal, EN/BN studio fonts, DPI warnings       | Immutable uploads in `private/uploads/`; server-rendered `300 DPI` print PNGs only    |
| **Phase 3 (Mode B)** | Blank `.glb` asset metadata, variant/print-zone UV mapping metadata, immutable `order_designs` checkout snapshots & customization pricing               | Lazy-loaded Three.js + R3F v9 3D Garment Studio (`CanvasTexture` on UV print islands) synced 1:1 with Mode A         | Never treat `DecalGeometry` cloth stretch as print truth; never mutate past orders    |
| **Phase 4**          | Creator opt-in, submission/review APIs, **mandatory admin moderation** (`PENDING_REVIEW` -> `APPROVED`), reporting/takedown, watermarked mockups        | `/marketplace`, `/marketplace/:designSlug`, `/creators/:username`, base-switcher (`Tee` <-> `Polo`), Admin Review UI | Designs never publish without explicit admin approval; clean masters stay server-side |
| **Phase 5**          | Configurable `creator_reward_rules`, eligibility state machine (`Pending`..`Paid`), append-only `creator_reward_ledger`, admin payout workflow          | Creator Dashboard (`/creator/*`) earnings, moderation queue status, ledger history, payout request UI                | Financial math via `DECIMAL(12,2)` + `BigInt`; ledger rows are append-only (no edits) |
| **Phase 6**          | Atomic `inventory_items` reservation (`stock_movements`), `production_jobs` (Freesub heat press / DTF), `quality_checks` gate, courier adapter          | Admin Operations & Production QC queues (`satnaing/shadcn-admin` + TanStack Table patterns)                          | Block `Ready to Ship` until QC passes; prevent negative available stock in DB         |
| **Phase 7**          | Verified `bKash` / `Nagad` / `SSLCommerz` webhooks with idempotency keys, SEO SSR evaluation (`@react-router/express`), backups, security hardening     | Public catalog SSR + `<ClientOnly>` Studio isolation, sitemaps, Schema.org JSON-LD, full E2E verification            | Idempotent payment state transitions; zero secret/master leakage in SSR payloads      |

---

## 5. Locked Technical Decisions Summary (Pre-Phase 1)

Full ADR rationale and trade-offs are recorded in [ARCHITECTURE_DECISIONS.md](decisions/ARCHITECTURE_DECISIONS.md) (`ADR-001` through `ADR-014`):

1. **IDs & Identifiers (`ADR-009`):** `BIGINT UNSIGNED AUTO_INCREMENT` internal PKs/FKs + `CHAR(36)` `public_id` (UUID) for users/designs/assets/orders, URL `slug` for catalog/marketplace, and formatted `order_number` (never expose sequential internal IDs publicly).
2. **Currency (`ADR-010`):** Single active MVP currency **`BDT`**, persisted with `DECIMAL(12, 2)` + explicit `currency_code CHAR(3) DEFAULT 'BDT'` columns across commercial/ledger tables so future multi-currency requires zero destructive table rewrites; all arithmetic via `BigInt` minor units (`paisa`).
3. **Soft Deletion & Immutability (`ADR-011`):** `deleted_at DATETIME(3) NULL` on mutable entities (`users`, `products`, `product_variants`, `designs`, `creator_profiles`, `marketplace_listings`); strict immutability + `ON DELETE RESTRICT` on `orders`, `order_items`, `order_designs`, `payment_transactions`, `creator_reward_ledger`, `audit_logs`. Deleted slugs/emails remain reserved (`tombstoned`).
4. **Local MariaDB Strategy (`ADR-012`):** Support both Docker Compose ([docker-compose.mariadb.yml](../infrastructure/docker/docker-compose.mariadb.yml)) and native Windows MariaDB `10.11+`. Provisioning live MariaDB + passing `pnpm db:migrate && pnpm db:seed` is the first mandatory gate before writing Phase 1 tables.
5. **Private Asset Storage (`ADR-013`):** Implement a `StorageService` interface backed by `STORAGE_DRIVER=local` (writing outside `apps/web/public/` with short-lived HMAC signed API download URLs) and `STORAGE_DRIVER=s3` (`@aws-sdk/client-s3` + presigner for S3/R2/MinIO in production) using identical object prefixes (`public/catalog/`, `public/garments-3d/`, `private/uploads/`, `private/creator-masters/`, `private/print-masters/`).
6. **UI & Motion Direction (`ADR-014`):** Preserve `@your-choice/ui` + `MotionProvider` (`LazyMotion strict`) and the light-first canvas (`#f8fafc` / `#ffffff`) + obsidian/charcoal dark bands (`#06080d` / `#111622`) with **Royal Blue / Electric Blue / Cyan / Silver** tokens—balancing `Orvante`-inspired editorial pacing & crisp tactile interaction without copying external templates or drifting from the official logo identity. Gate `/design-system` before production commerce routes ship.
