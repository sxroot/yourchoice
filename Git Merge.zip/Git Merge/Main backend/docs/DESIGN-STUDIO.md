# Native Design Studio Blueprint (Phase 2–3 Dual-Mode Scope)

> **Status:** Architecture Specification for Phases 2–3 — _Not implemented in Phase 0_  
> **Mode A (2D Editor):** Fabric.js v6/v7 (MIT, lazy-loaded client island)  
> **Mode B (3D Configurator):** Three.js + React Three Fiber v9 + `@react-three/drei` (MIT, glTF/GLB + Draco/KTX2, dedicated UV-island `CanvasTexture`)  
> **Server Print Engine:** Sharp (Apache-2.0, `300 DPI` transparent PNG export)  
> **Full Addendum Specs:** [DESIGN_STUDIO_ARCHITECTURE.md](architecture/DESIGN_STUDIO_ARCHITECTURE.md) · [RENDERING_AND_IP_PROTECTION.md](architecture/RENDERING_AND_IP_PROTECTION.md) · [DESIGN_STUDIO_TECHNOLOGY_DECISIONS.md](decisions/DESIGN_STUDIO_TECHNOLOGY_DECISIONS.md)

---

## 1. Core Architectural Guardrails

1. **Configurable Print Areas**: Print dimensions (e.g., `12" x 16"` front/back) and offsets MUST come from `product_print_areas` per product/variant, never hardcoded globally.
2. **Canonical Document vs. Mode State vs. Print Output**:
   - **Canonical Design Document**: Normalized `[0..1]` print-area-relative JSON persisted in `designs` / `design_versions` / `design_objects`, decoupled from ephemeral Fabric.js or Three.js scene objects.
   - **Dual-Mode Rendering**: Mode A (2D) edits directly on Fabric.js; Mode B (3D) maps the same surface textures via `THREE.CanvasTexture` onto distortion-controlled print-zone UV islands (avoiding `DecalGeometry` cloth distortion as the primary garment print engine).
   - **Original Uploaded Assets**: Validated via magic bytes (`file-type`), stripped/re-encoded server-side, and stored unaltered in private S3-compatible object storage (`private/uploads/`).
   - **Preview Images**: Downscaled/watermarked raster previews for fast storefront/cart/marketplace display.
   - **Print-Ready Files**: Server-rendered high-resolution files (`3600 x 4800 px` at `300 DPI` for a `12" x 16"` print area, PNG with transparent background) generated strictly server-side into private `private/print-masters/` storage and never exposed to buyer browsers.
3. **Immutability on Order**: Checking out a custom design creates an immutable design version snapshot (`order_designs`) so subsequent draft edits never mutate past orders.
4. **Validation**: Validate image resolution/DPI warnings, file signatures (magic bytes), print-area clipping boundaries, supported fonts, and missing asset references prior to checkout or marketplace submission.
