# Development & Deployment Guide

---

## 1. Prerequisites

- **Node.js**: LTS `20.x` or `24.x` (verified locally on `v24.14.0`)
- **pnpm**: `10.x` (verified locally on `10.33.0`)
- **MariaDB**: `10.11+` (local service, Docker container, or remote MariaDB server)
- **Git**: Recommended for version control

---

## 2. Local Development Setup

### Step 1: Install Workspace Dependencies

```bash
pnpm install
```

### Step 2: Configure Environment Variables

Copy `.env.example` to `.env` at the repository root and update database credentials:

```bash
cp .env.example .env
```

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

### Step 3: Provision MariaDB Database

Create a local database and user in MariaDB 10.11+:

```sql
CREATE DATABASE IF NOT EXISTS your_choice_dev
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'your_choice_dev'@'localhost'
  IDENTIFIED BY 'change_me_local_dev_password';

GRANT ALL PRIVILEGES ON your_choice_dev.* TO 'your_choice_dev'@'localhost';
FLUSH PRIVILEGES;
```

### Step 4: Build Shared Packages & Apply Initial Migration

```bash
pnpm build:packages
pnpm db:migrate
pnpm db:seed
```

### Step 5: Run Development Servers

```bash
pnpm dev
```

- **Frontend (`apps/web`)**: `http://localhost:5173`
- **Backend API (`apps/api`)**: `http://localhost:4000`
- **Health Check**: `GET http://localhost:4000/api/v1/health`

---

## 3. Quality Verification Commands

```bash
pnpm typecheck
pnpm lint
pnpm test
pnpm build
```

---

## 4. Production Deployment Architecture (Target)

```text
Internet (HTTPS / TLS)
   │
   ▼
Nginx Reverse Proxy
   ├── Static React SPA (apps/web/dist)
   └── Node.js Process Manager (PM2 / systemd) -> Express API (apps/api/dist)
          ├── MariaDB 10.11+ (automated daily backups + pre-migration snapshots)
          ├── S3-Compatible Object Storage (assets, previews, 300 DPI print files)
          └── Redis + BullMQ (optional background workers)
```

### Production Guardrails

- Never commit `.env` files, payment gateway keys, or database credentials.
- Run `pnpm db:migrate` only after taking a verified database backup.
- Keep `NODE_ENV=production`, strong `SESSION_SECRET` (minimum 32 random bytes), strict `CORS_ORIGINS`, and `TRUST_PROXY=true` when behind Nginx.
