# Database Architecture & Migration Strategy

> **Engine:** MariaDB 10.11+  
> **ORM & Migrations:** Drizzle ORM (`drizzle-orm/mysql2`) + Drizzle Kit (`drizzle-kit`)  
> **Schema Location:** `database/schema/`  
> **Migration Files:** `database/migrations/`

---

## 1. Core Database Conventions

1. **Financial Precision**: All monetary amounts, prices, discounts, commissions, and ledger entries MUST use `DECIMAL(12, 2)` (or higher precision if needed for rates such as `DECIMAL(5, 2)`), **never** `FLOAT` or `DOUBLE`.
2. **Timestamps**: All tables include explicit `created_at` and `updated_at` columns stored in UTC (`TIMESTAMP` / `DATETIME(3)`).
3. **Referential Integrity**: Every cross-table relation uses explicit foreign keys, named indexes on foreign keys and hot query columns, and strict transactional boundaries for multi-table writes.
4. **Migrations**: Every schema change MUST be authored in `database/schema/*.ts`, generated via `pnpm db:generate`, inspected in `database/migrations/*.sql`, and applied via `pnpm db:migrate`. Never run destructive schema changes without an explicit migration and verified backup.
5. **Immutable Records**:
   - `order_designs` / checkout snapshots remain immutable after order confirmation.
   - `creator_reward_ledger` uses append-only adjustment transactions — historical entries are never silently edited.
6. **Locked Domain Conventions (`ADR-009` to `ADR-011`)**:
   - **Hybrid Keys (`ADR-009`):** Internal `BIGINT UNSIGNED AUTO_INCREMENT` PKs + external URL-safe `public_id` / `slug` / `order_number` identifiers.
   - **Currency (`ADR-010`):** `BDT` primary (`currency_code CHAR(3) DEFAULT 'BDT'` + `DECIMAL(12, 2)`).
   - **Deletion Policy (`ADR-011`):** `deleted_at` soft delete on catalog/design entities; hard-preserve commercial, financial, and audit records (`orders`, `order_items`, `order_designs`, `creator_reward_ledger`, `audit_logs`).
   - Full Phase 1 ER diagram and table contracts are specified in [`PHASE_1_ARCHITECTURE.md`](architecture/PHASE_1_ARCHITECTURE.md).

---

## 2. Phase 0 Schema Scope

To avoid locking potentially irreversible domain decisions (such as domain primary key type or currency strategy) before confirmation, Phase 0 introduces only the foundational configuration table:

### `system_settings`

Stores dynamic, database-backed configuration rules so platform behavior does not depend on hardcoded constants.

| Column        | Type                                       | Purpose                                                                   |
| :------------ | :----------------------------------------- | :------------------------------------------------------------------------ |
| `setting_key` | `VARCHAR(128)` (PK)                        | Dot-namespaced setting identifier (e.g. `platform.brand_name`)            |
| `category`    | `VARCHAR(64)`                              | Logical group (`platform`, `commerce`, `studio`, `rewards`, `production`) |
| `value_json`  | `JSON`                                     | Structured JSON configuration payload                                     |
| `value_type`  | `ENUM('string','number','boolean','json')` | Runtime validation hint                                                   |
| `description` | `VARCHAR(500)`                             | Human-readable explanation for admin UI                                   |
| `is_public`   | `BOOLEAN`                                  | Whether safe to expose to unauthenticated storefront clients              |
| `created_at`  | `TIMESTAMP(3)`                             | Record creation timestamp                                                 |
| `updated_at`  | `TIMESTAMP(3)`                             | Last update timestamp                                                     |

---

## 3. Planned Domain Tables (Phases 1–6)

Per Master Specification Section 7:

- **Identity (Phase 1)**: `users`, `user_profiles`, `user_addresses`, `roles`, `permissions`, `role_permissions`, `user_roles`, `sessions`
- **Products & Inventory (Phase 1 & 6)**: `products`, `product_categories`, `product_images`, `product_variants`, `product_attributes`, `product_attribute_values`, `product_print_areas`, `inventory_items`, `stock_movements`, `suppliers`
- **Design Studio (Phase 2)**: `designs`, `design_versions`, `design_assets`, `design_objects`, `design_previews`
- **Marketplace (Phase 4)**: `creator_profiles`, `marketplace_listings`, `design_submissions`, `design_reviews`, `design_reports`
- **Commerce & Payments (Phase 1, 3, 7)**: `carts`, `cart_items`, `orders`, `order_items`, `order_designs`, `order_status_history`, `payment_transactions`, `payment_webhooks`, `refunds`
- **Rewards (Phase 5)**: `creator_reward_rules`, `creator_rewards`, `creator_reward_ledger`, `creator_payouts`
- **Production & Shipping (Phase 6)**: `production_jobs`, `production_files`, `production_materials`, `quality_checks`, `production_status_history`, `shipments`, `shipment_events`, `courier_providers`
- **Administration**: `admin_users`, `audit_logs`, `notifications`, `coupons`, `system_settings`, `content_pages`, `seo_meta`
