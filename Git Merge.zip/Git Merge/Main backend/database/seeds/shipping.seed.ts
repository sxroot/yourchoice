import { sql } from 'drizzle-orm';
import type { MySql2Database } from 'drizzle-orm/mysql2';
import type * as schema from '../schema/index.js';
import { shippingZones } from '../schema/index.js';
import { SHIPPING_ZONE_SEED_DATA } from '../shipping-seed-data.js';

export interface ShippingSeedSummary {
  zonesUpserted: number;
}

export async function seedShippingZones(
  db: MySql2Database<typeof schema>
): Promise<ShippingSeedSummary> {
  for (const zone of SHIPPING_ZONE_SEED_DATA) {
    await db
      .insert(shippingZones)
      .values({
        publicId: zone.publicId,
        code: zone.code,
        nameEn: zone.nameEn,
        nameBn: zone.nameBn,
        divisionsJson: [...zone.divisions],
        flatFee: zone.flatFee,
        freeShippingThreshold: zone.freeShippingThreshold,
        estimatedDaysMin: zone.estimatedDaysMin,
        estimatedDaysMax: zone.estimatedDaysMax,
        currencyCode: 'BDT',
        sortOrder: zone.sortOrder,
        isActive: true,
      })
      .onDuplicateKeyUpdate({
        set: {
          nameEn: sql`VALUES(name_en)`,
          nameBn: sql`VALUES(name_bn)`,
          divisionsJson: sql`VALUES(divisions_json)`,
          flatFee: sql`VALUES(flat_fee)`,
          freeShippingThreshold: sql`VALUES(free_shipping_threshold)`,
          estimatedDaysMin: sql`VALUES(estimated_days_min)`,
          estimatedDaysMax: sql`VALUES(estimated_days_max)`,
          sortOrder: sql`VALUES(sort_order)`,
          isActive: true,
        },
      });
  }

  return {
    zonesUpserted: SHIPPING_ZONE_SEED_DATA.length,
  };
}
