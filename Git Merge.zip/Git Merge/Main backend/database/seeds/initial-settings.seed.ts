import { sql } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/mysql2';
import { openDatabaseConnection } from '../scripts/connection.js';
import * as schema from '../schema/index.js';
import { type NewSystemSettingRow, systemSettings } from '../schema/index.js';
import { seedApparelCatalog } from './catalog.seed.js';
import { seedRbacCatalog } from './rbac.seed.js';
import { seedShippingZones } from './shipping.seed.js';

const INITIAL_SETTINGS: NewSystemSettingRow[] = [
  {
    settingKey: 'platform.brand_name',
    category: 'platform',
    valueJson: 'YOUR CHOICE',
    valueType: 'string',
    description: 'Public display name of the platform.',
    isPublic: true,
  },
  {
    settingKey: 'platform.tagline',
    category: 'platform',
    valueJson: 'Design it. Wear it. Earn from it.',
    valueType: 'string',
    description: 'Primary brand tagline.',
    isPublic: true,
  },
  {
    settingKey: 'studio.default_dpi',
    category: 'studio',
    valueJson: 300,
    valueType: 'number',
    description: 'Default export DPI target for print-ready production files.',
    isPublic: false,
  },
  {
    settingKey: 'marketplace.require_admin_moderation',
    category: 'marketplace',
    valueJson: true,
    valueType: 'boolean',
    description: 'Require explicit admin approval before submitted designs appear publicly.',
    isPublic: false,
  },
];

async function main(): Promise<void> {
  const connection = await openDatabaseConnection();

  try {
    const db = drizzle(connection, { schema, mode: 'default' });

    for (const row of INITIAL_SETTINGS) {
      await db
        .insert(systemSettings)
        .values(row)
        .onDuplicateKeyUpdate({
          set: {
            category: sql`VALUES(category)`,
            description: sql`VALUES(description)`,
            isPublic: sql`VALUES(is_public)`,
          },
        });
    }

    const rbacSummary = await seedRbacCatalog(db);
    const catalogSummary = await seedApparelCatalog(db);
    const shippingSummary = await seedShippingZones(db);

    console.info(
      `[db:seed] Upserted ${INITIAL_SETTINGS.length} initial system settings, RBAC catalog (${rbacSummary.rolesUpserted} roles, ${rbacSummary.permissionsUpserted} permissions, ${rbacSummary.grantsEnsured} grants), apparel catalog (${catalogSummary.categoriesUpserted} categories, ${catalogSummary.productsUpserted} products, ${catalogSummary.variantsUpserted} variants, ${catalogSummary.printAreasUpserted} print areas), and shipping zones (${shippingSummary.zonesUpserted} zones).`
    );
  } finally {
    await connection.end();
  }
}

main().catch((error: unknown) => {
  console.error('[db:seed] Seed failed:', error);
  process.exitCode = 1;
});
