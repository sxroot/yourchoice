import { inArray, sql } from 'drizzle-orm';
import type { MySql2Database } from 'drizzle-orm/mysql2';
import type * as schema from '../schema/index.js';
import { permissions, rolePermissions, roles } from '../schema/index.js';
import { DEFAULT_PERMISSIONS, DEFAULT_ROLES } from '../rbac-catalog.js';

/**
 * Idempotently seeds canonical RBAC roles, permissions, and role-permission grants.
 */
export async function seedRbacCatalog(db: MySql2Database<typeof schema>): Promise<{
  rolesUpserted: number;
  permissionsUpserted: number;
  grantsEnsured: number;
}> {
  for (const role of DEFAULT_ROLES) {
    await db
      .insert(roles)
      .values({
        code: role.code,
        name: role.name,
        description: role.description,
        isSystem: true,
      })
      .onDuplicateKeyUpdate({
        set: {
          name: sql`VALUES(name)`,
          description: sql`VALUES(description)`,
          isSystem: sql`VALUES(is_system)`,
        },
      });
  }

  for (const permission of DEFAULT_PERMISSIONS) {
    await db
      .insert(permissions)
      .values({
        code: permission.code,
        module: permission.module,
        description: permission.description,
      })
      .onDuplicateKeyUpdate({
        set: {
          module: sql`VALUES(module)`,
          description: sql`VALUES(description)`,
        },
      });
  }

  const roleRows = await db
    .select()
    .from(roles)
    .where(
      inArray(
        roles.code,
        DEFAULT_ROLES.map((r) => r.code)
      )
    );
  const permissionRows = await db
    .select()
    .from(permissions)
    .where(
      inArray(
        permissions.code,
        DEFAULT_PERMISSIONS.map((p) => p.code)
      )
    );

  const roleIdByCode = new Map(roleRows.map((row) => [row.code as string, row.id]));
  const permissionIdByCode = new Map(permissionRows.map((row) => [row.code, row.id]));

  const grantPairs: Array<{ roleId: number; permissionId: number }> = [];

  for (const roleDef of DEFAULT_ROLES) {
    const roleId = roleIdByCode.get(roleDef.code);
    if (!roleId) {
      continue;
    }

    for (const permissionCode of roleDef.permissions) {
      const permissionId = permissionIdByCode.get(permissionCode);
      if (!permissionId) {
        continue;
      }
      grantPairs.push({ roleId, permissionId });
    }
  }

  if (grantPairs.length > 0) {
    await db
      .insert(rolePermissions)
      .values(grantPairs)
      .onDuplicateKeyUpdate({
        set: {
          roleId: sql`VALUES(role_id)`,
        },
      });
  }

  return {
    rolesUpserted: DEFAULT_ROLES.length,
    permissionsUpserted: DEFAULT_PERMISSIONS.length,
    grantsEnsured: grantPairs.length,
  };
}
