import { eq, sql } from 'drizzle-orm';
import type { MySql2Database } from 'drizzle-orm/mysql2';
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS } from '../catalog-seed-data.js';
import type * as schema from '../schema/index.js';
import {
  productCategories,
  productImages,
  productPrintAreas,
  productVariants,
  products,
} from '../schema/index.js';

/**
 * Idempotently seeds baseline T-Shirt & Polo Shirt categories, products, variants, images,
 * and editor-agnostic front/back/left-chest print areas.
 */
export async function seedApparelCatalog(db: MySql2Database<typeof schema>): Promise<{
  categoriesUpserted: number;
  productsUpserted: number;
  variantsUpserted: number;
  printAreasUpserted: number;
}> {
  for (const category of INITIAL_CATEGORIES) {
    await db
      .insert(productCategories)
      .values({
        publicId: category.publicId,
        slug: category.slug,
        nameEn: category.nameEn,
        nameBn: category.nameBn,
        descriptionEn: category.descriptionEn,
        descriptionBn: category.descriptionBn,
        sortOrder: category.sortOrder,
        isActive: true,
      })
      .onDuplicateKeyUpdate({
        set: {
          nameEn: sql`VALUES(name_en)`,
          nameBn: sql`VALUES(name_bn)`,
          descriptionEn: sql`VALUES(description_en)`,
          descriptionBn: sql`VALUES(description_bn)`,
          sortOrder: sql`VALUES(sort_order)`,
          isActive: true,
        },
      });
  }

  let variantsUpserted = 0;
  let printAreasUpserted = 0;

  for (const product of INITIAL_PRODUCTS) {
    const [categoryRow] = await db
      .select({ id: productCategories.id })
      .from(productCategories)
      .where(eq(productCategories.slug, product.categorySlug))
      .limit(1);

    if (!categoryRow) {
      throw new Error(`Missing seeded category "${product.categorySlug}" for "${product.slug}"`);
    }

    await db
      .insert(products)
      .values({
        publicId: product.publicId,
        categoryId: categoryRow.id,
        slug: product.slug,
        skuPrefix: product.skuPrefix,
        nameEn: product.nameEn,
        nameBn: product.nameBn,
        subtitleEn: product.subtitleEn,
        subtitleBn: product.subtitleBn,
        descriptionEn: product.descriptionEn,
        descriptionBn: product.descriptionBn,
        fabricSpecEn: product.fabricSpecEn,
        fabricSpecBn: product.fabricSpecBn,
        gsm: product.gsm,
        fitType: product.fitType,
        basePrice: product.basePrice,
        currencyCode: 'BDT',
        isCustomizable: product.isCustomizable,
        status: product.status,
        featuredOrder: product.featuredOrder,
      })
      .onDuplicateKeyUpdate({
        set: {
          categoryId: categoryRow.id,
          nameEn: sql`VALUES(name_en)`,
          nameBn: sql`VALUES(name_bn)`,
          subtitleEn: sql`VALUES(subtitle_en)`,
          subtitleBn: sql`VALUES(subtitle_bn)`,
          descriptionEn: sql`VALUES(description_en)`,
          descriptionBn: sql`VALUES(description_bn)`,
          fabricSpecEn: sql`VALUES(fabric_spec_en)`,
          fabricSpecBn: sql`VALUES(fabric_spec_bn)`,
          gsm: sql`VALUES(gsm)`,
          fitType: sql`VALUES(fit_type)`,
          basePrice: sql`VALUES(base_price)`,
          isCustomizable: sql`VALUES(is_customizable)`,
          status: sql`VALUES(status)`,
          featuredOrder: sql`VALUES(featured_order)`,
        },
      });

    const [productRow] = await db
      .select({ id: products.id })
      .from(products)
      .where(eq(products.slug, product.slug))
      .limit(1);

    if (!productRow) {
      continue;
    }

    for (const image of product.images) {
      await db
        .insert(productImages)
        .values({
          publicId: image.publicId,
          productId: productRow.id,
          variantId: null,
          viewType: image.viewType,
          url: image.url,
          altTextEn: image.altTextEn,
          altTextBn: image.altTextBn,
          sortOrder: image.sortOrder,
          isPrimary: image.isPrimary,
        })
        .onDuplicateKeyUpdate({
          set: {
            url: sql`VALUES(url)`,
            altTextEn: sql`VALUES(alt_text_en)`,
            altTextBn: sql`VALUES(alt_text_bn)`,
            sortOrder: sql`VALUES(sort_order)`,
            isPrimary: sql`VALUES(is_primary)`,
          },
        });
    }

    for (const variant of product.variants) {
      await db
        .insert(productVariants)
        .values({
          publicId: variant.publicId,
          productId: productRow.id,
          sku: variant.sku,
          colorNameEn: variant.colorNameEn,
          colorNameBn: variant.colorNameBn,
          colorHex: variant.colorHex,
          sizeCode: variant.sizeCode,
          priceOverride: variant.priceOverride,
          currencyCode: 'BDT',
          stockQuantity: variant.stockQuantity,
          isActive: true,
        })
        .onDuplicateKeyUpdate({
          set: {
            colorNameEn: sql`VALUES(color_name_en)`,
            colorNameBn: sql`VALUES(color_name_bn)`,
            colorHex: sql`VALUES(color_hex)`,
            sizeCode: sql`VALUES(size_code)`,
            priceOverride: sql`VALUES(price_override)`,
            stockQuantity: sql`VALUES(stock_quantity)`,
            isActive: true,
          },
        });
      variantsUpserted += 1;
    }

    for (const printArea of product.printAreas) {
      await db
        .insert(productPrintAreas)
        .values({
          publicId: printArea.publicId,
          productId: productRow.id,
          surfaceKey: printArea.surfaceKey,
          labelEn: printArea.labelEn,
          labelBn: printArea.labelBn,
          physicalWidthMm: printArea.physicalWidthMm,
          physicalHeightMm: printArea.physicalHeightMm,
          targetDpi: printArea.targetDpi,
          safeInsetMm: printArea.safeInsetMm,
          coordinateSpace: 'normalized_0_1',
          mockupBoundsJson: printArea.mockupBounds,
          uvRegionJson: printArea.uvRegion,
          printMethodsJson: printArea.printMethods,
          surchargeAmount: printArea.surchargeAmount,
          currencyCode: 'BDT',
          isDefault: printArea.isDefault,
          isActive: true,
          sortOrder: printArea.sortOrder,
        })
        .onDuplicateKeyUpdate({
          set: {
            labelEn: sql`VALUES(label_en)`,
            labelBn: sql`VALUES(label_bn)`,
            physicalWidthMm: sql`VALUES(physical_width_mm)`,
            physicalHeightMm: sql`VALUES(physical_height_mm)`,
            targetDpi: sql`VALUES(target_dpi)`,
            safeInsetMm: sql`VALUES(safe_inset_mm)`,
            mockupBoundsJson: sql`VALUES(mockup_bounds_json)`,
            uvRegionJson: sql`VALUES(uv_region_json)`,
            printMethodsJson: sql`VALUES(print_methods_json)`,
            surchargeAmount: sql`VALUES(surcharge_amount)`,
            isDefault: sql`VALUES(is_default)`,
            isActive: true,
            sortOrder: sql`VALUES(sort_order)`,
          },
        });
      printAreasUpserted += 1;
    }
  }

  return {
    categoriesUpserted: INITIAL_CATEGORIES.length,
    productsUpserted: INITIAL_PRODUCTS.length,
    variantsUpserted,
    printAreasUpserted,
  };
}
