import { defineConfig } from 'drizzle-kit';
import { resolveDatabaseUrl } from './scripts/connection.js';

export default defineConfig({
  dialect: 'mysql',
  schema: './schema/index.ts',
  out: './migrations',
  strict: true,
  verbose: true,
  dbCredentials: {
    url: resolveDatabaseUrl(),
  },
});
