CREATE TABLE `design_assets` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`owner_user_id` bigint unsigned NOT NULL,
	`storage_driver` enum('local','s3') NOT NULL DEFAULT 'local',
	`object_key` varchar(500) NOT NULL,
	`preview_object_key` varchar(500) NOT NULL,
	`original_filename` varchar(255) NOT NULL,
	`mime_type` varchar(100) NOT NULL,
	`byte_size` int unsigned NOT NULL,
	`width_px` int unsigned NOT NULL,
	`height_px` int unsigned NOT NULL,
	`sha256` char(64) NOT NULL,
	`status` enum('active','deleted') NOT NULL DEFAULT 'active',
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`deleted_at` datetime(3),
	CONSTRAINT `design_assets_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_design_assets_public_id` UNIQUE(`public_id`)
);
--> statement-breakpoint
CREATE TABLE `design_print_exports` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`design_id` bigint unsigned NOT NULL,
	`design_version_id` bigint unsigned NOT NULL,
	`surface_key` enum('front','back','left_chest','right_sleeve','left_sleeve') NOT NULL,
	`object_key` varchar(500) NOT NULL,
	`width_px` int unsigned NOT NULL,
	`height_px` int unsigned NOT NULL,
	`dpi` int unsigned NOT NULL DEFAULT 300,
	`byte_size` int unsigned NOT NULL,
	`sha256` char(64) NOT NULL,
	`requested_by_user_id` bigint unsigned NOT NULL,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	CONSTRAINT `design_print_exports_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_design_print_exports_public_id` UNIQUE(`public_id`)
);
--> statement-breakpoint
CREATE TABLE `design_versions` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`design_id` bigint unsigned NOT NULL,
	`version_number` int unsigned NOT NULL,
	`document_json` json NOT NULL,
	`validation_summary_json` json NOT NULL,
	`surface_summary_json` json NOT NULL,
	`created_by_user_id` bigint unsigned NOT NULL,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	CONSTRAINT `design_versions_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_design_versions_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_design_versions_design_version` UNIQUE(`design_id`,`version_number`)
);
--> statement-breakpoint
CREATE TABLE `designs` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`owner_user_id` bigint unsigned NOT NULL,
	`product_id` bigint unsigned NOT NULL,
	`product_variant_id` bigint unsigned NOT NULL,
	`title` varchar(140) NOT NULL,
	`preferred_mode` enum('2d','3d') NOT NULL DEFAULT '2d',
	`current_version_number` int unsigned NOT NULL DEFAULT 1,
	`status` enum('draft','saved','ordered','archived') NOT NULL DEFAULT 'draft',
	`latest_preview_key` varchar(500),
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`deleted_at` datetime(3),
	CONSTRAINT `designs_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_designs_public_id` UNIQUE(`public_id`)
);
--> statement-breakpoint
ALTER TABLE `design_assets` ADD CONSTRAINT `design_assets_owner_user_id_users_id_fk` FOREIGN KEY (`owner_user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `design_print_exports` ADD CONSTRAINT `design_print_exports_design_id_designs_id_fk` FOREIGN KEY (`design_id`) REFERENCES `designs`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `design_print_exports` ADD CONSTRAINT `design_print_exports_design_version_id_design_versions_id_fk` FOREIGN KEY (`design_version_id`) REFERENCES `design_versions`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `design_print_exports` ADD CONSTRAINT `design_print_exports_requested_by_user_id_users_id_fk` FOREIGN KEY (`requested_by_user_id`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `design_versions` ADD CONSTRAINT `design_versions_design_id_designs_id_fk` FOREIGN KEY (`design_id`) REFERENCES `designs`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `design_versions` ADD CONSTRAINT `design_versions_created_by_user_id_users_id_fk` FOREIGN KEY (`created_by_user_id`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `designs` ADD CONSTRAINT `designs_owner_user_id_users_id_fk` FOREIGN KEY (`owner_user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `designs` ADD CONSTRAINT `designs_product_id_products_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE restrict ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `designs` ADD CONSTRAINT `designs_product_variant_id_product_variants_id_fk` FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants`(`id`) ON DELETE restrict ON UPDATE cascade;--> statement-breakpoint
CREATE INDEX `idx_design_assets_owner_status` ON `design_assets` (`owner_user_id`,`status`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_design_assets_sha256` ON `design_assets` (`sha256`);--> statement-breakpoint
CREATE INDEX `idx_design_print_exports_design_surface` ON `design_print_exports` (`design_id`,`surface_key`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_design_print_exports_version` ON `design_print_exports` (`design_version_id`);--> statement-breakpoint
CREATE INDEX `idx_design_versions_design_id` ON `design_versions` (`design_id`);--> statement-breakpoint
CREATE INDEX `idx_designs_owner_updated` ON `designs` (`owner_user_id`,`deleted_at`,`updated_at`);--> statement-breakpoint
CREATE INDEX `idx_designs_product_variant` ON `designs` (`product_id`,`product_variant_id`);