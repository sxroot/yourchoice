CREATE TABLE `audit_logs` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`actor_user_id` bigint unsigned,
	`action` varchar(100) NOT NULL,
	`entity_type` varchar(64) NOT NULL,
	`entity_public_id` varchar(64),
	`metadata_json` json,
	`ip_address` varchar(64),
	`request_id` varchar(64),
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `product_categories` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`parent_id` bigint unsigned,
	`slug` varchar(120) NOT NULL,
	`name_en` varchar(120) NOT NULL,
	`name_bn` varchar(120) NOT NULL,
	`description_en` varchar(500),
	`description_bn` varchar(500),
	`sort_order` int NOT NULL DEFAULT 0,
	`is_active` boolean NOT NULL DEFAULT true,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`deleted_at` datetime(3),
	CONSTRAINT `product_categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_product_categories_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_product_categories_slug` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `product_images` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`product_id` bigint unsigned NOT NULL,
	`variant_id` bigint unsigned,
	`view_type` enum('front','back','detail','flat_lay') NOT NULL,
	`url` varchar(500) NOT NULL,
	`alt_text_en` varchar(240) NOT NULL,
	`alt_text_bn` varchar(240) NOT NULL,
	`sort_order` int NOT NULL DEFAULT 0,
	`is_primary` boolean NOT NULL DEFAULT false,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	CONSTRAINT `product_images_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_product_images_public_id` UNIQUE(`public_id`)
);
--> statement-breakpoint
CREATE TABLE `product_print_areas` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`product_id` bigint unsigned NOT NULL,
	`surface_key` enum('front','back','left_chest','right_sleeve','left_sleeve') NOT NULL,
	`label_en` varchar(80) NOT NULL,
	`label_bn` varchar(80) NOT NULL,
	`physical_width_mm` int unsigned NOT NULL,
	`physical_height_mm` int unsigned NOT NULL,
	`target_dpi` int unsigned NOT NULL DEFAULT 300,
	`safe_inset_mm` int unsigned NOT NULL DEFAULT 10,
	`coordinate_space` varchar(32) NOT NULL DEFAULT 'normalized_0_1',
	`mockup_bounds_json` json NOT NULL,
	`uv_region_json` json,
	`print_methods_json` json NOT NULL,
	`surcharge_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
	`currency_code` char(3) NOT NULL DEFAULT 'BDT',
	`is_default` boolean NOT NULL DEFAULT false,
	`is_active` boolean NOT NULL DEFAULT true,
	`sort_order` int NOT NULL DEFAULT 0,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	CONSTRAINT `product_print_areas_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_product_print_areas_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_product_print_areas_product_surface` UNIQUE(`product_id`,`surface_key`)
);
--> statement-breakpoint
CREATE TABLE `product_variants` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`product_id` bigint unsigned NOT NULL,
	`sku` varchar(80) NOT NULL,
	`color_name_en` varchar(60) NOT NULL,
	`color_name_bn` varchar(60) NOT NULL,
	`color_hex` char(7) NOT NULL,
	`size_code` enum('XS','S','M','L','XL','XXL','3XL') NOT NULL,
	`price_override` decimal(12,2),
	`currency_code` char(3) NOT NULL DEFAULT 'BDT',
	`stock_quantity` int unsigned NOT NULL DEFAULT 0,
	`is_active` boolean NOT NULL DEFAULT true,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`deleted_at` datetime(3),
	CONSTRAINT `product_variants_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_product_variants_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_product_variants_sku` UNIQUE(`sku`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`category_id` bigint unsigned NOT NULL,
	`slug` varchar(160) NOT NULL,
	`sku_prefix` varchar(40) NOT NULL,
	`name_en` varchar(160) NOT NULL,
	`name_bn` varchar(160) NOT NULL,
	`subtitle_en` varchar(240),
	`subtitle_bn` varchar(240),
	`description_en` text NOT NULL,
	`description_bn` text NOT NULL,
	`fabric_spec_en` varchar(240),
	`fabric_spec_bn` varchar(240),
	`gsm` int unsigned,
	`fit_type` varchar(64),
	`base_price` decimal(12,2) NOT NULL,
	`currency_code` char(3) NOT NULL DEFAULT 'BDT',
	`is_customizable` boolean NOT NULL DEFAULT true,
	`status` enum('draft','active','archived') NOT NULL DEFAULT 'draft',
	`featured_order` int,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`deleted_at` datetime(3),
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_products_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_products_slug` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `user_addresses` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`user_id` bigint unsigned NOT NULL,
	`label` varchar(60) NOT NULL,
	`recipient_name` varchar(120) NOT NULL,
	`phone` varchar(32) NOT NULL,
	`division` varchar(80) NOT NULL,
	`district` varchar(80) NOT NULL,
	`area` varchar(120) NOT NULL,
	`address_line` varchar(255) NOT NULL,
	`postal_code` varchar(16),
	`is_default` boolean NOT NULL DEFAULT false,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`deleted_at` datetime(3),
	CONSTRAINT `user_addresses_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_user_addresses_public_id` UNIQUE(`public_id`)
);
--> statement-breakpoint
ALTER TABLE `audit_logs` ADD CONSTRAINT `audit_logs_actor_user_id_users_id_fk` FOREIGN KEY (`actor_user_id`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `product_categories` ADD CONSTRAINT `product_categories_parent_id_product_categories_id_fk` FOREIGN KEY (`parent_id`) REFERENCES `product_categories`(`id`) ON DELETE set null ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `product_images` ADD CONSTRAINT `product_images_product_id_products_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `product_images` ADD CONSTRAINT `product_images_variant_id_product_variants_id_fk` FOREIGN KEY (`variant_id`) REFERENCES `product_variants`(`id`) ON DELETE set null ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `product_print_areas` ADD CONSTRAINT `product_print_areas_product_id_products_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `product_variants` ADD CONSTRAINT `product_variants_product_id_products_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `products` ADD CONSTRAINT `products_category_id_product_categories_id_fk` FOREIGN KEY (`category_id`) REFERENCES `product_categories`(`id`) ON DELETE restrict ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `user_addresses` ADD CONSTRAINT `user_addresses_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
CREATE INDEX `idx_audit_logs_actor_created` ON `audit_logs` (`actor_user_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_audit_logs_entity` ON `audit_logs` (`entity_type`,`entity_public_id`);--> statement-breakpoint
CREATE INDEX `idx_audit_logs_action_created` ON `audit_logs` (`action`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_product_categories_parent_sort` ON `product_categories` (`parent_id`,`sort_order`);--> statement-breakpoint
CREATE INDEX `idx_product_categories_active_deleted` ON `product_categories` (`is_active`,`deleted_at`);--> statement-breakpoint
CREATE INDEX `idx_product_images_product_sort` ON `product_images` (`product_id`,`sort_order`);--> statement-breakpoint
CREATE INDEX `idx_product_images_variant` ON `product_images` (`variant_id`);--> statement-breakpoint
CREATE INDEX `idx_product_print_areas_product_active` ON `product_print_areas` (`product_id`,`is_active`);--> statement-breakpoint
CREATE INDEX `idx_product_variants_product_active` ON `product_variants` (`product_id`,`is_active`,`deleted_at`);--> statement-breakpoint
CREATE INDEX `idx_product_variants_size_color` ON `product_variants` (`size_code`,`color_hex`);--> statement-breakpoint
CREATE INDEX `idx_products_category_status` ON `products` (`category_id`,`status`,`deleted_at`);--> statement-breakpoint
CREATE INDEX `idx_products_status_featured` ON `products` (`status`,`featured_order`);--> statement-breakpoint
CREATE INDEX `idx_user_addresses_user_deleted` ON `user_addresses` (`user_id`,`deleted_at`);--> statement-breakpoint
CREATE INDEX `idx_user_addresses_user_default` ON `user_addresses` (`user_id`,`is_default`);