CREATE TABLE `cart_items` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`cart_id` bigint unsigned NOT NULL,
	`variant_id` bigint unsigned NOT NULL,
	`item_key` varchar(120) NOT NULL,
	`quantity` int unsigned NOT NULL DEFAULT 1,
	`unit_price_snapshot` decimal(12,2) NOT NULL,
	`customization_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
	`currency_code` char(3) NOT NULL DEFAULT 'BDT',
	`design_public_id` char(36),
	`customization_meta_json` json,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	CONSTRAINT `cart_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_cart_items_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_cart_items_cart_key` UNIQUE(`cart_id`,`item_key`)
);
--> statement-breakpoint
CREATE TABLE `carts` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`user_id` bigint unsigned,
	`guest_token_hash` char(64),
	`currency_code` char(3) NOT NULL DEFAULT 'BDT',
	`expires_at` datetime(3) NOT NULL,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	CONSTRAINT `carts_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_carts_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_carts_guest_token_hash` UNIQUE(`guest_token_hash`)
);
--> statement-breakpoint
CREATE TABLE `order_items` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`order_id` bigint unsigned NOT NULL,
	`product_id` bigint unsigned NOT NULL,
	`variant_id` bigint unsigned NOT NULL,
	`product_name_en_snapshot` varchar(160) NOT NULL,
	`product_name_bn_snapshot` varchar(160) NOT NULL,
	`product_slug_snapshot` varchar(160) NOT NULL,
	`sku_snapshot` varchar(80) NOT NULL,
	`color_name_en_snapshot` varchar(60) NOT NULL,
	`color_name_bn_snapshot` varchar(60) NOT NULL,
	`color_hex_snapshot` char(7) NOT NULL,
	`size_code_snapshot` varchar(10) NOT NULL,
	`primary_image_url_snapshot` varchar(500),
	`quantity` int unsigned NOT NULL,
	`unit_price` decimal(12,2) NOT NULL,
	`customization_fee` decimal(12,2) NOT NULL DEFAULT '0.00',
	`line_total` decimal(12,2) NOT NULL,
	`currency_code` char(3) NOT NULL DEFAULT 'BDT',
	`design_public_id` char(36),
	`design_title_snapshot` varchar(160),
	`production_spec_json` json,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	CONSTRAINT `order_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_order_items_public_id` UNIQUE(`public_id`)
);
--> statement-breakpoint
CREATE TABLE `order_status_history` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`order_id` bigint unsigned NOT NULL,
	`from_status` varchar(32),
	`to_status` varchar(32) NOT NULL,
	`changed_by_user_id` bigint unsigned,
	`actor_role` varchar(32),
	`note` varchar(500),
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	CONSTRAINT `order_status_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`order_number` varchar(32) NOT NULL,
	`user_id` bigint unsigned,
	`customer_email` varchar(255) NOT NULL,
	`customer_phone` varchar(32) NOT NULL,
	`shipping_address_json` json NOT NULL,
	`shipping_zone_code` varchar(40) NOT NULL,
	`shipping_zone_name_snapshot` varchar(120) NOT NULL,
	`payment_method` enum('cod','bkash','nagad','sslcommerz_card') NOT NULL DEFAULT 'cod',
	`payment_status` enum('unpaid','pending','paid','failed','refunded') NOT NULL DEFAULT 'unpaid',
	`order_status` enum('pending','confirmed','processing','packed','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
	`subtotal_amount` decimal(12,2) NOT NULL,
	`shipping_amount` decimal(12,2) NOT NULL,
	`discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
	`total_amount` decimal(12,2) NOT NULL,
	`currency_code` char(3) NOT NULL DEFAULT 'BDT',
	`customer_note` text,
	`cancelled_at` datetime(3),
	`cancellation_reason` varchar(255),
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_orders_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_orders_order_number` UNIQUE(`order_number`)
);
--> statement-breakpoint
CREATE TABLE `payment_transactions` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`order_id` bigint unsigned NOT NULL,
	`gateway` enum('cod','bkash','nagad','sslcommerz_card') NOT NULL,
	`transaction_ref` varchar(120),
	`provider_payment_id` varchar(120),
	`amount` decimal(12,2) NOT NULL,
	`currency_code` char(3) NOT NULL DEFAULT 'BDT',
	`status` enum('unpaid','pending','authorized','paid','failed','cancelled','refunded') NOT NULL DEFAULT 'unpaid',
	`verification_source` varchar(40),
	`raw_payload_json` json,
	`verified_at` datetime(3),
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	CONSTRAINT `payment_transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_payment_transactions_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_payment_transactions_gateway_ref` UNIQUE(`gateway`,`transaction_ref`)
);
--> statement-breakpoint
CREATE TABLE `shipping_zones` (
	`id` bigint unsigned AUTO_INCREMENT NOT NULL,
	`public_id` char(36) NOT NULL,
	`code` varchar(40) NOT NULL,
	`name_en` varchar(120) NOT NULL,
	`name_bn` varchar(120) NOT NULL,
	`divisions_json` json NOT NULL,
	`flat_fee` decimal(12,2) NOT NULL,
	`free_shipping_threshold` decimal(12,2),
	`estimated_days_min` int unsigned NOT NULL DEFAULT 1,
	`estimated_days_max` int unsigned NOT NULL DEFAULT 3,
	`currency_code` char(3) NOT NULL DEFAULT 'BDT',
	`sort_order` int NOT NULL DEFAULT 0,
	`is_active` boolean NOT NULL DEFAULT true,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	CONSTRAINT `shipping_zones_id` PRIMARY KEY(`id`),
	CONSTRAINT `uq_shipping_zones_public_id` UNIQUE(`public_id`),
	CONSTRAINT `uq_shipping_zones_code` UNIQUE(`code`)
);
--> statement-breakpoint
ALTER TABLE `cart_items` ADD CONSTRAINT `cart_items_cart_id_carts_id_fk` FOREIGN KEY (`cart_id`) REFERENCES `carts`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `cart_items` ADD CONSTRAINT `cart_items_variant_id_product_variants_id_fk` FOREIGN KEY (`variant_id`) REFERENCES `product_variants`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `carts` ADD CONSTRAINT `carts_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `order_items` ADD CONSTRAINT `order_items_order_id_orders_id_fk` FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `order_items` ADD CONSTRAINT `order_items_product_id_products_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE restrict ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `order_items` ADD CONSTRAINT `order_items_variant_id_product_variants_id_fk` FOREIGN KEY (`variant_id`) REFERENCES `product_variants`(`id`) ON DELETE restrict ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `order_status_history` ADD CONSTRAINT `order_status_history_order_id_orders_id_fk` FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `order_status_history` ADD CONSTRAINT `order_status_history_changed_by_user_id_users_id_fk` FOREIGN KEY (`changed_by_user_id`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `orders` ADD CONSTRAINT `orders_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE `payment_transactions` ADD CONSTRAINT `payment_transactions_order_id_orders_id_fk` FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
CREATE INDEX `idx_cart_items_variant_id` ON `cart_items` (`variant_id`);--> statement-breakpoint
CREATE INDEX `idx_carts_user_id` ON `carts` (`user_id`);--> statement-breakpoint
CREATE INDEX `idx_carts_expires_at` ON `carts` (`expires_at`);--> statement-breakpoint
CREATE INDEX `idx_order_items_order_id` ON `order_items` (`order_id`);--> statement-breakpoint
CREATE INDEX `idx_order_items_variant_id` ON `order_items` (`variant_id`);--> statement-breakpoint
CREATE INDEX `idx_order_status_history_order_id` ON `order_status_history` (`order_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_orders_user_created` ON `orders` (`user_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_orders_status_created` ON `orders` (`order_status`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_orders_customer_email` ON `orders` (`customer_email`);--> statement-breakpoint
CREATE INDEX `idx_payment_transactions_order_id` ON `payment_transactions` (`order_id`);--> statement-breakpoint
CREATE INDEX `idx_shipping_zones_active_sort` ON `shipping_zones` (`is_active`,`sort_order`);