CREATE TABLE `system_settings` (
	`setting_key` varchar(128) NOT NULL,
	`category` varchar(64) NOT NULL,
	`value_json` json NOT NULL,
	`value_type` enum('string','number','boolean','json') NOT NULL DEFAULT 'json',
	`description` varchar(500),
	`is_public` boolean NOT NULL DEFAULT false,
	`created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`updated_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	CONSTRAINT `system_settings_setting_key` PRIMARY KEY(`setting_key`)
);
--> statement-breakpoint
CREATE INDEX `idx_system_settings_category` ON `system_settings` (`category`);--> statement-breakpoint
CREATE INDEX `idx_system_settings_public` ON `system_settings` (`is_public`);