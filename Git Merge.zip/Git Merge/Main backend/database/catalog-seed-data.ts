import type { PrintAreaMockupBoundsJson, PrintAreaUvRegionJson } from './schema/catalog.js';

export interface SeedCategoryDefinition {
  publicId: string;
  slug: string;
  nameEn: string;
  nameBn: string;
  descriptionEn: string;
  descriptionBn: string;
  sortOrder: number;
}

export interface SeedProductImageDefinition {
  publicId: string;
  viewType: 'front' | 'back' | 'detail' | 'flat_lay';
  url: string;
  altTextEn: string;
  altTextBn: string;
  sortOrder: number;
  isPrimary: boolean;
}

export interface SeedProductVariantDefinition {
  publicId: string;
  sku: string;
  colorNameEn: string;
  colorNameBn: string;
  colorHex: string;
  sizeCode: 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL' | '3XL';
  priceOverride: string | null;
  stockQuantity: number;
}

export interface SeedPrintAreaDefinition {
  publicId: string;
  surfaceKey: 'front' | 'back' | 'left_chest' | 'right_sleeve' | 'left_sleeve';
  labelEn: string;
  labelBn: string;
  physicalWidthMm: number;
  physicalHeightMm: number;
  targetDpi: number;
  safeInsetMm: number;
  mockupBounds: PrintAreaMockupBoundsJson;
  uvRegion: PrintAreaUvRegionJson;
  printMethods: string[];
  surchargeAmount: string;
  isDefault: boolean;
  sortOrder: number;
}

export interface SeedProductDefinition {
  publicId: string;
  categorySlug: string;
  slug: string;
  skuPrefix: string;
  nameEn: string;
  nameBn: string;
  subtitleEn: string;
  subtitleBn: string;
  descriptionEn: string;
  descriptionBn: string;
  fabricSpecEn: string;
  fabricSpecBn: string;
  gsm: number;
  fitType: string;
  basePrice: string;
  isCustomizable: boolean;
  status: 'draft' | 'active' | 'archived';
  featuredOrder: number;
  images: readonly SeedProductImageDefinition[];
  variants: readonly SeedProductVariantDefinition[];
  printAreas: readonly SeedPrintAreaDefinition[];
}

export const INITIAL_CATEGORIES: readonly SeedCategoryDefinition[] = [
  {
    publicId: '00000000-0000-4000-8000-000000000001',
    slug: 't-shirts',
    nameEn: 'T-Shirts',
    nameBn: 'টি-শার্ট',
    descriptionEn:
      'Combed ring-spun cotton tees engineered in Dhaka for sharp DTF & screen prints.',
    descriptionBn: 'ঢাকায় তৈরি কম্বড রিং-স্পান কটন টি-শার্ট, নিখুঁত ডিটিএফ ও স্ক্রিন প্রিন্টের জন্য প্রস্তুত।',
    sortOrder: 1,
  },
  {
    publicId: '00000000-0000-4000-8000-000000000002',
    slug: 'polo-shirts',
    nameEn: 'Polo Shirts',
    nameBn: 'পলো শার্ট',
    descriptionEn:
      'Structured cotton pique polos with reinforced plackets and left-chest or back print zones.',
    descriptionBn: 'মজবুত প্ল্যাকেট এবং লেফট-চেস্ট ও ব্যাক প্রিন্ট জোনসহ স্ট্রাকচার্ড কটন পিকে পলো শার্ট।',
    sortOrder: 2,
  },
];

export const INITIAL_PRODUCTS: readonly SeedProductDefinition[] = [
  {
    publicId: '00000000-0000-4000-8000-000000000003',
    categorySlug: 't-shirts',
    slug: 'signature-heavyweight-tee',
    skuPrefix: 'YC-TEE-220',
    nameEn: 'Signature 220 GSM Crewneck Tee',
    nameBn: 'সিগনেচার ২২০ জিএসএম ক্রুনেক টি-শার্ট',
    subtitleEn: 'Pre-shrunk combed cotton studio blank',
    subtitleBn: 'প্রি-শ্রাঙ্ক কম্বড কটন স্টুডিও ব্ল্যাঙ্ক',
    descriptionEn:
      'Built for daily wear and high-definition custom printing. Compact-spun 100% Bangladesh cotton resists pilling while offering full front and back 300 DPI print canvases.',
    descriptionBn:
      'দৈনন্দিন ব্যবহার এবং হাই-ডেফিনিশন কাস্টম প্রিন্টের জন্য তৈরি। ১০০% কম্বড বাংলাদেশি কটন ফ্যাব্রিক ও সামনে-পিছনে ৩০০ ডিপিআই প্রিন্ট ক্যানভাস।',
    fabricSpecEn: '100% Combed Ring-Spun Cotton · Enzyme Washed',
    fabricSpecBn: '১০০% কম্বড রিং-স্পান কটন · এনজাইম ওয়াশড',
    gsm: 220,
    fitType: 'Regular Fit',
    basePrice: '790.00',
    isCustomizable: true,
    status: 'active',
    featuredOrder: 1,
    images: [
      {
        publicId: '00000000-0000-4000-8000-000000000004',
        viewType: 'front',
        url: '/catalog/tee-front.svg',
        altTextEn: 'Signature 220 GSM Crewneck Tee front view',
        altTextBn: 'সিগনেচার ২২০ জিএসএম ক্রুনেক টি-শার্ট সামনের দৃশ্য',
        sortOrder: 0,
        isPrimary: true,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000005',
        viewType: 'back',
        url: '/catalog/tee-back.svg',
        altTextEn: 'Signature 220 GSM Crewneck Tee back view',
        altTextBn: 'সিগনেচার ২২০ জিএসএম ক্রুনেক টি-শার্ট পিছনের দৃশ্য',
        sortOrder: 1,
        isPrimary: false,
      },
    ],
    variants: [
      {
        publicId: '00000000-0000-4000-8000-000000000006',
        sku: 'YC-TEE-220-BLK-M',
        colorNameEn: 'Obsidian Black',
        colorNameBn: 'অবসিডিয়ান কালো',
        colorHex: '#0F172A',
        sizeCode: 'M',
        priceOverride: null,
        stockQuantity: 48,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000007',
        sku: 'YC-TEE-220-BLK-L',
        colorNameEn: 'Obsidian Black',
        colorNameBn: 'অবসিডিয়ান কালো',
        colorHex: '#0F172A',
        sizeCode: 'L',
        priceOverride: null,
        stockQuantity: 54,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000008',
        sku: 'YC-TEE-220-RYL-M',
        colorNameEn: 'Royal Blue',
        colorNameBn: 'রয়্যাল ব্লু',
        colorHex: '#1D4ED8',
        sizeCode: 'M',
        priceOverride: '820.00',
        stockQuantity: 32,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000009',
        sku: 'YC-TEE-220-WHT-XL',
        colorNameEn: 'Studio White',
        colorNameBn: 'স্টুডিও সাদা',
        colorHex: '#F8FAFC',
        sizeCode: 'XL',
        priceOverride: null,
        stockQuantity: 28,
      },
    ],
    printAreas: [
      {
        publicId: '00000000-0000-4000-8000-00000000000a',
        surfaceKey: 'front',
        labelEn: 'Front Chest Canvas',
        labelBn: 'সামনের চেস্ট ক্যানভাস',
        physicalWidthMm: 280,
        physicalHeightMm: 360,
        targetDpi: 300,
        safeInsetMm: 12,
        mockupBounds: { x: 0.31, y: 0.25, width: 0.38, height: 0.48, rotationDeg: 0 },
        uvRegion: {
          islandKey: 'tee_front_torso',
          meshTarget: 'garment_front',
          uMin: 0.15,
          uMax: 0.45,
          vMin: 0.2,
          vMax: 0.72,
        },
        printMethods: ['dtf', 'screen_print'],
        surchargeAmount: '150.00',
        isDefault: true,
        sortOrder: 0,
      },
      {
        publicId: '00000000-0000-4000-8000-00000000000b',
        surfaceKey: 'back',
        labelEn: 'Full Back Canvas',
        labelBn: 'পিছনের ফুল ক্যানভাস',
        physicalWidthMm: 300,
        physicalHeightMm: 400,
        targetDpi: 300,
        safeInsetMm: 12,
        mockupBounds: { x: 0.29, y: 0.22, width: 0.42, height: 0.54, rotationDeg: 0 },
        uvRegion: {
          islandKey: 'tee_back_torso',
          meshTarget: 'garment_back',
          uMin: 0.55,
          uMax: 0.88,
          vMin: 0.18,
          vMax: 0.75,
        },
        printMethods: ['dtf', 'screen_print'],
        surchargeAmount: '180.00',
        isDefault: false,
        sortOrder: 1,
      },
    ],
  },
  {
    publicId: '00000000-0000-4000-8000-00000000000c',
    categorySlug: 't-shirts',
    slug: 'atelier-oversized-box-tee',
    skuPrefix: 'YC-TEE-240',
    nameEn: 'Atelier 240 GSM Oversized Drop Tee',
    nameBn: 'অ্যাটেলিয়ার ২৪০ জিএসএম ওভারসাইজড টি-শার্ট',
    subtitleEn: 'Streetwear boxy silhouette with wide back print zone',
    subtitleBn: 'বক্সি স্ট্রিটওয়্যার কাট ও প্রশস্ত ব্যাক প্রিন্ট জোন',
    descriptionEn:
      'Crafted from heavy 240 GSM double-knit jersey with dropped shoulders and ribbed crew collar—ideal for bold creator graphic drops.',
    descriptionBn:
      'হেভি ২৪০ জিএসএম জার্সি ও ড্রপড শোল্ডার ডিজাইনে তৈরি, যা ক্রিয়েটর গ্রাফিক কালেকশনের জন্য আদর্শ।',
    fabricSpecEn: '100% Heavyweight Single Jersey Cotton',
    fabricSpecBn: '১০০% হেভিওয়েট সিঙ্গেল জার্সি কটন',
    gsm: 240,
    fitType: 'Oversized Fit',
    basePrice: '950.00',
    isCustomizable: true,
    status: 'active',
    featuredOrder: 2,
    images: [
      {
        publicId: '00000000-0000-4000-8000-00000000000d',
        viewType: 'front',
        url: '/catalog/tee-front.svg',
        altTextEn: 'Atelier 240 GSM Oversized Drop Tee front view',
        altTextBn: 'অ্যাটেলিয়ার ২৪০ জিএসএম ওভারসাইজড টি-শার্ট সামনের দৃশ্য',
        sortOrder: 0,
        isPrimary: true,
      },
      {
        publicId: '00000000-0000-4000-8000-00000000000e',
        viewType: 'back',
        url: '/catalog/tee-back.svg',
        altTextEn: 'Atelier 240 GSM Oversized Drop Tee back view',
        altTextBn: 'অ্যাটেলিয়ার ২৪০ জিএসএম ওভারসাইজড টি-শার্ট পিছনের দৃশ্য',
        sortOrder: 1,
        isPrimary: false,
      },
    ],
    variants: [
      {
        publicId: '00000000-0000-4000-8000-00000000000f',
        sku: 'YC-TEE-240-SLT-M',
        colorNameEn: 'Charcoal Slate',
        colorNameBn: 'চারকোল স্লেট',
        colorHex: '#334155',
        sizeCode: 'M',
        priceOverride: null,
        stockQuantity: 36,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000010',
        sku: 'YC-TEE-240-BLK-L',
        colorNameEn: 'Obsidian Black',
        colorNameBn: 'অবসিডিয়ান কালো',
        colorHex: '#0F172A',
        sizeCode: 'L',
        priceOverride: null,
        stockQuantity: 42,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000011',
        sku: 'YC-TEE-240-CYN-XL',
        colorNameEn: 'Deep Cyan',
        colorNameBn: 'ডিপ সায়ান',
        colorHex: '#0891B2',
        sizeCode: 'XL',
        priceOverride: '990.00',
        stockQuantity: 19,
      },
    ],
    printAreas: [
      {
        publicId: '00000000-0000-4000-8000-000000000012',
        surfaceKey: 'front',
        labelEn: 'Front Center Graphic',
        labelBn: 'সামনের সেন্টার গ্রাফিক',
        physicalWidthMm: 290,
        physicalHeightMm: 380,
        targetDpi: 300,
        safeInsetMm: 14,
        mockupBounds: { x: 0.3, y: 0.25, width: 0.4, height: 0.48, rotationDeg: 0 },
        uvRegion: {
          islandKey: 'oversized_front',
          meshTarget: 'garment_front',
          uMin: 0.14,
          uMax: 0.46,
          vMin: 0.18,
          vMax: 0.74,
        },
        printMethods: ['dtf', 'screen_print'],
        surchargeAmount: '170.00',
        isDefault: true,
        sortOrder: 0,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000013',
        surfaceKey: 'back',
        labelEn: 'Oversized Back Print',
        labelBn: 'বড় ব্যাক প্রিন্ট',
        physicalWidthMm: 320,
        physicalHeightMm: 420,
        targetDpi: 300,
        safeInsetMm: 14,
        mockupBounds: { x: 0.28, y: 0.21, width: 0.44, height: 0.56, rotationDeg: 0 },
        uvRegion: {
          islandKey: 'oversized_back',
          meshTarget: 'garment_back',
          uMin: 0.54,
          uMax: 0.9,
          vMin: 0.15,
          vMax: 0.77,
        },
        printMethods: ['dtf', 'screen_print'],
        surchargeAmount: '200.00',
        isDefault: false,
        sortOrder: 1,
      },
    ],
  },
  {
    publicId: '00000000-0000-4000-8000-000000000014',
    categorySlug: 'polo-shirts',
    slug: 'executive-knit-polo',
    skuPrefix: 'YC-PLO-230',
    nameEn: 'Executive Combed Pique Polo Shirt',
    nameBn: 'এক্সিকিউটিভ কম্বড পিকে পলো শার্ট',
    subtitleEn: 'Breathable honeycomb pique with structured collar',
    subtitleBn: 'ব্রিদেবল হানিকম্ব পিকে এবং স্ট্রাকচার্ড কলার',
    descriptionEn:
      'Refined Bangladesh-knitted cotton pique polo engineered for brand uniforms, university clubs, and left-chest emblem + back studio customization.',
    descriptionBn:
      'ব্র্যান্ড ইউনিফর্ম, টিম এবং কাস্টম লেফট-চেস্ট ও ব্যাক প্রিন্টের জন্য তৈরি প্রিমিয়াম কটন পিকে পলো শার্ট।',
    fabricSpecEn: '100% Combed Honeycomb Cotton Pique',
    fabricSpecBn: '১০০% কম্বড হানিকম্ব কটন পিকে',
    gsm: 230,
    fitType: 'Tailored Fit',
    basePrice: '1290.00',
    isCustomizable: true,
    status: 'active',
    featuredOrder: 3,
    images: [
      {
        publicId: '00000000-0000-4000-8000-000000000015',
        viewType: 'front',
        url: '/catalog/polo-front.svg',
        altTextEn: 'Executive Combed Pique Polo Shirt front view',
        altTextBn: 'এক্সিকিউটিভ কম্বড পিকে পলো শার্ট সামনের দৃশ্য',
        sortOrder: 0,
        isPrimary: true,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000016',
        viewType: 'back',
        url: '/catalog/polo-back.svg',
        altTextEn: 'Executive Combed Pique Polo Shirt back view',
        altTextBn: 'এক্সিকিউটিভ কম্বড পিকে পলো শার্ট পিছনের দৃশ্য',
        sortOrder: 1,
        isPrimary: false,
      },
    ],
    variants: [
      {
        publicId: '00000000-0000-4000-8000-000000000017',
        sku: 'YC-PLO-230-RYL-M',
        colorNameEn: 'Royal Blue',
        colorNameBn: 'রয়্যাল ব্লু',
        colorHex: '#1D4ED8',
        sizeCode: 'M',
        priceOverride: null,
        stockQuantity: 34,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000018',
        sku: 'YC-PLO-230-BLK-L',
        colorNameEn: 'Obsidian Black',
        colorNameBn: 'অবসিডিয়ান কালো',
        colorHex: '#0F172A',
        sizeCode: 'L',
        priceOverride: null,
        stockQuantity: 40,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000019',
        sku: 'YC-PLO-230-WHT-S',
        colorNameEn: 'Studio White',
        colorNameBn: 'স্টুডিও সাদা',
        colorHex: '#F8FAFC',
        sizeCode: 'S',
        priceOverride: null,
        stockQuantity: 22,
      },
    ],
    printAreas: [
      {
        publicId: '00000000-0000-4000-8000-00000000001a',
        surfaceKey: 'left_chest',
        labelEn: 'Left Chest Emblem',
        labelBn: 'লেফট চেস্ট লোগো জোন',
        physicalWidthMm: 95,
        physicalHeightMm: 95,
        targetDpi: 300,
        safeInsetMm: 6,
        mockupBounds: { x: 0.56, y: 0.28, width: 0.14, height: 0.14, rotationDeg: 0 },
        uvRegion: {
          islandKey: 'polo_left_chest',
          meshTarget: 'garment_front',
          uMin: 0.54,
          uMax: 0.72,
          vMin: 0.55,
          vMax: 0.72,
        },
        printMethods: ['dtf', 'embroidery_ready'],
        surchargeAmount: '120.00',
        isDefault: true,
        sortOrder: 0,
      },
      {
        publicId: '00000000-0000-4000-8000-00000000001b',
        surfaceKey: 'back',
        labelEn: 'Upper Back Graphic',
        labelBn: 'পিছনের আপার ব্যাক জোন',
        physicalWidthMm: 280,
        physicalHeightMm: 340,
        targetDpi: 300,
        safeInsetMm: 12,
        mockupBounds: { x: 0.3, y: 0.23, width: 0.4, height: 0.48, rotationDeg: 0 },
        uvRegion: {
          islandKey: 'polo_back_torso',
          meshTarget: 'garment_back',
          uMin: 0.56,
          uMax: 0.88,
          vMin: 0.22,
          vMax: 0.74,
        },
        printMethods: ['dtf', 'screen_print'],
        surchargeAmount: '180.00',
        isDefault: false,
        sortOrder: 1,
      },
    ],
  },
  {
    publicId: '00000000-0000-4000-8000-00000000001c',
    categorySlug: 'polo-shirts',
    slug: 'aero-tech-collar-polo',
    skuPrefix: 'YC-PLO-210',
    nameEn: 'Aero-Tech Contrast Collar Polo',
    nameBn: 'অ্যারো-টেক কনট্রাস্ট কলার পলো',
    subtitleEn: 'Moisture-wicking cotton blend for events & teams',
    subtitleBn: 'ইভেন্ট ও টিমের জন্য ময়েশ্চার-উইকিং কটন ব্লেন্ড',
    descriptionEn:
      'Lightweight cotton-poly pique blend designed for humid climates across Bangladesh with dual front-chest & back customization geometry.',
    descriptionBn:
      'বাংলাদেশের আবহাওয়ায় আরামদায়ক কটন-পলি পিকে ব্লেন্ড, সামনে ও পিছনের প্রিন্ট ক্যালিব্রেশনসহ।',
    fabricSpecEn: '65% Combed Cotton / 35% Micro-Pique Poly',
    fabricSpecBn: '৬৫% কম্বড কটন / ৩৫% মাইক্রো-পিকে পলি',
    gsm: 210,
    fitType: 'Athletic Fit',
    basePrice: '1390.00',
    isCustomizable: true,
    status: 'active',
    featuredOrder: 4,
    images: [
      {
        publicId: '00000000-0000-4000-8000-00000000001d',
        viewType: 'front',
        url: '/catalog/polo-front.svg',
        altTextEn: 'Aero-Tech Contrast Collar Polo front view',
        altTextBn: 'অ্যারো-টেক কনট্রাস্ট কলার পলো সামনের দৃশ্য',
        sortOrder: 0,
        isPrimary: true,
      },
      {
        publicId: '00000000-0000-4000-8000-00000000001e',
        viewType: 'back',
        url: '/catalog/polo-back.svg',
        altTextEn: 'Aero-Tech Contrast Collar Polo back view',
        altTextBn: 'অ্যারো-টেক কনট্রাস্ট কলার পলো পিছনের দৃশ্য',
        sortOrder: 1,
        isPrimary: false,
      },
    ],
    variants: [
      {
        publicId: '00000000-0000-4000-8000-00000000001f',
        sku: 'YC-PLO-210-BLK-M',
        colorNameEn: 'Obsidian Black',
        colorNameBn: 'অবসিডিয়ান কালো',
        colorHex: '#0F172A',
        sizeCode: 'M',
        priceOverride: null,
        stockQuantity: 25,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000020',
        sku: 'YC-PLO-210-CYN-L',
        colorNameEn: 'Deep Cyan',
        colorNameBn: 'ডিপ সায়ান',
        colorHex: '#0891B2',
        sizeCode: 'L',
        priceOverride: '1420.00',
        stockQuantity: 30,
      },
    ],
    printAreas: [
      {
        publicId: '00000000-0000-4000-8000-000000000021',
        surfaceKey: 'left_chest',
        labelEn: 'Left Chest Badge',
        labelBn: 'লেফট চেস্ট ব্যাজ',
        physicalWidthMm: 90,
        physicalHeightMm: 90,
        targetDpi: 300,
        safeInsetMm: 6,
        mockupBounds: { x: 0.56, y: 0.28, width: 0.13, height: 0.13, rotationDeg: 0 },
        uvRegion: {
          islandKey: 'aerotech_left_chest',
          meshTarget: 'garment_front',
          uMin: 0.54,
          uMax: 0.72,
          vMin: 0.55,
          vMax: 0.72,
        },
        printMethods: ['dtf'],
        surchargeAmount: '120.00',
        isDefault: true,
        sortOrder: 0,
      },
      {
        publicId: '00000000-0000-4000-8000-000000000022',
        surfaceKey: 'back',
        labelEn: 'Team Back Print Zone',
        labelBn: 'টিম ব্যাক প্রিন্ট জোন',
        physicalWidthMm: 270,
        physicalHeightMm: 330,
        targetDpi: 300,
        safeInsetMm: 12,
        mockupBounds: { x: 0.3, y: 0.24, width: 0.4, height: 0.46, rotationDeg: 0 },
        uvRegion: {
          islandKey: 'aerotech_back_torso',
          meshTarget: 'garment_back',
          uMin: 0.56,
          uMax: 0.87,
          vMin: 0.22,
          vMax: 0.73,
        },
        printMethods: ['dtf', 'sublimation'],
        surchargeAmount: '180.00',
        isDefault: false,
        sortOrder: 1,
      },
    ],
  },
];
