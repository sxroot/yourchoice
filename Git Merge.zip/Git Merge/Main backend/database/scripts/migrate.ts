import path from 'node:path';
import { drizzle } from 'drizzle-orm/mysql2';
import { migrate } from 'drizzle-orm/mysql2/migrator';
import { databaseDir, openDatabaseConnection } from './connection.js';

async function main(): Promise<void> {
  const connection = await openDatabaseConnection();

  try {
    const db = drizzle(connection);
    await migrate(db, {
      migrationsFolder: path.join(databaseDir, 'migrations'),
    });
    console.info('[db:migrate] Migrations applied successfully.');
  } finally {
    await connection.end();
  }
}

main().catch((error: unknown) => {
  console.error('[db:migrate] Migration failed:', error);
  process.exitCode = 1;
});
