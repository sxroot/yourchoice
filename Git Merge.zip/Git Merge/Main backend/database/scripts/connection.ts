import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import mysql from 'mysql2/promise';

const currentDir = path.dirname(fileURLToPath(import.meta.url));
export const databaseDir = path.resolve(currentDir, '..');
export const repoRootDir = path.resolve(databaseDir, '..');

let envLoaded = false;

export function loadRootEnv(): void {
  if (!envLoaded) {
    dotenv.config({ path: path.join(repoRootDir, '.env'), quiet: true });
    envLoaded = true;
  }
}

export function resolveDatabaseUrl(): string {
  loadRootEnv();

  if (process.env.DATABASE_URL && process.env.DATABASE_URL.trim().length > 0) {
    return process.env.DATABASE_URL.trim();
  }

  const host = process.env.DB_HOST ?? '127.0.0.1';
  const port = process.env.DB_PORT ?? '3306';
  const user = encodeURIComponent(process.env.DB_USER ?? 'your_choice_dev');
  const password = encodeURIComponent(process.env.DB_PASSWORD ?? '');
  const database = process.env.DB_NAME ?? 'your_choice_dev';

  return `mysql://${user}:${password}@${host}:${port}/${database}`;
}

export async function openDatabaseConnection(): Promise<mysql.Connection> {
  loadRootEnv();

  if (process.env.DATABASE_URL && process.env.DATABASE_URL.trim().length > 0) {
    return mysql.createConnection({
      uri: process.env.DATABASE_URL.trim(),
      charset: 'utf8mb4',
      timezone: 'Z',
    });
  }

  return mysql.createConnection({
    host: process.env.DB_HOST ?? '127.0.0.1',
    port: Number(process.env.DB_PORT ?? '3306'),
    user: process.env.DB_USER ?? 'your_choice_dev',
    password: process.env.DB_PASSWORD ?? '',
    database: process.env.DB_NAME ?? 'your_choice_dev',
    charset: 'utf8mb4',
    timezone: 'Z',
  });
}
