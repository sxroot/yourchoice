type DatabaseBangladeshDivision =
  'Dhaka' | 'Chattogram' | 'Rajshahi' | 'Khulna' | 'Barishal' | 'Sylhet' | 'Rangpur' | 'Mymensingh';

export interface ShippingZoneSeedEntry {
  publicId: string;
  code: string;
  nameEn: string;
  nameBn: string;
  divisions: DatabaseBangladeshDivision[];
  flatFee: string;
  freeShippingThreshold: string | null;
  estimatedDaysMin: number;
  estimatedDaysMax: number;
  sortOrder: number;
}

export const SHIPPING_ZONE_SEED_DATA: readonly ShippingZoneSeedEntry[] = [
  {
    publicId: '77777777-7777-4777-8777-777777777101',
    code: 'dhaka_metro',
    nameEn: 'Dhaka Division Express',
    nameBn: 'ঢাকা বিভাগ এক্সপ্রেস ডেলিভারি',
    divisions: ['Dhaka'],
    flatFee: '70.00',
    freeShippingThreshold: '2500.00',
    estimatedDaysMin: 1,
    estimatedDaysMax: 2,
    sortOrder: 0,
  },
  {
    publicId: '77777777-7777-4777-8777-777777777102',
    code: 'nationwide_bd',
    nameEn: 'Nationwide Courier (Outside Dhaka Division)',
    nameBn: 'সারা বাংলাদেশ কুরিয়ার (ঢাকা বিভাগের বাইরে)',
    divisions: ['Chattogram', 'Rajshahi', 'Khulna', 'Barishal', 'Sylhet', 'Rangpur', 'Mymensingh'],
    flatFee: '130.00',
    freeShippingThreshold: '3000.00',
    estimatedDaysMin: 3,
    estimatedDaysMax: 5,
    sortOrder: 1,
  },
] as const;
