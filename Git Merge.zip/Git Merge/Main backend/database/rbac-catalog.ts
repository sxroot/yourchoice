export interface RoleDefinition {
  code: 'guest' | 'customer' | 'creator' | 'staff' | 'admin' | 'super_admin';
  name: string;
  description: string;
  permissions: readonly string[];
}

export interface PermissionDefinition {
  code: string;
  module: string;
  description: string;
}

export const DEFAULT_PERMISSIONS: readonly PermissionDefinition[] = [
  {
    code: 'profile:read:own',
    module: 'identity',
    description: 'Read own authenticated account profile and session summary',
  },
  {
    code: 'profile:write:own',
    module: 'identity',
    description: 'Update own profile details and locale preference',
  },
  {
    code: 'creator:studio:access',
    module: 'creator',
    description: 'Access native Design Studio creator tools and templates',
  },
  {
    code: 'creator:design:submit',
    module: 'marketplace',
    description: 'Submit original designs for marketplace review',
  },
  {
    code: 'catalog:read',
    module: 'catalog',
    description: 'Read product catalog and internal catalog details',
  },
  {
    code: 'catalog:write',
    module: 'catalog',
    description: 'Manage apparel products, variants, prices, and print areas',
  },
  {
    code: 'orders:read:all',
    module: 'orders',
    description: 'View customer orders across the platform',
  },
  {
    code: 'orders:write',
    module: 'orders',
    description: 'Manage order statuses and fulfillment transitions',
  },
  {
    code: 'users:read',
    module: 'identity',
    description: 'Inspect user accounts and active roles',
  },
  {
    code: 'users:manage',
    module: 'identity',
    description: 'Suspend or reinstate user accounts',
  },
  {
    code: 'roles:manage',
    module: 'identity',
    description: 'Assign or revoke elevated staff and admin role memberships',
  },
  {
    code: 'audit:read',
    module: 'audit',
    description: 'Read platform security and operational audit logs',
  },
  {
    code: 'system:settings:write',
    module: 'platform',
    description: 'Modify runtime system settings in MariaDB',
  },
] as const;

export const DEFAULT_ROLES: readonly RoleDefinition[] = [
  {
    code: 'guest',
    name: 'Guest',
    description: 'Unauthenticated storefront visitor with public catalog access',
    permissions: ['catalog:read'],
  },
  {
    code: 'customer',
    name: 'Customer',
    description:
      'Standard shopper able to customize products, manage own profile, and place orders',
    permissions: ['catalog:read', 'profile:read:own', 'profile:write:own'],
  },
  {
    code: 'creator',
    name: 'Creator',
    description: 'Approved or opted-in apparel creator with Design Studio submission permissions',
    permissions: [
      'catalog:read',
      'profile:read:own',
      'profile:write:own',
      'creator:studio:access',
      'creator:design:submit',
    ],
  },
  {
    code: 'staff',
    name: 'Operations Staff',
    description: 'Fulfillment and customer operations operator with catalog & order access',
    permissions: [
      'catalog:read',
      'profile:read:own',
      'profile:write:own',
      'orders:read:all',
      'orders:write',
      'users:read',
    ],
  },
  {
    code: 'admin',
    name: 'Administrator',
    description: 'Platform administrator managing catalog, orders, moderation, and users',
    permissions: [
      'catalog:read',
      'catalog:write',
      'profile:read:own',
      'profile:write:own',
      'creator:studio:access',
      'creator:design:submit',
      'orders:read:all',
      'orders:write',
      'users:read',
      'users:manage',
      'audit:read',
    ],
  },
  {
    code: 'super_admin',
    name: 'Super Administrator',
    description:
      'Unrestricted platform owner with role assignment and system configuration control',
    permissions: DEFAULT_PERMISSIONS.map((permission) => permission.code),
  },
] as const;

/**
 * Resolves effective sorted permission codes from one or more assigned role codes.
 */
export function resolvePermissionsForRoles(roleCodes: readonly string[]): string[] {
  const permissionSet = new Set<string>();
  const roleMap = new Map(DEFAULT_ROLES.map((role) => [role.code as string, role.permissions]));

  for (const roleCode of roleCodes) {
    const granted = roleMap.get(roleCode);
    if (!granted) {
      continue;
    }
    for (const permission of granted) {
      permissionSet.add(permission);
    }
  }

  return Array.from(permissionSet).sort();
}
