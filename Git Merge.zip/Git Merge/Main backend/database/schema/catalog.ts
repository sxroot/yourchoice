import { relations, sql } from 'drizzle-orm';
import {
  type AnyMySqlColumn,
  bigint,
  boolean,
  char,
  datetime,
  decimal,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  uniqueIndex,
  varchar,
} from 'drizzle-orm/mysql-core';

export interface PrintAreaMockupBoundsJson {
  x: number;
  y: number;
  width: number;
  height: number;
  rotationDeg: number;
}

export interface PrintAreaUvRegionJson {
  islandKey: string;
  meshTarget: string;
  uMin: number;
  uMax: number;
  vMin: number;
  vMax: number;
}

/**
 * Hierarchical apparel categories (e.g., T-Shirts, Polo Shirts).
 */
export const productCategories = mysqlTable(
  'product_categories',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    parentId: bigint('parent_id', { mode: 'number', unsigned: true }).references(
      (): AnyMySqlColumn => productCategories.id,
      { onDelete: 'set null', onUpdate: 'cascade' }
    ),
    slug: varchar('slug', { length: 120 }).notNull(),
    nameEn: varchar('name_en', { length: 120 }).notNull(),
    nameBn: varchar('name_bn', { length: 120 }).notNull(),
    descriptionEn: varchar('description_en', { length: 500 }),
    descriptionBn: varchar('description_bn', { length: 500 }),
    sortOrder: int('sort_order').notNull().default(0),
    isActive: boolean('is_active').notNull().default(true),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
    deletedAt: datetime('deleted_at', { fsp: 3 }),
  },
  (table) => [
    uniqueIndex('uq_product_categories_public_id').on(table.publicId),
    uniqueIndex('uq_product_categories_slug').on(table.slug),
    index('idx_product_categories_parent_sort').on(table.parentId, table.sortOrder),
    index('idx_product_categories_active_deleted').on(table.isActive, table.deletedAt),
  ]
);

/**
 * Base apparel products (e.g., Crewneck Tee, Combed Pique Polo) with EN/BN metadata
 * and BDT DECIMAL(12,2) pricing (ADR-010).
 */
export const products = mysqlTable(
  'products',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    categoryId: bigint('category_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => productCategories.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    slug: varchar('slug', { length: 160 }).notNull(),
    skuPrefix: varchar('sku_prefix', { length: 40 }).notNull(),
    nameEn: varchar('name_en', { length: 160 }).notNull(),
    nameBn: varchar('name_bn', { length: 160 }).notNull(),
    subtitleEn: varchar('subtitle_en', { length: 240 }),
    subtitleBn: varchar('subtitle_bn', { length: 240 }),
    descriptionEn: text('description_en').notNull(),
    descriptionBn: text('description_bn').notNull(),
    fabricSpecEn: varchar('fabric_spec_en', { length: 240 }),
    fabricSpecBn: varchar('fabric_spec_bn', { length: 240 }),
    gsm: int('gsm', { unsigned: true }),
    fitType: varchar('fit_type', { length: 64 }),
    basePrice: decimal('base_price', { precision: 12, scale: 2 }).notNull(),
    currencyCode: char('currency_code', { length: 3 }).notNull().default('BDT'),
    isCustomizable: boolean('is_customizable').notNull().default(true),
    status: mysqlEnum('status', ['draft', 'active', 'archived']).notNull().default('draft'),
    featuredOrder: int('featured_order'),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
    deletedAt: datetime('deleted_at', { fsp: 3 }),
  },
  (table) => [
    uniqueIndex('uq_products_public_id').on(table.publicId),
    uniqueIndex('uq_products_slug').on(table.slug),
    index('idx_products_category_status').on(table.categoryId, table.status, table.deletedAt),
    index('idx_products_status_featured').on(table.status, table.featuredOrder),
  ]
);

/**
 * Purchasable SKU variants specifying color colorway, garment size, optional price override,
 * and atomic-ready stock quantity.
 */
export const productVariants = mysqlTable(
  'product_variants',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    productId: bigint('product_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => products.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    sku: varchar('sku', { length: 80 }).notNull(),
    colorNameEn: varchar('color_name_en', { length: 60 }).notNull(),
    colorNameBn: varchar('color_name_bn', { length: 60 }).notNull(),
    colorHex: char('color_hex', { length: 7 }).notNull(),
    sizeCode: mysqlEnum('size_code', ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL']).notNull(),
    priceOverride: decimal('price_override', { precision: 12, scale: 2 }),
    currencyCode: char('currency_code', { length: 3 }).notNull().default('BDT'),
    stockQuantity: int('stock_quantity', { unsigned: true }).notNull().default(0),
    isActive: boolean('is_active').notNull().default(true),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
    deletedAt: datetime('deleted_at', { fsp: 3 }),
  },
  (table) => [
    uniqueIndex('uq_product_variants_public_id').on(table.publicId),
    uniqueIndex('uq_product_variants_sku').on(table.sku),
    index('idx_product_variants_product_active').on(
      table.productId,
      table.isActive,
      table.deletedAt
    ),
    index('idx_product_variants_size_color').on(table.sizeCode, table.colorHex),
  ]
);

/**
 * Gallery images for products and optional colorway variants (front, back, detail, flat_lay).
 */
export const productImages = mysqlTable(
  'product_images',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    productId: bigint('product_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => products.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    variantId: bigint('variant_id', { mode: 'number', unsigned: true }).references(
      () => productVariants.id,
      { onDelete: 'set null', onUpdate: 'cascade' }
    ),
    viewType: mysqlEnum('view_type', ['front', 'back', 'detail', 'flat_lay']).notNull(),
    url: varchar('url', { length: 500 }).notNull(),
    altTextEn: varchar('alt_text_en', { length: 240 }).notNull(),
    altTextBn: varchar('alt_text_bn', { length: 240 }).notNull(),
    sortOrder: int('sort_order').notNull().default(0),
    isPrimary: boolean('is_primary').notNull().default(false),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_product_images_public_id').on(table.publicId),
    index('idx_product_images_product_sort').on(table.productId, table.sortOrder),
    index('idx_product_images_variant').on(table.variantId),
  ]
);

/**
 * Editor-agnostic configurable print areas per garment product (ADR-006).
 * Stores normalized [0..1] 2D mockup bounds, physical mm/DPI production dimensions,
 * and optional 3D UV island metadata for seamless Phase 2 (Fabric.js) and Phase 3 (Three.js) consumption.
 */
export const productPrintAreas = mysqlTable(
  'product_print_areas',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    productId: bigint('product_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => products.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    surfaceKey: mysqlEnum('surface_key', [
      'front',
      'back',
      'left_chest',
      'right_sleeve',
      'left_sleeve',
    ]).notNull(),
    labelEn: varchar('label_en', { length: 80 }).notNull(),
    labelBn: varchar('label_bn', { length: 80 }).notNull(),
    physicalWidthMm: int('physical_width_mm', { unsigned: true }).notNull(),
    physicalHeightMm: int('physical_height_mm', { unsigned: true }).notNull(),
    targetDpi: int('target_dpi', { unsigned: true }).notNull().default(300),
    safeInsetMm: int('safe_inset_mm', { unsigned: true }).notNull().default(10),
    coordinateSpace: varchar('coordinate_space', { length: 32 })
      .notNull()
      .default('normalized_0_1'),
    mockupBoundsJson: json('mockup_bounds_json').$type<PrintAreaMockupBoundsJson>().notNull(),
    uvRegionJson: json('uv_region_json').$type<PrintAreaUvRegionJson | null>(),
    printMethodsJson: json('print_methods_json').$type<string[]>().notNull(),
    surchargeAmount: decimal('surcharge_amount', { precision: 12, scale: 2 })
      .notNull()
      .default('0.00'),
    currencyCode: char('currency_code', { length: 3 }).notNull().default('BDT'),
    isDefault: boolean('is_default').notNull().default(false),
    isActive: boolean('is_active').notNull().default(true),
    sortOrder: int('sort_order').notNull().default(0),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_product_print_areas_public_id').on(table.publicId),
    uniqueIndex('uq_product_print_areas_product_surface').on(table.productId, table.surfaceKey),
    index('idx_product_print_areas_product_active').on(table.productId, table.isActive),
  ]
);

export const productCategoriesRelations = relations(productCategories, ({ one, many }) => ({
  parent: one(productCategories, {
    fields: [productCategories.parentId],
    references: [productCategories.id],
    relationName: 'categoryParent',
  }),
  children: many(productCategories, { relationName: 'categoryParent' }),
  products: many(products),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  category: one(productCategories, {
    fields: [products.categoryId],
    references: [productCategories.id],
  }),
  variants: many(productVariants),
  images: many(productImages),
  printAreas: many(productPrintAreas),
}));

export const productVariantsRelations = relations(productVariants, ({ one, many }) => ({
  product: one(products, {
    fields: [productVariants.productId],
    references: [products.id],
  }),
  images: many(productImages),
}));

export const productImagesRelations = relations(productImages, ({ one }) => ({
  product: one(products, {
    fields: [productImages.productId],
    references: [products.id],
  }),
  variant: one(productVariants, {
    fields: [productImages.variantId],
    references: [productVariants.id],
  }),
}));

export const productPrintAreasRelations = relations(productPrintAreas, ({ one }) => ({
  product: one(products, {
    fields: [productPrintAreas.productId],
    references: [products.id],
  }),
}));

export type ProductCategoryRow = typeof productCategories.$inferSelect;
export type NewProductCategoryRow = typeof productCategories.$inferInsert;
export type ProductRow = typeof products.$inferSelect;
export type NewProductRow = typeof products.$inferInsert;
export type ProductVariantRow = typeof productVariants.$inferSelect;
export type NewProductVariantRow = typeof productVariants.$inferInsert;
export type ProductImageRow = typeof productImages.$inferSelect;
export type NewProductImageRow = typeof productImages.$inferInsert;
export type ProductPrintAreaRow = typeof productPrintAreas.$inferSelect;
export type NewProductPrintAreaRow = typeof productPrintAreas.$inferInsert;
