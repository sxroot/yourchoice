import { relations, sql } from 'drizzle-orm';
import {
  bigint,
  char,
  datetime,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  uniqueIndex,
  varchar,
} from 'drizzle-orm/mysql-core';
import { productVariants, products } from './catalog.js';
import { users } from './identity.js';

export interface DatabaseCanonicalDesignDocumentJson {
  schemaVersion: 1;
  designId: string | null;
  productId: string;
  productVariantId: string;
  preferredMode: '2d' | '3d';
  version: number;
  surfaces: Record<string, unknown>;
  updatedAt: string;
}

export interface DatabaseDesignValidationSummaryJson {
  isValidForPrint: boolean;
  errorCount: number;
  warningCount: number;
  activePrintSurfaces: string[];
  issues: unknown[];
}

export interface DatabaseDesignSurfaceSummaryJson {
  customizedSurfaces: string[];
  estimatedCustomizationFee: string;
  currencyCode: string;
}

/**
 * Private uploaded customer/creator raster artwork stored outside public web roots (ADR-013).
 */
export const designAssets = mysqlTable(
  'design_assets',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    ownerUserId: bigint('owner_user_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    storageDriver: mysqlEnum('storage_driver', ['local', 's3']).notNull().default('local'),
    objectKey: varchar('object_key', { length: 500 }).notNull(),
    previewObjectKey: varchar('preview_object_key', { length: 500 }).notNull(),
    originalFilename: varchar('original_filename', { length: 255 }).notNull(),
    mimeType: varchar('mime_type', { length: 100 }).notNull(),
    byteSize: int('byte_size', { unsigned: true }).notNull(),
    widthPx: int('width_px', { unsigned: true }).notNull(),
    heightPx: int('height_px', { unsigned: true }).notNull(),
    sha256: char('sha256', { length: 64 }).notNull(),
    status: mysqlEnum('status', ['active', 'deleted']).notNull().default('active'),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
    deletedAt: datetime('deleted_at', { fsp: 3 }),
  },
  (table) => [
    uniqueIndex('uq_design_assets_public_id').on(table.publicId),
    index('idx_design_assets_owner_status').on(table.ownerUserId, table.status, table.createdAt),
    index('idx_design_assets_sha256').on(table.sha256),
  ]
);

/**
 * Persistent customer/creator custom garment design workspace headers.
 * Keeps canonical design identity independent from 2D Fabric.js or 3D Three.js runtime engines.
 */
export const designs = mysqlTable(
  'designs',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    ownerUserId: bigint('owner_user_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    productId: bigint('product_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => products.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    productVariantId: bigint('product_variant_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => productVariants.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    title: varchar('title', { length: 140 }).notNull(),
    preferredMode: mysqlEnum('preferred_mode', ['2d', '3d']).notNull().default('2d'),
    currentVersionNumber: int('current_version_number', { unsigned: true }).notNull().default(1),
    status: mysqlEnum('status', ['draft', 'saved', 'ordered', 'archived'])
      .notNull()
      .default('draft'),
    latestPreviewKey: varchar('latest_preview_key', { length: 500 }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
    deletedAt: datetime('deleted_at', { fsp: 3 }),
  },
  (table) => [
    uniqueIndex('uq_designs_public_id').on(table.publicId),
    index('idx_designs_owner_updated').on(table.ownerUserId, table.deletedAt, table.updatedAt),
    index('idx_designs_product_variant').on(table.productId, table.productVariantId),
  ]
);

/**
 * Versioned CanonicalDesignDocument snapshots preserving design state across edits & orders.
 */
export const designVersions = mysqlTable(
  'design_versions',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    designId: bigint('design_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => designs.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    versionNumber: int('version_number', { unsigned: true }).notNull(),
    documentJson: json('document_json').$type<DatabaseCanonicalDesignDocumentJson>().notNull(),
    validationSummaryJson: json('validation_summary_json')
      .$type<DatabaseDesignValidationSummaryJson>()
      .notNull(),
    surfaceSummaryJson: json('surface_summary_json')
      .$type<DatabaseDesignSurfaceSummaryJson>()
      .notNull(),
    createdByUserId: bigint('created_by_user_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_design_versions_public_id').on(table.publicId),
    uniqueIndex('uq_design_versions_design_version').on(table.designId, table.versionNumber),
    index('idx_design_versions_design_id').on(table.designId),
  ]
);

/**
 * Protected server-rendered 300 DPI transparent PNG production masters stored under `private/print-masters/`.
 */
export const designPrintExports = mysqlTable(
  'design_print_exports',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    designId: bigint('design_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => designs.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    designVersionId: bigint('design_version_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => designVersions.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    surfaceKey: mysqlEnum('surface_key', [
      'front',
      'back',
      'left_chest',
      'right_sleeve',
      'left_sleeve',
    ]).notNull(),
    objectKey: varchar('object_key', { length: 500 }).notNull(),
    widthPx: int('width_px', { unsigned: true }).notNull(),
    heightPx: int('height_px', { unsigned: true }).notNull(),
    dpi: int('dpi', { unsigned: true }).notNull().default(300),
    byteSize: int('byte_size', { unsigned: true }).notNull(),
    sha256: char('sha256', { length: 64 }).notNull(),
    requestedByUserId: bigint('requested_by_user_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_design_print_exports_public_id').on(table.publicId),
    index('idx_design_print_exports_design_surface').on(
      table.designId,
      table.surfaceKey,
      table.createdAt
    ),
    index('idx_design_print_exports_version').on(table.designVersionId),
  ]
);

export const designAssetsRelations = relations(designAssets, ({ one }) => ({
  owner: one(users, {
    fields: [designAssets.ownerUserId],
    references: [users.id],
  }),
}));

export const designsRelations = relations(designs, ({ one, many }) => ({
  owner: one(users, {
    fields: [designs.ownerUserId],
    references: [users.id],
  }),
  product: one(products, {
    fields: [designs.productId],
    references: [products.id],
  }),
  variant: one(productVariants, {
    fields: [designs.productVariantId],
    references: [productVariants.id],
  }),
  versions: many(designVersions),
  printExports: many(designPrintExports),
}));

export const designVersionsRelations = relations(designVersions, ({ one, many }) => ({
  design: one(designs, {
    fields: [designVersions.designId],
    references: [designs.id],
  }),
  createdBy: one(users, {
    fields: [designVersions.createdByUserId],
    references: [users.id],
  }),
  printExports: many(designPrintExports),
}));

export const designPrintExportsRelations = relations(designPrintExports, ({ one }) => ({
  design: one(designs, {
    fields: [designPrintExports.designId],
    references: [designs.id],
  }),
  designVersion: one(designVersions, {
    fields: [designPrintExports.designVersionId],
    references: [designVersions.id],
  }),
  requestedBy: one(users, {
    fields: [designPrintExports.requestedByUserId],
    references: [users.id],
  }),
}));

export type DesignAssetRow = typeof designAssets.$inferSelect;
export type NewDesignAssetRow = typeof designAssets.$inferInsert;
export type DesignRow = typeof designs.$inferSelect;
export type NewDesignRow = typeof designs.$inferInsert;
export type DesignVersionRow = typeof designVersions.$inferSelect;
export type NewDesignVersionRow = typeof designVersions.$inferInsert;
export type DesignPrintExportRow = typeof designPrintExports.$inferSelect;
export type NewDesignPrintExportRow = typeof designPrintExports.$inferInsert;
