import { sql } from 'drizzle-orm';
import { bigint, datetime, index, json, mysqlTable, varchar } from 'drizzle-orm/mysql-core';
import { users } from './identity.js';

/**
 * Append-only operational and security audit log table (ADR-011).
 */
export const auditLogs = mysqlTable(
  'audit_logs',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    actorUserId: bigint('actor_user_id', { mode: 'number', unsigned: true }).references(
      () => users.id,
      { onDelete: 'set null', onUpdate: 'cascade' }
    ),
    action: varchar('action', { length: 100 }).notNull(),
    entityType: varchar('entity_type', { length: 64 }).notNull(),
    entityPublicId: varchar('entity_public_id', { length: 64 }),
    metadataJson: json('metadata_json').$type<Record<string, unknown> | null>(),
    ipAddress: varchar('ip_address', { length: 64 }),
    requestId: varchar('request_id', { length: 64 }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    index('idx_audit_logs_actor_created').on(table.actorUserId, table.createdAt),
    index('idx_audit_logs_entity').on(table.entityType, table.entityPublicId),
    index('idx_audit_logs_action_created').on(table.action, table.createdAt),
  ]
);

export type AuditLogRow = typeof auditLogs.$inferSelect;
export type NewAuditLogRow = typeof auditLogs.$inferInsert;
