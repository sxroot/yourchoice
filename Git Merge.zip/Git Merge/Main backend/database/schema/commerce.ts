import { relations, sql } from 'drizzle-orm';
import {
  bigint,
  boolean,
  char,
  datetime,
  decimal,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  uniqueIndex,
  varchar,
} from 'drizzle-orm/mysql-core';
import { productVariants, products } from './catalog.js';
import { users } from './identity.js';

type DatabaseBangladeshDivision =
  'Dhaka' | 'Chattogram' | 'Rajshahi' | 'Khulna' | 'Barishal' | 'Sylhet' | 'Rangpur' | 'Mymensingh';

export interface ShippingAddressSnapshotJson {
  label: string | null;
  recipientName: string;
  phone: string;
  division: DatabaseBangladeshDivision;
  district: string;
  area: string;
  addressLine: string;
  postalCode: string | null;
}

export interface CustomizationMetaSnapshotJson {
  designTitle?: string | null;
  designVersionNumber?: number | null;
  preferredMode?: '2d' | '3d' | null;
  surfaces: Array<{
    surfaceKey: string;
    labelEn: string;
    labelBn: string;
    previewImageRef?: string | null;
    surchargeAmount?: string | null;
  }>;
  note?: string | null;
}

export interface OrderItemProductionSpecJson {
  printMethod?: string | null;
  targetDpi?: number | null;
  designVersionNumber?: number | null;
  preferredMode?: '2d' | '3d' | null;
  surfaces: Array<{
    surfaceKey: string;
    labelEn: string;
    labelBn: string;
    physicalWidthMm?: number | null;
    physicalHeightMm?: number | null;
    targetDpi?: number | null;
    printReadyAssetRef?: string | null;
  }>;
}

/**
 * Configurable Bangladesh shipping zones & flat/threshold rates in BDT.
 */
export const shippingZones = mysqlTable(
  'shipping_zones',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    code: varchar('code', { length: 40 }).notNull(),
    nameEn: varchar('name_en', { length: 120 }).notNull(),
    nameBn: varchar('name_bn', { length: 120 }).notNull(),
    divisionsJson: json('divisions_json').$type<DatabaseBangladeshDivision[]>().notNull(),
    flatFee: decimal('flat_fee', { precision: 12, scale: 2 }).notNull(),
    freeShippingThreshold: decimal('free_shipping_threshold', { precision: 12, scale: 2 }),
    estimatedDaysMin: int('estimated_days_min', { unsigned: true }).notNull().default(1),
    estimatedDaysMax: int('estimated_days_max', { unsigned: true }).notNull().default(3),
    currencyCode: char('currency_code', { length: 3 }).notNull().default('BDT'),
    sortOrder: int('sort_order').notNull().default(0),
    isActive: boolean('is_active').notNull().default(true),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_shipping_zones_public_id').on(table.publicId),
    uniqueIndex('uq_shipping_zones_code').on(table.code),
    index('idx_shipping_zones_active_sort').on(table.isActive, table.sortOrder),
  ]
);

/**
 * Persistent shopping carts scoped either to an authenticated user or hashed guest cart token.
 */
export const carts = mysqlTable(
  'carts',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    userId: bigint('user_id', { mode: 'number', unsigned: true }).references(() => users.id, {
      onDelete: 'cascade',
      onUpdate: 'cascade',
    }),
    guestTokenHash: char('guest_token_hash', { length: 64 }),
    currencyCode: char('currency_code', { length: 3 }).notNull().default('BDT'),
    expiresAt: datetime('expires_at', { fsp: 3 }).notNull(),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_carts_public_id').on(table.publicId),
    uniqueIndex('uq_carts_guest_token_hash').on(table.guestTokenHash),
    index('idx_carts_user_id').on(table.userId),
    index('idx_carts_expires_at').on(table.expiresAt),
  ]
);

/**
 * Persistent line items inside a cart, reserving optional `design_public_id` & customization metadata
 * for Phase 2–3 Design Studio integration without breaking standard blank variant cart lines.
 */
export const cartItems = mysqlTable(
  'cart_items',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    cartId: bigint('cart_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => carts.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    variantId: bigint('variant_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => productVariants.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    itemKey: varchar('item_key', { length: 120 }).notNull(),
    quantity: int('quantity', { unsigned: true }).notNull().default(1),
    unitPriceSnapshot: decimal('unit_price_snapshot', { precision: 12, scale: 2 }).notNull(),
    customizationFee: decimal('customization_fee', { precision: 12, scale: 2 })
      .notNull()
      .default('0.00'),
    currencyCode: char('currency_code', { length: 3 }).notNull().default('BDT'),
    designPublicId: char('design_public_id', { length: 36 }),
    customizationMetaJson: json(
      'customization_meta_json'
    ).$type<CustomizationMetaSnapshotJson | null>(),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_cart_items_public_id').on(table.publicId),
    uniqueIndex('uq_cart_items_cart_key').on(table.cartId, table.itemKey),
    index('idx_cart_items_variant_id').on(table.variantId),
  ]
);

/**
 * Immutable commercial order headers preserving BDT totals and Bangladesh address snapshots (ADR-011).
 */
export const orders = mysqlTable(
  'orders',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    orderNumber: varchar('order_number', { length: 32 }).notNull(),
    userId: bigint('user_id', { mode: 'number', unsigned: true }).references(() => users.id, {
      onDelete: 'restrict',
      onUpdate: 'cascade',
    }),
    customerEmail: varchar('customer_email', { length: 255 }).notNull(),
    customerPhone: varchar('customer_phone', { length: 32 }).notNull(),
    shippingAddressJson: json('shipping_address_json')
      .$type<ShippingAddressSnapshotJson>()
      .notNull(),
    shippingZoneCode: varchar('shipping_zone_code', { length: 40 }).notNull(),
    shippingZoneNameSnapshot: varchar('shipping_zone_name_snapshot', { length: 120 }).notNull(),
    paymentMethod: mysqlEnum('payment_method', ['cod', 'bkash', 'nagad', 'sslcommerz_card'])
      .notNull()
      .default('cod'),
    paymentStatus: mysqlEnum('payment_status', ['unpaid', 'pending', 'paid', 'failed', 'refunded'])
      .notNull()
      .default('unpaid'),
    orderStatus: mysqlEnum('order_status', [
      'pending',
      'confirmed',
      'processing',
      'packed',
      'shipped',
      'delivered',
      'cancelled',
    ])
      .notNull()
      .default('pending'),
    subtotalAmount: decimal('subtotal_amount', { precision: 12, scale: 2 }).notNull(),
    shippingAmount: decimal('shipping_amount', { precision: 12, scale: 2 }).notNull(),
    discountAmount: decimal('discount_amount', { precision: 12, scale: 2 })
      .notNull()
      .default('0.00'),
    totalAmount: decimal('total_amount', { precision: 12, scale: 2 }).notNull(),
    currencyCode: char('currency_code', { length: 3 }).notNull().default('BDT'),
    customerNote: text('customer_note'),
    cancelledAt: datetime('cancelled_at', { fsp: 3 }),
    cancellationReason: varchar('cancellation_reason', { length: 255 }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_orders_public_id').on(table.publicId),
    uniqueIndex('uq_orders_order_number').on(table.orderNumber),
    index('idx_orders_user_created').on(table.userId, table.createdAt),
    index('idx_orders_status_created').on(table.orderStatus, table.createdAt),
    index('idx_orders_customer_email').on(table.customerEmail),
  ]
);

/**
 * Immutable line-item snapshots locking SKU, colorway, size, unit price, and future custom design refs.
 */
export const orderItems = mysqlTable(
  'order_items',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    orderId: bigint('order_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => orders.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    productId: bigint('product_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => products.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    variantId: bigint('variant_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => productVariants.id, { onDelete: 'restrict', onUpdate: 'cascade' }),
    productNameEnSnapshot: varchar('product_name_en_snapshot', { length: 160 }).notNull(),
    productNameBnSnapshot: varchar('product_name_bn_snapshot', { length: 160 }).notNull(),
    productSlugSnapshot: varchar('product_slug_snapshot', { length: 160 }).notNull(),
    skuSnapshot: varchar('sku_snapshot', { length: 80 }).notNull(),
    colorNameEnSnapshot: varchar('color_name_en_snapshot', { length: 60 }).notNull(),
    colorNameBnSnapshot: varchar('color_name_bn_snapshot', { length: 60 }).notNull(),
    colorHexSnapshot: char('color_hex_snapshot', { length: 7 }).notNull(),
    sizeCodeSnapshot: varchar('size_code_snapshot', { length: 10 }).notNull(),
    primaryImageUrlSnapshot: varchar('primary_image_url_snapshot', { length: 500 }),
    quantity: int('quantity', { unsigned: true }).notNull(),
    unitPrice: decimal('unit_price', { precision: 12, scale: 2 }).notNull(),
    customizationFee: decimal('customization_fee', { precision: 12, scale: 2 })
      .notNull()
      .default('0.00'),
    lineTotal: decimal('line_total', { precision: 12, scale: 2 }).notNull(),
    currencyCode: char('currency_code', { length: 3 }).notNull().default('BDT'),
    designPublicId: char('design_public_id', { length: 36 }),
    designTitleSnapshot: varchar('design_title_snapshot', { length: 160 }),
    productionSpecJson: json('production_spec_json').$type<OrderItemProductionSpecJson | null>(),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_order_items_public_id').on(table.publicId),
    index('idx_order_items_order_id').on(table.orderId),
    index('idx_order_items_variant_id').on(table.variantId),
  ]
);

/**
 * Append-only auditable timeline of order status transitions.
 */
export const orderStatusHistory = mysqlTable(
  'order_status_history',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    orderId: bigint('order_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => orders.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    fromStatus: varchar('from_status', { length: 32 }),
    toStatus: varchar('to_status', { length: 32 }).notNull(),
    changedByUserId: bigint('changed_by_user_id', { mode: 'number', unsigned: true }).references(
      () => users.id,
      { onDelete: 'set null', onUpdate: 'cascade' }
    ),
    actorRole: varchar('actor_role', { length: 32 }),
    note: varchar('note', { length: 500 }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
  },
  (table) => [index('idx_order_status_history_order_id').on(table.orderId, table.createdAt)]
);

/**
 * Payment provider transaction ledger supporting COD promise/settlement and future signed gateway webhooks.
 */
export const paymentTransactions = mysqlTable(
  'payment_transactions',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    orderId: bigint('order_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => orders.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    gateway: mysqlEnum('gateway', ['cod', 'bkash', 'nagad', 'sslcommerz_card']).notNull(),
    transactionRef: varchar('transaction_ref', { length: 120 }),
    providerPaymentId: varchar('provider_payment_id', { length: 120 }),
    amount: decimal('amount', { precision: 12, scale: 2 }).notNull(),
    currencyCode: char('currency_code', { length: 3 }).notNull().default('BDT'),
    status: mysqlEnum('status', [
      'unpaid',
      'pending',
      'authorized',
      'paid',
      'failed',
      'cancelled',
      'refunded',
    ])
      .notNull()
      .default('unpaid'),
    verificationSource: varchar('verification_source', { length: 40 }),
    rawPayloadJson: json('raw_payload_json').$type<Record<string, unknown> | null>(),
    verifiedAt: datetime('verified_at', { fsp: 3 }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_payment_transactions_public_id').on(table.publicId),
    uniqueIndex('uq_payment_transactions_gateway_ref').on(table.gateway, table.transactionRef),
    index('idx_payment_transactions_order_id').on(table.orderId),
  ]
);

export const cartsRelations = relations(carts, ({ one, many }) => ({
  user: one(users, {
    fields: [carts.userId],
    references: [users.id],
  }),
  items: many(cartItems),
}));

export const cartItemsRelations = relations(cartItems, ({ one }) => ({
  cart: one(carts, {
    fields: [cartItems.cartId],
    references: [carts.id],
  }),
  variant: one(productVariants, {
    fields: [cartItems.variantId],
    references: [productVariants.id],
  }),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  user: one(users, {
    fields: [orders.userId],
    references: [users.id],
  }),
  items: many(orderItems),
  statusHistory: many(orderStatusHistory),
  paymentTransactions: many(paymentTransactions),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  product: one(products, {
    fields: [orderItems.productId],
    references: [products.id],
  }),
  variant: one(productVariants, {
    fields: [orderItems.variantId],
    references: [productVariants.id],
  }),
}));

export const orderStatusHistoryRelations = relations(orderStatusHistory, ({ one }) => ({
  order: one(orders, {
    fields: [orderStatusHistory.orderId],
    references: [orders.id],
  }),
}));

export const paymentTransactionsRelations = relations(paymentTransactions, ({ one }) => ({
  order: one(orders, {
    fields: [paymentTransactions.orderId],
    references: [orders.id],
  }),
}));

export type ShippingZoneRow = typeof shippingZones.$inferSelect;
export type NewShippingZoneRow = typeof shippingZones.$inferInsert;
export type CartRow = typeof carts.$inferSelect;
export type CartItemRow = typeof cartItems.$inferSelect;
export type OrderRow = typeof orders.$inferSelect;
export type OrderItemRow = typeof orderItems.$inferSelect;
export type OrderStatusHistoryRow = typeof orderStatusHistory.$inferSelect;
export type PaymentTransactionRow = typeof paymentTransactions.$inferSelect;
