import { relations, sql } from 'drizzle-orm';
import {
  bigint,
  boolean,
  char,
  datetime,
  index,
  mysqlEnum,
  mysqlTable,
  primaryKey,
  uniqueIndex,
  varchar,
} from 'drizzle-orm/mysql-core';

/**
 * Core authenticated account table.
 * Hybrid ID strategy (ADR-009): compact BIGINT UNSIGNED PK internally + non-sequential UUID `public_id` externally.
 * Soft-deleted accounts set `deleted_at` and transition `status` to `deleted` (ADR-011).
 */
export const users = mysqlTable(
  'users',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    email: varchar('email', { length: 255 }).notNull(),
    passwordHash: varchar('password_hash', { length: 255 }).notNull(),
    status: mysqlEnum('status', ['active', 'suspended', 'deleted']).notNull().default('active'),
    emailVerifiedAt: datetime('email_verified_at', { fsp: 3 }),
    lastLoginAt: datetime('last_login_at', { fsp: 3 }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
    deletedAt: datetime('deleted_at', { fsp: 3 }),
  },
  (table) => [
    uniqueIndex('uq_users_public_id').on(table.publicId),
    uniqueIndex('uq_users_email').on(table.email),
    index('idx_users_status_deleted').on(table.status, table.deletedAt),
  ]
);

/**
 * 1:1 user display/locale metadata separated from credential fields.
 */
export const userProfiles = mysqlTable('user_profiles', {
  userId: bigint('user_id', { mode: 'number', unsigned: true })
    .primaryKey()
    .references(() => users.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
  fullName: varchar('full_name', { length: 120 }).notNull(),
  phone: varchar('phone', { length: 32 }),
  preferredLocale: mysqlEnum('preferred_locale', ['en', 'bn']).notNull().default('en'),
  createdAt: datetime('created_at', { fsp: 3 })
    .notNull()
    .default(sql`CURRENT_TIMESTAMP(3)`),
  updatedAt: datetime('updated_at', { fsp: 3 })
    .notNull()
    .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
});

/**
 * System & operational RBAC roles.
 */
export const roles = mysqlTable(
  'roles',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    code: mysqlEnum('code', [
      'guest',
      'customer',
      'creator',
      'staff',
      'admin',
      'super_admin',
    ]).notNull(),
    name: varchar('name', { length: 80 }).notNull(),
    description: varchar('description', { length: 255 }),
    isSystem: boolean('is_system').notNull().default(true),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [uniqueIndex('uq_roles_code').on(table.code)]
);

/**
 * Granular capability codes bound to roles via `role_permissions`.
 */
export const permissions = mysqlTable(
  'permissions',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    code: varchar('code', { length: 100 }).notNull(),
    module: varchar('module', { length: 64 }).notNull(),
    description: varchar('description', { length: 255 }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_permissions_code').on(table.code),
    index('idx_permissions_module').on(table.module),
  ]
);

/**
 * Many-to-many role-to-permission grant mapping.
 */
export const rolePermissions = mysqlTable(
  'role_permissions',
  {
    roleId: bigint('role_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => roles.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    permissionId: bigint('permission_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => permissions.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    primaryKey({ name: 'pk_role_permissions', columns: [table.roleId, table.permissionId] }),
    index('idx_role_permissions_permission_id').on(table.permissionId),
  ]
);

/**
 * Many-to-many user-to-role assignment table with optional assigner provenance.
 */
export const userRoles = mysqlTable(
  'user_roles',
  {
    userId: bigint('user_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    roleId: bigint('role_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => roles.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    assignedByUserId: bigint('assigned_by_user_id', { mode: 'number', unsigned: true }).references(
      () => users.id,
      { onDelete: 'set null', onUpdate: 'cascade' }
    ),
    assignedAt: datetime('assigned_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    primaryKey({ name: 'pk_user_roles', columns: [table.userId, table.roleId] }),
    index('idx_user_roles_role_id').on(table.roleId),
    index('idx_user_roles_assigned_by').on(table.assignedByUserId),
  ]
);

/**
 * Server-validated stateful HTTP session records.
 * Stores SHA-256 hex digest of opaque cookie secret (`token_hash`) rather than raw tokens.
 */
export const sessions = mysqlTable(
  'sessions',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    userId: bigint('user_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    tokenHash: char('token_hash', { length: 64 }).notNull(),
    ipAddress: varchar('ip_address', { length: 64 }),
    userAgent: varchar('user_agent', { length: 512 }),
    expiresAt: datetime('expires_at', { fsp: 3 }).notNull(),
    lastSeenAt: datetime('last_seen_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    revokedAt: datetime('revoked_at', { fsp: 3 }),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    uniqueIndex('uq_sessions_public_id').on(table.publicId),
    uniqueIndex('uq_sessions_token_hash').on(table.tokenHash),
    index('idx_sessions_user_id').on(table.userId),
    index('idx_sessions_expires_at').on(table.expiresAt),
  ]
);

/**
 * Customer Bangladesh delivery addresses scoped to an authenticated user.
 * Soft-deleted per ADR-011 so historical order shipping snapshots remain unaffected.
 */
export const userAddresses = mysqlTable(
  'user_addresses',
  {
    id: bigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
    publicId: char('public_id', { length: 36 }).notNull(),
    userId: bigint('user_id', { mode: 'number', unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
    label: varchar('label', { length: 60 }).notNull(),
    recipientName: varchar('recipient_name', { length: 120 }).notNull(),
    phone: varchar('phone', { length: 32 }).notNull(),
    division: varchar('division', { length: 80 }).notNull(),
    district: varchar('district', { length: 80 }).notNull(),
    area: varchar('area', { length: 120 }).notNull(),
    addressLine: varchar('address_line', { length: 255 }).notNull(),
    postalCode: varchar('postal_code', { length: 16 }),
    isDefault: boolean('is_default').notNull().default(false),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
    deletedAt: datetime('deleted_at', { fsp: 3 }),
  },
  (table) => [
    uniqueIndex('uq_user_addresses_public_id').on(table.publicId),
    index('idx_user_addresses_user_deleted').on(table.userId, table.deletedAt),
    index('idx_user_addresses_user_default').on(table.userId, table.isDefault),
  ]
);

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(userProfiles, {
    fields: [users.id],
    references: [userProfiles.userId],
  }),
  addresses: many(userAddresses),
  sessions: many(sessions),
  userRoles: many(userRoles, { relationName: 'userRoleTarget' }),
}));

export const userProfilesRelations = relations(userProfiles, ({ one }) => ({
  user: one(users, {
    fields: [userProfiles.userId],
    references: [users.id],
  }),
}));

export const rolesRelations = relations(roles, ({ many }) => ({
  rolePermissions: many(rolePermissions),
  userRoles: many(userRoles),
}));

export const permissionsRelations = relations(permissions, ({ many }) => ({
  rolePermissions: many(rolePermissions),
}));

export const rolePermissionsRelations = relations(rolePermissions, ({ one }) => ({
  role: one(roles, {
    fields: [rolePermissions.roleId],
    references: [roles.id],
  }),
  permission: one(permissions, {
    fields: [rolePermissions.permissionId],
    references: [permissions.id],
  }),
}));

export const userRolesRelations = relations(userRoles, ({ one }) => ({
  user: one(users, {
    fields: [userRoles.userId],
    references: [users.id],
    relationName: 'userRoleTarget',
  }),
  assignedBy: one(users, {
    fields: [userRoles.assignedByUserId],
    references: [users.id],
    relationName: 'userRoleAssigner',
  }),
  role: one(roles, {
    fields: [userRoles.roleId],
    references: [roles.id],
  }),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, {
    fields: [sessions.userId],
    references: [users.id],
  }),
}));

export const userAddressesRelations = relations(userAddresses, ({ one }) => ({
  user: one(users, {
    fields: [userAddresses.userId],
    references: [users.id],
  }),
}));

export type UserRow = typeof users.$inferSelect;
export type NewUserRow = typeof users.$inferInsert;
export type UserProfileRow = typeof userProfiles.$inferSelect;
export type NewUserProfileRow = typeof userProfiles.$inferInsert;
export type UserAddressRow = typeof userAddresses.$inferSelect;
export type NewUserAddressRow = typeof userAddresses.$inferInsert;
export type RoleRow = typeof roles.$inferSelect;
export type PermissionRow = typeof permissions.$inferSelect;
export type SessionRow = typeof sessions.$inferSelect;
export type NewSessionRow = typeof sessions.$inferInsert;
