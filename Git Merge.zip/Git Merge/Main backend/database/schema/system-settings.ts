import { sql } from 'drizzle-orm';
import {
  boolean,
  datetime,
  index,
  json,
  mysqlEnum,
  mysqlTable,
  varchar,
} from 'drizzle-orm/mysql-core';

/**
 * Dynamic, database-backed platform configuration store.
 * Prevents hardcoding business rules (currency, limits, feature flags, reward defaults) in code.
 */
export const systemSettings = mysqlTable(
  'system_settings',
  {
    settingKey: varchar('setting_key', { length: 128 }).primaryKey(),
    category: varchar('category', { length: 64 }).notNull(),
    valueJson: json('value_json').notNull(),
    valueType: mysqlEnum('value_type', ['string', 'number', 'boolean', 'json'])
      .notNull()
      .default('json'),
    description: varchar('description', { length: 500 }),
    isPublic: boolean('is_public').notNull().default(false),
    createdAt: datetime('created_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3)`),
    updatedAt: datetime('updated_at', { fsp: 3 })
      .notNull()
      .default(sql`CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)`),
  },
  (table) => [
    index('idx_system_settings_category').on(table.category),
    index('idx_system_settings_public').on(table.isPublic),
  ]
);

export type SystemSettingRow = typeof systemSettings.$inferSelect;
export type NewSystemSettingRow = typeof systemSettings.$inferInsert;
