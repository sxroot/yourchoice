import path from 'node:path';
import { fileURLToPath } from 'node:url';
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const repoRootDir = path.resolve(currentDir, '../..');

export default defineConfig({
  envDir: repoRootDir,
  plugins: [react(), tailwindcss()],
  optimizeDeps: {
    include: ['three', '@react-three/fiber', '@react-three/drei', 'fabric'],
  },
  resolve: {
    alias: {
      '@': path.resolve(currentDir, 'src'),
    },
  },
  build: {
    rolldownOptions: {
      output: {
        codeSplitting: {
          groups: [
            {
              name: 'react-vendor',
              test: /node_modules[\\/](react|react-dom|react-router|react-router-dom|scheduler)/,
              priority: 30,
            },
            {
              name: 'motion-vendor',
              test: /node_modules[\\/](motion|framer-motion)/,
              priority: 25,
            },
            {
              name: 'radix-vendor',
              test: /node_modules[\\/]@radix-ui/,
              priority: 20,
            },
            {
              name: 'validation-vendor',
              test: /node_modules[\\/]zod/,
              priority: 15,
            },
            {
              name: 'fabric-vendor',
              test: /node_modules[\\/](fabric|react-easy-crop|zustand)/,
              priority: 12,
            },
            {
              name: 'three-vendor',
              test: /node_modules[\\/](three|@react-three|three-stdlib|troika-|camera-controls|maath|suspend-react|meshoptimizer)/,
              priority: 10,
            },
          ],
        },
      },
    },
  },
  server: {
    port: 5173,
    strictPort: true,
    proxy: {
      '/api': {
        target: 'http://localhost:4000',
        changeOrigin: true,
      },
    },
  },
});
