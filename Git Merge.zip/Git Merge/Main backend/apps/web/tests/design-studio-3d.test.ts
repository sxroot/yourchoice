import type {
  ProductDetailDTO,
  ProductPrintAreaDTO,
  ProductVariantDTO,
} from '@your-choice/shared-types';
import { beforeEach, describe, expect, it } from 'vitest';
import { resolveCanvasTextureSize } from '../src/features/design-studio/three/canvas-texture-bridge';
import {
  detectWebGLCapability,
  getCameraPoseForPreset,
  getCameraPresetForSurface,
  resolveGarmentModelSpec,
  resolveMeshTargetForPrintArea,
} from '../src/features/design-studio/three/webgl-support';
import { useStudioStore } from '../src/features/design-studio/studio-store';

function makeSamplePrintAreas(
  surfaceKeys: Array<'front' | 'back' | 'left_chest'>
): ProductPrintAreaDTO[] {
  return surfaceKeys.map((key, idx) => ({
    id: `pa-${key}`,
    surfaceKey: key,
    labelEn: key,
    labelBn: key,
    physicalWidthMm: key === 'left_chest' ? 95 : 280,
    physicalHeightMm: key === 'left_chest' ? 95 : 360,
    targetDpi: 300,
    safeInsetMm: 10,
    coordinateSpace: 'normalized_0_1',
    mockupBounds: { x: 0.25, y: 0.22, width: 0.4, height: 0.48, rotationDeg: 0 },
    uvRegion:
      key === 'left_chest'
        ? {
            islandKey: 'polo_left_chest',
            meshTarget: 'garment_front',
            uMin: 0.54,
            uMax: 0.72,
            vMin: 0.55,
            vMax: 0.72,
          }
        : {
            islandKey: `tee_${key}`,
            meshTarget: key === 'back' ? 'garment_back' : 'garment_front',
            uMin: 0.1,
            uMax: 0.9,
            vMin: 0.1,
            vMax: 0.9,
          },
    printMethods: ['dtf'],
    surchargeAmount: '120.00',
    currencyCode: 'BDT',
    isDefault: idx === 0,
    isActive: true,
    sortOrder: idx,
  }));
}

function makeVariant(id: string, colorHex: string, colorNameEn: string): ProductVariantDTO {
  return {
    id,
    sku: `SKU-${id}`,
    colorNameEn,
    colorNameBn: colorNameEn,
    colorHex,
    sizeCode: 'L',
    priceOverride: null,
    effectivePrice: '850.00',
    currencyCode: 'BDT',
    stockQuantity: 25,
    inStock: true,
    isActive: true,
  };
}

function makeProduct(
  slug: string,
  catSlug: string,
  surfaceKeys: Array<'front' | 'back' | 'left_chest'>
): ProductDetailDTO {
  return {
    id: `prod-${slug}`,
    slug,
    skuPrefix: `YC-${slug.slice(0, 3).toUpperCase()}`,
    nameEn: slug,
    nameBn: slug,
    subtitleEn: null,
    subtitleBn: null,
    descriptionEn: slug,
    descriptionBn: slug,
    fabricSpecEn: null,
    fabricSpecBn: null,
    basePrice: '850.00',
    minPrice: '850.00',
    maxPrice: '850.00',
    currencyCode: 'BDT',
    gsm: 220,
    fitType: 'regular',
    isCustomizable: true,
    status: 'active',
    featuredOrder: 1,
    primaryImage: null,
    availableSizes: ['L'],
    availableColors: [
      { colorNameEn: 'Obsidian Black', colorNameBn: 'কালো', colorHex: '#111827' },
      { colorNameEn: 'Midnight Navy', colorNameBn: 'নেভি', colorHex: '#172554' },
    ],
    printSurfaces: surfaceKeys,
    totalStock: 50,
    variantCount: 2,
    createdAt: '2026-01-01T00:00:00.000Z',
    updatedAt: '2026-01-01T00:00:00.000Z',
    category: { id: `cat-${catSlug}`, slug: catSlug, nameEn: catSlug, nameBn: catSlug },
    images: [],
    variants: [
      makeVariant('var-obsidian', '#111827', 'Obsidian Black'),
      makeVariant('var-navy', '#172554', 'Midnight Navy'),
    ],
    printAreas: makeSamplePrintAreas(surfaceKeys),
  };
}

describe('Phase 3 Interactive 3D Apparel Design Studio', () => {
  beforeEach(() => {
    useStudioStore.setState({
      document: null,
      savedDesignId: null,
      isDirty: false,
      pastStates: [],
      futureStates: [],
      cameraPreset: 'three_quarter',
    });
  });

  it('resolves T-Shirt vs Oversized Tee vs Polo model specs and UV island mesh bindings', () => {
    const crewTee = makeProduct('signature-heavyweight-tee', 't-shirts', ['front', 'back']);
    const oversizedTee = makeProduct('atelier-oversized-box-tee', 't-shirts', ['front', 'back']);
    const polo = makeProduct('executive-knit-polo', 'polo-shirts', ['left_chest', 'back']);

    expect(resolveGarmentModelSpec(crewTee)).toMatchObject({
      modelPath: '/models/crew-tshirt.glb',
      fabricKind: 'jersey',
      widthScale: 1,
    });
    expect(resolveGarmentModelSpec(oversizedTee).widthScale).toBeGreaterThan(1);
    expect(resolveGarmentModelSpec(polo)).toMatchObject({
      modelPath: '/models/pique-polo.glb',
      fabricKind: 'pique',
    });

    expect(resolveMeshTargetForPrintArea(crewTee.printAreas[0]!)).toBe('garment_front');
    expect(resolveMeshTargetForPrintArea(crewTee.printAreas[1]!)).toBe('garment_back');
    expect(resolveMeshTargetForPrintArea(polo.printAreas[0]!)).toBe('polo_left_chest');
    expect(resolveMeshTargetForPrintArea(polo.printAreas[1]!)).toBe('garment_back');
  });

  it('computes CanvasTexture pixel dimensions proportional to physical mm print zones and safely probes WebGL', () => {
    const portraitArea = makeSamplePrintAreas(['front'])[0]!;
    expect(
      resolveCanvasTextureSize(
        {
          physicalWidthMm: portraitArea.physicalWidthMm,
          physicalHeightMm: portraitArea.physicalHeightMm,
        },
        1280
      )
    ).toEqual({
      widthPx: 996,
      heightPx: 1280,
    });

    expect(resolveCanvasTextureSize({ physicalWidthMm: 95, physicalHeightMm: 95 }, 1024)).toEqual({
      widthPx: 1024,
      heightPx: 1024,
    });

    // In Node environment, detectWebGLCapability gracefully reports unsupported instead of throwing
    expect(detectWebGLCapability().supported).toBe(false);
    expect(getCameraPresetForSurface('back')).toBe('back');
    expect(getCameraPresetForSurface('left_chest')).toBe('left_chest');
    expect(getCameraPoseForPreset('front').position[2]).toBeGreaterThan(0);
    expect(getCameraPoseForPreset('back').position[2]).toBeLessThan(0);
  });

  it('persists preferredMode ("3d" <-> "2d"), syncs camera preset on surface selection, and keeps artwork across variant switches', () => {
    const crewTee = makeProduct('signature-heavyweight-tee', 't-shirts', ['front', 'back']);
    const navyVariant = crewTee.variants[1]!;

    useStudioStore.getState().initFromProduct(crewTee, crewTee.variants[0]!, null, '3D Test', '3d');
    expect(useStudioStore.getState().document?.preferredMode).toBe('3d');

    useStudioStore.getState().mutateActiveSurfaceObjects(() => [
      {
        id: 'txt-3d-1',
        type: 'text',
        name: 'DHAKA 2026',
        x: 0.2,
        y: 0.25,
        width: 0.6,
        height: 0.16,
        rotationDeg: 0,
        opacity: 1,
        flipX: false,
        flipY: false,
        visible: true,
        locked: false,
        text: 'DHAKA 2026',
        fontFamily: 'Space Grotesk',
        fontSizeRatio: 0.08,
        fontWeight: 700,
        fontStyle: 'normal',
        textAlign: 'center',
        fill: '#2563EB',
        stroke: null,
        strokeWidth: 0,
        lineHeight: 1.15,
        letterSpacing: 0,
      },
    ]);

    // Switching variant keeps canonical text layer untouched while swapping color SKU
    useStudioStore.getState().switchProductOrVariant(crewTee, navyVariant);
    expect(useStudioStore.getState().document?.productVariantId).toBe(navyVariant.id);
    expect(useStudioStore.getState().document?.surfaces.front?.objects).toHaveLength(1);

    // Switching surface automatically updates 3D camera target preset
    useStudioStore.getState().setActiveSurfaceKey('back');
    expect(useStudioStore.getState().cameraPreset).toBe('back');

    // Switching back to 2D updates preferredMode cleanly without dropping artwork
    useStudioStore.getState().setPreferredMode('2d');
    expect(useStudioStore.getState().document?.preferredMode).toBe('2d');
    expect(useStudioStore.getState().document?.surfaces.front?.objects).toHaveLength(1);
  });
});
