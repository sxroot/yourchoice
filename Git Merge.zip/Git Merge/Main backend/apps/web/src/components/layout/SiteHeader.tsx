import { Button, Container, IconButton } from '@your-choice/ui';
import { Languages, LogOut, Menu, Package, ShoppingBag, User } from 'lucide-react';
import { useMemo, useRef, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/features/auth/auth-context';
import { useCart } from '@/features/commerce/cart-context';
import { useAppLocale } from '@/i18n';
import { webEnv } from '@/utils/env';
import { MobileNavDrawer, type NavItem } from './MobileNavDrawer';

export function SiteHeader() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const menuTriggerRef = useRef<HTMLButtonElement>(null);
  const navigate = useNavigate();
  const isHome = useLocation().pathname === '/';
  const { locale, t, toggleLocale } = useAppLocale();
  const { user, isAuthenticated, isLoading, isLoggingOut, hasRole, logout } = useAuth();
  const { itemCount, openDrawer } = useCart();

  const navItems = useMemo<NavItem[]>(() => {
    const items: NavItem[] = [
      { label: t('nav.home'), to: '/' },
      { label: t('nav.shop'), to: '/shop' },
      { label: t('nav.tShirts'), to: '/shop/t-shirts' },
      { label: t('nav.poloShirts'), to: '/shop/polo-shirts' },
      { label: t('nav.studio'), to: '/studio' },
      { label: t('nav.designSystem'), to: '/design-system' },
    ];
    if (isAuthenticated && hasRole(['creator', 'admin', 'super_admin'])) {
      items.push({ label: t('nav.creatorHub'), to: '/creator' });
    }
    if (isAuthenticated && hasRole(['admin', 'super_admin'])) {
      items.push({ label: t('nav.admin'), to: '/admin' });
    }
    return items;
  }, [isAuthenticated, hasRole, t]);

  const handleSignOut = async () => {
    await logout();
    setMobileOpen(false);
    navigate('/', { replace: true });
  };

  return (
    <header
      className={
        isHome
          ? 'home-site-header sticky top-3 z-40 border-0 bg-transparent'
          : 'sticky top-0 z-40 border-b border-border bg-surface/90 backdrop-blur-md'
      }
    >
      <Container
        className={
          isHome
            ? 'mx-auto flex h-16 items-center justify-between gap-3 rounded-full border border-white/70 bg-white/90 px-4 shadow-[0_12px_40px_rgba(6,8,13,0.14)] backdrop-blur-xl sm:px-5'
            : 'flex h-16 items-center justify-between gap-3'
        }
      >
        <Link
          to="/"
          className="inline-flex min-h-11 shrink-0 items-center gap-3 rounded-lg pr-2 font-display text-base font-bold tracking-tight text-ink transition-opacity hover:opacity-90"
        >
          <img
            src="/brand/your-choice-logo.png"
            alt="YOUR CHOICE"
            width={36}
            height={36}
            className="size-9 shrink-0 rounded-lg border border-border-dark bg-surface-dark object-contain"
          />
          <span className="whitespace-nowrap">{webEnv.VITE_APP_NAME}</span>
        </Link>

        <nav aria-label="Primary navigation" className="hidden items-center gap-1 lg:flex">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/' || item.to === '/shop'}
              className={({ isActive }) =>
                [
                  'inline-flex min-h-10 items-center rounded-lg px-3 py-2 text-sm font-medium whitespace-nowrap transition-colors',
                  isActive
                    ? 'bg-accent-soft text-accent-ink'
                    : 'text-ink-muted hover:bg-surface-muted hover:text-ink',
                ].join(' ')
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={toggleLocale}
            aria-label={t('common.switchLanguageLabel')}
            data-testid="locale-switcher"
            className="min-h-11 whitespace-nowrap font-mono text-xs sm:min-h-9"
          >
            <Languages className="size-4" aria-hidden="true" />
            <span>{locale === 'en' ? t('common.switchToBn') : t('common.switchToEn')}</span>
          </Button>

          <Button
            type="button"
            variant="secondary"
            size="sm"
            onClick={openDrawer}
            aria-label={t('nav.cart')}
            data-testid="cart-trigger-button"
            className="relative min-h-11 whitespace-nowrap px-3 sm:min-h-9"
          >
            <ShoppingBag className="size-4" aria-hidden="true" />
            <span className="hidden sm:inline">{t('nav.cart')}</span>
            {itemCount > 0 ? (
              <span
                data-testid="cart-badge-count"
                className="inline-flex min-w-5 items-center justify-center rounded-full bg-accent px-1.5 py-0.5 font-mono text-[11px] font-bold leading-none text-white"
              >
                {itemCount}
              </span>
            ) : null}
          </Button>

          {!isLoading && isAuthenticated && user ? (
            <div className="hidden items-center gap-2 lg:flex">
              <Button asChild variant="ghost" size="sm" className="whitespace-nowrap">
                <Link to="/orders">
                  <Package className="size-4" aria-hidden="true" />
                  <span>{t('nav.orders')}</span>
                </Link>
              </Button>
              <Button asChild variant="secondary" size="sm" className="whitespace-nowrap">
                <Link to="/account">
                  <User className="size-4" aria-hidden="true" />
                  <span className="max-w-32 truncate">{user.fullName}</span>
                </Link>
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleSignOut}
                disabled={isLoggingOut}
                className="whitespace-nowrap"
              >
                <LogOut className="size-4" aria-hidden="true" />
                <span>{t('nav.signOut')}</span>
              </Button>
            </div>
          ) : !isLoading ? (
            <div className="hidden items-center gap-2 lg:flex">
              <Button asChild variant="ghost" size="sm" className="whitespace-nowrap">
                <Link to="/login">{t('nav.signIn')}</Link>
              </Button>
              <Button asChild variant="primary" size="sm" className="whitespace-nowrap">
                <Link to="/register">{t('nav.createAccount')}</Link>
              </Button>
            </div>
          ) : null}

          <IconButton
            ref={menuTriggerRef}
            variant="secondary"
            aria-label="Open navigation menu"
            aria-expanded={mobileOpen}
            aria-controls="mobile-nav-drawer"
            className="lg:hidden"
            onClick={() => setMobileOpen(true)}
          >
            <Menu className="size-5" aria-hidden="true" />
          </IconButton>
        </div>
      </Container>

      <MobileNavDrawer
        open={mobileOpen}
        onOpenChange={setMobileOpen}
        items={navItems}
        returnFocusRef={menuTriggerRef}
        isAuthenticated={isAuthenticated}
        userFullName={user?.fullName ?? null}
        userRoles={user?.roles ?? []}
        isLoggingOut={isLoggingOut}
        onSignOut={handleSignOut}
      />
    </header>
  );
}
