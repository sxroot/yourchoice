import type { UserRole } from '@your-choice/shared-types';
import {
  Badge,
  Button,
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@your-choice/ui';
import { ArrowRight, Languages, LogOut, Package, ShoppingBag, User } from 'lucide-react';
import type { RefObject } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useAppLocale } from '@/i18n';
import { webEnv } from '@/utils/env';

export interface NavItem {
  label: string;
  to: string;
  description?: string;
}

export interface MobileNavDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: readonly NavItem[];
  returnFocusRef?: RefObject<HTMLButtonElement | null>;
  isAuthenticated?: boolean;
  userFullName?: string | null;
  userRoles?: readonly UserRole[];
  isLoggingOut?: boolean;
  onSignOut?: () => void;
}

/**
 * Accessible slide-over mobile navigation drawer with >= 44px touch targets and role-aware actions.
 */
export function MobileNavDrawer({
  open,
  onOpenChange,
  items,
  returnFocusRef,
  isAuthenticated = false,
  userFullName = null,
  userRoles = [],
  isLoggingOut = false,
  onSignOut,
}: MobileNavDrawerProps) {
  const { locale, t, toggleLocale } = useAppLocale();

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent
        id="mobile-nav-drawer"
        side="right"
        className="bg-surface"
        onCloseAutoFocus={(event) => {
          if (returnFocusRef?.current) {
            event.preventDefault();
            returnFocusRef.current.focus();
          }
        }}
      >
        <DrawerHeader className="border-b border-border pb-4">
          <div className="flex items-center gap-3">
            <img
              src="/brand/your-choice-logo.png"
              alt="YOUR CHOICE logo"
              width={40}
              height={40}
              className="size-10 shrink-0 rounded-lg border border-border-dark bg-surface-dark object-contain"
            />
            <div className="min-w-0">
              <DrawerTitle className="truncate text-base">{webEnv.VITE_APP_NAME}</DrawerTitle>
              <DrawerDescription className="text-xs">{t('common.tagline')}</DrawerDescription>
            </div>
          </div>
        </DrawerHeader>

        <nav aria-label="Mobile navigation" className="mt-5 flex flex-col gap-2">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/' || item.to === '/shop'}
              onClick={() => onOpenChange(false)}
              className={({ isActive }) =>
                [
                  'flex min-h-12 items-center justify-between gap-3 rounded-xl px-4 py-3 text-base font-medium transition-colors',
                  isActive
                    ? 'bg-accent-soft text-accent-ink ring-1 ring-accent/20'
                    : 'text-ink hover:bg-surface-muted',
                ].join(' ')
              }
            >
              <span>{item.label}</span>
              <ArrowRight className="size-4 shrink-0 opacity-70" aria-hidden="true" />
            </NavLink>
          ))}
        </nav>

        <div className="mt-6 space-y-2.5 border-t border-border pt-5">
          <Button
            type="button"
            variant="outline"
            className="w-full justify-between"
            onClick={toggleLocale}
          >
            <span className="inline-flex items-center gap-2">
              <Languages className="size-4" aria-hidden="true" />
              {t('common.switchLanguageLabel')}
            </span>
            <span className="font-mono text-xs">
              {locale === 'en' ? t('common.switchToBn') : t('common.switchToEn')}
            </span>
          </Button>

          <Button
            asChild
            variant="secondary"
            className="w-full justify-start"
            onClick={() => onOpenChange(false)}
          >
            <Link to="/cart">
              <ShoppingBag className="size-4" aria-hidden="true" />
              {t('nav.cart')}
            </Link>
          </Button>

          {isAuthenticated && userFullName ? (
            <>
              <div className="flex items-center justify-between gap-2 rounded-xl bg-surface-muted px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-ink">{userFullName}</p>
                  <p className="text-xs text-ink-muted">{userRoles.join(', ')}</p>
                </div>
                <Badge variant="accent">Active</Badge>
              </div>
              <Button
                asChild
                variant="secondary"
                className="w-full justify-start"
                onClick={() => onOpenChange(false)}
              >
                <Link to="/orders">
                  <Package className="size-4" aria-hidden="true" />
                  {t('nav.orders')}
                </Link>
              </Button>
              <Button
                asChild
                variant="secondary"
                className="w-full justify-start"
                onClick={() => onOpenChange(false)}
              >
                <Link to="/account">
                  <User className="size-4" aria-hidden="true" />
                  {t('nav.accountProfile')}
                </Link>
              </Button>
              <Button
                type="button"
                variant="outline"
                className="w-full justify-start"
                disabled={isLoggingOut}
                onClick={onSignOut}
              >
                <LogOut className="size-4" aria-hidden="true" />
                {isLoggingOut ? t('nav.signingOut') : t('nav.signOut')}
              </Button>
            </>
          ) : (
            <div className="grid gap-2.5">
              <Button
                asChild
                variant="primary"
                className="w-full"
                onClick={() => onOpenChange(false)}
              >
                <Link to="/register">{t('nav.createAccount')}</Link>
              </Button>
              <Button
                asChild
                variant="secondary"
                className="w-full"
                onClick={() => onOpenChange(false)}
              >
                <Link to="/login">{t('nav.signIn')}</Link>
              </Button>
            </div>
          )}
        </div>

        <DrawerFooter className="border-t border-border pt-4">
          <div className="flex items-center justify-between gap-2">
            <Badge variant="accent">Phase 1B Storefront</Badge>
            <span className="font-mono text-xs text-ink-muted">allyourchoice.com</span>
          </div>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}
