import { Badge, Container } from '@your-choice/ui';
import { Link } from 'react-router-dom';
import { useAppLocale } from '@/i18n';
import { webEnv } from '@/utils/env';

/**
 * Brand dark-tech footer featuring preserved logo, high-contrast silver copy, and route links.
 */
export function SiteFooter() {
  const { t } = useAppLocale();

  return (
    <footer className="border-t border-border-dark bg-dark-tech text-ink-inverse">
      <Container className="py-10 sm:py-12">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <div className="max-w-md space-y-3">
            <Link to="/" className="inline-flex items-center gap-3">
              <img
                src="/brand/your-choice-logo.png"
                alt="YOUR CHOICE"
                width={40}
                height={40}
                className="size-10 shrink-0 rounded-lg border border-border-dark bg-surface-dark object-contain"
              />
              <div>
                <p className="font-display text-base font-bold tracking-tight text-ink-inverse">
                  {webEnv.VITE_APP_NAME}
                </p>
                <p className="text-xs text-ink-silver">{t('common.tagline')}</p>
              </div>
            </Link>
            <p className="text-sm leading-relaxed text-ink-silver">{t('footer.description')}</p>
          </div>

          <div className="flex flex-wrap gap-8 sm:gap-12">
            <div className="space-y-2.5">
              <p className="font-mono text-xs font-semibold tracking-wider text-accent-cyan-bright uppercase">
                {t('footer.storefrontHeading')}
              </p>
              <ul className="space-y-1.5 text-sm">
                <li>
                  <Link
                    to="/shop"
                    className="inline-flex min-h-11 items-center text-ink-silver transition-colors hover:text-ink-inverse sm:min-h-9"
                  >
                    {t('nav.shop')}
                  </Link>
                </li>
                <li>
                  <Link
                    to="/shop/t-shirts"
                    className="inline-flex min-h-11 items-center text-ink-silver transition-colors hover:text-ink-inverse sm:min-h-9"
                  >
                    {t('nav.tShirts')}
                  </Link>
                </li>
                <li>
                  <Link
                    to="/shop/polo-shirts"
                    className="inline-flex min-h-11 items-center text-ink-silver transition-colors hover:text-ink-inverse sm:min-h-9"
                  >
                    {t('nav.poloShirts')}
                  </Link>
                </li>
              </ul>
            </div>

            <div className="space-y-2.5">
              <p className="font-mono text-xs font-semibold tracking-wider text-accent-cyan-bright uppercase">
                {t('footer.foundationHeading')}
              </p>
              <ul className="space-y-1.5 text-sm">
                <li>
                  <Link
                    to="/"
                    className="inline-flex min-h-11 items-center text-ink-silver transition-colors hover:text-ink-inverse sm:min-h-9"
                  >
                    {t('nav.home')}
                  </Link>
                </li>
                <li>
                  <Link
                    to="/design-system"
                    className="inline-flex min-h-11 items-center text-ink-silver transition-colors hover:text-ink-inverse sm:min-h-9"
                  >
                    {t('nav.designSystem')}
                  </Link>
                </li>
                <li>
                  <Link
                    to="/account"
                    className="inline-flex min-h-11 items-center text-ink-silver transition-colors hover:text-ink-inverse sm:min-h-9"
                  >
                    {t('nav.accountProfile')}
                  </Link>
                </li>
              </ul>
            </div>

            <div className="space-y-2.5">
              <p className="font-mono text-xs font-semibold tracking-wider text-accent-cyan-bright uppercase">
                Architecture
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="dark">React + Vite</Badge>
                <Badge variant="dark">Express 5</Badge>
                <Badge variant="dark">Drizzle + MariaDB</Badge>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-col gap-2 border-t border-border-dark pt-6 text-xs text-ink-silver sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} YOUR CHOICE · allyourchoice.com</p>
          <p className="font-mono">Phase 1B · Bilingual Storefront &amp; Apparel Catalogue</p>
        </div>
      </Container>
    </footer>
  );
}
