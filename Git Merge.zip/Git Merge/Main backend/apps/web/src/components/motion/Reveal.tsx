import { m, useReducedMotion } from 'motion/react';
import type { HTMLMotionProps } from 'motion/react';
import type { ReactNode } from 'react';
import { MOTION_DURATION, MOTION_EASE_OUT_EXPO } from './motion-tokens';

export interface RevealProps extends Omit<HTMLMotionProps<'div'>, 'children'> {
  children: ReactNode;
  delay?: number;
  distance?: number;
}

/**
 * Scroll-triggered GPU reveal (opacity + translateY) that triggers once and respects reduced motion.
 */
export function Reveal({ children, delay = 0, distance = 20, className, ...props }: RevealProps) {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <m.div
      initial={{ opacity: 0, y: distance }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.1 }}
      transition={{
        duration: MOTION_DURATION.reveal,
        delay,
        ease: MOTION_EASE_OUT_EXPO,
      }}
      className={className}
      {...props}
    >
      {children}
    </m.div>
  );
}
