import { m, useReducedMotion } from 'motion/react';
import type { HTMLMotionProps } from 'motion/react';
import type { ReactNode } from 'react';
import { MOTION_DURATION, MOTION_EASE_OUT_EXPO } from './motion-tokens';

export type SlideDirection = 'up' | 'down' | 'left' | 'right';

export interface SlideInProps extends Omit<HTMLMotionProps<'div'>, 'children'> {
  children: ReactNode;
  direction?: SlideDirection;
  distance?: number;
  delay?: number;
}

function getOffset(direction: SlideDirection, distance: number) {
  switch (direction) {
    case 'up':
      return { x: 0, y: distance };
    case 'down':
      return { x: 0, y: -distance };
    case 'left':
      return { x: distance, y: 0 };
    case 'right':
      return { x: -distance, y: 0 };
  }
}

/**
 * Directional GPU slide entrance using transform and opacity only.
 */
export function SlideIn({
  children,
  direction = 'up',
  distance = 18,
  delay = 0,
  className,
  ...props
}: SlideInProps) {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  const offset = getOffset(direction, distance);

  return (
    <m.div
      initial={{ opacity: 0, x: offset.x, y: offset.y }}
      animate={{ opacity: 1, x: 0, y: 0 }}
      transition={{
        duration: MOTION_DURATION.reveal,
        delay,
        ease: MOTION_EASE_OUT_EXPO,
      }}
      className={className}
      {...props}
    >
      {children}
    </m.div>
  );
}
