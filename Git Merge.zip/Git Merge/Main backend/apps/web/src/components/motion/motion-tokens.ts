export const MOTION_EASE_OUT_EXPO = [0.16, 1, 0.3, 1] as const;
export const MOTION_EASE_SNAPPY = [0.4, 0, 0.2, 1] as const;

export const MOTION_DURATION = {
  micro: 0.15,
  panel: 0.24,
  reveal: 0.5,
} as const;
