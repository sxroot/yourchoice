import { m, useReducedMotion } from 'motion/react';
import type { HTMLMotionProps } from 'motion/react';
import type { ReactNode } from 'react';
import { MOTION_DURATION, MOTION_EASE_SNAPPY } from './motion-tokens';

export interface FadeInProps extends Omit<HTMLMotionProps<'div'>, 'children'> {
  children: ReactNode;
  delay?: number;
  duration?: number;
}

/**
 * Subtle mount opacity transition for panels, headers, and above-the-fold blocks.
 */
export function FadeIn({
  children,
  delay = 0,
  duration = MOTION_DURATION.panel,
  className,
  ...props
}: FadeInProps) {
  const shouldReduceMotion = useReducedMotion();

  if (shouldReduceMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <m.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration, delay, ease: MOTION_EASE_SNAPPY }}
      className={className}
      {...props}
    >
      {children}
    </m.div>
  );
}
