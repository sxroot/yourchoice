import type { HealthCheckResponse } from '@your-choice/shared-types';
import { apiGet, ApiClientError } from './api-client';

export async function fetchHealthStatus(signal?: AbortSignal): Promise<HealthCheckResponse> {
  const response = await apiGet<HealthCheckResponse>('/health', signal);
  if (!response.success) {
    throw new ApiClientError(response.error.message, 500, response.error.code);
  }
  return response.data;
}
