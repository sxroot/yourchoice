import type { ApiErrorDetail, ApiResponse, CsrfTokenResponseData } from '@your-choice/shared-types';
import { webEnv } from '@/utils/env';

const CSRF_COOKIE_NAME = 'yc_csrf';
let cachedCsrfToken: string | null = null;

export class ApiClientError extends Error {
  public readonly status: number;
  public readonly code: string;
  public readonly details?: ApiErrorDetail[];

  constructor(message: string, status: number, code = 'API_ERROR', details?: ApiErrorDetail[]) {
    super(message);
    this.name = 'ApiClientError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export function setClientCsrfToken(token: string | null): void {
  cachedCsrfToken = token;
}

function readCookieValue(name: string): string | null {
  if (typeof document === 'undefined' || !document.cookie) {
    return null;
  }

  const pairs = document.cookie.split(';');
  for (const pair of pairs) {
    const eqIndex = pair.indexOf('=');
    if (eqIndex <= 0) {
      continue;
    }
    const key = pair.slice(0, eqIndex).trim();
    if (key === name) {
      try {
        return decodeURIComponent(pair.slice(eqIndex + 1).trim());
      } catch {
        return pair.slice(eqIndex + 1).trim();
      }
    }
  }

  return null;
}

export function buildApiUrl(path: string): string {
  const baseUrl = webEnv.VITE_API_BASE_URL.replace(/\/$/, '');
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return `${baseUrl}${normalizedPath}`;
}

async function parseJsonResponse<T>(response: Response): Promise<ApiResponse<T>> {
  let payload: unknown = null;
  const contentType = response.headers.get('content-type') ?? '';
  if (contentType.includes('application/json')) {
    payload = await response.json();
  }

  if (!response.ok) {
    if (
      typeof payload === 'object' &&
      payload !== null &&
      'error' in payload &&
      typeof payload.error === 'object' &&
      payload.error !== null &&
      'message' in payload.error &&
      typeof payload.error.message === 'string'
    ) {
      const code =
        'code' in payload.error && typeof payload.error.code === 'string'
          ? payload.error.code
          : 'API_ERROR';
      const details =
        'details' in payload.error && Array.isArray(payload.error.details)
          ? (payload.error.details as ApiErrorDetail[])
          : undefined;
      throw new ApiClientError(payload.error.message, response.status, code, details);
    }

    throw new ApiClientError(
      `Request failed with status ${response.status}`,
      response.status,
      'HTTP_ERROR'
    );
  }

  if (!payload || typeof payload !== 'object') {
    throw new ApiClientError(
      'Expected JSON response from API',
      response.status,
      'INVALID_RESPONSE'
    );
  }

  return payload as ApiResponse<T>;
}

async function ensureClientCsrfToken(signal?: AbortSignal): Promise<string> {
  const cookieToken = readCookieValue(CSRF_COOKIE_NAME);
  if (cookieToken) {
    cachedCsrfToken = cookieToken;
    return cookieToken;
  }

  if (cachedCsrfToken) {
    return cachedCsrfToken;
  }

  const res = await fetch(buildApiUrl('/auth/csrf'), {
    method: 'GET',
    credentials: 'include',
    headers: {
      Accept: 'application/json',
    },
    signal,
  });

  const parsed = await parseJsonResponse<CsrfTokenResponseData>(res);
  if (parsed.success && parsed.data.csrfToken) {
    cachedCsrfToken = parsed.data.csrfToken;
    return parsed.data.csrfToken;
  }

  throw new ApiClientError('Unable to initialize CSRF protection token', 403, 'CSRF_INIT_FAILED');
}

export interface ApiRequestOptions {
  body?: unknown;
  signal?: AbortSignal;
}

export async function apiRequest<T>(
  method: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE',
  path: string,
  options?: ApiRequestOptions
): Promise<ApiResponse<T>> {
  const isMutating = method !== 'GET';
  const headers: Record<string, string> = {
    Accept: 'application/json',
  };

  if (isMutating) {
    const csrfToken = await ensureClientCsrfToken(options?.signal);
    headers['X-CSRF-Token'] = csrfToken;
    if (options?.body !== undefined) {
      headers['Content-Type'] = 'application/json';
    }
  }

  const response = await fetch(buildApiUrl(path), {
    method,
    credentials: 'include',
    headers,
    ...(isMutating && options?.body !== undefined ? { body: JSON.stringify(options.body) } : {}),
    signal: options?.signal,
  });

  return parseJsonResponse<T>(response);
}

export function apiGet<T>(path: string, signal?: AbortSignal): Promise<ApiResponse<T>> {
  return apiRequest<T>('GET', path, { signal });
}

export function apiPost<T>(
  path: string,
  body?: unknown,
  signal?: AbortSignal
): Promise<ApiResponse<T>> {
  return apiRequest<T>('POST', path, { body, signal });
}

export function apiPatch<T>(
  path: string,
  body: unknown,
  signal?: AbortSignal
): Promise<ApiResponse<T>> {
  return apiRequest<T>('PATCH', path, { body, signal });
}

export function apiPut<T>(
  path: string,
  body: unknown,
  signal?: AbortSignal
): Promise<ApiResponse<T>> {
  return apiRequest<T>('PUT', path, { body, signal });
}

export function apiDelete<T>(path: string, signal?: AbortSignal): Promise<ApiResponse<T>> {
  return apiRequest<T>('DELETE', path, { signal });
}

export async function apiUploadFormData<T>(
  path: string,
  formData: FormData,
  signal?: AbortSignal
): Promise<ApiResponse<T>> {
  const csrfToken = await ensureClientCsrfToken(signal);
  const response = await fetch(buildApiUrl(path), {
    method: 'POST',
    credentials: 'include',
    headers: {
      Accept: 'application/json',
      'X-CSRF-Token': csrfToken,
    },
    body: formData,
    signal,
  });

  return parseJsonResponse<T>(response);
}
