import type { PreferredLocale } from '@your-choice/shared-types';
import { formatMoneyDisplay } from '@your-choice/shared-utils';
import i18n from 'i18next';
import { initReactI18next, useTranslation } from 'react-i18next';
import { i18nResources } from './resources';

const LOCALE_STORAGE_KEY = 'yc_locale';

function readInitialLocale(): PreferredLocale {
  if (typeof window === 'undefined') {
    return 'en';
  }
  const stored = window.localStorage.getItem(LOCALE_STORAGE_KEY);
  return stored === 'bn' ? 'bn' : 'en';
}

function syncDocumentLang(locale: PreferredLocale): void {
  if (typeof document !== 'undefined') {
    document.documentElement.lang = locale;
  }
}

const initialLocale = readInitialLocale();
syncDocumentLang(initialLocale);

void i18n.use(initReactI18next).init({
  resources: i18nResources,
  lng: initialLocale,
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false,
  },
});

export function setAppLocale(locale: PreferredLocale): void {
  syncDocumentLang(locale);
  if (typeof window !== 'undefined') {
    window.localStorage.setItem(LOCALE_STORAGE_KEY, locale);
  }
  void i18n.changeLanguage(locale);
}

export function useAppLocale() {
  const { i18n: i18nInstance, t } = useTranslation();
  const locale: PreferredLocale = i18nInstance.language === 'bn' ? 'bn' : 'en';

  return {
    locale,
    t,
    setLocale: setAppLocale,
    toggleLocale: () => setAppLocale(locale === 'en' ? 'bn' : 'en'),
  };
}

export function pickLocalizedText(
  locale: PreferredLocale,
  enText: string | null | undefined,
  bnText: string | null | undefined
): string {
  if (locale === 'bn' && bnText && bnText.trim().length > 0) {
    return bnText;
  }
  return enText ?? bnText ?? '';
}

export function formatBdtPrice(amount: string, currencyCode = 'BDT'): string {
  return formatMoneyDisplay(amount, currencyCode);
}
