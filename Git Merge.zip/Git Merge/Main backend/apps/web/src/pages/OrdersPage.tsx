import { useQuery } from '@tanstack/react-query';
import { Badge, Button, Card, Container, EmptyState, LoadingState, Section } from '@your-choice/ui';
import { ArrowRight, Package } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { fetchMyOrders } from '@/features/commerce/commerce.api';
import { OrderStatusBadge, PaymentStatusBadge } from '@/features/commerce/OrderStatusBadge';
import { formatBdtPrice, useAppLocale } from '@/i18n';

export function OrdersPage() {
  const { t } = useAppLocale();
  const [page, setPage] = useState(1);

  const ordersQuery = useQuery({
    queryKey: ['orders', 'me', page],
    queryFn: ({ signal }) => fetchMyOrders(page, 15, signal),
    staleTime: 15_000,
  });

  return (
    <Section spacing="md">
      <Container className="space-y-6">
        <div className="space-y-1.5 border-b border-border pb-5">
          <Badge variant="accent">{t('orders.historyBadge')}</Badge>
          <h1 className="font-display text-2xl font-bold tracking-tight text-ink sm:text-3xl">
            {t('orders.historyTitle')}
          </h1>
          <p className="text-sm text-ink-muted">{t('orders.historyDesc')}</p>
        </div>

        {ordersQuery.isLoading ? (
          <LoadingState label={t('common.loading')} />
        ) : ordersQuery.isError ? (
          <Card className="border-danger/30 bg-danger-soft p-6 text-sm text-danger">
            {ordersQuery.error instanceof Error
              ? ordersQuery.error.message
              : 'Unable to load orders.'}
          </Card>
        ) : !ordersQuery.data || ordersQuery.data.orders.length === 0 ? (
          <EmptyState
            icon={<Package className="size-6" />}
            title={t('orders.emptyTitle')}
            description={t('orders.emptyDesc')}
            action={
              <Button asChild variant="primary">
                <Link to="/shop">{t('cart.browseCatalogue')}</Link>
              </Button>
            }
          />
        ) : (
          <div className="space-y-4">
            {ordersQuery.data.orders.map((order) => (
              <Card
                key={order.id}
                className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-base font-bold text-ink">
                      {order.orderNumber}
                    </span>
                    <OrderStatusBadge status={order.orderStatus} />
                    <PaymentStatusBadge status={order.paymentStatus} />
                  </div>
                  <p className="text-xs text-ink-muted">
                    {new Date(order.createdAt).toLocaleString()} ·{' '}
                    {t('orders.itemsCount', { count: order.itemCount })} · {order.shippingDivision}{' '}
                    ({order.shippingZoneName})
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 sm:justify-end">
                  <div className="text-left sm:text-right">
                    <p className="font-mono text-base font-bold text-ink">
                      {formatBdtPrice(order.totalAmount, order.currencyCode)}
                    </p>
                    <p className="font-mono text-[11px] uppercase text-ink-muted">
                      {order.paymentMethod}
                    </p>
                  </div>
                  <Button asChild variant="secondary" size="sm">
                    <Link to={`/orders/${order.orderNumber}`}>
                      <span>{t('orders.viewDetails')}</span>
                      <ArrowRight className="size-4" aria-hidden="true" />
                    </Link>
                  </Button>
                </div>
              </Card>
            ))}

            {ordersQuery.data.pagination.totalPages > 1 ? (
              <div className="flex items-center justify-between pt-2">
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                >
                  {t('shop.previous')}
                </Button>
                <span className="font-mono text-xs text-ink-muted">
                  {t('shop.pageOf', {
                    page: ordersQuery.data.pagination.page,
                    totalPages: ordersQuery.data.pagination.totalPages,
                  })}
                </span>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  disabled={page >= ordersQuery.data.pagination.totalPages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  {t('shop.next')}
                </Button>
              </div>
            ) : null}
          </div>
        )}
      </Container>
    </Section>
  );
}
