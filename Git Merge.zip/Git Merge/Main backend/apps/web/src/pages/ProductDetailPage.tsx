import { useQuery } from '@tanstack/react-query';
import type {
  PrintAreaSurfaceKey,
  ProductImageDTO,
  ProductPrintAreaDTO,
  ProductVariantDTO,
} from '@your-choice/shared-types';
import { Badge, Button, Card, Container, EmptyState, LoadingState, Section } from '@your-choice/ui';
import {
  ArrowLeft,
  Check,
  Eye,
  EyeOff,
  Layers,
  MapPin,
  Minus,
  Plus,
  Ruler,
  Shirt,
  ShoppingBag,
  Sparkles,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { GarmentStagePreview } from '@/features/catalog/components/GarmentStagePreview';
import { fetchPublicProductBySlug } from '@/features/catalog/catalog.api';
import { useCart } from '@/features/commerce/cart-context';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';

function matchImageForSurface(
  images: ProductImageDTO[],
  surfaceKey: PrintAreaSurfaceKey | null
): ProductImageDTO | null {
  if (images.length === 0) return null;
  if (surfaceKey === 'back') {
    const backImg = images.find((img) => img.viewType === 'back');
    if (backImg) return backImg;
  }
  const frontImg = images.find((img) => img.viewType === 'front' || img.isPrimary);
  return frontImg ?? images[0] ?? null;
}

export function ProductDetailPage() {
  const { slug = '' } = useParams<{ slug: string }>();
  const { locale, t } = useAppLocale();

  const [selectedColorNameEn, setSelectedColorNameEn] = useState<string | null>(null);
  const [selectedSizeCode, setSelectedSizeCode] = useState<string | null>(null);
  const [selectedSurfaceKey, setSelectedSurfaceKey] = useState<PrintAreaSurfaceKey | null>(null);
  const [selectedImageId, setSelectedImageId] = useState<string | null>(null);
  const [showPrintGuide, setShowPrintGuide] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [cartFeedback, setCartFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);
  const { addItem, isMutating: isCartMutating } = useCart();

  const productQuery = useQuery({
    queryKey: ['catalog', 'product', slug],
    queryFn: ({ signal }) => fetchPublicProductBySlug(slug, signal),
    enabled: Boolean(slug),
    retry: false,
  });

  const product = productQuery.data;

  const activeColorNameEn = useMemo(() => {
    if (!product || product.availableColors.length === 0) return null;
    if (
      selectedColorNameEn &&
      product.availableColors.some((c) => c.colorNameEn === selectedColorNameEn)
    ) {
      return selectedColorNameEn;
    }
    return product.availableColors[0]!.colorNameEn;
  }, [product, selectedColorNameEn]);

  const activeColorSwatch = useMemo(() => {
    if (!product || !activeColorNameEn) return null;
    return product.availableColors.find((c) => c.colorNameEn === activeColorNameEn) ?? null;
  }, [product, activeColorNameEn]);

  const variantsForColor = useMemo<ProductVariantDTO[]>(() => {
    if (!product) return [];
    const active = product.variants.filter((v) => v.isActive);
    if (!activeColorNameEn) return active;
    return active.filter((v) => v.colorNameEn === activeColorNameEn);
  }, [product, activeColorNameEn]);

  const selectedVariant = useMemo<ProductVariantDTO | null>(() => {
    if (variantsForColor.length === 0) return null;
    if (selectedSizeCode) {
      const exact = variantsForColor.find((v) => v.sizeCode === selectedSizeCode);
      if (exact) return exact;
    }
    return variantsForColor.find((v) => v.inStock) ?? variantsForColor[0] ?? null;
  }, [variantsForColor, selectedSizeCode]);

  const activePrintAreas = useMemo<ProductPrintAreaDTO[]>(() => {
    if (!product) return [];
    return product.printAreas.filter((pa) => pa.isActive);
  }, [product]);

  const activePrintArea = useMemo<ProductPrintAreaDTO | null>(() => {
    if (activePrintAreas.length === 0) return null;
    if (selectedSurfaceKey) {
      const matched = activePrintAreas.find((pa) => pa.surfaceKey === selectedSurfaceKey);
      if (matched) return matched;
    }
    return activePrintAreas.find((pa) => pa.isDefault) ?? activePrintAreas[0] ?? null;
  }, [activePrintAreas, selectedSurfaceKey]);

  const activeImage = useMemo<ProductImageDTO | null>(() => {
    if (!product) return null;
    if (selectedImageId) {
      const matched = product.images.find((img) => img.id === selectedImageId);
      if (matched) return matched;
    }
    return matchImageForSurface(product.images, activePrintArea?.surfaceKey ?? null);
  }, [product, selectedImageId, activePrintArea]);

  if (productQuery.isLoading) {
    return (
      <Section spacing="md">
        <Container>
          <LoadingState label={t('common.loading')} />
        </Container>
      </Section>
    );
  }

  if (productQuery.isError || !product) {
    return (
      <Section spacing="md">
        <Container>
          <EmptyState
            icon={<Shirt className="size-6" />}
            title={t('product.notFoundTitle')}
            description={t('product.notFoundDesc')}
            action={
              <Button asChild variant="secondary">
                <Link to="/shop">
                  <ArrowLeft className="size-4" aria-hidden="true" />
                  {t('product.backToShop')}
                </Link>
              </Button>
            }
          />
        </Container>
      </Section>
    );
  }

  const title = pickLocalizedText(locale, product.nameEn, product.nameBn);
  const subtitle = pickLocalizedText(locale, product.subtitleEn, product.subtitleBn);
  const description = pickLocalizedText(locale, product.descriptionEn, product.descriptionBn);
  const fabricSpec = pickLocalizedText(locale, product.fabricSpecEn, product.fabricSpecBn);
  const categoryName = pickLocalizedText(locale, product.category.nameEn, product.category.nameBn);

  const displayedPrice = selectedVariant
    ? formatBdtPrice(selectedVariant.effectivePrice, selectedVariant.currencyCode)
    : formatBdtPrice(product.basePrice, product.currencyCode);

  const activeColorDisplay = activeColorSwatch
    ? pickLocalizedText(locale, activeColorSwatch.colorNameEn, activeColorSwatch.colorNameBn)
    : undefined;

  return (
    <Section spacing="md">
      <Container className="space-y-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link
            to={`/shop/${product.category.slug}`}
            className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-ink-muted transition-colors hover:text-ink"
          >
            <ArrowLeft className="size-4" aria-hidden="true" />
            <span>{categoryName}</span>
            <span>·</span>
            <span>{t('product.backToShop')}</span>
          </Link>

          <span className="font-mono text-xs text-ink-muted">SKU Prefix: {product.skuPrefix}</span>
        </div>

        <div className="grid gap-8 lg:grid-cols-12 lg:items-start">
          {/* Left: Garment Stage & Print-Area Guide */}
          <div className="space-y-4 lg:col-span-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              {activePrintAreas.length > 0 ? (
                <div className="flex flex-wrap gap-2" role="tablist" aria-label="Garment surfaces">
                  {activePrintAreas.map((area) => {
                    const isSelected = activePrintArea?.id === area.id;
                    return (
                      <button
                        key={area.id}
                        type="button"
                        role="tab"
                        aria-selected={isSelected}
                        onClick={() => {
                          setSelectedSurfaceKey(area.surfaceKey);
                          setSelectedImageId(null);
                        }}
                        className={`inline-flex min-h-11 cursor-pointer items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-semibold transition-colors ${
                          isSelected
                            ? 'border-accent bg-accent text-white shadow-xs'
                            : 'border-border bg-surface text-ink hover:bg-surface-muted'
                        }`}
                      >
                        <Layers className="size-3.5" aria-hidden="true" />
                        {pickLocalizedText(locale, area.labelEn, area.labelBn)}
                      </button>
                    );
                  })}
                </div>
              ) : null}

              {activePrintArea ? (
                <Button
                  type="button"
                  size="sm"
                  variant="secondary"
                  onClick={() => setShowPrintGuide((prev) => !prev)}
                >
                  {showPrintGuide ? (
                    <>
                      <EyeOff className="size-4" aria-hidden="true" />
                      {t('product.printZoneToggleHide')}
                    </>
                  ) : (
                    <>
                      <Eye className="size-4" aria-hidden="true" />
                      {t('product.printZoneToggleShow')}
                    </>
                  )}
                </Button>
              ) : null}
            </div>

            <GarmentStagePreview
              image={activeImage}
              productName={title}
              activeColorHex={activeColorSwatch?.colorHex}
              activeColorName={activeColorDisplay}
              activePrintArea={activePrintArea}
              showPrintGuide={showPrintGuide}
            />

            {product.images.length > 1 ? (
              <div className="flex flex-wrap gap-3">
                {product.images.map((img) => {
                  const isCurrent = activeImage?.id === img.id;
                  return (
                    <button
                      key={img.id}
                      type="button"
                      onClick={() => {
                        setSelectedImageId(img.id);
                        if (img.viewType === 'back') {
                          setSelectedSurfaceKey('back');
                        } else if (img.viewType === 'front') {
                          setSelectedSurfaceKey('front');
                        }
                      }}
                      className={`min-h-11 overflow-hidden rounded-xl border p-1 transition-all ${
                        isCurrent
                          ? 'border-accent ring-2 ring-accent/30'
                          : 'border-border hover:border-ink-muted/50'
                      }`}
                    >
                      <img
                        src={img.url}
                        alt={pickLocalizedText(locale, img.altTextEn, img.altTextBn)}
                        width={64}
                        height={76}
                        className="h-16 w-14 rounded-lg object-contain"
                      />
                    </button>
                  );
                })}
              </div>
            ) : null}
          </div>

          {/* Right: Specs, Variant Selection & Print Area Metadata */}
          <div className="space-y-6 lg:col-span-6">
            <div className="space-y-3 border-b border-border pb-5">
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="neutral">{categoryName}</Badge>
                {product.isCustomizable ? (
                  <Badge variant="accent" className="gap-1">
                    <Sparkles className="size-3" aria-hidden="true" />
                    {t('common.customizable')}
                  </Badge>
                ) : null}
                {product.gsm ? (
                  <Badge variant="neutral">{t('product.gsmValue', { gsm: product.gsm })}</Badge>
                ) : null}
              </div>

              <h1 className="font-display text-3xl font-bold tracking-tight text-ink sm:text-4xl">
                {title}
              </h1>
              {subtitle ? <p className="text-base text-ink-muted">{subtitle}</p> : null}

              <div className="flex flex-wrap items-baseline justify-between gap-4 pt-2">
                <div>
                  <p className="text-xs font-semibold tracking-wider text-ink-muted uppercase">
                    {t('product.variantPrice')}
                  </p>
                  <p className="font-display text-3xl font-bold text-ink">{displayedPrice}</p>
                </div>

                {selectedVariant ? (
                  <div className="text-right">
                    <p className="font-mono text-xs text-ink-muted">
                      {t('product.skuLabel')}:{' '}
                      <strong className="text-ink">{selectedVariant.sku}</strong>
                    </p>
                    <p
                      className={`mt-0.5 text-sm font-semibold ${
                        selectedVariant.inStock ? 'text-success' : 'text-danger'
                      }`}
                    >
                      {selectedVariant.inStock
                        ? t('common.inStock', { count: selectedVariant.stockQuantity })
                        : t('common.outOfStock')}
                    </p>
                  </div>
                ) : null}
              </div>
            </div>

            {/* Colorway Selection */}
            {product.availableColors.length > 0 ? (
              <div className="space-y-2.5">
                <p className="text-xs font-semibold tracking-wider text-ink-muted uppercase">
                  {t('product.selectColor')}: <span className="text-ink">{activeColorDisplay}</span>
                </p>
                <div className="flex flex-wrap gap-2.5">
                  {product.availableColors.map((swatch) => {
                    const isSelected = swatch.colorNameEn === activeColorNameEn;
                    const colorLabel = pickLocalizedText(
                      locale,
                      swatch.colorNameEn,
                      swatch.colorNameBn
                    );
                    return (
                      <button
                        key={swatch.colorNameEn}
                        type="button"
                        aria-pressed={isSelected}
                        onClick={() => {
                          setSelectedColorNameEn(swatch.colorNameEn);
                          setQuantity(1);
                          setCartFeedback(null);
                        }}
                        className={`inline-flex min-h-11 cursor-pointer items-center gap-2 rounded-xl border px-3.5 py-2 text-sm font-medium transition-all ${
                          isSelected
                            ? 'border-accent bg-accent-soft text-accent-ink ring-1 ring-accent'
                            : 'border-border bg-surface text-ink hover:bg-surface-muted'
                        }`}
                      >
                        <span
                          className="inline-block size-4 rounded-full border border-border-dark/30"
                          style={{ backgroundColor: swatch.colorHex }}
                          aria-hidden="true"
                        />
                        <span>{colorLabel}</span>
                        {isSelected ? <Check className="size-3.5 text-accent" /> : null}
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : null}

            {/* Size Selection */}
            {variantsForColor.length > 0 ? (
              <div className="space-y-2.5">
                <p className="text-xs font-semibold tracking-wider text-ink-muted uppercase">
                  {t('product.selectSize')}:{' '}
                  <span className="font-mono text-ink">{selectedVariant?.sizeCode}</span>
                </p>
                <div className="flex flex-wrap gap-2">
                  {variantsForColor.map((variant) => {
                    const isSelected = selectedVariant?.id === variant.id;
                    return (
                      <button
                        key={variant.id}
                        type="button"
                        aria-pressed={isSelected}
                        onClick={() => {
                          setSelectedSizeCode(variant.sizeCode);
                          setQuantity(1);
                          setCartFeedback(null);
                        }}
                        className={`inline-flex min-h-11 min-w-14 cursor-pointer flex-col items-center justify-center rounded-xl border px-3.5 py-1.5 font-mono text-sm font-semibold transition-all ${
                          isSelected
                            ? 'border-accent bg-accent text-white shadow-xs'
                            : variant.inStock
                              ? 'border-border bg-surface text-ink hover:bg-surface-muted'
                              : 'border-border bg-surface-muted/70 text-ink-muted line-through'
                        }`}
                      >
                        <span>{variant.sizeCode}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : null}

            {/* Quantity Stepper & Server-Validated Add to Cart */}
            <Card className="space-y-3 p-4">
              {selectedVariant ? (
                <>
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="space-y-1">
                      <span className="block text-[11px] font-semibold tracking-wider text-ink-muted uppercase">
                        {t('product.quantityLabel')}
                      </span>
                      <div className="inline-flex items-center rounded-xl border border-border bg-surface">
                        <button
                          type="button"
                          aria-label={t('cart.decreaseQty')}
                          disabled={quantity <= 1 || isCartMutating || !selectedVariant.inStock}
                          onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                          className="inline-flex min-h-11 min-w-11 cursor-pointer items-center justify-center rounded-l-xl text-ink hover:bg-surface-muted disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          <Minus className="size-4" aria-hidden="true" />
                        </button>
                        <span
                          data-testid="pdp-quantity-value"
                          className="min-w-10 text-center font-mono text-sm font-bold text-ink"
                        >
                          {quantity}
                        </span>
                        <button
                          type="button"
                          aria-label={t('cart.increaseQty')}
                          disabled={
                            quantity >= Math.min(50, selectedVariant.stockQuantity) ||
                            isCartMutating ||
                            !selectedVariant.inStock
                          }
                          onClick={() =>
                            setQuantity((q) =>
                              Math.min(Math.min(50, selectedVariant.stockQuantity), q + 1)
                            )
                          }
                          className="inline-flex min-h-11 min-w-11 cursor-pointer items-center justify-center rounded-r-xl text-ink hover:bg-surface-muted disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          <Plus className="size-4" aria-hidden="true" />
                        </button>
                      </div>
                    </div>

                    <div className="min-w-44 flex-1 self-end">
                      <Button
                        type="button"
                        variant="primary"
                        size="lg"
                        className="w-full"
                        data-testid="pdp-add-to-cart"
                        disabled={!selectedVariant.inStock || isCartMutating}
                        onClick={async () => {
                          setCartFeedback(null);
                          try {
                            await addItem(selectedVariant.id, quantity);
                            setCartFeedback({
                              type: 'success',
                              message: t('product.addedToCartMsg', { qty: quantity }),
                            });
                          } catch (err) {
                            setCartFeedback({
                              type: 'error',
                              message:
                                err instanceof ApiClientError
                                  ? err.message
                                  : t('cart.errorGeneric'),
                            });
                          }
                        }}
                      >
                        <ShoppingBag className="size-4" aria-hidden="true" />
                        <span>
                          {!selectedVariant.inStock
                            ? t('product.variantUnavailableBtn')
                            : isCartMutating
                              ? t('product.addingToCart')
                              : t('product.addToCartBtn')}
                        </span>
                      </Button>
                    </div>
                  </div>

                  {product.isCustomizable && activePrintAreas.length > 0 ? (
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                      <Button
                        asChild
                        variant="electric"
                        size="lg"
                        className="w-full"
                        data-testid="pdp-open-studio"
                      >
                        <Link to={`/studio?product=${product.slug}&variant=${selectedVariant.id}`}>
                          <Sparkles className="size-4" aria-hidden="true" />
                          <span>{t('product.customizeStudioBtn')}</span>
                        </Link>
                      </Button>
                      <Button
                        asChild
                        variant="outline"
                        size="lg"
                        className="w-full"
                        data-testid="pdp-open-studio-3d"
                      >
                        <Link
                          to={`/studio?product=${product.slug}&variant=${selectedVariant.id}&mode=3d`}
                        >
                          <Sparkles className="size-4" aria-hidden="true" />
                          <span>{t('product.previewIn3dBtn')}</span>
                        </Link>
                      </Button>
                    </div>
                  ) : null}

                  {cartFeedback ? (
                    <div
                      role={cartFeedback.type === 'error' ? 'alert' : 'status'}
                      className={`rounded-xl border px-3.5 py-2 text-xs font-medium ${
                        cartFeedback.type === 'error'
                          ? 'border-danger/30 bg-danger-soft text-danger'
                          : 'border-success/30 bg-success-soft text-success'
                      }`}
                    >
                      {cartFeedback.message}
                    </div>
                  ) : null}
                </>
              ) : (
                <p className="text-xs text-ink-muted">{t('product.selectVariantNotice')}</p>
              )}
            </Card>

            {/* Configurable Print Zones Spec Card */}
            {activePrintAreas.length > 0 ? (
              <Card className="space-y-3 p-5">
                <div className="flex items-center gap-2">
                  <Ruler className="size-4 text-accent-royal" aria-hidden="true" />
                  <h2 className="font-display text-base font-semibold text-ink">
                    {t('product.printZoneHeading')}
                  </h2>
                </div>

                <div className="space-y-2.5">
                  {activePrintAreas.map((area) => {
                    const isSelected = activePrintArea?.id === area.id;
                    return (
                      <button
                        key={area.id}
                        type="button"
                        onClick={() => {
                          setSelectedSurfaceKey(area.surfaceKey);
                          setSelectedImageId(null);
                          setShowPrintGuide(true);
                        }}
                        className={`flex w-full cursor-pointer flex-col gap-1.5 rounded-xl border p-3.5 text-left transition-colors ${
                          isSelected
                            ? 'border-accent bg-accent-soft/50'
                            : 'border-border bg-surface-muted/40 hover:bg-surface-muted'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-semibold text-ink">
                            {pickLocalizedText(locale, area.labelEn, area.labelBn)}
                          </span>
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="rounded bg-surface px-2 py-0.5 font-mono text-[11px] text-ink-muted">
                              {area.surfaceKey}
                            </span>
                            {Number(area.surchargeAmount) > 0 ? (
                              <Badge variant="neutral">
                                {t('product.printZoneSurcharge', { amount: area.surchargeAmount })}
                              </Badge>
                            ) : null}
                          </div>
                        </div>

                        <p className="font-mono text-xs text-ink-muted">
                          {t('product.printZoneSpecs', {
                            width: area.physicalWidthMm,
                            height: area.physicalHeightMm,
                            dpi: area.targetDpi,
                            inset: area.safeInsetMm,
                          })}
                        </p>

                        <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-ink-muted">
                          <span className="font-mono">
                            2D [{area.mockupBounds.x.toFixed(2)}, {area.mockupBounds.y.toFixed(2)},{' '}
                            {area.mockupBounds.width.toFixed(2)}×
                            {area.mockupBounds.height.toFixed(2)}]
                          </span>
                          {area.uvRegion ? (
                            <span className="font-mono">
                              · 3D UV: {area.uvRegion.islandKey} ({area.uvRegion.meshTarget})
                            </span>
                          ) : null}
                        </div>
                      </button>
                    );
                  })}
                </div>

                <p className="text-xs leading-relaxed text-ink-muted">
                  {t('product.studioReadyNotice')}
                </p>
              </Card>
            ) : null}

            {/* Fabric & Description */}
            <Card className="space-y-3 p-5">
              <h2 className="font-display text-base font-semibold text-ink">
                {t('product.fabricSpecs')}
              </h2>
              <p className="text-sm leading-relaxed text-ink">{description}</p>
              {fabricSpec ? (
                <p className="rounded-lg bg-surface-muted px-3 py-2 text-xs text-ink-muted">
                  {fabricSpec}
                </p>
              ) : null}
            </Card>

            {/* Studio / Delivery Next Steps Callout */}
            <Card className="space-y-3 border-border-dark bg-dark-tech p-5 text-ink-inverse">
              <div className="flex items-center gap-2 text-accent-cyan-bright">
                <Sparkles className="size-4" aria-hidden="true" />
                <h2 className="font-display text-base font-semibold text-white">
                  {t('product.phaseNextTitle')}
                </h2>
              </div>
              <p className="text-xs leading-relaxed text-ink-inverse-muted">
                {t('product.phaseNextDesc')}
              </p>
              <div className="flex flex-wrap gap-2.5 pt-1">
                <Button asChild size="sm" variant="secondary">
                  <Link to="/account">
                    <MapPin className="size-3.5" aria-hidden="true" />
                    {t('product.openAccountAddresses')}
                  </Link>
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </Container>
    </Section>
  );
}
