import { zodResolver } from '@hookform/resolvers/zod';
import { type UpdateProfileInput, updateProfileSchema } from '@your-choice/validation';
import { Badge, Button, Card, Container, FormField, Input, Section } from '@your-choice/ui';
import {
  CheckCircle2,
  KeyRound,
  LogOut,
  Package,
  ShieldCheck,
  Sparkles,
  UserCheck,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate } from 'react-router-dom';
import { AddressBookPanel } from '@/features/addresses/components/AddressBookPanel';
import { useAuth } from '@/features/auth/auth-context';
import { SavedDesignsPanel } from '@/features/design-studio/components/SavedDesignsPanel';
import { ApiClientError } from '@/services/api-client';

export function AccountPage() {
  const { user, session, logout, isLoggingOut, updateProfile, hasRole } = useAuth();
  const navigate = useNavigate();
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<UpdateProfileInput>({
    resolver: zodResolver(updateProfileSchema),
    defaultValues: {
      fullName: user?.fullName ?? '',
      phone: user?.phone ?? '',
      preferredLocale: user?.preferredLocale ?? 'en',
    },
  });

  useEffect(() => {
    if (user) {
      reset({
        fullName: user.fullName,
        phone: user.phone ?? '',
        preferredLocale: user.preferredLocale,
      });
    }
  }, [user, reset]);

  if (!user) {
    return null;
  }

  const handleSignOut = async () => {
    await logout();
    navigate('/login', { replace: true });
  };

  const onProfileSubmit = async (values: UpdateProfileInput) => {
    setStatusMessage(null);
    setErrorMessage(null);
    try {
      await updateProfile({
        fullName: values.fullName,
        phone: values.phone && values.phone.trim().length > 0 ? values.phone.trim() : null,
        preferredLocale: values.preferredLocale,
      });
      setStatusMessage('Profile details updated.');
    } catch (error: unknown) {
      if (error instanceof ApiClientError) {
        setErrorMessage(error.message);
        return;
      }
      setErrorMessage('Could not update profile right now.');
    }
  };

  const canAccessCreator = hasRole(['creator', 'admin', 'super_admin']);
  const canAccessAdmin = hasRole(['admin', 'super_admin']);

  return (
    <Section spacing="md">
      <Container className="space-y-8">
        <div className="flex flex-col gap-4 border-b border-border pb-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="accent">Authenticated Account</Badge>
              <Badge variant={user.status === 'active' ? 'success' : 'warning'}>
                {user.status.toUpperCase()}
              </Badge>
            </div>
            <h1 className="font-display text-2xl font-bold tracking-tight text-ink sm:text-3xl">
              {user.fullName}
            </h1>
            <p className="text-sm text-ink-muted">
              {user.email} · Public ID <code className="font-mono text-xs">{user.id}</code>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <Button asChild variant="secondary">
              <Link to="/orders">
                <Package className="size-4" aria-hidden="true" />
                My Orders
              </Link>
            </Button>
            {canAccessCreator ? (
              <Button asChild variant="secondary">
                <Link to="/creator">
                  <Sparkles className="size-4" aria-hidden="true" />
                  Creator Hub
                </Link>
              </Button>
            ) : null}
            {canAccessAdmin ? (
              <Button asChild variant="secondary">
                <Link to="/admin">
                  <ShieldCheck className="size-4" aria-hidden="true" />
                  Admin Console
                </Link>
              </Button>
            ) : null}
            <Button variant="outline" onClick={handleSignOut} disabled={isLoggingOut}>
              <LogOut className="size-4" aria-hidden="true" />
              {isLoggingOut ? 'Signing out...' : 'Sign Out'}
            </Button>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-12">
          <Card className="p-6 lg:col-span-7">
            <div className="flex items-center gap-2.5 border-b border-border pb-4">
              <UserCheck className="size-5 text-accent-royal" aria-hidden="true" />
              <h2 className="font-display text-lg font-semibold text-ink">Profile Preferences</h2>
            </div>

            {statusMessage ? (
              <div
                role="status"
                className="mt-4 flex items-center gap-2 rounded-xl border border-success/30 bg-success-soft px-4 py-2.5 text-sm text-success"
              >
                <CheckCircle2 className="size-4 shrink-0" aria-hidden="true" />
                <span>{statusMessage}</span>
              </div>
            ) : null}

            {errorMessage ? (
              <div
                role="alert"
                className="mt-4 rounded-xl border border-danger/30 bg-danger-soft px-4 py-2.5 text-sm text-danger"
              >
                {errorMessage}
              </div>
            ) : null}

            <form onSubmit={handleSubmit(onProfileSubmit)} noValidate className="mt-5 space-y-4">
              <FormField
                id="account-full-name"
                label="Full name"
                required
                error={errors.fullName?.message}
              >
                <Input
                  id="account-full-name"
                  invalid={Boolean(errors.fullName)}
                  {...register('fullName')}
                />
              </FormField>

              <FormField id="account-phone" label="Phone number" error={errors.phone?.message}>
                <Input
                  id="account-phone"
                  type="tel"
                  placeholder="+8801712345678"
                  invalid={Boolean(errors.phone)}
                  {...register('phone')}
                />
              </FormField>

              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Saving changes...' : 'Save Profile'}
              </Button>
            </form>
          </Card>

          <Card className="space-y-5 p-6 lg:col-span-5">
            <div className="flex items-center gap-2.5 border-b border-border pb-4">
              <KeyRound className="size-5 text-accent-royal" aria-hidden="true" />
              <h2 className="font-display text-lg font-semibold text-ink">Roles &amp; Session</h2>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-semibold tracking-wider text-ink-muted uppercase">
                Assigned Roles
              </p>
              <div className="flex flex-wrap gap-2">
                {user.roles.map((role) => (
                  <Badge key={role} variant="accent">
                    {role}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-semibold tracking-wider text-ink-muted uppercase">
                Effective Permissions ({user.permissions.length})
              </p>
              <div className="flex flex-wrap gap-1.5">
                {user.permissions.map((perm) => (
                  <Badge key={perm} variant="neutral" className="font-mono text-[11px]">
                    {perm}
                  </Badge>
                ))}
              </div>
            </div>

            {session ? (
              <div className="space-y-1 border-t border-border pt-4 text-xs text-ink-muted">
                <p>
                  Session ID: <code className="font-mono">{session.id}</code>
                </p>
                <p>Expires: {new Date(session.expiresAt).toLocaleString()}</p>
              </div>
            ) : null}
          </Card>
        </div>

        <Card className="space-y-4 p-6">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-4">
            <div className="flex items-center gap-2.5">
              <Sparkles className="size-5 text-accent-royal" aria-hidden="true" />
              <h2 className="font-display text-lg font-semibold text-ink">
                Saved 2D Studio Designs
              </h2>
            </div>
            <Button asChild size="sm" variant="primary">
              <Link to="/studio">Open 2D Studio</Link>
            </Button>
          </div>
          <SavedDesignsPanel />
        </Card>

        <AddressBookPanel />
      </Container>
    </Section>
  );
}
