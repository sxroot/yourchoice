import { useQuery } from '@tanstack/react-query';
import {
  Badge,
  Card,
  Container,
  LoadingState,
  Section,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@your-choice/ui';
import { ShieldCheck } from 'lucide-react';
import { AdminCatalogPanel } from '@/features/admin/components/AdminCatalogPanel';
import { AdminOrdersPanel } from '@/features/admin/components/AdminOrdersPanel';
import { fetchAdminOverview } from '@/features/auth/auth.api';
import { useAppLocale } from '@/i18n';

export function AdminOverviewPage() {
  const { t } = useAppLocale();
  const adminQuery = useQuery({
    queryKey: ['admin', 'overview'],
    queryFn: ({ signal }) => fetchAdminOverview(signal),
    retry: false,
  });

  return (
    <Section spacing="md">
      <Container className="space-y-6">
        <div className="space-y-2">
          <Badge variant="accent">Admin RBAC Console</Badge>
          <h1 className="font-display text-2xl font-bold text-ink sm:text-3xl">
            Identity &amp; Operations Overview
          </h1>
          <p className="text-sm text-ink-muted">
            Role-protected administrative boundary backed by `requireRoles(&apos;admin&apos;,
            &apos;super_admin&apos;)` plus RBAC permissions (`users:read`, `catalog:read`,
            `catalog:write`).
          </p>
        </div>

        <Tabs defaultValue="identity" className="w-full">
          <TabsList>
            <TabsTrigger value="identity">{t('admin.tabIdentity')}</TabsTrigger>
            <TabsTrigger value="catalog">{t('admin.tabCatalog')}</TabsTrigger>
            <TabsTrigger value="orders">{t('admin.tabOrders')}</TabsTrigger>
          </TabsList>

          <TabsContent value="identity">
            {adminQuery.isLoading ? (
              <LoadingState label="Loading admin overview..." />
            ) : adminQuery.error ? (
              <Card className="border-danger/30 bg-danger-soft p-6 text-sm text-danger">
                {adminQuery.error instanceof Error
                  ? adminQuery.error.message
                  : 'Unable to load admin overview.'}
              </Card>
            ) : (
              <Card className="space-y-4 p-6">
                <div className="flex items-center gap-3">
                  <div className="inline-flex size-10 items-center justify-center rounded-xl bg-accent-soft text-accent-royal">
                    <ShieldCheck className="size-5" aria-hidden="true" />
                  </div>
                  <div>
                    <h2 className="font-display text-lg font-semibold text-ink">
                      Registered Accounts ({adminQuery.data?.userCountSampled ?? 0})
                    </h2>
                    <p className="text-xs text-ink-muted">
                      Actor: <code className="font-mono">{adminQuery.data?.actorId}</code>
                    </p>
                  </div>
                </div>

                <div className="divide-y divide-border rounded-xl border border-border">
                  {adminQuery.data?.users.map((entry) => (
                    <div
                      key={entry.id}
                      className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div>
                        <p className="text-sm font-medium text-ink">{entry.fullName}</p>
                        <p className="text-xs text-ink-muted">{entry.email}</p>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {entry.roles.map((role) => (
                          <Badge key={role} variant="accent">
                            {role}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="catalog">
            <AdminCatalogPanel />
          </TabsContent>

          <TabsContent value="orders">
            <AdminOrdersPanel />
          </TabsContent>
        </Tabs>
      </Container>
    </Section>
  );
}
