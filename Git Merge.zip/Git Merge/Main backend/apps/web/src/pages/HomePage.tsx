import type { ProductCategoryDTO, ProductSummaryDTO } from '@your-choice/shared-types';
import { Button, Container } from '@your-choice/ui';
import { useQuery } from '@tanstack/react-query';
import { m, useReducedMotion, useScroll, useTransform, type MotionValue } from 'motion/react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Circle,
  RotateCw,
  Sparkles,
} from 'lucide-react';
import { useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ProductCard } from '@/features/catalog/components/ProductCard';
import { fetchPublicCategories, fetchPublicProducts } from '@/features/catalog/catalog.api';
import { useHealthStatus } from '@/hooks/useHealthStatus';
import { Reveal } from '@/components/motion';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';

const FALLBACK_CATEGORIES = [
  {
    slug: 't-shirts',
    nameEn: 'T-shirts',
    nameBn: 'টি-শার্ট',
    image: '/catalog/tee-front.svg',
  },
  {
    slug: 'polo-shirts',
    nameEn: 'Polo shirts',
    nameBn: 'পলো শার্ট',
    image: '/catalog/polo-front.svg',
  },
] as const;

type RailItem = {
  key: string;
  title: string;
  subtitle: string;
  image: string | null;
  href: string;
  price?: string;
  product?: ProductSummaryDTO;
};

type FallbackCategory = {
  slug: string;
  nameEn: string;
  nameBn: string;
  image: string;
};

function categoryImage(category: Pick<ProductCategoryDTO, 'slug' | 'nameEn'>) {
  const isPolo = category.slug.toLowerCase().includes('polo') || /polo/i.test(category.nameEn);
  return isPolo ? '/catalog/polo-front.svg' : '/catalog/tee-front.svg';
}

function OrbitCard({
  item,
  index,
  count,
  counterRotation,
  reducedMotion,
  locale,
}: {
  item: ProductSummaryDTO | FallbackCategory;
  index: number;
  count: number;
  counterRotation: MotionValue<number>;
  reducedMotion: boolean;
  locale: 'en' | 'bn';
}) {
  const isProduct = 'primaryImage' in item;
  const label = isProduct
    ? pickLocalizedText(locale, item.nameEn, item.nameBn)
    : locale === 'bn'
      ? item.nameBn
      : item.nameEn;
  const image = isProduct
    ? item.primaryImage?.url
    : item.image;
  const href = isProduct ? `/product/${item.slug}` : `/shop/${item.slug}`;
  const angle = (index / count) * Math.PI * 2 - Math.PI / 2 + Math.PI / 4;
  const left = 50 + Math.cos(angle) * 36;
  const top = 50 + Math.sin(angle) * 36;

  return (
    <div className="home-orbit__card" style={{ left: `${left}%`, top: `${top}%` }}>
      <m.div className="home-orbit__card-face" style={{ rotate: reducedMotion ? 0 : counterRotation }}>
        <Link to={href} aria-label={`${label} — ${isProduct ? 'view product' : 'browse category'}`}>
          <span className="home-orbit__card-media">
            {image ? (
              <img src={image} alt="" loading="lazy" decoding="async" width="440" height="520" />
            ) : (
              <span>{label}</span>
            )}
            <span className="home-orbit__card-glyph"><ArrowUpRight aria-hidden="true" /></span>
          </span>
          <span className="home-orbit__card-label">
            <span>{String(index + 1).padStart(2, '0')}</span>
            <strong>{label}</strong>
          </span>
        </Link>
      </m.div>
    </div>
  );
}

function OrbitStory({ products, locale }: { products: ProductSummaryDTO[]; locale: 'en' | 'bn' }) {
  const sectionRef = useRef<HTMLElement>(null);
  const shouldReduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start start', 'end end'],
  });
  const rotation = useTransform(scrollYProgress, [0, 1], [0, 220]);
  const counterRotation = useTransform(scrollYProgress, [0, 1], [0, -220]);
  const haloScale = useTransform(scrollYProgress, [0, 0.5, 1], [0.84, 1, 0.91]);
  const haloOpacity = useTransform(scrollYProgress, [0, 0.08, 0.9, 1], [0.2, 0.78, 0.7, 0.18]);
  const { t } = useAppLocale();
  const orbitalProducts = products.slice(0, 8);
  const fallbackItems: FallbackCategory[] = [
    FALLBACK_CATEGORIES[0],
    FALLBACK_CATEGORIES[1],
    { ...FALLBACK_CATEGORIES[0], image: '/catalog/tee-back.svg' },
    { ...FALLBACK_CATEGORIES[1], image: '/catalog/polo-back.svg' },
  ];
  const items: Array<ProductSummaryDTO | FallbackCategory> = orbitalProducts.length
    ? orbitalProducts
    : fallbackItems;

  return (
    <section
      ref={sectionRef}
      className={`home-orbit${shouldReduceMotion ? ' home-orbit--reduced' : ''}`}
      aria-labelledby="orbit-title"
      data-testid="home-orbit"
    >
      <div className="home-orbit__sticky">
        <div className="home-orbit__grain" aria-hidden="true" />
        <m.div
          className="home-orbit__halo"
          style={{ scale: shouldReduceMotion ? 1 : haloScale, opacity: shouldReduceMotion ? 0.55 : haloOpacity }}
          aria-hidden="true"
        />
        <div className="home-orbit__header">
          <span className="home-eyebrow home-eyebrow--light"><span className="home-eyebrow__dot" />{t('home.orbitEyebrow')}</span>
          <h2 id="orbit-title">{t('home.orbitTitle')}</h2>
          <p>{t('home.orbitDesc')}</p>
        </div>
        <m.div
          className="home-orbit__ring"
          style={{ rotate: shouldReduceMotion ? 0 : rotation }}
          aria-label={t('home.orbitAria')}
        >
          {items.map((item, index) => (
            <OrbitCard
              key={`${'id' in item ? item.id : item.slug}-${index}`}
              item={item}
              index={index}
              count={items.length}
              counterRotation={counterRotation}
              reducedMotion={Boolean(shouldReduceMotion)}
              locale={locale}
            />
          ))}
        </m.div>
        <div className="home-orbit__center">
          <img src="/brand/your-choice-transparent-monogram.png" alt="YOUR CHOICE" width="74" height="74" />
          <span>{t('home.orbitCenter')}</span>
          <strong>{t('home.orbitCenterAccent')}</strong>
        </div>
        <div className="home-orbit__foot">
          <span>YC / 01</span>
          <span><ArrowDown aria-hidden="true" /> {t('home.orbitScroll')}</span>
          <span>APPAREL — DHAKA</span>
        </div>
      </div>
    </section>
  );
}

function ShutterStrip({ index, progress, reduced }: { index: number; progress: MotionValue<number>; reduced: boolean }) {
  const delay = index * 0.025;
  const exit = index % 2 === 0 ? '108vw' : '-108vw';
  const x = useTransform(progress, [0.04 + delay, 0.48 + delay], ['0vw', exit]);
  return <m.span className="home-shutter__strip" style={{ x: reduced ? (index % 2 ? '-108vw' : '108vw') : x }} />;
}

function ShutterStory() {
  const sectionRef = useRef<HTMLElement>(null);
  const shouldReduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start start', 'end end'],
  });
  const { t } = useAppLocale();

  return (
    <section ref={sectionRef} className={`home-shutter${shouldReduceMotion ? ' home-shutter--reduced' : ''}`} aria-labelledby="shutter-title" data-testid="home-shutter">
      <div className="home-shutter__sticky">
        <img
          className="home-shutter__image"
          src="/campaign/your-choice-hero.jpg"
          alt="YOUR CHOICE campaign portrait in layered black outerwear"
          loading="lazy"
          decoding="async"
          width="1680"
          height="952"
        />
        <div className="home-shutter__shade" aria-hidden="true" />
        <div className="home-shutter__frame" aria-hidden="true">
          <span>SUBJECT / YC.001</span><span>NEW FORM, YOUR FORM</span>
        </div>
        <div className="home-shutter__copy">
          <span className="home-eyebrow home-eyebrow--light"><span className="home-eyebrow__dot" />{t('home.shutterEyebrow')}</span>
          <h2 id="shutter-title">{t('home.shutterTitle')}<br /><em>{t('home.shutterAccent')}</em></h2>
          <Link to="/shop" className="home-shutter__link">{t('home.shutterLink')} <ArrowUpRight aria-hidden="true" /></Link>
        </div>
        <div className="home-shutter__strips" aria-hidden="true">{Array.from({ length: 11 }, (_, index) => <ShutterStrip key={index} index={index} progress={scrollYProgress} reduced={Boolean(shouldReduceMotion)} />)}</div>
        <div className="home-shutter__progress" aria-hidden="true"><span>01</span><span className="home-shutter__progress-line" /><span>03</span></div>
      </div>
    </section>
  );
}

export function HomePage() {
  const { locale, t } = useAppLocale();
  const shouldReduceMotion = useReducedMotion();
  const [selectedRailIndex, setSelectedRailIndex] = useState(0);
  const productRailRef = useRef<HTMLDivElement>(null);
  const garmentRailRef = useRef<HTMLDivElement>(null);
  const health = useHealthStatus();

  const categoriesQuery = useQuery({
    queryKey: ['catalog', 'categories'],
    queryFn: ({ signal }) => fetchPublicCategories(signal),
    retry: false,
  });
  const productsQuery = useQuery({
    queryKey: ['catalog', 'products', { sort: 'featured', page: 1, pageSize: 16 }],
    queryFn: ({ signal }) => fetchPublicProducts({ sort: 'featured', page: 1, pageSize: 16 }, signal),
    retry: false,
  });

  const products = useMemo(() => productsQuery.data?.products ?? [], [productsQuery.data]);
  const categories = useMemo(() => {
    const active = (categoriesQuery.data ?? []).filter((category) => category.isActive);
    return active.length ? active : FALLBACK_CATEGORIES.map((category, index) => ({
      id: category.slug,
      slug: category.slug,
      parentId: null,
      nameEn: category.nameEn,
      nameBn: category.nameBn,
      descriptionEn: null,
      descriptionBn: null,
      sortOrder: index,
      isActive: true,
      productCount: 0,
    }));
  }, [categoriesQuery.data]);
  const railItems = useMemo<RailItem[]>(() => {
    if (products.length) {
      return products.slice(0, 8).map((product) => ({
        key: product.id,
        title: pickLocalizedText(locale, product.nameEn, product.nameBn),
        subtitle: pickLocalizedText(locale, product.subtitleEn, product.subtitleBn) || t('home.railCustomizable'),
        image: product.primaryImage?.url ?? null,
        href: `/product/${product.slug}`,
        price: product.minPrice === product.maxPrice
          ? formatBdtPrice(product.minPrice, product.currencyCode)
          : `${formatBdtPrice(product.minPrice, product.currencyCode)} – ${formatBdtPrice(product.maxPrice, product.currencyCode)}`,
        product,
      }));
    }
    return categories.map((category) => ({
      key: category.id,
      title: pickLocalizedText(locale, category.nameEn, category.nameBn),
      subtitle: t('home.railStartHere'),
      image: categoryImage(category),
      href: `/shop/${category.slug}`,
    }));
  }, [categories, locale, products, t]);
  const activeRailItem = railItems[Math.min(selectedRailIndex, railItems.length - 1)];

  const moveRail = (direction: -1 | 1) => {
    if (!railItems.length) return;
    setSelectedRailIndex((current) => (current + direction + railItems.length) % railItems.length);
    garmentRailRef.current?.scrollBy({ left: direction * Math.max(220, garmentRailRef.current.clientWidth * 0.65), behavior: shouldReduceMotion ? 'auto' : 'smooth' });
  };

  const moveProductRail = (direction: -1 | 1) => {
    productRailRef.current?.scrollBy({ left: direction * Math.max(260, productRailRef.current.clientWidth * 0.72), behavior: shouldReduceMotion ? 'auto' : 'smooth' });
  };

  return (
    <div className="home-page home-page--cinematic">
      <section className="home-hero home-hero--cinematic" aria-labelledby="home-hero-title" data-testid="home-hero">
        <img
          className="home-hero__image home-hero__image--cinematic"
          src="/campaign/your-choice-hero.jpg"
          alt="A model wearing a YOUR CHOICE black jacket over a white tee"
          width="1680"
          height="952"
          fetchPriority="high"
          decoding="async"
        />
        <div className="home-hero__shade home-hero__shade--cinematic" aria-hidden="true" />
        <div className="home-hero__grid" aria-hidden="true" />
        <Container className="home-hero__inner home-hero__inner--cinematic">
          <div className="home-hero__meta">
            <span className="home-eyebrow home-eyebrow--light"><span className="home-eyebrow__dot" />{t('home.heroBadge')}</span>
            <span className="home-hero__edition">YC / COLLECTION 01&nbsp;&nbsp; — &nbsp;&nbsp;DHAKA</span>
          </div>
          <div className="home-hero__copy home-hero__copy--cinematic">
            <Reveal distance={24}>
              <h1 id="home-hero-title" className="home-hero__title home-hero__title--cinematic">
                {t('home.heroTitleStart')}<br /><span>{t('home.heroTitleAccent')}</span>
              </h1>
            </Reveal>
            <p className="home-hero__tagline">{t('common.tagline')}</p>
            <p className="home-hero__body">{t('home.heroBody')}</p>
            <div className="home-hero__actions">
              <Button asChild variant="primary" className="home-hero__primary">
                <Link to="/shop">{t('home.browseShop')} <ArrowUpRight aria-hidden="true" className="size-4" /></Link>
              </Button>
              <Link to="/studio" className="home-hero__secondary"><Sparkles aria-hidden="true" className="size-4" />{t('home.exploreDesignSystem')}</Link>
            </div>
          </div>
          <div className="home-hero__brand-card" aria-label="YOUR CHOICE — Design it. Wear it. Earn from it.">
            <img src="/brand/your-choice-transparent-monogram.png" alt="" width="44" height="44" />
            <span><small>YOUR CHOICE / STUDIO</small><strong>{t('home.heroStampValue')}</strong></span>
            <ArrowUpRight aria-hidden="true" />
          </div>
          <a href="#home-orbit" className="home-hero__scroll"><span className="home-hero__scroll-icon"><ArrowDown aria-hidden="true" /></span>{t('home.scrollPrompt')}</a>
          <span className="home-hero__index">01 / 04</span>
          <div className="home-hero__side-note" aria-hidden="true"><span>MAKE IT</span><span>MEAN MORE</span></div>
        </Container>
      </section>

      <div id="home-orbit"><OrbitStory products={products} locale={locale} /></div>

      <ShutterStory />

      <section className="home-collection home-section-shell home-collection--editorial" id="collection" aria-labelledby="collection-title">
        <Container>
          <div className="home-section-heading home-section-heading--collection">
            <Reveal className="home-section-heading__copy" distance={18}>
              <p className="home-eyebrow home-eyebrow--blue"><span className="home-eyebrow__dot" />{t('home.categoriesEyebrow')}</p>
              <h2 id="collection-title" className="home-display-heading">{t('home.featuredTitle')}</h2>
              <p className="home-section-intro">{t('home.featuredDesc')}</p>
            </Reveal>
            <div className="home-rail-controls">
              <span className="home-rail-count"><b>{String(products.length || 2).padStart(2, '0')}</b> {t('home.railPieces')}</span>
              <div className="home-rail-buttons">
                <button type="button" className="home-rail-button" onClick={() => moveProductRail(-1)} aria-label={t('home.previousProducts')}><ArrowLeft aria-hidden="true" /></button>
                <button type="button" className="home-rail-button" onClick={() => moveProductRail(1)} aria-label={t('home.nextProducts')}><ArrowRight aria-hidden="true" /></button>
              </div>
            </div>
          </div>
          {productsQuery.isLoading ? (
            <div className="home-products-loading" role="status">{t('common.loading')}</div>
          ) : products.length ? (
            <div className="home-product-rail" ref={productRailRef} aria-label={t('home.featuredTitle')}>
              {products.slice(0, 8).map((product, index) => (
                <Reveal key={product.id} className="home-product-rail__item" delay={Math.min(index * 0.06, 0.24)} distance={16}>
                  <ProductCard product={product} presentation="editorial" />
                </Reveal>
              ))}
            </div>
          ) : (
            <div className="home-editorial-empty">
              <span>01 — 02</span>
              <p>{productsQuery.isError ? t('home.collectionError') : t('home.emptyCatalogue')}</p>
              <Link to="/shop">{t('home.viewAllCatalogue')} <ArrowUpRight aria-hidden="true" /></Link>
            </div>
          )}
          <div className="home-collection__footer"><span>{t('home.priceNote')}</span><span className="home-collection__rule" /><Link to="/shop">{t('home.viewAllCatalogue')} <ArrowUpRight aria-hidden="true" /></Link></div>
        </Container>
      </section>

      <section className="home-rail-story" aria-labelledby="rail-title" data-testid="home-garment-rail">
        <Container className="home-rail-story__container">
          <div className="home-rail-story__head">
            <div>
              <p className="home-eyebrow home-eyebrow--blue"><span className="home-eyebrow__dot" />{t('home.railEyebrow')}</p>
              <h2 className="home-display-heading" id="rail-title">{t('home.railTitle')}</h2>
            </div>
            <p className="home-section-intro">{t('home.railDesc')}</p>
          </div>
          <div className="home-rail-stage">
            <span className="home-rail-stage__serial">STUDIO OBJECT / {String(Math.min(selectedRailIndex + 1, railItems.length)).padStart(2, '0')}</span>
            <div className="home-rail-stage__spotlight" aria-live="polite">
              {activeRailItem?.image ? (
                <Link key={activeRailItem.key} to={activeRailItem.href} aria-label={`${activeRailItem.title} — ${t('home.railSelectLabel')}`} className="home-rail-stage__product-link">
                  <img src={activeRailItem.image} alt={activeRailItem.title} width="800" height="960" loading="lazy" decoding="async" />
                </Link>
              ) : <span className="home-rail-stage__empty">{activeRailItem?.title ?? t('home.emptyCatalogue')}</span>}
              <div className="home-rail-stage__spec"><span>{activeRailItem?.subtitle}</span><strong>{activeRailItem?.title}</strong>{activeRailItem?.price ? <small>{activeRailItem.price}</small> : null}</div>
            </div>
            <div className="home-rail-stage__actions">
              <Link to={activeRailItem?.href ?? '/shop'} aria-label={t('home.railSelectLabel')} className="home-rail-stage__view">{t('home.railSelectLabel')} <ArrowUpRight aria-hidden="true" /></Link>
              <div className="home-rail-buttons">
                <button type="button" className="home-rail-button" onClick={() => moveRail(-1)} aria-label={t('home.previousProducts')}><ArrowLeft aria-hidden="true" /></button>
                <button type="button" className="home-rail-button" onClick={() => moveRail(1)} aria-label={t('home.nextProducts')}><ArrowRight aria-hidden="true" /></button>
              </div>
            </div>
            <div className="home-rail-track" ref={garmentRailRef} aria-label={t('home.railTitle')}>
              <span className="home-rail-track__bar" aria-hidden="true" />
              {railItems.map((item, index) => (
                <button
                  type="button"
                  key={item.key}
                  className={`home-rail-track__item${Math.min(selectedRailIndex, railItems.length - 1) === index ? ' is-active' : ''}`}
                  onClick={() => {
                    setSelectedRailIndex(index);
                    garmentRailRef.current?.scrollTo({ left: Math.max(0, index * 158 - 90), behavior: shouldReduceMotion ? 'auto' : 'smooth' });
                  }}
                  aria-pressed={Math.min(selectedRailIndex, railItems.length - 1) === index}
                  aria-label={`${t('home.railSelectLabel')}: ${item.title}`}
                >
                  <span className="home-rail-track__hanger" aria-hidden="true" />
                  <span className="home-rail-track__image">{item.image ? <img src={item.image} alt="" width="220" height="260" loading="lazy" decoding="async" /> : <Circle aria-hidden="true" />}</span>
                  <span className="home-rail-track__name">{item.title}</span>
                  <span className="home-rail-track__number">{String(index + 1).padStart(2, '0')}</span>
                </button>
              ))}
              {railItems.length > 1 ? <div className="home-rail-track__nudge" aria-hidden="true"><RotateCw /><span>{t('home.railDrag')}</span></div> : null}
            </div>
            <div className="home-rail-track__mobile-scroll" aria-hidden="true"><ChevronDown /> {t('home.railDrag')}</div>
          </div>
        </Container>
      </section>

      <section className="home-categories home-section-shell home-categories--editorial" aria-labelledby="category-title">
        <Container>
          <div className="home-section-heading home-section-heading--categories">
            <Reveal distance={18}>
              <p className="home-eyebrow home-eyebrow--blue"><span className="home-eyebrow__dot" />{t('home.categoryEyebrow')}</p>
              <h2 id="category-title" className="home-display-heading">{t('home.categoryTitle')}</h2>
            </Reveal>
            <p className="home-section-intro">{t('home.categoryIntro')}</p>
          </div>
          <div className="home-category-grid">
            {categories.slice(0, 4).map((category, index) => (
              <Reveal key={category.id} className="home-category-reveal" delay={index * 0.08} distance={18}>
                <Link to={`/shop/${category.slug}`} className="home-category-card">
                  <span className="home-category-card__image-wrap">
                    <img src={categoryImage(category)} alt="" className="home-category-card__image" width="580" height="700" loading="lazy" decoding="async" />
                    <span className="home-category-card__number">FORM / {String(index + 1).padStart(2, '0')}</span>
                    <span className="home-category-card__arrow"><ArrowUpRight aria-hidden="true" /></span>
                  </span>
                  <span className="home-category-card__caption">
                    <span><strong>{pickLocalizedText(locale, category.nameEn, category.nameBn)}</strong><small>{category.productCount ? t('shop.showingCount', { shown: category.productCount, total: category.productCount }) : t('home.railStartHere')}</small></span>
                    <ArrowUpRight aria-hidden="true" />
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      <section className="home-studio home-studio--editorial" id="studio" aria-labelledby="studio-title">
        <Container className="home-studio__inner">
          <div className="home-studio__copy">
            <p className="home-eyebrow home-eyebrow--light"><span className="home-eyebrow__dot" />{t('home.studioBandBadge')}</p>
            <h2 className="home-studio__title" id="studio-title">{t('home.studioBandTitle')}</h2>
            <p className="home-studio__body">{t('home.studioBandBody')}</p>
            <div className="home-studio__actions">
              <Button asChild variant="primary"><Link to="/studio">{t('home.studioCta')} <ArrowUpRight aria-hidden="true" className="size-4" /></Link></Button>
              <span>{t('home.studioStatus')}</span>
            </div>
          </div>
          <div className="home-studio-art" aria-label={t('home.studioStatus')}>
            <div className="home-studio-art__halo" aria-hidden="true" />
            <div className="home-studio-art__garment"><img src="/catalog/tee-front.svg" alt="" width="480" height="560" loading="lazy" /></div>
            <span className="home-studio-art__mode home-studio-art__mode--2d">02D / CANVAS <Check aria-hidden="true" /></span>
            <span className="home-studio-art__mode home-studio-art__mode--3d">03D / PREVIEW <Sparkles aria-hidden="true" /></span>
            <span className="home-studio-art__caption"><span>DESIGN OBJECT</span><span>FRONT / PRINT SURFACE</span></span>
          </div>
        </Container>
      </section>

      <div className="home-status-wrap home-status-wrap--editorial">
        <Container>
          <details className="home-status">
            <summary><Circle aria-hidden="true" className="size-2 fill-current text-accent" /><span>{t('home.platformStatus')}</span><span className="home-status__chevron"><ChevronDown aria-hidden="true" className="size-4" /></span></summary>
            <div className="home-status__content">
              <span className="home-status__line">{t('home.platformStatus')}: {health.status === 'loaded' ? (health.data?.status === 'healthy' ? t('home.statusHealthy') : t('home.statusOffline')) : health.status === 'loading' ? t('home.statusChecking') : t('home.statusOffline')}</span>
              <span className="home-status__line">{t('home.databaseStatus')}: {health.data?.checks.database.status === 'up' ? t('home.statusConnected') : t('home.statusOffline')}</span>
              <button type="button" onClick={health.refresh}>{t('home.refreshStatus')}</button>
              {health.errorMessage ? <p className="home-status__error">{health.errorMessage}</p> : null}
            </div>
          </details>
        </Container>
      </div>
    </div>
  );
}
