import { useQuery } from '@tanstack/react-query';
import {
  CATALOG_SORT_OPTIONS,
  type CatalogSortOption,
  GARMENT_SIZES,
  type GarmentSizeCode,
} from '@your-choice/shared-types';
import {
  Badge,
  Button,
  Card,
  Checkbox,
  Container,
  EmptyState,
  Input,
  LoadingState,
  Section,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@your-choice/ui';
import { AlertCircle, ChevronLeft, ChevronRight, RotateCcw, Search, Shirt } from 'lucide-react';
import { useMemo, useRef } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ProductCard } from '@/features/catalog/components/ProductCard';
import { fetchPublicCategories, fetchPublicProducts } from '@/features/catalog/catalog.api';
import { pickLocalizedText, useAppLocale } from '@/i18n';

const ALL_VALUE = '__all__';

function isValidSort(val: string | null): val is CatalogSortOption {
  return val !== null && (CATALOG_SORT_OPTIONS as readonly string[]).includes(val);
}

function isValidSize(val: string | null): val is GarmentSizeCode {
  return val !== null && (GARMENT_SIZES as readonly string[]).includes(val);
}

export function ShopPage() {
  const { category } = useParams<{ category?: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { locale, t } = useAppLocale();

  const searchParam = searchParams.get('search') ?? '';
  const rawSizeParam = searchParams.get('size');
  const sizeParam = isValidSize(rawSizeParam) ? rawSizeParam : undefined;
  const colorParam = searchParams.get('color') ?? undefined;
  const customizableParam = searchParams.get('customizable') === 'true' ? true : undefined;
  const rawSortParam = searchParams.get('sort');
  const sortParam: CatalogSortOption = isValidSort(rawSortParam) ? rawSortParam : 'featured';
  const rawPage = Number.parseInt(searchParams.get('page') ?? '1', 10);
  const pageParam = Number.isFinite(rawPage) && rawPage >= 1 ? rawPage : 1;
  const searchInputRef = useRef<HTMLInputElement>(null);

  const categoriesQuery = useQuery({
    queryKey: ['catalog', 'categories'],
    queryFn: ({ signal }) => fetchPublicCategories(signal),
    retry: false,
  });

  const productsQuery = useQuery({
    queryKey: [
      'catalog',
      'products',
      {
        category: category ?? null,
        search: searchParam || null,
        size: sizeParam ?? null,
        color: colorParam ?? null,
        customizable: customizableParam ?? null,
        sort: sortParam,
        page: pageParam,
      },
    ],
    queryFn: ({ signal }) =>
      fetchPublicProducts(
        {
          category,
          search: searchParam || undefined,
          size: sizeParam,
          color: colorParam,
          customizable: customizableParam,
          sort: sortParam,
          page: pageParam,
          pageSize: 12,
        },
        signal
      ),
    retry: false,
  });

  const categories = useMemo(() => categoriesQuery.data ?? [], [categoriesQuery.data]);
  const activeCategory = useMemo(
    () => categories.find((item) => item.slug === category) ?? null,
    [categories, category]
  );

  const pageHeading = activeCategory
    ? t('shop.titleCategory', {
        category: pickLocalizedText(locale, activeCategory.nameEn, activeCategory.nameBn),
      })
    : t('shop.titleAll');

  const updateFilterParam = (updates: Record<string, string | undefined>) => {
    const next = new URLSearchParams(searchParams);
    for (const [key, value] of Object.entries(updates)) {
      if (!value) {
        next.delete(key);
      } else {
        next.set(key, value);
      }
    }
    if (!('page' in updates)) {
      next.delete('page');
    }
    setSearchParams(next, { replace: true });
  };

  const resetAllFilters = () => {
    if (searchInputRef.current) {
      searchInputRef.current.value = '';
    }
    setSearchParams({}, { replace: true });
    if (category) {
      navigate('/shop');
    }
  };

  const hasActiveFilters = Boolean(
    category ||
    searchParam ||
    sizeParam ||
    colorParam ||
    customizableParam ||
    sortParam !== 'featured'
  );

  const facets = productsQuery.data?.facets ?? { sizes: [], colors: [] };
  const pagination = productsQuery.data?.pagination;
  const products = productsQuery.data?.products ?? [];

  return (
    <Section spacing="md">
      <Container className="space-y-8">
        <div className="space-y-5 border-b border-border pb-6">
          <Badge variant="accent">{t('shop.badge')}</Badge>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div className="space-y-2">
              <h1 className="font-display text-3xl font-bold tracking-tight text-ink sm:text-4xl">
                {pageHeading}
              </h1>
              <p className="max-w-2xl text-sm leading-relaxed text-ink-muted sm:text-base">
                {activeCategory
                  ? pickLocalizedText(
                      locale,
                      activeCategory.descriptionEn,
                      activeCategory.descriptionBn
                    ) || t('shop.subtitle')
                  : t('shop.subtitle')}
              </p>
            </div>

            <nav aria-label="Product categories" className="flex flex-wrap gap-2">
              <Link
                to="/shop"
                className={`inline-flex min-h-11 items-center rounded-xl border px-4 py-2 text-sm font-medium transition-colors ${
                  !category
                    ? 'border-accent bg-accent text-white shadow-xs'
                    : 'border-border bg-surface text-ink hover:bg-surface-muted'
                }`}
              >
                {t('shop.categoryAll')}
              </Link>
              {categories.map((item) => {
                const isActive = category === item.slug;
                return (
                  <Link
                    key={item.id}
                    to={`/shop/${item.slug}`}
                    className={`inline-flex min-h-11 items-center gap-2 rounded-xl border px-4 py-2 text-sm font-medium transition-colors ${
                      isActive
                        ? 'border-accent bg-accent text-white shadow-xs'
                        : 'border-border bg-surface text-ink hover:bg-surface-muted'
                    }`}
                  >
                    <span>{pickLocalizedText(locale, item.nameEn, item.nameBn)}</span>
                    <span
                      className={`rounded-full px-1.5 py-0.5 font-mono text-[11px] ${
                        isActive ? 'bg-white/20 text-white' : 'bg-surface-muted text-ink-muted'
                      }`}
                    >
                      {item.productCount}
                    </span>
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>

        <Card className="p-4 sm:p-5">
          <div className="grid gap-3 md:grid-cols-12 md:items-center">
            <form
              className="relative md:col-span-4"
              onSubmit={(event) => {
                event.preventDefault();
                updateFilterParam({
                  search: searchInputRef.current?.value.trim() || undefined,
                });
              }}
            >
              <label htmlFor="shop-search-input" className="sr-only">
                {t('shop.searchLabel')}
              </label>
              <Search
                className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-ink-muted"
                aria-hidden="true"
              />
              <Input
                key={searchParam}
                ref={searchInputRef}
                id="shop-search-input"
                type="search"
                defaultValue={searchParam}
                onChange={(event) => {
                  if (event.target.value === '' && searchParam !== '') {
                    updateFilterParam({ search: undefined });
                  }
                }}
                placeholder={t('shop.searchPlaceholder')}
                className="pl-10"
              />
            </form>

            <div className="md:col-span-2">
              <Select
                value={sizeParam ?? ALL_VALUE}
                onValueChange={(value) =>
                  updateFilterParam({ size: value === ALL_VALUE ? undefined : value })
                }
              >
                <SelectTrigger aria-label={t('shop.sizeFilter')}>
                  <SelectValue placeholder={t('common.allSizes')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={ALL_VALUE}>{t('common.allSizes')}</SelectItem>
                  {(facets.sizes.length > 0 ? facets.sizes : GARMENT_SIZES).map((size) => (
                    <SelectItem key={size} value={size}>
                      {size}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="md:col-span-2">
              <Select
                value={colorParam ?? ALL_VALUE}
                onValueChange={(value) =>
                  updateFilterParam({ color: value === ALL_VALUE ? undefined : value })
                }
              >
                <SelectTrigger aria-label={t('shop.colorFilter')}>
                  <SelectValue placeholder={t('shop.colorFilter')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={ALL_VALUE}>{t('shop.colorFilter')}: All</SelectItem>
                  {facets.colors.map((swatch) => (
                    <SelectItem key={swatch.colorHex} value={swatch.colorHex}>
                      {pickLocalizedText(locale, swatch.colorNameEn, swatch.colorNameBn)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="md:col-span-2">
              <Select
                value={sortParam}
                onValueChange={(value) => updateFilterParam({ sort: value })}
              >
                <SelectTrigger aria-label={t('shop.sortLabel')}>
                  <SelectValue placeholder={t('shop.sortLabel')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">{t('shop.sortFeatured')}</SelectItem>
                  <SelectItem value="newest">{t('shop.sortNewest')}</SelectItem>
                  <SelectItem value="price_asc">{t('shop.sortPriceAsc')}</SelectItem>
                  <SelectItem value="price_desc">{t('shop.sortPriceDesc')}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between gap-2 md:col-span-2 md:justify-end">
              {hasActiveFilters ? (
                <Button type="button" variant="ghost" size="sm" onClick={resetAllFilters}>
                  <RotateCcw className="size-3.5" aria-hidden="true" />
                  {t('shop.clearFilters')}
                </Button>
              ) : null}
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-3">
            <Checkbox
              id="shop-customizable-filter"
              checked={Boolean(customizableParam)}
              onChange={(event) =>
                updateFilterParam({
                  customizable: event.target.checked ? 'true' : undefined,
                })
              }
              label={t('shop.customizableOnly')}
            />

            {pagination ? (
              <p className="font-mono text-xs text-ink-muted">
                {t('shop.showingCount', {
                  shown: products.length,
                  total: pagination.totalItems,
                })}
              </p>
            ) : null}
          </div>
        </Card>

        {productsQuery.isLoading ? (
          <LoadingState label={t('common.loading')} />
        ) : productsQuery.isError ? (
          <Card className="border-warning/30 bg-warning-soft/50 p-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <AlertCircle className="mt-0.5 size-5 shrink-0 text-warning" aria-hidden="true" />
                <div className="space-y-1">
                  <h2 className="font-display text-lg font-semibold text-ink">
                    {t('home.catalogUnavailableTitle')}
                  </h2>
                  <p className="text-sm text-ink-muted">{t('home.catalogUnavailableDesc')}</p>
                </div>
              </div>
              <Button type="button" variant="secondary" onClick={() => productsQuery.refetch()}>
                {t('common.retry')}
              </Button>
            </div>
          </Card>
        ) : products.length === 0 ? (
          <EmptyState
            icon={<Shirt className="size-6" />}
            title={t('shop.emptyTitle')}
            description={t('shop.emptyDesc')}
            action={
              <Button type="button" variant="secondary" onClick={resetAllFilters}>
                <RotateCcw className="size-4" aria-hidden="true" />
                {t('shop.clearFilters')}
              </Button>
            }
          />
        ) : (
          <>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>

            {pagination && pagination.totalPages > 1 ? (
              <div className="flex items-center justify-between border-t border-border pt-6">
                <Button
                  type="button"
                  variant="secondary"
                  disabled={pagination.page <= 1}
                  onClick={() => updateFilterParam({ page: String(pagination.page - 1) })}
                >
                  <ChevronLeft className="size-4" aria-hidden="true" />
                  {t('shop.previous')}
                </Button>

                <span className="font-mono text-xs text-ink-muted">
                  {t('shop.pageOf', {
                    page: pagination.page,
                    totalPages: pagination.totalPages,
                  })}
                </span>

                <Button
                  type="button"
                  variant="secondary"
                  disabled={pagination.page >= pagination.totalPages}
                  onClick={() => updateFilterParam({ page: String(pagination.page + 1) })}
                >
                  {t('shop.next')}
                  <ChevronRight className="size-4" aria-hidden="true" />
                </Button>
              </div>
            ) : null}
          </>
        )}
      </Container>
    </Section>
  );
}
