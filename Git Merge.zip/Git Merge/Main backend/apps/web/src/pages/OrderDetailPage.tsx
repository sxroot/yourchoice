import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Badge,
  Button,
  Card,
  Container,
  EmptyState,
  FormField,
  Input,
  LoadingState,
  Section,
} from '@your-choice/ui';
import { ArrowLeft, CheckCircle2, Clock, CreditCard, MapPin, Package, XCircle } from 'lucide-react';
import { useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { cancelOwnOrder, fetchOrderDetail } from '@/features/commerce/commerce.api';
import { OrderStatusBadge, PaymentStatusBadge } from '@/features/commerce/OrderStatusBadge';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';

export function OrderDetailPage() {
  const { orderNumber = '' } = useParams<{ orderNumber: string }>();
  const [searchParams] = useSearchParams();
  const isJustPlaced = searchParams.get('placed') === '1';
  const { locale, t } = useAppLocale();
  const queryClient = useQueryClient();

  const [cancelReason, setCancelReason] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);

  const orderQuery = useQuery({
    queryKey: ['orders', 'detail', orderNumber],
    queryFn: ({ signal }) => fetchOrderDetail(orderNumber, signal),
    enabled: Boolean(orderNumber),
    retry: false,
  });

  const cancelMutation = useMutation({
    mutationFn: () =>
      cancelOwnOrder(orderNumber, cancelReason.trim() ? { reason: cancelReason.trim() } : {}),
    onSuccess: (updated) => {
      setActionError(null);
      queryClient.setQueryData(['orders', 'detail', orderNumber], updated);
      void queryClient.invalidateQueries({ queryKey: ['orders', 'me'] });
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'Unable to cancel order.');
    },
  });

  if (orderQuery.isLoading) {
    return (
      <Section spacing="md">
        <Container>
          <LoadingState label={t('common.loading')} />
        </Container>
      </Section>
    );
  }

  if (orderQuery.isError || !orderQuery.data) {
    return (
      <Section spacing="md">
        <Container>
          <EmptyState
            icon={<Package className="size-6" />}
            title="Order record unavailable"
            description={
              orderQuery.error instanceof Error
                ? orderQuery.error.message
                : 'Sign in with the ordering account or use the checkout browser receipt session.'
            }
            action={
              <Button asChild variant="secondary">
                <Link to="/shop">
                  <ArrowLeft className="size-4" aria-hidden="true" />
                  {t('product.backToShop')}
                </Link>
              </Button>
            }
          />
        </Container>
      </Section>
    );
  }

  const order = orderQuery.data;

  return (
    <Section spacing="md">
      <Container className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link
            to="/orders"
            className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-ink-muted transition-colors hover:text-ink"
          >
            <ArrowLeft className="size-4" aria-hidden="true" />
            <span>{t('orders.backToOrders')}</span>
          </Link>
          <span className="font-mono text-xs text-ink-muted">
            {new Date(order.createdAt).toLocaleString()}
          </span>
        </div>

        {isJustPlaced ? (
          <Card
            data-testid="order-confirmation-banner"
            className="flex items-start gap-3 border-success/40 bg-success-soft p-5 text-success"
          >
            <CheckCircle2 className="mt-0.5 size-5 shrink-0" aria-hidden="true" />
            <div className="space-y-1">
              <p className="font-display text-base font-bold">
                {t('orders.confirmationBannerTitle')}
              </p>
              <p className="text-xs">
                {t('orders.confirmationBannerDesc', { orderNumber: order.orderNumber })}
              </p>
            </div>
          </Card>
        ) : null}

        {actionError ? (
          <div
            role="alert"
            className="rounded-xl border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger"
          >
            {actionError}
          </div>
        ) : null}

        <Card className="flex flex-col gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <h1
                data-testid="order-number-heading"
                className="font-mono text-xl font-bold text-ink sm:text-2xl"
              >
                {order.orderNumber}
              </h1>
              <OrderStatusBadge status={order.orderStatus} />
              <PaymentStatusBadge status={order.paymentStatus} />
            </div>
            <p className="text-xs text-ink-muted">
              {order.customerEmail} · <span className="font-mono">{order.customerPhone}</span>
            </p>
          </div>

          <div className="space-y-0.5 text-left sm:text-right">
            <p className="font-mono text-xl font-bold text-ink">
              {formatBdtPrice(order.totalAmount, order.currencyCode)}
            </p>
            <p className="text-xs text-ink-muted">
              {t('cart.subtotalLabel')}: {formatBdtPrice(order.subtotalAmount)} ·{' '}
              {formatBdtPrice(order.shippingAmount)}
            </p>
          </div>
        </Card>

        <div className="grid gap-6 lg:grid-cols-12 lg:items-start">
          <div className="space-y-6 lg:col-span-7">
            {/* Ordered Items Snapshot */}
            <Card className="space-y-4 p-5 sm:p-6">
              <h2 className="font-display text-base font-semibold text-ink">
                {t('orders.itemsSection')}
              </h2>
              <div className="divide-y divide-border">
                {order.items.map((item) => {
                  const name = pickLocalizedText(locale, item.productNameEn, item.productNameBn);
                  const color = pickLocalizedText(locale, item.colorNameEn, item.colorNameBn);
                  return (
                    <div
                      key={item.id}
                      className="flex items-start justify-between gap-3 py-3 first:pt-0 last:pb-0"
                    >
                      <div className="flex min-w-0 items-start gap-3">
                        <div className="size-14 shrink-0 overflow-hidden rounded-xl border border-border bg-surface-muted">
                          {item.primaryImageUrl ? (
                            <img
                              src={item.primaryImageUrl}
                              alt={name}
                              className="h-full w-full object-cover"
                            />
                          ) : null}
                        </div>
                        <div className="min-w-0 space-y-0.5">
                          <Link
                            to={`/product/${item.productSlug}`}
                            className="line-clamp-1 font-display text-sm font-semibold text-ink hover:text-accent"
                          >
                            {name}
                          </Link>
                          <p className="text-xs text-ink-muted">
                            {color} · <span className="font-mono">{item.sizeCode}</span> ·{' '}
                            <span className="font-mono">{item.sku}</span>
                          </p>
                          <p className="font-mono text-xs text-ink-muted">
                            {formatBdtPrice(item.unitPrice)} × {item.quantity}
                            {Number.parseFloat(item.customizationFee) > 0
                              ? ` (+${formatBdtPrice(item.customizationFee)} ${t('cart.customPrintFee')})`
                              : ''}
                          </p>
                          {item.designTitle || item.productionSpec ? (
                            <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-accent-ink">
                              <span className="rounded-full border border-accent/35 bg-accent-soft px-2 py-0.5 font-medium">
                                {t('cart.customDesignLabel')}: {item.designTitle ?? 'Studio Design'}
                              </span>
                              {item.productionSpec?.surfaces.length ? (
                                <span className="text-ink-muted">
                                  {item.productionSpec.surfaces
                                    .map((s) => `${s.surfaceKey} (${s.targetDpi ?? 300} DPI)`)
                                    .join(' · ')}
                                </span>
                              ) : null}
                            </div>
                          ) : null}
                        </div>
                      </div>

                      <span className="shrink-0 font-mono text-sm font-bold text-ink">
                        {formatBdtPrice(item.lineTotal, item.currencyCode)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </Card>

            {/* Timeline */}
            <Card className="space-y-4 p-5 sm:p-6">
              <div className="flex items-center gap-2">
                <Clock className="size-4 text-accent-royal" aria-hidden="true" />
                <h2 className="font-display text-base font-semibold text-ink">
                  {t('orders.timelineSection')}
                </h2>
              </div>
              <div className="space-y-3">
                {order.statusHistory.map((entry) => (
                  <div
                    key={entry.id}
                    className="flex flex-col gap-1 rounded-xl border border-border bg-surface-muted/40 px-3.5 py-2.5 text-xs"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <OrderStatusBadge status={entry.toStatus} />
                        {entry.actorRole ? (
                          <span className="font-mono text-[11px] text-ink-muted">
                            [{entry.actorRole}]
                          </span>
                        ) : null}
                      </div>
                      <span className="font-mono text-[11px] text-ink-muted">
                        {new Date(entry.createdAt).toLocaleString()}
                      </span>
                    </div>
                    {entry.note ? <p className="text-ink">{entry.note}</p> : null}
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <div className="space-y-6 lg:col-span-5">
            {/* Shipping Snapshot */}
            <Card className="space-y-3 p-5 sm:p-6">
              <div className="flex items-center gap-2">
                <MapPin className="size-4 text-accent-royal" aria-hidden="true" />
                <h2 className="font-display text-base font-semibold text-ink">
                  {t('orders.shippingDestination')}
                </h2>
              </div>
              <div className="space-y-1 text-xs text-ink">
                <p className="font-semibold">{order.shippingAddress.recipientName}</p>
                <p className="font-mono text-ink-muted">{order.shippingAddress.phone}</p>
                <p className="text-ink-muted">
                  {order.shippingAddress.addressLine}, {order.shippingAddress.area},{' '}
                  {order.shippingAddress.district}, {order.shippingAddress.division}
                  {order.shippingAddress.postalCode ? ` (${order.shippingAddress.postalCode})` : ''}
                </p>
                <Badge variant="neutral">{order.shippingZoneName}</Badge>
                {order.customerNote ? (
                  <p className="mt-2 rounded-lg bg-surface-muted px-3 py-2 text-ink-muted">
                    {order.customerNote}
                  </p>
                ) : null}
              </div>
            </Card>

            {/* Payment Records */}
            <Card className="space-y-3 p-5 sm:p-6">
              <div className="flex items-center gap-2">
                <CreditCard className="size-4 text-accent-royal" aria-hidden="true" />
                <h2 className="font-display text-base font-semibold text-ink">
                  {t('orders.paymentsSection')}
                </h2>
              </div>
              <div className="space-y-2">
                {order.paymentTransactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="space-y-1 rounded-xl border border-border bg-surface-muted/40 p-3 text-xs"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono font-semibold uppercase text-ink">
                        {tx.gateway}
                      </span>
                      <Badge variant={tx.status === 'paid' ? 'success' : 'neutral'}>
                        {tx.status}
                      </Badge>
                    </div>
                    <p className="font-mono text-ink">
                      {formatBdtPrice(tx.amount, tx.currencyCode)}
                    </p>
                    {tx.transactionRef ? (
                      <p className="font-mono text-[11px] text-ink-muted">
                        Ref: {tx.transactionRef}
                      </p>
                    ) : null}
                  </div>
                ))}
              </div>
            </Card>

            {/* Customer Self-Service Cancel */}
            {order.canCustomerCancel ? (
              <Card className="space-y-3 border-danger/25 p-5 sm:p-6">
                <div className="flex items-center gap-2 text-danger">
                  <XCircle className="size-4" aria-hidden="true" />
                  <h2 className="font-display text-base font-semibold">
                    {t('orders.cancelOrderBtn')}
                  </h2>
                </div>
                <p className="text-xs text-ink-muted">{t('orders.cancelConfirmDesc')}</p>
                <FormField id="cancel-reason-input" label={t('orders.cancelReasonLabel')}>
                  <Input
                    id="cancel-reason-input"
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    placeholder="Changed size / ordered by mistake"
                    className="text-base sm:text-sm"
                  />
                </FormField>
                <Button
                  type="button"
                  variant="danger"
                  className="w-full"
                  data-testid="cancel-order-button"
                  disabled={cancelMutation.isPending}
                  onClick={() => cancelMutation.mutate()}
                >
                  {cancelMutation.isPending ? t('common.loading') : t('orders.cancelOrderBtn')}
                </Button>
              </Card>
            ) : null}
          </div>
        </div>
      </Container>
    </Section>
  );
}
