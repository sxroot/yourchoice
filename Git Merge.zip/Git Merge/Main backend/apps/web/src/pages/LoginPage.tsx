import { zodResolver } from '@hookform/resolvers/zod';
import { type LoginInput, loginSchema } from '@your-choice/validation';
import { Badge, Button, Card, Container, FormField, Input, Section } from '@your-choice/ui';
import { AlertCircle, ArrowRight, KeyRound, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { FadeIn } from '@/components/motion';
import { sanitizeRedirectPath, useAuth } from '@/features/auth/auth-context';
import { PasswordInput } from '@/features/auth/components/PasswordInput';
import { ApiClientError } from '@/services/api-client';

export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [serverError, setServerError] = useState<string | null>(null);

  const rawRedirect = searchParams.get('redirect');
  const destination = sanitizeRedirectPath(rawRedirect, '/account');
  const registerHref = rawRedirect
    ? `/register?redirect=${encodeURIComponent(rawRedirect)}`
    : '/register';

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: '',
      password: '',
      rememberMe: true,
    },
  });

  const onSubmit = async (values: LoginInput) => {
    setServerError(null);
    try {
      await login(values);
      navigate(destination, { replace: true });
    } catch (error: unknown) {
      if (error instanceof ApiClientError) {
        setServerError(error.message);
        return;
      }
      setServerError('Unable to sign in right now. Please try again shortly.');
    }
  };

  return (
    <Section spacing="md" className="min-h-[calc(100dvh-14rem)]">
      <Container>
        <div className="mx-auto grid max-w-5xl items-stretch gap-8 lg:grid-cols-12">
          <FadeIn className="hidden lg:col-span-5 lg:flex">
            <Card className="flex w-full flex-col justify-between border-border-dark bg-dark-tech p-8 text-ink-inverse shadow-elevated">
              <div className="space-y-5">
                <Badge variant="dark" className="border-accent-cyan/40 text-accent-cyan-bright">
                  YOUR CHOICE Identity
                </Badge>
                <h1 className="font-display text-3xl leading-tight font-bold tracking-tight text-ink-inverse">
                  Sign in to your custom apparel studio &amp; orders.
                </h1>
                <p className="text-sm leading-relaxed text-ink-silver">
                  Access saved garment drafts, track production fulfillment, or manage your creator
                  marketplace storefront with encrypted session protection.
                </p>
              </div>

              <div className="space-y-4 border-t border-border-dark pt-6 text-xs text-ink-silver">
                <div className="flex items-start gap-3">
                  <ShieldCheck
                    className="mt-0.5 size-4 shrink-0 text-accent-cyan-bright"
                    aria-hidden="true"
                  />
                  <span>
                    HttpOnly server-validated MariaDB sessions with CSRF Origin verification.
                  </span>
                </div>
                <div className="flex items-start gap-3">
                  <KeyRound
                    className="mt-0.5 size-4 shrink-0 text-accent-cyan-bright"
                    aria-hidden="true"
                  />
                  <span>Role-scoped access across Customer, Creator, Operations, and Admin.</span>
                </div>
              </div>
            </Card>
          </FadeIn>

          <FadeIn delay={0.05} className="lg:col-span-7">
            <Card className="mx-auto max-w-xl p-6 sm:p-8 lg:max-w-none">
              <div className="space-y-2 border-b border-border pb-5">
                <Badge variant="accent">Account Sign In</Badge>
                <h2 className="font-display text-2xl font-bold tracking-tight text-ink sm:text-3xl">
                  Welcome back
                </h2>
                <p className="text-sm text-ink-muted">
                  Sign in with your email and password to continue on YOUR CHOICE.
                </p>
              </div>

              {serverError ? (
                <div
                  role="alert"
                  className="mt-5 flex items-start gap-2.5 rounded-xl border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger"
                >
                  <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                  <span>{serverError}</span>
                </div>
              ) : null}

              <form onSubmit={handleSubmit(onSubmit)} noValidate className="mt-6 space-y-5">
                <FormField
                  id="login-email"
                  label="Email address"
                  required
                  error={errors.email?.message}
                >
                  <Input
                    id="login-email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@allyourchoice.com"
                    invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'login-email-error' : undefined}
                    {...register('email')}
                  />
                </FormField>

                <FormField
                  id="login-password"
                  label="Password"
                  required
                  error={errors.password?.message}
                >
                  <PasswordInput
                    id="login-password"
                    autoComplete="current-password"
                    placeholder="Enter your password"
                    invalid={Boolean(errors.password)}
                    aria-describedby={errors.password ? 'login-password-error' : undefined}
                    {...register('password')}
                  />
                </FormField>

                <div className="flex items-center justify-between gap-4">
                  <label className="inline-flex min-h-11 cursor-pointer items-center gap-2.5 text-sm text-ink">
                    <input
                      type="checkbox"
                      className="size-4 rounded border-border accent-accent-royal focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent-electric"
                      {...register('rememberMe')}
                    />
                    <span>Keep me signed in on this browser</span>
                  </label>
                </div>

                <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? 'Signing in...' : 'Sign In'}
                  <ArrowRight className="size-4" aria-hidden="true" />
                </Button>
              </form>

              <p className="mt-6 border-t border-border pt-5 text-center text-sm text-ink-muted">
                New to YOUR CHOICE?{' '}
                <Link
                  to={registerHref}
                  className="font-semibold text-accent-ink underline-offset-4 hover:underline"
                >
                  Create an account
                </Link>
              </p>
            </Card>
          </FadeIn>
        </div>
      </Container>
    </Section>
  );
}
