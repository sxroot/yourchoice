import { AlertTriangle, RefreshCw } from 'lucide-react';
import { isRouteErrorResponse, Link, useRouteError } from 'react-router-dom';
import { Button, Card, Container } from '@your-choice/ui';

export function RouteErrorPage() {
  const error = useRouteError();

  let title = 'Unexpected application error';
  let detail = 'Something went wrong while rendering this route.';

  if (isRouteErrorResponse(error)) {
    title = `${error.status} ${error.statusText || 'Route Error'}`;
    detail = typeof error.data === 'string' ? error.data : detail;
  } else if (error instanceof Error) {
    detail = error.message;
  }

  return (
    <div className="flex min-h-dvh items-center bg-canvas py-12 text-ink">
      <Container>
        <Card className="mx-auto max-w-lg space-y-4 text-center">
          <div className="mx-auto inline-flex size-11 items-center justify-center rounded-xl border border-danger/30 bg-danger-soft text-danger">
            <AlertTriangle className="size-5" aria-hidden="true" />
          </div>
          <h1 className="font-display text-2xl font-bold text-ink">{title}</h1>
          <p className="text-sm text-ink-muted">{detail}</p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <Button variant="secondary" onClick={() => window.location.reload()}>
              <RefreshCw className="size-4" aria-hidden="true" />
              Reload Page
            </Button>
            <Button asChild>
              <Link to="/">Return Home</Link>
            </Button>
          </div>
        </Card>
      </Container>
    </div>
  );
}
