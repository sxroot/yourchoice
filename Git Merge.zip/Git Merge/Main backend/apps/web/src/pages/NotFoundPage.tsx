import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button, Card, Container, Section } from '@your-choice/ui';

export function NotFoundPage() {
  return (
    <Section spacing="md">
      <Container>
        <Card className="mx-auto max-w-lg space-y-4 text-center">
          <p className="font-mono text-xs font-semibold uppercase tracking-wider text-accent-ink">
            404
          </p>
          <h1 className="font-display text-2xl font-bold text-ink">Page not found</h1>
          <p className="text-sm text-ink-muted">
            This route has not been staged in the current foundation milestone.
          </p>
          <div className="pt-2">
            <Button asChild>
              <Link to="/">
                <ArrowLeft className="size-4" aria-hidden="true" />
                Return to Foundation Home
              </Link>
            </Button>
          </div>
        </Card>
      </Container>
    </Section>
  );
}
