import {
  Badge,
  Button,
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
  Container,
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
  EmptyState,
  IconButton,
  Input,
  LoadingState,
  Section,
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
  Skeleton,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
  Textarea,
} from '@your-choice/ui';
import {
  ArrowRight,
  Check,
  Layers,
  Menu,
  Palette,
  RefreshCw,
  Shirt,
  SlidersHorizontal,
  Sparkles,
} from 'lucide-react';
import { useId, useState } from 'react';
import { FadeIn, Reveal, SlideIn, StaggerContainer, StaggerItem } from '@/components/motion';

interface SwatchToken {
  name: string;
  variable: string;
  hex: string;
  role: string;
  swatchClass: string;
  darkText?: boolean;
}

const BRAND_SWATCHES: readonly SwatchToken[] = [
  {
    name: 'Royal Blue',
    variable: '--color-accent',
    hex: '#1d4ed8',
    role: 'Primary CTA & active brand focal accent',
    swatchClass: 'bg-accent',
  },
  {
    name: 'Electric Blue',
    variable: '--color-accent-electric',
    hex: '#2563eb',
    role: 'Interactive focus ring & luminous highlight',
    swatchClass: 'bg-accent-electric',
  },
  {
    name: 'Deep Cyan',
    variable: '--color-accent-cyan',
    hex: '#0891b2',
    role: 'Studio precision badges & gradient endpoint',
    swatchClass: 'bg-accent-cyan',
  },
  {
    name: 'Bright Cyan',
    variable: '--color-accent-cyan-bright',
    hex: '#22d3ee',
    role: 'High-contrast cyan accent on dark surfaces',
    swatchClass: 'bg-accent-cyan-bright',
    darkText: true,
  },
  {
    name: 'Obsidian Black',
    variable: '--color-surface-dark',
    hex: '#06080d',
    role: 'Dark-tech canvas, logo plate & footer depth',
    swatchClass: 'bg-surface-dark',
  },
  {
    name: 'Charcoal',
    variable: '--color-surface-charcoal',
    hex: '#111622',
    role: 'Dark storytelling bands & studio chrome',
    swatchClass: 'bg-surface-charcoal',
  },
  {
    name: 'Silver',
    variable: '--color-ink-silver',
    hex: '#cbd5e1',
    role: 'Secondary typography & specs on dark bands',
    swatchClass: 'bg-ink-silver',
    darkText: true,
  },
  {
    name: 'Crisp White',
    variable: '--color-surface',
    hex: '#ffffff',
    role: 'Primary storefront surface & elevated cards',
    swatchClass: 'bg-surface border border-border',
    darkText: true,
  },
];

const MOTION_PILLARS = [
  {
    title: 'Above-the-Fold Immediate Entrance',
    detail: 'FadeIn and SlideIn animate on mount using GPU transform + opacity only.',
  },
  {
    title: 'Scroll-Once Editorial Reveals',
    detail: 'Reveal uses viewport once: true and amount: 0.1 so sections never stick invisible.',
  },
  {
    title: 'Staggered Bento Grids',
    detail: 'StaggerContainer sequences bounded card groups with 60ms micro-offsets.',
  },
];

/**
 * Internal Phase A & B design-system showcase page for token, component, motion, and viewport QA.
 */
export function DesignSystemPage() {
  const nameId = useId();
  const notesId = useId();
  const garmentId = useId();

  const [selectedGarment, setSelectedGarment] = useState('heavyweight-tee');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [rightDrawerOpen, setRightDrawerOpen] = useState(false);
  const [bottomSheetOpen, setBottomSheetOpen] = useState(false);
  const [loadingMode, setLoadingMode] = useState<'inline' | 'cards'>('inline');
  const [motionReplayKey, setMotionReplayKey] = useState(0);

  return (
    <div className="min-w-0">
      {/* Dark-Tech Brand Hero */}
      <Section tone="dark" spacing="lg" className="border-b border-border-dark">
        <Container className="space-y-8">
          <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
            <SlideIn direction="up" className="min-w-0 space-y-5">
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="dark">Phase A &amp; B UI Foundation</Badge>
                <Badge variant="cyan-dark">Internal QA Preview</Badge>
              </div>

              <h1
                className="font-display font-bold tracking-tight text-ink-inverse"
                style={{ fontSize: 'var(--text-h1)', lineHeight: 1.12 }}
              >
                YOUR CHOICE Design System &amp; Component Foundation
              </h1>

              <p className="max-w-2xl text-base leading-relaxed text-ink-silver sm:text-lg">
                Built on the official Royal Blue, Electric Blue, Cyan, Obsidian Black, Charcoal,
                Silver, and Crisp White system—engineered for responsive precision from 360px mobile
                to 1440px desktop.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <Button variant="electric" size="lg" asChild>
                  <a href="#brand-tokens">
                    Inspect Tokens
                    <ArrowRight className="size-4" aria-hidden="true" />
                  </a>
                </Button>
                <Button variant="dark" size="lg" asChild>
                  <a href="#interactive-primitives">Test Overlays &amp; Forms</a>
                </Button>
              </div>
            </SlideIn>

            <FadeIn delay={0.08} className="min-w-0">
              <div className="rounded-2xl border border-border-dark bg-surface-charcoal p-6 shadow-elevated">
                <div className="flex flex-col items-center gap-5 text-center sm:flex-row sm:text-left">
                  <div className="shrink-0 overflow-hidden rounded-2xl border border-border-dark bg-surface-dark p-3">
                    <img
                      src="/brand/your-choice-logo.png"
                      alt="YOUR CHOICE official wing-shaped technology monogram"
                      width={112}
                      height={112}
                      className="size-24 object-contain sm:size-28"
                    />
                  </div>
                  <div className="min-w-0 space-y-2">
                    <p className="font-mono text-xs tracking-wider text-accent-cyan-bright uppercase">
                      Preserved Brand Mark
                    </p>
                    <p className="font-display text-lg font-semibold text-ink-inverse">
                      Always 1:1 Unaltered Aspect
                    </p>
                    <p className="text-sm text-ink-silver">
                      Original asset served from{' '}
                      <code className="rounded bg-surface-charcoal-elevated px-1.5 py-0.5 font-mono text-xs text-ink-inverse">
                        /brand/your-choice-logo.png
                      </code>{' '}
                      without cropping or color distortion.
                    </p>
                  </div>
                </div>
              </div>
            </FadeIn>
          </div>
        </Container>
      </Section>

      {/* Brand Palette & Gradients */}
      <Section id="brand-tokens" tone="surface" spacing="md" className="border-b border-border">
        <Container className="space-y-8">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-accent-ink">
              <Palette className="size-4" aria-hidden="true" />
              <span className="font-mono text-xs font-semibold tracking-wider uppercase">
                Color Tokens
              </span>
            </div>
            <h2
              className="font-display font-bold tracking-tight text-ink"
              style={{ fontSize: 'var(--text-h2)' }}
            >
              Official Brand Palette &amp; Selective Blue Gradient
            </h2>
            <p className="max-w-2xl text-sm leading-relaxed text-ink-muted">
              Every text and surface pairing meets WCAG 2.1 AA contrast ratios without purple or
              violet accents.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {BRAND_SWATCHES.map((swatch) => (
              <Card key={swatch.variable} className="overflow-hidden p-0">
                <div className={`flex h-24 items-end justify-between p-4 ${swatch.swatchClass}`}>
                  <span
                    className={`font-mono text-xs font-semibold ${
                      swatch.darkText ? 'text-ink' : 'text-ink-inverse'
                    }`}
                  >
                    {swatch.hex}
                  </span>
                </div>
                <div className="space-y-1 p-4">
                  <p className="font-display text-sm font-semibold text-ink">{swatch.name}</p>
                  <p className="font-mono text-xs text-accent-ink">{swatch.variable}</p>
                  <p className="text-xs leading-relaxed text-ink-muted">{swatch.role}</p>
                </div>
              </Card>
            ))}
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="bg-brand-gradient rounded-2xl p-6 text-white shadow-card">
              <p className="font-mono text-xs tracking-wider uppercase opacity-90">
                .bg-brand-gradient
              </p>
              <p className="mt-2 font-display text-xl font-bold">
                Royal Blue &rarr; Electric Blue &rarr; Cyan
              </p>
              <p className="mt-1 text-sm text-white/90">
                Used selectively on flagship hero highlights, brand dividers, and studio callouts.
              </p>
            </div>

            <div className="bg-dark-tech rounded-2xl border border-border-dark p-6 text-ink-inverse shadow-card">
              <p className="font-mono text-xs tracking-wider text-accent-cyan-bright uppercase">
                .bg-dark-tech
              </p>
              <p className="mt-2 font-display text-xl font-bold">
                Obsidian &amp; Charcoal Radial Depth
              </p>
              <p className="mt-1 text-sm text-ink-silver">
                Subtle electric blue and cyan atmospheric glows framing dark showcase sections.
              </p>
            </div>
          </div>
        </Container>
      </Section>

      {/* Fluid Responsive Typography */}
      <Section tone="canvas" spacing="md" className="border-b border-border">
        <Container className="space-y-6">
          <div className="space-y-2">
            <span className="font-mono text-xs font-semibold tracking-wider text-accent-ink uppercase">
              Typography Scale
            </span>
            <h2
              className="font-display font-bold tracking-tight text-ink"
              style={{ fontSize: 'var(--text-h2)' }}
            >
              Fluid Clamp Scale + Multilingual Pairing
            </h2>
          </div>

          <Card className="space-y-6">
            <div className="space-y-1 border-b border-border pb-4">
              <span className="font-mono text-xs text-ink-muted">--text-display</span>
              <p
                className="font-display font-bold tracking-tight text-ink"
                style={{ fontSize: 'var(--text-display)', lineHeight: 1.08 }}
              >
                Design it. Wear it.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1">
                <span className="font-mono text-xs text-ink-muted">--text-h2 · Space Grotesk</span>
                <p
                  className="font-display font-bold text-ink"
                  style={{ fontSize: 'var(--text-h2)' }}
                >
                  Custom Apparel Architecture
                </p>
              </div>
              <div className="space-y-1">
                <span className="font-mono text-xs text-ink-muted">--text-h3 · Plus Jakarta</span>
                <p className="font-semibold text-ink" style={{ fontSize: 'var(--text-h3)' }}>
                  Creator Royalty Transparency
                </p>
              </div>
            </div>

            <div className="grid gap-4 border-t border-border pt-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <span className="font-mono text-xs text-ink-muted">
                  Bangla Script · Hind Siliguri
                </span>
                <p className="text-base leading-relaxed text-ink">
                  আপনার নিজস্ব ডিজাইন তৈরি করুন, কাস্টম টি-শার্ট অর্ডার করুন এবং ক্রিয়েটর মার্কেটপ্লেসে আয়
                  করুন।
                </p>
              </div>
              <div className="space-y-1.5">
                <span className="font-mono text-xs text-ink-muted">
                  Technical Specs · JetBrains Mono
                </span>
                <p className="font-mono text-sm text-ink-muted">
                  DPI: 300 · BLEED: 3.175mm · ASPECT: 1:1 · MIN-TOUCH: 44x44px
                </p>
              </div>
            </div>
          </Card>
        </Container>
      </Section>

      {/* Buttons, Badges & Cards */}
      <Section tone="surface" spacing="md" className="border-b border-border">
        <Container className="space-y-8">
          <div className="space-y-2">
            <span className="font-mono text-xs font-semibold tracking-wider text-accent-ink uppercase">
              Core Primitives
            </span>
            <h2
              className="font-display font-bold tracking-tight text-ink"
              style={{ fontSize: 'var(--text-h2)' }}
            >
              Buttons, Badges &amp; Surface Tones
            </h2>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Button Variants &amp; Touch Targets</CardTitle>
                <CardDescription>
                  Minimum 40–48px hit areas with accessible focus-visible rings.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="flex flex-wrap gap-2.5">
                  <Button variant="primary">Primary Royal</Button>
                  <Button variant="electric">Electric Accent</Button>
                  <Button variant="secondary">Secondary</Button>
                  <Button variant="outline">Outline</Button>
                  <Button variant="dark">Obsidian Dark</Button>
                  <Button variant="ghost">Ghost</Button>
                  <Button variant="danger">Danger</Button>
                </div>

                <div className="flex flex-wrap items-center gap-3 border-t border-border pt-4">
                  <Button size="sm">Small (40px)</Button>
                  <Button size="md">Medium (44px)</Button>
                  <Button size="lg">Large (48px)</Button>
                  <IconButton variant="secondary" aria-label="Filter design assets">
                    <SlidersHorizontal className="size-4" aria-hidden="true" />
                  </IconButton>
                  <IconButton variant="primary" size="lg" aria-label="Open menu preview">
                    <Menu className="size-5" aria-hidden="true" />
                  </IconButton>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Badge Semantics &amp; Card Anatomy</CardTitle>
                <CardDescription>
                  Status pills calibrated for both crisp light surfaces and dark charcoal panels.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="neutral">Neutral</Badge>
                  <Badge variant="accent">Royal Accent</Badge>
                  <Badge variant="cyan">Studio Cyan</Badge>
                  <Badge variant="dark">Dark Tech</Badge>
                  <Badge variant="success">Verified Ready</Badge>
                  <Badge variant="warning">Moderation Queue</Badge>
                  <Badge variant="danger">Out of Bounds</Badge>
                </div>

                <div className="rounded-xl border border-border-dark bg-surface-charcoal p-4 text-ink-inverse">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <Shirt className="size-5 text-accent-cyan-bright" aria-hidden="true" />
                      <span className="font-display text-sm font-semibold">
                        Dark Charcoal Surface Card
                      </span>
                    </div>
                    <Badge variant="dark">2D / 3D Ready</Badge>
                  </div>
                  <p className="mt-2 text-xs leading-relaxed text-ink-silver">
                    Dedicated charcoal token (`#111622`) paired with silver (`#cbd5e1`) for upcoming
                    Design Studio panels.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </Container>
      </Section>

      {/* Interactive Forms, Tabs, Dialog & Drawers */}
      <Section
        id="interactive-primitives"
        tone="muted"
        spacing="md"
        className="border-b border-border"
      >
        <Container className="space-y-8">
          <div className="space-y-2">
            <span className="font-mono text-xs font-semibold tracking-wider text-accent-ink uppercase">
              Interactive Controls
            </span>
            <h2
              className="font-display font-bold tracking-tight text-ink"
              style={{ fontSize: 'var(--text-h2)' }}
            >
              Forms, Tabs, Modal Dialog &amp; Slide/Bottom Drawers
            </h2>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Accessible Form Inputs */}
            <Card>
              <CardHeader>
                <CardTitle>Form Inputs (&ge; 16px Mobile Font Size)</CardTitle>
                <CardDescription>
                  Prevents iOS Safari auto-zoom while maintaining compact desktop ergonomics.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1.5">
                  <label htmlFor={nameId} className="block text-sm font-medium text-ink">
                    Collection Title
                  </label>
                  <Input id={nameId} placeholder="e.g. Dhaka Monochrome Drop 01" />
                </div>

                <div className="space-y-1.5">
                  <label htmlFor={garmentId} className="block text-sm font-medium text-ink">
                    Base Apparel Template
                  </label>
                  <Select value={selectedGarment} onValueChange={setSelectedGarment}>
                    <SelectTrigger id={garmentId} aria-label="Base apparel template">
                      <SelectValue placeholder="Choose base product" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectLabel>Initial Catalog</SelectLabel>
                        <SelectItem value="heavyweight-tee">Heavyweight Street T-Shirt</SelectItem>
                        <SelectItem value="pique-polo">Tech Pique Polo Shirt</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <label htmlFor={notesId} className="block text-sm font-medium text-ink">
                    Production &amp; Print Notes
                  </label>
                  <Textarea
                    id={notesId}
                    placeholder="Specify front chest placement, DTG color profile, or packaging notes..."
                  />
                </div>

                <div className="space-y-1.5">
                  <label
                    htmlFor="invalid-input-demo"
                    className="block text-sm font-medium text-ink"
                  >
                    Validation Error State
                  </label>
                  <Input
                    id="invalid-input-demo"
                    invalid
                    defaultValue="Invalid slug with spaces"
                    aria-describedby="invalid-input-help"
                  />
                  <p id="invalid-input-help" className="text-xs font-medium text-danger">
                    Slugs may only contain lowercase letters, numbers, and hyphens.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Tabs + Dialog + Drawer Triggers */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Accessible Radix Tabs</CardTitle>
                  <CardDescription>
                    Keyboard arrow navigation across structured studio or product specifications.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="specs">
                    <TabsList aria-label="Component specification tabs">
                      <TabsTrigger value="specs">Token Specs</TabsTrigger>
                      <TabsTrigger value="a11y">Accessibility</TabsTrigger>
                      <TabsTrigger value="viewport">Viewports</TabsTrigger>
                    </TabsList>
                    <TabsContent value="specs">
                      <p className="text-sm leading-relaxed text-ink-muted">
                        Selected base template:{' '}
                        <span className="font-mono font-semibold text-ink">{selectedGarment}</span>.
                        Radius uses semantic tokens (`--radius-card`, `--radius-panel`).
                      </p>
                    </TabsContent>
                    <TabsContent value="a11y">
                      <p className="text-sm leading-relaxed text-ink-muted">
                        Focus rings render with 2px Electric Blue outlines (`#2563eb`), and all
                        overlays trap focus and close on Escape.
                      </p>
                    </TabsContent>
                    <TabsContent value="viewport">
                      <p className="text-sm leading-relaxed text-ink-muted">
                        Audited at 1440×900, 1280×800, 768×1024, 390×844, and 360×800 with zero
                        horizontal overflow.
                      </p>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Overlays: Dialog, Side Drawer &amp; Bottom Sheet</CardTitle>
                  <CardDescription>
                    Built on Radix Dialog primitives for clean focus restoration and screen reader
                    announcements.
                  </CardDescription>
                </CardHeader>
                <CardFooter className="flex flex-wrap gap-3">
                  <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="primary">Open Modal Dialog</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Confirm Print Specification</DialogTitle>
                        <DialogDescription>
                          Modal dialogs trap keyboard focus and dismiss cleanly on Escape or
                          backdrop click.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="mt-4 rounded-xl border border-border bg-surface-muted p-3.5 text-sm text-ink-muted">
                        Template selected:{' '}
                        <span className="font-mono font-semibold text-ink">{selectedGarment}</span>
                      </div>
                      <DialogFooter>
                        <DialogClose asChild>
                          <Button variant="secondary">Cancel</Button>
                        </DialogClose>
                        <Button variant="electric" onClick={() => setDialogOpen(false)}>
                          <Check className="size-4" aria-hidden="true" />
                          Confirm
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <Drawer open={rightDrawerOpen} onOpenChange={setRightDrawerOpen}>
                    <DrawerTrigger asChild>
                      <Button variant="secondary">Open Side Drawer</Button>
                    </DrawerTrigger>
                    <DrawerContent side="right">
                      <DrawerHeader>
                        <DrawerTitle>Side Inspection Panel</DrawerTitle>
                        <DrawerDescription>
                          Used for mobile navigation, cart drawers, and desktop inspector trays.
                        </DrawerDescription>
                      </DrawerHeader>
                      <div className="mt-5 space-y-3 text-sm text-ink-muted">
                        <p>
                          Slides smoothly via hardware-accelerated transform transitions along the
                          right edge.
                        </p>
                      </div>
                      <DrawerFooter>
                        <DrawerClose asChild>
                          <Button variant="primary">Done Inspecting</Button>
                        </DrawerClose>
                      </DrawerFooter>
                    </DrawerContent>
                  </Drawer>

                  <Drawer open={bottomSheetOpen} onOpenChange={setBottomSheetOpen}>
                    <DrawerTrigger asChild>
                      <Button variant="outline">Open Bottom Sheet</Button>
                    </DrawerTrigger>
                    <DrawerContent side="bottom">
                      <DrawerHeader>
                        <DrawerTitle>Mobile Tool &amp; Filter Sheet</DrawerTitle>
                        <DrawerDescription>
                          Ergonomic bottom-anchored drawer for future mobile studio toolbars and
                          catalog filters.
                        </DrawerDescription>
                      </DrawerHeader>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Badge variant="accent">Front Print Zone</Badge>
                        <Badge variant="cyan">300 DPI PNG</Badge>
                        <Badge variant="neutral">Cotton 240 GSM</Badge>
                      </div>
                      <DrawerFooter>
                        <DrawerClose asChild>
                          <Button variant="primary">Apply &amp; Close</Button>
                        </DrawerClose>
                      </DrawerFooter>
                    </DrawerContent>
                  </Drawer>
                </CardFooter>
              </Card>
            </div>
          </div>
        </Container>
      </Section>

      {/* Loading & Empty States */}
      <Section tone="surface" spacing="md" className="border-b border-border">
        <Container className="space-y-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div className="space-y-2">
              <span className="font-mono text-xs font-semibold tracking-wider text-accent-ink uppercase">
                Async Feedback
              </span>
              <h2
                className="font-display font-bold tracking-tight text-ink"
                style={{ fontSize: 'var(--text-h2)' }}
              >
                Skeleton, Loading &amp; Empty States
              </h2>
            </div>

            <div className="flex gap-2">
              <Button
                size="sm"
                variant={loadingMode === 'inline' ? 'primary' : 'secondary'}
                onClick={() => setLoadingMode('inline')}
              >
                Inline Loader
              </Button>
              <Button
                size="sm"
                variant={loadingMode === 'cards' ? 'primary' : 'secondary'}
                onClick={() => setLoadingMode('cards')}
              >
                Card Skeletons
              </Button>
            </div>
          </div>

          <LoadingState
            variant={loadingMode}
            count={3}
            label="Synchronizing apparel studio templates..."
          />

          <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
            <Card className="space-y-4">
              <CardTitle>Custom Skeleton Composition</CardTitle>
              <div className="flex items-center gap-3">
                <Skeleton className="size-12 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/5" />
                  <Skeleton className="h-3 w-2/5" />
                </div>
              </div>
              <Skeleton className="h-24 w-full rounded-xl" />
            </Card>

            <EmptyState
              icon={<Layers className="size-6" aria-hidden="true" />}
              title="No saved studio drafts yet"
              description="EmptyState primitives provide clear recovery paths when customer carts, saved designs, or filtered searches return zero items."
              action={
                <Button variant="electric" size="sm" onClick={() => setBottomSheetOpen(true)}>
                  Preview Action Trigger
                </Button>
              }
            />
          </div>
        </Container>
      </Section>

      {/* Motion Primitives Demo */}
      <Section tone="charcoal" spacing="md">
        <Container className="space-y-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-accent-cyan-bright">
                <Sparkles className="size-4" aria-hidden="true" />
                <span className="font-mono text-xs font-semibold tracking-wider uppercase">
                  Motion System
                </span>
              </div>
              <h2
                className="font-display font-bold tracking-tight text-ink-inverse"
                style={{ fontSize: 'var(--text-h2)' }}
              >
                GPU-Composited Reveals &amp; Reduced-Motion Safety
              </h2>
              <p className="max-w-2xl text-sm leading-relaxed text-ink-silver">
                All transitions animate exclusively via transform and opacity with LazyMotion strict
                bundle splitting and automatic `prefers-reduced-motion` fallback.
              </p>
            </div>

            <Button variant="dark" size="sm" onClick={() => setMotionReplayKey((prev) => prev + 1)}>
              <RefreshCw className="size-3.5" aria-hidden="true" />
              Replay Stagger
            </Button>
          </div>

          <StaggerContainer key={motionReplayKey} className="grid gap-4 md:grid-cols-3">
            {MOTION_PILLARS.map((pillar, index) => (
              <StaggerItem key={pillar.title}>
                <div className="flex h-full flex-col justify-between rounded-2xl border border-border-dark bg-surface-charcoal-elevated p-5">
                  <div className="space-y-2">
                    <Badge variant="dark">0{index + 1}</Badge>
                    <h3 className="font-display text-base font-semibold text-ink-inverse">
                      {pillar.title}
                    </h3>
                    <p className="text-sm leading-relaxed text-ink-silver">{pillar.detail}</p>
                  </div>
                </div>
              </StaggerItem>
            ))}
          </StaggerContainer>

          <Reveal className="rounded-2xl border border-border-dark bg-surface-dark p-6">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="space-y-1">
                <p className="font-mono text-xs text-accent-cyan-bright">Reveal Wrapper Check</p>
                <p className="text-sm text-ink-silver">
                  Scroll-triggered content always resolves to opacity: 1 cleanly even after direct
                  hash-link or jump scrolling.
                </p>
              </div>
              <Badge variant="cyan-dark">transform + opacity only</Badge>
            </div>
          </Reveal>
        </Container>
      </Section>
    </div>
  );
}
