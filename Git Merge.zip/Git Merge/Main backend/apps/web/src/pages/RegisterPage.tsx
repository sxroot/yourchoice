import { zodResolver } from '@hookform/resolvers/zod';
import { type RegisterFormInput, registerFormSchema } from '@your-choice/validation';
import { Badge, Button, Card, Container, FormField, Input, Section } from '@your-choice/ui';
import { AlertCircle, ArrowRight, CheckCircle2, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { FadeIn } from '@/components/motion';
import { sanitizeRedirectPath, useAuth } from '@/features/auth/auth-context';
import { PasswordInput } from '@/features/auth/components/PasswordInput';
import { ApiClientError } from '@/services/api-client';

export function RegisterPage() {
  const { register: registerAccount } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [serverError, setServerError] = useState<string | null>(null);

  const rawRedirect = searchParams.get('redirect');
  const destination = sanitizeRedirectPath(rawRedirect, '/account');
  const loginHref = rawRedirect ? `/login?redirect=${encodeURIComponent(rawRedirect)}` : '/login';

  const {
    register,
    control,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<RegisterFormInput>({
    resolver: zodResolver(registerFormSchema),
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      password: '',
      confirmPassword: '',
      preferredLocale: 'en',
    },
  });

  const watchedPassword = useWatch({ control, name: 'password' }) ?? '';
  const hasMinLength = watchedPassword.length >= 8;
  const hasLetterAndDigit = /[A-Za-z]/.test(watchedPassword) && /\d/.test(watchedPassword);

  const onSubmit = async (values: RegisterFormInput) => {
    setServerError(null);
    try {
      const normalizedPhone = values.phone?.trim() ? values.phone.trim() : null;
      await registerAccount({
        fullName: values.fullName,
        email: values.email,
        phone: normalizedPhone,
        password: values.password,
        confirmPassword: values.confirmPassword,
        preferredLocale: values.preferredLocale ?? 'en',
      });
      navigate(destination, { replace: true });
    } catch (error: unknown) {
      if (error instanceof ApiClientError) {
        if (error.code === 'EMAIL_ALREADY_REGISTERED') {
          setError('email', { type: 'server', message: error.message });
        }
        setServerError(error.message);
        return;
      }
      setServerError('Unable to create account right now. Please try again shortly.');
    }
  };

  return (
    <Section spacing="md" className="min-h-[calc(100dvh-14rem)]">
      <Container>
        <div className="mx-auto grid max-w-5xl items-stretch gap-8 lg:grid-cols-12">
          <FadeIn className="hidden lg:col-span-5 lg:flex">
            <Card className="flex w-full flex-col justify-between border-border-dark bg-dark-tech p-8 text-ink-inverse shadow-elevated">
              <div className="space-y-5">
                <Badge variant="dark" className="border-accent-cyan/40 text-accent-cyan-bright">
                  Create Account
                </Badge>
                <h1 className="font-display text-3xl leading-tight font-bold tracking-tight text-ink-inverse">
                  Design it. Wear it. Earn from it.
                </h1>
                <p className="text-sm leading-relaxed text-ink-silver">
                  Start customizing premium T-shirts and polos, manage saved delivery details across
                  Bangladesh, and unlock creator tools as you grow.
                </p>
              </div>

              <ul className="space-y-3 border-t border-border-dark pt-6 text-xs text-ink-silver">
                <li className="flex items-start gap-2.5">
                  <Sparkles
                    className="mt-0.5 size-4 shrink-0 text-accent-cyan-bright"
                    aria-hidden="true"
                  />
                  <span>Customer role provisioned automatically with instant active session.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Sparkles
                    className="mt-0.5 size-4 shrink-0 text-accent-cyan-bright"
                    aria-hidden="true"
                  />
                  <span>
                    Passkeys/Argon2id credential protection — passwords are never stored raw.
                  </span>
                </li>
              </ul>
            </Card>
          </FadeIn>

          <FadeIn delay={0.05} className="lg:col-span-7">
            <Card className="mx-auto max-w-xl p-6 sm:p-8 lg:max-w-none">
              <div className="space-y-2 border-b border-border pb-5">
                <Badge variant="accent">New Customer Account</Badge>
                <h2 className="font-display text-2xl font-bold tracking-tight text-ink sm:text-3xl">
                  Join YOUR CHOICE
                </h2>
                <p className="text-sm text-ink-muted">
                  Create your account in under a minute to save designs and manage orders.
                </p>
              </div>

              {serverError ? (
                <div
                  role="alert"
                  className="mt-5 flex items-start gap-2.5 rounded-xl border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger"
                >
                  <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                  <span>{serverError}</span>
                </div>
              ) : null}

              <form onSubmit={handleSubmit(onSubmit)} noValidate className="mt-6 space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField
                    id="register-full-name"
                    label="Full name"
                    required
                    error={errors.fullName?.message}
                  >
                    <Input
                      id="register-full-name"
                      autoComplete="name"
                      placeholder="Arafat Hossain"
                      invalid={Boolean(errors.fullName)}
                      aria-describedby={errors.fullName ? 'register-full-name-error' : undefined}
                      {...register('fullName')}
                    />
                  </FormField>

                  <FormField
                    id="register-phone"
                    label="Phone (optional)"
                    error={errors.phone?.message}
                    hint="Bangladesh mobile or +880 format"
                  >
                    <Input
                      id="register-phone"
                      type="tel"
                      autoComplete="tel"
                      placeholder="+8801712345678"
                      invalid={Boolean(errors.phone)}
                      aria-describedby={
                        errors.phone ? 'register-phone-error' : 'register-phone-hint'
                      }
                      {...register('phone')}
                    />
                  </FormField>
                </div>

                <FormField
                  id="register-email"
                  label="Email address"
                  required
                  error={errors.email?.message}
                >
                  <Input
                    id="register-email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@allyourchoice.com"
                    invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'register-email-error' : undefined}
                    {...register('email')}
                  />
                </FormField>

                <FormField
                  id="register-password"
                  label="Password"
                  required
                  error={errors.password?.message}
                >
                  <PasswordInput
                    id="register-password"
                    autoComplete="new-password"
                    placeholder="At least 8 characters"
                    invalid={Boolean(errors.password)}
                    aria-describedby={
                      errors.password ? 'register-password-error' : 'register-password-rules'
                    }
                    {...register('password')}
                  />
                </FormField>

                <div
                  id="register-password-rules"
                  className="grid gap-1.5 rounded-xl border border-border bg-surface-muted/70 px-3.5 py-2.5 text-xs sm:grid-cols-2"
                >
                  <span
                    className={
                      hasMinLength
                        ? 'inline-flex items-center gap-1.5 font-medium text-success'
                        : 'inline-flex items-center gap-1.5 text-ink-muted'
                    }
                  >
                    <CheckCircle2 className="size-3.5 shrink-0" aria-hidden="true" />
                    8+ characters minimum ({hasMinLength ? 'Met' : 'Required'})
                  </span>
                  <span
                    className={
                      hasLetterAndDigit
                        ? 'inline-flex items-center gap-1.5 font-medium text-success'
                        : 'inline-flex items-center gap-1.5 text-ink-muted'
                    }
                  >
                    <CheckCircle2 className="size-3.5 shrink-0" aria-hidden="true" />
                    Letter &amp; number ({hasLetterAndDigit ? 'Met' : 'Required'})
                  </span>
                </div>

                <FormField
                  id="register-confirm-password"
                  label="Confirm password"
                  required
                  error={errors.confirmPassword?.message}
                >
                  <PasswordInput
                    id="register-confirm-password"
                    autoComplete="new-password"
                    placeholder="Re-enter your password"
                    invalid={Boolean(errors.confirmPassword)}
                    aria-describedby={
                      errors.confirmPassword ? 'register-confirm-password-error' : undefined
                    }
                    {...register('confirmPassword')}
                  />
                </FormField>

                <Button type="submit" size="lg" className="mt-2 w-full" disabled={isSubmitting}>
                  {isSubmitting ? 'Creating account...' : 'Create Account'}
                  <ArrowRight className="size-4" aria-hidden="true" />
                </Button>
              </form>

              <p className="mt-6 border-t border-border pt-5 text-center text-sm text-ink-muted">
                Already registered?{' '}
                <Link
                  to={loginHref}
                  className="font-semibold text-accent-ink underline-offset-4 hover:underline"
                >
                  Sign in instead
                </Link>
              </p>
            </Card>
          </FadeIn>
        </div>
      </Container>
    </Section>
  );
}
