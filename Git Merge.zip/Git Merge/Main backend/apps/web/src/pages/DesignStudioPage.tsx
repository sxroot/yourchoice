import {
  type DesignAssetDTO,
  type DesignPrintExportDTO,
  type ProductDetailDTO,
  type ProductVariantDTO,
  type StudioGraphicPackItem,
  type StudioShapeKind,
} from '@your-choice/shared-types';
import { validateDesignDocumentForPrint } from '@your-choice/validation';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Badge,
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@your-choice/ui';
import {
  ArrowLeft,
  Box,
  CheckCircle2,
  Code2,
  Download,
  Loader2,
  Pencil,
  Redo2,
  RotateCcw,
  Save,
  ShoppingBag,
  Undo2,
} from 'lucide-react';
import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import type { Canvas } from 'fabric';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';
import { useAuth } from '@/features/auth/auth-context';
import { fetchPublicProductBySlug, fetchPublicProducts } from '@/features/catalog/catalog.api';
import { CART_QUERY_KEY, useCart } from '@/features/commerce/cart-context';
import { ApiClientError } from '@/services/api-client';
import {
  addCustomDesignToCart,
  createDesign,
  getDesignDetail,
  listMyDesignAssets,
  resolveDesignAssetPreviewUrl,
  updateDesign,
  uploadDesignAsset,
} from '@/features/design-studio/design-studio.api';
import {
  alignObjectInCanvas,
  createCanonicalGraphicObject,
  createCanonicalImageObject,
  createCanonicalShapeObject,
  createCanonicalTextObject,
  createObjectId,
  groupActiveCanvasSelection,
  serializeFabricCanvasToObjects,
  ungroupSelectedCanvasObject,
} from '@/features/design-studio/fabric-adapter';
import {
  loadStudioDraft,
  persistStudioDraft,
  useStudioStore,
} from '@/features/design-studio/studio-store';
import { DesignJsonModal } from '@/features/design-studio/components/DesignJsonModal';
import { ImageCropModal } from '@/features/design-studio/components/ImageCropModal';
import { PrintExportModal } from '@/features/design-studio/components/PrintExportModal';
import { SavedDesignsPanel } from '@/features/design-studio/components/SavedDesignsPanel';
import { StudioCanvasStage } from '@/features/design-studio/components/StudioCanvasStage';
import { StudioInspectorPanel } from '@/features/design-studio/components/StudioInspectorPanel';
import {
  type StudioLeftTab,
  StudioToolPanels,
} from '@/features/design-studio/components/StudioToolPanels';

const LazyStudioStage3D = lazy(() =>
  import('@/features/design-studio/three/StudioStage3D').then((m) => ({
    default: m.StudioStage3D,
  }))
);

export function DesignStudioPage() {
  const { designId: routeDesignId } = useParams<{ designId?: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { locale, t } = useAppLocale();
  const { isAuthenticated } = useAuth();
  const { openDrawer } = useCart();

  const canvasRef = useRef<Canvas | null>(null);
  const stageDimensionsRef = useRef<{ width: number; height: number }>({ width: 224, height: 270 });

  const [leftTab, setLeftTab] = useState<StudioLeftTab>('text');
  const [manualSelection, setManualSelection] = useState<{
    routeKey: string | null;
    slug: string;
    variantId: string;
  }>(() => ({
    routeKey: routeDesignId ?? null,
    slug: searchParams.get('product') ?? '',
    variantId: searchParams.get('variant') ?? '',
  }));
  const [jsonModalOpen, setJsonModalOpen] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [savedDesignsOpen, setSavedDesignsOpen] = useState(false);
  const [cropTargetId, setCropTargetId] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [statusError, setStatusError] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [sessionExports, setSessionExports] = useState<DesignPrintExportDTO[]>([]);
  const [dismissedDraftKey, setDismissedDraftKey] = useState<string | null>(null);

  const selectedSlug =
    manualSelection.routeKey === (routeDesignId ?? null) ? manualSelection.slug : '';
  const selectedVariantId =
    manualSelection.routeKey === (routeDesignId ?? null) ? manualSelection.variantId : '';

  const document = useStudioStore((s) => s.document);
  const designTitle = useStudioStore((s) => s.designTitle);
  const savedDesignId = useStudioStore((s) => s.savedDesignId);
  const savedVersionNumber = useStudioStore((s) => s.savedVersionNumber);
  const activeSurfaceKey = useStudioStore((s) => s.activeSurfaceKey);
  const selectedObjectIds = useStudioStore((s) => s.selectedObjectIds);
  const zoom = useStudioStore((s) => s.zoom);
  const showBackdrop = useStudioStore((s) => s.showBackdrop);
  const showSafeZone = useStudioStore((s) => s.showSafeZone);
  const showGrid = useStudioStore((s) => s.showGrid);
  const snapToGuides = useStudioStore((s) => s.snapToGuides);
  const isDirty = useStudioStore((s) => s.isDirty);
  const pastStates = useStudioStore((s) => s.pastStates);
  const futureStates = useStudioStore((s) => s.futureStates);
  const proportionNotice = useStudioStore((s) => s.lastProportionNotice);
  const cameraPreset = useStudioStore((s) => s.cameraPreset);
  const lightingPreset = useStudioStore((s) => s.lightingPreset);
  const autoRotate3d = useStudioStore((s) => s.autoRotate3d);
  const show3dPrintGuides = useStudioStore((s) => s.show3dPrintGuides);

  const initFromProduct = useStudioStore((s) => s.initFromProduct);
  const restoreDocumentFromDraft = useStudioStore((s) => s.restoreDocumentFromDraft);
  const switchProductOrVariant = useStudioStore((s) => s.switchProductOrVariant);
  const setPreferredMode = useStudioStore((s) => s.setPreferredMode);
  const setCameraPreset = useStudioStore((s) => s.setCameraPreset);
  const setLightingPreset = useStudioStore((s) => s.setLightingPreset);
  const toggleAutoRotate3d = useStudioStore((s) => s.toggleAutoRotate3d);
  const toggle3dPrintGuides = useStudioStore((s) => s.toggle3dPrintGuides);
  const setDesignTitle = useStudioStore((s) => s.setDesignTitle);
  const setActiveSurfaceKey = useStudioStore((s) => s.setActiveSurfaceKey);
  const setSelectedObjectIds = useStudioStore((s) => s.setSelectedObjectIds);
  const commitDocument = useStudioStore((s) => s.commitDocument);
  const mutateActiveSurfaceObjects = useStudioStore((s) => s.mutateActiveSurfaceObjects);
  const undo = useStudioStore((s) => s.undo);
  const redo = useStudioStore((s) => s.redo);
  const setZoom = useStudioStore((s) => s.setZoom);
  const toggleBackdrop = useStudioStore((s) => s.toggleBackdrop);
  const toggleSafeZone = useStudioStore((s) => s.toggleSafeZone);
  const toggleGrid = useStudioStore((s) => s.toggleGrid);
  const toggleSnapToGuides = useStudioStore((s) => s.toggleSnapToGuides);
  const markSaved = useStudioStore((s) => s.markSaved);
  const dismissProportionNotice = useStudioStore((s) => s.dismissProportionNotice);

  // Fetch customizable garments list
  const catalogQuery = useQuery({
    queryKey: ['studio-customizable-products'],
    queryFn: ({ signal }) => fetchPublicProducts({ customizable: true, pageSize: 20 }, signal),
    staleTime: 60_000,
  });

  const existingDesignQuery = useQuery({
    queryKey: ['studio-design-detail', routeDesignId],
    queryFn: ({ signal }) => getDesignDetail(routeDesignId!, signal),
    enabled: Boolean(routeDesignId) && isAuthenticated,
    retry: false,
  });

  // Resolve target slug cleanly from existing design or URL query or first customizable catalog item
  const effectiveSlug = useMemo(() => {
    if (selectedSlug) {
      return selectedSlug;
    }
    if (existingDesignQuery.data?.productSlug) {
      return existingDesignQuery.data.productSlug;
    }
    return catalogQuery.data?.products[0]?.slug ?? '';
  }, [selectedSlug, existingDesignQuery.data, catalogQuery.data]);

  const productDetailQuery = useQuery({
    queryKey: ['studio-product-detail', effectiveSlug],
    queryFn: ({ signal }) => fetchPublicProductBySlug(effectiveSlug, signal),
    enabled: Boolean(effectiveSlug),
    staleTime: 60_000,
  });

  const assetsQuery = useQuery({
    queryKey: ['studio-design-assets'],
    queryFn: ({ signal }) => listMyDesignAssets(signal),
    enabled: isAuthenticated,
    staleTime: 30_000,
  });

  const currentProduct: ProductDetailDTO | undefined = productDetailQuery.data;

  const currentVariant: ProductVariantDTO | undefined = useMemo(() => {
    if (!currentProduct) {
      return undefined;
    }
    const targetVarId =
      selectedVariantId ||
      document?.productVariantId ||
      existingDesignQuery.data?.productVariantId ||
      '';
    return (
      currentProduct.variants.find((v) => v.isActive && v.id === targetVarId) ??
      currentProduct.variants.find((v) => v.isActive && v.inStock) ??
      currentProduct.variants.find((v) => v.isActive) ??
      currentProduct.variants[0]
    );
  }, [currentProduct, selectedVariantId, document?.productVariantId, existingDesignQuery.data]);

  // Hydrate or switch store when initial product/design arrives
  const initializedKeyRef = useRef<string | null>(null);
  useEffect(() => {
    if (!currentProduct || !currentVariant) {
      return;
    }
    if (routeDesignId && !existingDesignQuery.data) {
      return;
    }

    const modeParam = searchParams.get('mode');
    const requestedMode = modeParam === '3d' ? '3d' : modeParam === '2d' ? '2d' : undefined;

    const hydrationKey = routeDesignId ? `design:${routeDesignId}` : `product:${currentProduct.id}`;
    if (initializedKeyRef.current !== hydrationKey) {
      initializedKeyRef.current = hydrationKey;
      const existing = existingDesignQuery.data ?? null;
      initFromProduct(
        currentProduct,
        currentVariant,
        existing,
        `${pickLocalizedText(locale, currentProduct.nameEn, currentProduct.nameBn)} Custom`,
        requestedMode
      );
    } else if (document && document.productId !== currentProduct.id) {
      switchProductOrVariant(currentProduct, currentVariant);
    }
  }, [
    currentProduct,
    currentVariant,
    routeDesignId,
    existingDesignQuery.data,
    document,
    initFromProduct,
    switchProductOrVariant,
    locale,
    searchParams,
  ]);

  const exportsHistory = useMemo(() => {
    const serverExports = existingDesignQuery.data?.exports ?? [];
    const seen = new Set(sessionExports.map((e) => e.id));
    return [...sessionExports, ...serverExports.filter((e) => !seen.has(e.id))];
  }, [sessionExports, existingDesignQuery.data?.exports]);

  const currentDraftKey = currentProduct
    ? `${existingDesignQuery.data?.id ?? 'new'}:${currentProduct.id}`
    : null;

  const pendingDraft = useMemo(() => {
    if (!currentProduct || !currentDraftKey || dismissedDraftKey === currentDraftKey || isDirty) {
      return null;
    }
    const existing = existingDesignQuery.data ?? null;
    const draft = loadStudioDraft(existing?.id ?? null, currentProduct.id);
    if (!draft) {
      return null;
    }
    const baselineUpdatedAt = existing ? new Date(existing.updatedAt).getTime() : 0;
    const draftTime = new Date(draft.savedAt).getTime();
    return draftTime > baselineUpdatedAt ? draft : null;
  }, [currentProduct, currentDraftKey, dismissedDraftKey, isDirty, existingDesignQuery.data]);

  // Debounced localStorage draft autosave so customer work survives accidental reloads
  useEffect(() => {
    if (!document || !isDirty) {
      return;
    }
    const timer = window.setTimeout(() => {
      persistStudioDraft(savedDesignId, document.productId, designTitle, document);
    }, 650);
    return () => window.clearTimeout(timer);
  }, [document, designTitle, savedDesignId, isDirty]);

  const activeSurface = document?.surfaces[activeSurfaceKey];
  const activePrintArea = useMemo(() => {
    if (!currentProduct) {
      return undefined;
    }
    return (
      currentProduct.printAreas.find((pa) => pa.isActive && pa.surfaceKey === activeSurfaceKey) ??
      currentProduct.printAreas.find((pa) => pa.isActive)
    );
  }, [currentProduct, activeSurfaceKey]);

  const knownAssetIds = useMemo(() => {
    if (!assetsQuery.data) {
      return null;
    }
    return new Set(assetsQuery.data.map((a) => a.id));
  }, [assetsQuery.data]);

  const validationReport = useMemo(() => {
    if (!document || !currentProduct) {
      return null;
    }
    return validateDesignDocumentForPrint(document, currentProduct.printAreas, knownAssetIds);
  }, [document, currentProduct, knownAssetIds]);

  const activeObjects = useMemo(() => activeSurface?.objects ?? [], [activeSurface]);

  const selectedObjects = useMemo(
    () => activeObjects.filter((obj) => selectedObjectIds.includes(obj.id)),
    [activeObjects, selectedObjectIds]
  );

  // Server customization fee + unit garment total
  const estimatedTotals = useMemo(() => {
    if (!currentProduct || !currentVariant || !validationReport) {
      return null;
    }
    const base = Number.parseFloat(currentVariant.effectivePrice);
    const fee = currentProduct.printAreas
      .filter((pa) => validationReport.activePrintSurfaces.includes(pa.surfaceKey))
      .reduce((sum, pa) => sum + Number.parseFloat(pa.surchargeAmount), 0);
    return {
      garmentPrice: base.toFixed(2),
      customizationFee: fee.toFixed(2),
      unitTotal: (base + fee).toFixed(2),
    };
  }, [currentProduct, currentVariant, validationReport]);

  const handleSaveDesign = useCallback(async (): Promise<string | null> => {
    if (!document) {
      return null;
    }
    setStatusError(null);
    setStatusMessage(null);

    if (!isAuthenticated) {
      persistStudioDraft(savedDesignId, document.productId, designTitle, document);
      navigate('/login?next=/studio');
      return null;
    }

    const safeTitle = designTitle.trim().length >= 2 ? designTitle.trim() : 'Custom Design';

    try {
      let saved;
      if (savedDesignId) {
        saved = await updateDesign(savedDesignId, {
          title: safeTitle,
          document,
          createVersionSnapshot: true,
        });
      } else {
        saved = await createDesign({
          title: safeTitle,
          document,
        });
      }

      markSaved(saved);
      setSessionExports(saved.exports);
      void queryClient.invalidateQueries({ queryKey: ['my-designs'] });
      setStatusMessage(`${t('studio.savedSuccess')} (v${saved.currentVersionNumber})`);

      if (!routeDesignId) {
        navigate(`/studio/${saved.id}`, { replace: true });
      }
      return saved.id;
    } catch (err) {
      setStatusError(err instanceof ApiClientError ? err.message : t('studio.saveFailed'));
      return null;
    }
  }, [
    document,
    isAuthenticated,
    savedDesignId,
    designTitle,
    navigate,
    markSaved,
    queryClient,
    t,
    routeDesignId,
  ]);

  const saveMutation = useMutation({
    mutationFn: () => handleSaveDesign(),
  });

  const uploadMutation = useMutation({
    mutationFn: (file: File) => uploadDesignAsset(file),
    onSuccess: (asset) => {
      setUploadError(null);
      void queryClient.invalidateQueries({ queryKey: ['studio-design-assets'] });
      if (activePrintArea) {
        const newImg = createCanonicalImageObject(
          asset,
          activePrintArea.physicalWidthMm,
          activePrintArea.physicalHeightMm
        );
        mutateActiveSurfaceObjects((prev) => [...prev, newImg]);
        setSelectedObjectIds([newImg.id]);
      }
    },
    onError: (err) => {
      setUploadError(err instanceof ApiClientError ? err.message : t('studio.uploadFailed'));
    },
  });

  const addToCartMutation = useMutation({
    mutationFn: async () => {
      if (!currentVariant) {
        throw new Error('Select a garment variant first');
      }
      let targetId = savedDesignId;
      if (!targetId || isDirty) {
        targetId = await handleSaveDesign();
      }
      if (!targetId) {
        throw new Error(t('studio.saveFailed'));
      }
      return addCustomDesignToCart(targetId, {
        variantId: currentVariant.id,
        quantity: 1,
      });
    },
    onSuccess: (updatedCart) => {
      setStatusError(null);
      queryClient.setQueryData(CART_QUERY_KEY, updatedCart);
      void queryClient.invalidateQueries({ queryKey: ['my-designs'] });
      openDrawer();
    },
    onError: (err) => {
      setStatusError(err instanceof ApiClientError ? err.message : t('studio.addToCartFailed'));
    },
  });

  // Keyboard shortcuts (Delete/Backspace, Undo/Redo, Ctrl+S)
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const inInput =
        target?.tagName === 'INPUT' ||
        target?.tagName === 'TEXTAREA' ||
        target?.tagName === 'SELECT' ||
        target?.isContentEditable;

      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 's') {
        event.preventDefault();
        if (isAuthenticated && !saveMutation.isPending) {
          void saveMutation.mutateAsync();
        }
        return;
      }

      if (inInput) {
        return;
      }

      const activeCanvasObj = canvasRef.current?.getActiveObject() as
        { isEditing?: boolean } | undefined;
      if (activeCanvasObj?.isEditing) {
        return;
      }

      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'z') {
        event.preventDefault();
        if (event.shiftKey) {
          redo();
        } else {
          undo();
        }
        return;
      }

      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'y') {
        event.preventDefault();
        redo();
        return;
      }

      if ((event.key === 'Delete' || event.key === 'Backspace') && selectedObjectIds.length > 0) {
        event.preventDefault();
        mutateActiveSurfaceObjects((prev) =>
          prev.filter((obj) => !selectedObjectIds.includes(obj.id) || obj.locked)
        );
        setSelectedObjectIds([]);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isAuthenticated,
    saveMutation,
    selectedObjectIds,
    mutateActiveSurfaceObjects,
    setSelectedObjectIds,
    undo,
    redo,
  ]);

  const handleAddText = (fontFamily: string, sampleText?: string) => {
    const obj = createCanonicalTextObject(activeObjects.length, fontFamily, sampleText);
    mutateActiveSurfaceObjects((prev) => [...prev, obj]);
    setSelectedObjectIds([obj.id]);
    setStatusMessage(null);
  };

  const handleAddShape = (kind: StudioShapeKind) => {
    const obj = createCanonicalShapeObject(kind, activeObjects.length);
    mutateActiveSurfaceObjects((prev) => [...prev, obj]);
    setSelectedObjectIds([obj.id]);
    setStatusMessage(null);
  };

  const handleAddGraphic = (item: StudioGraphicPackItem) => {
    const obj = createCanonicalGraphicObject(item, activeObjects.length);
    mutateActiveSurfaceObjects((prev) => [...prev, obj]);
    setSelectedObjectIds([obj.id]);
    setStatusMessage(null);
  };

  const handleInsertAsset = (asset: DesignAssetDTO) => {
    if (!activePrintArea) {
      return;
    }
    const obj = createCanonicalImageObject(
      asset,
      activePrintArea.physicalWidthMm,
      activePrintArea.physicalHeightMm
    );
    mutateActiveSurfaceObjects((prev) => [...prev, obj]);
    setSelectedObjectIds([obj.id]);
    setStatusMessage(null);
  };

  const syncAfterDirectCanvasOp = () => {
    const canvas = canvasRef.current;
    if (!canvas) {
      return;
    }
    const nextObjects = serializeFabricCanvasToObjects(
      canvas,
      stageDimensionsRef.current.width,
      stageDimensionsRef.current.height
    );
    mutateActiveSurfaceObjects(() => nextObjects);
  };

  const handleAlign = (mode: 'left' | 'center-x' | 'right' | 'top' | 'center-y' | 'bottom') => {
    if (!activePrintArea) {
      return;
    }
    const insetX = activePrintArea.safeInsetMm / Math.max(1, activePrintArea.physicalWidthMm);
    const insetY = activePrintArea.safeInsetMm / Math.max(1, activePrintArea.physicalHeightMm);
    const canvas = canvasRef.current;

    if (!canvas) {
      if (selectedObjectIds.length === 0) {
        return;
      }
      mutateActiveSurfaceObjects((prev) =>
        prev.map((item) => {
          if (!selectedObjectIds.includes(item.id) || item.locked) {
            return item;
          }
          switch (mode) {
            case 'left':
              return { ...item, x: Number(insetX.toFixed(4)) };
            case 'center-x':
              return { ...item, x: Number(((1 - item.width) / 2).toFixed(4)) };
            case 'right':
              return { ...item, x: Number(Math.max(0, 1 - insetX - item.width).toFixed(4)) };
            case 'top':
              return { ...item, y: Number(insetY.toFixed(4)) };
            case 'center-y':
              return { ...item, y: Number(((1 - item.height) / 2).toFixed(4)) };
            case 'bottom':
              return { ...item, y: Number(Math.max(0, 1 - insetY - item.height).toFixed(4)) };
          }
        })
      );
      return;
    }

    if (
      alignObjectInCanvas(
        canvas,
        mode,
        stageDimensionsRef.current.width,
        stageDimensionsRef.current.height,
        insetX,
        insetY
      )
    ) {
      syncAfterDirectCanvasOp();
    }
  };

  const handleGroupSelected = () => {
    const canvas = canvasRef.current;
    if (canvas && groupActiveCanvasSelection(canvas, t('studio.groupLayerName'))) {
      syncAfterDirectCanvasOp();
    }
  };

  const handleUngroupSelected = () => {
    const canvas = canvasRef.current;
    if (canvas && ungroupSelectedCanvasObject(canvas)) {
      syncAfterDirectCanvasOp();
    }
  };

  const handleDuplicateByIds = (ids: string[]) => {
    mutateActiveSurfaceObjects((prev) => {
      const copies = prev
        .filter((item) => ids.includes(item.id))
        .map((item) => ({
          ...structuredClone(item),
          id: createObjectId(item.type.slice(0, 3)),
          name: `${item.name} Copy`,
          x: Math.min(0.85, Number((item.x + 0.04).toFixed(4))),
          y: Math.min(0.85, Number((item.y + 0.04).toFixed(4))),
        }));
      return [...prev, ...copies];
    });
  };

  const handleDeleteByIds = (ids: string[]) => {
    mutateActiveSurfaceObjects((prev) =>
      prev.filter((item) => !ids.includes(item.id) || item.locked)
    );
    setSelectedObjectIds([]);
  };

  const handleMoveLayer = (objectId: string, direction: 'up' | 'down') => {
    mutateActiveSurfaceObjects((prev) => {
      const idx = prev.findIndex((item) => item.id === objectId);
      if (idx < 0) {
        return prev;
      }
      const swapIdx = direction === 'up' ? idx + 1 : idx - 1;
      if (swapIdx < 0 || swapIdx >= prev.length) {
        return prev;
      }
      const next = [...prev];
      const current = next[idx]!;
      next[idx] = next[swapIdx]!;
      next[swapIdx] = current;
      return next;
    });
  };

  const handleSelectLayerOnCanvas = (objectId: string) => {
    setSelectedObjectIds([objectId]);
    const canvas = canvasRef.current;
    if (!canvas) {
      return;
    }
    const target = canvas.getObjects().find((obj) => {
      const isMatch = activeSurface?.objects.some((item) => item.id === objectId && !item.locked);
      if (!isMatch) {
        return false;
      }
      const itemIndex = activeSurface?.objects.findIndex((item) => item.id === objectId) ?? -1;
      return canvas.getObjects()[itemIndex] === obj;
    });
    if (target && target.selectable !== false) {
      canvas.setActiveObject(target);
      canvas.requestRenderAll();
    }
  };

  const cropTargetObject = useMemo(
    () => activeObjects.find((item) => item.id === cropTargetId && item.type === 'image') ?? null,
    [activeObjects, cropTargetId]
  );

  const activeMode = document?.preferredMode ?? '2d';

  const handleModeSwitch = useCallback(
    (nextMode: '2d' | '3d') => {
      setPreferredMode(nextMode);
      const nextParams = new URLSearchParams(searchParams);
      nextParams.set('mode', nextMode);
      setSearchParams(nextParams, { replace: true });
    },
    [setPreferredMode, searchParams, setSearchParams]
  );

  if (
    catalogQuery.isLoading ||
    productDetailQuery.isLoading ||
    !currentProduct ||
    !currentVariant ||
    !document ||
    !activePrintArea ||
    !activeSurface
  ) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-7xl items-center justify-center px-4">
        <div className="flex items-center gap-3 rounded-2xl border border-border bg-surface px-6 py-4 text-sm font-medium text-ink-muted">
          <Loader2 className="h-5 w-5 animate-spin text-accent" />
          <span>{t('studio.loadingStudio')}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto flex w-full max-w-[1600px] flex-col gap-3 px-3 py-4 sm:px-6 overflow-x-clip">
      {/* Studio Top Bar */}
      <header className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-surface px-3.5 py-2.5">
        <div className="flex min-w-0 flex-1 items-center gap-2.5">
          <Button asChild size="sm" variant="outline">
            <Link to={`/product/${currentProduct.slug}`}>
              <ArrowLeft className="mr-1.5 h-3.5 w-3.5" />
              {t('studio.backToProduct')}
            </Link>
          </Button>
          <input
            aria-label={t('studio.designTitleLabel')}
            type="text"
            value={designTitle}
            maxLength={140}
            onChange={(e) => setDesignTitle(e.target.value)}
            className="min-w-40 max-w-xs flex-1 rounded-lg border border-border bg-canvas px-3 py-1.5 text-base sm:text-sm font-semibold text-ink focus:outline-none focus:ring-2 focus:ring-accent"
          />
          {savedDesignId ? (
            <Badge variant="neutral" className="hidden sm:inline-flex font-mono text-[11px]">
              v{savedVersionNumber}
            </Badge>
          ) : null}
          {isDirty ? (
            <Badge variant="neutral" className="text-[11px] text-amber-600 dark:text-amber-400">
              {t('studio.unsavedDraft')}
            </Badge>
          ) : savedDesignId ? (
            <Badge
              variant="neutral"
              className="gap-1 text-[11px] text-emerald-600 dark:text-emerald-400"
            >
              <CheckCircle2 className="h-3 w-3" />
              {t('studio.savedLabel')}
            </Badge>
          ) : null}
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {/* Mode A (2D Editor) vs Mode B (3D Studio) Switcher */}
          <div
            role="group"
            aria-label={t('studio3d.modeSwitcherLabel')}
            className="inline-flex items-center rounded-xl border border-border bg-canvas p-0.5"
          >
            <button
              type="button"
              data-testid="studio-mode-2d"
              aria-pressed={activeMode === '2d'}
              onClick={() => handleModeSwitch('2d')}
              className={`inline-flex min-h-9 items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-semibold transition focus:outline-none focus:ring-2 focus:ring-accent ${
                activeMode === '2d'
                  ? 'bg-accent text-white shadow-sm'
                  : 'text-ink-muted hover:text-ink'
              }`}
            >
              <Pencil className="h-3.5 w-3.5" />
              <span>{t('studio3d.mode2d')}</span>
            </button>
            <button
              type="button"
              data-testid="studio-mode-3d"
              aria-pressed={activeMode === '3d'}
              onClick={() => handleModeSwitch('3d')}
              className={`inline-flex min-h-9 items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-semibold transition focus:outline-none focus:ring-2 focus:ring-accent ${
                activeMode === '3d'
                  ? 'bg-accent text-white shadow-sm'
                  : 'text-ink-muted hover:text-ink'
              }`}
            >
              <Box className="h-3.5 w-3.5" />
              <span>{t('studio3d.mode3d')}</span>
            </button>
          </div>

          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={pastStates.length === 0}
            aria-label={t('studio.undo')}
            onClick={undo}
          >
            <Undo2 className="h-3.5 w-3.5 sm:mr-1" />
            <span className="hidden sm:inline">{t('studio.undo')}</span>
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={futureStates.length === 0}
            aria-label={t('studio.redo')}
            onClick={redo}
          >
            <Redo2 className="h-3.5 w-3.5 sm:mr-1" />
            <span className="hidden sm:inline">{t('studio.redo')}</span>
          </Button>
          <Button type="button" size="sm" variant="outline" onClick={() => setJsonModalOpen(true)}>
            <Code2 className="h-3.5 w-3.5 sm:mr-1" />
            <span className="hidden sm:inline">JSON</span>
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={saveMutation.isPending}
            onClick={() => void saveMutation.mutateAsync()}
          >
            {saveMutation.isPending ? (
              <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
            ) : (
              <Save className="mr-1.5 h-3.5 w-3.5" />
            )}
            {t('studio.saveDesign')}
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={!isAuthenticated}
            onClick={() => setExportModalOpen(true)}
          >
            <Download className="mr-1.5 h-3.5 w-3.5" />
            {t('studio.export300Dpi')}
          </Button>
          <Button
            type="button"
            size="sm"
            disabled={!validationReport?.isValidForPrint || addToCartMutation.isPending}
            onClick={() => void addToCartMutation.mutateAsync()}
          >
            {addToCartMutation.isPending ? (
              <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
            ) : (
              <ShoppingBag className="mr-1.5 h-3.5 w-3.5" />
            )}
            {t('studio.addCustomToCart')}
            {estimatedTotals ? ` · ${formatBdtPrice(estimatedTotals.unitTotal)}` : ''}
          </Button>
        </div>
      </header>

      {/* Draft Recovery & Status Banners */}
      {pendingDraft ? (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-accent/40 bg-accent/10 px-4 py-2.5 text-xs">
          <span>
            {t('studio.draftRecoveryPrompt')} ({new Date(pendingDraft.savedAt).toLocaleTimeString()}
            )
          </span>
          <div className="flex items-center gap-2">
            <Button
              type="button"
              size="sm"
              onClick={() => {
                restoreDocumentFromDraft(pendingDraft.title, pendingDraft.document);
                if (currentDraftKey) {
                  setDismissedDraftKey(currentDraftKey);
                }
              }}
            >
              <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
              {t('studio.restoreDraft')}
            </Button>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => {
                if (currentDraftKey) {
                  setDismissedDraftKey(currentDraftKey);
                }
              }}
            >
              {t('common.dismiss')}
            </Button>
          </div>
        </div>
      ) : null}

      {statusMessage ? (
        <div
          role="status"
          className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs font-medium text-emerald-700 dark:text-emerald-300"
        >
          {statusMessage}
        </div>
      ) : null}

      {statusError ? (
        <div
          role="alert"
          className="rounded-xl border border-danger/45 bg-danger/10 px-4 py-2 text-xs font-medium text-danger"
        >
          {statusError}
        </div>
      ) : null}

      {/* 3-Column Studio Workbench */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-[310px_minmax(0,1fr)_310px] lg:min-h-[680px]">
        <StudioToolPanels
          activeTab={leftTab}
          onTabChange={setLeftTab}
          isAuthenticated={isAuthenticated}
          products={catalogQuery.data?.products ?? []}
          currentProduct={currentProduct}
          currentVariant={currentVariant}
          onSelectProductSlug={(slug) => {
            setManualSelection({
              routeKey: routeDesignId ?? null,
              slug,
              variantId: '',
            });
          }}
          onSelectVariant={(variant) => {
            setManualSelection((prev) => ({
              routeKey: routeDesignId ?? null,
              slug: prev.routeKey === (routeDesignId ?? null) ? prev.slug : effectiveSlug,
              variantId: variant.id,
            }));
            switchProductOrVariant(currentProduct, variant);
          }}
          proportionNotice={proportionNotice}
          onDismissProportionNotice={dismissProportionNotice}
          onAddText={handleAddText}
          onAddShape={handleAddShape}
          onAddGraphic={handleAddGraphic}
          assets={assetsQuery.data ?? []}
          isLoadingAssets={assetsQuery.isLoading}
          isUploadingAsset={uploadMutation.isPending}
          uploadError={uploadError}
          onUploadFile={(file) => uploadMutation.mutate(file)}
          onInsertAsset={handleInsertAsset}
          objects={activeObjects}
          selectedObjectIds={selectedObjectIds}
          onSelectLayer={handleSelectLayerOnCanvas}
          onMoveLayer={handleMoveLayer}
          onToggleLayerVisibility={(objectId) =>
            mutateActiveSurfaceObjects((prev) =>
              prev.map((item) =>
                item.id === objectId ? { ...item, visible: !item.visible } : item
              )
            )
          }
          onToggleLayerLock={(objectId) =>
            mutateActiveSurfaceObjects((prev) =>
              prev.map((item) => (item.id === objectId ? { ...item, locked: !item.locked } : item))
            )
          }
          onDuplicateLayer={(objectId) => handleDuplicateByIds([objectId])}
          onDeleteLayer={(objectId) => handleDeleteByIds([objectId])}
          validation={validationReport}
          onOpenSavedDesigns={() => setSavedDesignsOpen(true)}
        />

        {activeMode === '3d' ? (
          <Suspense
            fallback={
              <section className="flex min-h-[460px] flex-col items-center justify-center gap-2 rounded-2xl border border-border bg-surface p-6 text-xs font-medium text-ink-muted">
                <Loader2 className="h-6 w-6 animate-spin text-accent" />
                <span>{t('studio3d.loadingModel')}</span>
              </section>
            }
          >
            <LazyStudioStage3D
              product={currentProduct}
              variant={currentVariant}
              activePrintArea={activePrintArea}
              allSurfaces={document.surfaces}
              activeSurfaceKey={activeSurfaceKey}
              cameraPreset={cameraPreset}
              lightingPreset={lightingPreset}
              autoRotate={autoRotate3d}
              showPrintGuides={show3dPrintGuides}
              onSelectSurface={setActiveSurfaceKey}
              onSelectCameraPreset={setCameraPreset}
              onChangeLightingPreset={setLightingPreset}
              onToggleAutoRotate={toggleAutoRotate3d}
              onTogglePrintGuides={toggle3dPrintGuides}
              onSwitchTo2DEditor={() => handleModeSwitch('2d')}
            />
          </Suspense>
        ) : (
          <StudioCanvasStage
            product={currentProduct}
            variant={currentVariant}
            activePrintArea={activePrintArea}
            surface={activeSurface}
            allSurfaces={document.surfaces}
            activeSurfaceKey={activeSurfaceKey}
            zoom={zoom}
            showBackdrop={showBackdrop}
            showSafeZone={showSafeZone}
            showGrid={showGrid}
            snapToGuides={snapToGuides}
            canvasRef={canvasRef}
            stageDimensionsRef={stageDimensionsRef}
            onSelectSurface={setActiveSurfaceKey}
            onZoomChange={setZoom}
            onToggleBackdrop={toggleBackdrop}
            onToggleSafeZone={toggleSafeZone}
            onToggleGrid={toggleGrid}
            onToggleSnapGuides={toggleSnapToGuides}
            onSelectionChange={setSelectedObjectIds}
            onCommitObjects={(nextObjects) => mutateActiveSurfaceObjects(() => nextObjects)}
          />
        )}

        <StudioInspectorPanel
          activePrintArea={activePrintArea}
          selectedObjects={selectedObjects}
          multiSelectionCount={selectedObjectIds.length}
          onAlign={handleAlign}
          onGroupSelected={handleGroupSelected}
          onUngroupSelected={handleUngroupSelected}
          onUpdateSelectedObject={(updater) => {
            const targetId = selectedObjectIds[0];
            if (!targetId) {
              return;
            }
            mutateActiveSurfaceObjects((prev) =>
              prev.map((item) => (item.id === targetId ? updater(item) : item))
            );
          }}
          onDuplicateSelected={() => handleDuplicateByIds(selectedObjectIds)}
          onDeleteSelected={() => handleDeleteByIds(selectedObjectIds)}
          onOpenCropImage={() => {
            if (selectedObjects[0]?.type === 'image') {
              setCropTargetId(selectedObjects[0].id);
            }
          }}
        />
      </div>

      {/* Studio Modals */}
      <DesignJsonModal
        open={jsonModalOpen}
        onOpenChange={setJsonModalOpen}
        document={document}
        onApplyDocument={(nextDoc) => commitDocument(nextDoc)}
      />

      <PrintExportModal
        open={exportModalOpen}
        onOpenChange={setExportModalOpen}
        designId={savedDesignId}
        isDirty={isDirty}
        activeSurfaces={currentProduct.printAreas.filter((pa) => pa.isActive)}
        validation={validationReport}
        exportsHistory={exportsHistory}
        onSaveBeforeExport={handleSaveDesign}
        onExportSuccess={(created) =>
          setSessionExports((prev) => [created, ...prev.filter((p) => p.id !== created.id)])
        }
      />

      {cropTargetObject && cropTargetObject.type === 'image' ? (
        <ImageCropModal
          open={Boolean(cropTargetId)}
          onOpenChange={(open) => {
            if (!open) {
              setCropTargetId(null);
            }
          }}
          imageUrl={resolveDesignAssetPreviewUrl(cropTargetObject.assetId)}
          initialCrop={cropTargetObject.cropRect}
          onApplyCrop={(cropRect) => {
            mutateActiveSurfaceObjects((prev) =>
              prev.map((item) =>
                item.id === cropTargetObject.id && item.type === 'image'
                  ? { ...item, cropRect }
                  : item
              )
            );
          }}
          onResetCrop={() => {
            mutateActiveSurfaceObjects((prev) =>
              prev.map((item) =>
                item.id === cropTargetObject.id && item.type === 'image'
                  ? { ...item, cropRect: null }
                  : item
              )
            );
          }}
        />
      ) : null}

      <Dialog open={savedDesignsOpen} onOpenChange={setSavedDesignsOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('studio.savedDesignsBtn')}</DialogTitle>
            <DialogDescription>{t('studio.savedDesignsModalSubtitle')}</DialogDescription>
          </DialogHeader>
          <div className="max-h-[65vh] overflow-y-auto pr-1">
            <SavedDesignsPanel
              compact
              onSelectDesign={(id) => {
                setSavedDesignsOpen(false);
                navigate(`/studio/${id}`);
              }}
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
