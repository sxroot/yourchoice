import { useQuery } from '@tanstack/react-query';
import { Badge, Card, Container, LoadingState, Section } from '@your-choice/ui';
import { Brush } from 'lucide-react';
import { fetchCreatorWorkspace } from '@/features/auth/auth.api';
import { useAuth } from '@/features/auth/auth-context';

export function CreatorWorkspacePage() {
  const { user } = useAuth();
  const workspaceQuery = useQuery({
    queryKey: ['creator', 'workspace'],
    queryFn: ({ signal }) => fetchCreatorWorkspace(signal),
    retry: false,
  });

  return (
    <Section spacing="md">
      <Container className="space-y-6">
        <div className="space-y-2">
          <Badge variant="accent">Creator RBAC Workspace</Badge>
          <h1 className="font-display text-2xl font-bold text-ink sm:text-3xl">Creator Hub</h1>
          <p className="text-sm text-ink-muted">
            Protected creator studio staging surface for verified creators and administrators.
          </p>
        </div>

        {workspaceQuery.isLoading ? (
          <LoadingState label="Loading creator workspace permissions..." />
        ) : workspaceQuery.error ? (
          <Card className="border-danger/30 bg-danger-soft p-6 text-sm text-danger">
            {workspaceQuery.error instanceof Error
              ? workspaceQuery.error.message
              : 'Unable to load creator workspace.'}
          </Card>
        ) : (
          <Card className="space-y-4 p-6">
            <div className="flex items-center gap-3">
              <div className="inline-flex size-10 items-center justify-center rounded-xl bg-accent-soft text-accent-royal">
                <Brush className="size-5" aria-hidden="true" />
              </div>
              <div>
                <h2 className="font-display text-lg font-semibold text-ink">
                  Design Studio Ready ({workspaceQuery.data?.studioStatus})
                </h2>
                <p className="text-xs text-ink-muted">
                  Signed in as {user?.fullName} ({workspaceQuery.data?.creatorId})
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {workspaceQuery.data?.capabilities.map((perm) => (
                <Badge key={perm} variant="neutral" className="font-mono text-[11px]">
                  {perm}
                </Badge>
              ))}
            </div>
          </Card>
        )}
      </Container>
    </Section>
  );
}
