import { useQuery } from '@tanstack/react-query';
import { BANGLADESH_DIVISIONS, type BangladeshDivision } from '@your-choice/shared-types';
import {
  Badge,
  Button,
  Card,
  Container,
  EmptyState,
  LoadingState,
  Section,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@your-choice/ui';
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, Truck } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '@/features/commerce/cart-context';
import { fetchShippingQuote } from '@/features/commerce/commerce.api';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';

export function CartPage() {
  const { locale, t } = useAppLocale();
  const { cart, isLoading, isMutating, updateItemQuantity, removeItem, clearAllItems } = useCart();
  const [division, setDivision] = useState<BangladeshDivision>('Dhaka');
  const [actionError, setActionError] = useState<string | null>(null);

  const subtotal = cart?.subtotal ?? '0.00';

  const quoteQuery = useQuery({
    queryKey: ['shipping', 'quote', division, subtotal],
    queryFn: ({ signal }) => fetchShippingQuote(division, subtotal, signal),
    enabled: Boolean(cart && cart.items.length > 0),
    staleTime: 30_000,
  });

  if (isLoading && !cart) {
    return (
      <Section spacing="md">
        <Container>
          <LoadingState label={t('common.loading')} />
        </Container>
      </Section>
    );
  }

  return (
    <Section spacing="md">
      <Container className="space-y-6">
        <div className="flex flex-col gap-3 border-b border-border pb-5 sm:flex-row sm:items-end sm:justify-between">
          <div className="space-y-1.5">
            <Badge variant="accent">{t('nav.cart')}</Badge>
            <h1 className="font-display text-2xl font-bold tracking-tight text-ink sm:text-3xl">
              {t('cart.pageTitle')}
            </h1>
            <p className="text-sm text-ink-muted">{t('cart.pageSubtitle')}</p>
          </div>

          {cart && cart.items.length > 0 ? (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              disabled={isMutating}
              onClick={async () => {
                setActionError(null);
                try {
                  await clearAllItems();
                } catch (err) {
                  setActionError(
                    err instanceof ApiClientError ? err.message : t('cart.errorGeneric')
                  );
                }
              }}
            >
              <Trash2 className="size-4" aria-hidden="true" />
              <span>{t('cart.clearCart')}</span>
            </Button>
          ) : null}
        </div>

        {actionError ? (
          <div
            role="alert"
            className="rounded-xl border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger"
          >
            {actionError}
          </div>
        ) : null}

        {!cart || cart.items.length === 0 ? (
          <EmptyState
            icon={<ShoppingBag className="size-6" />}
            title={t('cart.emptyTitle')}
            description={t('cart.emptyDesc')}
            action={
              <Button asChild variant="primary">
                <Link to="/shop">{t('cart.browseCatalogue')}</Link>
              </Button>
            }
          />
        ) : (
          <div className="grid gap-6 lg:grid-cols-12 lg:items-start">
            <div className="space-y-3 lg:col-span-7">
              {cart.items.map((item) => {
                const name = pickLocalizedText(locale, item.productNameEn, item.productNameBn);
                const color = pickLocalizedText(locale, item.colorNameEn, item.colorNameBn);
                return (
                  <Card
                    key={item.id}
                    className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="flex min-w-0 flex-1 items-start gap-3.5">
                      <div className="size-20 shrink-0 overflow-hidden rounded-xl border border-border bg-surface-muted">
                        {item.primaryImageUrl ? (
                          <img
                            src={item.primaryImageUrl}
                            alt={name}
                            className="h-full w-full object-cover"
                          />
                        ) : null}
                      </div>

                      <div className="min-w-0 flex-1 space-y-1">
                        <Link
                          to={`/product/${item.productSlug}`}
                          className="line-clamp-1 font-display text-base font-semibold text-ink hover:text-accent"
                        >
                          {name}
                        </Link>
                        <div className="flex flex-wrap items-center gap-2 text-xs text-ink-muted">
                          <span
                            className="inline-block size-3.5 rounded-full border border-border-dark/30"
                            style={{ backgroundColor: item.colorHex }}
                            aria-hidden="true"
                          />
                          <span>{color}</span>
                          <span>·</span>
                          <span className="font-mono font-semibold text-ink">{item.sizeCode}</span>
                          <span>·</span>
                          <span className="font-mono">{item.sku}</span>
                        </div>
                        <p className="font-mono text-xs text-ink-muted">
                          {formatBdtPrice(item.unitPrice, item.currencyCode)}
                          {Number.parseFloat(item.customizationFee) > 0
                            ? ` + ${formatBdtPrice(item.customizationFee, item.currencyCode)} (${t('cart.customPrintFee')})`
                            : ''}
                        </p>
                        {item.designPublicId && item.customizationMeta ? (
                          <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                            <Link
                              to={`/studio/${item.designPublicId}`}
                              className="inline-flex items-center gap-1.5 rounded-full border border-accent/35 bg-accent-soft px-2.5 py-0.5 font-medium text-accent-ink hover:underline"
                            >
                              <span>{t('cart.customDesignLabel')}:</span>
                              <span className="font-semibold">
                                {item.customizationMeta.designTitle ?? 'Studio Design'}
                              </span>
                              {item.customizationMeta.surfaces.length > 0 ? (
                                <span className="opacity-80">
                                  (
                                  {item.customizationMeta.surfaces
                                    .map((s) => pickLocalizedText(locale, s.labelEn, s.labelBn))
                                    .join(', ')}
                                  )
                                </span>
                              ) : null}
                            </Link>
                          </div>
                        ) : null}
                        {!item.isVariantAvailable ? (
                          <p className="text-xs font-medium text-danger">
                            {t('cart.unavailableNotice')}
                          </p>
                        ) : null}
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-3 sm:justify-end">
                      <div className="inline-flex items-center rounded-xl border border-border bg-surface-muted/40">
                        <button
                          type="button"
                          aria-label={t('cart.decreaseQty')}
                          disabled={isMutating || item.quantity <= 1}
                          onClick={async () => {
                            setActionError(null);
                            try {
                              await updateItemQuantity(item.id, item.quantity - 1);
                            } catch (err) {
                              setActionError(
                                err instanceof ApiClientError ? err.message : t('cart.errorGeneric')
                              );
                            }
                          }}
                          className="inline-flex min-h-11 min-w-11 cursor-pointer items-center justify-center rounded-l-xl text-ink hover:bg-surface disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          <Minus className="size-4" aria-hidden="true" />
                        </button>
                        <span className="min-w-9 text-center font-mono text-sm font-semibold text-ink">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          aria-label={t('cart.increaseQty')}
                          disabled={
                            isMutating || item.quantity >= Math.min(50, item.availableStock)
                          }
                          onClick={async () => {
                            setActionError(null);
                            try {
                              await updateItemQuantity(item.id, item.quantity + 1);
                            } catch (err) {
                              setActionError(
                                err instanceof ApiClientError ? err.message : t('cart.errorGeneric')
                              );
                            }
                          }}
                          className="inline-flex min-h-11 min-w-11 cursor-pointer items-center justify-center rounded-r-xl text-ink hover:bg-surface disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          <Plus className="size-4" aria-hidden="true" />
                        </button>
                      </div>

                      <span className="min-w-24 text-right font-mono text-sm font-bold text-ink">
                        {formatBdtPrice(item.lineTotal, item.currencyCode)}
                      </span>

                      <button
                        type="button"
                        aria-label={t('cart.removeItem')}
                        disabled={isMutating}
                        onClick={async () => {
                          setActionError(null);
                          try {
                            await removeItem(item.id);
                          } catch (err) {
                            setActionError(
                              err instanceof ApiClientError ? err.message : t('cart.errorGeneric')
                            );
                          }
                        }}
                        className="inline-flex min-h-11 min-w-11 cursor-pointer items-center justify-center rounded-xl text-ink-muted transition-colors hover:bg-danger-soft hover:text-danger"
                      >
                        <Trash2 className="size-4" aria-hidden="true" />
                      </button>
                    </div>
                  </Card>
                );
              })}
            </div>

            <Card className="space-y-5 p-6 lg:col-span-5">
              <div className="flex items-center gap-2 border-b border-border pb-3">
                <Truck className="size-5 text-accent-royal" aria-hidden="true" />
                <h2 className="font-display text-lg font-semibold text-ink">
                  {t('cart.shippingEstimatorTitle')}
                </h2>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="cart-division-select"
                  className="block text-xs font-semibold tracking-wider text-ink-muted uppercase"
                >
                  {t('cart.divisionSelectLabel')}
                </label>
                <Select
                  value={division}
                  onValueChange={(value) => setDivision(value as BangladeshDivision)}
                >
                  <SelectTrigger
                    id="cart-division-select"
                    className="min-h-11 text-base sm:text-sm"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {BANGLADESH_DIVISIONS.map((div) => (
                      <SelectItem key={div} value={div}>
                        {div}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2.5 border-t border-border pt-4 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-ink-muted">{t('cart.subtotalLabel')}</span>
                  <span className="font-mono font-semibold text-ink">
                    {formatBdtPrice(cart.subtotal, cart.currencyCode)}
                  </span>
                </div>

                {quoteQuery.data ? (
                  <>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-ink-muted">
                        {t('cart.shippingFeeLabel', {
                          zone: pickLocalizedText(
                            locale,
                            quoteQuery.data.zone.nameEn,
                            quoteQuery.data.zone.nameBn
                          ),
                        })}
                      </span>
                      <span className="font-mono font-semibold text-ink">
                        {quoteQuery.data.freeShippingQualified
                          ? t('cart.freeLabel')
                          : formatBdtPrice(
                              quoteQuery.data.shippingFee,
                              quoteQuery.data.currencyCode
                            )}
                      </span>
                    </div>

                    {quoteQuery.data.freeShippingQualified ? (
                      <p className="rounded-xl border border-success/30 bg-success-soft px-3 py-2 text-xs font-medium text-success">
                        {t('cart.freeShippingUnlocked')}
                      </p>
                    ) : quoteQuery.data.amountRemainingForFreeShipping ? (
                      <p className="rounded-xl border border-border bg-surface-muted/60 px-3 py-2 text-xs text-ink-muted">
                        {t('cart.freeShippingProgress', {
                          amount: formatBdtPrice(
                            quoteQuery.data.amountRemainingForFreeShipping,
                            quoteQuery.data.currencyCode
                          ),
                        })}
                      </p>
                    ) : null}

                    <div className="flex items-center justify-between border-t border-border pt-3 text-base">
                      <span className="font-display font-bold text-ink">
                        {t('cart.estimatedTotalLabel')}
                      </span>
                      <span
                        data-testid="cart-estimated-total"
                        className="font-mono text-lg font-bold text-ink"
                      >
                        {formatBdtPrice(
                          quoteQuery.data.estimatedTotal,
                          quoteQuery.data.currencyCode
                        )}
                      </span>
                    </div>
                  </>
                ) : null}
              </div>

              <Button
                asChild
                variant="primary"
                size="lg"
                className="w-full"
                data-testid="cart-proceed-checkout"
              >
                <Link to="/checkout">
                  <span>{t('cart.proceedCheckout')}</span>
                  <ArrowRight className="size-4" aria-hidden="true" />
                </Link>
              </Button>
            </Card>
          </div>
        )}
      </Container>
    </Section>
  );
}
