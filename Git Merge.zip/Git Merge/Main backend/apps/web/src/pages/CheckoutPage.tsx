import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  BANGLADESH_DIVISIONS,
  type BangladeshDivision,
  type PaymentMethod,
} from '@your-choice/shared-types';
import {
  Badge,
  Button,
  Card,
  Container,
  EmptyState,
  FormField,
  Input,
  LoadingState,
  Section,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  Textarea,
} from '@your-choice/ui';
import { CheckCircle2, CreditCard, Lock, MapPin, ShoppingBag, Truck } from 'lucide-react';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { fetchMyAddresses } from '@/features/addresses/addresses.api';
import { useAuth } from '@/features/auth/auth-context';
import { CART_QUERY_KEY, useCart } from '@/features/commerce/cart-context';
import {
  fetchCheckoutOptions,
  fetchShippingQuote,
  placeOrder,
} from '@/features/commerce/commerce.api';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';

const NEW_ADDRESS_SENTINEL = '__new_address__';

export function CheckoutPage() {
  const { locale, t } = useAppLocale();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user, isAuthenticated } = useAuth();
  const { cart, isLoading: isCartLoading } = useCart();

  const [selectedSavedId, setSelectedSavedId] = useState<string | null>(null);
  const [customerEmail, setCustomerEmail] = useState<string | null>(null);
  const [customerPhone, setCustomerPhone] = useState<string | null>(null);
  const [recipientName, setRecipientName] = useState<string | null>(null);
  const [addressPhone, setAddressPhone] = useState<string | null>(null);
  const [division, setDivision] = useState<BangladeshDivision>('Dhaka');
  const [district, setDistrict] = useState('Dhaka');
  const [area, setArea] = useState('');
  const [addressLine, setAddressLine] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [customerNote, setCustomerNote] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [submitError, setSubmitError] = useState<string | null>(null);

  const optionsQuery = useQuery({
    queryKey: ['checkout', 'options'],
    queryFn: ({ signal }) => fetchCheckoutOptions(signal),
    staleTime: 60_000,
  });

  const addressesQuery = useQuery({
    queryKey: ['addresses', 'me'],
    queryFn: ({ signal }) => fetchMyAddresses(signal),
    enabled: isAuthenticated,
    staleTime: 30_000,
  });

  const savedAddresses = addressesQuery.data ?? [];
  const effectiveSavedId =
    selectedSavedId === NEW_ADDRESS_SENTINEL
      ? null
      : (selectedSavedId ??
        savedAddresses.find((a) => a.isDefault)?.id ??
        savedAddresses[0]?.id ??
        null);
  const activeSavedAddress = savedAddresses.find((a) => a.id === effectiveSavedId) ?? null;

  const activeDivision: BangladeshDivision = activeSavedAddress
    ? activeSavedAddress.division
    : division;
  const subtotal = cart?.subtotal ?? '0.00';

  const quoteQuery = useQuery({
    queryKey: ['shipping', 'quote', activeDivision, subtotal],
    queryFn: ({ signal }) => fetchShippingQuote(activeDivision, subtotal, signal),
    enabled: Boolean(cart && cart.items.length > 0),
    staleTime: 30_000,
  });

  const placeOrderMutation = useMutation({
    mutationFn: placeOrder,
    onSuccess: (createdOrder) => {
      queryClient.setQueryData(CART_QUERY_KEY, {
        id: cart?.id ?? '00000000-0000-0000-0000-000000000000',
        items: [],
        itemCount: 0,
        subtotal: '0.00',
        currencyCode: 'BDT',
        hasUnavailableItems: false,
        expiresAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
      });
      void queryClient.invalidateQueries({ queryKey: ['orders', 'me'] });
      navigate(`/orders/${createdOrder.orderNumber}?placed=1`, { replace: true });
    },
    onError: (err) => {
      setSubmitError(err instanceof ApiClientError ? err.message : 'Could not place order.');
    },
  });

  if (isCartLoading && !cart) {
    return (
      <Section spacing="md">
        <Container>
          <LoadingState label={t('common.loading')} />
        </Container>
      </Section>
    );
  }

  if (!cart || cart.items.length === 0) {
    return (
      <Section spacing="md">
        <Container>
          <EmptyState
            icon={<ShoppingBag className="size-6" />}
            title={t('checkout.emptyCartTitle')}
            description={t('checkout.emptyCartDesc')}
            action={
              <Button asChild variant="primary">
                <Link to="/shop">{t('cart.browseCatalogue')}</Link>
              </Button>
            }
          />
        </Container>
      </Section>
    );
  }

  const effectiveEmail = customerEmail ?? user?.email ?? '';
  const effectivePhone = customerPhone ?? activeSavedAddress?.phone ?? user?.phone ?? '';
  const effectiveRecipientName = recipientName ?? user?.fullName ?? '';
  const effectiveAddressPhone = addressPhone ?? effectivePhone;

  const handleCheckoutSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    setSubmitError(null);

    if (!activeSavedAddress && (!effectiveEmail.trim() || !effectivePhone.trim())) {
      setSubmitError('Please provide your contact email and Bangladesh mobile number.');
      return;
    }

    placeOrderMutation.mutate({
      ...(activeSavedAddress
        ? { savedAddressId: activeSavedAddress.id }
        : {
            shippingAddress: {
              recipientName: effectiveRecipientName.trim(),
              phone: effectiveAddressPhone.trim(),
              division,
              district: district.trim(),
              area: area.trim(),
              addressLine: addressLine.trim(),
              postalCode: postalCode.trim() ? postalCode.trim() : null,
            },
          }),
      ...(effectiveEmail.trim() ? { customerEmail: effectiveEmail.trim() } : {}),
      ...(effectivePhone.trim() ? { customerPhone: effectivePhone.trim() } : {}),
      paymentMethod,
      customerNote: customerNote.trim() ? customerNote.trim() : null,
    });
  };

  return (
    <Section spacing="md">
      <Container className="space-y-6">
        <div className="space-y-1.5 border-b border-border pb-5">
          <Badge variant="accent">{t('checkout.badge')}</Badge>
          <h1 className="font-display text-2xl font-bold tracking-tight text-ink sm:text-3xl">
            {t('checkout.title')}
          </h1>
          <p className="text-sm text-ink-muted">{t('checkout.subtitle')}</p>
        </div>

        {submitError ? (
          <div
            role="alert"
            className="rounded-xl border border-danger/30 bg-danger-soft px-4 py-3 text-sm text-danger"
          >
            {submitError}
          </div>
        ) : null}

        <form
          onSubmit={handleCheckoutSubmit}
          noValidate
          className="grid gap-6 lg:grid-cols-12 lg:items-start"
        >
          <div className="space-y-6 lg:col-span-7">
            {/* Contact Details */}
            <Card className="space-y-4 p-5 sm:p-6">
              <h2 className="font-display text-lg font-semibold text-ink">
                {t('checkout.contactTitle')}
              </h2>

              <div className="grid gap-4 sm:grid-cols-2">
                <FormField id="checkout-email" label={t('checkout.emailLabel')} required>
                  <Input
                    id="checkout-email"
                    type="email"
                    value={effectiveEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="text-base sm:text-sm"
                  />
                </FormField>

                <FormField id="checkout-phone" label={t('checkout.phoneLabel')} required>
                  <Input
                    id="checkout-phone"
                    type="tel"
                    value={effectivePhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="+88017XXXXXXXX"
                    className="text-base sm:text-sm"
                  />
                </FormField>
              </div>
            </Card>

            {/* Delivery Address */}
            <Card className="space-y-4 p-5 sm:p-6">
              <div className="flex items-center gap-2">
                <MapPin className="size-5 text-accent-royal" aria-hidden="true" />
                <h2 className="font-display text-lg font-semibold text-ink">
                  {t('checkout.deliveryTitle')}
                </h2>
              </div>

              {isAuthenticated && savedAddresses.length > 0 ? (
                <div className="space-y-2">
                  <p className="text-xs font-semibold tracking-wider text-ink-muted uppercase">
                    {t('checkout.savedAddressesLabel')}
                  </p>
                  <div className="grid gap-2.5">
                    {savedAddresses.map((addr) => {
                      const isSelected = activeSavedAddress?.id === addr.id;
                      return (
                        <button
                          key={addr.id}
                          type="button"
                          onClick={() => setSelectedSavedId(addr.id)}
                          className={`flex w-full cursor-pointer items-start justify-between gap-3 rounded-xl border p-3.5 text-left transition-all ${
                            isSelected
                              ? 'border-accent bg-accent-soft/60 ring-1 ring-accent'
                              : 'border-border bg-surface hover:bg-surface-muted'
                          }`}
                        >
                          <div className="space-y-0.5 text-xs">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-semibold text-ink">{addr.label}</span>
                              {addr.isDefault ? (
                                <Badge variant="accent">{t('addresses.defaultBadge')}</Badge>
                              ) : null}
                            </div>
                            <p className="text-ink">
                              {addr.recipientName} · <span className="font-mono">{addr.phone}</span>
                            </p>
                            <p className="text-ink-muted">
                              {addr.addressLine}, {addr.area}, {addr.district}, {addr.division}
                              {addr.postalCode ? ` (${addr.postalCode})` : ''}
                            </p>
                          </div>
                          {isSelected ? (
                            <CheckCircle2
                              className="size-5 shrink-0 text-accent"
                              aria-hidden="true"
                            />
                          ) : null}
                        </button>
                      );
                    })}

                    <button
                      type="button"
                      onClick={() => setSelectedSavedId(NEW_ADDRESS_SENTINEL)}
                      className={`min-h-11 w-full cursor-pointer rounded-xl border px-3.5 py-2 text-left text-xs font-medium transition-colors ${
                        !activeSavedAddress
                          ? 'border-accent bg-accent-soft/60 text-accent-ink ring-1 ring-accent'
                          : 'border-dashed border-border text-ink-muted hover:bg-surface-muted'
                      }`}
                    >
                      + {t('checkout.newAddressOption')}
                    </button>
                  </div>
                </div>
              ) : null}

              {!activeSavedAddress ? (
                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField id="checkout-recipient" label={t('addresses.recipientField')} required>
                    <Input
                      id="checkout-recipient"
                      value={effectiveRecipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      placeholder="Sadia Rahman"
                      className="text-base sm:text-sm"
                    />
                  </FormField>

                  <FormField id="checkout-addr-phone" label={t('addresses.phoneField')} required>
                    <Input
                      id="checkout-addr-phone"
                      type="tel"
                      value={effectiveAddressPhone}
                      onChange={(e) => setAddressPhone(e.target.value)}
                      placeholder="+8801712345678"
                      className="text-base sm:text-sm"
                    />
                  </FormField>

                  <FormField id="checkout-division" label={t('addresses.divisionField')} required>
                    <Select
                      value={division}
                      onValueChange={(value) => setDivision(value as BangladeshDivision)}
                    >
                      <SelectTrigger
                        id="checkout-division"
                        className="min-h-11 text-base sm:text-sm"
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {BANGLADESH_DIVISIONS.map((div) => (
                          <SelectItem key={div} value={div}>
                            {div}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormField>

                  <FormField id="checkout-district" label={t('addresses.districtField')} required>
                    <Input
                      id="checkout-district"
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      placeholder="Dhaka"
                      className="text-base sm:text-sm"
                    />
                  </FormField>

                  <FormField id="checkout-area" label={t('addresses.areaField')} required>
                    <Input
                      id="checkout-area"
                      value={area}
                      onChange={(e) => setArea(e.target.value)}
                      placeholder="Dhanmondi / Nasirabad"
                      className="text-base sm:text-sm"
                    />
                  </FormField>

                  <FormField id="checkout-postal" label={t('addresses.postalCodeField')}>
                    <Input
                      id="checkout-postal"
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value)}
                      placeholder="1209"
                      className="text-base sm:text-sm"
                    />
                  </FormField>

                  <div className="sm:col-span-2">
                    <FormField
                      id="checkout-address-line"
                      label={t('addresses.addressLineField')}
                      required
                    >
                      <Input
                        id="checkout-address-line"
                        value={addressLine}
                        onChange={(e) => setAddressLine(e.target.value)}
                        placeholder="House 24, Road 9A, Floor 3"
                        className="text-base sm:text-sm"
                      />
                    </FormField>
                  </div>
                </div>
              ) : null}

              <FormField id="checkout-note" label={t('checkout.noteLabel')}>
                <Textarea
                  id="checkout-note"
                  rows={2}
                  value={customerNote}
                  onChange={(e) => setCustomerNote(e.target.value)}
                  placeholder={t('checkout.notePlaceholder')}
                  className="text-base sm:text-sm"
                />
              </FormField>
            </Card>

            {/* Payment Providers */}
            <Card className="space-y-4 p-5 sm:p-6">
              <div className="flex items-center gap-2">
                <CreditCard className="size-5 text-accent-royal" aria-hidden="true" />
                <h2 className="font-display text-lg font-semibold text-ink">
                  {t('checkout.paymentTitle')}
                </h2>
              </div>

              {optionsQuery.isLoading ? (
                <LoadingState label={t('common.loading')} />
              ) : (
                <div className="grid gap-3">
                  {(optionsQuery.data?.paymentProviders ?? []).map((provider) => {
                    const isSelected = paymentMethod === provider.method;
                    const label = pickLocalizedText(locale, provider.labelEn, provider.labelBn);
                    const desc = pickLocalizedText(
                      locale,
                      provider.descriptionEn,
                      provider.descriptionBn
                    );
                    const reason = pickLocalizedText(
                      locale,
                      provider.unavailableReasonEn,
                      provider.unavailableReasonBn
                    );

                    return (
                      <button
                        key={provider.method}
                        type="button"
                        disabled={!provider.enabled}
                        data-testid={`payment-option-${provider.method}`}
                        onClick={() => {
                          if (provider.enabled) {
                            setPaymentMethod(provider.method);
                          }
                        }}
                        className={`flex w-full items-start justify-between gap-3 rounded-xl border p-4 text-left transition-all ${
                          !provider.enabled
                            ? 'cursor-not-allowed border-border bg-surface-muted/50 opacity-75'
                            : isSelected
                              ? 'cursor-pointer border-accent bg-accent-soft/60 ring-1 ring-accent'
                              : 'cursor-pointer border-border bg-surface hover:bg-surface-muted'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-display text-sm font-semibold text-ink">
                              {label}
                            </span>
                            <Badge variant={provider.enabled ? 'success' : 'neutral'}>
                              {provider.enabled
                                ? t('checkout.paymentReadyBadge')
                                : t('checkout.paymentUnavailableBadge')}
                            </Badge>
                          </div>
                          <p className="text-xs text-ink-muted">{desc}</p>
                          {!provider.enabled && reason ? (
                            <p className="text-xs font-medium text-warning">{reason}</p>
                          ) : null}
                        </div>

                        {isSelected && provider.enabled ? (
                          <CheckCircle2
                            className="size-5 shrink-0 text-accent"
                            aria-hidden="true"
                          />
                        ) : null}
                      </button>
                    );
                  })}
                </div>
              )}

              {paymentMethod === 'cod' ? (
                <p className="flex items-center gap-2 text-xs text-ink-muted">
                  <Truck className="size-4 shrink-0 text-success" aria-hidden="true" />
                  <span>{t('checkout.codConfirmationHint')}</span>
                </p>
              ) : null}
            </Card>
          </div>

          {/* Right: Order Summary */}
          <Card className="space-y-4 p-6 lg:sticky lg:top-24 lg:col-span-5">
            <h2 className="border-b border-border pb-3 font-display text-lg font-semibold text-ink">
              {t('checkout.orderSummaryTitle')}
            </h2>

            <div className="max-h-72 space-y-3 overflow-y-auto pr-1">
              {cart.items.map((item) => {
                const name = pickLocalizedText(locale, item.productNameEn, item.productNameBn);
                const color = pickLocalizedText(locale, item.colorNameEn, item.colorNameBn);
                return (
                  <div key={item.id} className="flex items-start justify-between gap-3 text-xs">
                    <div className="min-w-0">
                      <p className="truncate font-semibold text-ink">{name}</p>
                      <p className="text-ink-muted">
                        {color} · {item.sizeCode} × {item.quantity}
                      </p>
                      {item.designPublicId && item.customizationMeta ? (
                        <p className="truncate font-medium text-accent-ink">
                          {t('cart.customDesignLabel')}:{' '}
                          {item.customizationMeta.designTitle ?? 'Studio Design'}
                        </p>
                      ) : null}
                    </div>
                    <span className="shrink-0 font-mono font-semibold text-ink">
                      {formatBdtPrice(item.lineTotal, item.currencyCode)}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="space-y-2 border-t border-border pt-4 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-ink-muted">{t('cart.subtotalLabel')}</span>
                <span className="font-mono font-semibold text-ink">
                  {formatBdtPrice(cart.subtotal, cart.currencyCode)}
                </span>
              </div>

              {quoteQuery.data ? (
                <>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-ink-muted">
                      {t('cart.shippingFeeLabel', {
                        zone: pickLocalizedText(
                          locale,
                          quoteQuery.data.zone.nameEn,
                          quoteQuery.data.zone.nameBn
                        ),
                      })}
                    </span>
                    <span className="font-mono font-semibold text-ink">
                      {quoteQuery.data.freeShippingQualified
                        ? t('cart.freeLabel')
                        : formatBdtPrice(quoteQuery.data.shippingFee, quoteQuery.data.currencyCode)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between border-t border-border pt-3 text-base">
                    <span className="font-display font-bold text-ink">
                      {t('cart.estimatedTotalLabel')}
                    </span>
                    <span
                      data-testid="checkout-total-amount"
                      className="font-mono text-lg font-bold text-ink"
                    >
                      {formatBdtPrice(quoteQuery.data.estimatedTotal, quoteQuery.data.currencyCode)}
                    </span>
                  </div>
                </>
              ) : null}
            </div>

            <Button
              type="submit"
              variant="primary"
              size="lg"
              className="w-full"
              data-testid="place-order-button"
              disabled={placeOrderMutation.isPending || cart.hasUnavailableItems}
            >
              <Lock className="size-4" aria-hidden="true" />
              <span>
                {placeOrderMutation.isPending
                  ? t('checkout.placingOrderBtn')
                  : t('checkout.placeOrderBtn')}
              </span>
            </Button>
          </Card>
        </form>
      </Container>
    </Section>
  );
}
