import { useCallback, useEffect, useState } from 'react';
import type { HealthCheckResponse } from '@your-choice/shared-types';
import { fetchHealthStatus } from '@/services/health.service';

export interface HealthState {
  status: 'loading' | 'loaded' | 'error';
  data: HealthCheckResponse | null;
  errorMessage: string | null;
  refresh: () => void;
}

export function useHealthStatus(): HealthState {
  const [status, setStatus] = useState<'loading' | 'loaded' | 'error'>('loading');
  const [data, setData] = useState<HealthCheckResponse | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [reloadNonce, setReloadNonce] = useState(0);

  const refresh = useCallback(() => {
    setStatus('loading');
    setErrorMessage(null);
    setReloadNonce((prev) => prev + 1);
  }, []);

  useEffect(() => {
    const controller = new AbortController();

    fetchHealthStatus(controller.signal)
      .then((health) => {
        setData(health);
        setStatus('loaded');
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) {
          return;
        }
        setStatus('error');
        setErrorMessage(
          error instanceof Error ? error.message : 'Unable to reach API health endpoint'
        );
      });

    return () => {
      controller.abort();
    };
  }, [reloadNonce]);

  return {
    status,
    data,
    errorMessage,
    refresh,
  };
}
