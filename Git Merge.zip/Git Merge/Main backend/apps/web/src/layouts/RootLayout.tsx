import { Outlet } from 'react-router-dom';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { CartProvider } from '@/features/commerce/CartProvider';

export function RootLayout() {
  return (
    <CartProvider>
      <div className="flex min-h-dvh flex-col bg-canvas text-ink">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:rounded-lg focus:bg-accent focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-white"
        >
          Skip to main content
        </a>

        <SiteHeader />

        <main id="main-content" tabIndex={-1} className="flex-1">
          <Outlet />
        </main>

        <SiteFooter />
      </div>
    </CartProvider>
  );
}
