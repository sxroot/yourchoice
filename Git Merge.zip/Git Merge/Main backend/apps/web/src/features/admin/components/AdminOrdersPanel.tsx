import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ORDER_STATUSES, type OrderStatus } from '@your-choice/shared-types';
import {
  Badge,
  Button,
  Card,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  EmptyState,
  FormField,
  Input,
  LoadingState,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@your-choice/ui';
import { CheckCircle2, CreditCard, Package, Search } from 'lucide-react';
import { useState } from 'react';
import {
  fetchAdminOrderDetail,
  fetchAdminOrders,
  settleAdminCodPayment,
  updateAdminOrderStatus,
} from '@/features/commerce/commerce.api';
import { OrderStatusBadge, PaymentStatusBadge } from '@/features/commerce/OrderStatusBadge';
import { formatBdtPrice, useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';

const ALL_STATUSES = '__all__';

export function AdminOrdersPanel() {
  const { t } = useAppLocale();
  const queryClient = useQueryClient();

  const [statusFilter, setStatusFilter] = useState<OrderStatus | typeof ALL_STATUSES>(ALL_STATUSES);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrderNumber, setSelectedOrderNumber] = useState<string | null>(null);
  const [statusNote, setStatusNote] = useState('');
  const [codRef, setCodRef] = useState('');
  const [panelError, setPanelError] = useState<string | null>(null);

  const ordersQuery = useQuery({
    queryKey: ['admin', 'orders', statusFilter, searchTerm],
    queryFn: ({ signal }) =>
      fetchAdminOrders(
        {
          ...(statusFilter !== ALL_STATUSES ? { status: statusFilter } : {}),
          ...(searchTerm.trim() ? { search: searchTerm.trim() } : {}),
          page: 1,
          pageSize: 25,
        },
        signal
      ),
  });

  const detailQuery = useQuery({
    queryKey: ['admin', 'orders', 'detail', selectedOrderNumber],
    queryFn: ({ signal }) => fetchAdminOrderDetail(selectedOrderNumber!, signal),
    enabled: Boolean(selectedOrderNumber),
  });

  const statusMutation = useMutation({
    mutationFn: ({ orderNumber, toStatus }: { orderNumber: string; toStatus: OrderStatus }) =>
      updateAdminOrderStatus(orderNumber, {
        toStatus,
        note: statusNote.trim() ? statusNote.trim() : null,
      }),
    onSuccess: (updated) => {
      setPanelError(null);
      setStatusNote('');
      queryClient.setQueryData(['admin', 'orders', 'detail', updated.orderNumber], updated);
      void queryClient.invalidateQueries({ queryKey: ['admin', 'orders'] });
    },
    onError: (err) => {
      setPanelError(err instanceof ApiClientError ? err.message : 'Unable to update order status.');
    },
  });

  const settleCodMutation = useMutation({
    mutationFn: ({
      orderNumber,
      transactionRef,
    }: {
      orderNumber: string;
      transactionRef: string;
    }) => settleAdminCodPayment(orderNumber, { transactionRef }),
    onSuccess: (updated) => {
      setPanelError(null);
      setCodRef('');
      queryClient.setQueryData(['admin', 'orders', 'detail', updated.orderNumber], updated);
      void queryClient.invalidateQueries({ queryKey: ['admin', 'orders'] });
    },
    onError: (err) => {
      setPanelError(err instanceof ApiClientError ? err.message : 'Unable to settle COD payment.');
    },
  });

  const activeOrder = detailQuery.data ?? null;

  return (
    <div className="space-y-5">
      <Card className="space-y-4 p-5 sm:p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-lg font-semibold text-ink">
              {t('admin.ordersTitle')}
            </h2>
            <p className="text-xs text-ink-muted">{t('admin.ordersDesc')}</p>
          </div>
          {ordersQuery.data ? (
            <Badge variant="neutral">{ordersQuery.data.pagination.totalItems} orders</Badge>
          ) : null}
        </div>

        <div className="grid gap-3 sm:grid-cols-12">
          <div className="relative sm:col-span-7">
            <Search
              className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-ink-muted"
              aria-hidden="true"
            />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t('admin.searchOrdersPlaceholder')}
              className="pl-9 text-base sm:text-sm"
            />
          </div>

          <div className="sm:col-span-5">
            <Select
              value={statusFilter}
              onValueChange={(value) => setStatusFilter(value as OrderStatus | typeof ALL_STATUSES)}
            >
              <SelectTrigger className="min-h-11 text-base sm:text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_STATUSES}>{t('admin.allStatuses')}</SelectItem>
                {ORDER_STATUSES.map((st) => (
                  <SelectItem key={st} value={st}>
                    {t(`orders.status.${st}`)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {ordersQuery.isLoading ? (
          <LoadingState label={t('common.loading')} />
        ) : ordersQuery.isError ? (
          <div className="rounded-xl border border-danger/30 bg-danger-soft p-4 text-sm text-danger">
            {ordersQuery.error instanceof Error
              ? ordersQuery.error.message
              : 'Unable to load orders.'}
          </div>
        ) : !ordersQuery.data || ordersQuery.data.orders.length === 0 ? (
          <EmptyState
            icon={<Package className="size-6" />}
            title={t('orders.emptyTitle')}
            description="Customer orders placed from checkout will appear here."
          />
        ) : (
          <div className="divide-y divide-border rounded-xl border border-border">
            {ordersQuery.data.orders.map((order) => (
              <div
                key={order.id}
                className="flex flex-col gap-3 px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-sm font-bold text-ink">
                      {order.orderNumber}
                    </span>
                    <OrderStatusBadge status={order.orderStatus} />
                    <PaymentStatusBadge status={order.paymentStatus} />
                  </div>
                  <p className="text-xs text-ink-muted">
                    {order.customerEmail} · <span className="font-mono">{order.customerPhone}</span>{' '}
                    · {order.shippingDivision}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-mono text-sm font-bold text-ink">
                    {formatBdtPrice(order.totalAmount, order.currencyCode)}
                  </span>
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    data-testid={`admin-manage-order-${order.orderNumber}`}
                    onClick={() => {
                      setPanelError(null);
                      setSelectedOrderNumber(order.orderNumber);
                    }}
                  >
                    Manage
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Dialog
        open={Boolean(selectedOrderNumber)}
        onOpenChange={(open) => {
          if (!open) {
            setSelectedOrderNumber(null);
            setPanelError(null);
          }
        }}
      >
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="font-mono">
              {activeOrder?.orderNumber ?? selectedOrderNumber}
            </DialogTitle>
            <DialogDescription>
              {activeOrder
                ? `${activeOrder.customerEmail} · ${activeOrder.customerPhone}`
                : t('common.loading')}
            </DialogDescription>
          </DialogHeader>

          {panelError ? (
            <div
              role="alert"
              className="rounded-xl border border-danger/30 bg-danger-soft px-3.5 py-2 text-xs text-danger"
            >
              {panelError}
            </div>
          ) : null}

          {detailQuery.isLoading || !activeOrder ? (
            <LoadingState label={t('common.loading')} />
          ) : (
            <div className="space-y-4 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                <OrderStatusBadge status={activeOrder.orderStatus} />
                <PaymentStatusBadge status={activeOrder.paymentStatus} />
                <Badge variant="neutral">{activeOrder.paymentMethod.toUpperCase()}</Badge>
                <span className="ml-auto font-mono text-sm font-bold text-ink">
                  {formatBdtPrice(activeOrder.totalAmount, activeOrder.currencyCode)}
                </span>
              </div>

              <div className="rounded-xl border border-border bg-surface-muted/40 p-3">
                <p className="font-semibold text-ink">
                  {activeOrder.shippingAddress.recipientName}
                </p>
                <p className="text-ink-muted">
                  {activeOrder.shippingAddress.addressLine}, {activeOrder.shippingAddress.area},{' '}
                  {activeOrder.shippingAddress.district}, {activeOrder.shippingAddress.division}
                </p>
              </div>

              {activeOrder.items && activeOrder.items.length > 0 ? (
                <div className="space-y-2 rounded-xl border border-border p-3">
                  <p className="font-semibold text-ink">{t('orders.itemsSection')}</p>
                  {activeOrder.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-start justify-between gap-2 border-t border-border/60 pt-1.5 first:border-t-0 first:pt-0"
                    >
                      <div className="min-w-0">
                        <p className="font-medium text-ink">
                          {item.productNameEn} ({item.sizeCode}) × {item.quantity}
                        </p>
                        {item.designTitle ? (
                          <p className="text-[11px] font-medium text-accent-ink">
                            Custom Studio: {item.designTitle}
                            {item.productionSpec?.surfaces.length
                              ? ` · [${item.productionSpec.surfaces.map((s) => s.surfaceKey).join(', ')}]`
                              : ''}
                          </p>
                        ) : null}
                      </div>
                      <span className="shrink-0 font-mono font-semibold text-ink">
                        {formatBdtPrice(item.lineTotal, item.currencyCode)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : null}

              {activeOrder.allowedNextStatuses.length > 0 ? (
                <div className="space-y-2.5 rounded-xl border border-border p-3.5">
                  <FormField id="admin-order-note" label="Status Note">
                    <Input
                      id="admin-order-note"
                      value={statusNote}
                      onChange={(e) => setStatusNote(e.target.value)}
                      placeholder={t('admin.statusNotePlaceholder')}
                      className="text-base sm:text-sm"
                    />
                  </FormField>

                  <div className="flex flex-wrap gap-2">
                    {activeOrder.allowedNextStatuses.map((nextSt) => (
                      <Button
                        key={nextSt}
                        type="button"
                        size="sm"
                        variant={nextSt === 'cancelled' ? 'danger' : 'secondary'}
                        data-testid={`admin-transition-${nextSt}`}
                        disabled={statusMutation.isPending}
                        onClick={() =>
                          statusMutation.mutate({
                            orderNumber: activeOrder.orderNumber,
                            toStatus: nextSt,
                          })
                        }
                      >
                        {t(`orders.status.${nextSt}`)}
                      </Button>
                    ))}
                  </div>
                </div>
              ) : null}

              {activeOrder.paymentMethod === 'cod' &&
              activeOrder.paymentStatus !== 'paid' &&
              activeOrder.orderStatus !== 'cancelled' ? (
                <div className="space-y-2.5 rounded-xl border border-border p-3.5">
                  <div className="flex items-center gap-1.5 font-semibold text-ink">
                    <CreditCard className="size-4 text-accent-royal" aria-hidden="true" />
                    <span>{t('admin.settleCodBtn')}</span>
                  </div>
                  <FormField id="admin-cod-ref" label={t('admin.codRefLabel')} required>
                    <Input
                      id="admin-cod-ref"
                      value={codRef}
                      onChange={(e) => setCodRef(e.target.value)}
                      placeholder="STEADFAST-POD-2026-001"
                      className="text-base sm:text-sm"
                    />
                  </FormField>
                  <Button
                    type="button"
                    size="sm"
                    variant="primary"
                    data-testid="admin-settle-cod-button"
                    disabled={settleCodMutation.isPending || codRef.trim().length < 3}
                    onClick={() =>
                      settleCodMutation.mutate({
                        orderNumber: activeOrder.orderNumber,
                        transactionRef: codRef.trim(),
                      })
                    }
                  >
                    <CheckCircle2 className="size-4" aria-hidden="true" />
                    <span>{t('admin.settleCodBtn')}</span>
                  </Button>
                </div>
              ) : null}
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setSelectedOrderNumber(null)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
