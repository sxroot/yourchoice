import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { ProductStatus, ProductSummaryDTO } from '@your-choice/shared-types';
import { createProductSchema } from '@your-choice/validation';
import {
  Badge,
  Button,
  Card,
  Checkbox,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  EmptyState,
  FormField,
  Input,
  LoadingState,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  Textarea,
} from '@your-choice/ui';
import { CheckCircle2, Layers, Plus, Settings2, Shirt, Sparkles } from 'lucide-react';
import { useState } from 'react';
import {
  createAdminProduct,
  fetchAdminCategories,
  fetchAdminProducts,
  updateAdminProduct,
} from '@/features/catalog/catalog.api';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';
import { AdminProductWorkspaceDialog } from './AdminProductWorkspaceDialog';

const ALL_STATUS = '__all__';

export function AdminCatalogPanel() {
  const { locale, t } = useAppLocale();
  const queryClient = useQueryClient();

  const [statusFilter, setStatusFilter] = useState<ProductStatus | typeof ALL_STATUS>(ALL_STATUS);
  const [searchTerm, setSearchTerm] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [workspaceProductId, setWorkspaceProductId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Create Product dialog state
  const [categoryId, setCategoryId] = useState('');
  const [slug, setSlug] = useState('');
  const [skuPrefix, setSkuPrefix] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [nameBn, setNameBn] = useState('');
  const [subtitleEn, setSubtitleEn] = useState('');
  const [subtitleBn, setSubtitleBn] = useState('');
  const [descriptionEn, setDescriptionEn] = useState('');
  const [descriptionBn, setDescriptionBn] = useState('');
  const [gsm, setGsm] = useState('220');
  const [fitType, setFitType] = useState('Regular Studio Fit');
  const [basePrice, setBasePrice] = useState('690.00');
  const [primaryImageUrl, setPrimaryImageUrl] = useState('/catalog/tee-front.svg');
  const [isCustomizable, setIsCustomizable] = useState(true);

  const categoriesQuery = useQuery({
    queryKey: ['admin', 'categories'],
    queryFn: ({ signal }) => fetchAdminCategories(signal),
    retry: false,
  });

  const productsQuery = useQuery({
    queryKey: ['admin', 'products', statusFilter, searchTerm],
    queryFn: ({ signal }) =>
      fetchAdminProducts(
        {
          status: statusFilter === ALL_STATUS ? undefined : statusFilter,
          search: searchTerm.trim() || undefined,
          pageSize: 30,
        },
        signal
      ),
    retry: false,
  });

  const invalidateCatalog = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'products'] });
    await queryClient.invalidateQueries({ queryKey: ['admin', 'categories'] });
    await queryClient.invalidateQueries({ queryKey: ['catalog'] });
  };

  const createMutation = useMutation({
    mutationFn: () => {
      const resolvedCategoryId = categoryId || categoriesQuery.data?.[0]?.id || '';
      const parsed = createProductSchema.safeParse({
        categoryId: resolvedCategoryId,
        slug,
        skuPrefix,
        nameEn,
        nameBn,
        subtitleEn: subtitleEn.trim() || null,
        subtitleBn: subtitleBn.trim() || null,
        descriptionEn,
        descriptionBn,
        gsm: gsm.trim() ? gsm : null,
        fitType: fitType.trim() || null,
        basePrice,
        isCustomizable,
        status: 'draft',
        images: primaryImageUrl.trim()
          ? [
              {
                viewType: 'front',
                url: primaryImageUrl.trim(),
                altTextEn: nameEn.trim() || 'Apparel product',
                altTextBn: nameBn.trim() || 'পোশাক',
                isPrimary: true,
                sortOrder: 0,
              },
            ]
          : undefined,
      });

      if (!parsed.success) {
        throw new Error(parsed.error.issues[0]?.message ?? 'Validation error');
      }

      return createAdminProduct(parsed.data);
    },
    onSuccess: async (created) => {
      await invalidateCatalog();
      setCreateOpen(false);
      setSlug('');
      setSkuPrefix('');
      setNameEn('');
      setNameBn('');
      setSubtitleEn('');
      setSubtitleBn('');
      setDescriptionEn('');
      setDescriptionBn('');
      setFeedback(`Created draft garment: ${created.nameEn}`);
      setErrorMsg(null);
      setWorkspaceProductId(created.id);
    },
    onError: (err) => {
      setErrorMsg(
        err instanceof ApiClientError || err instanceof Error ? err.message : 'Create failed.'
      );
    },
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, nextStatus }: { id: string; nextStatus: ProductStatus }) =>
      updateAdminProduct(id, { status: nextStatus }),
    onSuccess: async (updated) => {
      await invalidateCatalog();
      setFeedback(`Updated "${updated.nameEn}" status to ${updated.status}.`);
      setErrorMsg(null);
    },
    onError: (err) => {
      setErrorMsg(
        err instanceof ApiClientError || err instanceof Error
          ? err.message
          : 'Could not update product status.'
      );
    },
  });

  const categories = categoriesQuery.data ?? [];
  const products: ProductSummaryDTO[] = productsQuery.data?.products ?? [];
  const selectedCategoryValue = categoryId || categories[0]?.id || '';

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex flex-col gap-4 border-b border-border pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1">
            <h2 className="font-display text-lg font-semibold text-ink">
              {t('admin.catalogTitle')}
            </h2>
            <p className="text-sm text-ink-muted">{t('admin.catalogDesc')}</p>
          </div>

          <Button
            type="button"
            onClick={() => {
              setErrorMsg(null);
              setCreateOpen(true);
            }}
          >
            <Plus className="size-4" aria-hidden="true" />
            {t('admin.newProductBtn')}
          </Button>
        </div>

        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
          <Input
            aria-label={t('shop.searchLabel')}
            placeholder={t('shop.searchPlaceholder')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="sm:max-w-xs"
          />

          <Select
            value={statusFilter}
            onValueChange={(val) => setStatusFilter(val as ProductStatus | typeof ALL_STATUS)}
          >
            <SelectTrigger aria-label="Filter product status" className="sm:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL_STATUS}>{t('admin.allStatuses')}</SelectItem>
              <SelectItem value="active">{t('common.active')}</SelectItem>
              <SelectItem value="draft">{t('common.draft')}</SelectItem>
              <SelectItem value="archived">{t('common.archived')}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {feedback ? (
          <div
            role="status"
            className="mt-4 flex items-center gap-2 rounded-xl border border-success/30 bg-success-soft px-4 py-2.5 text-sm text-success"
          >
            <CheckCircle2 className="size-4 shrink-0" aria-hidden="true" />
            <span>{feedback}</span>
          </div>
        ) : null}

        {errorMsg && !createOpen ? (
          <div
            role="alert"
            className="mt-4 rounded-xl border border-danger/30 bg-danger-soft px-4 py-2.5 text-sm text-danger"
          >
            {errorMsg}
          </div>
        ) : null}

        <div className="mt-5">
          {productsQuery.isLoading ? (
            <LoadingState label={t('common.loading')} />
          ) : productsQuery.isError ? (
            <div
              role="alert"
              className="rounded-xl border border-warning/30 bg-warning-soft p-4 text-sm text-warning"
            >
              {productsQuery.error instanceof Error
                ? productsQuery.error.message
                : 'Unable to load admin catalogue.'}
            </div>
          ) : products.length === 0 ? (
            <EmptyState
              icon={<Shirt className="size-6" />}
              title={t('shop.emptyTitle')}
              description="Create your first T-Shirt or Polo Shirt blank above."
            />
          ) : (
            <div className="divide-y divide-border rounded-xl border border-border">
              {products.map((item) => (
                <div
                  key={item.id}
                  data-testid={`admin-product-row-${item.slug}`}
                  className="flex flex-col gap-4 p-4 lg:flex-row lg:items-center lg:justify-between"
                >
                  <div className="flex items-start gap-3">
                    {item.primaryImage ? (
                      <img
                        src={item.primaryImage.url}
                        alt={item.nameEn}
                        width={56}
                        height={64}
                        className="h-16 w-14 shrink-0 rounded-lg border border-border bg-surface-muted object-contain p-1"
                      />
                    ) : null}
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-display font-semibold text-ink">
                          {pickLocalizedText(locale, item.nameEn, item.nameBn)}
                        </span>
                        <Badge
                          variant={
                            item.status === 'active'
                              ? 'success'
                              : item.status === 'draft'
                                ? 'warning'
                                : 'neutral'
                          }
                        >
                          {item.status.toUpperCase()}
                        </Badge>
                        {item.isCustomizable ? (
                          <Badge variant="accent" className="gap-1">
                            <Sparkles className="size-3" aria-hidden="true" />
                            {t('common.customizable')}
                          </Badge>
                        ) : null}
                      </div>

                      <p className="font-mono text-xs text-ink-muted">
                        {item.skuPrefix} · {formatBdtPrice(item.basePrice, item.currencyCode)} ·{' '}
                        {t('shop.variantsLabel', { count: item.variantCount })} · {item.totalStock}{' '}
                        units
                      </p>
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-ink-muted">
                        <Layers className="size-3.5 text-accent-royal" aria-hidden="true" />
                        <span>
                          {item.printSurfaces.length > 0
                            ? item.printSurfaces.join(', ')
                            : 'No print zones configured'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant="secondary"
                      onClick={() => setWorkspaceProductId(item.id)}
                    >
                      <Settings2 className="size-3.5" aria-hidden="true" />
                      {t('admin.manageProduct')}
                    </Button>

                    {item.status !== 'active' ? (
                      <Button
                        type="button"
                        size="sm"
                        disabled={statusMutation.isPending}
                        onClick={() => statusMutation.mutate({ id: item.id, nextStatus: 'active' })}
                      >
                        {t('admin.publishProduct')}
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        disabled={statusMutation.isPending}
                        onClick={() => statusMutation.mutate({ id: item.id, nextStatus: 'draft' })}
                      >
                        {t('admin.unpublishProduct')}
                      </Button>
                    )}

                    {item.status !== 'archived' ? (
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        disabled={statusMutation.isPending}
                        onClick={() =>
                          statusMutation.mutate({ id: item.id, nextStatus: 'archived' })
                        }
                      >
                        {t('admin.archiveProduct')}
                      </Button>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Card>

      {/* Create New Product Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('admin.createProductTitle')}</DialogTitle>
            <DialogDescription>
              Products start in Draft status so you can attach SKU variants and print zones before
              publishing.
            </DialogDescription>
          </DialogHeader>

          {errorMsg ? (
            <div
              role="alert"
              className="mt-3 rounded-xl border border-danger/30 bg-danger-soft px-3.5 py-2.5 text-sm text-danger"
            >
              {errorMsg}
            </div>
          ) : null}

          <div className="mt-4 space-y-4">
            <div className="grid gap-3 sm:grid-cols-3">
              <FormField id="create-cat" label="Category" required>
                <Select value={selectedCategoryValue} onValueChange={setCategoryId}>
                  <SelectTrigger id="create-cat">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {pickLocalizedText(locale, cat.nameEn, cat.nameBn)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </FormField>

              <FormField id="create-slug" label="URL Slug" required>
                <Input
                  id="create-slug"
                  value={slug}
                  onChange={(e) => setSlug(e.target.value)}
                  placeholder="dhaka-drop-tee"
                />
              </FormField>

              <FormField id="create-sku-prefix" label="SKU Prefix" required>
                <Input
                  id="create-sku-prefix"
                  value={skuPrefix}
                  onChange={(e) => setSkuPrefix(e.target.value)}
                  placeholder="YC-DROP"
                />
              </FormField>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <FormField id="create-name-en" label="Name (English)" required>
                <Input
                  id="create-name-en"
                  value={nameEn}
                  onChange={(e) => setNameEn(e.target.value)}
                  placeholder="Dhaka Heavyweight Drop Tee"
                />
              </FormField>
              <FormField id="create-name-bn" label="Name (বাংলা)" required>
                <Input
                  id="create-name-bn"
                  value={nameBn}
                  onChange={(e) => setNameBn(e.target.value)}
                  placeholder="ঢাকা হেভিওয়েট ড্রপ টি-শার্ট"
                />
              </FormField>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <FormField id="create-sub-en" label="Subtitle (English)">
                <Input
                  id="create-sub-en"
                  value={subtitleEn}
                  onChange={(e) => setSubtitleEn(e.target.value)}
                />
              </FormField>
              <FormField id="create-sub-bn" label="Subtitle (বাংলা)">
                <Input
                  id="create-sub-bn"
                  value={subtitleBn}
                  onChange={(e) => setSubtitleBn(e.target.value)}
                />
              </FormField>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <FormField id="create-desc-en" label="Description (English)" required>
                <Textarea
                  id="create-desc-en"
                  rows={3}
                  value={descriptionEn}
                  onChange={(e) => setDescriptionEn(e.target.value)}
                  placeholder="220 GSM combed cotton blank tailored for crisp DTF & screen prints."
                />
              </FormField>
              <FormField id="create-desc-bn" label="Description (বাংলা)" required>
                <Textarea
                  id="create-desc-bn"
                  rows={3}
                  value={descriptionBn}
                  onChange={(e) => setDescriptionBn(e.target.value)}
                  placeholder="ডিটিএফ ও স্ক্রিন প্রিন্টের জন্য উপযোগী ২২০ জিএসএম কম্বড কটন টি-শার্ট।"
                />
              </FormField>
            </div>

            <div className="grid gap-3 sm:grid-cols-4">
              <FormField id="create-price" label="Base Price (BDT)" required>
                <Input
                  id="create-price"
                  value={basePrice}
                  onChange={(e) => setBasePrice(e.target.value)}
                />
              </FormField>
              <FormField id="create-gsm" label="Fabric GSM">
                <Input
                  id="create-gsm"
                  type="number"
                  value={gsm}
                  onChange={(e) => setGsm(e.target.value)}
                />
              </FormField>
              <FormField id="create-fit" label="Fit Type">
                <Input
                  id="create-fit"
                  value={fitType}
                  onChange={(e) => setFitType(e.target.value)}
                />
              </FormField>
              <FormField id="create-img" label="Stage Image Path">
                <Input
                  id="create-img"
                  value={primaryImageUrl}
                  onChange={(e) => setPrimaryImageUrl(e.target.value)}
                />
              </FormField>
            </div>

            <Checkbox
              id="create-customizable"
              checked={isCustomizable}
              onChange={(e) => setIsCustomizable(e.target.checked)}
              label="Studio-customizable garment blank"
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="secondary"
              onClick={() => setCreateOpen(false)}
              disabled={createMutation.isPending}
            >
              {t('common.cancel')}
            </Button>
            <Button
              type="button"
              disabled={createMutation.isPending}
              onClick={() => createMutation.mutate()}
            >
              {createMutation.isPending ? t('common.loading') : t('common.create')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AdminProductWorkspaceDialog
        productId={workspaceProductId}
        open={Boolean(workspaceProductId)}
        onOpenChange={(open) => {
          if (!open) setWorkspaceProductId(null);
        }}
      />
    </div>
  );
}
