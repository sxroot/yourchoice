import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  GARMENT_SIZES,
  type GarmentSizeCode,
  PRINT_AREA_SURFACES,
  type PrintAreaSurfaceKey,
} from '@your-choice/shared-types';
import {
  createVariantSchema,
  updateProductSchema,
  upsertPrintAreaSchema,
} from '@your-choice/validation';
import {
  Badge,
  Button,
  Checkbox,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  FormField,
  Input,
  LoadingState,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@your-choice/ui';
import { Layers, Plus, Save, Trash2 } from 'lucide-react';
import { useState } from 'react';
import {
  addAdminVariant,
  deleteAdminVariant,
  fetchAdminProductById,
  updateAdminProduct,
  updateAdminVariant,
  upsertAdminPrintArea,
} from '@/features/catalog/catalog.api';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';

export interface AdminProductWorkspaceDialogProps {
  productId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AdminProductWorkspaceDialog({
  productId,
  open,
  onOpenChange,
}: AdminProductWorkspaceDialogProps) {
  const { locale, t } = useAppLocale();
  const queryClient = useQueryClient();

  const detailQuery = useQuery({
    queryKey: ['admin', 'product', productId],
    queryFn: ({ signal }) => fetchAdminProductById(productId!, signal),
    enabled: Boolean(open && productId),
    retry: false,
  });

  const product = detailQuery.data;

  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Quick product pricing/name edit state (seeded when editing)
  const [editBasePrice, setEditBasePrice] = useState<string>('');
  const [stockDrafts, setStockDrafts] = useState<Record<string, string>>({});

  // New Variant form state
  const [sku, setSku] = useState('');
  const [colorNameEn, setColorNameEn] = useState('Obsidian Black');
  const [colorNameBn, setColorNameBn] = useState('অবসিডিয়ান কালো');
  const [colorHex, setColorHex] = useState('#0F172A');
  const [sizeCode, setSizeCode] = useState<GarmentSizeCode>('M');
  const [priceOverride, setPriceOverride] = useState('');
  const [stockQuantity, setStockQuantity] = useState('25');

  // Print Area Config form state
  const [surfaceKey, setSurfaceKey] = useState<PrintAreaSurfaceKey>('front');
  const [labelEn, setLabelEn] = useState('Front Chest Print Zone');
  const [labelBn, setLabelBn] = useState('সামনের চেস্ট প্রিন্ট জোন');
  const [physicalWidthMm, setPhysicalWidthMm] = useState('280');
  const [physicalHeightMm, setPhysicalHeightMm] = useState('340');
  const [targetDpi, setTargetDpi] = useState('300');
  const [safeInsetMm, setSafeInsetMm] = useState('12');
  const [boundsX, setBoundsX] = useState('0.28');
  const [boundsY, setBoundsY] = useState('0.24');
  const [boundsW, setBoundsW] = useState('0.44');
  const [boundsH, setBoundsH] = useState('0.46');
  const [surchargeAmount, setSurchargeAmount] = useState('0.00');
  const [isDefaultArea, setIsDefaultArea] = useState(true);
  const [uvIslandKey, setUvIslandKey] = useState('front_torso');
  const [uvMeshTarget, setUvMeshTarget] = useState('garment_body');

  const invalidateProduct = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'products'] });
    if (productId) {
      await queryClient.invalidateQueries({ queryKey: ['admin', 'product', productId] });
    }
    await queryClient.invalidateQueries({ queryKey: ['catalog'] });
  };

  const updateProductMutation = useMutation({
    mutationFn: (basePrice: string) => {
      const parsed = updateProductSchema.safeParse({ basePrice });
      if (!parsed.success) {
        throw new Error(parsed.error.issues[0]?.message ?? 'Invalid base price');
      }
      return updateAdminProduct(product!.id, parsed.data);
    },
    onSuccess: async () => {
      await invalidateProduct();
      setEditBasePrice('');
      setStatusMessage('Product base price updated.');
      setErrorMessage(null);
    },
    onError: (err) => {
      setErrorMessage(
        err instanceof ApiClientError || err instanceof Error ? err.message : 'Update failed.'
      );
    },
  });

  const addVariantMutation = useMutation({
    mutationFn: () => {
      const parsed = createVariantSchema.safeParse({
        sku,
        colorNameEn,
        colorNameBn,
        colorHex,
        sizeCode,
        priceOverride: priceOverride.trim() || null,
        stockQuantity,
        isActive: true,
      });
      if (!parsed.success) {
        throw new Error(parsed.error.issues[0]?.message ?? 'Invalid variant details');
      }
      return addAdminVariant(product!.id, parsed.data);
    },
    onSuccess: async () => {
      await invalidateProduct();
      setSku('');
      setPriceOverride('');
      setStatusMessage('Variant SKU added.');
      setErrorMessage(null);
    },
    onError: (err) => {
      setErrorMessage(
        err instanceof ApiClientError || err instanceof Error
          ? err.message
          : 'Failed to add variant.'
      );
    },
  });

  const updateStockMutation = useMutation({
    mutationFn: ({ variantId, nextStock }: { variantId: string; nextStock: number }) =>
      updateAdminVariant(product!.id, variantId, { stockQuantity: nextStock }),
    onSuccess: async () => {
      await invalidateProduct();
      setStatusMessage('Variant stock updated.');
      setErrorMessage(null);
    },
    onError: (err) => {
      setErrorMessage(
        err instanceof ApiClientError || err instanceof Error ? err.message : 'Stock update failed.'
      );
    },
  });

  const deleteVariantMutation = useMutation({
    mutationFn: (variantId: string) => deleteAdminVariant(product!.id, variantId),
    onSuccess: async () => {
      await invalidateProduct();
      setStatusMessage('Variant deleted.');
      setErrorMessage(null);
    },
    onError: (err) => {
      setErrorMessage(
        err instanceof ApiClientError || err instanceof Error ? err.message : 'Delete failed.'
      );
    },
  });

  const upsertPrintAreaMutation = useMutation({
    mutationFn: () => {
      const parsed = upsertPrintAreaSchema.safeParse({
        surfaceKey,
        labelEn,
        labelBn,
        physicalWidthMm,
        physicalHeightMm,
        targetDpi,
        safeInsetMm,
        mockupBounds: {
          x: boundsX,
          y: boundsY,
          width: boundsW,
          height: boundsH,
          rotationDeg: 0,
        },
        uvRegion:
          uvIslandKey.trim() && uvMeshTarget.trim()
            ? {
                islandKey: uvIslandKey.trim(),
                meshTarget: uvMeshTarget.trim(),
                uMin: 0.1,
                uMax: 0.9,
                vMin: 0.1,
                vMax: 0.9,
              }
            : null,
        printMethods: ['dtf', 'screen_print'],
        surchargeAmount,
        isDefault: isDefaultArea,
        isActive: true,
        sortOrder: surfaceKey === 'front' ? 0 : surfaceKey === 'back' ? 1 : 2,
      });

      if (!parsed.success) {
        throw new Error(parsed.error.issues[0]?.message ?? 'Invalid print area configuration');
      }
      return upsertAdminPrintArea(product!.id, parsed.data);
    },
    onSuccess: async () => {
      await invalidateProduct();
      setStatusMessage(`Print area (${surfaceKey}) saved.`);
      setErrorMessage(null);
    },
    onError: (err) => {
      setErrorMessage(
        err instanceof ApiClientError || err instanceof Error
          ? err.message
          : 'Failed to save print area.'
      );
    },
  });

  const loadSurfaceIntoForm = (key: PrintAreaSurfaceKey) => {
    setSurfaceKey(key);
    const existing = product?.printAreas.find((pa) => pa.surfaceKey === key);
    if (existing) {
      setLabelEn(existing.labelEn);
      setLabelBn(existing.labelBn);
      setPhysicalWidthMm(String(existing.physicalWidthMm));
      setPhysicalHeightMm(String(existing.physicalHeightMm));
      setTargetDpi(String(existing.targetDpi));
      setSafeInsetMm(String(existing.safeInsetMm));
      setBoundsX(String(existing.mockupBounds.x));
      setBoundsY(String(existing.mockupBounds.y));
      setBoundsW(String(existing.mockupBounds.width));
      setBoundsH(String(existing.mockupBounds.height));
      setSurchargeAmount(existing.surchargeAmount);
      setIsDefaultArea(existing.isDefault);
      setUvIslandKey(existing.uvRegion?.islandKey ?? `${key}_torso`);
      setUvMeshTarget(existing.uvRegion?.meshTarget ?? 'garment_body');
      return;
    }

    if (key === 'left_chest') {
      setLabelEn('Left Chest Crest');
      setLabelBn('বাম চেস্ট ক্রেস্ট');
      setPhysicalWidthMm('100');
      setPhysicalHeightMm('100');
      setBoundsX('0.56');
      setBoundsY('0.26');
      setBoundsW('0.18');
      setBoundsH('0.18');
      setIsDefaultArea(false);
    } else if (key === 'back') {
      setLabelEn('Full Back Canvas');
      setLabelBn('পিছনের ফুল প্রিন্ট জোন');
      setPhysicalWidthMm('320');
      setPhysicalHeightMm('400');
      setBoundsX('0.26');
      setBoundsY('0.20');
      setBoundsW('0.48');
      setBoundsH('0.52');
      setIsDefaultArea(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>
            {product
              ? pickLocalizedText(locale, product.nameEn, product.nameBn)
              : t('admin.manageProduct')}
          </DialogTitle>
          <DialogDescription>
            {product
              ? `${product.skuPrefix} · ${product.status.toUpperCase()}`
              : t('common.loading')}
          </DialogDescription>
        </DialogHeader>

        {detailQuery.isLoading ? (
          <LoadingState label={t('common.loading')} />
        ) : !product ? (
          <div role="alert" className="rounded-xl bg-danger-soft p-4 text-sm text-danger">
            Unable to load product details.
          </div>
        ) : (
          <div className="mt-4 space-y-6">
            {statusMessage ? (
              <div
                role="status"
                className="rounded-xl border border-success/30 bg-success-soft px-4 py-2.5 text-sm text-success"
              >
                {statusMessage}
              </div>
            ) : null}

            {errorMessage ? (
              <div
                role="alert"
                className="rounded-xl border border-danger/30 bg-danger-soft px-4 py-2.5 text-sm text-danger"
              >
                {errorMessage}
              </div>
            ) : null}

            {/* Base BDT Price Quick Update */}
            <div className="flex flex-col gap-3 rounded-xl border border-border bg-surface-muted/40 p-4 sm:flex-row sm:items-end">
              <FormField
                id="admin-edit-base-price"
                label={`Base Price (Current: ${formatBdtPrice(product.basePrice, product.currencyCode)})`}
                className="flex-1"
              >
                <Input
                  id="admin-edit-base-price"
                  value={editBasePrice || product.basePrice}
                  onChange={(e) => setEditBasePrice(e.target.value)}
                  placeholder="690.00"
                />
              </FormField>
              <Button
                type="button"
                variant="secondary"
                disabled={updateProductMutation.isPending}
                onClick={() => updateProductMutation.mutate(editBasePrice || product.basePrice)}
              >
                <Save className="size-4" aria-hidden="true" />
                {t('common.save')}
              </Button>
            </div>

            {/* Variants Section */}
            <div className="space-y-4 border-t border-border pt-5">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-base font-semibold text-ink">
                  {t('admin.variantsSection')} ({product.variants.length})
                </h3>
              </div>

              {product.variants.length > 0 ? (
                <div className="divide-y divide-border rounded-xl border border-border">
                  {product.variants.map((variant) => {
                    const draftVal = stockDrafts[variant.id] ?? String(variant.stockQuantity);
                    return (
                      <div
                        key={variant.id}
                        className="flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
                      >
                        <div className="flex flex-wrap items-center gap-2.5">
                          <span
                            className="inline-block size-4 rounded-full border border-border-dark/25"
                            style={{ backgroundColor: variant.colorHex }}
                            aria-hidden="true"
                          />
                          <span className="font-mono text-xs font-semibold text-ink">
                            {variant.sku}
                          </span>
                          <Badge variant="neutral">{variant.sizeCode}</Badge>
                          <span className="text-xs text-ink-muted">
                            {pickLocalizedText(locale, variant.colorNameEn, variant.colorNameBn)} ·{' '}
                            {formatBdtPrice(variant.effectivePrice, variant.currencyCode)}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <Input
                            aria-label={`Stock for ${variant.sku}`}
                            type="number"
                            min={0}
                            value={draftVal}
                            onChange={(e) =>
                              setStockDrafts((prev) => ({
                                ...prev,
                                [variant.id]: e.target.value,
                              }))
                            }
                            className="w-24"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="secondary"
                            disabled={updateStockMutation.isPending}
                            onClick={() => {
                              const parsed = Number.parseInt(draftVal, 10);
                              if (!Number.isFinite(parsed) || parsed < 0) {
                                setErrorMessage('Stock quantity must be 0 or greater.');
                                return;
                              }
                              updateStockMutation.mutate({
                                variantId: variant.id,
                                nextStock: parsed,
                              });
                            }}
                          >
                            {t('common.save')}
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            disabled={deleteVariantMutation.isPending}
                            onClick={() => deleteVariantMutation.mutate(variant.id)}
                            className="text-danger hover:bg-danger-soft hover:text-danger"
                            aria-label={`Delete ${variant.sku}`}
                          >
                            <Trash2 className="size-4" aria-hidden="true" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-sm text-ink-muted">
                  No variants yet. At least one active variant is required before publishing live.
                </p>
              )}

              {/* Add Variant Form */}
              <div className="rounded-xl border border-dashed border-border bg-surface-muted/30 p-4">
                <p className="mb-3 text-xs font-semibold tracking-wider text-ink-muted uppercase">
                  {t('admin.addVariantBtn')}
                </p>
                <div className="grid gap-3 sm:grid-cols-4">
                  <FormField id="var-sku" label="SKU">
                    <Input
                      id="var-sku"
                      value={sku}
                      onChange={(e) => setSku(e.target.value)}
                      placeholder={`${product.skuPrefix}-BLK-M`}
                    />
                  </FormField>
                  <FormField id="var-size" label="Size">
                    <Select
                      value={sizeCode}
                      onValueChange={(val) => setSizeCode(val as GarmentSizeCode)}
                    >
                      <SelectTrigger id="var-size">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {GARMENT_SIZES.map((s) => (
                          <SelectItem key={s} value={s}>
                            {s}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormField>
                  <FormField id="var-stock" label="Stock">
                    <Input
                      id="var-stock"
                      type="number"
                      min={0}
                      value={stockQuantity}
                      onChange={(e) => setStockQuantity(e.target.value)}
                    />
                  </FormField>
                  <FormField id="var-override" label="BDT Override (optional)">
                    <Input
                      id="var-override"
                      value={priceOverride}
                      onChange={(e) => setPriceOverride(e.target.value)}
                      placeholder="e.g. 740.00"
                    />
                  </FormField>
                </div>

                <div className="mt-3 grid gap-3 sm:grid-cols-3">
                  <FormField id="var-color-en" label="Color (EN)">
                    <Input
                      id="var-color-en"
                      value={colorNameEn}
                      onChange={(e) => setColorNameEn(e.target.value)}
                    />
                  </FormField>
                  <FormField id="var-color-bn" label="Color (BN)">
                    <Input
                      id="var-color-bn"
                      value={colorNameBn}
                      onChange={(e) => setColorNameBn(e.target.value)}
                    />
                  </FormField>
                  <FormField id="var-hex" label="Color Hex">
                    <Input
                      id="var-hex"
                      value={colorHex}
                      onChange={(e) => setColorHex(e.target.value)}
                      placeholder="#0F172A"
                    />
                  </FormField>
                </div>

                <div className="mt-3 flex justify-end">
                  <Button
                    type="button"
                    size="sm"
                    disabled={addVariantMutation.isPending}
                    onClick={() => addVariantMutation.mutate()}
                  >
                    <Plus className="size-4" aria-hidden="true" />
                    {t('admin.addVariantBtn')}
                  </Button>
                </div>
              </div>
            </div>

            {/* Print Area Configurator */}
            <div className="space-y-4 border-t border-border pt-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="font-display text-base font-semibold text-ink">
                  {t('admin.printAreasSection')}
                </h3>
                <div className="flex flex-wrap gap-1.5">
                  {product.printAreas.map((area) => (
                    <Badge key={area.id} variant="accent" className="gap-1">
                      <Layers className="size-3" aria-hidden="true" />
                      {area.surfaceKey} ({area.physicalWidthMm}×{area.physicalHeightMm}mm)
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="rounded-xl border border-border bg-surface-muted/30 p-4 space-y-3">
                <div className="grid gap-3 sm:grid-cols-3">
                  <FormField id="pa-surface" label="Surface">
                    <Select
                      value={surfaceKey}
                      onValueChange={(val) => loadSurfaceIntoForm(val as PrintAreaSurfaceKey)}
                    >
                      <SelectTrigger id="pa-surface">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PRINT_AREA_SURFACES.map((surface) => (
                          <SelectItem key={surface} value={surface}>
                            {surface}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormField>
                  <FormField id="pa-label-en" label="Label (EN)">
                    <Input
                      id="pa-label-en"
                      value={labelEn}
                      onChange={(e) => setLabelEn(e.target.value)}
                    />
                  </FormField>
                  <FormField id="pa-label-bn" label="Label (BN)">
                    <Input
                      id="pa-label-bn"
                      value={labelBn}
                      onChange={(e) => setLabelBn(e.target.value)}
                    />
                  </FormField>
                </div>

                <div className="grid gap-3 sm:grid-cols-4">
                  <FormField id="pa-w-mm" label="Width (mm)">
                    <Input
                      id="pa-w-mm"
                      type="number"
                      value={physicalWidthMm}
                      onChange={(e) => setPhysicalWidthMm(e.target.value)}
                    />
                  </FormField>
                  <FormField id="pa-h-mm" label="Height (mm)">
                    <Input
                      id="pa-h-mm"
                      type="number"
                      value={physicalHeightMm}
                      onChange={(e) => setPhysicalHeightMm(e.target.value)}
                    />
                  </FormField>
                  <FormField id="pa-dpi" label="Target DPI">
                    <Input
                      id="pa-dpi"
                      type="number"
                      value={targetDpi}
                      onChange={(e) => setTargetDpi(e.target.value)}
                    />
                  </FormField>
                  <FormField id="pa-surcharge" label="Surcharge (BDT)">
                    <Input
                      id="pa-surcharge"
                      value={surchargeAmount}
                      onChange={(e) => setSurchargeAmount(e.target.value)}
                    />
                  </FormField>
                </div>

                <div className="grid gap-3 sm:grid-cols-4">
                  <FormField id="pa-bx" label="Bounds X [0..1]">
                    <Input
                      id="pa-bx"
                      value={boundsX}
                      onChange={(e) => setBoundsX(e.target.value)}
                    />
                  </FormField>
                  <FormField id="pa-by" label="Bounds Y [0..1]">
                    <Input
                      id="pa-by"
                      value={boundsY}
                      onChange={(e) => setBoundsY(e.target.value)}
                    />
                  </FormField>
                  <FormField id="pa-bw" label="Width [0..1]">
                    <Input
                      id="pa-bw"
                      value={boundsW}
                      onChange={(e) => setBoundsW(e.target.value)}
                    />
                  </FormField>
                  <FormField id="pa-bh" label="Height [0..1]">
                    <Input
                      id="pa-bh"
                      value={boundsH}
                      onChange={(e) => setBoundsH(e.target.value)}
                    />
                  </FormField>
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  <FormField id="pa-uv-island" label="3D UV Island Key">
                    <Input
                      id="pa-uv-island"
                      value={uvIslandKey}
                      onChange={(e) => setUvIslandKey(e.target.value)}
                    />
                  </FormField>
                  <FormField id="pa-uv-mesh" label="3D Mesh Target">
                    <Input
                      id="pa-uv-mesh"
                      value={uvMeshTarget}
                      onChange={(e) => setUvMeshTarget(e.target.value)}
                    />
                  </FormField>
                  <div className="flex items-end pb-1">
                    <Checkbox
                      id="pa-default"
                      checked={isDefaultArea}
                      onChange={(e) => setIsDefaultArea(e.target.checked)}
                      label="Default surface"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button
                    type="button"
                    size="sm"
                    disabled={upsertPrintAreaMutation.isPending}
                    onClick={() => upsertPrintAreaMutation.mutate()}
                  >
                    <Save className="size-4" aria-hidden="true" />
                    {t('admin.savePrintAreaBtn')}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
