import type { CartDTO } from '@your-choice/shared-types';
import { createContext, useContext } from 'react';

export const CART_QUERY_KEY = ['cart'] as const;

export interface CartContextValue {
  cart: CartDTO | null;
  itemCount: number;
  isLoading: boolean;
  isMutating: boolean;
  isDrawerOpen: boolean;
  openDrawer: () => void;
  closeDrawer: () => void;
  setDrawerOpen: (open: boolean) => void;
  addItem: (variantId: string, quantity: number) => Promise<CartDTO>;
  updateItemQuantity: (itemId: string, quantity: number) => Promise<CartDTO>;
  removeItem: (itemId: string) => Promise<CartDTO>;
  clearAllItems: () => Promise<CartDTO>;
  refreshCart: () => Promise<void>;
}

export const CartContext = createContext<CartContextValue | null>(null);

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) {
    throw new Error('useCart must be used within CartProvider');
  }
  return ctx;
}
