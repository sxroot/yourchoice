import type { CartDTO } from '@your-choice/shared-types';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Badge,
  Button,
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@your-choice/ui';
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react';
import { type ReactNode, useCallback, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';
import {
  addCartItem,
  clearCart,
  fetchCart,
  removeCartItem,
  updateCartItemQuantity,
} from './commerce.api';
import { CART_QUERY_KEY, CartContext, type CartContextValue } from './cart-context';

export function CartProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const { locale, t } = useAppLocale();
  const [isDrawerOpen, setDrawerOpen] = useState(false);
  const [drawerError, setDrawerError] = useState<string | null>(null);

  const cartQuery = useQuery({
    queryKey: CART_QUERY_KEY,
    queryFn: ({ signal }) => fetchCart(signal),
    staleTime: 30_000,
    retry: false,
  });

  const syncCartCache = useCallback(
    (updated: CartDTO) => {
      queryClient.setQueryData<CartDTO>(CART_QUERY_KEY, updated);
    },
    [queryClient]
  );

  const addMutation = useMutation({
    mutationFn: ({ variantId, quantity }: { variantId: string; quantity: number }) =>
      addCartItem(variantId, quantity),
    onSuccess: (updated) => {
      setDrawerError(null);
      syncCartCache(updated);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ itemId, quantity }: { itemId: string; quantity: number }) =>
      updateCartItemQuantity(itemId, quantity),
    onSuccess: (updated) => {
      setDrawerError(null);
      syncCartCache(updated);
    },
    onError: (err) => {
      setDrawerError(err instanceof ApiClientError ? err.message : t('cart.errorGeneric'));
    },
  });

  const removeMutation = useMutation({
    mutationFn: (itemId: string) => removeCartItem(itemId),
    onSuccess: (updated) => {
      setDrawerError(null);
      syncCartCache(updated);
    },
    onError: (err) => {
      setDrawerError(err instanceof ApiClientError ? err.message : t('cart.errorGeneric'));
    },
  });

  const clearMutation = useMutation({
    mutationFn: () => clearCart(),
    onSuccess: (updated) => {
      setDrawerError(null);
      syncCartCache(updated);
    },
  });

  const addItem = useCallback(
    async (variantId: string, quantity: number) => {
      const updated = await addMutation.mutateAsync({ variantId, quantity });
      setDrawerOpen(true);
      return updated;
    },
    [addMutation]
  );

  const updateItemQuantityFn = useCallback(
    async (itemId: string, quantity: number) => {
      return updateMutation.mutateAsync({ itemId, quantity });
    },
    [updateMutation]
  );

  const removeItemFn = useCallback(
    async (itemId: string) => {
      return removeMutation.mutateAsync(itemId);
    },
    [removeMutation]
  );

  const clearAllItems = useCallback(async () => clearMutation.mutateAsync(), [clearMutation]);

  const refreshCart = useCallback(async () => {
    await queryClient.invalidateQueries({ queryKey: CART_QUERY_KEY });
  }, [queryClient]);

  const cart = cartQuery.data ?? null;
  const itemCount = cart?.itemCount ?? 0;
  const isMutating =
    addMutation.isPending ||
    updateMutation.isPending ||
    removeMutation.isPending ||
    clearMutation.isPending;

  const value = useMemo<CartContextValue>(
    () => ({
      cart,
      itemCount,
      isLoading: cartQuery.isLoading,
      isMutating,
      isDrawerOpen,
      openDrawer: () => setDrawerOpen(true),
      closeDrawer: () => setDrawerOpen(false),
      setDrawerOpen,
      addItem,
      updateItemQuantity: updateItemQuantityFn,
      removeItem: removeItemFn,
      clearAllItems,
      refreshCart,
    }),
    [
      cart,
      itemCount,
      cartQuery.isLoading,
      isMutating,
      isDrawerOpen,
      addItem,
      updateItemQuantityFn,
      removeItemFn,
      clearAllItems,
      refreshCart,
    ]
  );

  return (
    <CartContext.Provider value={value}>
      {children}

      <Drawer open={isDrawerOpen} onOpenChange={setDrawerOpen}>
        <DrawerContent
          id="cart-slide-drawer"
          side="right"
          className="flex flex-col bg-surface"
          data-testid="cart-drawer"
        >
          <DrawerHeader className="border-b border-border pb-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="size-5 text-accent" aria-hidden="true" />
                <DrawerTitle className="text-base">{t('cart.drawerTitle')}</DrawerTitle>
              </div>
              <Badge variant="accent">{t('cart.itemCountLabel', { count: itemCount })}</Badge>
            </div>
            <DrawerDescription className="text-xs">{t('cart.drawerDesc')}</DrawerDescription>
          </DrawerHeader>

          {drawerError ? (
            <div
              role="alert"
              className="mt-3 rounded-xl border border-danger/30 bg-danger-soft px-3.5 py-2 text-xs text-danger"
            >
              {drawerError}
            </div>
          ) : null}

          <div className="mt-4 flex-1 space-y-3 overflow-y-auto pr-1">
            {!cart || cart.items.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-surface-muted/40 px-5 py-10 text-center">
                <ShoppingBag className="size-8 text-ink-muted" aria-hidden="true" />
                <p className="mt-3 font-display text-base font-semibold text-ink">
                  {t('cart.emptyTitle')}
                </p>
                <p className="mt-1 text-xs text-ink-muted">{t('cart.emptyDesc')}</p>
                <Button
                  asChild
                  size="sm"
                  variant="secondary"
                  className="mt-4"
                  onClick={() => setDrawerOpen(false)}
                >
                  <Link to="/shop">{t('cart.browseCatalogue')}</Link>
                </Button>
              </div>
            ) : (
              cart.items.map((item) => {
                const name = pickLocalizedText(locale, item.productNameEn, item.productNameBn);
                const color = pickLocalizedText(locale, item.colorNameEn, item.colorNameBn);
                return (
                  <div
                    key={item.id}
                    className="flex gap-3 rounded-2xl border border-border bg-surface p-3 shadow-xs"
                  >
                    <div className="size-16 shrink-0 overflow-hidden rounded-xl border border-border bg-surface-muted">
                      {item.primaryImageUrl ? (
                        <img
                          src={item.primaryImageUrl}
                          alt={name}
                          className="h-full w-full object-cover"
                        />
                      ) : null}
                    </div>

                    <div className="min-w-0 flex-1 space-y-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <Link
                          to={`/product/${item.productSlug}`}
                          onClick={() => setDrawerOpen(false)}
                          className="line-clamp-1 font-display text-sm font-semibold text-ink hover:text-accent"
                        >
                          {name}
                        </Link>
                        <button
                          type="button"
                          aria-label={t('cart.removeItem')}
                          disabled={isMutating}
                          onClick={() => void removeItemFn(item.id)}
                          className="inline-flex min-h-9 min-w-9 shrink-0 cursor-pointer items-center justify-center rounded-lg text-ink-muted transition-colors hover:bg-danger-soft hover:text-danger"
                        >
                          <Trash2 className="size-4" aria-hidden="true" />
                        </button>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-ink-muted">
                        <span
                          className="inline-block size-3 rounded-full border border-border-dark/30"
                          style={{ backgroundColor: item.colorHex }}
                          aria-hidden="true"
                        />
                        <span>{color}</span>
                        <span>·</span>
                        <span className="font-mono font-semibold text-ink">{item.sizeCode}</span>
                        <span>·</span>
                        <span className="font-mono">{formatBdtPrice(item.unitPrice)}</span>
                      </div>

                      {item.designPublicId && item.customizationMeta ? (
                        <div className="flex flex-wrap items-center gap-1.5 rounded-lg border border-accent/30 bg-accent-soft px-2 py-1 text-[11px] text-accent-ink">
                          <Badge variant="accent" className="px-1.5 py-0 text-[10px]">
                            {t('cart.customDesignLabel')}
                          </Badge>
                          <span className="truncate font-semibold">
                            {item.customizationMeta.designTitle ?? 'Custom Print'}
                          </span>
                          {Number.parseFloat(item.customizationFee) > 0 ? (
                            <span className="font-mono">
                              (+{formatBdtPrice(item.customizationFee)})
                            </span>
                          ) : null}
                        </div>
                      ) : null}

                      {!item.isVariantAvailable ? (
                        <p className="text-xs font-medium text-danger">
                          {t('cart.unavailableNotice')}
                        </p>
                      ) : null}

                      <div className="flex items-center justify-between pt-1">
                        <div className="inline-flex items-center rounded-xl border border-border bg-surface-muted/50">
                          <button
                            type="button"
                            aria-label={t('cart.decreaseQty')}
                            disabled={isMutating || item.quantity <= 1}
                            onClick={() => void updateItemQuantityFn(item.id, item.quantity - 1)}
                            className="inline-flex min-h-10 min-w-10 cursor-pointer items-center justify-center rounded-l-xl text-ink hover:bg-surface disabled:cursor-not-allowed disabled:opacity-40"
                          >
                            <Minus className="size-3.5" aria-hidden="true" />
                          </button>
                          <span className="min-w-8 text-center font-mono text-xs font-semibold text-ink">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            aria-label={t('cart.increaseQty')}
                            disabled={isMutating || item.quantity >= item.availableStock}
                            onClick={() => void updateItemQuantityFn(item.id, item.quantity + 1)}
                            className="inline-flex min-h-10 min-w-10 cursor-pointer items-center justify-center rounded-r-xl text-ink hover:bg-surface disabled:cursor-not-allowed disabled:opacity-40"
                          >
                            <Plus className="size-3.5" aria-hidden="true" />
                          </button>
                        </div>

                        <span className="font-mono text-sm font-bold text-ink">
                          {formatBdtPrice(item.lineTotal, item.currencyCode)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {cart && cart.items.length > 0 ? (
            <DrawerFooter className="mt-4 space-y-3 border-t border-border pt-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-ink-muted">{t('cart.subtotalLabel')}</span>
                <span className="font-mono text-base font-bold text-ink">
                  {formatBdtPrice(cart.subtotal, cart.currencyCode)}
                </span>
              </div>
              <p className="text-xs text-ink-muted">{t('cart.shippingCalculatedNext')}</p>

              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <Button
                  asChild
                  variant="secondary"
                  className="w-full"
                  onClick={() => setDrawerOpen(false)}
                >
                  <Link to="/cart">{t('cart.viewCart')}</Link>
                </Button>
                <Button
                  asChild
                  variant="primary"
                  className="w-full"
                  onClick={() => setDrawerOpen(false)}
                >
                  <Link to="/checkout">
                    <span>{t('cart.proceedCheckout')}</span>
                    <ArrowRight className="size-4" aria-hidden="true" />
                  </Link>
                </Button>
              </div>
            </DrawerFooter>
          ) : null}
        </DrawerContent>
      </Drawer>
    </CartContext.Provider>
  );
}
