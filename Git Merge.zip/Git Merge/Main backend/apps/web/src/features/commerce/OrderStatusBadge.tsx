import type { OrderStatus, PaymentStatus } from '@your-choice/shared-types';
import { Badge, type BadgeProps } from '@your-choice/ui';
import { useAppLocale } from '@/i18n';

const ORDER_STATUS_VARIANT: Record<OrderStatus, BadgeProps['variant']> = {
  pending: 'warning',
  confirmed: 'accent',
  processing: 'accent',
  packed: 'accent',
  shipped: 'accent',
  delivered: 'success',
  cancelled: 'danger',
};

const PAYMENT_STATUS_VARIANT: Record<PaymentStatus, BadgeProps['variant']> = {
  unpaid: 'warning',
  pending: 'neutral',
  paid: 'success',
  failed: 'danger',
  refunded: 'neutral',
};

export function OrderStatusBadge({ status }: { status: OrderStatus }) {
  const { t } = useAppLocale();
  return <Badge variant={ORDER_STATUS_VARIANT[status]}>{t(`orders.status.${status}`)}</Badge>;
}

export function PaymentStatusBadge({ status }: { status: PaymentStatus }) {
  const { t } = useAppLocale();
  return (
    <Badge variant={PAYMENT_STATUS_VARIANT[status]}>{t(`orders.paymentStatus.${status}`)}</Badge>
  );
}
