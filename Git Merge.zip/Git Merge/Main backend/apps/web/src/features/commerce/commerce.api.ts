import type {
  BangladeshDivision,
  CartDTO,
  CartResponseData,
  CheckoutOptionsResponseData,
  OrderDetailDTO,
  OrderDetailResponseData,
  OrderListResponseData,
  OrderStatus,
  ShippingQuoteDTO,
  ShippingQuoteResponseData,
  ShippingZoneDTO,
  ShippingZonesResponseData,
} from '@your-choice/shared-types';
import type {
  AdminSettleCodPaymentInput,
  AdminUpdateOrderStatusInput,
  CancelOwnOrderInput,
  CreateOrderInput,
} from '@your-choice/validation';
import { apiDelete, apiGet, apiPatch, apiPost } from '@/services/api-client';

export async function fetchCart(signal?: AbortSignal): Promise<CartDTO> {
  const response = await apiGet<CartResponseData>('/cart', signal);
  if (!response.success) {
    throw new Error('Unable to load shopping cart');
  }
  return response.data.cart;
}

export async function addCartItem(variantId: string, quantity: number): Promise<CartDTO> {
  const response = await apiPost<CartResponseData>('/cart/items', { variantId, quantity });
  if (!response.success) {
    throw new Error('Unable to add item to cart');
  }
  return response.data.cart;
}

export async function updateCartItemQuantity(itemId: string, quantity: number): Promise<CartDTO> {
  const response = await apiPatch<CartResponseData>(`/cart/items/${itemId}`, { quantity });
  if (!response.success) {
    throw new Error('Unable to update cart item quantity');
  }
  return response.data.cart;
}

export async function removeCartItem(itemId: string): Promise<CartDTO> {
  const response = await apiDelete<CartResponseData>(`/cart/items/${itemId}`);
  if (!response.success) {
    throw new Error('Unable to remove cart item');
  }
  return response.data.cart;
}

export async function clearCart(): Promise<CartDTO> {
  const response = await apiDelete<CartResponseData>('/cart');
  if (!response.success) {
    throw new Error('Unable to clear cart');
  }
  return response.data.cart;
}

export async function fetchShippingZones(signal?: AbortSignal): Promise<ShippingZoneDTO[]> {
  const response = await apiGet<ShippingZonesResponseData>('/shipping/zones', signal);
  if (!response.success) {
    throw new Error('Unable to load shipping zones');
  }
  return response.data.zones;
}

export async function fetchShippingQuote(
  division: BangladeshDivision,
  subtotal: string,
  signal?: AbortSignal
): Promise<ShippingQuoteDTO> {
  const params = new URLSearchParams({ division, subtotal });
  const response = await apiGet<ShippingQuoteResponseData>(
    `/shipping/quote?${params.toString()}`,
    signal
  );
  if (!response.success) {
    throw new Error('Unable to calculate shipping fee');
  }
  return response.data.quote;
}

export async function fetchCheckoutOptions(
  signal?: AbortSignal
): Promise<CheckoutOptionsResponseData> {
  const response = await apiGet<CheckoutOptionsResponseData>('/checkout/options', signal);
  if (!response.success) {
    throw new Error('Unable to load checkout options');
  }
  return response.data;
}

export async function placeOrder(input: CreateOrderInput): Promise<OrderDetailDTO> {
  const response = await apiPost<OrderDetailResponseData>('/orders', input);
  if (!response.success) {
    throw new Error('Unable to place order');
  }
  return response.data.order;
}

export async function fetchMyOrders(
  page = 1,
  pageSize = 20,
  signal?: AbortSignal
): Promise<OrderListResponseData> {
  const params = new URLSearchParams({ page: String(page), pageSize: String(pageSize) });
  const response = await apiGet<OrderListResponseData>(`/orders?${params.toString()}`, signal);
  if (!response.success) {
    throw new Error('Unable to load order history');
  }
  return response.data;
}

export async function fetchOrderDetail(
  orderNumber: string,
  signal?: AbortSignal
): Promise<OrderDetailDTO> {
  const response = await apiGet<OrderDetailResponseData>(`/orders/${orderNumber}`, signal);
  if (!response.success) {
    throw new Error('Unable to load order details');
  }
  return response.data.order;
}

export async function cancelOwnOrder(
  orderNumber: string,
  input: CancelOwnOrderInput = {}
): Promise<OrderDetailDTO> {
  const response = await apiPost<OrderDetailResponseData>(`/orders/${orderNumber}/cancel`, input);
  if (!response.success) {
    throw new Error('Unable to cancel order');
  }
  return response.data.order;
}

export interface AdminOrderFilterParams {
  status?: OrderStatus;
  search?: string;
  page?: number;
  pageSize?: number;
}

export async function fetchAdminOrders(
  params: AdminOrderFilterParams,
  signal?: AbortSignal
): Promise<OrderListResponseData> {
  const sp = new URLSearchParams();
  if (params.status) sp.set('status', params.status);
  if (params.search && params.search.trim()) sp.set('search', params.search.trim());
  if (params.page) sp.set('page', String(params.page));
  if (params.pageSize) sp.set('pageSize', String(params.pageSize));
  const qs = sp.toString();

  const response = await apiGet<OrderListResponseData>(
    `/admin/orders${qs ? `?${qs}` : ''}`,
    signal
  );
  if (!response.success) {
    throw new Error('Unable to load admin orders');
  }
  return response.data;
}

export async function fetchAdminOrderDetail(
  orderNumber: string,
  signal?: AbortSignal
): Promise<OrderDetailDTO> {
  const response = await apiGet<OrderDetailResponseData>(`/admin/orders/${orderNumber}`, signal);
  if (!response.success) {
    throw new Error('Unable to load admin order details');
  }
  return response.data.order;
}

export async function updateAdminOrderStatus(
  orderNumber: string,
  input: AdminUpdateOrderStatusInput
): Promise<OrderDetailDTO> {
  const response = await apiPatch<OrderDetailResponseData>(
    `/admin/orders/${orderNumber}/status`,
    input
  );
  if (!response.success) {
    throw new Error('Unable to update order status');
  }
  return response.data.order;
}

export async function settleAdminCodPayment(
  orderNumber: string,
  input: AdminSettleCodPaymentInput
): Promise<OrderDetailDTO> {
  const response = await apiPost<OrderDetailResponseData>(
    `/admin/orders/${orderNumber}/payment-settlement`,
    input
  );
  if (!response.success) {
    throw new Error('Unable to settle COD payment');
  }
  return response.data.order;
}
