import type { ProductSummaryDTO } from '@your-choice/shared-types';
import { Badge, Button, Card } from '@your-choice/ui';
import { ArrowRight, ArrowUpRight, Layers, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';

export interface ProductCardProps {
  product: ProductSummaryDTO;
  presentation?: 'default' | 'editorial';
}

export function ProductCard({ product, presentation = 'default' }: ProductCardProps) {
  const { locale, t } = useAppLocale();
  const title = pickLocalizedText(locale, product.nameEn, product.nameBn);
  const subtitle = pickLocalizedText(locale, product.subtitleEn, product.subtitleBn);
  const categoryName = pickLocalizedText(locale, product.category.nameEn, product.category.nameBn);
  const imageAlt = product.primaryImage
    ? pickLocalizedText(locale, product.primaryImage.altTextEn, product.primaryImage.altTextBn)
    : title;

  const priceDisplay =
    product.minPrice === product.maxPrice
      ? formatBdtPrice(product.minPrice, product.currencyCode)
      : `${formatBdtPrice(product.minPrice, product.currencyCode)} – ${formatBdtPrice(
          product.maxPrice,
          product.currencyCode
        )}`;

  if (presentation === 'editorial') {
    return (
      <article className="home-product-card">
        <Link to={`/product/${product.slug}`} className="home-product-card__visual">
          {product.primaryImage ? (
            <img
              src={product.primaryImage.url}
              alt={imageAlt}
              loading="lazy"
              width={800}
              height={960}
              decoding="async"
              className="home-product-card__image"
            />
          ) : (
            <span className="home-product-card__fallback">{title}</span>
          )}
          <span className="home-product-card__category">{categoryName}</span>
          {product.isCustomizable ? (
            <span className="home-product-card__custom">
              <Sparkles className="size-3" aria-hidden="true" />
              {t('common.customizable')}
            </span>
          ) : null}
          <span className="home-product-card__open" aria-hidden="true">
            <ArrowRight className="size-4" />
          </span>
        </Link>

        <div className="home-product-card__details">
          <div className="home-product-card__title-row">
            <div>
              <h3>
                <Link to={`/product/${product.slug}`}>{title}</Link>
              </h3>
              {subtitle ? <p className="home-product-card__subtitle">{subtitle}</p> : null}
            </div>
            <span className="home-product-card__price">{priceDisplay}</span>
          </div>

          <div className="home-product-card__footer">
            <div className="home-product-card__swatches" aria-label="Available colors">
              {product.availableColors.slice(0, 5).map((swatch) => (
                <span
                  key={swatch.colorHex}
                  title={pickLocalizedText(locale, swatch.colorNameEn, swatch.colorNameBn)}
                  style={{ backgroundColor: swatch.colorHex }}
                />
              ))}
              <span className="home-product-card__sizes">
                {product.availableSizes.slice(0, 4).join(' · ')}
              </span>
            </div>
            <Link to={`/product/${product.slug}`} className="home-product-card__view">
              {t('shop.inspectProduct')}
              <ArrowUpRight className="size-4" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </article>
    );
  }

  return (
    <Card className="group flex h-full flex-col overflow-hidden p-0 transition-shadow hover:shadow-elevated">
      <Link
        to={`/product/${product.slug}`}
        className="relative block aspect-[5/6] overflow-hidden bg-surface-muted/70"
      >
        {product.primaryImage ? (
          <img
            src={product.primaryImage.url}
            alt={imageAlt}
            loading="lazy"
            width={800}
            height={960}
            className="h-full w-full object-contain p-3 transition-transform duration-300 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-sm text-ink-muted">
            {title}
          </div>
        )}

        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
          <Badge variant="neutral">{categoryName}</Badge>
          {product.isCustomizable ? (
            <Badge variant="accent" className="gap-1">
              <Sparkles className="size-3" aria-hidden="true" />
              {t('common.customizable')}
            </Badge>
          ) : null}
        </div>

        {product.gsm ? (
          <span className="absolute right-3 bottom-3 rounded-md bg-surface-dark/85 px-2 py-0.5 font-mono text-[11px] font-medium text-ink-inverse">
            {product.gsm} GSM
          </span>
        ) : null}
      </Link>

      <div className="flex flex-1 flex-col justify-between gap-4 p-5">
        <div className="space-y-2">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-display text-lg font-semibold leading-snug text-ink">
              <Link to={`/product/${product.slug}`} className="hover:text-accent-ink">
                {title}
              </Link>
            </h3>
          </div>
          {subtitle ? <p className="text-xs leading-relaxed text-ink-muted">{subtitle}</p> : null}

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <div className="flex items-center gap-1" aria-label="Available colorways">
              {product.availableColors.map((swatch) => (
                <span
                  key={swatch.colorHex}
                  title={pickLocalizedText(locale, swatch.colorNameEn, swatch.colorNameBn)}
                  className="inline-block size-4 rounded-full border border-border-dark/25"
                  style={{ backgroundColor: swatch.colorHex }}
                />
              ))}
            </div>
            <span className="text-xs text-ink-muted">·</span>
            <span className="font-mono text-xs text-ink-muted">
              {product.availableSizes.join(' · ') || '—'}
            </span>
          </div>
        </div>

        <div className="space-y-3 border-t border-border pt-3">
          <div className="flex items-center justify-between gap-2">
            <p className="font-display text-base font-bold text-ink">{priceDisplay}</p>
            <span className="inline-flex items-center gap-1 text-xs text-ink-muted">
              <Layers className="size-3.5 text-accent-royal" aria-hidden="true" />
              {t('shop.surfacesLabel', { count: product.printSurfaces.length })}
            </span>
          </div>

          <Button asChild variant="secondary" size="sm" className="w-full justify-between">
            <Link to={`/product/${product.slug}`}>
              <span>{t('shop.inspectProduct')}</span>
              <ArrowRight className="size-4" aria-hidden="true" />
            </Link>
          </Button>
        </div>
      </div>
    </Card>
  );
}
