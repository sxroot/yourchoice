import type {
  AdminCategoryMutationResponseData,
  AdminProductMutationResponseData,
  CatalogSortOption,
  CategoryListResponseData,
  GarmentSizeCode,
  ProductCategoryDTO,
  ProductDetailDTO,
  ProductDetailResponseData,
  ProductImageDTO,
  ProductListResponseData,
  ProductPrintAreaDTO,
  ProductStatus,
  ProductVariantDTO,
} from '@your-choice/shared-types';
import type {
  CreateCategoryInput,
  CreateProductImageInput,
  CreateProductInput,
  CreateVariantInput,
  UpdateProductInput,
  UpdateVariantInput,
  UpsertPrintAreaInput,
} from '@your-choice/validation';
import { apiDelete, apiGet, apiPatch, apiPost, apiPut } from '@/services/api-client';

export interface PublicCatalogFilterParams {
  category?: string;
  search?: string;
  size?: GarmentSizeCode;
  color?: string;
  customizable?: boolean;
  sort?: CatalogSortOption;
  page?: number;
  pageSize?: number;
}

function buildCatalogQueryString(
  params: PublicCatalogFilterParams & { status?: ProductStatus }
): string {
  const searchParams = new URLSearchParams();
  if (params.category) searchParams.set('category', params.category);
  if (params.search && params.search.trim()) searchParams.set('search', params.search.trim());
  if (params.size) searchParams.set('size', params.size);
  if (params.color) searchParams.set('color', params.color);
  if (params.customizable !== undefined)
    searchParams.set('customizable', String(params.customizable));
  if (params.sort) searchParams.set('sort', params.sort);
  if (params.page) searchParams.set('page', String(params.page));
  if (params.pageSize) searchParams.set('pageSize', String(params.pageSize));
  if (params.status) searchParams.set('status', params.status);

  const query = searchParams.toString();
  return query ? `?${query}` : '';
}

export async function fetchPublicCategories(signal?: AbortSignal): Promise<ProductCategoryDTO[]> {
  const response = await apiGet<CategoryListResponseData>('/categories', signal);
  if (!response.success) {
    throw new Error('Unable to load categories');
  }
  return response.data.categories;
}

export async function fetchPublicProducts(
  params: PublicCatalogFilterParams,
  signal?: AbortSignal
): Promise<ProductListResponseData> {
  const qs = buildCatalogQueryString(params);
  const response = await apiGet<ProductListResponseData>(`/products${qs}`, signal);
  if (!response.success) {
    throw new Error('Unable to load products');
  }
  return response.data;
}

export async function fetchPublicProductBySlug(
  slug: string,
  signal?: AbortSignal
): Promise<ProductDetailDTO> {
  const response = await apiGet<ProductDetailResponseData>(`/products/${slug}`, signal);
  if (!response.success) {
    throw new Error('Unable to load product details');
  }
  return response.data.product;
}

export async function fetchAdminCategories(signal?: AbortSignal): Promise<ProductCategoryDTO[]> {
  const response = await apiGet<CategoryListResponseData>('/admin/categories', signal);
  if (!response.success) {
    throw new Error('Unable to load admin categories');
  }
  return response.data.categories;
}

export async function createAdminCategory(input: CreateCategoryInput): Promise<ProductCategoryDTO> {
  const response = await apiPost<AdminCategoryMutationResponseData>('/admin/categories', input);
  if (!response.success) {
    throw new Error('Unable to create category');
  }
  return response.data.category;
}

export async function fetchAdminProducts(
  params: PublicCatalogFilterParams & { status?: ProductStatus },
  signal?: AbortSignal
): Promise<ProductListResponseData> {
  const qs = buildCatalogQueryString(params);
  const response = await apiGet<ProductListResponseData>(`/admin/products${qs}`, signal);
  if (!response.success) {
    throw new Error('Unable to load admin catalogue');
  }
  return response.data;
}

export async function fetchAdminProductById(
  productPublicId: string,
  signal?: AbortSignal
): Promise<ProductDetailDTO> {
  const response = await apiGet<ProductDetailResponseData>(
    `/admin/products/${productPublicId}`,
    signal
  );
  if (!response.success) {
    throw new Error('Unable to load product');
  }
  return response.data.product;
}

export async function createAdminProduct(input: CreateProductInput): Promise<ProductDetailDTO> {
  const response = await apiPost<AdminProductMutationResponseData>('/admin/products', input);
  if (!response.success) {
    throw new Error('Unable to create product');
  }
  return response.data.product;
}

export async function updateAdminProduct(
  productPublicId: string,
  input: UpdateProductInput
): Promise<ProductDetailDTO> {
  const response = await apiPatch<AdminProductMutationResponseData>(
    `/admin/products/${productPublicId}`,
    input
  );
  if (!response.success) {
    throw new Error('Unable to update product');
  }
  return response.data.product;
}

export async function deleteAdminProduct(productPublicId: string): Promise<string> {
  const response = await apiDelete<{ deletedId: string }>(`/admin/products/${productPublicId}`);
  if (!response.success) {
    throw new Error('Unable to delete product');
  }
  return response.data.deletedId;
}

export async function addAdminProductImage(
  productPublicId: string,
  input: CreateProductImageInput
): Promise<ProductImageDTO> {
  const response = await apiPost<{ image: ProductImageDTO }>(
    `/admin/products/${productPublicId}/images`,
    input
  );
  if (!response.success) {
    throw new Error('Unable to add product image');
  }
  return response.data.image;
}

export async function addAdminVariant(
  productPublicId: string,
  input: CreateVariantInput
): Promise<ProductVariantDTO> {
  const response = await apiPost<{ variant: ProductVariantDTO }>(
    `/admin/products/${productPublicId}/variants`,
    input
  );
  if (!response.success) {
    throw new Error('Unable to add variant');
  }
  return response.data.variant;
}

export async function updateAdminVariant(
  productPublicId: string,
  variantPublicId: string,
  input: UpdateVariantInput
): Promise<ProductVariantDTO> {
  const response = await apiPatch<{ variant: ProductVariantDTO }>(
    `/admin/products/${productPublicId}/variants/${variantPublicId}`,
    input
  );
  if (!response.success) {
    throw new Error('Unable to update variant');
  }
  return response.data.variant;
}

export async function deleteAdminVariant(
  productPublicId: string,
  variantPublicId: string
): Promise<string> {
  const response = await apiDelete<{ deletedId: string }>(
    `/admin/products/${productPublicId}/variants/${variantPublicId}`
  );
  if (!response.success) {
    throw new Error('Unable to delete variant');
  }
  return response.data.deletedId;
}

export async function upsertAdminPrintArea(
  productPublicId: string,
  input: UpsertPrintAreaInput
): Promise<ProductPrintAreaDTO> {
  const response = await apiPut<{ printArea: ProductPrintAreaDTO }>(
    `/admin/products/${productPublicId}/print-areas`,
    input
  );
  if (!response.success) {
    throw new Error('Unable to save print area');
  }
  return response.data.printArea;
}
