import type { ProductImageDTO, ProductPrintAreaDTO } from '@your-choice/shared-types';
import { Badge } from '@your-choice/ui';
import { Layers, Maximize2 } from 'lucide-react';
import { pickLocalizedText, useAppLocale } from '@/i18n';

export interface GarmentStagePreviewProps {
  image: ProductImageDTO | null;
  productName: string;
  activeColorHex?: string;
  activeColorName?: string;
  activePrintArea: ProductPrintAreaDTO | null;
  showPrintGuide: boolean;
}

/**
 * Renders the product stage view along with an optional editor-agnostic normalized [0..1]
 * print-area bounding guide for front, back, or left-chest studio surfaces.
 */
export function GarmentStagePreview({
  image,
  productName,
  activeColorHex,
  activeColorName,
  activePrintArea,
  showPrintGuide,
}: GarmentStagePreviewProps) {
  const { locale } = useAppLocale();
  const altText = image ? pickLocalizedText(locale, image.altTextEn, image.altTextBn) : productName;

  const printLabel = activePrintArea
    ? pickLocalizedText(locale, activePrintArea.labelEn, activePrintArea.labelBn)
    : null;

  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-surface-muted/60">
      <div className="relative mx-auto aspect-[5/6] w-full max-w-lg select-none">
        {image ? (
          <img
            src={image.url}
            alt={altText}
            width={800}
            height={960}
            className="h-full w-full object-contain"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-surface-muted text-sm text-ink-muted">
            {productName}
          </div>
        )}

        {showPrintGuide && activePrintArea ? (
          <div
            data-testid="print-area-overlay"
            aria-label={printLabel ?? activePrintArea.surfaceKey}
            style={{
              left: `${activePrintArea.mockupBounds.x * 100}%`,
              top: `${activePrintArea.mockupBounds.y * 100}%`,
              width: `${activePrintArea.mockupBounds.width * 100}%`,
              height: `${activePrintArea.mockupBounds.height * 100}%`,
              transform: activePrintArea.mockupBounds.rotationDeg
                ? `rotate(${activePrintArea.mockupBounds.rotationDeg}deg)`
                : undefined,
            }}
            className="pointer-events-none absolute flex flex-col items-center justify-between rounded-lg border-2 border-dashed border-accent-cyan-bright bg-accent-electric/15 p-1.5 shadow-[0_0_0_1px_rgba(37,99,235,0.35)]"
          >
            <span className="inline-flex items-center gap-1 rounded bg-surface-dark/90 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-accent-cyan-bright">
              <Maximize2 className="size-2.5" aria-hidden="true" />
              {activePrintArea.physicalWidthMm}×{activePrintArea.physicalHeightMm}mm
            </span>
            <span className="rounded bg-surface-dark/85 px-1.5 py-0.5 text-center text-[10px] font-medium text-white">
              {printLabel}
            </span>
          </div>
        ) : null}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border bg-surface px-4 py-3 text-xs">
        <div className="flex items-center gap-2">
          {activeColorHex ? (
            <span className="inline-flex items-center gap-1.5 font-medium text-ink">
              <span
                className="inline-block size-3.5 rounded-full border border-border-dark/30"
                style={{ backgroundColor: activeColorHex }}
                aria-hidden="true"
              />
              {activeColorName}
            </span>
          ) : null}
        </div>

        <div className="flex items-center gap-1.5">
          {activePrintArea ? (
            <Badge variant="accent" className="gap-1">
              <Layers className="size-3" aria-hidden="true" />
              <span>
                {activePrintArea.targetDpi} DPI · {activePrintArea.surfaceKey}
              </span>
            </Badge>
          ) : null}
        </div>
      </div>
    </div>
  );
}
