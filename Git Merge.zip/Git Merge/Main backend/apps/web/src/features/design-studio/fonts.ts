import '@fontsource/baloo-da-2/400.css';
import '@fontsource/baloo-da-2/600.css';
import '@fontsource/baloo-da-2/700.css';
import '@fontsource/barlow-condensed/400.css';
import '@fontsource/barlow-condensed/600.css';
import '@fontsource/barlow-condensed/700.css';
import '@fontsource/bebas-neue/400.css';
import '@fontsource/noto-sans-bengali/400.css';
import '@fontsource/noto-sans-bengali/600.css';
import '@fontsource/noto-sans-bengali/700.css';
import '@fontsource/outfit/400.css';
import '@fontsource/outfit/600.css';
import '@fontsource/outfit/700.css';
import '@fontsource/syne/400.css';
import '@fontsource/syne/600.css';
import '@fontsource/syne/700.css';
import { STUDIO_FONT_PRESETS, type StudioFontPreset } from '@your-choice/shared-types';

let fontsPreloadPromise: Promise<void> | null = null;

export function getStudioFontPreset(family: string): StudioFontPreset {
  return STUDIO_FONT_PRESETS.find((preset) => preset.family === family) ?? STUDIO_FONT_PRESETS[0]!;
}

/**
 * Ensures locally hosted commercial-safe Latin + Bengali studio fonts are loaded in document.fonts
 * before Fabric.js measures glyph bounding boxes or re-renders text layers.
 */
export async function ensureStudioFontsLoaded(): Promise<void> {
  if (typeof document === 'undefined' || !('fonts' in document)) {
    return;
  }

  if (!fontsPreloadPromise) {
    fontsPreloadPromise = Promise.allSettled(
      STUDIO_FONT_PRESETS.flatMap((preset) =>
        preset.weights.map((weight) =>
          document.fonts.load(`${weight} 36px "${preset.family}"`, preset.sampleText)
        )
      )
    )
      .then(() => document.fonts.ready)
      .then(() => undefined);
  }

  await fontsPreloadPromise;
}
