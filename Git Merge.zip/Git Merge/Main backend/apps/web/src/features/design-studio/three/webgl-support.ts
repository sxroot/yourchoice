import type {
  PrintAreaSurfaceKey,
  ProductDetailDTO,
  ProductPrintAreaDTO,
} from '@your-choice/shared-types';

export type StudioCameraPreset = 'three_quarter' | 'front' | 'back' | 'left_chest' | 'collar';

export type StudioLightingPreset = 'studio' | 'daylight';

export interface WebGLCapabilityReport {
  supported: boolean;
  isWebGL2: boolean;
  isLowPowerDevice: boolean;
  isSoftwareRenderer: boolean;
  recommendedDpr: [number, number];
  rendererLabel: string | null;
  reason: string | null;
}

export interface GarmentModelSpec {
  modelPath: '/models/crew-tshirt.glb' | '/models/pique-polo.glb';
  garmentKind: 't_shirt' | 'polo_shirt';
  fabricKind: 'jersey' | 'pique';
  widthScale: number;
  label: string;
}

export interface CameraPose {
  position: [number, number, number];
  target: [number, number, number];
}

const CAMERA_POSES: Record<StudioCameraPreset, CameraPose> = {
  three_quarter: {
    position: [0.46, 0.12, 1.08],
    target: [0, 0.01, 0],
  },
  front: {
    position: [0, 0.03, 1.15],
    target: [0, 0.01, 0],
  },
  back: {
    position: [0, 0.03, -1.15],
    target: [0, 0.01, 0],
  },
  left_chest: {
    position: [0.16, 0.11, 0.66],
    target: [0.095, 0.095, 0.08],
  },
  collar: {
    position: [0.22, 0.34, 0.68],
    target: [0, 0.21, 0.02],
  },
};

export function getCameraPoseForPreset(preset: StudioCameraPreset): CameraPose {
  return CAMERA_POSES[preset] ?? CAMERA_POSES.three_quarter;
}

export function getCameraPresetForSurface(surfaceKey: PrintAreaSurfaceKey): StudioCameraPreset {
  switch (surfaceKey) {
    case 'back':
      return 'back';
    case 'left_chest':
      return 'left_chest';
    case 'front':
    default:
      return 'front';
  }
}

export function resolveGarmentModelSpec(
  product: Pick<ProductDetailDTO, 'slug' | 'category'>
): GarmentModelSpec {
  const slugLower = product.slug.toLowerCase();
  const catLower = product.category.slug.toLowerCase();
  const isPolo = catLower.includes('polo') || slugLower.includes('polo');

  if (isPolo) {
    return {
      modelPath: '/models/pique-polo.glb',
      garmentKind: 'polo_shirt',
      fabricKind: 'pique',
      widthScale: 1,
      label: 'Pique Knit Polo',
    };
  }

  const isOversized = slugLower.includes('oversized') || slugLower.includes('box');
  return {
    modelPath: '/models/crew-tshirt.glb',
    garmentKind: 't_shirt',
    fabricKind: 'jersey',
    widthScale: isOversized ? 1.07 : 1,
    label: isOversized ? 'Oversized Boxy Crewneck' : 'Heavyweight Crewneck',
  };
}

export function resolveMeshTargetForPrintArea(printArea: ProductPrintAreaDTO): string {
  const island = printArea.uvRegion?.islandKey?.trim();
  if (island === 'garment_front' || island === 'garment_back' || island === 'polo_left_chest') {
    return island;
  }

  switch (printArea.surfaceKey) {
    case 'left_chest':
      return 'polo_left_chest';
    case 'back':
      return 'garment_back';
    case 'front':
    default:
      return 'garment_front';
  }
}

/**
 * Safely inspects browser WebGL capability without crashing in SSR/headless environments
 * and releases its probe context immediately to avoid exhausting browser WebGL slots.
 */
export function detectWebGLCapability(): WebGLCapabilityReport {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return {
      supported: false,
      isWebGL2: false,
      isLowPowerDevice: false,
      isSoftwareRenderer: false,
      recommendedDpr: [1, 1.5],
      rendererLabel: null,
      reason: 'Browser document unavailable',
    };
  }

  try {
    const canvas = document.createElement('canvas');
    const gl2 = canvas.getContext('webgl2', {
      failIfMajorPerformanceCaveat: false,
    });
    const gl =
      gl2 ??
      (canvas.getContext('webgl', {
        failIfMajorPerformanceCaveat: false,
      }) as WebGLRenderingContext | null) ??
      (canvas.getContext('experimental-webgl') as WebGLRenderingContext | null);

    if (!gl) {
      return {
        supported: false,
        isWebGL2: false,
        isLowPowerDevice: false,
        isSoftwareRenderer: false,
        recommendedDpr: [1, 1.25],
        rendererLabel: null,
        reason: 'WebGL context unavailable on this device or browser',
      };
    }

    const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
    const rendererLabel = debugInfo
      ? String(gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) ?? '')
      : null;

    const cores = typeof navigator !== 'undefined' ? (navigator.hardwareConcurrency ?? 4) : 4;
    const isSoftware =
      Boolean(rendererLabel) &&
      /swiftshader|llvmpipe|software|microsoft basic/i.test(rendererLabel ?? '');
    const isNarrowViewport = window.innerWidth < 768;
    const isLowPowerDevice = cores <= 4 || isSoftware || isNarrowViewport;

    const loseExt = gl.getExtension('WEBGL_lose_context');
    loseExt?.loseContext();

    return {
      supported: true,
      isWebGL2: Boolean(gl2),
      isLowPowerDevice,
      isSoftwareRenderer: isSoftware,
      recommendedDpr: isSoftware ? [1, 1] : isLowPowerDevice ? [1, 1.5] : [1, 2],
      rendererLabel,
      reason: null,
    };
  } catch (err) {
    return {
      supported: false,
      isWebGL2: false,
      isLowPowerDevice: true,
      isSoftwareRenderer: false,
      recommendedDpr: [1, 1.25],
      rendererLabel: null,
      reason: err instanceof Error ? err.message : 'Failed to initialize WebGL probe',
    };
  }
}
