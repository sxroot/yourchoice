import {
  type CanonicalDesignObject,
  type DesignAssetDTO,
  type DesignValidationReport,
  type ProductDetailDTO,
  type ProductSummaryDTO,
  type ProductVariantDTO,
  STUDIO_FONT_PRESETS,
  STUDIO_GRAPHIC_PACK,
  STUDIO_SHAPE_KINDS,
  type StudioGraphicPackItem,
  type StudioShapeKind,
} from '@your-choice/shared-types';
import { Badge, Button } from '@your-choice/ui';
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  Copy,
  Eye,
  EyeOff,
  FolderOpen,
  ImagePlus,
  Layers,
  Lock,
  Loader2,
  Package,
  Shapes,
  Sparkles,
  Trash2,
  Type,
  Unlock,
} from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { pickLocalizedText, useAppLocale } from '@/i18n';
import { resolveDesignAssetPreviewUrl } from '../design-studio.api';

export type StudioLeftTab = 'products' | 'text' | 'uploads' | 'shapes' | 'layers' | 'preflight';

interface StudioToolPanelsProps {
  activeTab: StudioLeftTab;
  onTabChange: (tab: StudioLeftTab) => void;
  isAuthenticated: boolean;
  products: ProductSummaryDTO[];
  currentProduct: ProductDetailDTO;
  currentVariant: ProductVariantDTO;
  onSelectProductSlug: (slug: string) => void;
  onSelectVariant: (variant: ProductVariantDTO) => void;
  proportionNotice: boolean;
  onDismissProportionNotice: () => void;
  onAddText: (fontFamily: string, sampleText?: string) => void;
  onAddShape: (shapeKind: StudioShapeKind) => void;
  onAddGraphic: (graphic: StudioGraphicPackItem) => void;
  assets: DesignAssetDTO[];
  isLoadingAssets: boolean;
  isUploadingAsset: boolean;
  uploadError: string | null;
  onUploadFile: (file: File) => void;
  onInsertAsset: (asset: DesignAssetDTO) => void;
  objects: CanonicalDesignObject[];
  selectedObjectIds: string[];
  onSelectLayer: (objectId: string) => void;
  onMoveLayer: (objectId: string, direction: 'up' | 'down') => void;
  onToggleLayerVisibility: (objectId: string) => void;
  onToggleLayerLock: (objectId: string) => void;
  onDuplicateLayer: (objectId: string) => void;
  onDeleteLayer: (objectId: string) => void;
  validation: DesignValidationReport | null;
  onOpenSavedDesigns: () => void;
}

export function StudioToolPanels({
  activeTab,
  onTabChange,
  isAuthenticated,
  products,
  currentProduct,
  currentVariant,
  onSelectProductSlug,
  onSelectVariant,
  proportionNotice,
  onDismissProportionNotice,
  onAddText,
  onAddShape,
  onAddGraphic,
  assets,
  isLoadingAssets,
  isUploadingAsset,
  uploadError,
  onUploadFile,
  onInsertAsset,
  objects,
  selectedObjectIds,
  onSelectLayer,
  onMoveLayer,
  onToggleLayerVisibility,
  onToggleLayerLock,
  onDuplicateLayer,
  onDeleteLayer,
  validation,
  onOpenSavedDesigns,
}: StudioToolPanelsProps) {
  const { locale, t } = useAppLocale();
  const [customTextDraft, setCustomTextDraft] = useState('YOUR CHOICE');

  const tabs: Array<{ id: StudioLeftTab; label: string; icon: typeof Package; badge?: number }> = [
    { id: 'products', label: t('studio.tabProducts'), icon: Package },
    { id: 'text', label: t('studio.tabText'), icon: Type },
    { id: 'uploads', label: t('studio.tabUploads'), icon: ImagePlus },
    { id: 'shapes', label: t('studio.tabShapes'), icon: Shapes },
    { id: 'layers', label: t('studio.tabLayers'), icon: Layers, badge: objects.length },
    {
      id: 'preflight',
      label: t('studio.tabPreflight'),
      icon: CheckCircle2,
      badge: validation?.errorCount ?? 0,
    },
  ];

  // Deduplicate active variants into color groups then size buttons
  const colorGroups = Array.from(
    new Map(
      currentProduct.variants
        .filter((v) => v.isActive)
        .map((v) => [
          v.colorHex,
          { colorHex: v.colorHex, colorNameEn: v.colorNameEn, colorNameBn: v.colorNameBn },
        ])
    ).values()
  );

  const variantsInColor = currentProduct.variants.filter(
    (v) => v.isActive && v.colorHex === currentVariant.colorHex
  );

  return (
    <aside className="flex h-full flex-col rounded-2xl border border-border bg-surface">
      {/* Horizontal/Wrap Tool Navigation */}
      <div className="grid grid-cols-3 gap-1 border-b border-border p-2 sm:grid-cols-6 lg:grid-cols-3">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className={`relative flex min-h-11 flex-col items-center justify-center gap-1 rounded-xl px-2 py-1.5 text-[11px] font-semibold transition ${
                isActive
                  ? 'bg-accent text-white shadow-sm'
                  : 'text-ink-muted hover:bg-canvas hover:text-ink'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span className="truncate">{tab.label}</span>
              {tab.badge && tab.badge > 0 ? (
                <span
                  className={`absolute top-1 right-1 rounded-full px-1.5 text-[10px] font-mono ${
                    tab.id === 'preflight'
                      ? 'bg-danger text-white'
                      : isActive
                        ? 'bg-white/25 text-white'
                        : 'bg-accent/15 text-accent'
                  }`}
                >
                  {tab.badge}
                </span>
              ) : null}
            </button>
          );
        })}
      </div>

      {/* Tool Body */}
      <div className="flex-1 space-y-4 overflow-y-auto p-3.5">
        {activeTab === 'products' ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                {t('studio.selectGarment')}
              </h2>
              {isAuthenticated ? (
                <Button type="button" size="sm" variant="outline" onClick={onOpenSavedDesigns}>
                  <FolderOpen className="mr-1.5 h-3.5 w-3.5" />
                  {t('studio.savedDesignsBtn')}
                </Button>
              ) : null}
            </div>

            {proportionNotice ? (
              <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-800 dark:text-amber-300">
                <p>{t('studio.proportionChangedNotice')}</p>
                <button
                  type="button"
                  onClick={onDismissProportionNotice}
                  className="mt-1.5 font-semibold underline"
                >
                  {t('common.dismiss')}
                </button>
              </div>
            ) : null}

            <div className="space-y-2">
              {products.map((prod) => {
                const selected = prod.id === currentProduct.id;
                return (
                  <button
                    key={prod.id}
                    type="button"
                    onClick={() => onSelectProductSlug(prod.slug)}
                    className={`flex min-h-11 w-full items-center justify-between rounded-xl border px-3 py-2 text-left transition ${
                      selected ? 'border-accent bg-accent/10' : 'border-border hover:border-border'
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="truncate text-xs font-semibold text-ink">
                        {pickLocalizedText(locale, prod.nameEn, prod.nameBn)}
                      </p>
                      <p className="text-[11px] text-ink-muted">
                        {prod.category.slug.includes('polo') ? 'Polo' : 'T-Shirt'}
                        {prod.gsm ? ` · ${prod.gsm} GSM` : ''}
                      </p>
                    </div>
                    {selected ? <Badge variant="accent">{t('studio.active')}</Badge> : null}
                  </button>
                );
              })}
            </div>

            <div className="space-y-2 pt-2">
              <p className="text-xs font-semibold text-ink-muted">
                {t('studio.fabricColor')}:{' '}
                <span className="text-ink">
                  {pickLocalizedText(
                    locale,
                    currentVariant.colorNameEn,
                    currentVariant.colorNameBn
                  )}
                </span>
              </p>
              <div className="flex flex-wrap gap-2">
                {colorGroups.map((group) => {
                  const selected = group.colorHex === currentVariant.colorHex;
                  return (
                    <button
                      key={group.colorHex}
                      type="button"
                      aria-label={pickLocalizedText(locale, group.colorNameEn, group.colorNameBn)}
                      onClick={() => {
                        const match =
                          currentProduct.variants.find(
                            (v) =>
                              v.isActive &&
                              v.colorHex === group.colorHex &&
                              v.sizeCode === currentVariant.sizeCode
                          ) ??
                          currentProduct.variants.find(
                            (v) => v.isActive && v.colorHex === group.colorHex
                          );
                        if (match) {
                          onSelectVariant(match);
                        }
                      }}
                      className={`h-9 w-9 rounded-full border-2 transition ${
                        selected ? 'scale-110 border-accent ring-2 ring-accent/35' : 'border-border'
                      }`}
                      style={{ backgroundColor: group.colorHex }}
                    />
                  );
                })}
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-semibold text-ink-muted">{t('studio.garmentSize')}</p>
              <div className="flex flex-wrap gap-1.5">
                {variantsInColor.map((v) => {
                  const selected = v.id === currentVariant.id;
                  return (
                    <button
                      key={v.id}
                      type="button"
                      disabled={!v.inStock}
                      onClick={() => onSelectVariant(v)}
                      className={`min-h-10 min-w-11 rounded-lg border px-2.5 text-xs font-semibold transition ${
                        selected
                          ? 'border-accent bg-accent text-white'
                          : 'border-border bg-canvas text-ink'
                      } ${!v.inStock ? 'cursor-not-allowed opacity-40 line-through' : ''}`}
                    >
                      {v.sizeCode}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        ) : null}

        {activeTab === 'text' ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <label
                htmlFor="yc-studio-text-input"
                className="text-xs font-semibold text-ink-muted"
              >
                {t('studio.textCopyLabel')}
              </label>
              <input
                id="yc-studio-text-input"
                type="text"
                value={customTextDraft}
                onChange={(e) => setCustomTextDraft(e.target.value)}
                placeholder={t('studio.textPlaceholder')}
                className="w-full rounded-xl border border-border bg-canvas px-3 py-2.5 text-base sm:text-sm text-ink focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <Button
                type="button"
                className="w-full"
                onClick={() => onAddText('Outfit', customTextDraft.trim() || 'YOUR CHOICE')}
              >
                <Type className="mr-1.5 h-4 w-4" />
                {t('studio.addHeadingLayer')}
              </Button>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                {t('studio.fontPresetsTitle')}
              </p>
              <div className="space-y-2">
                {STUDIO_FONT_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => onAddText(preset.family, preset.sampleText)}
                    className="flex min-h-11 w-full items-center justify-between rounded-xl border border-border bg-canvas px-3 py-2 text-left transition hover:border-accent"
                  >
                    <div className="min-w-0">
                      <p
                        className="truncate text-sm font-semibold text-ink"
                        style={{ fontFamily: preset.fallbackStack }}
                      >
                        {preset.sampleText}
                      </p>
                      <p className="text-[11px] text-ink-muted">{preset.label}</p>
                    </div>
                    <Badge variant="neutral" className="ml-2 shrink-0 text-[10px]">
                      {preset.script === 'bengali' ? 'BN' : 'EN'}
                    </Badge>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : null}

        {activeTab === 'uploads' ? (
          <div className="space-y-4">
            {!isAuthenticated ? (
              <div className="rounded-xl border border-border bg-canvas p-4 text-xs space-y-2">
                <p className="font-semibold text-ink">{t('studio.loginRequiredForUploadsTitle')}</p>
                <p className="text-ink-muted">{t('studio.loginRequiredForUploadsBody')}</p>
                <Button asChild size="sm" className="w-full">
                  <Link to="/login?next=/studio">{t('nav.login')}</Link>
                </Button>
              </div>
            ) : (
              <>
                <label className="flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-border bg-canvas p-5 text-center transition hover:border-accent">
                  {isUploadingAsset ? (
                    <Loader2 className="mb-2 h-6 w-6 animate-spin text-accent" />
                  ) : (
                    <ImagePlus className="mb-2 h-6 w-6 text-accent" />
                  )}
                  <span className="text-xs font-semibold text-ink">
                    {isUploadingAsset ? t('studio.uploadingArtwork') : t('studio.uploadArtworkBtn')}
                  </span>
                  <span className="mt-1 text-[11px] text-ink-muted">
                    PNG, JPG, WebP · Max 15 MB
                  </span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="sr-only"
                    disabled={isUploadingAsset}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        onUploadFile(file);
                        e.target.value = '';
                      }
                    }}
                  />
                </label>

                {uploadError ? (
                  <p role="alert" className="text-xs font-medium text-danger">
                    {uploadError}
                  </p>
                ) : null}

                <div className="space-y-2">
                  <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                    {t('studio.yourArtworkLibrary')}
                  </p>
                  {isLoadingAssets ? (
                    <p className="text-xs text-ink-muted">{t('common.loading')}</p>
                  ) : assets.length === 0 ? (
                    <p className="text-xs text-ink-muted">{t('studio.noUploadedAssets')}</p>
                  ) : (
                    <div className="grid grid-cols-2 gap-2">
                      {assets.map((asset) => (
                        <button
                          key={asset.id}
                          type="button"
                          onClick={() => onInsertAsset(asset)}
                          className="group flex flex-col overflow-hidden rounded-xl border border-border bg-canvas text-left transition hover:border-accent"
                        >
                          <div className="flex aspect-square w-full items-center justify-center bg-slate-900/5 p-2">
                            <img
                              src={resolveDesignAssetPreviewUrl(asset.id)}
                              alt={asset.originalFilename}
                              className="max-h-full max-w-full object-contain"
                            />
                          </div>
                          <div className="p-2">
                            <p className="truncate text-[11px] font-semibold text-ink">
                              {asset.originalFilename}
                            </p>
                            <p className="font-mono text-[10px] text-ink-muted">
                              {asset.widthPx}×{asset.heightPx}px
                            </p>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        ) : null}

        {activeTab === 'shapes' ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                {t('studio.geometricShapes')}
              </p>
              <div className="grid grid-cols-3 gap-2">
                {STUDIO_SHAPE_KINDS.map((kind) => (
                  <button
                    key={kind}
                    type="button"
                    onClick={() => onAddShape(kind)}
                    className="flex min-h-11 flex-col items-center justify-center rounded-xl border border-border bg-canvas px-2 py-2 text-xs font-semibold capitalize hover:border-accent"
                  >
                    {kind}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5 text-accent" />
                <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                  {t('studio.commercialVectorPack')}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {STUDIO_GRAPHIC_PACK.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onAddGraphic(item)}
                    className="flex flex-col items-center gap-1.5 rounded-xl border border-border bg-canvas p-2.5 text-center transition hover:border-accent"
                  >
                    <svg
                      viewBox={`0 0 ${item.viewBoxSize} ${item.viewBoxSize}`}
                      className="h-10 w-10"
                    >
                      <path
                        d={item.pathData}
                        fill={item.defaultFill}
                        stroke={item.defaultStroke}
                        strokeWidth="3"
                      />
                    </svg>
                    <span className="line-clamp-1 text-[11px] font-semibold text-ink">
                      {pickLocalizedText(locale, item.labelEn, item.labelBn)}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : null}

        {activeTab === 'layers' ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold uppercase tracking-wider text-ink-muted">
                {t('studio.layerStack')} ({objects.length})
              </p>
            </div>
            {objects.length === 0 ? (
              <p className="rounded-xl border border-dashed border-border p-4 text-center text-xs text-ink-muted">
                {t('studio.noLayersYet')}
              </p>
            ) : (
              <div className="space-y-1.5">
                {[...objects].reverse().map((obj) => {
                  const selected = selectedObjectIds.includes(obj.id);
                  return (
                    <div
                      key={obj.id}
                      className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-2 transition ${
                        selected ? 'border-accent bg-accent/10' : 'border-border bg-canvas'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => onSelectLayer(obj.id)}
                        className="min-w-0 flex-1 text-left"
                      >
                        <p className="truncate text-xs font-semibold text-ink">{obj.name}</p>
                        <p className="text-[10px] uppercase text-ink-muted">
                          {obj.type === 'group' ? `group (${obj.children.length})` : obj.type}
                        </p>
                      </button>

                      <button
                        type="button"
                        aria-label={t('studio.layerUp')}
                        onClick={() => onMoveLayer(obj.id, 'up')}
                        className="rounded p-1.5 hover:bg-surface"
                      >
                        <ArrowUp className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label={t('studio.layerDown')}
                        onClick={() => onMoveLayer(obj.id, 'down')}
                        className="rounded p-1.5 hover:bg-surface"
                      >
                        <ArrowDown className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label={obj.visible ? t('studio.hideLayer') : t('studio.showLayer')}
                        onClick={() => onToggleLayerVisibility(obj.id)}
                        className="rounded p-1.5 hover:bg-surface"
                      >
                        {obj.visible ? (
                          <Eye className="h-3.5 w-3.5" />
                        ) : (
                          <EyeOff className="h-3.5 w-3.5 opacity-50" />
                        )}
                      </button>
                      <button
                        type="button"
                        aria-label={obj.locked ? t('studio.unlockLayer') : t('studio.lockLayer')}
                        onClick={() => onToggleLayerLock(obj.id)}
                        className="rounded p-1.5 hover:bg-surface"
                      >
                        {obj.locked ? (
                          <Lock className="h-3.5 w-3.5 text-amber-500" />
                        ) : (
                          <Unlock className="h-3.5 w-3.5" />
                        )}
                      </button>
                      <button
                        type="button"
                        aria-label={t('studio.duplicateLayer')}
                        onClick={() => onDuplicateLayer(obj.id)}
                        className="rounded p-1.5 hover:bg-surface"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label={t('studio.deleteLayer')}
                        onClick={() => onDeleteLayer(obj.id)}
                        className="rounded p-1.5 text-danger hover:bg-surface"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : null}

        {activeTab === 'preflight' ? (
          <div className="space-y-3">
            <div
              className={`rounded-xl border p-3.5 text-xs ${
                validation?.isValidForPrint
                  ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-800 dark:text-emerald-300'
                  : 'border-amber-500/40 bg-amber-500/10 text-amber-800 dark:text-amber-300'
              }`}
            >
              <div className="flex items-center gap-2 font-semibold">
                {validation?.isValidForPrint ? (
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                ) : (
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                )}
                <span>
                  {validation?.isValidForPrint
                    ? t('studio.preflightPassed')
                    : t('studio.preflightAttention')}
                </span>
              </div>
              <p className="mt-1 opacity-90">
                {validation?.errorCount ?? 0} {t('studio.errors')} · {validation?.warningCount ?? 0}{' '}
                {t('studio.warnings')}
              </p>
            </div>

            {validation && validation.issues.length > 0 ? (
              <div className="space-y-2">
                {validation.issues.map((issue, idx) => (
                  <div
                    key={`${issue.code}-${issue.objectId ?? idx}`}
                    className={`rounded-xl border p-3 text-xs ${
                      issue.severity === 'error'
                        ? 'border-danger/45 bg-danger/10 text-ink'
                        : 'border-amber-500/35 bg-amber-500/10 text-ink'
                    }`}
                  >
                    <p className="font-semibold uppercase text-[10px] tracking-wider opacity-75">
                      {issue.surfaceKey} · {issue.severity}
                    </p>
                    <p className="mt-0.5">
                      {pickLocalizedText(locale, issue.messageEn, issue.messageBn)}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-ink-muted">{t('studio.preflightCleanNote')}</p>
            )}
          </div>
        ) : null}
      </div>
    </aside>
  );
}
