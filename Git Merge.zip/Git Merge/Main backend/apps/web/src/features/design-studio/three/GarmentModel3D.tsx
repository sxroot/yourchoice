import type {
  CanonicalDesignSurface,
  PrintAreaSurfaceKey,
  ProductDetailDTO,
  ProductVariantDTO,
} from '@your-choice/shared-types';
import { type ThreeEvent, useThree } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { buildSurfaceCanvasTexture } from './canvas-texture-bridge';
import { getProceduralFabricBumpMap } from './procedural-fabric-maps';
import { resolveGarmentModelSpec, resolveMeshTargetForPrintArea } from './webgl-support';

interface GarmentModel3DProps {
  product: ProductDetailDTO;
  variant: ProductVariantDTO;
  surfaces: Record<string, CanonicalDesignSurface>;
  activeSurfaceKey: PrintAreaSurfaceKey;
  showPrintGuides: boolean;
  isLowPowerDevice: boolean;
  onSelectSurface: (surfaceKey: PrintAreaSurfaceKey) => void;
}

const KNOWN_ISLAND_NAMES = new Set(['garment_front', 'garment_back', 'polo_left_chest']);

export function GarmentModel3D({
  product,
  variant,
  surfaces,
  activeSurfaceKey,
  showPrintGuides,
  isLowPowerDevice,
  onSelectSurface,
}: GarmentModel3DProps) {
  const { invalidate } = useThree();
  const modelSpec = useMemo(() => resolveGarmentModelSpec(product), [product]);
  const gltf = useGLTF(modelSpec.modelPath);
  const [imageDecodeTick, setImageDecodeTick] = useState(0);

  // Clone scene graph + child geometries cleanly per mount so shared GLTF cache stays pure
  const clonedScene = useMemo(() => {
    const root = gltf.scene.clone(true);
    root.traverse((obj) => {
      if (obj instanceof THREE.Mesh && obj.geometry) {
        obj.geometry = obj.geometry.clone();
        obj.castShadow = !KNOWN_ISLAND_NAMES.has(obj.name);
        obj.receiveShadow = true;
      }
    });
    return root;
  }, [gltf.scene]);

  // Dispose cloned geometries on unmount / model change
  useEffect(() => {
    return () => {
      clonedScene.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry?.dispose();
          const mat = obj.material;
          if (Array.isArray(mat)) {
            mat.forEach((m) => m.dispose());
          } else if (mat) {
            mat.dispose();
          }
        }
      });
    };
  }, [clonedScene]);

  const meshToSurfaceMap = useMemo(() => {
    const map = new Map<string, PrintAreaSurfaceKey>();
    for (const area of product.printAreas) {
      if (!area.isActive) {
        continue;
      }
      map.set(resolveMeshTargetForPrintArea(area), area.surfaceKey);
    }
    return map;
  }, [product.printAreas]);

  // Apply physically based garment fabric materials & colorway tint
  useEffect(() => {
    const bumpMap = getProceduralFabricBumpMap(modelSpec.fabricKind);
    const garmentColor = new THREE.Color(variant.colorHex || '#111827');
    const sheenTint = garmentColor.clone().lerp(new THREE.Color('#f8fafc'), 0.32);

    clonedScene.traverse((obj) => {
      if (!(obj instanceof THREE.Mesh)) {
        return;
      }

      if (KNOWN_ISLAND_NAMES.has(obj.name)) {
        return;
      }

      const prevMat = obj.material;
      if (Array.isArray(prevMat)) {
        prevMat.forEach((m) => m.dispose());
      } else if (prevMat) {
        prevMat.dispose();
      }

      if (obj.name === 'garment_lining') {
        obj.material = new THREE.MeshStandardMaterial({
          color: new THREE.Color('#090b10'),
          roughness: 0.94,
          metalness: 0,
          side: THREE.FrontSide,
        });
        return;
      }

      if (obj.name === 'garment_buttons') {
        const buttonColor = garmentColor.clone().lerp(new THREE.Color('#1e293b'), 0.65);
        obj.material = new THREE.MeshPhysicalMaterial({
          color: buttonColor,
          roughness: 0.26,
          metalness: 0.08,
          clearcoat: 0.45,
          clearcoatRoughness: 0.2,
        });
        return;
      }

      const isCollar = obj.name === 'garment_collar';
      obj.material = new THREE.MeshPhysicalMaterial({
        color: garmentColor,
        roughness: isCollar ? 0.9 : modelSpec.fabricKind === 'pique' ? 0.88 : 0.82,
        metalness: 0,
        sheen: 0.46,
        sheenRoughness: 0.72,
        sheenColor: sheenTint,
        bumpMap: bumpMap ?? null,
        bumpScale: modelSpec.fabricKind === 'pique' ? 0.0042 : 0.0024,
        side: isCollar ? THREE.DoubleSide : THREE.FrontSide,
      });
    });
    invalidate();
  }, [clonedScene, modelSpec.fabricKind, variant.colorHex, invalidate]);

  const activeTexturesRef = useRef<THREE.CanvasTexture[]>([]);

  // Serialize surface contents cleanly so texture rebuild runs whenever layers/text/assets change
  const surfacesFingerprint = useMemo(() => JSON.stringify(surfaces), [surfaces]);

  useEffect(() => {
    let cancelled = false;

    const rebuildTextures = async () => {
      const nextTextures: THREE.CanvasTexture[] = [];
      const maxDim = isLowPowerDevice ? 896 : 1280;
      const bumpMap = getProceduralFabricBumpMap(modelSpec.fabricKind);

      const targets = new Map<string, CanonicalDesignSurface>();
      for (const area of product.printAreas) {
        if (!area.isActive) {
          continue;
        }
        const surf = surfaces[area.surfaceKey];
        if (surf) {
          targets.set(resolveMeshTargetForPrintArea(area), surf);
        }
      }

      const builtByMesh = new Map<string, THREE.CanvasTexture | null>();
      for (const [meshName, surfaceData] of targets.entries()) {
        const hasVisibleObjects = surfaceData.objects.some((o) => o.visible);
        if (!hasVisibleObjects && !showPrintGuides) {
          builtByMesh.set(meshName, null);
          continue;
        }

        const tex = await buildSurfaceCanvasTexture(surfaceData, {
          maxDimensionPx: maxDim,
          showPrintGuide: showPrintGuides,
          isActiveSurface: surfaceData.surfaceKey === activeSurfaceKey,
          onImageLoaded: () => setImageDecodeTick((c) => c + 1),
        });
        if (cancelled) {
          tex?.dispose();
          return;
        }
        if (tex) {
          nextTextures.push(tex);
        }
        builtByMesh.set(meshName, tex);
      }

      if (cancelled) {
        nextTextures.forEach((t) => t.dispose());
        return;
      }

      // Dispose previous CanvasTextures once new batch is ready
      for (const oldTex of activeTexturesRef.current) {
        oldTex.dispose();
      }
      activeTexturesRef.current = nextTextures;

      clonedScene.traverse((obj) => {
        if (!(obj instanceof THREE.Mesh) || !KNOWN_ISLAND_NAMES.has(obj.name)) {
          return;
        }
        const tex = builtByMesh.get(obj.name) ?? null;
        if (!tex) {
          obj.visible = false;
          return;
        }

        obj.visible = true;
        const prevMat = obj.material;
        if (Array.isArray(prevMat)) {
          prevMat.forEach((m) => m.dispose());
        } else if (prevMat) {
          prevMat.dispose();
        }

        obj.material = new THREE.MeshStandardMaterial({
          map: tex,
          transparent: true,
          alphaTest: 0.015,
          depthWrite: false,
          polygonOffset: true,
          polygonOffsetFactor: -2,
          polygonOffsetUnits: -2,
          roughness: 0.56,
          metalness: 0,
          bumpMap: bumpMap ?? null,
          bumpScale: 0.0008,
        });
      });
      invalidate();
    };

    void rebuildTextures();

    return () => {
      cancelled = true;
    };
  }, [
    clonedScene,
    product.printAreas,
    surfaces,
    surfacesFingerprint,
    activeSurfaceKey,
    showPrintGuides,
    isLowPowerDevice,
    modelSpec.fabricKind,
    imageDecodeTick,
  ]);

  useEffect(() => {
    return () => {
      for (const tex of activeTexturesRef.current) {
        tex.dispose();
      }
      activeTexturesRef.current = [];
    };
  }, []);

  const handlePointerClick = (event: ThreeEvent<MouseEvent>) => {
    const clickedMesh = event.object;
    if (!(clickedMesh instanceof THREE.Mesh)) {
      return;
    }
    const surfaceKey = meshToSurfaceMap.get(clickedMesh.name);
    if (surfaceKey) {
      event.stopPropagation();
      onSelectSurface(surfaceKey);
    }
  };

  return (
    <group
      position={[0, 0.02, 0]}
      scale={[modelSpec.widthScale, 1, 1]}
      onClick={handlePointerClick}
    >
      <primitive object={clonedScene} />
    </group>
  );
}
