import type {
  CanonicalDesignObject,
  CanonicalDesignSurface,
  CanonicalGroupObject,
  CanonicalTextObject,
} from '@your-choice/shared-types';
import * as THREE from 'three';
import { resolveDesignAssetPreviewUrl } from '../design-studio.api';
import { ensureStudioFontsLoaded, getStudioFontPreset } from '../fonts';

export interface CanvasTextureDimensions {
  widthPx: number;
  heightPx: number;
}

/**
 * Computes crisp offscreen texture dimensions preserving physical print area aspect ratio.
 */
export function resolveCanvasTextureSize(
  surface: Pick<CanonicalDesignSurface, 'physicalWidthMm' | 'physicalHeightMm'>,
  maxDimensionPx = 1280
): CanvasTextureDimensions {
  const safeMax = Math.max(256, Math.min(2048, Math.round(maxDimensionPx)));
  const ratio = surface.physicalWidthMm / Math.max(1, surface.physicalHeightMm);

  if (ratio >= 1) {
    return {
      widthPx: safeMax,
      heightPx: Math.max(256, Math.round(safeMax / ratio)),
    };
  }

  return {
    widthPx: Math.max(256, Math.round(safeMax * ratio)),
    heightPx: safeMax,
  };
}

const imageLoadCache = new Map<string, Promise<HTMLImageElement | null>>();
const loadedImages = new Map<string, HTMLImageElement>();

function loadPreviewImage(assetId: string, onLoaded?: () => void): HTMLImageElement | null {
  const existing = loadedImages.get(assetId);
  if (existing) {
    return existing;
  }

  if (typeof Image === 'undefined') {
    return null;
  }

  if (!imageLoadCache.has(assetId)) {
    const url = resolveDesignAssetPreviewUrl(assetId);
    const promise = new Promise<HTMLImageElement | null>((resolve) => {
      const img = new Image();
      img.crossOrigin = 'use-credentials';
      img.onload = () => {
        loadedImages.set(assetId, img);
        onLoaded?.();
        resolve(img);
      };
      img.onerror = () => {
        resolve(null);
      };
      img.src = url;
    });
    imageLoadCache.set(assetId, promise);
  }

  return null;
}

function buildPolygonPoints(
  pointsCount: number,
  radius: number,
  innerRadius?: number
): Array<{ x: number; y: number }> {
  const pts: Array<{ x: number; y: number }> = [];
  const total = innerRadius !== undefined ? pointsCount * 2 : pointsCount;
  for (let i = 0; i < total; i++) {
    const r = innerRadius !== undefined && i % 2 === 1 ? innerRadius : radius;
    const angle = ((Math.PI * 2) / total) * i - Math.PI / 2;
    pts.push({
      x: Math.cos(angle) * r,
      y: Math.sin(angle) * r,
    });
  }
  return pts;
}

function traceClosedPoints(
  ctx: CanvasRenderingContext2D,
  points: Array<{ x: number; y: number }>
): void {
  if (points.length === 0) {
    return;
  }
  ctx.beginPath();
  ctx.moveTo(points[0]!.x, points[0]!.y);
  for (let i = 1; i < points.length; i++) {
    ctx.lineTo(points[i]!.x, points[i]!.y);
  }
  ctx.closePath();
}

function drawRoundedRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
): void {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  if (typeof ctx.roundRect === 'function') {
    ctx.roundRect(x, y, width, height, r);
  } else {
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + width - r, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + r);
    ctx.lineTo(x + width, y + height - r);
    ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
    ctx.lineTo(x + r, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }
}

function drawTextObject(
  ctx: CanvasRenderingContext2D,
  obj: CanonicalTextObject,
  targetW: number,
  targetH: number,
  boxWidth: number
): void {
  const preset = getStudioFontPreset(obj.fontFamily);
  const fontFamilyCss = preset.fallbackStack || preset.family || 'sans-serif';
  const weight = String(obj.fontWeight);
  const style = obj.fontStyle === 'italic' ? 'italic' : 'normal';

  const lines = (obj.text || '').split(/\r?\n/);
  const baseLineCount = Math.max(1, lines.length);
  const approxFontPx = Math.max(14, targetH / (baseLineCount * Math.max(0.85, obj.lineHeight)));

  ctx.font = `${style} ${weight} ${approxFontPx.toFixed(1)}px ${fontFamilyCss}`;
  ctx.textBaseline = 'middle';
  ctx.textAlign = obj.textAlign;

  // Measure widest line and scale horizontally if needed to fit canonical bounding box
  let maxLineWidth = 1;
  for (const line of lines) {
    maxLineWidth = Math.max(maxLineWidth, ctx.measureText(line || ' ').width);
  }
  const scaleXFit = targetW / maxLineWidth;
  const lineStepPx = targetH / baseLineCount;

  ctx.save();
  ctx.scale(scaleXFit, 1);

  const alignAnchorX =
    obj.textAlign === 'left'
      ? -targetW / (2 * scaleXFit)
      : obj.textAlign === 'right'
        ? targetW / (2 * scaleXFit)
        : 0;

  const strokePx = obj.stroke ? (obj.strokeWidth * boxWidth) / 1000 : 0;

  lines.forEach((line, idx) => {
    const lineY = -targetH / 2 + (idx + 0.5) * lineStepPx;
    if (obj.stroke && strokePx > 0) {
      ctx.strokeStyle = obj.stroke;
      ctx.lineWidth = strokePx / Math.max(0.2, scaleXFit);
      ctx.lineJoin = 'round';
      ctx.strokeText(line, alignAnchorX, lineY);
    }
    ctx.fillStyle = obj.fill;
    ctx.fillText(line, alignAnchorX, lineY);
  });

  ctx.restore();
}

function drawCanonicalNode(
  ctx: CanvasRenderingContext2D,
  node: CanonicalDesignObject,
  boxWidth: number,
  boxHeight: number,
  onImageLoaded?: () => void
): void {
  if (!node.visible || node.opacity <= 0) {
    return;
  }

  const targetW = Math.max(8, node.width * boxWidth);
  const targetH = Math.max(8, node.height * boxHeight);
  const cx = (node.x + node.width / 2) * boxWidth;
  const cy = (node.y + node.height / 2) * boxHeight;

  ctx.save();
  ctx.translate(cx, cy);
  if (node.rotationDeg !== 0) {
    ctx.rotate((node.rotationDeg * Math.PI) / 180);
  }
  ctx.scale(node.flipX ? -1 : 1, node.flipY ? -1 : 1);
  ctx.globalAlpha *= Math.max(0, Math.min(1, node.opacity));

  if (node.type === 'text') {
    drawTextObject(ctx, node, targetW, targetH, boxWidth);
    ctx.restore();
    return;
  }

  if (node.type === 'shape') {
    const strokePx = node.stroke ? (node.strokeWidth * boxWidth) / 1000 : 0;
    const hw = targetW / 2;
    const hh = targetH / 2;

    switch (node.shapeKind) {
      case 'circle': {
        ctx.beginPath();
        ctx.ellipse(0, 0, hw, hh, 0, 0, Math.PI * 2);
        ctx.fillStyle = node.fill;
        ctx.fill();
        if (node.stroke && strokePx > 0) {
          ctx.strokeStyle = node.stroke;
          ctx.lineWidth = strokePx;
          ctx.stroke();
        }
        break;
      }
      case 'triangle': {
        traceClosedPoints(ctx, [
          { x: 0, y: -hh },
          { x: hw, y: hh },
          { x: -hw, y: hh },
        ]);
        ctx.fillStyle = node.fill;
        ctx.fill();
        if (node.stroke && strokePx > 0) {
          ctx.strokeStyle = node.stroke;
          ctx.lineWidth = strokePx;
          ctx.stroke();
        }
        break;
      }
      case 'star': {
        const rawPts = buildPolygonPoints(5, 1, 0.44);
        traceClosedPoints(
          ctx,
          rawPts.map((pt) => ({ x: pt.x * hw, y: pt.y * hh }))
        );
        ctx.fillStyle = node.fill;
        ctx.fill();
        if (node.stroke && strokePx > 0) {
          ctx.strokeStyle = node.stroke;
          ctx.lineWidth = strokePx;
          ctx.stroke();
        }
        break;
      }
      case 'hexagon': {
        const rawPts = buildPolygonPoints(6, 1);
        traceClosedPoints(
          ctx,
          rawPts.map((pt) => ({ x: pt.x * hw, y: pt.y * hh }))
        );
        ctx.fillStyle = node.fill;
        ctx.fill();
        if (node.stroke && strokePx > 0) {
          ctx.strokeStyle = node.stroke;
          ctx.lineWidth = strokePx;
          ctx.stroke();
        }
        break;
      }
      case 'line': {
        ctx.beginPath();
        ctx.moveTo(-hw, 0);
        ctx.lineTo(hw, 0);
        ctx.strokeStyle = node.stroke ?? node.fill;
        ctx.lineWidth = Math.max(3, (node.strokeWidth * boxWidth) / 1000);
        ctx.lineCap = 'round';
        ctx.stroke();
        break;
      }
      case 'rect':
      default: {
        const r = ((node.cornerRadius ?? 0) * boxWidth) / 420;
        drawRoundedRectPath(ctx, -hw, -hh, targetW, targetH, r);
        ctx.fillStyle = node.fill;
        ctx.fill();
        if (node.stroke && strokePx > 0) {
          ctx.strokeStyle = node.stroke;
          ctx.lineWidth = strokePx;
          ctx.stroke();
        }
        break;
      }
    }

    ctx.restore();
    return;
  }

  if (node.type === 'graphic') {
    const vb = Math.max(1, node.viewBoxSize || 100);
    const sx = targetW / vb;
    const sy = targetH / vb;
    ctx.save();
    ctx.translate(-targetW / 2, -targetH / 2);
    ctx.scale(sx, sy);

    if (typeof Path2D !== 'undefined') {
      const path = new Path2D(node.pathData);
      ctx.fillStyle = node.fill;
      ctx.fill(path);
      if (node.stroke && node.strokeWidth > 0) {
        ctx.strokeStyle = node.stroke;
        ctx.lineWidth = (node.strokeWidth * boxWidth) / 1000 / Math.max(0.25, Math.min(sx, sy));
        ctx.stroke(path);
      }
    }
    ctx.restore();
    ctx.restore();
    return;
  }

  if (node.type === 'image') {
    const img = loadPreviewImage(node.assetId, onImageLoaded);
    if (img) {
      const srcW = img.naturalWidth || img.width || node.naturalWidthPx || 200;
      const srcH = img.naturalHeight || img.height || node.naturalHeightPx || 200;
      const sx = node.cropRect ? node.cropRect.x * srcW : 0;
      const sy = node.cropRect ? node.cropRect.y * srcH : 0;
      const sw = node.cropRect ? Math.max(4, node.cropRect.width * srcW) : srcW;
      const sh = node.cropRect ? Math.max(4, node.cropRect.height * srcH) : srcH;
      ctx.drawImage(img, sx, sy, sw, sh, -targetW / 2, -targetH / 2, targetW, targetH);
    } else {
      ctx.fillStyle = 'rgba(37, 99, 235, 0.14)';
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.7)';
      ctx.lineWidth = 2;
      drawRoundedRectPath(ctx, -targetW / 2, -targetH / 2, targetW, targetH, 8);
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();
    return;
  }

  if (node.type === 'group') {
    const groupNode = node as CanonicalGroupObject;
    ctx.translate(-targetW / 2, -targetH / 2);
    for (const child of groupNode.children) {
      drawCanonicalNode(ctx, child, targetW, targetH, onImageLoaded);
    }
  }

  ctx.restore();
}

export interface RenderSurfaceTextureOptions {
  maxDimensionPx?: number;
  showPrintGuide?: boolean;
  isActiveSurface?: boolean;
  onImageLoaded?: () => void;
}

/**
 * Paints a CanonicalDesignSurface into a dedicated offscreen canvas and creates a
 * properly calibrated glTF-oriented THREE.CanvasTexture (SRGBColorSpace, flipY = false).
 */
export async function buildSurfaceCanvasTexture(
  surface: CanonicalDesignSurface,
  options: RenderSurfaceTextureOptions = {}
): Promise<THREE.CanvasTexture | null> {
  if (typeof document === 'undefined') {
    return null;
  }

  await ensureStudioFontsLoaded();

  const { widthPx, heightPx } = resolveCanvasTextureSize(surface, options.maxDimensionPx ?? 1280);
  const canvas = document.createElement('canvas');
  canvas.width = widthPx;
  canvas.height = heightPx;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return null;
  }

  ctx.clearRect(0, 0, widthPx, heightPx);

  for (const obj of surface.objects) {
    drawCanonicalNode(ctx, obj, widthPx, heightPx, options.onImageLoaded);
  }

  if (options.showPrintGuide) {
    const insetX = (surface.safeInsetMm / Math.max(1, surface.physicalWidthMm)) * widthPx;
    const insetY = (surface.safeInsetMm / Math.max(1, surface.physicalHeightMm)) * heightPx;

    ctx.save();
    ctx.strokeStyle = options.isActiveSurface
      ? 'rgba(34, 211, 238, 0.85)'
      : 'rgba(148, 163, 184, 0.45)';
    ctx.lineWidth = Math.max(2, Math.round(widthPx * 0.0035));
    ctx.setLineDash([Math.round(widthPx * 0.02), Math.round(widthPx * 0.015)]);
    ctx.strokeRect(
      insetX,
      insetY,
      Math.max(16, widthPx - insetX * 2),
      Math.max(16, heightPx - insetY * 2)
    );
    ctx.restore();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.flipY = false; // glTF 2.0 TEXCOORD_0 uses top-left (0,0)
  texture.anisotropy = 4;
  texture.generateMipmaps = true;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.needsUpdate = true;

  return texture;
}
