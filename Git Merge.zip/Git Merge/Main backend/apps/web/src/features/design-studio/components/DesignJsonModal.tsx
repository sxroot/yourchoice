import type { CanonicalDesignDocument } from '@your-choice/shared-types';
import { canonicalDesignDocumentSchema } from '@your-choice/validation';
import {
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@your-choice/ui';
import { Check, Code2, Copy } from 'lucide-react';
import { useState } from 'react';
import { useAppLocale } from '@/i18n';

interface DesignJsonModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  document: CanonicalDesignDocument | null;
  onApplyDocument: (nextDoc: CanonicalDesignDocument) => void;
}

interface DesignJsonModalBodyProps {
  document: CanonicalDesignDocument;
  onOpenChange: (open: boolean) => void;
  onApplyDocument: (nextDoc: CanonicalDesignDocument) => void;
}

function DesignJsonModalBody({
  document,
  onOpenChange,
  onApplyDocument,
}: DesignJsonModalBodyProps) {
  const { t } = useAppLocale();
  const [rawJson, setRawJson] = useState(() => JSON.stringify(document, null, 2));
  const [errorText, setErrorText] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      await navigator.clipboard.writeText(rawJson);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    }
  };

  const handleApply = () => {
    try {
      const parsedJson = JSON.parse(rawJson) as unknown;
      const result = canonicalDesignDocumentSchema.safeParse(parsedJson);
      if (!result.success) {
        const firstIssue = result.error.issues[0];
        setErrorText(
          firstIssue
            ? `${firstIssue.path.join('.') || 'document'}: ${firstIssue.message}`
            : t('studio.jsonInvalid')
        );
        return;
      }

      onApplyDocument(result.data);
      setErrorText(null);
      onOpenChange(false);
    } catch {
      setErrorText(t('studio.jsonSyntaxError'));
    }
  };

  return (
    <>
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Code2 className="h-4 w-4 text-accent" />
          <span>{t('studio.jsonModalTitle')}</span>
        </DialogTitle>
        <DialogDescription>{t('studio.jsonModalSubtitle')}</DialogDescription>
      </DialogHeader>

      <div className="space-y-2">
        <div className="flex justify-end">
          <Button type="button" size="sm" variant="outline" onClick={() => void handleCopy()}>
            {copied ? (
              <Check className="mr-1.5 h-3.5 w-3.5" />
            ) : (
              <Copy className="mr-1.5 h-3.5 w-3.5" />
            )}
            {copied ? t('studio.copied') : t('studio.copyJson')}
          </Button>
        </div>
        <textarea
          aria-label={t('studio.jsonModalTitle')}
          value={rawJson}
          onChange={(e) => setRawJson(e.target.value)}
          spellCheck={false}
          rows={15}
          className="w-full rounded-xl border border-border bg-canvas p-3 font-mono text-xs leading-relaxed text-ink focus:outline-none focus:ring-2 focus:ring-accent"
        />
        {errorText ? (
          <p role="alert" className="text-xs font-medium text-danger">
            {errorText}
          </p>
        ) : null}
      </div>

      <DialogFooter className="gap-2">
        <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
          {t('common.cancel')}
        </Button>
        <Button type="button" onClick={handleApply}>
          {t('studio.applyJson')}
        </Button>
      </DialogFooter>
    </>
  );
}

export function DesignJsonModal({
  open,
  onOpenChange,
  document,
  onApplyDocument,
}: DesignJsonModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        {open && document ? (
          <DesignJsonModalBody
            key={`${document.productId}-${document.productVariantId}-${document.updatedAt ?? 'draft'}`}
            document={document}
            onOpenChange={onOpenChange}
            onApplyDocument={onApplyDocument}
          />
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
