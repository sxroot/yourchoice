import type {
  CartDTO,
  CartResponseData,
  DesignAssetDTO,
  DesignAssetListResponseData,
  DesignAssetUploadResponseData,
  DesignDetailDTO,
  DesignDetailResponseData,
  DesignListResponseData,
  DesignPrintExportDTO,
  DesignPrintExportResponseData,
  PrintAreaSurfaceKey,
} from '@your-choice/shared-types';
import type { CreateDesignInput, UpdateDesignInput } from '@your-choice/validation';
import {
  apiDelete,
  apiGet,
  apiPost,
  apiPut,
  apiUploadFormData,
  buildApiUrl,
} from '@/services/api-client';

function unwrap<T>(
  res: { success: boolean; data?: T; error?: { message: string } },
  fallbackMsg: string
): T {
  if (!res.success || res.data === undefined) {
    throw new Error(res.error?.message ?? fallbackMsg);
  }
  return res.data;
}

export async function listMyDesigns(
  page = 1,
  pageSize = 20,
  signal?: AbortSignal
): Promise<DesignListResponseData> {
  const response = await apiGet<DesignListResponseData>(
    `/designs?page=${page}&pageSize=${pageSize}`,
    signal
  );
  return unwrap(response, 'Unable to load saved designs');
}

export async function getDesignDetail(
  designId: string,
  signal?: AbortSignal
): Promise<DesignDetailDTO> {
  const response = await apiGet<DesignDetailResponseData>(`/designs/${designId}`, signal);
  return unwrap(response, 'Unable to load design').design;
}

export async function createDesign(
  payload: CreateDesignInput,
  signal?: AbortSignal
): Promise<DesignDetailDTO> {
  const response = await apiPost<DesignDetailResponseData>('/designs', payload, signal);
  return unwrap(response, 'Unable to save design').design;
}

export async function updateDesign(
  designId: string,
  payload: UpdateDesignInput,
  signal?: AbortSignal
): Promise<DesignDetailDTO> {
  const response = await apiPut<DesignDetailResponseData>(`/designs/${designId}`, payload, signal);
  return unwrap(response, 'Unable to update design').design;
}

export async function deleteDesign(designId: string, signal?: AbortSignal): Promise<void> {
  const response = await apiDelete<{ deleted: true; designId: string }>(
    `/designs/${designId}`,
    signal
  );
  unwrap(response, 'Unable to delete design');
}

export async function listMyDesignAssets(signal?: AbortSignal): Promise<DesignAssetDTO[]> {
  const response = await apiGet<DesignAssetListResponseData>('/designs/assets', signal);
  return unwrap(response, 'Unable to load uploaded artwork').assets;
}

export async function uploadDesignAsset(file: File, signal?: AbortSignal): Promise<DesignAssetDTO> {
  const formData = new FormData();
  formData.append('file', file, file.name);
  const response = await apiUploadFormData<DesignAssetUploadResponseData>(
    '/designs/assets/upload',
    formData,
    signal
  );
  return unwrap(response, 'Unable to upload artwork').asset;
}

export async function exportDesignPrintMaster(
  designId: string,
  surfaceKey: PrintAreaSurfaceKey,
  signal?: AbortSignal
): Promise<DesignPrintExportDTO> {
  const response = await apiPost<DesignPrintExportResponseData>(
    `/designs/${designId}/surfaces/${surfaceKey}/export-print-master`,
    undefined,
    signal
  );
  return unwrap(response, 'Unable to export 300 DPI print master').printExport;
}

export async function addCustomDesignToCart(
  designId: string,
  payload: { variantId?: string; quantity: number; note?: string },
  signal?: AbortSignal
): Promise<CartDTO> {
  const response = await apiPost<CartResponseData>(
    `/designs/${designId}/add-to-cart`,
    payload,
    signal
  );
  return unwrap(response, 'Unable to add custom design to cart').cart;
}

export function resolveDesignAssetPreviewUrl(assetId: string): string {
  return buildApiUrl(`/designs/assets/${assetId}/preview`);
}

export function resolveDesignExportDownloadUrl(exportId: string): string {
  return buildApiUrl(`/designs/exports/${exportId}/download`);
}
