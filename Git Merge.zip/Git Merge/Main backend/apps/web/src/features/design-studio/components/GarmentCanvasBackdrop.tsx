import type { PrintAreaSurfaceKey } from '@your-choice/shared-types';

interface GarmentCanvasBackdropProps {
  garmentType: 't_shirt' | 'polo_shirt';
  surfaceKey: PrintAreaSurfaceKey;
  colorHex: string;
}

function getStrokeInk(colorHex: string): string {
  const clean = colorHex.replace('#', '');
  const r = Number.parseInt(clean.slice(0, 2), 16) || 0;
  const g = Number.parseInt(clean.slice(2, 4), 16) || 0;
  const b = Number.parseInt(clean.slice(4, 6), 16) || 0;
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.55 ? 'rgba(15, 23, 42, 0.24)' : 'rgba(248, 250, 252, 0.24)';
}

/**
 * Vector flat-lay studio garment silhouette aligned 1:1 to normalized [0..1] print-area mockupBounds.
 */
export function GarmentCanvasBackdrop({
  garmentType,
  surfaceKey,
  colorHex,
}: GarmentCanvasBackdropProps) {
  const seamInk = getStrokeInk(colorHex);
  const isPolo = garmentType === 'polo_shirt';
  const isBack = surfaceKey === 'back';
  const isSleeve = surfaceKey === 'left_sleeve' || surfaceKey === 'right_sleeve';

  if (isSleeve) {
    return (
      <svg
        viewBox="0 0 1000 1000"
        className="h-full w-full select-none pointer-events-none drop-shadow-[0_24px_38px_rgba(2,6,23,0.18)]"
        aria-hidden="true"
      >
        <path
          d="M 220 140 L 760 220 L 830 810 C 660 855 340 855 170 810 Z"
          fill={colorHex}
          stroke={seamInk}
          strokeWidth="6"
          strokeLinejoin="round"
        />
        <path
          d="M 190 760 Q 500 800 810 760"
          fill="none"
          stroke={seamInk}
          strokeWidth="4"
          strokeDasharray="10 8"
        />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 1000 1000"
      className="h-full w-full select-none pointer-events-none drop-shadow-[0_24px_42px_rgba(2,6,23,0.2)]"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="ycGarmentSheen" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="rgba(255,255,255,0.11)" />
          <stop offset="50%" stopColor="rgba(255,255,255,0)" />
          <stop offset="100%" stopColor="rgba(2,6,23,0.14)" />
        </linearGradient>
      </defs>

      {/* Main Garment Silhouette */}
      <path
        d={
          isPolo
            ? 'M 335 125 L 408 106 Q 500 155 592 106 L 665 125 L 915 245 L 855 430 L 745 385 L 745 905 Q 500 926 255 905 L 255 385 L 145 430 L 85 245 Z'
            : 'M 340 120 L 405 104 Q 500 165 595 104 L 660 120 L 915 250 L 850 432 L 742 385 L 742 904 Q 500 924 258 904 L 258 385 L 150 432 L 85 250 Z'
        }
        fill={colorHex}
        stroke={seamInk}
        strokeWidth="5"
        strokeLinejoin="round"
      />
      <path
        d="M 340 120 L 405 104 Q 500 165 595 104 L 660 120 L 915 250 L 850 432 L 742 385 L 742 904 Q 500 924 258 904 L 258 385 L 150 432 L 85 250 Z"
        fill="url(#ycGarmentSheen)"
      />

      {/* Collar + Placket Construction Lines */}
      {isBack ? (
        <path
          d="M 405 106 Q 500 132 595 106"
          fill="none"
          stroke={seamInk}
          strokeWidth="6"
          strokeLinecap="round"
        />
      ) : (
        <>
          <path
            d={isPolo ? 'M 405 106 Q 500 175 595 106' : 'M 405 106 Q 500 198 595 106'}
            fill="none"
            stroke={seamInk}
            strokeWidth="7"
            strokeLinecap="round"
          />
          {isPolo ? (
            <>
              <path
                d="M 406 108 L 368 175 L 478 168 L 500 148 L 522 168 L 632 175 L 594 108"
                fill="none"
                stroke={seamInk}
                strokeWidth="4.5"
                strokeLinejoin="round"
              />
              <rect
                x="484"
                y="150"
                width="32"
                height="135"
                rx="6"
                fill="none"
                stroke={seamInk}
                strokeWidth="4"
              />
              <circle cx="500" cy="195" r="5" fill={seamInk} />
              <circle cx="500" cy="245" r="5" fill={seamInk} />
            </>
          ) : null}
        </>
      )}

      {/* Subtle Shoulder & Bottom Hem Stitching */}
      <path
        d="M 262 865 Q 500 886 738 865"
        fill="none"
        stroke={seamInk}
        strokeWidth="3"
        strokeDasharray="10 8"
      />
      <path
        d="M 150 400 L 254 360"
        fill="none"
        stroke={seamInk}
        strokeWidth="3"
        strokeDasharray="8 6"
      />
      <path
        d="M 850 400 L 746 360"
        fill="none"
        stroke={seamInk}
        strokeWidth="3"
        strokeDasharray="8 6"
      />
    </svg>
  );
}
