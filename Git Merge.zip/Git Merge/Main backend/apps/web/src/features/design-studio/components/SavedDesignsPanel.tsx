import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge, Button, Card, CardContent } from '@your-choice/ui';
import { ExternalLink, Layers, Loader2, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatBdtPrice, pickLocalizedText, useAppLocale } from '@/i18n';
import { deleteDesign, listMyDesigns } from '../design-studio.api';

interface SavedDesignsPanelProps {
  onSelectDesign?: (designId: string) => void;
  compact?: boolean;
}

export function SavedDesignsPanel({ onSelectDesign, compact = false }: SavedDesignsPanelProps) {
  const { locale, t } = useAppLocale();
  const queryClient = useQueryClient();

  const designsQuery = useQuery({
    queryKey: ['my-designs'],
    queryFn: ({ signal }) => listMyDesigns(1, 20, signal),
    staleTime: 20_000,
  });

  const deleteMutation = useMutation({
    mutationFn: (designId: string) => deleteDesign(designId),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['my-designs'] });
    },
  });

  if (designsQuery.isLoading) {
    return (
      <div className="flex items-center gap-2 py-8 text-sm text-ink-muted">
        <Loader2 className="h-4 w-4 animate-spin" />
        <span>{t('studio.loadingSavedDesigns')}</span>
      </div>
    );
  }

  const items = designsQuery.data?.designs ?? [];
  if (items.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-border p-6 text-center">
        <Layers className="mx-auto mb-2 h-6 w-6 text-ink-muted" />
        <p className="text-sm font-medium text-ink">{t('studio.noSavedDesignsTitle')}</p>
        <p className="mt-1 text-xs text-ink-muted">{t('studio.noSavedDesignsSubtitle')}</p>
        <div className="mt-4">
          <Button asChild size="sm">
            <Link to="/studio">{t('studio.openDesignStudio')}</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className={compact ? 'space-y-3' : 'grid gap-4 sm:grid-cols-2'}>
      {items.map((design) => (
        <Card key={design.id} className="border-border">
          <CardContent className="flex flex-col gap-3 p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="truncate font-semibold text-ink">{design.title}</p>
                <p className="truncate text-xs text-ink-muted">
                  {pickLocalizedText(locale, design.productNameEn, design.productNameBn)} ·{' '}
                  {pickLocalizedText(locale, design.variantColorNameEn, design.variantColorNameBn)}{' '}
                  ({design.variantSizeCode})
                </p>
              </div>
              <Badge variant={design.isValidForPrint ? 'success' : 'warning'} className="shrink-0">
                v{design.currentVersionNumber}
              </Badge>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs text-ink-muted">
              <span
                className="inline-block h-3 w-3 rounded-full border border-black/20"
                style={{ backgroundColor: design.variantColorHex }}
              />
              <span>
                {design.customizedSurfaces.length > 0
                  ? design.customizedSurfaces.join(', ')
                  : t('studio.emptySurface')}
              </span>
              <span>·</span>
              <span className="font-mono font-medium text-ink">
                +{formatBdtPrice(design.estimatedCustomizationFee)}
              </span>
            </div>

            <div className="flex items-center justify-between gap-2 pt-1">
              {onSelectDesign ? (
                <Button type="button" size="sm" onClick={() => onSelectDesign(design.id)}>
                  {t('studio.loadDesign')}
                </Button>
              ) : (
                <Button asChild size="sm">
                  <Link to={`/studio/${design.id}`}>
                    <ExternalLink className="mr-1.5 h-3.5 w-3.5" />
                    {t('studio.editInStudio')}
                  </Link>
                </Button>
              )}
              <Button
                type="button"
                size="sm"
                variant="outline"
                aria-label={`${t('studio.deleteDesign')} ${design.title}`}
                disabled={deleteMutation.isPending}
                onClick={() => deleteMutation.mutate(design.id)}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
