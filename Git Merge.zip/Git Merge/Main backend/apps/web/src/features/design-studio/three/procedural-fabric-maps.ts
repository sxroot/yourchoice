import * as THREE from 'three';

const fabricBumpCache = new Map<'jersey' | 'pique', THREE.CanvasTexture>();

/**
 * Procedurally synthesizes a tileable micro-weave cotton bump map (zero external network assets).
 */
export function getProceduralFabricBumpMap(
  fabricKind: 'jersey' | 'pique'
): THREE.CanvasTexture | null {
  if (typeof document === 'undefined') {
    return null;
  }

  const cached = fabricBumpCache.get(fabricKind);
  if (cached) {
    return cached;
  }

  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return null;
  }

  const imgData = ctx.createImageData(size, size);
  const data = imgData.data;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let lum;
      if (fabricKind === 'pique') {
        // Honeycomb knit cell dimples
        const u = (x % 8) / 8;
        const v = (y % 8) / 8;
        const staggeredU = ((x + (y & 8 ? 4 : 0)) % 8) / 8;
        const wave =
          Math.sin(staggeredU * Math.PI * 2) * Math.sin(v * Math.PI * 2) +
          0.35 * Math.cos(u * Math.PI * 4);
        lum = Math.max(0, Math.min(255, Math.round(128 + wave * 34)));
      } else {
        // Fine cotton jersey vertical rib stitch
        const rib = Math.sin((x % 4) * (Math.PI / 2)) * 18;
        const course = Math.cos((y % 4) * (Math.PI / 2)) * 10;
        const microGrain = (((x * 37 + y * 91) % 19) - 9) * 1.4;
        lum = Math.max(0, Math.min(255, Math.round(128 + rib + course + microGrain)));
      }

      const idx = (y * size + x) * 4;
      data[idx] = lum;
      data[idx + 1] = lum;
      data[idx + 2] = lum;
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(fabricKind === 'pique' ? 14 : 18, fabricKind === 'pique' ? 14 : 18);
  texture.colorSpace = THREE.NoColorSpace;
  texture.needsUpdate = true;

  fabricBumpCache.set(fabricKind, texture);
  return texture;
}
