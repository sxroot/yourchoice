import type {
  DesignPrintExportDTO,
  DesignValidationReport,
  PrintAreaSurfaceKey,
  ProductPrintAreaDTO,
} from '@your-choice/shared-types';
import {
  Badge,
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@your-choice/ui';
import { Download, FileCheck2, Loader2, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { pickLocalizedText, useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';
import { exportDesignPrintMaster, resolveDesignExportDownloadUrl } from '../design-studio.api';

interface PrintExportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  designId: string | null;
  isDirty: boolean;
  activeSurfaces: ProductPrintAreaDTO[];
  validation: DesignValidationReport | null;
  exportsHistory: DesignPrintExportDTO[];
  onSaveBeforeExport: () => Promise<string | null>;
  onExportSuccess: (created: DesignPrintExportDTO) => void;
}

export function PrintExportModal({
  open,
  onOpenChange,
  designId,
  isDirty,
  activeSurfaces,
  validation,
  exportsHistory,
  onSaveBeforeExport,
  onExportSuccess,
}: PrintExportModalProps) {
  const { locale, t } = useAppLocale();
  const [selectedSurface, setSelectedSurface] = useState<PrintAreaSurfaceKey>(
    activeSurfaces[0]?.surfaceKey ?? 'front'
  );
  const [isExporting, setIsExporting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [latestExport, setLatestExport] = useState<DesignPrintExportDTO | null>(null);

  const populatedKeys = new Set(validation?.activePrintSurfaces ?? []);
  const currentSurfaceArea = activeSurfaces.find((a) => a.surfaceKey === selectedSurface);
  const targetPxW = currentSurfaceArea
    ? Math.round((currentSurfaceArea.physicalWidthMm / 25.4) * currentSurfaceArea.targetDpi)
    : 3307;
  const targetPxH = currentSurfaceArea
    ? Math.round((currentSurfaceArea.physicalHeightMm / 25.4) * currentSurfaceArea.targetDpi)
    : 4252;

  const handleGenerateExport = async () => {
    setErrorMessage(null);
    setIsExporting(true);
    try {
      let targetDesignId = designId;
      if (!targetDesignId || isDirty) {
        targetDesignId = await onSaveBeforeExport();
      }
      if (!targetDesignId) {
        setIsExporting(false);
        return;
      }

      const generated = await exportDesignPrintMaster(targetDesignId, selectedSurface);
      setLatestExport(generated);
      onExportSuccess(generated);
    } catch (err) {
      setErrorMessage(err instanceof ApiClientError ? err.message : t('studio.exportFailed'));
    } finally {
      setIsExporting(false);
    }
  };

  const recentList = latestExport
    ? [latestExport, ...exportsHistory.filter((item) => item.id !== latestExport.id)]
    : exportsHistory;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileCheck2 className="h-4 w-4 text-accent" />
            <span>{t('studio.exportTitle')}</span>
          </DialogTitle>
          <DialogDescription>{t('studio.exportSubtitle')}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-xl border border-border bg-canvas p-3.5 text-xs text-ink-muted">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
              <div className="space-y-1">
                <p className="font-semibold text-ink">{t('studio.dtfBoundaryTitle')}</p>
                <p>{t('studio.dtfBoundaryNote')}</p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted">
              {t('studio.chooseExportSurface')}
            </p>
            <div className="grid grid-cols-2 gap-2">
              {activeSurfaces.map((area) => {
                const hasArt = populatedKeys.has(area.surfaceKey);
                const selected = area.surfaceKey === selectedSurface;
                return (
                  <button
                    key={area.id}
                    type="button"
                    disabled={!hasArt}
                    onClick={() => setSelectedSurface(area.surfaceKey)}
                    className={`flex min-h-11 flex-col items-start justify-center rounded-lg border px-3 py-2 text-left transition ${
                      selected
                        ? 'border-accent bg-accent-soft text-ink'
                        : 'border-border bg-surface text-ink-muted'
                    } ${!hasArt ? 'cursor-not-allowed opacity-45' : 'hover:border-accent/50'}`}
                  >
                    <span className="text-xs font-semibold">
                      {pickLocalizedText(locale, area.labelEn, area.labelBn)}
                    </span>
                    <span className="font-mono text-[11px] opacity-80">
                      {area.physicalWidthMm}×{area.physicalHeightMm}mm @ {area.targetDpi} DPI
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border px-3 py-2 text-xs">
            <span className="text-ink-muted">{t('studio.expectedOutputResolution')}</span>
            <Badge variant="neutral" className="font-mono">
              {targetPxW} × {targetPxH} px · RGBA Transparent PNG
            </Badge>
          </div>

          {!validation?.isValidForPrint ? (
            <p className="rounded-lg border border-warning/40 bg-warning-soft px-3 py-2 text-xs text-warning">
              {t('studio.exportBlockedHint')}
            </p>
          ) : null}

          {errorMessage ? (
            <p role="alert" className="text-xs font-medium text-danger">
              {errorMessage}
            </p>
          ) : null}

          {recentList.length > 0 ? (
            <div className="space-y-2 border-t border-border pt-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted">
                {t('studio.generatedMasters')}
              </p>
              <div className="max-h-40 space-y-2 overflow-y-auto pr-1">
                {recentList.slice(0, 4).map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between gap-3 rounded-lg border border-border px-3 py-2 text-xs"
                  >
                    <div className="min-w-0">
                      <p className="font-semibold uppercase text-ink">
                        {item.surfaceKey} · v{item.designVersionNumber} ({item.widthPx}×
                        {item.heightPx}px)
                      </p>
                      <p className="truncate font-mono text-[11px] text-ink-muted">
                        SHA-256: {item.sha256.slice(0, 16)}… · {(item.byteSize / 1024).toFixed(1)}{' '}
                        KB
                      </p>
                    </div>
                    <a
                      href={resolveDesignExportDownloadUrl(item.id)}
                      download
                      className="inline-flex min-h-9 shrink-0 items-center gap-1.5 rounded-md bg-accent px-3 py-1.5 text-xs font-semibold text-white hover:bg-accent-hover"
                    >
                      <Download className="h-3.5 w-3.5" />
                      {t('studio.downloadPng')}
                    </a>
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </div>

        <DialogFooter className="gap-2">
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            {t('common.close')}
          </Button>
          <Button
            type="button"
            disabled={
              isExporting || !populatedKeys.has(selectedSurface) || !validation?.isValidForPrint
            }
            onClick={() => void handleGenerateExport()}
          >
            {isExporting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {t('studio.generatePrintPng')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
