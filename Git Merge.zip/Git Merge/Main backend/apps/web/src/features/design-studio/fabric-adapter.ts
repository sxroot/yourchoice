import type {
  CanonicalDesignObject,
  CanonicalDesignSurface,
  CanonicalGraphicObject,
  CanonicalGroupObject,
  CanonicalImageObject,
  CanonicalShapeObject,
  CanonicalTextObject,
  DesignAssetDTO,
  StudioGraphicPackItem,
  StudioShapeKind,
} from '@your-choice/shared-types';
import {
  ActiveSelection,
  type Canvas,
  Circle,
  FabricImage,
  type FabricObject,
  Group,
  IText,
  Line,
  Path,
  Point,
  Polygon,
  Rect,
  Triangle,
} from 'fabric';
import { resolveDesignAssetPreviewUrl } from './design-studio.api';
import { getStudioFontPreset } from './fonts';

type LeafCanonicalObject =
  CanonicalTextObject | CanonicalShapeObject | CanonicalGraphicObject | CanonicalImageObject;

export interface FabricObjectCustomMeta {
  id: string;
  name: string;
  canonicalType: CanonicalDesignObject['type'];
  locked: boolean;
  shapeKind?: StudioShapeKind;
  cornerRadius?: number;
  graphicId?: string;
  pathData?: string;
  viewBoxSize?: number;
  assetId?: string;
  naturalWidthPx?: number;
  naturalHeightPx?: number;
  cropRect?: CanonicalImageObject['cropRect'];
  fontFamilyRaw?: string;
  fontSizeRatioFallback?: number;
}

const objectMetaMap = new WeakMap<FabricObject, FabricObjectCustomMeta>();

function setObjectMeta(obj: FabricObject, meta: FabricObjectCustomMeta): void {
  objectMetaMap.set(obj, meta);
}

export function getObjectMeta(obj: FabricObject): FabricObjectCustomMeta | undefined {
  return objectMetaMap.get(obj);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function roundNorm(value: number): number {
  return Number(value.toFixed(5));
}

function normalizeHex(color: unknown, fallback = '#0F172A'): string {
  if (typeof color === 'string' && /^#[0-9a-fA-F]{6}$/.test(color.trim())) {
    return color.trim().toUpperCase();
  }
  return fallback;
}

function normalizeOptionalHex(color: unknown): string | null {
  if (typeof color === 'string' && /^#[0-9a-fA-F]{6}$/.test(color.trim())) {
    return color.trim().toUpperCase();
  }
  return null;
}

function createStarPoints(outerRadius: number, innerRadius: number, pointsCount = 5) {
  const pts: Array<{ x: number; y: number }> = [];
  for (let i = 0; i < pointsCount * 2; i += 1) {
    const r = i % 2 === 0 ? outerRadius : innerRadius;
    const angle = (Math.PI / pointsCount) * i - Math.PI / 2;
    pts.push({ x: Math.cos(angle) * r, y: Math.sin(angle) * r });
  }
  return pts;
}

function createPolygonPoints(radius: number, sides: number) {
  const pts: Array<{ x: number; y: number }> = [];
  for (let i = 0; i < sides; i += 1) {
    const angle = ((Math.PI * 2) / sides) * i - Math.PI / 2;
    pts.push({ x: Math.cos(angle) * radius, y: Math.sin(angle) * radius });
  }
  return pts;
}

export function createObjectId(prefix: string): string {
  const rand =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10);
  return `${prefix}-${rand}`;
}

export function createCanonicalTextObject(
  indexHint: number,
  fontFamily = 'Outfit',
  text = 'YOUR CHOICE'
): CanonicalTextObject {
  const stagger = (indexHint % 4) * 0.035;
  return {
    id: createObjectId('txt'),
    type: 'text',
    name: `Text ${indexHint + 1}`,
    x: roundNorm(0.2 + stagger * 0.5),
    y: roundNorm(0.22 + stagger),
    width: 0.56,
    height: 0.14,
    rotationDeg: 0,
    opacity: 1,
    flipX: false,
    flipY: false,
    visible: true,
    locked: false,
    text,
    fontFamily,
    fontSizeRatio: 0.095,
    fontWeight: 700,
    fontStyle: 'normal',
    textAlign: 'center',
    lineHeight: 1.15,
    letterSpacing: 40,
    fill: '#1D4ED8',
    stroke: null,
    strokeWidth: 0,
  };
}

export function createCanonicalShapeObject(
  shapeKind: StudioShapeKind,
  indexHint: number,
  fill = '#2563EB'
): CanonicalShapeObject {
  const stagger = (indexHint % 4) * 0.035;
  return {
    id: createObjectId('shp'),
    type: 'shape',
    name: `${shapeKind.charAt(0).toUpperCase()}${shapeKind.slice(1)} ${indexHint + 1}`,
    x: roundNorm(0.32 + stagger * 0.5),
    y: roundNorm(0.32 + stagger),
    width: 0.34,
    height: shapeKind === 'line' ? 0.04 : 0.28,
    rotationDeg: 0,
    opacity: 1,
    flipX: false,
    flipY: false,
    visible: true,
    locked: false,
    shapeKind,
    fill,
    stroke: '#0F172A',
    strokeWidth: shapeKind === 'line' ? 6 : 2,
    cornerRadius: shapeKind === 'rect' ? 12 : 0,
  };
}

export function createCanonicalGraphicObject(
  item: StudioGraphicPackItem,
  indexHint: number
): CanonicalGraphicObject {
  const stagger = (indexHint % 4) * 0.035;
  return {
    id: createObjectId('gfx'),
    type: 'graphic',
    name: item.labelEn,
    x: roundNorm(0.31 + stagger * 0.4),
    y: roundNorm(0.28 + stagger),
    width: 0.36,
    height: 0.32,
    rotationDeg: 0,
    opacity: 1,
    flipX: false,
    flipY: false,
    visible: true,
    locked: false,
    graphicId: item.id,
    pathData: item.pathData,
    viewBoxSize: item.viewBoxSize,
    fill: item.defaultFill,
    stroke: item.defaultStroke,
    strokeWidth: 2,
  };
}

export function createCanonicalImageObject(
  asset: DesignAssetDTO,
  surfacePhysicalWidthMm: number,
  surfacePhysicalHeightMm: number,
  cropRect: CanonicalImageObject['cropRect'] = null
): CanonicalImageObject {
  const effectiveW = asset.widthPx * (cropRect ? cropRect.width : 1);
  const effectiveH = asset.heightPx * (cropRect ? cropRect.height : 1);
  const imgAspect = effectiveW / Math.max(1, effectiveH);
  const surfaceAspect = surfacePhysicalWidthMm / Math.max(1, surfacePhysicalHeightMm);

  let width = 0.54;
  let height = (width * surfaceAspect) / Math.max(0.1, imgAspect);
  if (height > 0.6) {
    height = 0.6;
    width = (height * imgAspect) / Math.max(0.1, surfaceAspect);
  }

  return {
    id: createObjectId('img'),
    type: 'image',
    name: asset.originalFilename.slice(0, 48) || 'Uploaded Artwork',
    x: roundNorm((1 - width) / 2),
    y: roundNorm((1 - height) / 2),
    width: roundNorm(clamp(width, 0.08, 0.92)),
    height: roundNorm(clamp(height, 0.08, 0.92)),
    rotationDeg: 0,
    opacity: 1,
    flipX: false,
    flipY: false,
    visible: true,
    locked: false,
    assetId: asset.id,
    naturalWidthPx: asset.widthPx,
    naturalHeightPx: asset.heightPx,
    cropRect,
  };
}

function applyCommonControlsAndLock(obj: FabricObject, locked: boolean): void {
  obj.set({
    originX: 'center',
    originY: 'center',
    cornerColor: '#2563EB',
    cornerStrokeColor: '#FFFFFF',
    borderColor: '#2563EB',
    cornerStyle: 'circle',
    cornerSize: 10,
    transparentCorners: false,
    borderScaleFactor: 1.5,
    selectable: !locked,
    evented: !locked,
    lockMovementX: locked,
    lockMovementY: locked,
    lockRotation: locked,
    lockScalingX: locked,
    lockScalingY: locked,
    hasControls: !locked,
  });
}

async function buildLeafFabricObject(
  node: LeafCanonicalObject,
  boxWidth: number,
  boxHeight: number,
  centerX: number,
  centerY: number
): Promise<FabricObject | null> {
  const commonProps = {
    left: centerX,
    top: centerY,
    angle: node.rotationDeg,
    opacity: node.opacity,
    flipX: node.flipX,
    flipY: node.flipY,
    visible: node.visible,
  };

  if (node.type === 'text') {
    const preset = getStudioFontPreset(node.fontFamily);
    const fontSize = Math.max(12, node.fontSizeRatio * boxHeight);
    const textObj = new IText(node.text, {
      ...commonProps,
      fontFamily: preset.fallbackStack,
      fontSize,
      fontWeight: node.fontWeight,
      fontStyle: node.fontStyle,
      textAlign: node.textAlign,
      lineHeight: node.lineHeight,
      charSpacing: node.letterSpacing,
      fill: node.fill,
      stroke: node.stroke ?? undefined,
      strokeWidth: node.stroke ? (node.strokeWidth * boxWidth) / 1000 : 0,
    });
    textObj.initDimensions();
    if (textObj.width > 0 && textObj.height > 0) {
      const targetW = Math.max(12, node.width * boxWidth);
      const targetH = Math.max(12, node.height * boxHeight);
      textObj.set({
        scaleX: targetW / textObj.width,
        scaleY: targetH / textObj.height,
      });
    }
    applyCommonControlsAndLock(textObj, node.locked);
    setObjectMeta(textObj, {
      id: node.id,
      name: node.name,
      canonicalType: 'text',
      locked: node.locked,
      fontFamilyRaw: node.fontFamily,
      fontSizeRatioFallback: node.fontSizeRatio,
    });
    return textObj;
  }

  if (node.type === 'shape') {
    const targetW = Math.max(12, node.width * boxWidth);
    const targetH = Math.max(8, node.height * boxHeight);
    const strokeW = node.stroke ? (node.strokeWidth * boxWidth) / 1000 : 0;
    let shapeObj: FabricObject;

    switch (node.shapeKind) {
      case 'circle': {
        shapeObj = new Circle({
          ...commonProps,
          radius: Math.max(6, Math.min(targetW, targetH) / 2),
          fill: node.fill,
          stroke: node.stroke ?? undefined,
          strokeWidth: strokeW,
        });
        const naturalD = Math.max(12, Math.min(targetW, targetH));
        shapeObj.set({ scaleX: targetW / naturalD, scaleY: targetH / naturalD });
        break;
      }
      case 'triangle': {
        shapeObj = new Triangle({
          ...commonProps,
          width: targetW,
          height: targetH,
          fill: node.fill,
          stroke: node.stroke ?? undefined,
          strokeWidth: strokeW,
        });
        break;
      }
      case 'star': {
        shapeObj = new Polygon(createStarPoints(100, 44, 5), {
          ...commonProps,
          fill: node.fill,
          stroke: node.stroke ?? undefined,
          strokeWidth: strokeW,
        });
        shapeObj.set({
          scaleX: targetW / Math.max(1, shapeObj.width),
          scaleY: targetH / Math.max(1, shapeObj.height),
        });
        break;
      }
      case 'hexagon': {
        shapeObj = new Polygon(createPolygonPoints(100, 6), {
          ...commonProps,
          fill: node.fill,
          stroke: node.stroke ?? undefined,
          strokeWidth: strokeW,
        });
        shapeObj.set({
          scaleX: targetW / Math.max(1, shapeObj.width),
          scaleY: targetH / Math.max(1, shapeObj.height),
        });
        break;
      }
      case 'line': {
        shapeObj = new Line([-targetW / 2, 0, targetW / 2, 0], {
          ...commonProps,
          fill: node.fill,
          stroke: node.stroke ?? node.fill,
          strokeWidth: Math.max(3, (node.strokeWidth * boxWidth) / 1000),
          strokeLineCap: 'round',
        });
        break;
      }
      case 'rect':
      default: {
        shapeObj = new Rect({
          ...commonProps,
          width: targetW,
          height: targetH,
          rx: node.cornerRadius,
          ry: node.cornerRadius,
          fill: node.fill,
          stroke: node.stroke ?? undefined,
          strokeWidth: strokeW,
        });
        break;
      }
    }

    applyCommonControlsAndLock(shapeObj, node.locked);
    setObjectMeta(shapeObj, {
      id: node.id,
      name: node.name,
      canonicalType: 'shape',
      locked: node.locked,
      shapeKind: node.shapeKind,
      cornerRadius: node.cornerRadius,
    });
    return shapeObj;
  }

  if (node.type === 'graphic') {
    const targetW = Math.max(14, node.width * boxWidth);
    const targetH = Math.max(14, node.height * boxHeight);
    const pathObj = new Path(node.pathData, {
      ...commonProps,
      fill: node.fill,
      stroke: node.stroke ?? undefined,
      strokeWidth: node.stroke ? (node.strokeWidth * boxWidth) / 1000 : 0,
    });
    pathObj.set({
      scaleX: targetW / Math.max(1, pathObj.width),
      scaleY: targetH / Math.max(1, pathObj.height),
    });
    applyCommonControlsAndLock(pathObj, node.locked);
    setObjectMeta(pathObj, {
      id: node.id,
      name: node.name,
      canonicalType: 'graphic',
      locked: node.locked,
      graphicId: node.graphicId,
      pathData: node.pathData,
      viewBoxSize: node.viewBoxSize,
    });
    return pathObj;
  }

  // Image asset node
  try {
    const imageUrl = resolveDesignAssetPreviewUrl(node.assetId);
    const imgObj = await FabricImage.fromURL(imageUrl, { crossOrigin: 'use-credentials' });
    const srcW = imgObj.width || node.naturalWidthPx || 200;
    const srcH = imgObj.height || node.naturalHeightPx || 200;
    const targetW = Math.max(14, node.width * boxWidth);
    const targetH = Math.max(14, node.height * boxHeight);

    if (node.cropRect) {
      const cropX = Math.round(node.cropRect.x * srcW);
      const cropY = Math.round(node.cropRect.y * srcH);
      const cropW = Math.max(10, Math.round(node.cropRect.width * srcW));
      const cropH = Math.max(10, Math.round(node.cropRect.height * srcH));
      imgObj.set({
        cropX,
        cropY,
        width: cropW,
        height: cropH,
        scaleX: targetW / cropW,
        scaleY: targetH / cropH,
      });
    } else {
      imgObj.set({
        scaleX: targetW / srcW,
        scaleY: targetH / srcH,
      });
    }

    imgObj.set(commonProps);
    applyCommonControlsAndLock(imgObj, node.locked);
    setObjectMeta(imgObj, {
      id: node.id,
      name: node.name,
      canonicalType: 'image',
      locked: node.locked,
      assetId: node.assetId,
      naturalWidthPx: node.naturalWidthPx,
      naturalHeightPx: node.naturalHeightPx,
      cropRect: node.cropRect,
    });
    return imgObj;
  } catch {
    const placeholder = new Rect({
      ...commonProps,
      width: Math.max(24, node.width * boxWidth),
      height: Math.max(24, node.height * boxHeight),
      fill: '#E2E8F0',
      stroke: '#94A3B8',
      strokeWidth: 2,
      strokeDashArray: [6, 4],
    });
    applyCommonControlsAndLock(placeholder, node.locked);
    setObjectMeta(placeholder, {
      id: node.id,
      name: node.name,
      canonicalType: 'image',
      locked: node.locked,
      assetId: node.assetId,
      naturalWidthPx: node.naturalWidthPx,
      naturalHeightPx: node.naturalHeightPx,
      cropRect: node.cropRect,
    });
    return placeholder;
  }
}

export async function hydrateSurfaceToFabricCanvas(
  canvas: Canvas,
  surface: CanonicalDesignSurface,
  stageWidth: number,
  stageHeight: number
): Promise<void> {
  canvas.clear();
  for (const node of surface.objects) {
    const cx = (node.x + node.width / 2) * stageWidth;
    const cy = (node.y + node.height / 2) * stageHeight;

    if (node.type === 'group') {
      const groupW = Math.max(20, node.width * stageWidth);
      const groupH = Math.max(20, node.height * stageHeight);
      const childObjs: FabricObject[] = [];
      for (const child of node.children) {
        const childCx = (child.x + child.width / 2 - 0.5) * groupW;
        const childCy = (child.y + child.height / 2 - 0.5) * groupH;
        const built = await buildLeafFabricObject(child, groupW, groupH, childCx, childCy);
        if (built) {
          childObjs.push(built);
        }
      }

      if (childObjs.length > 0) {
        const group = new Group(childObjs, {
          left: cx,
          top: cy,
          angle: node.rotationDeg,
          opacity: node.opacity,
          flipX: node.flipX,
          flipY: node.flipY,
          visible: node.visible,
        });
        applyCommonControlsAndLock(group, node.locked);
        setObjectMeta(group, {
          id: node.id,
          name: node.name,
          canonicalType: 'group',
          locked: node.locked,
        });
        canvas.add(group);
      }
      continue;
    }

    const built = await buildLeafFabricObject(node, stageWidth, stageHeight, cx, cy);
    if (built) {
      canvas.add(built);
    }
  }

  canvas.requestRenderAll();
}

function serializeLeafFabricObject(
  obj: FabricObject,
  refWidth: number,
  refHeight: number,
  cx: number,
  cy: number,
  renderedW: number,
  renderedH: number
): LeafCanonicalObject | null {
  const meta = getObjectMeta(obj);
  const id = meta?.id ?? createObjectId('obj');
  const name = meta?.name ?? 'Design Element';

  const normWidth = roundNorm(clamp(renderedW / Math.max(1, refWidth), 0.005, 1.5));
  const normHeight = roundNorm(clamp(renderedH / Math.max(1, refHeight), 0.005, 1.5));
  const normX = roundNorm(clamp((cx - renderedW / 2) / Math.max(1, refWidth), -0.25, 1.25));
  const normY = roundNorm(clamp((cy - renderedH / 2) / Math.max(1, refHeight), -0.25, 1.25));

  const base = {
    id,
    name,
    x: normX,
    y: normY,
    width: normWidth,
    height: normHeight,
    rotationDeg: Number(((obj.angle ?? 0) % 360).toFixed(2)),
    opacity: Number(clamp(obj.opacity ?? 1, 0, 1).toFixed(3)),
    flipX: Boolean(obj.flipX),
    flipY: Boolean(obj.flipY),
    visible: obj.visible !== false,
    locked: Boolean(meta?.locked),
  };

  if (obj instanceof IText || meta?.canonicalType === 'text') {
    const textInstance = obj as IText;
    const scaledFontSize = (textInstance.fontSize ?? 32) * Math.abs(textInstance.scaleY ?? 1);
    const fontFamily = meta?.fontFamilyRaw ?? 'Outfit';
    const strokeHex = normalizeOptionalHex(textInstance.stroke);
    const strokeWidthNorm = strokeHex
      ? Number(
          clamp(
            (((textInstance.strokeWidth ?? 0) * Math.abs(textInstance.scaleX ?? 1)) /
              Math.max(1, refWidth)) *
              1000,
            0,
            40
          ).toFixed(2)
        )
      : 0;

    return {
      ...base,
      type: 'text',
      text: (textInstance.text ?? 'Text').slice(0, 500) || 'Text',
      fontFamily,
      fontSizeRatio: Number(clamp(scaledFontSize / Math.max(1, refHeight), 0.01, 0.85).toFixed(5)),
      fontWeight:
        textInstance.fontWeight === 400 || textInstance.fontWeight === 700
          ? textInstance.fontWeight
          : 600,
      fontStyle: textInstance.fontStyle === 'italic' ? 'italic' : 'normal',
      textAlign:
        textInstance.textAlign === 'left' || textInstance.textAlign === 'right'
          ? textInstance.textAlign
          : 'center',
      lineHeight: Number(clamp(textInstance.lineHeight ?? 1.15, 0.75, 3).toFixed(2)),
      letterSpacing: Math.round(clamp(textInstance.charSpacing ?? 0, -100, 800)),
      fill: normalizeHex(textInstance.fill, '#1D4ED8'),
      stroke: strokeHex,
      strokeWidth: strokeWidthNorm,
    };
  }

  if (meta?.canonicalType === 'graphic' && meta.pathData) {
    const strokeHex = normalizeOptionalHex(obj.stroke);
    return {
      ...base,
      type: 'graphic',
      graphicId: meta.graphicId ?? 'yc-graphic',
      pathData: meta.pathData,
      viewBoxSize: meta.viewBoxSize ?? 100,
      fill: normalizeHex(obj.fill, '#2563EB'),
      stroke: strokeHex,
      strokeWidth: strokeHex
        ? Number(
            clamp(
              (((obj.strokeWidth ?? 0) * Math.abs(obj.scaleX ?? 1)) / Math.max(1, refWidth)) * 1000,
              0,
              40
            ).toFixed(2)
          )
        : 0,
    };
  }

  if (meta?.canonicalType === 'image' && meta.assetId) {
    return {
      ...base,
      type: 'image',
      assetId: meta.assetId,
      naturalWidthPx: meta.naturalWidthPx ?? 1000,
      naturalHeightPx: meta.naturalHeightPx ?? 1000,
      cropRect: meta.cropRect ?? null,
    };
  }

  const shapeKind: StudioShapeKind =
    meta?.shapeKind ??
    (obj instanceof Circle
      ? 'circle'
      : obj instanceof Triangle
        ? 'triangle'
        : obj instanceof Line
          ? 'line'
          : 'rect');
  const strokeHex = normalizeOptionalHex(obj.stroke);
  return {
    ...base,
    type: 'shape',
    shapeKind,
    fill: normalizeHex(obj.fill, '#2563EB'),
    stroke: strokeHex,
    strokeWidth: strokeHex
      ? Number(clamp(((obj.strokeWidth ?? 0) / Math.max(1, refWidth)) * 1000, 0, 40).toFixed(2))
      : 0,
    cornerRadius:
      shapeKind === 'rect' && obj instanceof Rect ? Math.round(clamp(obj.rx ?? 0, 0, 200)) : 0,
  };
}

export function serializeFabricCanvasToObjects(
  canvas: Canvas,
  stageWidth: number,
  stageHeight: number
): CanonicalDesignObject[] {
  const result: CanonicalDesignObject[] = [];

  for (const obj of canvas.getObjects()) {
    const center = obj.getCenterPoint();
    const renderedW = Math.max(2, (obj.width ?? 10) * Math.abs(obj.scaleX ?? 1));
    const renderedH = Math.max(2, (obj.height ?? 10) * Math.abs(obj.scaleY ?? 1));
    const meta = getObjectMeta(obj);

    if (obj instanceof Group && meta?.canonicalType !== 'graphic') {
      const rawChildren = obj.getObjects();
      const gw = Math.max(2, obj.width ?? renderedW);
      const gh = Math.max(2, obj.height ?? renderedH);
      const children: LeafCanonicalObject[] = [];

      for (const child of rawChildren) {
        const childW = Math.max(2, (child.width ?? 10) * Math.abs(child.scaleX ?? 1));
        const childH = Math.max(2, (child.height ?? 10) * Math.abs(child.scaleY ?? 1));
        const childCx = (child.left ?? 0) + gw / 2;
        const childCy = (child.top ?? 0) + gh / 2;
        const serializedChild = serializeLeafFabricObject(
          child,
          gw,
          gh,
          childCx,
          childCy,
          childW,
          childH
        );
        if (serializedChild) {
          children.push(serializedChild);
        }
      }

      if (children.length > 0) {
        const groupCanonical: CanonicalGroupObject = {
          id: meta?.id ?? createObjectId('grp'),
          type: 'group',
          name: meta?.name ?? 'Group',
          x: roundNorm(clamp((center.x - renderedW / 2) / stageWidth, -0.25, 1.25)),
          y: roundNorm(clamp((center.y - renderedH / 2) / stageHeight, -0.25, 1.25)),
          width: roundNorm(clamp(renderedW / stageWidth, 0.005, 1.5)),
          height: roundNorm(clamp(renderedH / stageHeight, 0.005, 1.5)),
          rotationDeg: Number(((obj.angle ?? 0) % 360).toFixed(2)),
          opacity: Number(clamp(obj.opacity ?? 1, 0, 1).toFixed(3)),
          flipX: Boolean(obj.flipX),
          flipY: Boolean(obj.flipY),
          visible: obj.visible !== false,
          locked: Boolean(meta?.locked),
          children,
        };
        result.push(groupCanonical);
      }
      continue;
    }

    const leaf = serializeLeafFabricObject(
      obj,
      stageWidth,
      stageHeight,
      center.x,
      center.y,
      renderedW,
      renderedH
    );
    if (leaf) {
      result.push(leaf);
    }
  }

  return result;
}

export interface SnapGuidesState {
  verticalCenter: boolean;
  horizontalCenter: boolean;
}

export function attachSnapGuides(
  canvas: Canvas,
  stageWidth: number,
  stageHeight: number,
  isEnabled: () => boolean,
  onGuidesChange: (guides: SnapGuidesState) => void
): () => void {
  const THRESHOLD_PX = 7;

  const handleMoving = (evt: { target?: FabricObject }) => {
    const target = evt.target;
    if (!target || !isEnabled()) {
      onGuidesChange({ verticalCenter: false, horizontalCenter: false });
      return;
    }

    const center = target.getCenterPoint();
    let vSnap = false;
    let hSnap = false;
    let nextX = center.x;
    let nextY = center.y;

    if (Math.abs(center.x - stageWidth / 2) <= THRESHOLD_PX) {
      nextX = stageWidth / 2;
      vSnap = true;
    }
    if (Math.abs(center.y - stageHeight / 2) <= THRESHOLD_PX) {
      nextY = stageHeight / 2;
      hSnap = true;
    }

    if (vSnap || hSnap) {
      target.setPositionByOrigin(new Point(nextX, nextY), 'center', 'center');
      target.setCoords();
    }

    onGuidesChange({ verticalCenter: vSnap, horizontalCenter: hSnap });
  };

  const handleClear = () => {
    onGuidesChange({ verticalCenter: false, horizontalCenter: false });
  };

  canvas.on('object:moving', handleMoving);
  canvas.on('object:modified', handleClear);
  canvas.on('mouse:up', handleClear);

  return () => {
    canvas.off('object:moving', handleMoving);
    canvas.off('object:modified', handleClear);
    canvas.off('mouse:up', handleClear);
  };
}

export function alignObjectInCanvas(
  canvas: Canvas,
  mode: 'left' | 'center-x' | 'right' | 'top' | 'center-y' | 'bottom',
  stageWidth: number,
  stageHeight: number,
  safeInsetXRatio = 0.04,
  safeInsetYRatio = 0.04
): boolean {
  const active = canvas.getActiveObject();
  if (!active) {
    return false;
  }
  const rect = active.getBoundingRect();
  const safeX = stageWidth * safeInsetXRatio;
  const safeY = stageHeight * safeInsetYRatio;

  let dx = 0;
  let dy = 0;
  switch (mode) {
    case 'left':
      dx = safeX - rect.left;
      break;
    case 'center-x':
      dx = stageWidth / 2 - (rect.left + rect.width / 2);
      break;
    case 'right':
      dx = stageWidth - safeX - (rect.left + rect.width);
      break;
    case 'top':
      dy = safeY - rect.top;
      break;
    case 'center-y':
      dy = stageHeight / 2 - (rect.top + rect.height / 2);
      break;
    case 'bottom':
      dy = stageHeight - safeY - (rect.top + rect.height);
      break;
  }

  active.set({
    left: (active.left ?? 0) + dx,
    top: (active.top ?? 0) + dy,
  });
  active.setCoords();
  canvas.requestRenderAll();
  return true;
}

export function groupActiveCanvasSelection(canvas: Canvas, name = 'Grouped Layer'): boolean {
  const active = canvas.getActiveObject();
  if (!(active instanceof ActiveSelection)) {
    return false;
  }
  const selected = active.getObjects().filter((item) => !getObjectMeta(item)?.locked);
  if (selected.length < 2) {
    return false;
  }

  canvas.discardActiveObject();
  for (const item of selected) {
    canvas.remove(item);
  }
  const group = new Group(selected, {});
  applyCommonControlsAndLock(group, false);
  setObjectMeta(group, {
    id: createObjectId('grp'),
    name,
    canonicalType: 'group',
    locked: false,
  });
  canvas.add(group);
  canvas.setActiveObject(group);
  canvas.requestRenderAll();
  return true;
}

export function ungroupSelectedCanvasObject(canvas: Canvas): boolean {
  const active = canvas.getActiveObject();
  if (!(active instanceof Group)) {
    return false;
  }
  const meta = getObjectMeta(active);
  if (meta?.canonicalType === 'graphic') {
    return false;
  }

  const children = active.removeAll();
  canvas.remove(active);
  for (const child of children) {
    applyCommonControlsAndLock(child, Boolean(getObjectMeta(child)?.locked));
    canvas.add(child);
  }
  if (children.length > 0) {
    const selection = new ActiveSelection(children, { canvas });
    canvas.setActiveObject(selection);
  }
  canvas.requestRenderAll();
  return true;
}
