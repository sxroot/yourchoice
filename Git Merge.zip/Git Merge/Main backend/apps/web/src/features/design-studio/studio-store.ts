import type {
  CanonicalDesignDocument,
  CanonicalDesignObject,
  CanonicalDesignSurface,
  DesignDetailDTO,
  PrintAreaSurfaceKey,
  ProductDetailDTO,
  ProductPrintAreaDTO,
  ProductVariantDTO,
} from '@your-choice/shared-types';
import { canonicalDesignDocumentSchema } from '@your-choice/validation';
import { create } from 'zustand';
import {
  getCameraPresetForSurface,
  type StudioCameraPreset,
  type StudioLightingPreset,
} from './three/webgl-support';

const MAX_UNDO_HISTORY = 50;
const DRAFT_STORAGE_PREFIX = 'yc_studio_2d_draft_v1_';

export function buildSurfaceFromPrintArea(
  printArea: ProductPrintAreaDTO,
  existingObjects: CanonicalDesignObject[] = []
): CanonicalDesignSurface {
  return {
    surfaceKey: printArea.surfaceKey,
    printAreaId: printArea.id,
    physicalWidthMm: printArea.physicalWidthMm,
    physicalHeightMm: printArea.physicalHeightMm,
    targetDpi: printArea.targetDpi,
    safeInsetMm: printArea.safeInsetMm,
    objects: structuredClone(existingObjects),
  };
}

export function createBlankDesignDocument(
  product: ProductDetailDTO,
  variant: ProductVariantDTO,
  preferredMode: '2d' | '3d' = '2d'
): CanonicalDesignDocument {
  const surfaces: Record<string, CanonicalDesignSurface> = {};
  for (const area of product.printAreas) {
    if (area.isActive) {
      surfaces[area.surfaceKey] = buildSurfaceFromPrintArea(area);
    }
  }

  return {
    schemaVersion: 1,
    designId: null,
    productId: product.id,
    productVariantId: variant.id,
    preferredMode,
    version: 1,
    surfaces,
    updatedAt: new Date().toISOString(),
  };
}

export function getDraftStorageKey(designId: string | null, productId: string): string {
  return designId
    ? `${DRAFT_STORAGE_PREFIX}design_${designId}`
    : `${DRAFT_STORAGE_PREFIX}product_${productId}`;
}

export function persistStudioDraft(
  designId: string | null,
  productId: string,
  title: string,
  document: CanonicalDesignDocument
): void {
  if (typeof window === 'undefined') {
    return;
  }
  try {
    const key = getDraftStorageKey(designId, productId);
    window.localStorage.setItem(
      key,
      JSON.stringify({
        savedAt: new Date().toISOString(),
        title,
        document,
      })
    );
  } catch {
    // Ignore storage quota / private browsing failures gracefully
  }
}

export function loadStudioDraft(
  designId: string | null,
  productId: string
): { savedAt: string; title: string; document: CanonicalDesignDocument } | null {
  if (typeof window === 'undefined') {
    return null;
  }
  try {
    const raw = window.localStorage.getItem(getDraftStorageKey(designId, productId));
    if (!raw) {
      return null;
    }
    const parsed = JSON.parse(raw) as {
      savedAt?: unknown;
      title?: unknown;
      document?: unknown;
    };
    const docResult = canonicalDesignDocumentSchema.safeParse(parsed.document);
    if (!docResult.success || typeof parsed.title !== 'string') {
      return null;
    }
    return {
      savedAt: typeof parsed.savedAt === 'string' ? parsed.savedAt : docResult.data.updatedAt,
      title: parsed.title,
      document: docResult.data,
    };
  } catch {
    return null;
  }
}

export function clearStudioDraft(designId: string | null, productId: string): void {
  if (typeof window === 'undefined') {
    return;
  }
  try {
    window.localStorage.removeItem(getDraftStorageKey(designId, productId));
  } catch {
    // Ignore storage errors
  }
}

interface StudioState {
  document: CanonicalDesignDocument | null;
  designTitle: string;
  savedDesignId: string | null;
  savedVersionNumber: number;
  activeSurfaceKey: PrintAreaSurfaceKey;
  selectedObjectIds: string[];
  zoom: number;
  showBackdrop: boolean;
  showSafeZone: boolean;
  showGrid: boolean;
  snapToGuides: boolean;
  isDirty: boolean;
  pastStates: CanonicalDesignDocument[];
  futureStates: CanonicalDesignDocument[];
  lastProportionNotice: boolean;
  cameraPreset: StudioCameraPreset;
  lightingPreset: StudioLightingPreset;
  autoRotate3d: boolean;
  show3dPrintGuides: boolean;

  initFromProduct: (
    product: ProductDetailDTO,
    variant: ProductVariantDTO,
    existingDesign?: DesignDetailDTO | null,
    defaultTitle?: string,
    initialMode?: '2d' | '3d'
  ) => void;
  restoreDocumentFromDraft: (title: string, doc: CanonicalDesignDocument) => void;
  switchProductOrVariant: (product: ProductDetailDTO, variant: ProductVariantDTO) => void;
  setPreferredMode: (mode: '2d' | '3d') => void;
  setCameraPreset: (preset: StudioCameraPreset) => void;
  setLightingPreset: (lighting: StudioLightingPreset) => void;
  toggleAutoRotate3d: () => void;
  toggle3dPrintGuides: () => void;
  setDesignTitle: (title: string) => void;
  setActiveSurfaceKey: (surfaceKey: PrintAreaSurfaceKey) => void;
  setSelectedObjectIds: (ids: string[]) => void;
  commitDocument: (nextDoc: CanonicalDesignDocument, pushHistory?: boolean) => void;
  mutateActiveSurfaceObjects: (
    updater: (objects: CanonicalDesignObject[]) => CanonicalDesignObject[],
    pushHistory?: boolean
  ) => void;
  undo: () => void;
  redo: () => void;
  setZoom: (zoom: number) => void;
  toggleBackdrop: () => void;
  toggleSafeZone: () => void;
  toggleGrid: () => void;
  toggleSnapToGuides: () => void;
  markSaved: (detail: DesignDetailDTO) => void;
  dismissProportionNotice: () => void;
}

export const useStudioStore = create<StudioState>((set, get) => ({
  document: null,
  designTitle: 'Custom Apparel Design',
  savedDesignId: null,
  savedVersionNumber: 1,
  activeSurfaceKey: 'front',
  selectedObjectIds: [],
  zoom: 1,
  showBackdrop: true,
  showSafeZone: true,
  showGrid: false,
  snapToGuides: true,
  isDirty: false,
  pastStates: [],
  futureStates: [],
  lastProportionNotice: false,
  cameraPreset: 'three_quarter',
  lightingPreset: 'studio',
  autoRotate3d: false,
  show3dPrintGuides: true,

  initFromProduct: (product, variant, existingDesign, defaultTitle, initialMode) => {
    const activeAreas = product.printAreas.filter((pa) => pa.isActive);
    const defaultSurface =
      activeAreas.find((pa) => pa.isDefault)?.surfaceKey ?? activeAreas[0]?.surfaceKey ?? 'front';

    if (existingDesign) {
      const mergedSurfaces: Record<string, CanonicalDesignSurface> = {};
      for (const area of activeAreas) {
        const existingSurface = existingDesign.document.surfaces[area.surfaceKey];
        mergedSurfaces[area.surfaceKey] = buildSurfaceFromPrintArea(
          area,
          existingSurface?.objects ?? []
        );
      }

      const firstPopulated = activeAreas.find(
        (pa) => (mergedSurfaces[pa.surfaceKey]?.objects.length ?? 0) > 0
      );
      const resolvedSurface = firstPopulated?.surfaceKey ?? defaultSurface;
      const resolvedMode = initialMode ?? existingDesign.document.preferredMode ?? '2d';

      set({
        document: {
          ...structuredClone(existingDesign.document),
          preferredMode: resolvedMode,
          surfaces: mergedSurfaces,
        },
        designTitle: existingDesign.title,
        savedDesignId: existingDesign.id,
        savedVersionNumber: existingDesign.currentVersionNumber,
        activeSurfaceKey: resolvedSurface,
        selectedObjectIds: [],
        isDirty: false,
        pastStates: [],
        futureStates: [],
        lastProportionNotice: false,
        cameraPreset: 'three_quarter',
      });
      return;
    }

    const blankDoc = createBlankDesignDocument(product, variant, initialMode ?? '2d');
    set({
      document: blankDoc,
      designTitle: defaultTitle ?? `${product.nameEn} Custom`,
      savedDesignId: null,
      savedVersionNumber: 1,
      activeSurfaceKey: defaultSurface,
      selectedObjectIds: [],
      isDirty: false,
      pastStates: [],
      futureStates: [],
      lastProportionNotice: false,
      cameraPreset: 'three_quarter',
    });
  },

  restoreDocumentFromDraft: (title, doc) => {
    set({
      document: structuredClone(doc),
      designTitle: title,
      selectedObjectIds: [],
      isDirty: true,
      pastStates: [],
      futureStates: [],
    });
  },

  switchProductOrVariant: (product, variant) => {
    const current = get().document;
    if (!current) {
      return;
    }

    const activeAreas = product.printAreas.filter((pa) => pa.isActive);
    const nextSurfaces: Record<string, CanonicalDesignSurface> = {};
    let proportionChanged = false;

    for (const area of activeAreas) {
      const oldSurface = current.surfaces[area.surfaceKey];
      if (oldSurface && oldSurface.objects.length > 0) {
        const oldRatio = oldSurface.physicalWidthMm / Math.max(1, oldSurface.physicalHeightMm);
        const newRatio = area.physicalWidthMm / Math.max(1, area.physicalHeightMm);
        if (Math.abs(oldRatio - newRatio) / oldRatio > 0.08) {
          proportionChanged = true;
        }
      }
      nextSurfaces[area.surfaceKey] = buildSurfaceFromPrintArea(area, oldSurface?.objects ?? []);
    }

    const nextActiveSurface =
      nextSurfaces[get().activeSurfaceKey] !== undefined
        ? get().activeSurfaceKey
        : (activeAreas.find((pa) => pa.isDefault)?.surfaceKey ??
          activeAreas[0]?.surfaceKey ??
          'front');

    const nextDoc: CanonicalDesignDocument = {
      ...structuredClone(current),
      productId: product.id,
      productVariantId: variant.id,
      surfaces: nextSurfaces,
      updatedAt: new Date().toISOString(),
    };

    set((state) => ({
      pastStates: [...state.pastStates.slice(-(MAX_UNDO_HISTORY - 1)), current],
      futureStates: [],
      document: nextDoc,
      activeSurfaceKey: nextActiveSurface,
      selectedObjectIds: [],
      isDirty: true,
      lastProportionNotice: proportionChanged,
    }));
  },

  setPreferredMode: (mode) => {
    const current = get().document;
    if (!current || current.preferredMode === mode) {
      return;
    }
    set({
      document: {
        ...structuredClone(current),
        preferredMode: mode,
        updatedAt: new Date().toISOString(),
      },
      isDirty: true,
    });
  },

  setCameraPreset: (preset) => set({ cameraPreset: preset }),
  setLightingPreset: (lighting) => set({ lightingPreset: lighting }),
  toggleAutoRotate3d: () => set((s) => ({ autoRotate3d: !s.autoRotate3d })),
  toggle3dPrintGuides: () => set((s) => ({ show3dPrintGuides: !s.show3dPrintGuides })),

  setDesignTitle: (title) => {
    set({ designTitle: title, isDirty: true });
  },

  setActiveSurfaceKey: (surfaceKey) => {
    set({
      activeSurfaceKey: surfaceKey,
      selectedObjectIds: [],
      cameraPreset: getCameraPresetForSurface(surfaceKey),
    });
  },

  setSelectedObjectIds: (ids) => {
    set({ selectedObjectIds: ids });
  },

  commitDocument: (nextDoc, pushHistory = true) => {
    const current = get().document;
    if (!current) {
      set({ document: structuredClone(nextDoc), isDirty: true });
      return;
    }

    const stamped: CanonicalDesignDocument = {
      ...structuredClone(nextDoc),
      updatedAt: new Date().toISOString(),
    };

    set((state) => ({
      document: stamped,
      isDirty: true,
      ...(pushHistory
        ? {
            pastStates: [...state.pastStates.slice(-(MAX_UNDO_HISTORY - 1)), current],
            futureStates: [],
          }
        : {}),
    }));
  },

  mutateActiveSurfaceObjects: (updater, pushHistory = true) => {
    const state = get();
    const current = state.document;
    if (!current) {
      return;
    }
    const currentSurface = current.surfaces[state.activeSurfaceKey];
    if (!currentSurface) {
      return;
    }

    const nextObjects = updater(structuredClone(currentSurface.objects));
    const nextDoc: CanonicalDesignDocument = {
      ...structuredClone(current),
      surfaces: {
        ...structuredClone(current.surfaces),
        [state.activeSurfaceKey]: {
          ...structuredClone(currentSurface),
          objects: nextObjects,
        },
      },
      updatedAt: new Date().toISOString(),
    };

    set((prev) => ({
      document: nextDoc,
      isDirty: true,
      ...(pushHistory
        ? {
            pastStates: [...prev.pastStates.slice(-(MAX_UNDO_HISTORY - 1)), current],
            futureStates: [],
          }
        : {}),
    }));
  },

  undo: () => {
    const { pastStates, document, futureStates } = get();
    if (pastStates.length === 0 || !document) {
      return;
    }
    const previous = pastStates[pastStates.length - 1]!;
    set({
      document: structuredClone(previous),
      pastStates: pastStates.slice(0, -1),
      futureStates: [structuredClone(document), ...futureStates.slice(0, MAX_UNDO_HISTORY - 1)],
      selectedObjectIds: [],
      isDirty: true,
    });
  },

  redo: () => {
    const { futureStates, document, pastStates } = get();
    if (futureStates.length === 0 || !document) {
      return;
    }
    const next = futureStates[0]!;
    set({
      document: structuredClone(next),
      pastStates: [...pastStates.slice(-(MAX_UNDO_HISTORY - 1)), structuredClone(document)],
      futureStates: futureStates.slice(1),
      selectedObjectIds: [],
      isDirty: true,
    });
  },

  setZoom: (zoom) => {
    const clamped = Math.min(2.4, Math.max(0.5, Number(zoom.toFixed(2))));
    set({ zoom: clamped });
  },

  toggleBackdrop: () => set((s) => ({ showBackdrop: !s.showBackdrop })),
  toggleSafeZone: () => set((s) => ({ showSafeZone: !s.showSafeZone })),
  toggleGrid: () => set((s) => ({ showGrid: !s.showGrid })),
  toggleSnapToGuides: () => set((s) => ({ snapToGuides: !s.snapToGuides })),

  markSaved: (detail) => {
    clearStudioDraft(null, detail.productId);
    clearStudioDraft(detail.id, detail.productId);
    set({
      savedDesignId: detail.id,
      savedVersionNumber: detail.currentVersionNumber,
      designTitle: detail.title,
      document: structuredClone(detail.document),
      isDirty: false,
    });
  },

  dismissProportionNotice: () => set({ lastProportionNotice: false }),
}));
