import type {
  CanonicalDesignSurface,
  PrintAreaSurfaceKey,
  ProductDetailDTO,
  ProductPrintAreaDTO,
  ProductVariantDTO,
} from '@your-choice/shared-types';
import { ContactShadows, Environment, Lightformer, OrbitControls } from '@react-three/drei';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Badge, Button } from '@your-choice/ui';
import {
  AlertTriangle,
  Box,
  Compass,
  Eye,
  EyeOff,
  Loader2,
  Pencil,
  RotateCcw,
  RotateCw,
  Sun,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  Component,
  type ComponentRef,
  type ErrorInfo,
  type ReactNode,
  Suspense,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import * as THREE from 'three';
import { pickLocalizedText, useAppLocale } from '@/i18n';
import { GarmentCanvasBackdrop } from '../components/GarmentCanvasBackdrop';
import { GarmentModel3D } from './GarmentModel3D';
import {
  detectWebGLCapability,
  getCameraPoseForPreset,
  getCameraPresetForSurface,
  resolveGarmentModelSpec,
  type StudioCameraPreset,
  type StudioLightingPreset,
} from './webgl-support';

interface ErrorBoundaryProps {
  onError: (err: Error) => void;
  fallback: ReactNode;
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class Studio3DErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  override state: ErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  override componentDidCatch(error: Error, _info: ErrorInfo) {
    this.props.onError(error);
  }

  override render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

type OrbitControlsImpl = ComponentRef<typeof OrbitControls>;

interface CameraRigProps {
  preset: StudioCameraPreset;
  requestVersion: number;
  zoomCommand: { version: number; factor: number };
  controlsRef: React.RefObject<OrbitControlsImpl | null>;
  reducedMotion: boolean;
}

function CameraRigController({
  preset,
  requestVersion,
  zoomCommand,
  controlsRef,
  reducedMotion,
}: CameraRigProps) {
  const { camera, invalidate } = useThree();
  const goalPosRef = useRef(new THREE.Vector3(...getCameraPoseForPreset(preset).position));
  const goalTargetRef = useRef(new THREE.Vector3(...getCameraPoseForPreset(preset).target));
  const transitioningRef = useRef(false);
  const lastZoomVersionRef = useRef(0);

  useEffect(() => {
    const pose = getCameraPoseForPreset(preset);
    goalPosRef.current.set(...pose.position);
    goalTargetRef.current.set(...pose.target);

    if (reducedMotion) {
      camera.position.copy(goalPosRef.current);
      if (controlsRef.current) {
        controlsRef.current.target.copy(goalTargetRef.current);
        controlsRef.current.update();
      }
      transitioningRef.current = false;
    } else {
      transitioningRef.current = true;
    }
    invalidate();
  }, [preset, requestVersion, camera, controlsRef, reducedMotion, invalidate]);

  useEffect(() => {
    if (zoomCommand.version <= lastZoomVersionRef.current) {
      return;
    }
    lastZoomVersionRef.current = zoomCommand.version;
    const controls = controlsRef.current;
    const target = controls ? controls.target : new THREE.Vector3(0, 0, 0);
    const offset = camera.position.clone().sub(target);
    const nextDist = THREE.MathUtils.clamp(offset.length() * zoomCommand.factor, 0.56, 1.9);
    offset.setLength(nextDist);
    camera.position.copy(target).add(offset);
    controls?.update();
    invalidate();
  }, [zoomCommand, camera, controlsRef, invalidate]);

  useFrame((_state, delta) => {
    if (!transitioningRef.current) {
      return;
    }
    const alpha = 1 - Math.exp(-Math.min(0.1, delta) * 7.5);
    camera.position.lerp(goalPosRef.current, alpha);
    const controls = controlsRef.current;
    if (controls) {
      controls.target.lerp(goalTargetRef.current, alpha);
      controls.update();
    }
    if (camera.position.distanceTo(goalPosRef.current) < 0.004) {
      camera.position.copy(goalPosRef.current);
      if (controls) {
        controls.target.copy(goalTargetRef.current);
        controls.update();
      }
      transitioningRef.current = false;
    } else {
      invalidate();
    }
  });

  return null;
}

export interface StudioStage3DProps {
  product: ProductDetailDTO;
  variant: ProductVariantDTO;
  activePrintArea: ProductPrintAreaDTO;
  allSurfaces: Record<string, CanonicalDesignSurface>;
  activeSurfaceKey: PrintAreaSurfaceKey;
  cameraPreset: StudioCameraPreset;
  lightingPreset: StudioLightingPreset;
  autoRotate: boolean;
  showPrintGuides: boolean;
  onSelectSurface: (surfaceKey: PrintAreaSurfaceKey) => void;
  onSelectCameraPreset: (preset: StudioCameraPreset) => void;
  onChangeLightingPreset: (lighting: StudioLightingPreset) => void;
  onToggleAutoRotate: () => void;
  onTogglePrintGuides: () => void;
  onSwitchTo2DEditor: () => void;
}

export function StudioStage3D({
  product,
  variant,
  activePrintArea,
  allSurfaces,
  activeSurfaceKey,
  cameraPreset,
  lightingPreset,
  autoRotate,
  showPrintGuides,
  onSelectSurface,
  onSelectCameraPreset,
  onChangeLightingPreset,
  onToggleAutoRotate,
  onTogglePrintGuides,
  onSwitchTo2DEditor,
}: StudioStage3DProps) {
  const { locale, t } = useAppLocale();
  const controlsRef = useRef<OrbitControlsImpl | null>(null);
  const [presetVersion, setPresetVersion] = useState(0);
  const [zoomCommand, setZoomCommand] = useState({ version: 0, factor: 1 });
  const [contextError, setContextError] = useState<string | null>(null);
  const [mountNonce, setMountNonce] = useState(0);

  const webglReport = useMemo(() => {
    void mountNonce;
    return detectWebGLCapability();
  }, [mountNonce]);

  const reducedMotion = useMemo(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
      return false;
    }
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }, []);

  const modelSpec = useMemo(() => resolveGarmentModelSpec(product), [product]);
  const activeAreas = useMemo(
    () => product.printAreas.filter((pa) => pa.isActive).sort((a, b) => a.sortOrder - b.sortOrder),
    [product.printAreas]
  );

  const handleCameraPreset = useCallback(
    (preset: StudioCameraPreset) => {
      onSelectCameraPreset(preset);
      setPresetVersion((v) => v + 1);
      if (preset === 'front' || preset === 'back' || preset === 'left_chest') {
        const matchingArea = activeAreas.find((pa) => pa.surfaceKey === preset);
        if (matchingArea) {
          onSelectSurface(matchingArea.surfaceKey);
        }
      }
    },
    [activeAreas, onSelectCameraPreset, onSelectSurface]
  );

  const handleSurfaceSwitch = useCallback(
    (surfaceKey: PrintAreaSurfaceKey) => {
      onSelectSurface(surfaceKey);
      const linkedPreset = getCameraPresetForSurface(surfaceKey);
      onSelectCameraPreset(linkedPreset);
      setPresetVersion((v) => v + 1);
    },
    [onSelectSurface, onSelectCameraPreset]
  );

  const presetOptions = useMemo(() => {
    const items: Array<{ id: StudioCameraPreset; label: string }> = [
      { id: 'three_quarter', label: t('studio3d.angleThreeQuarter') },
      { id: 'front', label: t('studio3d.angleFront') },
      { id: 'back', label: t('studio3d.angleBack') },
    ];
    if (activeAreas.some((pa) => pa.surfaceKey === 'left_chest')) {
      items.push({ id: 'left_chest', label: t('studio3d.angleLeftChest') });
    }
    items.push({ id: 'collar', label: t('studio3d.angleCollar') });
    return items;
  }, [activeAreas, t]);

  const fallbackUi = (
    <div
      data-testid="studio-3d-fallback"
      className="flex min-h-[440px] flex-col items-center justify-center gap-4 rounded-xl border border-border bg-canvas/85 p-6 text-center"
    >
      <div className="flex max-w-md flex-col items-center gap-2">
        <div className="flex h-11 w-11 items-center justify-center rounded-full border border-amber-500/40 bg-amber-500/10 text-amber-500">
          <AlertTriangle className="h-5 w-5" />
        </div>
        <h3 className="text-base font-bold text-ink">{t('studio3d.webglUnavailableTitle')}</h3>
        <p className="text-xs leading-relaxed text-ink-muted">
          {contextError || webglReport.reason || t('studio3d.webglUnavailableDesc')}
        </p>
      </div>

      {/* Static SVG garment visual fallback so customers can still inspect colorway & switch surfaces */}
      <div className="relative h-60 w-60 overflow-hidden rounded-2xl border border-border bg-surface p-3 shadow-inner">
        <GarmentCanvasBackdrop
          garmentType={modelSpec.garmentKind}
          colorHex={variant.colorHex}
          surfaceKey={activePrintArea.surfaceKey}
        />
        <div
          className="pointer-events-none absolute border border-dashed border-cyan-500/70 bg-cyan-500/5"
          style={{
            left: `${activePrintArea.mockupBounds.x * 100}%`,
            top: `${activePrintArea.mockupBounds.y * 100}%`,
            width: `${activePrintArea.mockupBounds.width * 100}%`,
            height: `${activePrintArea.mockupBounds.height * 100}%`,
          }}
        >
          <span className="inline-block rounded-br bg-canvas/90 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-ink">
            {activePrintArea.surfaceKey} · {allSurfaces[activeSurfaceKey]?.objects.length ?? 0}{' '}
            layers
          </span>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-2">
        <Button type="button" size="sm" onClick={onSwitchTo2DEditor}>
          <Pencil className="mr-1.5 h-3.5 w-3.5" />
          {t('studio3d.switchTo2d')}
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={() => {
            setContextError(null);
            setMountNonce((n) => n + 1);
          }}
        >
          <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
          {t('studio3d.retry3d')}
        </Button>
      </div>
    </div>
  );

  const stageBgClass =
    lightingPreset === 'daylight'
      ? 'bg-[radial-gradient(circle_at_50%_30%,#e2e8f0_0%,#cbd5e1_58%,#94a3b8_100%)] dark:bg-[radial-gradient(circle_at_50%_28%,#1e293b_0%,#0f172a_72%,#06080d_100%)]'
      : 'bg-[radial-gradient(circle_at_50%_28%,#1e293b_0%,#0b1120_65%,#06080d_100%)]';

  return (
    <section
      aria-label={t('studio3d.stageAriaLabel')}
      data-testid="studio-3d-stage"
      className="flex flex-col rounded-2xl border border-border bg-surface p-3 shadow-sm"
    >
      {/* Surface Switcher & Camera / View Controls */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-border pb-3">
        <div
          className="flex flex-wrap items-center gap-1.5"
          role="tablist"
          aria-label={t('studio.printSurfaces')}
        >
          {activeAreas.map((area) => {
            const isSelected = area.surfaceKey === activeSurfaceKey;
            const label = pickLocalizedText(locale, area.labelEn, area.labelBn);
            const count = allSurfaces[area.surfaceKey]?.objects.length ?? 0;
            return (
              <button
                key={area.id}
                type="button"
                role="tab"
                aria-selected={isSelected}
                onClick={() => handleSurfaceSwitch(area.surfaceKey)}
                className={`min-h-10 rounded-lg px-3 py-1.5 text-xs font-semibold transition focus:outline-none focus:ring-2 focus:ring-accent ${
                  isSelected
                    ? 'bg-accent text-white shadow-sm'
                    : 'bg-canvas text-ink-muted hover:text-ink border border-border'
                }`}
              >
                {label}
                {count > 0 ? (
                  <span
                    className={`ml-1.5 rounded-full px-1.5 py-0.5 text-[10px] ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-accent/15 text-accent'
                    }`}
                  >
                    {count}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <Button
            type="button"
            size="sm"
            variant="outline"
            aria-label={t('studio.zoomOut')}
            onClick={() => setZoomCommand((z) => ({ version: z.version + 1, factor: 1.18 }))}
          >
            <ZoomOut className="h-3.5 w-3.5" />
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            aria-label={t('studio.zoomIn')}
            onClick={() => setZoomCommand((z) => ({ version: z.version + 1, factor: 0.85 }))}
          >
            <ZoomIn className="h-3.5 w-3.5" />
          </Button>
          <Button
            type="button"
            size="sm"
            variant={autoRotate ? 'primary' : 'outline'}
            aria-pressed={autoRotate}
            onClick={onToggleAutoRotate}
          >
            <RotateCw className="mr-1 h-3.5 w-3.5" />
            <span className="hidden sm:inline">{t('studio3d.autoRotate')}</span>
          </Button>
          <Button
            type="button"
            size="sm"
            variant={showPrintGuides ? 'primary' : 'outline'}
            aria-pressed={showPrintGuides}
            onClick={onTogglePrintGuides}
          >
            {showPrintGuides ? (
              <Eye className="mr-1 h-3.5 w-3.5" />
            ) : (
              <EyeOff className="mr-1 h-3.5 w-3.5" />
            )}
            <span className="hidden sm:inline">{t('studio3d.printGuides')}</span>
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() =>
              onChangeLightingPreset(lightingPreset === 'studio' ? 'daylight' : 'studio')
            }
          >
            <Sun className="mr-1 h-3.5 w-3.5" />
            <span className="hidden sm:inline">
              {lightingPreset === 'studio'
                ? t('studio3d.lightingStudio')
                : t('studio3d.lightingDaylight')}
            </span>
          </Button>
        </div>
      </div>

      {/* Interactive WebGL Viewport or Clean Fallback */}
      {!webglReport.supported || contextError ? (
        fallbackUi
      ) : (
        <Studio3DErrorBoundary
          fallback={fallbackUi}
          onError={(err) => setContextError(err.message)}
        >
          <div
            className={`relative min-h-[440px] flex-1 overflow-hidden rounded-xl border border-border sm:min-h-[540px] ${stageBgClass}`}
          >
            {/* Top-left garment metadata overlay */}
            <div className="pointer-events-none absolute top-3 left-3 z-10 flex flex-wrap items-center gap-1.5">
              <Badge variant="neutral" className="bg-surface/85 backdrop-blur-sm text-[11px]">
                <Box className="mr-1 h-3 w-3 text-accent" />
                {modelSpec.label}
              </Badge>
              <Badge variant="neutral" className="bg-surface/85 backdrop-blur-sm text-[11px]">
                <span
                  className="mr-1.5 inline-block h-2.5 w-2.5 rounded-full border border-white/40"
                  style={{ backgroundColor: variant.colorHex }}
                />
                {pickLocalizedText(locale, variant.colorNameEn, variant.colorNameBn)}
              </Badge>
            </div>

            {/* Bottom camera preset switcher bar */}
            <div className="pointer-events-none absolute inset-x-3 bottom-3 z-10 flex flex-wrap items-center justify-between gap-2">
              <div
                className="pointer-events-auto flex flex-wrap items-center gap-1 rounded-xl border border-border/70 bg-surface/90 p-1 shadow-lg backdrop-blur-md"
                role="group"
                aria-label={t('studio3d.cameraPresetsLabel')}
              >
                {presetOptions.map((item) => {
                  const active = cameraPreset === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleCameraPreset(item.id)}
                      className={`min-h-9 rounded-lg px-2.5 py-1 text-[11px] font-semibold transition focus:outline-none focus:ring-2 focus:ring-accent ${
                        active
                          ? 'bg-accent text-white shadow-sm'
                          : 'text-ink-muted hover:bg-canvas hover:text-ink'
                      }`}
                    >
                      {item.label}
                    </button>
                  );
                })}
                <button
                  type="button"
                  onClick={() => handleCameraPreset('three_quarter')}
                  aria-label={t('studio3d.resetCamera')}
                  className="inline-flex min-h-9 items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-ink-muted hover:bg-canvas hover:text-ink focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  <Compass className="h-3.5 w-3.5" />
                  <span className="hidden md:inline">{t('studio3d.resetCamera')}</span>
                </button>
              </div>

              <span className="hidden rounded-lg border border-border/60 bg-surface/80 px-2.5 py-1 text-[11px] text-ink-muted backdrop-blur-sm md:inline-block">
                {t('studio3d.dragHint')}
              </span>
            </div>

            <Suspense
              fallback={
                <div
                  aria-busy="true"
                  className="flex h-full min-h-[440px] flex-col items-center justify-center gap-2 text-xs font-medium text-ink-muted"
                >
                  <Loader2 className="h-6 w-6 animate-spin text-accent" />
                  <span>{t('studio3d.loadingModel')}</span>
                </div>
              }
            >
              <Canvas
                key={mountNonce}
                frameloop={
                  webglReport.isSoftwareRenderer && !(autoRotate && !reducedMotion)
                    ? 'demand'
                    : 'always'
                }
                shadows
                dpr={webglReport.recommendedDpr}
                camera={{ position: [0.46, 0.12, 1.08], fov: 35, near: 0.1, far: 25 }}
                gl={{
                  antialias: !webglReport.isSoftwareRenderer,
                  powerPreference: 'high-performance',
                  toneMapping: THREE.ACESFilmicToneMapping,
                  toneMappingExposure: lightingPreset === 'daylight' ? 1.14 : 1.04,
                }}
                onCreated={({ gl }) => {
                  gl.domElement.addEventListener(
                    'webglcontextlost',
                    (event) => {
                      event.preventDefault();
                      setContextError(t('studio3d.contextLostError'));
                    },
                    false
                  );
                }}
              >
                <ambientLight
                  intensity={lightingPreset === 'daylight' ? 0.55 : 0.36}
                  color="#f8fafc"
                />
                <hemisphereLight
                  args={[
                    '#e0f2fe',
                    lightingPreset === 'daylight' ? '#cbd5e1' : '#0f172a',
                    lightingPreset === 'daylight' ? 0.65 : 0.45,
                  ]}
                />

                {/* Key Light */}
                <directionalLight
                  position={[1.8, 2.6, 2.2]}
                  intensity={lightingPreset === 'daylight' ? 1.55 : 1.35}
                  color="#fffbeb"
                  castShadow
                  shadow-mapSize-width={webglReport.isLowPowerDevice ? 512 : 1024}
                  shadow-mapSize-height={webglReport.isLowPowerDevice ? 512 : 1024}
                  shadow-camera-near={0.5}
                  shadow-camera-far={8}
                  shadow-bias={-0.0004}
                />

                {/* Soft front fill */}
                <directionalLight position={[-1.6, 0.9, 1.5]} intensity={0.62} color="#dbeafe" />

                {/* Calibrated Cyan Rim Light to lift dark obsidian silhouettes */}
                <directionalLight
                  position={[0.6, 1.6, -2.4]}
                  intensity={lightingPreset === 'daylight' ? 0.8 : 1.05}
                  color="#38bdf8"
                />

                {/* Local procedural HDRI lighting (zero external CDN requests) */}
                <Environment
                  key={lightingPreset}
                  frames={1}
                  resolution={webglReport.isLowPowerDevice ? 64 : 128}
                >
                  <Lightformer
                    form="rect"
                    intensity={lightingPreset === 'daylight' ? 2.4 : 1.8}
                    color="#ffffff"
                    position={[0, 3, 2]}
                    rotation={[Math.PI / 3, 0, 0]}
                    scale={[5, 2, 1]}
                  />
                  <Lightformer
                    form="rect"
                    intensity={1.2}
                    color="#bfdbfe"
                    position={[-3, 1.2, 0]}
                    rotation={[0, Math.PI / 2, 0]}
                    scale={[3, 2, 1]}
                  />
                  <Lightformer
                    form="rect"
                    intensity={1.1}
                    color="#67e8f9"
                    position={[2.8, 1.5, -2.2]}
                    rotation={[0, -Math.PI / 1.4, 0]}
                    scale={[3, 2, 1]}
                  />
                </Environment>

                <Suspense fallback={null}>
                  <GarmentModel3D
                    product={product}
                    variant={variant}
                    surfaces={allSurfaces}
                    activeSurfaceKey={activeSurfaceKey}
                    showPrintGuides={showPrintGuides}
                    isLowPowerDevice={webglReport.isLowPowerDevice}
                    onSelectSurface={handleSurfaceSwitch}
                  />
                </Suspense>

                <ContactShadows
                  key={modelSpec.modelPath}
                  frames={1}
                  position={[0, -0.37, 0]}
                  opacity={lightingPreset === 'daylight' ? 0.34 : 0.45}
                  scale={1.85}
                  blur={2.3}
                  far={1.1}
                  resolution={webglReport.isLowPowerDevice ? 256 : 512}
                />

                <OrbitControls
                  ref={controlsRef}
                  makeDefault
                  enablePan={false}
                  enableDamping
                  dampingFactor={0.075}
                  minDistance={0.56}
                  maxDistance={1.9}
                  minPolarAngle={Math.PI * 0.16}
                  maxPolarAngle={Math.PI * 0.78}
                  autoRotate={autoRotate && !reducedMotion}
                  autoRotateSpeed={1.2}
                />

                <CameraRigController
                  preset={cameraPreset}
                  requestVersion={presetVersion}
                  zoomCommand={zoomCommand}
                  controlsRef={controlsRef}
                  reducedMotion={reducedMotion}
                />
              </Canvas>
            </Suspense>
          </div>
        </Studio3DErrorBoundary>
      )}

      {/* Stage Footer Summary */}
      <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-ink-muted">
        <span>
          {t('studio3d.activeZoneLabel')}:{' '}
          <strong className="text-ink">
            {pickLocalizedText(locale, activePrintArea.labelEn, activePrintArea.labelBn)}
          </strong>{' '}
          ({activePrintArea.physicalWidthMm} × {activePrintArea.physicalHeightMm} mm ·{' '}
          {activePrintArea.targetDpi} DPI)
        </span>
        <span>
          {allSurfaces[activeSurfaceKey]?.objects.length ?? 0} {t('studio3d.layersLabel')} ·{' '}
          {t('studio3d.clickMeshHint')}
        </span>
      </div>
    </section>
  );
}
