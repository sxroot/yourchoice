import 'react-easy-crop/react-easy-crop.css';
import type { CanonicalImageObject } from '@your-choice/shared-types';
import {
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@your-choice/ui';
import { Crop } from 'lucide-react';
import { useState } from 'react';
import Cropper, { type Area } from 'react-easy-crop';
import { useAppLocale } from '@/i18n';

interface ImageCropModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  imageUrl: string;
  initialCrop: CanonicalImageObject['cropRect'];
  onApplyCrop: (cropRect: NonNullable<CanonicalImageObject['cropRect']>) => void;
  onResetCrop: () => void;
}

export function ImageCropModal({
  open,
  onOpenChange,
  imageUrl,
  initialCrop,
  onApplyCrop,
  onResetCrop,
}: ImageCropModalProps) {
  const { t } = useAppLocale();
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedArea, setCroppedArea] = useState<Area | null>(null);

  const handleConfirm = () => {
    if (!croppedArea) {
      onOpenChange(false);
      return;
    }

    onApplyCrop({
      x: Math.max(0, Math.min(0.95, Number((croppedArea.x / 100).toFixed(4)))),
      y: Math.max(0, Math.min(0.95, Number((croppedArea.y / 100).toFixed(4)))),
      width: Math.max(0.05, Math.min(1, Number((croppedArea.width / 100).toFixed(4)))),
      height: Math.max(0.05, Math.min(1, Number((croppedArea.height / 100).toFixed(4)))),
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crop className="h-4 w-4 text-accent" />
            <span>{t('studio.cropTitle')}</span>
          </DialogTitle>
          <DialogDescription>{t('studio.cropSubtitle')}</DialogDescription>
        </DialogHeader>

        <div className="relative h-80 w-full overflow-hidden rounded-xl border border-border bg-surface-dark">
          <Cropper
            image={imageUrl}
            crop={crop}
            zoom={zoom}
            aspect={undefined}
            initialCroppedAreaPercentages={
              initialCrop
                ? {
                    x: initialCrop.x * 100,
                    y: initialCrop.y * 100,
                    width: initialCrop.width * 100,
                    height: initialCrop.height * 100,
                  }
                : undefined
            }
            onCropChange={setCrop}
            onZoomChange={setZoom}
            onCropComplete={(croppedPercent) => setCroppedArea(croppedPercent)}
          />
        </div>

        <div className="flex items-center gap-3 pt-1">
          <label htmlFor="yc-crop-zoom" className="text-xs font-medium text-ink-muted">
            {t('studio.zoomLabel')}
          </label>
          <input
            id="yc-crop-zoom"
            type="range"
            min={1}
            max={3}
            step={0.05}
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
            className="h-2 flex-1 cursor-pointer accent-accent"
          />
          <span className="w-12 text-right font-mono text-xs">{Math.round(zoom * 100)}%</span>
        </div>

        <DialogFooter className="gap-2 sm:justify-between">
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              onResetCrop();
              onOpenChange(false);
            }}
          >
            {t('studio.resetCrop')}
          </Button>
          <div className="flex items-center gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t('common.cancel')}
            </Button>
            <Button type="button" onClick={handleConfirm}>
              {t('studio.applyCrop')}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
