import type {
  CanonicalDesignObject,
  CanonicalDesignSurface,
  PrintAreaSurfaceKey,
  ProductDetailDTO,
  ProductPrintAreaDTO,
  ProductVariantDTO,
} from '@your-choice/shared-types';
import { Badge, Button } from '@your-choice/ui';
import { Eye, EyeOff, Grid, Magnet, Maximize2, ShieldAlert, ZoomIn, ZoomOut } from 'lucide-react';
import { type MutableRefObject, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, type FabricObject } from 'fabric';
import { pickLocalizedText, useAppLocale } from '@/i18n';
import { ensureStudioFontsLoaded } from '../fonts';
import {
  attachSnapGuides,
  getObjectMeta,
  hydrateSurfaceToFabricCanvas,
  serializeFabricCanvasToObjects,
  type SnapGuidesState,
} from '../fabric-adapter';
import { GarmentCanvasBackdrop } from './GarmentCanvasBackdrop';

const GARMENT_STAGE_BASE_PX = 560;

interface StudioCanvasStageProps {
  product: ProductDetailDTO;
  variant: ProductVariantDTO;
  activePrintArea: ProductPrintAreaDTO;
  surface: CanonicalDesignSurface;
  allSurfaces: Record<string, CanonicalDesignSurface>;
  activeSurfaceKey: PrintAreaSurfaceKey;
  zoom: number;
  showBackdrop: boolean;
  showSafeZone: boolean;
  showGrid: boolean;
  snapToGuides: boolean;
  canvasRef: MutableRefObject<Canvas | null>;
  stageDimensionsRef: MutableRefObject<{ width: number; height: number }>;
  onSelectSurface: (surfaceKey: PrintAreaSurfaceKey) => void;
  onZoomChange: (zoom: number) => void;
  onToggleBackdrop: () => void;
  onToggleSafeZone: () => void;
  onToggleGrid: () => void;
  onToggleSnapGuides: () => void;
  onSelectionChange: (selectedIds: string[]) => void;
  onCommitObjects: (objects: CanonicalDesignObject[]) => void;
}

export function StudioCanvasStage({
  product,
  variant,
  activePrintArea,
  surface,
  allSurfaces,
  activeSurfaceKey,
  zoom,
  showBackdrop,
  showSafeZone,
  showGrid,
  snapToGuides,
  canvasRef,
  stageDimensionsRef,
  onSelectSurface,
  onZoomChange,
  onToggleBackdrop,
  onToggleSafeZone,
  onToggleGrid,
  onToggleSnapGuides,
  onSelectionChange,
  onCommitObjects,
}: StudioCanvasStageProps) {
  const { locale, t } = useAppLocale();
  const canvasElRef = useRef<HTMLCanvasElement | null>(null);
  const isHydratingRef = useRef(false);
  const snapEnabledRef = useRef(snapToGuides);
  const lastCommittedJsonRef = useRef('');
  const [snapGuides, setSnapGuides] = useState<SnapGuidesState>({
    verticalCenter: false,
    horizontalCenter: false,
  });

  // Derive responsive print-area canvas size preserving exact printArea physical aspect ratio
  const canvasBox = useMemo(() => {
    const outerPx = GARMENT_STAGE_BASE_PX;
    if (showBackdrop) {
      const boxW = Math.max(150, Math.round(activePrintArea.mockupBounds.width * outerPx));
      const boxH = Math.max(150, Math.round(activePrintArea.mockupBounds.height * outerPx));
      return {
        outerPx,
        leftPx: Math.round(activePrintArea.mockupBounds.x * outerPx),
        topPx: Math.round(activePrintArea.mockupBounds.y * outerPx),
        widthPx: boxW,
        heightPx: boxH,
      };
    }

    const ratio = activePrintArea.physicalWidthMm / Math.max(1, activePrintArea.physicalHeightMm);
    const maxArtboard = 410;
    const widthPx = ratio >= 1 ? maxArtboard : Math.round(maxArtboard * ratio);
    const heightPx = ratio >= 1 ? Math.round(maxArtboard / ratio) : maxArtboard;
    return {
      outerPx,
      leftPx: Math.round((outerPx - widthPx) / 2),
      topPx: Math.round((outerPx - heightPx) / 2),
      widthPx,
      heightPx,
    };
  }, [activePrintArea, showBackdrop]);

  const activeAreas = useMemo(
    () => product.printAreas.filter((pa) => pa.isActive).sort((a, b) => a.sortOrder - b.sortOrder),
    [product.printAreas]
  );

  // Store latest handlers/props in refs inside an effect so render stays pure
  const handlersRef = useRef({ onSelectionChange, onCommitObjects });
  const surfaceRef = useRef(surface);

  useEffect(() => {
    snapEnabledRef.current = snapToGuides;
    stageDimensionsRef.current = { width: canvasBox.widthPx, height: canvasBox.heightPx };
    handlersRef.current = { onSelectionChange, onCommitObjects };
    surfaceRef.current = surface;
  }, [
    snapToGuides,
    canvasBox.widthPx,
    canvasBox.heightPx,
    stageDimensionsRef,
    onSelectionChange,
    onCommitObjects,
    surface,
  ]);

  useEffect(() => {
    const el = canvasElRef.current;
    if (!el) {
      return;
    }

    let disposed = false;
    const fabricCanvas = new Canvas(el, {
      width: canvasBox.widthPx,
      height: canvasBox.heightPx,
      preserveObjectStacking: true,
      selection: true,
      backgroundColor: 'transparent',
    });

    canvasRef.current = fabricCanvas;

    const emitSelection = () => {
      if (isHydratingRef.current || disposed) {
        return;
      }
      const selected = fabricCanvas.getActiveObjects();
      const ids = selected
        .map((item) => getObjectMeta(item)?.id)
        .filter((id): id is string => Boolean(id));
      handlersRef.current.onSelectionChange(ids);
    };

    const emitCommit = () => {
      if (isHydratingRef.current || disposed) {
        return;
      }
      const nextObjects = serializeFabricCanvasToObjects(
        fabricCanvas,
        canvasBox.widthPx,
        canvasBox.heightPx
      );
      lastCommittedJsonRef.current = JSON.stringify(nextObjects);
      handlersRef.current.onCommitObjects(nextObjects);
    };

    const detachSnap = attachSnapGuides(
      fabricCanvas,
      canvasBox.widthPx,
      canvasBox.heightPx,
      () => snapEnabledRef.current,
      setSnapGuides
    );

    fabricCanvas.on('selection:created', emitSelection);
    fabricCanvas.on('selection:updated', emitSelection);
    fabricCanvas.on('selection:cleared', emitSelection);
    fabricCanvas.on('object:modified', emitCommit);
    fabricCanvas.on('text:changed', emitCommit);

    void (async () => {
      isHydratingRef.current = true;
      await ensureStudioFontsLoaded();
      if (disposed) {
        return;
      }
      const initialSurface = surfaceRef.current;
      const jsonSnapshot = JSON.stringify(initialSurface.objects);
      lastCommittedJsonRef.current = jsonSnapshot;
      await hydrateSurfaceToFabricCanvas(
        fabricCanvas,
        initialSurface,
        canvasBox.widthPx,
        canvasBox.heightPx
      );
      if (!disposed) {
        isHydratingRef.current = false;
      }
    })();

    return () => {
      disposed = true;
      detachSnap();
      fabricCanvas.off('selection:created', emitSelection);
      fabricCanvas.off('selection:updated', emitSelection);
      fabricCanvas.off('selection:cleared', emitSelection);
      fabricCanvas.off('object:modified', emitCommit);
      fabricCanvas.off('text:changed', emitCommit);
      void fabricCanvas.dispose();
      if (canvasRef.current === fabricCanvas) {
        canvasRef.current = null;
      }
    };
  }, [activeSurfaceKey, canvasBox.widthPx, canvasBox.heightPx, canvasRef]);

  // Synchronize external store changes (Undo/Redo, Inspector tweaks, Add/Delete layer, JSON apply)
  const serializedSurfaceObjects = useMemo(
    () => JSON.stringify(surface.objects),
    [surface.objects]
  );

  useEffect(() => {
    const fabricCanvas = canvasRef.current;
    if (!fabricCanvas) {
      return;
    }
    if (serializedSurfaceObjects === lastCommittedJsonRef.current) {
      return;
    }

    let cancelled = false;
    void (async () => {
      isHydratingRef.current = true;
      await ensureStudioFontsLoaded();
      if (cancelled) {
        return;
      }
      lastCommittedJsonRef.current = serializedSurfaceObjects;
      const activeIdsBefore = fabricCanvas
        .getActiveObjects()
        .map((obj: FabricObject) => getObjectMeta(obj)?.id)
        .filter((id): id is string => Boolean(id));

      await hydrateSurfaceToFabricCanvas(
        fabricCanvas,
        surface,
        canvasBox.widthPx,
        canvasBox.heightPx
      );
      if (!cancelled) {
        if (activeIdsBefore.length === 1) {
          const match = fabricCanvas
            .getObjects()
            .find((obj) => getObjectMeta(obj)?.id === activeIdsBefore[0]);
          if (match && match.selectable !== false) {
            fabricCanvas.setActiveObject(match);
            fabricCanvas.requestRenderAll();
          }
        }
        isHydratingRef.current = false;
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [serializedSurfaceObjects, surface, canvasBox.widthPx, canvasBox.heightPx, canvasRef]);

  const safeInsetXPercent =
    (activePrintArea.safeInsetMm / Math.max(1, activePrintArea.physicalWidthMm)) * 100;
  const safeInsetYPercent =
    (activePrintArea.safeInsetMm / Math.max(1, activePrintArea.physicalHeightMm)) * 100;

  const outputPxW = Math.round(
    (activePrintArea.physicalWidthMm / 25.4) * activePrintArea.targetDpi
  );
  const outputPxH = Math.round(
    (activePrintArea.physicalHeightMm / 25.4) * activePrintArea.targetDpi
  );

  return (
    <div className="flex h-full flex-col justify-between gap-3 rounded-2xl border border-border bg-surface p-3 sm:p-4">
      {/* Top Stage Header: Surface tabs + Production spec badge */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div
          className="flex flex-wrap items-center gap-1.5"
          role="tablist"
          aria-label={t('studio.printSurfaces')}
        >
          {activeAreas.map((area) => {
            const count = allSurfaces[area.surfaceKey]?.objects.length ?? 0;
            const selected = area.surfaceKey === activeSurfaceKey;
            return (
              <button
                key={area.id}
                type="button"
                role="tab"
                aria-selected={selected}
                onClick={() => onSelectSurface(area.surfaceKey)}
                className={`inline-flex min-h-10 items-center gap-2 rounded-lg border px-3 py-1.5 text-xs font-semibold transition ${
                  selected
                    ? 'border-accent bg-accent text-white shadow-sm'
                    : 'border-border bg-canvas text-ink-muted hover:text-ink'
                }`}
              >
                <span>{pickLocalizedText(locale, area.labelEn, area.labelBn)}</span>
                {count > 0 ? (
                  <span
                    className={`rounded-full px-1.5 py-0.5 font-mono text-[10px] ${
                      selected ? 'bg-white/20 text-white' : 'bg-accent/15 text-accent'
                    }`}
                  >
                    {count}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="neutral" className="gap-1.5 font-mono text-[11px]">
            <span
              className="h-2.5 w-2.5 rounded-full border border-black/25"
              style={{ backgroundColor: variant.colorHex }}
            />
            {activePrintArea.physicalWidthMm}×{activePrintArea.physicalHeightMm}mm · {outputPxW}×
            {outputPxH}px @ {activePrintArea.targetDpi} DPI
          </Badge>
        </div>
      </div>

      {/* Main Zoomable Garment + Interactive Print Canvas Stage */}
      <div className="relative flex min-h-[380px] flex-1 items-center justify-center overflow-auto rounded-xl border border-border bg-[radial-gradient(circle_at_center,rgba(37,99,235,0.06),transparent_65%),linear-gradient(135deg,var(--yc-canvas)_0%,var(--yc-white)_100%)] p-4">
        <div
          className="relative shrink-0 origin-center transition-transform duration-150 ease-out"
          style={{
            width: `${canvasBox.outerPx}px`,
            height: `${canvasBox.outerPx}px`,
            transform: `scale(${zoom})`,
          }}
        >
          {showBackdrop ? (
            <GarmentCanvasBackdrop
              garmentType={product.category.slug.includes('polo') ? 'polo_shirt' : 't_shirt'}
              surfaceKey={activeSurfaceKey}
              colorHex={variant.colorHex}
            />
          ) : (
            <div
              className="pointer-events-none absolute rounded-xl border border-dashed border-border"
              style={{
                left: `${canvasBox.leftPx}px`,
                top: `${canvasBox.topPx}px`,
                width: `${canvasBox.widthPx}px`,
                height: `${canvasBox.heightPx}px`,
                backgroundImage:
                  'linear-gradient(45deg, rgba(148,163,184,0.14) 25%, transparent 25%), linear-gradient(-45deg, rgba(148,163,184,0.14) 25%, transparent 25%), linear-gradient(45deg, transparent 75%, rgba(148,163,184,0.14) 75%), linear-gradient(-45deg, transparent 75%, rgba(148,163,184,0.14) 75%)',
                backgroundSize: '20px 20px',
                backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
              }}
            />
          )}

          {/* Print-Area Coordinate Frame & Interactive Fabric Canvas */}
          <div
            data-testid="studio-print-area-frame"
            className="absolute"
            style={{
              left: `${canvasBox.leftPx}px`,
              top: `${canvasBox.topPx}px`,
              width: `${canvasBox.widthPx}px`,
              height: `${canvasBox.heightPx}px`,
            }}
          >
            {/* Outer Print Boundary Frame */}
            <div className="pointer-events-none absolute inset-0 rounded-sm border border-dashed border-sky-400/80 shadow-[inset_0_0_0_1px_rgba(37,99,235,0.2)]" />

            {/* Safe Margin Guide */}
            {showSafeZone && activePrintArea.safeInsetMm > 0 ? (
              <div
                aria-hidden="true"
                className="pointer-events-none absolute border border-dotted border-cyan-400/65"
                style={{
                  left: `${safeInsetXPercent}%`,
                  right: `${safeInsetXPercent}%`,
                  top: `${safeInsetYPercent}%`,
                  bottom: `${safeInsetYPercent}%`,
                }}
              />
            ) : null}

            {/* Optional Alignment Grid */}
            {showGrid ? (
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 opacity-35"
                style={{
                  backgroundImage:
                    'linear-gradient(to right, rgba(56,189,248,0.45) 1px, transparent 1px), linear-gradient(to bottom, rgba(56,189,248,0.45) 1px, transparent 1px)',
                  backgroundSize: '25% 25%',
                }}
              />
            ) : null}

            {/* Snap Center Guides */}
            {snapGuides.verticalCenter ? (
              <div
                aria-hidden="true"
                className="pointer-events-none absolute top-0 bottom-0 left-1/2 w-px -translate-x-1/2 bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.9)]"
              />
            ) : null}
            {snapGuides.horizontalCenter ? (
              <div
                aria-hidden="true"
                className="pointer-events-none absolute left-0 right-0 top-1/2 h-px -translate-y-1/2 bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.9)]"
              />
            ) : null}

            <canvas
              ref={canvasElRef}
              id="yc-studio-2d-canvas"
              aria-label={t('studio.canvasAriaLabel')}
              className="block h-full w-full"
            />
          </div>
        </div>
      </div>

      {/* Bottom Stage Utility Bar: Guides + Zoom */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex flex-wrap items-center gap-1.5">
          <Button
            type="button"
            size="sm"
            variant={showBackdrop ? 'primary' : 'outline'}
            onClick={onToggleBackdrop}
          >
            {showBackdrop ? (
              <Eye className="mr-1.5 h-3.5 w-3.5" />
            ) : (
              <EyeOff className="mr-1.5 h-3.5 w-3.5" />
            )}
            {t('studio.garmentMockup')}
          </Button>
          <Button
            type="button"
            size="sm"
            variant={showSafeZone ? 'primary' : 'outline'}
            onClick={onToggleSafeZone}
          >
            <ShieldAlert className="mr-1.5 h-3.5 w-3.5" />
            {t('studio.safeZone')}
          </Button>
          <Button
            type="button"
            size="sm"
            variant={showGrid ? 'primary' : 'outline'}
            onClick={onToggleGrid}
          >
            <Grid className="mr-1.5 h-3.5 w-3.5" />
            {t('studio.grid')}
          </Button>
          <Button
            type="button"
            size="sm"
            variant={snapToGuides ? 'primary' : 'outline'}
            onClick={onToggleSnapGuides}
          >
            <Magnet className="mr-1.5 h-3.5 w-3.5" />
            {t('studio.snap')}
          </Button>
        </div>

        <div className="flex items-center gap-1.5">
          <Button
            type="button"
            size="sm"
            variant="outline"
            aria-label={t('studio.zoomOut')}
            onClick={() => onZoomChange(zoom - 0.15)}
          >
            <ZoomOut className="h-3.5 w-3.5" />
          </Button>
          <button
            type="button"
            onClick={() => onZoomChange(1)}
            className="min-w-14 rounded-md border border-border px-2 py-1.5 font-mono text-xs font-medium hover:bg-canvas"
          >
            {Math.round(zoom * 100)}%
          </button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            aria-label={t('studio.zoomIn')}
            onClick={() => onZoomChange(zoom + 0.15)}
          >
            <ZoomIn className="h-3.5 w-3.5" />
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            aria-label={t('studio.zoomReset')}
            onClick={() => onZoomChange(1)}
          >
            <Maximize2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
