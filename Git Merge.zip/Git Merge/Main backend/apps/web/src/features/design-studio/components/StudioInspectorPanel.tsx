import {
  type CanonicalDesignObject,
  type ProductPrintAreaDTO,
  STUDIO_FONT_PRESETS,
} from '@your-choice/shared-types';
import { Badge, Button } from '@your-choice/ui';
import {
  AlignCenterHorizontal,
  AlignCenterVertical,
  AlignEndHorizontal,
  AlignEndVertical,
  AlignStartHorizontal,
  AlignStartVertical,
  Copy,
  Crop,
  FlipHorizontal2,
  FlipVertical2,
  Group,
  Lock,
  Trash2,
  Ungroup,
} from 'lucide-react';
import { useAppLocale } from '@/i18n';

const STUDIO_INK_SWATCHES = [
  '#06080D',
  '#F8FAFC',
  '#1D4ED8',
  '#2563EB',
  '#22D3EE',
  '#DC2626',
  '#F59E0B',
  '#10B981',
] as const;

interface StudioInspectorPanelProps {
  activePrintArea: ProductPrintAreaDTO;
  selectedObjects: CanonicalDesignObject[];
  multiSelectionCount: number;
  onAlign: (mode: 'left' | 'center-x' | 'right' | 'top' | 'center-y' | 'bottom') => void;
  onGroupSelected: () => void;
  onUngroupSelected: () => void;
  onUpdateSelectedObject: (updater: (obj: CanonicalDesignObject) => CanonicalDesignObject) => void;
  onDuplicateSelected: () => void;
  onDeleteSelected: () => void;
  onOpenCropImage: () => void;
}

export function StudioInspectorPanel({
  activePrintArea,
  selectedObjects,
  multiSelectionCount,
  onAlign,
  onGroupSelected,
  onUngroupSelected,
  onUpdateSelectedObject,
  onDuplicateSelected,
  onDeleteSelected,
  onOpenCropImage,
}: StudioInspectorPanelProps) {
  const { t } = useAppLocale();
  const single =
    selectedObjects.length === 1 && multiSelectionCount <= 1 ? selectedObjects[0]! : null;

  return (
    <aside className="flex h-full flex-col gap-4 rounded-2xl border border-border bg-surface p-3.5 overflow-y-auto">
      <div className="flex items-center justify-between border-b border-border pb-2.5">
        <h2 className="text-xs font-bold uppercase tracking-wider text-ink-muted">
          {t('studio.inspectorTitle')}
        </h2>
        {single ? (
          <Badge variant="neutral" className="uppercase text-[10px]">
            {single.type}
          </Badge>
        ) : null}
      </div>

      {/* Multi-Selection Actions */}
      {multiSelectionCount >= 2 ? (
        <div className="space-y-3 rounded-xl border border-accent/40 bg-accent/10 p-3">
          <p className="text-xs font-semibold text-ink">
            {multiSelectionCount} {t('studio.layersSelected')}
          </p>
          <div className="flex flex-wrap gap-2">
            <Button type="button" size="sm" onClick={onGroupSelected}>
              <Group className="mr-1.5 h-3.5 w-3.5" />
              {t('studio.groupLayers')}
            </Button>
            <Button type="button" size="sm" variant="outline" onClick={onDeleteSelected}>
              <Trash2 className="mr-1.5 h-3.5 w-3.5" />
              {t('common.delete')}
            </Button>
          </div>
        </div>
      ) : null}

      {/* Empty Selection State */}
      {!single && multiSelectionCount < 2 ? (
        <div className="space-y-3 text-xs text-ink-muted">
          <p>{t('studio.inspectorEmptyHint')}</p>
          <div className="rounded-xl border border-border bg-canvas p-3 space-y-1.5">
            <p className="font-semibold text-ink">{t('studio.surfaceSpecs')}</p>
            <p className="font-mono text-[11px]">
              {activePrintArea.physicalWidthMm}mm × {activePrintArea.physicalHeightMm}mm
            </p>
            <p className="font-mono text-[11px]">
              {t('studio.safeInsetLabel')}: {activePrintArea.safeInsetMm}mm
            </p>
            <p className="font-mono text-[11px]">
              {t('studio.targetDpiLabel')}: {activePrintArea.targetDpi} DPI
            </p>
          </div>
        </div>
      ) : null}

      {/* Single Object Controls */}
      {single ? (
        <div className="space-y-4 text-xs">
          {single.locked ? (
            <div className="flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 p-2.5 text-amber-800 dark:text-amber-300">
              <Lock className="h-3.5 w-3.5 shrink-0" />
              <span>{t('studio.layerLockedNotice')}</span>
            </div>
          ) : null}

          {/* Alignment Bar */}
          <div className="space-y-1.5">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-muted">
              {t('studio.alignToPrintArea')}
            </p>
            <div className="grid grid-cols-6 gap-1">
              <Button
                type="button"
                size="sm"
                variant="outline"
                aria-label={t('studio.alignLeft')}
                onClick={() => onAlign('left')}
              >
                <AlignStartVertical className="h-3.5 w-3.5" />
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                aria-label={t('studio.alignCenterX')}
                onClick={() => onAlign('center-x')}
              >
                <AlignCenterVertical className="h-3.5 w-3.5" />
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                aria-label={t('studio.alignRight')}
                onClick={() => onAlign('right')}
              >
                <AlignEndVertical className="h-3.5 w-3.5" />
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                aria-label={t('studio.alignTop')}
                onClick={() => onAlign('top')}
              >
                <AlignStartHorizontal className="h-3.5 w-3.5" />
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                aria-label={t('studio.alignCenterY')}
                onClick={() => onAlign('center-y')}
              >
                <AlignCenterHorizontal className="h-3.5 w-3.5" />
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                aria-label={t('studio.alignBottom')}
                onClick={() => onAlign('bottom')}
              >
                <AlignEndHorizontal className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>

          {/* Physical Dimensions & Rotation Telemetry */}
          <div className="grid grid-cols-2 gap-2 rounded-xl border border-border bg-canvas p-2.5">
            <div>
              <span className="text-[10px] uppercase text-ink-muted">W × H (mm)</span>
              <p className="font-mono font-semibold text-ink">
                {Math.round(single.width * activePrintArea.physicalWidthMm)} ×{' '}
                {Math.round(single.height * activePrintArea.physicalHeightMm)} mm
              </p>
            </div>
            <div>
              <span className="text-[10px] uppercase text-ink-muted">X / Y (mm)</span>
              <p className="font-mono font-semibold text-ink">
                {Math.round(single.x * activePrintArea.physicalWidthMm)} /{' '}
                {Math.round(single.y * activePrintArea.physicalHeightMm)} mm
              </p>
            </div>
          </div>

          {/* Rotation & Opacity */}
          <div className="grid grid-cols-2 gap-2">
            <label className="space-y-1">
              <span className="text-[11px] font-medium text-ink-muted">
                {t('studio.rotationLabel')} (°)
              </span>
              <input
                type="number"
                value={Math.round(single.rotationDeg)}
                min={-360}
                max={360}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  if (Number.isFinite(val)) {
                    onUpdateSelectedObject((obj) => ({ ...obj, rotationDeg: val }));
                  }
                }}
                className="w-full rounded-lg border border-border bg-canvas px-2.5 py-1.5 text-base sm:text-xs font-mono"
              />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] font-medium text-ink-muted">
                {t('studio.opacityLabel')} ({Math.round(single.opacity * 100)}%)
              </span>
              <input
                type="range"
                min={0.1}
                max={1}
                step={0.05}
                value={single.opacity}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  onUpdateSelectedObject((obj) => ({ ...obj, opacity: val }));
                }}
                className="mt-2 h-2 w-full cursor-pointer accent-accent"
              />
            </label>
          </div>

          {/* Flip & Group controls */}
          <div className="flex flex-wrap gap-1.5">
            <Button
              type="button"
              size="sm"
              variant={single.flipX ? 'primary' : 'outline'}
              onClick={() => onUpdateSelectedObject((obj) => ({ ...obj, flipX: !obj.flipX }))}
            >
              <FlipHorizontal2 className="mr-1 h-3.5 w-3.5" />
              {t('studio.flipX')}
            </Button>
            <Button
              type="button"
              size="sm"
              variant={single.flipY ? 'primary' : 'outline'}
              onClick={() => onUpdateSelectedObject((obj) => ({ ...obj, flipY: !obj.flipY }))}
            >
              <FlipVertical2 className="mr-1 h-3.5 w-3.5" />
              {t('studio.flipY')}
            </Button>
            {single.type === 'group' ? (
              <Button type="button" size="sm" variant="outline" onClick={onUngroupSelected}>
                <Ungroup className="mr-1 h-3.5 w-3.5" />
                {t('studio.ungroupLayers')}
              </Button>
            ) : null}
          </div>

          {/* Text Properties */}
          {single.type === 'text' ? (
            <div className="space-y-3 border-t border-border pt-3">
              <label className="block space-y-1">
                <span className="text-[11px] font-medium text-ink-muted">
                  {t('studio.textContentLabel')}
                </span>
                <textarea
                  rows={2}
                  value={single.text}
                  onChange={(e) => {
                    const nextText = e.target.value;
                    onUpdateSelectedObject((obj) =>
                      obj.type === 'text' ? { ...obj, text: nextText || ' ' } : obj
                    );
                  }}
                  className="w-full rounded-lg border border-border bg-canvas px-2.5 py-1.5 text-base sm:text-xs"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-[11px] font-medium text-ink-muted">
                  {t('studio.fontFamilyLabel')}
                </span>
                <select
                  value={single.fontFamily}
                  onChange={(e) => {
                    const family = e.target.value;
                    onUpdateSelectedObject((obj) =>
                      obj.type === 'text' ? { ...obj, fontFamily: family } : obj
                    );
                  }}
                  className="w-full rounded-lg border border-border bg-canvas px-2.5 py-2 text-base sm:text-xs"
                >
                  {STUDIO_FONT_PRESETS.map((preset) => (
                    <option key={preset.id} value={preset.family}>
                      {preset.label}
                    </option>
                  ))}
                </select>
              </label>

              <div className="grid grid-cols-2 gap-2">
                <label className="space-y-1">
                  <span className="text-[11px] text-ink-muted">{t('studio.fontWeightLabel')}</span>
                  <select
                    value={single.fontWeight}
                    onChange={(e) => {
                      const weight = Number(e.target.value) as 400 | 600 | 700;
                      onUpdateSelectedObject((obj) =>
                        obj.type === 'text' ? { ...obj, fontWeight: weight } : obj
                      );
                    }}
                    className="w-full rounded-lg border border-border bg-canvas px-2 py-1.5 text-base sm:text-xs"
                  >
                    <option value={400}>Regular 400</option>
                    <option value={600}>SemiBold 600</option>
                    <option value={700}>Bold 700</option>
                  </select>
                </label>

                <label className="space-y-1">
                  <span className="text-[11px] text-ink-muted">
                    {t('studio.letterSpacingLabel')}
                  </span>
                  <input
                    type="number"
                    min={-100}
                    max={600}
                    step={20}
                    value={single.letterSpacing}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (Number.isFinite(val)) {
                        onUpdateSelectedObject((obj) =>
                          obj.type === 'text' ? { ...obj, letterSpacing: val } : obj
                        );
                      }
                    }}
                    className="w-full rounded-lg border border-border bg-canvas px-2 py-1.5 text-base sm:text-xs font-mono"
                  />
                </label>
              </div>
            </div>
          ) : null}

          {/* Ink Fill & Stroke Colors for Text / Shape / Graphic */}
          {single.type === 'text' || single.type === 'shape' || single.type === 'graphic' ? (
            <div className="space-y-2 border-t border-border pt-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-ink-muted">
                  {t('studio.inkFillColor')}
                </span>
                <input
                  type="color"
                  aria-label={t('studio.inkFillColor')}
                  value={single.fill}
                  onChange={(e) => {
                    const hex = e.target.value.toUpperCase();
                    onUpdateSelectedObject((obj) =>
                      obj.type === 'text' || obj.type === 'shape' || obj.type === 'graphic'
                        ? { ...obj, fill: hex }
                        : obj
                    );
                  }}
                  className="h-7 w-10 cursor-pointer rounded border border-border bg-transparent p-0"
                />
              </div>
              <div className="flex flex-wrap gap-1.5">
                {STUDIO_INK_SWATCHES.map((swatch) => (
                  <button
                    key={swatch}
                    type="button"
                    aria-label={swatch}
                    onClick={() =>
                      onUpdateSelectedObject((obj) =>
                        obj.type === 'text' || obj.type === 'shape' || obj.type === 'graphic'
                          ? { ...obj, fill: swatch }
                          : obj
                      )
                    }
                    className={`h-7 w-7 rounded-md border transition ${
                      single.fill.toUpperCase() === swatch
                        ? 'scale-110 border-accent ring-2 ring-accent/40'
                        : 'border-slate-400/50'
                    }`}
                    style={{ backgroundColor: swatch }}
                  />
                ))}
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <label className="space-y-1">
                  <span className="text-[11px] text-ink-muted">{t('studio.outlineColor')}</span>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={single.stroke ?? '#0F172A'}
                      onChange={(e) => {
                        const hex = e.target.value.toUpperCase();
                        onUpdateSelectedObject((obj) =>
                          obj.type === 'text' || obj.type === 'shape' || obj.type === 'graphic'
                            ? { ...obj, stroke: hex, strokeWidth: obj.strokeWidth || 2 }
                            : obj
                        );
                      }}
                      className="h-8 w-10 cursor-pointer rounded border border-border p-0"
                    />
                    {single.stroke ? (
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          onUpdateSelectedObject((obj) =>
                            obj.type === 'text' || obj.type === 'shape' || obj.type === 'graphic'
                              ? { ...obj, stroke: null, strokeWidth: 0 }
                              : obj
                          )
                        }
                      >
                        {t('common.clear')}
                      </Button>
                    ) : null}
                  </div>
                </label>
                <label className="space-y-1">
                  <span className="text-[11px] text-ink-muted">{t('studio.strokeWidth')}</span>
                  <input
                    type="number"
                    min={0}
                    max={40}
                    value={Math.round(single.strokeWidth)}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (Number.isFinite(val)) {
                        onUpdateSelectedObject((obj) =>
                          obj.type === 'text' || obj.type === 'shape' || obj.type === 'graphic'
                            ? {
                                ...obj,
                                stroke: val > 0 ? (obj.stroke ?? '#0F172A') : null,
                                strokeWidth: Math.max(0, Math.min(40, val)),
                              }
                            : obj
                        );
                      }
                    }}
                    className="w-full rounded-lg border border-border bg-canvas px-2 py-1.5 text-base sm:text-xs font-mono"
                  />
                </label>
              </div>
            </div>
          ) : null}

          {/* Image DPI & Crop */}
          {single.type === 'image' ? (
            <div className="space-y-3 border-t border-border pt-3">
              {(() => {
                const effSrcW = single.naturalWidthPx * (single.cropRect?.width ?? 1);
                const effSrcH = single.naturalHeightPx * (single.cropRect?.height ?? 1);
                const printWIn = (single.width * activePrintArea.physicalWidthMm) / 25.4;
                const printHIn = (single.height * activePrintArea.physicalHeightMm) / 25.4;
                const dpi = Math.round(
                  Math.min(effSrcW / Math.max(0.05, printWIn), effSrcH / Math.max(0.05, printHIn))
                );
                return (
                  <div className="flex items-center justify-between rounded-lg border border-border px-2.5 py-2">
                    <span className="text-[11px] text-ink-muted">
                      {t('studio.effectiveResolution')}
                    </span>
                    <Badge
                      variant={dpi >= 300 ? 'success' : 'warning'}
                      className="font-mono text-[11px]"
                    >
                      {dpi} DPI
                    </Badge>
                  </div>
                );
              })()}

              <Button type="button" variant="outline" className="w-full" onClick={onOpenCropImage}>
                <Crop className="mr-1.5 h-3.5 w-3.5" />
                {t('studio.cropImageBtn')}
              </Button>
            </div>
          ) : null}

          {/* Layer Quick Actions */}
          <div className="flex items-center gap-2 border-t border-border pt-3">
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="flex-1"
              onClick={onDuplicateSelected}
            >
              <Copy className="mr-1.5 h-3.5 w-3.5" />
              {t('studio.duplicate')}
            </Button>
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="flex-1"
              onClick={onDeleteSelected}
            >
              <Trash2 className="mr-1.5 h-3.5 w-3.5 text-danger" />
              {t('common.delete')}
            </Button>
          </div>
        </div>
      ) : null}
    </aside>
  );
}
