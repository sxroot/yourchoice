import type {
  AuthSessionDTO,
  AuthSuccessData,
  AuthUserDTO,
  PermissionCode,
  UserRole,
} from '@your-choice/shared-types';
import type { LoginInput, RegisterRequestInput, UpdateProfileInput } from '@your-choice/validation';
import { createContext, useContext } from 'react';

export const AUTH_SESSION_QUERY_KEY = ['auth', 'me'] as const;

export interface AuthContextValue {
  user: AuthUserDTO | null;
  session: AuthSessionDTO | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isLoggingOut: boolean;
  login: (input: LoginInput) => Promise<AuthSuccessData>;
  register: (input: RegisterRequestInput) => Promise<AuthSuccessData>;
  logout: () => Promise<void>;
  updateProfile: (input: UpdateProfileInput) => Promise<AuthUserDTO>;
  refreshSession: () => Promise<void>;
  hasRole: (allowedRoles: readonly UserRole[]) => boolean;
  hasPermission: (permission: PermissionCode) => boolean;
}

export const AuthContext = createContext<AuthContextValue | null>(null);

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used inside an AuthProvider');
  }
  return context;
}

/**
 * Prevents open redirects after authentication by permitting only internal relative routes.
 */
export function sanitizeRedirectPath(
  candidate: string | null | undefined,
  fallback = '/account'
): string {
  if (!candidate || typeof candidate !== 'string') {
    return fallback;
  }
  const trimmed = candidate.trim();
  if (!trimmed.startsWith('/') || trimmed.startsWith('//')) {
    return fallback;
  }
  return trimmed;
}
