import type { UserRole } from '@your-choice/shared-types';
import { Badge, Button, Card, Container, LoadingState } from '@your-choice/ui';
import { ShieldAlert } from 'lucide-react';
import type { ReactNode } from 'react';
import { Link, Navigate, useLocation, useSearchParams } from 'react-router-dom';
import { sanitizeRedirectPath, useAuth } from '../auth-context';

export function RequireAuth({ children }: { children: ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <Container className="py-12">
        <LoadingState label="Verifying your YOUR CHOICE session..." />
      </Container>
    );
  }

  if (!isAuthenticated) {
    const returnTo = encodeURIComponent(`${location.pathname}${location.search}`);
    return <Navigate to={`/login?redirect=${returnTo}`} replace />;
  }

  return <>{children}</>;
}

export function RequireRole({
  roles,
  children,
}: {
  roles: readonly UserRole[];
  children: ReactNode;
}) {
  const { user, isAuthenticated, isLoading, hasRole } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <Container className="py-12">
        <LoadingState label="Checking workspace permissions..." />
      </Container>
    );
  }

  if (!isAuthenticated) {
    const returnTo = encodeURIComponent(`${location.pathname}${location.search}`);
    return <Navigate to={`/login?redirect=${returnTo}`} replace />;
  }

  if (!hasRole(roles)) {
    return (
      <Container className="py-12 sm:py-16">
        <Card
          className="mx-auto max-w-xl p-6 sm:p-8"
          role="region"
          aria-labelledby="forbidden-title"
        >
          <div className="inline-flex size-12 items-center justify-center rounded-xl bg-danger-soft text-danger">
            <ShieldAlert className="size-6" aria-hidden="true" />
          </div>
          <h1 id="forbidden-title" className="mt-4 font-display text-2xl font-bold text-ink">
            Access Restricted
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-ink-muted">
            Your signed-in account does not hold the required role permission to open this area.
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-ink-muted">Your roles:</span>
            {user?.roles.map((role) => (
              <Badge key={role} variant="neutral">
                {role}
              </Badge>
            ))}
            <span className="text-xs font-medium text-ink-muted">Required:</span>
            {roles.map((role) => (
              <Badge key={role} variant="accent">
                {role}
              </Badge>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button asChild variant="primary">
              <Link to="/account">Go to Account</Link>
            </Button>
            <Button asChild variant="secondary">
              <Link to="/">Return Home</Link>
            </Button>
          </div>
        </Card>
      </Container>
    );
  }

  return <>{children}</>;
}

export function GuestOnlyRoute({ children }: { children: ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  const [searchParams] = useSearchParams();

  if (isLoading) {
    return (
      <Container className="py-12">
        <LoadingState label="Checking active session..." />
      </Container>
    );
  }

  if (isAuthenticated) {
    const destination = sanitizeRedirectPath(searchParams.get('redirect'), '/account');
    return <Navigate to={destination} replace />;
  }

  return <>{children}</>;
}
