import type {
  AuthMeResponseData,
  AuthSuccessData,
  AuthUserDTO,
  LogoutResponseData,
  PermissionCode,
  UserRole,
} from '@your-choice/shared-types';
import type { LoginInput, RegisterRequestInput, UpdateProfileInput } from '@your-choice/validation';
import { apiGet, apiPatch, apiPost, setClientCsrfToken } from '@/services/api-client';

export interface CreatorWorkspaceData {
  creatorId: string;
  roles: UserRole[];
  studioStatus: string;
  capabilities: PermissionCode[];
}

export interface AdminOverviewData {
  actorId: string;
  actorRoles: UserRole[];
  userCountSampled: number;
  users: AuthUserDTO[];
}

export async function fetchCurrentSession(signal?: AbortSignal): Promise<AuthMeResponseData> {
  const response = await apiGet<AuthMeResponseData>('/auth/me', signal);
  if (!response.success) {
    return {
      authenticated: false,
      user: null,
      session: null,
      csrfToken: '',
    };
  }
  if (response.data.csrfToken) {
    setClientCsrfToken(response.data.csrfToken);
  }
  return response.data;
}

export async function loginWithCredentials(input: LoginInput): Promise<AuthSuccessData> {
  const response = await apiPost<AuthSuccessData>('/auth/login', input);
  if (!response.success) {
    throw new Error('Authentication failed');
  }
  if (response.data.csrfToken) {
    setClientCsrfToken(response.data.csrfToken);
  }
  return response.data;
}

export async function registerCustomerAccount(
  input: RegisterRequestInput
): Promise<AuthSuccessData> {
  const response = await apiPost<AuthSuccessData>('/auth/register', input);
  if (!response.success) {
    throw new Error('Registration failed');
  }
  if (response.data.csrfToken) {
    setClientCsrfToken(response.data.csrfToken);
  }
  return response.data;
}

export async function logoutCurrentSession(): Promise<LogoutResponseData> {
  const response = await apiPost<LogoutResponseData>('/auth/logout');
  if (!response.success) {
    throw new Error('Logout failed');
  }
  return response.data;
}

export async function updateOwnProfile(input: UpdateProfileInput): Promise<AuthUserDTO> {
  const response = await apiPatch<{ user: AuthUserDTO }>('/users/me', input);
  if (!response.success) {
    throw new Error('Profile update failed');
  }
  return response.data.user;
}

export async function fetchCreatorWorkspace(signal?: AbortSignal): Promise<CreatorWorkspaceData> {
  const response = await apiGet<CreatorWorkspaceData>('/creator/workspace', signal);
  if (!response.success) {
    throw new Error('Unable to load creator workspace');
  }
  return response.data;
}

export async function fetchAdminOverview(signal?: AbortSignal): Promise<AdminOverviewData> {
  const response = await apiGet<AdminOverviewData>('/admin/overview', signal);
  if (!response.success) {
    throw new Error('Unable to load admin overview');
  }
  return response.data;
}
