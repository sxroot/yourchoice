import { Input, type InputProps } from '@your-choice/ui';
import { Eye, EyeOff } from 'lucide-react';
import { useState } from 'react';

export interface PasswordInputProps extends Omit<InputProps, 'type'> {
  id: string;
}

/**
 * Accessible password input with an explicit 44px visibility toggle.
 * Preserves browser password manager integration and paste support (WCAG 2.2 AA).
 */
export function PasswordInput({ className, ...props }: PasswordInputProps) {
  const [visible, setVisible] = useState(false);

  return (
    <div className="relative">
      <Input
        type={visible ? 'text' : 'password'}
        className={['pr-12', className].filter(Boolean).join(' ')}
        {...props}
      />
      <button
        type="button"
        onClick={() => setVisible((prev) => !prev)}
        aria-label={visible ? 'Hide password' : 'Show password'}
        aria-pressed={visible}
        className="absolute inset-y-0 right-0 inline-flex min-h-11 min-w-11 items-center justify-center rounded-r-lg text-ink-muted transition-colors hover:text-ink focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-accent-electric"
      >
        {visible ? (
          <EyeOff className="size-4" aria-hidden="true" />
        ) : (
          <Eye className="size-4" aria-hidden="true" />
        )}
      </button>
    </div>
  );
}
