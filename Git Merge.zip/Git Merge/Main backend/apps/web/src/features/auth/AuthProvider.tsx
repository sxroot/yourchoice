import type { AuthMeResponseData, PermissionCode, UserRole } from '@your-choice/shared-types';
import type { LoginInput, RegisterRequestInput, UpdateProfileInput } from '@your-choice/validation';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { type ReactNode, useCallback, useMemo } from 'react';
import {
  fetchCurrentSession,
  loginWithCredentials,
  logoutCurrentSession,
  registerCustomerAccount,
  updateOwnProfile,
} from './auth.api';
import { AUTH_SESSION_QUERY_KEY, AuthContext, type AuthContextValue } from './auth-context';
import { CART_QUERY_KEY } from '@/features/commerce/cart-context';

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();

  const sessionQuery = useQuery({
    queryKey: AUTH_SESSION_QUERY_KEY,
    queryFn: ({ signal }) => fetchCurrentSession(signal),
    retry: false,
    staleTime: 60_000,
    refetchOnWindowFocus: true,
  });

  const applyAuthenticatedState = useCallback(
    (
      user: AuthMeResponseData['user'],
      session: AuthMeResponseData['session'],
      csrfToken: string
    ) => {
      queryClient.setQueryData<AuthMeResponseData>(AUTH_SESSION_QUERY_KEY, {
        authenticated: Boolean(user),
        user,
        session,
        csrfToken,
      });
    },
    [queryClient]
  );

  const loginMutation = useMutation({
    mutationFn: (input: LoginInput) => loginWithCredentials(input),
    onSuccess: (data) => {
      applyAuthenticatedState(data.user, data.session, data.csrfToken);
      void queryClient.invalidateQueries({ queryKey: CART_QUERY_KEY });
    },
  });

  const registerMutation = useMutation({
    mutationFn: (input: RegisterRequestInput) => registerCustomerAccount(input),
    onSuccess: (data) => {
      applyAuthenticatedState(data.user, data.session, data.csrfToken);
      void queryClient.invalidateQueries({ queryKey: CART_QUERY_KEY });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: () => logoutCurrentSession(),
    onSettled: () => {
      const current = queryClient.getQueryData<AuthMeResponseData>(AUTH_SESSION_QUERY_KEY);
      queryClient.setQueryData<AuthMeResponseData>(AUTH_SESSION_QUERY_KEY, {
        authenticated: false,
        user: null,
        session: null,
        csrfToken: current?.csrfToken ?? '',
      });
      void queryClient.invalidateQueries({ queryKey: ['creator'] });
      void queryClient.invalidateQueries({ queryKey: ['admin'] });
      void queryClient.invalidateQueries({ queryKey: CART_QUERY_KEY });
    },
  });

  const profileMutation = useMutation({
    mutationFn: (input: UpdateProfileInput) => updateOwnProfile(input),
    onSuccess: (updatedUser) => {
      const current = queryClient.getQueryData<AuthMeResponseData>(AUTH_SESSION_QUERY_KEY);
      queryClient.setQueryData<AuthMeResponseData>(AUTH_SESSION_QUERY_KEY, {
        authenticated: true,
        user: updatedUser,
        session: current?.session ?? null,
        csrfToken: current?.csrfToken ?? '',
      });
    },
  });

  const user = sessionQuery.data?.authenticated ? sessionQuery.data.user : null;
  const session = sessionQuery.data?.authenticated ? sessionQuery.data.session : null;

  const hasRole = useCallback(
    (allowedRoles: readonly UserRole[]) => {
      if (!user) {
        return false;
      }
      return user.roles.some((role) => allowedRoles.includes(role));
    },
    [user]
  );

  const hasPermission = useCallback(
    (permission: PermissionCode) => {
      if (!user) {
        return false;
      }
      return user.permissions.includes(permission);
    },
    [user]
  );

  const refreshSession = useCallback(async () => {
    await queryClient.invalidateQueries({ queryKey: AUTH_SESSION_QUERY_KEY });
  }, [queryClient]);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      session,
      isAuthenticated: Boolean(user),
      isLoading: sessionQuery.isLoading,
      isLoggingOut: logoutMutation.isPending,
      login: loginMutation.mutateAsync,
      register: registerMutation.mutateAsync,
      logout: async () => {
        await logoutMutation.mutateAsync();
      },
      updateProfile: profileMutation.mutateAsync,
      refreshSession,
      hasRole,
      hasPermission,
    }),
    [
      user,
      session,
      sessionQuery.isLoading,
      logoutMutation,
      loginMutation.mutateAsync,
      registerMutation.mutateAsync,
      profileMutation.mutateAsync,
      refreshSession,
      hasRole,
      hasPermission,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
