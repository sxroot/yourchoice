import type {
  AddressListResponseData,
  AddressMutationResponseData,
  CustomerAddressDTO,
  DeleteAddressResponseData,
} from '@your-choice/shared-types';
import type { CreateAddressInput, UpdateAddressInput } from '@your-choice/validation';
import { apiDelete, apiGet, apiPatch, apiPost } from '@/services/api-client';

export async function fetchMyAddresses(signal?: AbortSignal): Promise<CustomerAddressDTO[]> {
  const response = await apiGet<AddressListResponseData>('/users/me/addresses', signal);
  if (!response.success) {
    throw new Error('Unable to load delivery addresses');
  }
  return response.data.addresses;
}

export async function createMyAddress(input: CreateAddressInput): Promise<CustomerAddressDTO> {
  const response = await apiPost<AddressMutationResponseData>('/users/me/addresses', input);
  if (!response.success) {
    throw new Error('Unable to create delivery address');
  }
  return response.data.address;
}

export async function updateMyAddress(
  addressPublicId: string,
  input: UpdateAddressInput
): Promise<CustomerAddressDTO> {
  const response = await apiPatch<AddressMutationResponseData>(
    `/users/me/addresses/${addressPublicId}`,
    input
  );
  if (!response.success) {
    throw new Error('Unable to update delivery address');
  }
  return response.data.address;
}

export async function deleteMyAddress(addressPublicId: string): Promise<string> {
  const response = await apiDelete<DeleteAddressResponseData>(
    `/users/me/addresses/${addressPublicId}`
  );
  if (!response.success) {
    throw new Error('Unable to delete delivery address');
  }
  return response.data.deletedId;
}
