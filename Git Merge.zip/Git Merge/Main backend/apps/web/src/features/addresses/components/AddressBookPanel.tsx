import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  BANGLADESH_DIVISIONS,
  type BangladeshDivision,
  type CustomerAddressDTO,
} from '@your-choice/shared-types';
import {
  type CreateAddressFormInput,
  type CreateAddressInput,
  createAddressSchema,
} from '@your-choice/validation';
import {
  Badge,
  Button,
  Card,
  Checkbox,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  EmptyState,
  FormField,
  Input,
  LoadingState,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@your-choice/ui';
import { CheckCircle2, MapPin, Pencil, Plus, Star, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import {
  createMyAddress,
  deleteMyAddress,
  fetchMyAddresses,
  updateMyAddress,
} from '@/features/addresses/addresses.api';
import { useAppLocale } from '@/i18n';
import { ApiClientError } from '@/services/api-client';

const EMPTY_ADDRESS_VALUES: CreateAddressFormInput = {
  label: '',
  recipientName: '',
  phone: '',
  division: 'Dhaka',
  district: 'Dhaka',
  area: '',
  addressLine: '',
  postalCode: '',
  isDefault: false,
};

function toFormValues(address: CustomerAddressDTO): CreateAddressFormInput {
  return {
    label: address.label,
    recipientName: address.recipientName,
    phone: address.phone,
    division: address.division,
    district: address.district,
    area: address.area,
    addressLine: address.addressLine,
    postalCode: address.postalCode ?? '',
    isDefault: address.isDefault,
  };
}

export function AddressBookPanel() {
  const { t } = useAppLocale();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAddress, setEditingAddress] = useState<CustomerAddressDTO | null>(null);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const addressesQuery = useQuery({
    queryKey: ['addresses', 'me'],
    queryFn: ({ signal }) => fetchMyAddresses(signal),
    retry: false,
  });

  const {
    register,
    control,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<CreateAddressFormInput, unknown, CreateAddressInput>({
    resolver: zodResolver(createAddressSchema),
    defaultValues: EMPTY_ADDRESS_VALUES,
  });

  const invalidateAddresses = async () => {
    await queryClient.invalidateQueries({ queryKey: ['addresses', 'me'] });
  };

  const createMutation = useMutation({
    mutationFn: (input: CreateAddressInput) => createMyAddress(input),
    onSuccess: async () => {
      await invalidateAddresses();
      setFeedbackMessage(t('addresses.savedSuccess'));
      setActionError(null);
      setDialogOpen(false);
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'Could not save address.');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, input }: { id: string; input: CreateAddressInput }) =>
      updateMyAddress(id, input),
    onSuccess: async () => {
      await invalidateAddresses();
      setFeedbackMessage(t('addresses.savedSuccess'));
      setActionError(null);
      setDialogOpen(false);
      setEditingAddress(null);
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'Could not update address.');
    },
  });

  const setDefaultMutation = useMutation({
    mutationFn: (addressId: string) => updateMyAddress(addressId, { isDefault: true }),
    onSuccess: async () => {
      await invalidateAddresses();
      setFeedbackMessage(t('addresses.savedSuccess'));
      setActionError(null);
    },
    onError: (err) => {
      setActionError(
        err instanceof ApiClientError ? err.message : 'Could not update default address.'
      );
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (addressId: string) => deleteMyAddress(addressId),
    onSuccess: async () => {
      await invalidateAddresses();
      setFeedbackMessage(t('addresses.deletedSuccess'));
      setActionError(null);
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'Could not delete address.');
    },
  });

  const openCreateDialog = () => {
    setEditingAddress(null);
    setActionError(null);
    reset({
      ...EMPTY_ADDRESS_VALUES,
      isDefault: (addressesQuery.data?.length ?? 0) === 0,
    });
    setDialogOpen(true);
  };

  const openEditDialog = (address: CustomerAddressDTO) => {
    setEditingAddress(address);
    setActionError(null);
    reset(toFormValues(address));
    setDialogOpen(true);
  };

  const onSubmit = async (values: CreateAddressInput) => {
    setFeedbackMessage(null);
    setActionError(null);
    if (editingAddress) {
      await updateMutation.mutateAsync({ id: editingAddress.id, input: values });
      return;
    }
    await createMutation.mutateAsync(values);
  };

  const addresses = addressesQuery.data ?? [];

  return (
    <Card className="p-6">
      <div className="flex flex-col gap-4 border-b border-border pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <MapPin className="size-5 text-accent-royal" aria-hidden="true" />
            <h2 className="font-display text-lg font-semibold text-ink">
              {t('addresses.sectionTitle')}
            </h2>
          </div>
          <p className="text-sm text-ink-muted">{t('addresses.sectionDesc')}</p>
        </div>

        <Button type="button" onClick={openCreateDialog} className="shrink-0">
          <Plus className="size-4" aria-hidden="true" />
          {t('addresses.addAddress')}
        </Button>
      </div>

      {feedbackMessage ? (
        <div
          role="status"
          className="mt-4 flex items-center gap-2 rounded-xl border border-success/30 bg-success-soft px-4 py-2.5 text-sm text-success"
        >
          <CheckCircle2 className="size-4 shrink-0" aria-hidden="true" />
          <span>{feedbackMessage}</span>
        </div>
      ) : null}

      {actionError && !dialogOpen ? (
        <div
          role="alert"
          className="mt-4 rounded-xl border border-danger/30 bg-danger-soft px-4 py-2.5 text-sm text-danger"
        >
          {actionError}
        </div>
      ) : null}

      <div className="mt-5">
        {addressesQuery.isLoading ? (
          <LoadingState label={t('common.loading')} />
        ) : addressesQuery.isError ? (
          <div
            role="alert"
            className="rounded-xl border border-warning/30 bg-warning-soft p-4 text-sm text-warning"
          >
            {addressesQuery.error instanceof Error
              ? addressesQuery.error.message
              : 'Delivery address service is currently unavailable.'}
          </div>
        ) : addresses.length === 0 ? (
          <EmptyState
            icon={<MapPin className="size-6" />}
            title={t('addresses.emptyTitle')}
            description={t('addresses.emptyDesc')}
            action={
              <Button type="button" variant="secondary" onClick={openCreateDialog}>
                <Plus className="size-4" aria-hidden="true" />
                {t('addresses.addAddress')}
              </Button>
            }
          />
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {addresses.map((address) => (
              <div
                key={address.id}
                data-testid={`address-card-${address.label}`}
                className="flex flex-col justify-between gap-4 rounded-xl border border-border bg-surface-muted/40 p-4"
              >
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-display text-base font-semibold text-ink">
                        {address.label}
                      </span>
                      {address.isDefault ? (
                        <Badge variant="accent" className="gap-1">
                          <Star className="size-3 fill-current" aria-hidden="true" />
                          {t('addresses.defaultBadge')}
                        </Badge>
                      ) : null}
                    </div>
                    <span className="rounded-md bg-surface px-2 py-0.5 font-mono text-xs text-ink-muted">
                      {address.division}
                    </span>
                  </div>

                  <div className="space-y-1 text-sm text-ink-muted">
                    <p className="font-medium text-ink">
                      {address.recipientName} · <span className="font-mono">{address.phone}</span>
                    </p>
                    <p>{address.addressLine}</p>
                    <p>
                      {address.area}, {address.district}, {address.division}
                      {address.postalCode ? ` - ${address.postalCode}` : ''}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 border-t border-border pt-3">
                  {!address.isDefault ? (
                    <Button
                      type="button"
                      size="sm"
                      variant="secondary"
                      disabled={setDefaultMutation.isPending}
                      onClick={() => {
                        setFeedbackMessage(null);
                        setDefaultMutation.mutate(address.id);
                      }}
                    >
                      <Star className="size-3.5" aria-hidden="true" />
                      {t('addresses.setDefault')}
                    </Button>
                  ) : null}

                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => openEditDialog(address)}
                  >
                    <Pencil className="size-3.5" aria-hidden="true" />
                    {t('common.edit')}
                  </Button>

                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    disabled={deleteMutation.isPending}
                    onClick={() => {
                      setFeedbackMessage(null);
                      deleteMutation.mutate(address.id);
                    }}
                    className="text-danger hover:bg-danger-soft hover:text-danger"
                  >
                    <Trash2 className="size-3.5" aria-hidden="true" />
                    {t('common.delete')}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>
              {editingAddress ? t('addresses.editAddress') : t('addresses.addAddress')}
            </DialogTitle>
            <DialogDescription>{t('addresses.sectionDesc')}</DialogDescription>
          </DialogHeader>

          {actionError ? (
            <div
              role="alert"
              className="mt-3 rounded-xl border border-danger/30 bg-danger-soft px-3.5 py-2.5 text-sm text-danger"
            >
              {actionError}
            </div>
          ) : null}

          <form onSubmit={handleSubmit(onSubmit)} noValidate className="mt-4 space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField
                id="address-label"
                label={t('addresses.labelField')}
                required
                error={errors.label?.message}
              >
                <Input
                  id="address-label"
                  placeholder={t('addresses.labelPlaceholder')}
                  invalid={Boolean(errors.label)}
                  {...register('label')}
                />
              </FormField>

              <FormField
                id="address-recipient"
                label={t('addresses.recipientField')}
                required
                error={errors.recipientName?.message}
              >
                <Input
                  id="address-recipient"
                  invalid={Boolean(errors.recipientName)}
                  {...register('recipientName')}
                />
              </FormField>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <FormField
                id="address-phone"
                label={t('addresses.phoneField')}
                required
                error={errors.phone?.message}
              >
                <Input
                  id="address-phone"
                  type="tel"
                  placeholder="+8801712345678"
                  invalid={Boolean(errors.phone)}
                  {...register('phone')}
                />
              </FormField>

              <FormField
                id="address-division"
                label={t('addresses.divisionField')}
                required
                error={errors.division?.message}
              >
                <Controller
                  control={control}
                  name="division"
                  render={({ field }) => (
                    <Select
                      value={field.value}
                      onValueChange={(val) => field.onChange(val as BangladeshDivision)}
                    >
                      <SelectTrigger id="address-division">
                        <SelectValue placeholder="Dhaka" />
                      </SelectTrigger>
                      <SelectContent>
                        {BANGLADESH_DIVISIONS.map((division) => (
                          <SelectItem key={division} value={division}>
                            {division}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                />
              </FormField>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              <FormField
                id="address-district"
                label={t('addresses.districtField')}
                required
                error={errors.district?.message}
              >
                <Input
                  id="address-district"
                  invalid={Boolean(errors.district)}
                  {...register('district')}
                />
              </FormField>

              <FormField
                id="address-area"
                label={t('addresses.areaField')}
                required
                error={errors.area?.message}
              >
                <Input
                  id="address-area"
                  placeholder="Dhanmondi"
                  invalid={Boolean(errors.area)}
                  {...register('area')}
                />
              </FormField>

              <FormField
                id="address-postal"
                label={t('addresses.postalCodeField')}
                error={errors.postalCode?.message}
              >
                <Input
                  id="address-postal"
                  placeholder="1209"
                  invalid={Boolean(errors.postalCode)}
                  {...register('postalCode')}
                />
              </FormField>
            </div>

            <FormField
              id="address-line"
              label={t('addresses.addressLineField')}
              required
              error={errors.addressLine?.message}
            >
              <Input
                id="address-line"
                placeholder="House 14, Road 6/A, Apt 4B"
                invalid={Boolean(errors.addressLine)}
                {...register('addressLine')}
              />
            </FormField>

            <Checkbox
              id="address-default"
              label={t('addresses.makeDefaultField')}
              {...register('isDefault')}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="secondary"
                onClick={() => setDialogOpen(false)}
                disabled={isSubmitting}
              >
                {t('common.cancel')}
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting
                  ? t('common.loading')
                  : editingAddress
                    ? t('addresses.updateAddress')
                    : t('addresses.saveAddress')}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
