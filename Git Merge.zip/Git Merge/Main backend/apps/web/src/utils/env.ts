import { z } from 'zod';

const webEnvSchema = z.object({
  VITE_APP_NAME: z.string().trim().min(1).default('YOUR CHOICE'),
  VITE_API_BASE_URL: z.string().trim().min(1).default('/api/v1'),
});

export const webEnv = webEnvSchema.parse({
  VITE_APP_NAME: import.meta.env.VITE_APP_NAME,
  VITE_API_BASE_URL: import.meta.env.VITE_API_BASE_URL,
});
