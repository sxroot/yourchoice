import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { RouterProvider } from 'react-router-dom';
import { MotionProvider } from '@/components/motion';
import { AuthProvider } from '@/features/auth/AuthProvider';
import { router } from './routes';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <MotionProvider>
          <RouterProvider router={router} />
        </MotionProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
