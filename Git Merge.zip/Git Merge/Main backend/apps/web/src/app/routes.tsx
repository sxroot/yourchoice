import { createBrowserRouter } from 'react-router-dom';
import { GuestOnlyRoute, RequireAuth, RequireRole } from '@/features/auth/components/RouteGuards';
import { RootLayout } from '@/layouts/RootLayout';
import { HomePage } from '@/pages/HomePage';
import { NotFoundPage } from '@/pages/NotFoundPage';
import { RouteErrorPage } from '@/pages/RouteErrorPage';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    errorElement: <RouteErrorPage />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: 'design-system',
        async lazy() {
          const { DesignSystemPage } = await import('@/pages/DesignSystemPage');
          return { Component: DesignSystemPage };
        },
      },
      {
        path: 'shop',
        async lazy() {
          const { ShopPage } = await import('@/pages/ShopPage');
          return { Component: ShopPage };
        },
      },
      {
        path: 'shop/:category',
        async lazy() {
          const { ShopPage } = await import('@/pages/ShopPage');
          return { Component: ShopPage };
        },
      },
      {
        path: 'product/:slug',
        async lazy() {
          const { ProductDetailPage } = await import('@/pages/ProductDetailPage');
          return { Component: ProductDetailPage };
        },
      },
      {
        path: 'studio',
        async lazy() {
          const { DesignStudioPage } = await import('@/pages/DesignStudioPage');
          return { Component: DesignStudioPage };
        },
      },
      {
        path: 'studio/:designId',
        async lazy() {
          const { DesignStudioPage } = await import('@/pages/DesignStudioPage');
          return { Component: DesignStudioPage };
        },
      },
      {
        path: 'cart',
        async lazy() {
          const { CartPage } = await import('@/pages/CartPage');
          return { Component: CartPage };
        },
      },
      {
        path: 'checkout',
        async lazy() {
          const { CheckoutPage } = await import('@/pages/CheckoutPage');
          return { Component: CheckoutPage };
        },
      },
      {
        path: 'orders',
        async lazy() {
          const { OrdersPage } = await import('@/pages/OrdersPage');
          return {
            Component: function ProtectedOrdersRoute() {
              return (
                <RequireAuth>
                  <OrdersPage />
                </RequireAuth>
              );
            },
          };
        },
      },
      {
        path: 'orders/:orderNumber',
        async lazy() {
          const { OrderDetailPage } = await import('@/pages/OrderDetailPage');
          return { Component: OrderDetailPage };
        },
      },
      {
        path: 'login',
        async lazy() {
          const { LoginPage } = await import('@/pages/LoginPage');
          return {
            Component: function GuardedLoginRoute() {
              return (
                <GuestOnlyRoute>
                  <LoginPage />
                </GuestOnlyRoute>
              );
            },
          };
        },
      },
      {
        path: 'register',
        async lazy() {
          const { RegisterPage } = await import('@/pages/RegisterPage');
          return {
            Component: function GuardedRegisterRoute() {
              return (
                <GuestOnlyRoute>
                  <RegisterPage />
                </GuestOnlyRoute>
              );
            },
          };
        },
      },
      {
        path: 'account',
        async lazy() {
          const { AccountPage } = await import('@/pages/AccountPage');
          return {
            Component: function ProtectedAccountRoute() {
              return (
                <RequireAuth>
                  <AccountPage />
                </RequireAuth>
              );
            },
          };
        },
      },
      {
        path: 'creator',
        async lazy() {
          const { CreatorWorkspacePage } = await import('@/pages/CreatorWorkspacePage');
          return {
            Component: function ProtectedCreatorRoute() {
              return (
                <RequireRole roles={['creator', 'admin', 'super_admin']}>
                  <CreatorWorkspacePage />
                </RequireRole>
              );
            },
          };
        },
      },
      {
        path: 'admin',
        async lazy() {
          const { AdminOverviewPage } = await import('@/pages/AdminOverviewPage');
          return {
            Component: function ProtectedAdminRoute() {
              return (
                <RequireRole roles={['admin', 'super_admin']}>
                  <AdminOverviewPage />
                </RequireRole>
              );
            },
          };
        },
      },
      {
        path: '*',
        element: <NotFoundPage />,
      },
    ],
  },
]);
