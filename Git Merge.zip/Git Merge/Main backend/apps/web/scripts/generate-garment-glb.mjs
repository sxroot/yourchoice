import { Buffer } from 'node:buffer';
import console from 'node:console';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as THREE from 'three';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const OUTPUT_DIR = path.resolve(__dirname, '..', 'public', 'models');

/**
 * Parametric garment torso point evaluator.
 * Produces an organic chest/shoulder/waist/hem drape centered vertically around y = 0.
 * - y spans roughly [-0.36, +0.34] (meters)
 * - front faces +Z, back faces -Z, wearer left side is +X
 */
function evaluateTorsoSurface(uCircumference, vHeight, necklineStyle = 'crew') {
  // uCircumference in [0, 1): 0 = +X side seam, 0.25 = +Z front center, 0.5 = -X side seam, 0.75 = -Z back center
  const theta = uCircumference * Math.PI * 2;
  const cosT = Math.cos(theta);
  const sinT = Math.sin(theta);

  // Bottom hem at -0.35, top shoulder base around +0.295
  const yBottom = -0.35;
  const shoulderHeight = 0.295 - 0.036 * Math.pow(Math.abs(cosT), 1.65);

  // Front neckline scoop (+Z is sinT > 0) and slight back neck drop
  const frontFactor = Math.max(0, sinT);
  const backFactor = Math.max(0, -sinT);
  const neckCenterProximity = Math.exp(-Math.pow(cosT / 0.34, 2));

  const neckDrop =
    necklineStyle === 'polo'
      ? (0.058 * Math.pow(frontFactor, 1.5) + 0.018 * Math.pow(backFactor, 1.4)) *
        neckCenterProximity
      : (0.082 * Math.pow(frontFactor, 1.6) + 0.022 * Math.pow(backFactor, 1.5)) *
        neckCenterProximity;

  const yTop = shoulderHeight - neckDrop;
  const y = THREE.MathUtils.lerp(yBottom, yTop, vHeight);

  // Half-width rx varies from hem (0.246m) -> subtle waist (0.236m) -> chest/shoulder (0.256m)
  const chestProfile = Math.exp(-Math.pow((vHeight - 0.76) / 0.28, 2));
  const waistDip = Math.exp(-Math.pow((vHeight - 0.36) / 0.22, 2));
  const neckTaper = Math.max(0, (vHeight - 0.88) / 0.12);
  let rx =
    0.246 -
    0.01 * waistDip +
    0.012 * chestProfile -
    0.055 * neckTaper * Math.pow(Math.abs(sinT), 2.0);
  rx = Math.max(0.11, rx);

  // Front-to-back depth rz: fuller upper chest (+Z), flatter back (-Z), tapered near shoulders
  const chestRoundness = Math.exp(-Math.pow((vHeight - 0.72) / 0.32, 2));
  const upperTaper = 1 - 0.42 * Math.pow(Math.max(0, (vHeight - 0.78) / 0.22), 1.5);
  let rz = (0.106 + 0.018 * chestRoundness - 0.008 * waistDip) * upperTaper;

  // Front chest contour vs slight spine curve in back
  if (sinT < 0) {
    rz *= 0.92;
  }

  // Superellipse exponent gives tailored broad shoulders instead of a pure cylinder
  const expX = 0.88;
  const expZ = 0.95;
  let x = rx * Math.sign(cosT) * Math.pow(Math.abs(cosT), expX);
  let z = rz * Math.sign(sinT) * Math.pow(Math.abs(sinT), expZ);

  // Subtle vertical cloth drape ripples near hem
  const drapeStrength = (1 - Math.min(1, vHeight * 1.15)) * 0.0045;
  const drape = Math.sin(theta * 5 + 0.6) * drapeStrength;
  x += cosT * drape;
  z += sinT * drape;

  return { x, y, z, nx: cosT, nz: sinT };
}

/**
 * Helper to create a triangle mesh from a parametric (u, v) evaluator.
 */
function buildParametricGridGeometry({
  uSteps,
  vSteps,
  uClosed = false,
  evaluate,
  flipWinding = false,
}) {
  const cols = uClosed ? uSteps : uSteps + 1;
  const rows = vSteps + 1;
  const positions = new Float32Array(cols * rows * 3);
  const uvs = new Float32Array(cols * rows * 2);

  for (let row = 0; row < rows; row++) {
    const v = row / vSteps;
    for (let col = 0; col < cols; col++) {
      const u = col / uSteps;
      const pt = evaluate(u, v);
      const idx = row * cols + col;
      positions[idx * 3] = pt.x;
      positions[idx * 3 + 1] = pt.y;
      positions[idx * 3 + 2] = pt.z;
      uvs[idx * 2] = pt.u ?? u;
      uvs[idx * 2 + 1] = pt.v ?? 1 - v;
    }
  }

  const indices = [];
  for (let row = 0; row < vSteps; row++) {
    for (let col = 0; col < uSteps; col++) {
      const nextCol = uClosed ? (col + 1) % uSteps : col + 1;
      const a = row * cols + col;
      const b = row * cols + nextCol;
      const c = (row + 1) * cols + col;
      const d = (row + 1) * cols + nextCol;

      if (!flipWinding) {
        indices.push(a, b, d, a, d, c);
      } else {
        indices.push(a, d, b, a, c, d);
      }
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/**
 * Builds the main torso outer shell + top shoulder cap seam + dark inner neck cavity lining.
 */
function buildTorsoBodyGeometry(necklineStyle) {
  const outer = buildParametricGridGeometry({
    uSteps: 72,
    vSteps: 36,
    uClosed: true,
    evaluate: (u, v) => {
      const pt = evaluateTorsoSurface(u, v, necklineStyle);
      return {
        x: pt.x,
        y: pt.y,
        z: pt.z,
        u: (u * 2) % 1,
        v: 1 - v,
      };
    },
    flipWinding: false,
  });

  // Build shoulder seam strip closing left and right top edges beside the neck hole
  const shoulderPositions = [];
  const shoulderUvs = [];
  const shoulderIndices = [];

  for (const side of [1, -1]) {
    const startIdx = shoulderPositions.length / 3;
    const steps = 16;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps; // 0 = front side -> 1 = back side around shoulder
      const cosVal = side * THREE.MathUtils.lerp(0.46, 0.99, Math.sin(t * Math.PI));
      const sinVal = THREE.MathUtils.lerp(0.88, -0.88, t);
      const uNorm = (Math.atan2(sinVal, cosVal) / (Math.PI * 2) + 1) % 1;
      const pt = evaluateTorsoSurface(uNorm, 1, necklineStyle);

      // Front/back ridge points slightly inset/closed toward centerline
      shoulderPositions.push(pt.x, pt.y, pt.z);
      shoulderUvs.push(t, 0.5);
      shoulderPositions.push(pt.x * 0.96, pt.y + 0.008, 0);
      shoulderUvs.push(t, 0.55);
    }

    for (let i = 0; i < steps; i++) {
      const a = startIdx + i * 2;
      const b = a + 1;
      const c = a + 2;
      const d = a + 3;
      if (side > 0) {
        shoulderIndices.push(a, c, d, a, d, b);
      } else {
        shoulderIndices.push(a, d, c, a, b, d);
      }
    }
  }

  const shoulderGeo = new THREE.BufferGeometry();
  shoulderGeo.setAttribute('position', new THREE.Float32BufferAttribute(shoulderPositions, 3));
  shoulderGeo.setAttribute('uv', new THREE.Float32BufferAttribute(shoulderUvs, 2));
  shoulderGeo.setIndex(shoulderIndices);
  shoulderGeo.computeVertexNormals();

  return mergeGeometries([outer, shoulderGeo]);
}

/**
 * Builds an angled tapered short sleeve with closed cuff rim.
 */
function buildSleeveGeometry(sideSign, necklineStyle) {
  // sideSign: +1 = wearer left (+X), -1 = wearer right (-X)
  const shoulderX = sideSign * 0.228;
  const shoulderY = 0.214;
  const angleRad = sideSign * -0.58; // angled downward ~33 deg
  const length = 0.215;

  const axisX = sideSign * Math.cos(Math.abs(angleRad));
  const axisY = Math.sin(-Math.abs(angleRad));
  // Perpendicular vector in XY plane
  const perpX = -axisY * sideSign;
  const perpY = axisX * sideSign;

  const sleeve = buildParametricGridGeometry({
    uSteps: 36,
    vSteps: 14,
    uClosed: true,
    evaluate: (u, v) => {
      const theta = u * Math.PI * 2;
      const dist = v * length;
      const radiusY = THREE.MathUtils.lerp(0.088, 0.068, Math.pow(v, 0.85));
      const radiusZ = THREE.MathUtils.lerp(0.082, 0.064, Math.pow(v, 0.85));

      const localUp = Math.cos(theta) * radiusY;
      const localZ = Math.sin(theta) * radiusZ;

      // Tuck inner root smoothly inside torso shoulder contour
      const tuck = (1 - Math.min(1, v * 2.5)) * 0.015;
      const centerX = shoulderX + axisX * dist - sideSign * tuck;
      const centerY = shoulderY + axisY * dist;

      // Slight arm drape downward
      const armDroop = -0.008 * Math.sin(v * Math.PI * 0.7);
      return {
        x: centerX + perpX * localUp,
        y: centerY + perpY * localUp + armDroop,
        z: localZ,
        u,
        v,
      };
    },
    flipWinding: sideSign < 0,
  });

  // Add subtle sleeve cuff hem band near v = 1
  const cuff = buildParametricGridGeometry({
    uSteps: 36,
    vSteps: 2,
    uClosed: true,
    evaluate: (u, v) => {
      const theta = u * Math.PI * 2;
      const dist = THREE.MathUtils.lerp(length - 0.022, length, v);
      const bump = v === 0 ? 0.002 : v === 1 ? -0.004 : 0.0028;
      const radiusY = 0.068 + bump;
      const radiusZ = 0.064 + bump;
      const centerX = shoulderX + axisX * dist;
      const centerY = shoulderY + axisY * dist - 0.006;
      return {
        x: centerX + perpX * Math.cos(theta) * radiusY,
        y: centerY + perpY * Math.cos(theta) * radiusY,
        z: Math.sin(theta) * radiusZ,
        u,
        v,
      };
    },
    flipWinding: sideSign < 0,
  });

  void necklineStyle;
  return mergeGeometries([sleeve, cuff]);
}

/**
 * Builds dark interior neck cavity lining so top-angle orbits never look hollow.
 */
function buildInnerLiningGeometry(necklineStyle) {
  return buildParametricGridGeometry({
    uSteps: 48,
    vSteps: 10,
    uClosed: true,
    evaluate: (u, v) => {
      const vTorso = THREE.MathUtils.lerp(0.68, 1.0, v);
      const pt = evaluateTorsoSurface(u, vTorso, necklineStyle);
      return {
        x: pt.x * 0.94,
        y: pt.y - 0.004,
        z: pt.z * 0.92,
        u,
        v: 1 - v,
      };
    },
    flipWinding: true, // inward facing
  });
}

/**
 * Builds ribbed crewneck collar ring wrapping around top neck opening.
 */
function buildCrewCollarGeometry() {
  return buildParametricGridGeometry({
    uSteps: 64,
    vSteps: 8,
    uClosed: true,
    evaluate: (u, v) => {
      const theta = u * Math.PI * 2;
      const cosT = Math.cos(theta);
      const sinT = Math.sin(theta);

      const neckRadiusX = 0.088;
      const neckRadiusZ = 0.072;
      const frontDrop = 0.056 * Math.pow(Math.max(0, sinT), 1.45);
      const backDrop = 0.014 * Math.pow(Math.max(0, -sinT), 1.4);

      const baseY = 0.292 - frontDrop - backDrop;
      // Tube cross-section profile around collar edge
      const tubeAngle = v * Math.PI * 1.4 - Math.PI * 0.25;
      const radialOut = Math.cos(tubeAngle) * 0.014;
      const verticalLift = Math.sin(tubeAngle) * 0.014;

      return {
        x: cosT * (neckRadiusX + radialOut),
        y: baseY + verticalLift,
        z: sinT * (neckRadiusZ + radialOut),
        u: (u * 4) % 1,
        v,
      };
    },
    flipWinding: false,
  });
}

/**
 * Builds structured polo collar stand + folded collar wings leaving front placket opening.
 */
function buildPoloCollarGeometry() {
  return buildParametricGridGeometry({
    uSteps: 56,
    vSteps: 10,
    uClosed: false,
    evaluate: (u, v) => {
      // Sweep around back neck, leaving front gap between the two collar points
      // u=0 -> right collar tip (x = -0.022, front), u=0.5 -> back neck center, u=1 -> left collar tip (x = +0.022, front)
      const sweep = THREE.MathUtils.lerp(-Math.PI * 0.36, Math.PI * 1.36, u);
      const cosT = Math.cos(sweep);
      const sinT = Math.sin(sweep);

      const frontOpenness = Math.pow(Math.max(0, 1 - Math.abs(u - 0.5) * 2), 0.7);
      const neckRadiusX = 0.086;
      const neckRadiusZ = 0.072;

      const ptYBase = 0.295 - 0.044 * Math.max(0, -sinT) + 0.008 * frontOpenness;
      // v in [0..0.45]: collar stand rising up; v in [0.45..1]: folded outer flap angling outward and down
      let radiusOffset;
      let yOffset;

      if (v <= 0.45) {
        const tStand = v / 0.45;
        yOffset = tStand * 0.034;
        radiusOffset = 0.003 * (1 - tStand);
      } else {
        const tFold = (v - 0.45) / 0.55;
        yOffset = 0.034 - tFold * (0.046 + 0.016 * (1 - frontOpenness));
        radiusOffset = 0.006 + tFold * 0.028;
      }

      // Collar point flare at front ends
      const tipSharpening =
        Math.abs(u - 0.5) > 0.38 ? 0.012 * (v > 0.45 ? (v - 0.45) / 0.55 : 0) : 0;

      return {
        x: cosT * (neckRadiusX + radiusOffset) + Math.sign(cosT) * tipSharpening,
        y: ptYBase + yOffset,
        z: -sinT * (neckRadiusZ + radiusOffset),
        u,
        v,
      };
    },
    flipWinding: false,
  });
}

/**
 * Builds front polo button placket box conforming to upper chest contour.
 */
function buildPoloPlacketGeometry() {
  const halfW = 0.017;
  const vMin = 0.66;
  const vMax = 0.895;

  const box = new THREE.BoxGeometry(halfW * 2, 0.165, 0.006, 2, 8, 1);
  const pos = box.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const px = pos.getX(i);
    const pyNorm = (pos.getY(i) + 0.165 / 2) / 0.165;
    const pzLocal = pos.getZ(i);
    const uCirc = 0.25 - px / 1.45;
    const vH = THREE.MathUtils.lerp(vMin, vMax, pyNorm);
    const surface = evaluateTorsoSurface(uCirc, vH, 'polo');
    pos.setXYZ(i, px, surface.y, surface.z + pzLocal + 0.0035);
  }
  box.computeVertexNormals();
  return box;
}

/**
 * Builds 3 subtle polo placket buttons.
 */
function buildPoloButtonsGeometry() {
  const buttons = [];
  const heights = [0.71, 0.775, 0.84];
  for (const vH of heights) {
    const surf = evaluateTorsoSurface(0.25, vH, 'polo');
    const cyl = new THREE.CylinderGeometry(0.0062, 0.0062, 0.0032, 18);
    cyl.rotateX(Math.PI / 2);
    cyl.translate(0, surf.y, surf.z + 0.0085);
    buttons.push(cyl);
  }
  return mergeGeometries(buttons);
}

/**
 * Builds a dedicated distortion-minimized curved print-zone UV island that conforms cleanly
 * to the torso contour at a small outward offset (+2.2mm) so CanvasTexture artwork maps 1:1
 * without stretching across sleeves/side seams or mirroring text.
 */
function buildPrintIslandGeometry({
  side, // 'front' | 'back'
  xMin,
  xMax,
  vMin,
  vMax,
  offsetMm = 2.4,
  necklineStyle = 'crew',
}) {
  const uSteps = 28;
  const vSteps = 28;
  const offsetM = offsetMm / 1000;

  return buildParametricGridGeometry({
    uSteps,
    vSteps,
    uClosed: false,
    evaluate: (uTex, vRow) => {
      // Top-down vertical parameter vRow in [0..1] (0 = bottom, 1 = top)
      // For glTF flipY=false CanvasTexture: (uTex=0, texV=0) is top-left, (uTex=1, texV=1) is bottom-right.
      const vTorso = THREE.MathUtils.lerp(vMin, vMax, vRow);

      // Horizontal X across front/back face so text reads left-to-right when camera faces that side:
      // - Facing FRONT (+Z): camera right is +X, camera left is -X -> x goes xMin -> xMax as uTex goes 0 -> 1.
      // - Facing BACK (-Z): camera right is -X, camera left is +X -> x goes xMax -> xMin as uTex goes 0 -> 1.
      const targetX =
        side === 'front'
          ? THREE.MathUtils.lerp(xMin, xMax, uTex)
          : THREE.MathUtils.lerp(xMax, xMin, uTex);

      // Estimate circumference uCirc matching targetX along front (+Z) or back (-Z) half-ellipse
      const basePt = evaluateTorsoSurface(side === 'front' ? 0.25 : 0.75, vTorso, necklineStyle);
      const maxXRef = Math.abs(evaluateTorsoSurface(0, vTorso, necklineStyle).x);
      const normX = THREE.MathUtils.clamp(targetX / Math.max(0.14, maxXRef), -0.92, 0.92);

      // Invert cos(theta) = normX onto front half (sin > 0) or back half (sin < 0)
      const angleBase = Math.acos(normX); // [0..pi], 0 at +X, pi at -X
      const theta = side === 'front' ? angleBase : Math.PI * 2 - angleBase;
      const uCirc = theta / (Math.PI * 2);

      const surfacePt = evaluateTorsoSurface(uCirc, vTorso, necklineStyle);
      void basePt;

      // Project outward smoothly along horizontal radial + slight Z face direction
      const mag = Math.hypot(surfacePt.nx, surfacePt.nz) || 1;
      const outX = (surfacePt.nx / mag) * offsetM;
      const outZ = (surfacePt.nz / mag) * offsetM;

      return {
        x: surfacePt.x + outX,
        y: surfacePt.y,
        z: surfacePt.z + outZ,
        u: uTex,
        v: 1 - vRow, // top row (vRow = 1) maps to CanvasTexture top v = 0 (flipY = false)
      };
    },
    flipWinding: false,
  });
}

/**
 * Simple indexed geometry merger matching position/uv/normal attributes.
 */
function mergeGeometries(geos) {
  let totalVerts = 0;
  let totalIndices = 0;

  for (const g of geos) {
    totalVerts += g.attributes.position.count;
    totalIndices += g.index ? g.index.count : g.attributes.position.count;
  }

  const positions = new Float32Array(totalVerts * 3);
  const normals = new Float32Array(totalVerts * 3);
  const uvs = new Float32Array(totalVerts * 2);
  const indices = new Uint32Array(totalIndices);

  let vOffset = 0;
  let iOffset = 0;

  for (const g of geos) {
    if (!g.attributes.normal) {
      g.computeVertexNormals();
    }
    const pos = g.attributes.position;
    const norm = g.attributes.normal;
    const uv = g.attributes.uv;

    for (let i = 0; i < pos.count; i++) {
      const dst = vOffset + i;
      positions[dst * 3] = pos.getX(i);
      positions[dst * 3 + 1] = pos.getY(i);
      positions[dst * 3 + 2] = pos.getZ(i);

      normals[dst * 3] = norm.getX(i);
      normals[dst * 3 + 1] = norm.getY(i);
      normals[dst * 3 + 2] = norm.getZ(i);

      uvs[dst * 2] = uv ? uv.getX(i) : 0;
      uvs[dst * 2 + 1] = uv ? uv.getY(i) : 0;
    }

    if (g.index) {
      for (let i = 0; i < g.index.count; i++) {
        indices[iOffset + i] = g.index.getX(i) + vOffset;
      }
      iOffset += g.index.count;
    } else {
      for (let i = 0; i < pos.count; i++) {
        indices[iOffset + i] = vOffset + i;
      }
      iOffset += pos.count;
    }
    vOffset += pos.count;
  }

  const merged = new THREE.BufferGeometry();
  merged.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  merged.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
  merged.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  merged.setIndex(new THREE.BufferAttribute(indices, 1));
  return merged;
}

/**
 * Pure glTF 2.0 binary (.glb) packer writing normalized BufferGeometries,
 * PBR materials, and named Scene nodes with zero browser dependencies.
 */
function exportMeshesToGlb(parts, outFilePath) {
  const binChunks = [];
  let byteLength = 0;

  const bufferViews = [];
  const accessors = [];
  const meshes = [];
  const nodes = [];
  const materials = [];
  const materialIndexByName = new Map();

  const appendBuffer = (typedArray, target) => {
    const raw = Buffer.from(typedArray.buffer, typedArray.byteOffset, typedArray.byteLength);
    const pad = (4 - (raw.byteLength % 4)) % 4;
    const viewIndex = bufferViews.length;
    bufferViews.push({
      buffer: 0,
      byteOffset: byteLength,
      byteLength: raw.byteLength,
      ...(target ? { target } : {}),
    });
    binChunks.push(raw);
    if (pad > 0) {
      binChunks.push(Buffer.alloc(pad, 0));
    }
    byteLength += raw.byteLength + pad;
    return viewIndex;
  };

  for (const part of parts) {
    let matIdx = materialIndexByName.get(part.materialName);
    if (matIdx === undefined) {
      matIdx = materials.length;
      materialIndexByName.set(part.materialName, matIdx);
      materials.push({
        name: part.materialName,
        pbrMetallicRoughness: {
          baseColorFactor: part.baseColorFactor ?? [0.95, 0.96, 0.98, 1],
          metallicFactor: part.metallicFactor ?? 0,
          roughnessFactor: part.roughnessFactor ?? 0.82,
        },
        alphaMode: part.alphaMode ?? 'OPAQUE',
        doubleSided: part.doubleSided ?? false,
      });
    }

    const geo = part.geometry;
    const posAttr = geo.attributes.position;
    const normAttr = geo.attributes.normal;
    const uvAttr = geo.attributes.uv;
    const idxAttr = geo.index;

    posAttr.array.forEach(() => {});
    let minX = Infinity;
    let minY = Infinity;
    let minZ = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let maxZ = -Infinity;
    for (let i = 0; i < posAttr.count; i++) {
      const x = posAttr.getX(i);
      const y = posAttr.getY(i);
      const z = posAttr.getZ(i);
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (z < minZ) minZ = z;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
      if (z > maxZ) maxZ = z;
    }

    const posArray = new Float32Array(posAttr.array);
    const normArray = new Float32Array(normAttr.array);
    const uvArray = new Float32Array(uvAttr.array);
    const useUint32 = posAttr.count > 65535;
    const idxArray = useUint32 ? new Uint32Array(idxAttr.array) : new Uint16Array(idxAttr.array);

    const posView = appendBuffer(posArray, 34962); // ARRAY_BUFFER
    const normView = appendBuffer(normArray, 34962);
    const uvView = appendBuffer(uvArray, 34962);
    const idxView = appendBuffer(idxArray, 34963); // ELEMENT_ARRAY_BUFFER

    const posAccessor = accessors.length;
    accessors.push({
      bufferView: posView,
      componentType: 5126, // FLOAT
      count: posAttr.count,
      type: 'VEC3',
      min: [minX, minY, minZ],
      max: [maxX, maxY, maxZ],
    });

    const normAccessor = accessors.length;
    accessors.push({
      bufferView: normView,
      componentType: 5126,
      count: normAttr.count,
      type: 'VEC3',
    });

    const uvAccessor = accessors.length;
    accessors.push({
      bufferView: uvView,
      componentType: 5126,
      count: uvAttr.count,
      type: 'VEC2',
    });

    const idxAccessor = accessors.length;
    accessors.push({
      bufferView: idxView,
      componentType: useUint32 ? 5125 : 5123, // UNSIGNED_INT : UNSIGNED_SHORT
      count: idxAttr.count,
      type: 'SCALAR',
    });

    const meshIndex = meshes.length;
    meshes.push({
      name: part.name,
      primitives: [
        {
          attributes: {
            POSITION: posAccessor,
            NORMAL: normAccessor,
            TEXCOORD_0: uvAccessor,
          },
          indices: idxAccessor,
          material: matIdx,
        },
      ],
    });

    nodes.push({
      name: part.name,
      mesh: meshIndex,
    });
  }

  const gltfJson = {
    asset: {
      version: '2.0',
      generator: 'YOUR CHOICE Parametric Garment Builder (CC0 Original In-House Asset)',
    },
    scene: 0,
    scenes: [
      {
        name: 'garment_root',
        nodes: nodes.map((_, idx) => idx),
      },
    ],
    nodes,
    meshes,
    materials,
    accessors,
    bufferViews,
    buffers: [
      {
        byteLength,
      },
    ],
  };

  const jsonString = JSON.stringify(gltfJson);
  const rawJson = Buffer.from(jsonString, 'utf8');
  const jsonPad = (4 - (rawJson.byteLength % 4)) % 4;
  const jsonChunk = Buffer.concat([rawJson, Buffer.alloc(jsonPad, 0x20)]);
  const binChunk = Buffer.concat(binChunks);

  const totalLength = 12 + 8 + jsonChunk.byteLength + 8 + binChunk.byteLength;
  const header = Buffer.alloc(12);
  header.writeUInt32LE(0x46546c67, 0); // 'glTF'
  header.writeUInt32LE(2, 4); // glTF v2
  header.writeUInt32LE(totalLength, 8);

  const jsonHeader = Buffer.alloc(8);
  jsonHeader.writeUInt32LE(jsonChunk.byteLength, 0);
  jsonHeader.writeUInt32LE(0x4e4f534a, 4); // 'JSON'

  const binHeader = Buffer.alloc(8);
  binHeader.writeUInt32LE(binChunk.byteLength, 0);
  binHeader.writeUInt32LE(0x004e4942, 4); // 'BIN\0'

  const finalBuffer = Buffer.concat([header, jsonHeader, jsonChunk, binHeader, binChunk]);
  fs.mkdirSync(path.dirname(outFilePath), { recursive: true });
  fs.writeFileSync(outFilePath, finalBuffer);
  return { byteLength: finalBuffer.byteLength, meshCount: meshes.length };
}

function buildCrewTshirtGlb() {
  const torso = buildTorsoBodyGeometry('crew');
  const leftSleeve = buildSleeveGeometry(1, 'crew');
  const rightSleeve = buildSleeveGeometry(-1, 'crew');
  const collar = buildCrewCollarGeometry();
  const lining = buildInnerLiningGeometry('crew');

  // Physical print islands matching seeded 280x360mm front & 300x400mm back
  const frontIsland = buildPrintIslandGeometry({
    side: 'front',
    xMin: -0.138,
    xMax: 0.138,
    vMin: 0.2,
    vMax: 0.77,
    offsetMm: 2.3,
    necklineStyle: 'crew',
  });
  const backIsland = buildPrintIslandGeometry({
    side: 'back',
    xMin: -0.148,
    xMax: 0.148,
    vMin: 0.18,
    vMax: 0.81,
    offsetMm: 2.3,
    necklineStyle: 'crew',
  });

  const parts = [
    {
      name: 'garment_body',
      geometry: mergeGeometries([torso, leftSleeve, rightSleeve]),
      materialName: 'fabric_jersey',
      roughnessFactor: 0.84,
      doubleSided: false,
    },
    {
      name: 'garment_collar',
      geometry: collar,
      materialName: 'fabric_rib_collar',
      roughnessFactor: 0.88,
      doubleSided: true,
    },
    {
      name: 'garment_lining',
      geometry: lining,
      materialName: 'fabric_lining',
      baseColorFactor: [0.06, 0.07, 0.09, 1],
      roughnessFactor: 0.92,
      doubleSided: false,
    },
    {
      name: 'garment_front',
      geometry: frontIsland,
      materialName: 'print_island_front',
      alphaMode: 'BLEND',
      roughnessFactor: 0.58,
      doubleSided: false,
    },
    {
      name: 'garment_back',
      geometry: backIsland,
      materialName: 'print_island_back',
      alphaMode: 'BLEND',
      roughnessFactor: 0.58,
      doubleSided: false,
    },
  ];

  return exportMeshesToGlb(parts, path.join(OUTPUT_DIR, 'crew-tshirt.glb'));
}

function buildPiquePoloGlb() {
  const torso = buildTorsoBodyGeometry('polo');
  const leftSleeve = buildSleeveGeometry(1, 'polo');
  const rightSleeve = buildSleeveGeometry(-1, 'polo');
  const collar = buildPoloCollarGeometry();
  const placket = buildPoloPlacketGeometry();
  const buttons = buildPoloButtonsGeometry();
  const lining = buildInnerLiningGeometry('polo');

  // Wearer's left chest sits on +X (when camera faces front +Z, viewer's right = wearer's left)
  const leftChestIsland = buildPrintIslandGeometry({
    side: 'front',
    xMin: 0.056,
    xMax: 0.151,
    vMin: 0.58,
    vMax: 0.74,
    offsetMm: 2.5,
    necklineStyle: 'polo',
  });

  // Also include standard upper back print zone matching 280x340mm seeded back print area
  const backIsland = buildPrintIslandGeometry({
    side: 'back',
    xMin: -0.14,
    xMax: 0.14,
    vMin: 0.22,
    vMax: 0.79,
    offsetMm: 2.3,
    necklineStyle: 'polo',
  });

  const parts = [
    {
      name: 'garment_body',
      geometry: mergeGeometries([torso, leftSleeve, rightSleeve, placket]),
      materialName: 'fabric_pique',
      roughnessFactor: 0.86,
      doubleSided: false,
    },
    {
      name: 'garment_collar',
      geometry: collar,
      materialName: 'fabric_polo_collar',
      roughnessFactor: 0.89,
      doubleSided: true,
    },
    {
      name: 'garment_buttons',
      geometry: buttons,
      materialName: 'polo_buttons_pearl',
      baseColorFactor: [0.18, 0.2, 0.24, 1],
      metallicFactor: 0.05,
      roughnessFactor: 0.28,
      doubleSided: false,
    },
    {
      name: 'garment_lining',
      geometry: lining,
      materialName: 'fabric_lining',
      baseColorFactor: [0.06, 0.07, 0.09, 1],
      roughnessFactor: 0.92,
      doubleSided: false,
    },
    {
      name: 'polo_left_chest',
      geometry: leftChestIsland,
      materialName: 'print_island_left_chest',
      alphaMode: 'BLEND',
      roughnessFactor: 0.56,
      doubleSided: false,
    },
    {
      name: 'garment_back',
      geometry: backIsland,
      materialName: 'print_island_back',
      alphaMode: 'BLEND',
      roughnessFactor: 0.56,
      doubleSided: false,
    },
  ];

  return exportMeshesToGlb(parts, path.join(OUTPUT_DIR, 'pique-polo.glb'));
}

const teeResult = buildCrewTshirtGlb();
const poloResult = buildPiquePoloGlb();
console.log(
  `Generated GLB garments cleanly:\n- crew-tshirt.glb: ${(teeResult.byteLength / 1024).toFixed(1)} KB (${teeResult.meshCount} meshes)\n- pique-polo.glb: ${(poloResult.byteLength / 1024).toFixed(1)} KB (${poloResult.meshCount} meshes)`
);
