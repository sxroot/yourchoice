import { rateLimit, type RateLimitRequestHandler } from 'express-rate-limit';
import { sendError } from '../utils/api-response.js';

export interface AuthRateLimitConfig {
  strictWindowMs?: number;
  strictMax?: number;
  generalWindowMs?: number;
  generalMax?: number;
}

export function createJsonRateLimiter(options: {
  windowMs: number;
  limit: number;
  message: string;
}): RateLimitRequestHandler {
  return rateLimit({
    windowMs: options.windowMs,
    limit: options.limit,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    handler: (_req, res) => {
      sendError(
        res,
        {
          code: 'TOO_MANY_REQUESTS',
          message: options.message,
        },
        429
      );
    },
  });
}

export function createAuthRateLimiters(config?: AuthRateLimitConfig) {
  const strictAuthLimiter = createJsonRateLimiter({
    windowMs: config?.strictWindowMs ?? 15 * 60 * 1000,
    limit: config?.strictMax ?? 15,
    message: 'Too many authentication attempts. Please wait a few minutes before trying again.',
  });

  const generalAuthLimiter = createJsonRateLimiter({
    windowMs: config?.generalWindowMs ?? 15 * 60 * 1000,
    limit: config?.generalMax ?? 120,
    message: 'Too many requests to authentication endpoints. Please slow down.',
  });

  return {
    strictAuthLimiter,
    generalAuthLimiter,
  };
}
