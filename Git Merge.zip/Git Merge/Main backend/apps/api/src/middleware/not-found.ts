import type { Request, Response } from 'express';
import { sendError } from '../utils/api-response.js';

export function notFoundHandler(req: Request, res: Response): void {
  sendError(
    res,
    {
      code: 'ROUTE_NOT_FOUND',
      message: `No route matched ${req.method} ${req.originalUrl}`,
    },
    404
  );
}
