import type { NextFunction, Request, Response } from 'express';
import type { Logger } from 'pino';
import { ZodError } from 'zod';
import { ApiError, isDatabaseUnavailableError } from '../utils/api-error.js';
import { sendError } from '../utils/api-response.js';

export function createErrorHandler(logger: Logger, isProduction: boolean) {
  return (error: unknown, req: Request, res: Response, _next: NextFunction): void => {
    const requestId = typeof res.locals.requestId === 'string' ? res.locals.requestId : 'unknown';

    if (error instanceof ApiError) {
      logger.warn({ err: error, requestId, path: req.originalUrl }, error.message);
      sendError(
        res,
        {
          code: error.code,
          message: error.message,
          ...(error.details ? { details: error.details } : {}),
        },
        error.statusCode
      );
      return;
    }

    if (error instanceof ZodError) {
      const details = error.issues.map((issue) => ({
        field: issue.path.join('.') || undefined,
        message: issue.message,
        code: issue.code,
      }));
      sendError(
        res,
        {
          code: 'VALIDATION_ERROR',
          message: 'Request validation failed',
          details,
        },
        400
      );
      return;
    }

    if (error instanceof SyntaxError && 'status' in error && error.status === 400) {
      sendError(
        res,
        {
          code: 'INVALID_JSON',
          message: 'Malformed JSON request payload',
        },
        400
      );
      return;
    }

    if (isDatabaseUnavailableError(error)) {
      logger.error({ err: error, requestId, path: req.originalUrl }, 'Database unavailable');
      sendError(
        res,
        {
          code: 'SERVICE_UNAVAILABLE',
          message: 'Database service is temporarily unavailable. Please try again shortly.',
        },
        503
      );
      return;
    }

    logger.error({ err: error, requestId, path: req.originalUrl }, 'Unhandled API error');

    sendError(
      res,
      {
        code: 'INTERNAL_SERVER_ERROR',
        message: isProduction
          ? 'An unexpected error occurred'
          : error instanceof Error
            ? error.message
            : 'An unexpected error occurred',
      },
      500
    );
  };
}
