import type { NextFunction, Request, Response } from 'express';
import type { ApiEnv } from '../config/env.js';
import {
  createSignedCsrfToken,
  safeEqualStrings,
  verifySignedCsrfToken,
} from '../modules/auth/tokens.js';
import { ApiError } from '../utils/api-error.js';
import { buildCsrfCookieOptions, CSRF_COOKIE_NAME, parseCookieHeader } from '../utils/cookies.js';

const SAFE_HTTP_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

function buildAllowedOrigins(env: ApiEnv): Set<string> {
  const allowed = new Set<string>(env.corsOriginsList);

  for (const candidateUrl of [env.WEB_URL, env.APP_URL]) {
    try {
      allowed.add(new URL(candidateUrl).origin);
    } catch {
      // Ignore invalid optional URL strings already guarded by Zod env parsing
    }
  }

  return allowed;
}

function extractRequestOrigin(req: Request): { present: boolean; origin: string | null } {
  const originHeader = req.get('origin');
  if (originHeader) {
    return { present: true, origin: originHeader };
  }

  const refererHeader = req.get('referer');
  if (refererHeader) {
    try {
      return { present: true, origin: new URL(refererHeader).origin };
    } catch {
      return { present: true, origin: null };
    }
  }

  return { present: false, origin: null };
}

/**
 * Reuses a valid signed CSRF cookie or mints a fresh one on the response.
 */
export function ensureCsrfToken(req: Request, res: Response, env: ApiEnv): string {
  const cookies = parseCookieHeader(req.headers.cookie);
  const existing = cookies[CSRF_COOKIE_NAME];

  if (existing && verifySignedCsrfToken(existing, env.SESSION_SECRET)) {
    return existing;
  }

  const token = createSignedCsrfToken(env.SESSION_SECRET);
  res.cookie(CSRF_COOKIE_NAME, token, buildCsrfCookieOptions(env));
  return token;
}

/**
 * Enforces Origin/Referer allowlisting and HMAC-signed Double-Submit CSRF verification
 * (`yc_csrf` cookie matching `X-CSRF-Token` header) on state-changing requests.
 */
export function createCsrfProtectionMiddleware(env: ApiEnv) {
  const allowedOrigins = buildAllowedOrigins(env);

  return (req: Request, _res: Response, next: NextFunction): void => {
    if (SAFE_HTTP_METHODS.has(req.method.toUpperCase()) || !env.CSRF_ENABLED) {
      next();
      return;
    }

    const originCheck = extractRequestOrigin(req);
    if (originCheck.present && (!originCheck.origin || !allowedOrigins.has(originCheck.origin))) {
      next(new ApiError(403, 'CSRF_ORIGIN_DENIED', 'Cross-site request origin is not permitted'));
      return;
    }

    const cookies = parseCookieHeader(req.headers.cookie);
    const cookieToken = cookies[CSRF_COOKIE_NAME];
    const headerToken = req.get('x-csrf-token');

    if (
      !cookieToken ||
      !headerToken ||
      !verifySignedCsrfToken(cookieToken, env.SESSION_SECRET) ||
      !safeEqualStrings(cookieToken, headerToken)
    ) {
      next(new ApiError(403, 'CSRF_TOKEN_INVALID', 'Missing or invalid CSRF token'));
      return;
    }

    next();
  };
}
