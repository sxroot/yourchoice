import type { PermissionCode, UserRole } from '@your-choice/shared-types';
import type { NextFunction, Request, Response } from 'express';
import type { ApiEnv } from '../config/env.js';
import type { AuthService, AuthenticatedContext } from '../modules/auth/auth.service.js';
import { ApiError, isDatabaseUnavailableError } from '../utils/api-error.js';
import {
  buildClearSessionCookieOptions,
  buildSessionCookieOptions,
  parseCookieHeader,
} from '../utils/cookies.js';

const AUTH_LOCALS_KEY = 'authContext';

export function getAuthContext(res: Response): AuthenticatedContext | null {
  const value = res.locals[AUTH_LOCALS_KEY] as AuthenticatedContext | null | undefined;
  return value ?? null;
}

export function requireAuthContext(res: Response): AuthenticatedContext {
  const context = getAuthContext(res);
  if (!context) {
    throw ApiError.unauthorized('Authentication is required for this resource');
  }
  return context;
}

function setAuthContext(res: Response, context: AuthenticatedContext | null): void {
  res.locals[AUTH_LOCALS_KEY] = context;
}

/**
 * Resolves `authContext` on `res.locals` from the HTTP-only session cookie when present.
 * Runs cleanly with zero DB queries for anonymous visitors without a cookie.
 */
export function createAttachAuthMiddleware(authService: AuthService, env: ApiEnv) {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const cookies = parseCookieHeader(req.headers.cookie);
    const rawSessionToken = cookies[env.SESSION_COOKIE_NAME];

    if (!rawSessionToken) {
      setAuthContext(res, null);
      next();
      return;
    }

    try {
      const authContext = await authService.authenticateSession(rawSessionToken);
      if (!authContext) {
        setAuthContext(res, null);
        res.clearCookie(env.SESSION_COOKIE_NAME, buildClearSessionCookieOptions(env));
        next();
        return;
      }

      if (authContext.renewedExpiresAt) {
        res.cookie(
          env.SESSION_COOKIE_NAME,
          rawSessionToken,
          buildSessionCookieOptions(env, authContext.renewedExpiresAt)
        );
      }

      setAuthContext(res, authContext);
      next();
    } catch (error: unknown) {
      if (isDatabaseUnavailableError(error)) {
        next(ApiError.serviceUnavailable('Authentication database is temporarily unavailable'));
        return;
      }
      next(error);
    }
  };
}

export function requireAuth(_req: Request, res: Response, next: NextFunction): void {
  if (!getAuthContext(res)) {
    next(ApiError.unauthorized('Authentication is required for this resource'));
    return;
  }
  next();
}

export function requireRoles(...allowedRoles: UserRole[]) {
  const allowedSet = new Set<UserRole>(allowedRoles);

  return (_req: Request, res: Response, next: NextFunction): void => {
    const auth = getAuthContext(res);
    if (!auth) {
      next(ApiError.unauthorized('Authentication is required for this resource'));
      return;
    }

    const hasAllowedRole = auth.user.roles.some((role) => allowedSet.has(role));
    if (!hasAllowedRole) {
      next(ApiError.forbidden(`Access denied. Required role: ${allowedRoles.join(' or ')}`));
      return;
    }

    next();
  };
}

export function requirePermissions(...requiredPermissions: PermissionCode[]) {
  return (_req: Request, res: Response, next: NextFunction): void => {
    const auth = getAuthContext(res);
    if (!auth) {
      next(ApiError.unauthorized('Authentication is required for this resource'));
      return;
    }

    const granted = new Set<PermissionCode>(auth.user.permissions);
    const missing = requiredPermissions.filter((perm) => !granted.has(perm));

    if (missing.length > 0) {
      next(ApiError.forbidden(`Missing required permissions: ${missing.join(', ')}`));
      return;
    }

    next();
  };
}

export interface OwnershipGuardOptions {
  resolveOwnerPublicId: (req: Request) => Promise<string | null> | string | null;
  bypassRoles?: readonly UserRole[];
  notFoundWhenMissing?: boolean;
}

/**
 * Enforces resource ownership unless the caller holds a designated administrative bypass role.
 */
export function requireOwnershipOrRole(options: OwnershipGuardOptions) {
  const bypassSet = new Set<UserRole>(options.bypassRoles ?? ['admin', 'super_admin']);

  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const auth = getAuthContext(res);
    if (!auth) {
      next(ApiError.unauthorized('Authentication is required for this resource'));
      return;
    }

    const hasBypass = auth.user.roles.some((role) => bypassSet.has(role));
    if (hasBypass) {
      next();
      return;
    }

    const ownerPublicId = await options.resolveOwnerPublicId(req);
    if (!ownerPublicId) {
      if (options.notFoundWhenMissing) {
        next(ApiError.notFound('Requested resource was not found'));
        return;
      }
      next(ApiError.forbidden('You do not have permission to access this resource'));
      return;
    }

    if (ownerPublicId !== auth.user.id) {
      next(ApiError.forbidden('You do not have permission to access this resource'));
      return;
    }

    next();
  };
}
