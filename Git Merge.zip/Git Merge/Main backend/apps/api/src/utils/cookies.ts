import type { CookieOptions } from 'express';
import type { ApiEnv } from '../config/env.js';

export const CSRF_COOKIE_NAME = 'yc_csrf';
export const GUEST_ORDER_RECEIPT_COOKIE = 'yc_order_receipt';

/**
 * Parses an HTTP `Cookie` request header into a key/value map without throwing on malformed encodings.
 */
export function parseCookieHeader(cookieHeader: string | undefined): Record<string, string> {
  if (!cookieHeader) {
    return {};
  }

  const result: Record<string, string> = {};
  const pairs = cookieHeader.split(';');

  for (const pair of pairs) {
    const eqIndex = pair.indexOf('=');
    if (eqIndex <= 0) {
      continue;
    }

    const name = pair.slice(0, eqIndex).trim();
    const rawValue = pair.slice(eqIndex + 1).trim();
    if (!name) {
      continue;
    }

    try {
      result[name] = decodeURIComponent(rawValue);
    } catch {
      result[name] = rawValue;
    }
  }

  return result;
}

function shouldUseSecureCookies(env: ApiEnv): boolean {
  return env.NODE_ENV === 'production' || env.NODE_ENV === 'staging';
}

export function buildSessionCookieOptions(env: ApiEnv, expiresAt: Date): CookieOptions {
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: shouldUseSecureCookies(env),
    path: '/',
    expires: expiresAt,
  };
}

export function buildClearSessionCookieOptions(env: ApiEnv): CookieOptions {
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: shouldUseSecureCookies(env),
    path: '/',
  };
}

export function buildCsrfCookieOptions(env: ApiEnv): CookieOptions {
  return {
    httpOnly: false,
    sameSite: 'lax',
    secure: shouldUseSecureCookies(env),
    path: '/',
    maxAge: env.SESSION_TTL_HOURS * 60 * 60 * 1000,
  };
}

export function buildCartCookieOptions(env: ApiEnv, expiresAt: Date): CookieOptions {
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: shouldUseSecureCookies(env),
    path: '/',
    expires: expiresAt,
  };
}

export function buildClearCartCookieOptions(env: ApiEnv): CookieOptions {
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: shouldUseSecureCookies(env),
    path: '/',
  };
}

export function buildGuestReceiptCookieOptions(env: ApiEnv): CookieOptions {
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: shouldUseSecureCookies(env),
    path: '/',
    maxAge: 24 * 60 * 60 * 1000,
  };
}
