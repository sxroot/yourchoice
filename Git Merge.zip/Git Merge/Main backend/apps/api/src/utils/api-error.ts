import type { ApiErrorDetail } from '@your-choice/shared-types';

export class ApiError extends Error {
  public readonly statusCode: number;
  public readonly code: string;
  public readonly details?: ApiErrorDetail[];

  constructor(statusCode: number, code: string, message: string, details?: ApiErrorDetail[]) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
  }

  static badRequest(message: string, details?: ApiErrorDetail[]): ApiError {
    return new ApiError(400, 'BAD_REQUEST', message, details);
  }

  static unauthorized(message = 'Authentication required'): ApiError {
    return new ApiError(401, 'UNAUTHORIZED', message);
  }

  static forbidden(message = 'Insufficient permissions'): ApiError {
    return new ApiError(403, 'FORBIDDEN', message);
  }

  static conflict(code: string, message: string): ApiError {
    return new ApiError(409, code, message);
  }

  static tooManyRequests(message = 'Too many requests, please try again later'): ApiError {
    return new ApiError(429, 'TOO_MANY_REQUESTS', message);
  }

  static notFound(message = 'Requested resource was not found'): ApiError {
    return new ApiError(404, 'NOT_FOUND', message);
  }

  static serviceUnavailable(
    message = 'Service temporarily unavailable, please retry shortly'
  ): ApiError {
    return new ApiError(503, 'SERVICE_UNAVAILABLE', message);
  }

  static internal(message = 'An unexpected internal error occurred'): ApiError {
    return new ApiError(500, 'INTERNAL_SERVER_ERROR', message);
  }
}

export function isDuplicateEntryError(error: unknown): boolean {
  if (typeof error !== 'object' || error === null) {
    return false;
  }

  const record = error as { code?: unknown; errno?: unknown; cause?: unknown };
  if (record.code === 'ER_DUP_ENTRY' || record.errno === 1062) {
    return true;
  }

  return record.cause ? isDuplicateEntryError(record.cause) : false;
}

export function isDatabaseUnavailableError(error: unknown): boolean {
  if (typeof error !== 'object' || error === null) {
    return false;
  }

  const record = error as { code?: unknown; cause?: unknown };
  const unavailableCodes = new Set([
    'ECONNREFUSED',
    'ENOTFOUND',
    'ETIMEDOUT',
    'EHOSTUNREACH',
    'PROTOCOL_CONNECTION_LOST',
    'ER_CON_COUNT_ERROR',
  ]);

  if (typeof record.code === 'string' && unavailableCodes.has(record.code)) {
    return true;
  }

  return record.cause ? isDatabaseUnavailableError(record.cause) : false;
}
