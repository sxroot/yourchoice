import type { Response } from 'express';
import type {
  ApiErrorPayload,
  ApiErrorResponse,
  ApiMeta,
  ApiSuccessResponse,
} from '@your-choice/shared-types';

function buildMeta(res: Response): ApiMeta {
  const requestId =
    typeof res.locals.requestId === 'string' && res.locals.requestId.length > 0
      ? res.locals.requestId
      : 'unknown';

  return {
    requestId,
    timestamp: new Date().toISOString(),
  };
}

export function sendSuccess<T>(
  res: Response,
  data: T,
  statusCode = 200
): Response<ApiSuccessResponse<T>> {
  return res.status(statusCode).json({
    success: true,
    data,
    meta: buildMeta(res),
  });
}

export function sendError(
  res: Response,
  error: ApiErrorPayload,
  statusCode = 500
): Response<ApiErrorResponse> {
  return res.status(statusCode).json({
    success: false,
    error,
    meta: buildMeta(res),
  });
}
