import { createApp } from './app.js';
import { getEnv } from './config/env.js';
import { createLogger } from './config/logger.js';
import { createDatabaseClient } from './database/client.js';
import { createDatabasePing } from './database/health.js';

async function bootstrap(): Promise<void> {
  const env = getEnv();
  const logger = createLogger(env);
  const database = createDatabaseClient(env);
  const pingDatabase = createDatabasePing(database.pool);

  const app = createApp({ env, logger, pingDatabase, db: database.db });

  const server = app.listen(env.API_PORT, env.API_HOST, () => {
    logger.info(
      {
        host: env.API_HOST,
        port: env.API_PORT,
        prefix: env.API_PREFIX,
        env: env.NODE_ENV,
      },
      `${env.APP_NAME} API server listening`
    );

    void pingDatabase().then((initialDbStatus) => {
      if (initialDbStatus.status === 'up') {
        logger.info({ latencyMs: initialDbStatus.latencyMs }, 'MariaDB connection verified');
      } else {
        logger.warn(
          { error: initialDbStatus.error },
          'MariaDB is not reachable at startup; /health will report unhealthy until connected'
        );
      }
    });
  });

  const shutdown = async (signal: NodeJS.Signals): Promise<void> => {
    logger.info({ signal }, 'Graceful shutdown initiated');
    server.close(async (closeError) => {
      if (closeError) {
        logger.error({ err: closeError }, 'Error closing HTTP server');
      }

      try {
        await database.close();
        logger.info('MariaDB connection pool closed');
      } catch (dbError) {
        logger.error({ err: dbError }, 'Error closing MariaDB connection pool');
      } finally {
        process.exit(closeError ? 1 : 0);
      }
    });
  };

  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
}

bootstrap().catch((error: unknown) => {
  console.error('[api] Fatal startup error:', error);
  process.exit(1);
});
