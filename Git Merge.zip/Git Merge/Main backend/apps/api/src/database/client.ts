import { drizzle, type MySql2Database } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import * as schema from '@your-choice/database/schema';
import type { ApiEnv } from '../config/env.js';

export type AppDatabase = MySql2Database<typeof schema>;

export interface DatabaseClient {
  pool: mysql.Pool;
  db: AppDatabase;
  close: () => Promise<void>;
}

export function createDatabaseClient(env: ApiEnv): DatabaseClient {
  const commonPoolOptions = {
    connectionLimit: env.DB_CONNECTION_LIMIT,
    connectTimeout: 2000,
    waitForConnections: true,
    queueLimit: 0,
    charset: 'utf8mb4',
    timezone: 'Z',
    ...(env.DB_SSL ? { ssl: {} } : {}),
  };

  const pool =
    env.DATABASE_URL && env.DATABASE_URL.length > 0
      ? mysql.createPool({
          uri: env.DATABASE_URL,
          ...commonPoolOptions,
        })
      : mysql.createPool({
          host: env.DB_HOST,
          port: env.DB_PORT,
          user: env.DB_USER,
          password: env.DB_PASSWORD,
          database: env.DB_NAME,
          ...commonPoolOptions,
        });

  const db = drizzle(pool, { schema, mode: 'default' });

  return {
    pool,
    db,
    close: async () => {
      await pool.end();
    },
  };
}
