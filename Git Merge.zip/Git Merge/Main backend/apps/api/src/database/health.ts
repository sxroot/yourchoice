import type mysql from 'mysql2/promise';
import type { DatabaseHealthCheck } from '@your-choice/shared-types';

const DEFAULT_PING_TIMEOUT_MS = 2500;

export type DatabasePingFn = () => Promise<DatabaseHealthCheck>;

export function createDatabasePing(
  pool: Pick<mysql.Pool, 'query'>,
  timeoutMs = DEFAULT_PING_TIMEOUT_MS
): DatabasePingFn {
  return async (): Promise<DatabaseHealthCheck> => {
    const start = performance.now();
    let timer: NodeJS.Timeout | undefined;

    try {
      const queryPromise = pool.query('SELECT 1 AS ok');
      const timeoutPromise = new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => {
          reject(new Error(`Database health check timed out after ${timeoutMs}ms`));
        }, timeoutMs);
      });

      await Promise.race([queryPromise, timeoutPromise]);

      return {
        status: 'up',
        dialect: 'mariadb',
        latencyMs: Math.round((performance.now() - start) * 100) / 100,
      };
    } catch (error) {
      const code =
        typeof error === 'object' &&
        error !== null &&
        'code' in error &&
        typeof error.code === 'string'
          ? error.code
          : 'DB_UNREACHABLE';

      return {
        status: 'down',
        dialect: 'mariadb',
        latencyMs: null,
        error:
          code === 'DB_UNREACHABLE' && error instanceof Error
            ? error.message
            : `Database unavailable (${code})`,
      };
    } finally {
      if (timer) {
        clearTimeout(timer);
      }
    }
  };
}
