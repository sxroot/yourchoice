import type {
  OrderDetailDTO,
  PaymentMethod,
  PaymentProviderAvailabilityDTO,
  PaymentStatus,
} from '@your-choice/shared-types';
import type { PaymentWebhookPayloadInput } from '@your-choice/validation';
import type { ApiEnv } from '../../config/env.js';
import { ApiError } from '../../utils/api-error.js';
import type { CommerceRepository } from '../commerce/commerce.repository.js';
import { type PaymentGatewayAdapter, createBangladeshPaymentRegistry } from './payment-gateway.js';

export function buildCanonicalWebhookPayload(payload: PaymentWebhookPayloadInput): string {
  return [
    payload.orderNumber,
    payload.providerPaymentId,
    payload.transactionRef,
    payload.status,
    payload.amount,
    payload.currencyCode.toUpperCase(),
  ].join('|');
}

export class PaymentService {
  private readonly registry: Map<PaymentMethod, PaymentGatewayAdapter>;

  constructor(
    private readonly commerceRepo: CommerceRepository,
    env: ApiEnv
  ) {
    this.registry = createBangladeshPaymentRegistry(env);
  }

  listProviderAvailability(): PaymentProviderAvailabilityDTO[] {
    return Array.from(this.registry.values()).map((adapter) => adapter.getAvailability());
  }

  assertMethodAvailableForCheckout(method: PaymentMethod): PaymentGatewayAdapter {
    const adapter = this.registry.get(method);
    if (!adapter) {
      throw new ApiError(
        400,
        'PAYMENT_PROVIDER_UNSUPPORTED',
        `Unsupported payment method: ${method}`
      );
    }

    const availability = adapter.getAvailability();
    if (!availability.enabled || !availability.configured) {
      throw new ApiError(
        400,
        'PAYMENT_PROVIDER_NOT_CONFIGURED',
        availability.unavailableReasonEn ?? `Payment provider "${method}" is not configured.`
      );
    }

    return adapter;
  }

  async verifyAndHandleWebhook(
    gateway: Exclude<PaymentMethod, 'cod'>,
    providedSignature: string | undefined,
    payload: PaymentWebhookPayloadInput
  ): Promise<{
    order: OrderDetailDTO;
    paymentStatus: PaymentStatus;
    idempotentReplay: boolean;
  }> {
    const adapter = this.registry.get(gateway);
    if (!adapter || !adapter.getWebhookSecret()) {
      throw ApiError.serviceUnavailable(
        `Payment gateway "${gateway}" webhook verification is not configured on this server.`
      );
    }

    if (!providedSignature) {
      throw new ApiError(
        401,
        'PAYMENT_WEBHOOK_SIGNATURE_MISSING',
        'Missing X-Webhook-Signature verification header.'
      );
    }

    const canonicalPayload = buildCanonicalWebhookPayload(payload);
    if (!adapter.verifyWebhookSignature(canonicalPayload, providedSignature)) {
      throw new ApiError(
        401,
        'PAYMENT_WEBHOOK_INVALID_SIGNATURE',
        'Invalid payment provider webhook signature.'
      );
    }

    return this.commerceRepo.applyVerifiedPaymentWebhook({
      orderNumber: payload.orderNumber,
      gateway,
      providerPaymentId: payload.providerPaymentId,
      transactionRef: payload.transactionRef,
      nextTransactionStatus: payload.status,
      amount: payload.amount,
      currencyCode: payload.currencyCode,
      rawPayload: payload as unknown as Record<string, unknown>,
    });
  }
}
