import { createHmac } from 'node:crypto';
import type { PaymentMethod, PaymentProviderAvailabilityDTO } from '@your-choice/shared-types';
import type { ApiEnv } from '../../config/env.js';
import { safeEqualStrings } from '../auth/tokens.js';

export interface PaymentGatewayAdapter {
  readonly method: PaymentMethod;
  getAvailability(): PaymentProviderAvailabilityDTO;
  getWebhookSecret(): string | null;
  verifyWebhookSignature(canonicalPayload: string, providedSignature: string): boolean;
}

class CodGatewayAdapter implements PaymentGatewayAdapter {
  readonly method = 'cod' as const;

  getAvailability(): PaymentProviderAvailabilityDTO {
    return {
      method: 'cod',
      labelEn: 'Cash on Delivery (COD)',
      labelBn: 'ক্যাশ অন ডেলিভারি (COD)',
      descriptionEn: 'Pay in cash when your parcel arrives anywhere across Bangladesh.',
      descriptionBn: 'বাংলাদেশের যেকোনো স্থানে পার্সেল হাতে পেয়ে নগদ মূল্য পরিশোধ করুন।',
      enabled: true,
      configured: true,
      mode: 'offline_settlement',
      unavailableReasonEn: null,
      unavailableReasonBn: null,
    };
  }

  getWebhookSecret(): string | null {
    return null;
  }

  verifyWebhookSignature(): boolean {
    return false;
  }
}

class ConfiguredWebhookGatewayAdapter implements PaymentGatewayAdapter {
  constructor(
    readonly method: Exclude<PaymentMethod, 'cod'>,
    private readonly meta: {
      labelEn: string;
      labelBn: string;
      descriptionEn: string;
      descriptionBn: string;
      unavailableReasonEn: string;
      unavailableReasonBn: string;
    },
    private readonly secret: string | null
  ) {}

  getAvailability(): PaymentProviderAvailabilityDTO {
    const isConfigured = Boolean(this.secret && this.secret.length >= 8);
    return {
      method: this.method,
      labelEn: this.meta.labelEn,
      labelBn: this.meta.labelBn,
      descriptionEn: this.meta.descriptionEn,
      descriptionBn: this.meta.descriptionBn,
      enabled: isConfigured,
      configured: isConfigured,
      mode: 'redirect_webhook',
      unavailableReasonEn: isConfigured ? null : this.meta.unavailableReasonEn,
      unavailableReasonBn: isConfigured ? null : this.meta.unavailableReasonBn,
    };
  }

  getWebhookSecret(): string | null {
    return this.secret;
  }

  verifyWebhookSignature(canonicalPayload: string, providedSignature: string): boolean {
    if (!this.secret) {
      return false;
    }

    const expectedHex = createHmac('sha256', this.secret)
      .update(canonicalPayload, 'utf8')
      .digest('hex');

    return safeEqualStrings(expectedHex.toLowerCase(), providedSignature.trim().toLowerCase());
  }
}

export function createBangladeshPaymentRegistry(
  env: ApiEnv
): Map<PaymentMethod, PaymentGatewayAdapter> {
  const adapters: PaymentGatewayAdapter[] = [
    new CodGatewayAdapter(),
    new ConfiguredWebhookGatewayAdapter(
      'bkash',
      {
        labelEn: 'bKash Mobile Wallet',
        labelBn: 'বিকাশ মোবাইল ওয়ালেট',
        descriptionEn: 'Instant BDT checkout verified via official bKash tokenized callback.',
        descriptionBn: 'অফিশিয়াল বিকাশ কলব্যাক ভেরিফিকেশনের মাধ্যমে তাৎক্ষণিক পেমেন্ট।',
        unavailableReasonEn:
          'Merchant API credentials (BKASH_WEBHOOK_SECRET) are not configured on this server.',
        unavailableReasonBn: 'সার্ভারে মার্চেন্ট বিকাশ ক্রেডেনশিয়াল কনফিগার করা নেই।',
      },
      env.BKASH_WEBHOOK_SECRET ?? null
    ),
    new ConfiguredWebhookGatewayAdapter(
      'nagad',
      {
        labelEn: 'Nagad Digital Payment',
        labelBn: 'নগদ ডিজিটাল পেমেন্ট',
        descriptionEn: 'Bangladesh MFS checkout with cryptographic signature verification.',
        descriptionBn: 'ক্রিপ্টোগ্রাফিক সিগনেচার যাচাইকৃত নগদ পেমেন্ট গেটওয়ে।',
        unavailableReasonEn:
          'Merchant credentials (NAGAD_WEBHOOK_SECRET) are not configured on this server.',
        unavailableReasonBn: 'সার্ভারে নগদ মার্চেন্ট ক্রেডেনশিয়াল কনফিগার করা নেই।',
      },
      env.NAGAD_WEBHOOK_SECRET ?? null
    ),
    new ConfiguredWebhookGatewayAdapter(
      'sslcommerz_card',
      {
        labelEn: 'Visa / Mastercard / Debit Card (SSLCommerz)',
        labelBn: 'ভিসা / মাস্টারকার্ড / ব্যাংক কার্ড (SSLCommerz)',
        descriptionEn: 'Local & international cards settled in BDT with IPN verification.',
        descriptionBn: 'IPN ভেরিফিকেশনসহ লোকাল ও আন্তর্জাতিক কার্ড পেমেন্ট।',
        unavailableReasonEn:
          'SSLCommerz store credentials (SSLCOMMERZ_STORE_PASSWD) are not configured on this server.',
        unavailableReasonBn: 'সার্ভারে SSLCommerz স্টোর ক্রেডেনশিয়াল কনফিগার করা নেই।',
      },
      env.SSLCOMMERZ_STORE_PASSWD ?? null
    ),
  ];

  return new Map(adapters.map((adapter) => [adapter.method, adapter]));
}
