import {
  paymentWebhookGatewayParamSchema,
  paymentWebhookPayloadSchema,
} from '@your-choice/validation';
import { Router } from 'express';
import { validateRequest } from '../../middleware/validate.js';
import { sendSuccess } from '../../utils/api-response.js';
import type { PaymentService } from './payment.service.js';

export function createPaymentWebhookRouter(paymentService: PaymentService): Router {
  const router = Router();

  router.post(
    '/:gateway',
    validateRequest({
      params: paymentWebhookGatewayParamSchema,
      body: paymentWebhookPayloadSchema,
    }),
    async (req, res) => {
      const { gateway } = req.params as { gateway: 'bkash' | 'nagad' | 'sslcommerz_card' };
      const signature = req.get('x-webhook-signature');

      const result = await paymentService.verifyAndHandleWebhook(gateway, signature, req.body);

      sendSuccess(res, {
        orderNumber: result.order.orderNumber,
        paymentStatus: result.paymentStatus,
        orderStatus: result.order.orderStatus,
        idempotentReplay: result.idempotentReplay,
      });
    }
  );

  return router;
}
