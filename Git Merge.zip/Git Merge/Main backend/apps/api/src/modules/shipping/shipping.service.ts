import type {
  BangladeshDivision,
  ShippingQuoteDTO,
  ShippingZoneDTO,
} from '@your-choice/shared-types';
import { ApiError } from '../../utils/api-error.js';
import type { CommerceRepository } from '../commerce/commerce.repository.js';
import { computeShippingQuote } from '../commerce/pricing.js';

export class ShippingService {
  constructor(private readonly commerceRepo: CommerceRepository) {}

  async listActiveZones(): Promise<ShippingZoneDTO[]> {
    return this.commerceRepo.listActiveShippingZones();
  }

  async resolveZoneForDivision(division: BangladeshDivision): Promise<ShippingZoneDTO> {
    const zone = await this.commerceRepo.findShippingZoneByDivision(division);
    if (!zone) {
      throw new ApiError(
        400,
        'SHIPPING_ZONE_UNAVAILABLE',
        `No active shipping configuration covers Bangladesh division "${division}".`
      );
    }
    return zone;
  }

  async getShippingQuote(
    division: BangladeshDivision,
    subtotalDecimal: string
  ): Promise<ShippingQuoteDTO> {
    const zone = await this.resolveZoneForDivision(division);
    return computeShippingQuote(division, zone, subtotalDecimal);
  }
}
