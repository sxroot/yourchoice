import type {
  ShippingQuoteResponseData,
  ShippingZonesResponseData,
} from '@your-choice/shared-types';
import { shippingQuoteQuerySchema } from '@your-choice/validation';
import { Router } from 'express';
import { validateRequest } from '../../middleware/validate.js';
import { sendSuccess } from '../../utils/api-response.js';
import type { ShippingService } from './shipping.service.js';

export function createShippingRouter(shippingService: ShippingService): Router {
  const router = Router();

  router.get('/zones', async (_req, res) => {
    const zones = await shippingService.listActiveZones();
    sendSuccess<ShippingZonesResponseData>(res, { zones });
  });

  router.get('/quote', validateRequest({ query: shippingQuoteQuerySchema }), async (req, res) => {
    const query = req.query as unknown as {
      division: Parameters<ShippingService['getShippingQuote']>[0];
      subtotal: string;
    };
    const quote = await shippingService.getShippingQuote(query.division, query.subtotal);
    sendSuccess<ShippingQuoteResponseData>(res, { quote });
  });

  return router;
}
