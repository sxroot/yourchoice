import { constants as fsConstants } from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';
import { ApiError } from '../../utils/api-error.js';

export interface StorageService {
  readonly driver: 'local' | 's3';
  putPrivateObject(objectKey: string, data: Buffer): Promise<void>;
  getPrivateObject(objectKey: string): Promise<Buffer>;
  deletePrivateObject(objectKey: string): Promise<void>;
  objectExists(objectKey: string): Promise<boolean>;
}

/**
 * Local disk private object storage rooted strictly outside public web directories.
 * Implements path-traversal sanitization so production masters (`private/print-masters/`)
 * and raw artwork (`private/uploads/`) remain cleanly partitioned until S3/R2 activates.
 */
export class LocalDiskStorageService implements StorageService {
  public readonly driver = 'local' as const;
  private readonly resolvedRoot: string;

  constructor(rootDir: string) {
    this.resolvedRoot = path.resolve(rootDir);
  }

  private resolveSafePath(objectKey: string): string {
    const cleaned = objectKey.replace(/\\/g, '/').replace(/^\/+/, '');
    if (!cleaned || cleaned.includes('\0') || cleaned.split('/').some((seg) => seg === '..')) {
      throw ApiError.badRequest('Invalid storage object key');
    }

    const candidate = path.resolve(this.resolvedRoot, cleaned);
    const relative = path.relative(this.resolvedRoot, candidate);
    if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) {
      throw ApiError.badRequest('Storage path escapes private storage root');
    }

    return candidate;
  }

  async putPrivateObject(objectKey: string, data: Buffer): Promise<void> {
    const filePath = this.resolveSafePath(objectKey);
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, data);
  }

  async getPrivateObject(objectKey: string): Promise<Buffer> {
    const filePath = this.resolveSafePath(objectKey);
    try {
      return await fs.readFile(filePath);
    } catch {
      throw ApiError.notFound('Stored artwork asset was not found');
    }
  }

  async deletePrivateObject(objectKey: string): Promise<void> {
    const filePath = this.resolveSafePath(objectKey);
    try {
      await fs.unlink(filePath);
    } catch {
      // Idempotent delete
    }
  }

  async objectExists(objectKey: string): Promise<boolean> {
    const filePath = this.resolveSafePath(objectKey);
    try {
      await fs.access(filePath, fsConstants.R_OK);
      return true;
    } catch {
      return false;
    }
  }
}
