import { Router } from 'express';
import { requireAuthContext, requirePermissions, requireRoles } from '../../middleware/auth.js';
import { sendSuccess } from '../../utils/api-response.js';

export function createCreatorRouter(): Router {
  const router = Router();

  router.get(
    '/workspace',
    requireRoles('creator', 'admin', 'super_admin'),
    requirePermissions('creator:studio:access'),
    (_req, res) => {
      const auth = requireAuthContext(res);
      sendSuccess(res, {
        creatorId: auth.user.id,
        roles: auth.user.roles,
        studioStatus: 'ready-for-phase-2',
        capabilities: auth.user.permissions,
      });
    }
  );

  return router;
}
