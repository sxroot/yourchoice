import type { OrderDetailResponseData, OrderListResponseData } from '@your-choice/shared-types';
import {
  adminOrderListQuerySchema,
  adminSettleCodPaymentSchema,
  adminUpdateOrderStatusSchema,
  orderNumberParamSchema,
} from '@your-choice/validation';
import { Router } from 'express';
import {
  getAuthContext,
  requireAuth,
  requirePermissions,
  requireRoles,
} from '../../middleware/auth.js';
import { validateRequest } from '../../middleware/validate.js';
import { sendSuccess } from '../../utils/api-response.js';
import type { OrderService } from './order.service.js';

export function createAdminOrdersRouter(orderService: OrderService): Router {
  const router = Router();

  router.use(requireAuth, requireRoles('staff', 'admin', 'super_admin'));

  router.get(
    '/orders',
    requirePermissions('orders:read:all'),
    validateRequest({ query: adminOrderListQuerySchema }),
    async (req, res) => {
      const query = req.query as unknown as Parameters<OrderService['adminListOrders']>[0];
      const result = await orderService.adminListOrders(query);
      sendSuccess<OrderListResponseData>(res, result);
    }
  );

  router.get(
    '/orders/:orderNumber',
    requirePermissions('orders:read:all'),
    validateRequest({ params: orderNumberParamSchema }),
    async (req, res) => {
      const { orderNumber } = req.params as { orderNumber: string };
      const order = await orderService.adminGetOrder(orderNumber);
      sendSuccess<OrderDetailResponseData>(res, { order });
    }
  );

  router.patch(
    '/orders/:orderNumber/status',
    requirePermissions('orders:write'),
    validateRequest({
      params: orderNumberParamSchema,
      body: adminUpdateOrderStatusSchema,
    }),
    async (req, res) => {
      const auth = getAuthContext(res)!;
      const { orderNumber } = req.params as { orderNumber: string };
      const order = await orderService.adminUpdateStatus({
        orderNumber,
        input: req.body,
        actorUserId: auth.internalUserId,
        actorRole: auth.user.roles[0] ?? 'admin',
        ipAddress: req.ip,
        requestId: res.locals.requestId as string | undefined,
      });

      sendSuccess<OrderDetailResponseData>(res, { order });
    }
  );

  router.post(
    '/orders/:orderNumber/payment-settlement',
    requirePermissions('orders:write'),
    validateRequest({
      params: orderNumberParamSchema,
      body: adminSettleCodPaymentSchema,
    }),
    async (req, res) => {
      const auth = getAuthContext(res)!;
      const { orderNumber } = req.params as { orderNumber: string };
      const order = await orderService.adminSettleCodPayment({
        orderNumber,
        input: req.body,
        actorUserId: auth.internalUserId,
        actorRole: auth.user.roles[0] ?? 'admin',
        ipAddress: req.ip,
        requestId: res.locals.requestId as string | undefined,
      });

      sendSuccess<OrderDetailResponseData>(res, { order });
    }
  );

  return router;
}
