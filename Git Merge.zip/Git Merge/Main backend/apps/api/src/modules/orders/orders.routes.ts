import type {
  CheckoutOptionsResponseData,
  OrderDetailResponseData,
  OrderListResponseData,
} from '@your-choice/shared-types';
import {
  cancelOwnOrderSchema,
  createOrderSchema,
  orderNumberParamSchema,
  paginationQuerySchema,
} from '@your-choice/validation';
import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import type { ApiEnv } from '../../config/env.js';
import { getAuthContext, requireAuth } from '../../middleware/auth.js';
import { validateRequest } from '../../middleware/validate.js';
import { sendSuccess } from '../../utils/api-response.js';
import {
  GUEST_ORDER_RECEIPT_COOKIE,
  buildClearCartCookieOptions,
  buildGuestReceiptCookieOptions,
  parseCookieHeader,
} from '../../utils/cookies.js';
import { type OrderService, signGuestOrderReceiptToken } from './order.service.js';

export function createCheckoutOptionsRouter(orderService: OrderService): Router {
  const router = Router();

  router.get('/options', async (_req, res) => {
    const options = await orderService.getCheckoutOptions();
    sendSuccess<CheckoutOptionsResponseData>(res, options);
  });

  return router;
}

export function createOrdersRouter(
  orderService: OrderService,
  env: ApiEnv,
  orderWriteMaxPerWindow = 25
): Router {
  const router = Router();

  const checkoutLimiter = rateLimit({
    windowMs: 10 * 60 * 1000,
    max: orderWriteMaxPerWindow,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: {
      success: false,
      error: {
        code: 'TOO_MANY_REQUESTS',
        message: 'Too many checkout attempts. Please try again in a few minutes.',
      },
    },
  });

  router.get(
    '/',
    requireAuth,
    validateRequest({ query: paginationQuerySchema }),
    async (req, res) => {
      const auth = getAuthContext(res)!;
      const query = req.query as unknown as { page: number; pageSize: number };
      const result = await orderService.listCustomerOrders(
        auth.internalUserId,
        query.page,
        query.pageSize
      );
      sendSuccess<OrderListResponseData>(res, result);
    }
  );

  router.post(
    '/',
    checkoutLimiter,
    validateRequest({ body: createOrderSchema }),
    async (req, res) => {
      const auth = getAuthContext(res);
      const cookies = parseCookieHeader(req.headers.cookie);
      const rawGuestCartToken = cookies[env.CART_COOKIE_NAME] ?? null;

      const order = await orderService.checkoutFromCart({
        userId: auth?.internalUserId ?? null,
        userEmail: auth?.user.email ?? null,
        userPhone: auth?.user.phone ?? null,
        actorRole: auth?.user.roles[0] ?? 'guest',
        rawGuestCartToken,
        input: req.body,
      });

      if (!auth) {
        res.clearCookie(env.CART_COOKIE_NAME, buildClearCartCookieOptions(env));
        res.cookie(
          GUEST_ORDER_RECEIPT_COOKIE,
          signGuestOrderReceiptToken(order.orderNumber, env.SESSION_SECRET),
          buildGuestReceiptCookieOptions(env)
        );
      }

      sendSuccess<OrderDetailResponseData>(res, { order }, 201);
    }
  );

  router.get(
    '/:orderNumber',
    validateRequest({ params: orderNumberParamSchema }),
    async (req, res) => {
      const auth = getAuthContext(res);
      const { orderNumber } = req.params as { orderNumber: string };
      const cookies = parseCookieHeader(req.headers.cookie);

      const isAdminOrStaff = Boolean(
        auth?.user.permissions.includes('orders:read:all') ||
        auth?.user.roles.some((r) => r === 'staff' || r === 'admin' || r === 'super_admin')
      );

      const order = await orderService.getOrderForViewer({
        orderNumber,
        viewerUserId: auth?.internalUserId ?? null,
        isAdminOrStaff,
        guestReceiptCookie: cookies[GUEST_ORDER_RECEIPT_COOKIE],
      });

      sendSuccess<OrderDetailResponseData>(res, { order });
    }
  );

  router.post(
    '/:orderNumber/cancel',
    requireAuth,
    validateRequest({ params: orderNumberParamSchema, body: cancelOwnOrderSchema }),
    async (req, res) => {
      const auth = getAuthContext(res)!;
      const { orderNumber } = req.params as { orderNumber: string };
      const body = req.body as { reason?: string };

      const order = await orderService.cancelCustomerOrder({
        orderNumber,
        userId: auth.internalUserId,
        reason: body.reason,
        ipAddress: req.ip,
        requestId: res.locals.requestId as string | undefined,
      });

      sendSuccess<OrderDetailResponseData>(res, { order });
    }
  );

  return router;
}
