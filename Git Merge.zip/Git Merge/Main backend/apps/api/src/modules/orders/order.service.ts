import { createHmac } from 'node:crypto';
import type {
  CheckoutOptionsResponseData,
  OrderDetailDTO,
  ShippingAddressSnapshotDTO,
} from '@your-choice/shared-types';
import type {
  AdminOrderListQueryInput,
  AdminSettleCodPaymentInput,
  AdminUpdateOrderStatusInput,
  CreateOrderInput,
} from '@your-choice/validation';
import type { ApiEnv } from '../../config/env.js';
import { ApiError } from '../../utils/api-error.js';
import type { AddressService } from '../addresses/address.service.js';
import type { AuditService } from '../audit/audit.service.js';
import { safeEqualStrings } from '../auth/tokens.js';
import type { CartService } from '../cart/cart.service.js';
import type {
  CommerceOrderListResult,
  CommerceRepository,
} from '../commerce/commerce.repository.js';
import type { PaymentService } from '../payments/payment.service.js';
import type { ShippingService } from '../shipping/shipping.service.js';

export function signGuestOrderReceiptToken(orderNumber: string, secret: string): string {
  const sig = createHmac('sha256', secret)
    .update(`yc_receipt:${orderNumber}`, 'utf8')
    .digest('base64url');
  return `${orderNumber}.${sig}`;
}

export function verifyGuestOrderReceiptToken(
  token: string | undefined,
  expectedOrderNumber: string,
  secret: string
): boolean {
  if (!token) return false;
  const expected = signGuestOrderReceiptToken(expectedOrderNumber, secret);
  return safeEqualStrings(token, expected);
}

export class OrderService {
  constructor(
    private readonly commerceRepo: CommerceRepository,
    private readonly cartService: CartService,
    private readonly shippingService: ShippingService,
    private readonly paymentService: PaymentService,
    private readonly addressService: AddressService,
    private readonly auditService: AuditService,
    private readonly env: ApiEnv
  ) {}

  async getCheckoutOptions(): Promise<CheckoutOptionsResponseData> {
    const [shippingZones, paymentProviders] = await Promise.all([
      this.shippingService.listActiveZones(),
      Promise.resolve(this.paymentService.listProviderAvailability()),
    ]);

    return { shippingZones, paymentProviders };
  }

  async checkoutFromCart(params: {
    userId: number | null;
    userEmail: string | null;
    userPhone: string | null;
    actorRole: string;
    rawGuestCartToken: string | null;
    input: CreateOrderInput;
  }): Promise<OrderDetailDTO> {
    // Verify configured payment gateway capability upfront — never simulate unconfigured digital gateways.
    this.paymentService.assertMethodAvailableForCheckout(params.input.paymentMethod);

    const activeCart = await this.cartService.resolveExistingCart({
      userId: params.userId,
      rawGuestCartToken: params.rawGuestCartToken,
    });

    if (!activeCart || activeCart.dto.items.length === 0) {
      throw ApiError.badRequest('Your shopping cart is empty');
    }

    if (activeCart.dto.hasUnavailableItems) {
      throw ApiError.conflict(
        'CART_HAS_UNAVAILABLE_ITEMS',
        'One or more cart items exceed available stock or are no longer available'
      );
    }

    let shippingSnapshot: ShippingAddressSnapshotDTO;

    if (params.input.savedAddressId) {
      if (params.userId === null) {
        throw ApiError.unauthorized('Sign in to use a saved delivery address');
      }
      const savedList = await this.addressService.listAddresses(params.userId);
      const matched = savedList.find((addr) => addr.id === params.input.savedAddressId);
      if (!matched) {
        throw ApiError.notFound('Selected saved delivery address was not found');
      }

      shippingSnapshot = {
        label: matched.label,
        recipientName: matched.recipientName,
        phone: matched.phone,
        division: matched.division,
        district: matched.district,
        area: matched.area,
        addressLine: matched.addressLine,
        postalCode: matched.postalCode ?? null,
      };
    } else if (params.input.shippingAddress) {
      const addr = params.input.shippingAddress;
      shippingSnapshot = {
        label: addr.label ?? null,
        recipientName: addr.recipientName,
        phone: addr.phone,
        division: addr.division,
        district: addr.district,
        area: addr.area,
        addressLine: addr.addressLine,
        postalCode: addr.postalCode ?? null,
      };
    } else {
      throw ApiError.badRequest('Provide a delivery address to place your order');
    }

    const customerEmail = params.input.customerEmail ?? params.userEmail;
    if (!customerEmail) {
      throw ApiError.badRequest('A contact email address is required for order confirmation');
    }

    const customerPhone = params.input.customerPhone ?? shippingSnapshot.phone ?? params.userPhone;
    if (!customerPhone) {
      throw ApiError.badRequest('A contact phone number is required for delivery');
    }

    const shippingZone = await this.shippingService.resolveZoneForDivision(
      shippingSnapshot.division
    );

    const createdOrder = await this.commerceRepo.placeOrderTransactionally({
      userId: params.userId,
      cartId: activeCart.cartId,
      customerEmail,
      customerPhone,
      shippingAddress: shippingSnapshot,
      shippingZoneCode: shippingZone.code,
      paymentMethod: params.input.paymentMethod,
      customerNote: params.input.customerNote ?? null,
      actorRole: params.actorRole,
    });

    await this.auditService.record({
      actorUserId: params.userId,
      action: 'order.placed',
      entityType: 'order',
      entityPublicId: createdOrder.orderNumber,
      metadata: {
        paymentMethod: createdOrder.paymentMethod,
        totalAmount: createdOrder.totalAmount,
        itemCount: createdOrder.itemCount,
      },
    });

    return createdOrder;
  }

  async listCustomerOrders(
    userId: number,
    page: number,
    pageSize: number
  ): Promise<CommerceOrderListResult> {
    return this.commerceRepo.listOrdersByUserId(userId, page, pageSize);
  }

  async getOrderForViewer(params: {
    orderNumber: string;
    viewerUserId: number | null;
    isAdminOrStaff: boolean;
    guestReceiptCookie: string | undefined;
  }): Promise<OrderDetailDTO> {
    const found = await this.commerceRepo.findOrderByNumber(params.orderNumber);
    if (!found) {
      throw ApiError.notFound('Order not found');
    }

    if (params.isAdminOrStaff) {
      return found.order;
    }

    if (params.viewerUserId !== null && found.ownerUserId === params.viewerUserId) {
      return found.order;
    }

    if (
      found.ownerUserId === null &&
      verifyGuestOrderReceiptToken(
        params.guestReceiptCookie,
        found.order.orderNumber,
        this.env.SESSION_SECRET
      )
    ) {
      return found.order;
    }

    if (params.viewerUserId === null) {
      throw ApiError.unauthorized('Sign in as the order owner to inspect this order');
    }

    throw ApiError.forbidden('You do not have access to inspect this order');
  }

  async cancelCustomerOrder(params: {
    orderNumber: string;
    userId: number;
    reason?: string;
    ipAddress?: string;
    requestId?: string;
  }): Promise<OrderDetailDTO> {
    const cancelled = await this.commerceRepo.cancelOrderTransactionally({
      orderNumber: params.orderNumber,
      actorUserId: params.userId,
      actorRole: 'customer',
      reason: params.reason ?? 'Cancelled by customer before fulfillment',
      isCustomerSelfService: true,
    });

    await this.auditService.record({
      actorUserId: params.userId,
      action: 'order.cancelled_by_customer',
      entityType: 'order',
      entityPublicId: cancelled.orderNumber,
      metadata: { reason: cancelled.cancellationReason },
      ipAddress: params.ipAddress,
      requestId: params.requestId,
    });

    return cancelled;
  }

  async adminListOrders(query: AdminOrderListQueryInput): Promise<CommerceOrderListResult> {
    return this.commerceRepo.adminListOrders(query);
  }

  async adminGetOrder(orderNumber: string): Promise<OrderDetailDTO> {
    const found = await this.commerceRepo.findOrderByNumber(orderNumber);
    if (!found) {
      throw ApiError.notFound('Order not found');
    }
    return found.order;
  }

  async adminUpdateStatus(params: {
    orderNumber: string;
    input: AdminUpdateOrderStatusInput;
    actorUserId: number;
    actorRole: string;
    ipAddress?: string;
    requestId?: string;
  }): Promise<OrderDetailDTO> {
    const updated =
      params.input.toStatus === 'cancelled'
        ? await this.commerceRepo.cancelOrderTransactionally({
            orderNumber: params.orderNumber,
            actorUserId: params.actorUserId,
            actorRole: params.actorRole,
            reason: params.input.note ?? null,
            isCustomerSelfService: false,
          })
        : await this.commerceRepo.adminUpdateOrderStatus({
            orderNumber: params.orderNumber,
            toStatus: params.input.toStatus,
            actorUserId: params.actorUserId,
            actorRole: params.actorRole,
            note: params.input.note ?? null,
          });

    await this.auditService.record({
      actorUserId: params.actorUserId,
      action: 'order.status_updated',
      entityType: 'order',
      entityPublicId: updated.orderNumber,
      metadata: { orderStatus: updated.orderStatus, note: params.input.note ?? null },
      ipAddress: params.ipAddress,
      requestId: params.requestId,
    });

    return updated;
  }

  async adminSettleCodPayment(params: {
    orderNumber: string;
    input: AdminSettleCodPaymentInput;
    actorUserId: number;
    actorRole: string;
    ipAddress?: string;
    requestId?: string;
  }): Promise<OrderDetailDTO> {
    const updated = await this.commerceRepo.adminSettleCodPayment({
      orderNumber: params.orderNumber,
      transactionRef: params.input.transactionRef,
      actorUserId: params.actorUserId,
      actorRole: params.actorRole,
      note: params.input.note ?? null,
    });

    await this.auditService.record({
      actorUserId: params.actorUserId,
      action: 'order.cod_payment_settled',
      entityType: 'order',
      entityPublicId: updated.orderNumber,
      metadata: {
        transactionRef: params.input.transactionRef,
        paymentStatus: updated.paymentStatus,
      },
      ipAddress: params.ipAddress,
      requestId: params.requestId,
    });

    return updated;
  }
}
