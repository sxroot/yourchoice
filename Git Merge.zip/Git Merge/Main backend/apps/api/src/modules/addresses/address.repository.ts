import type { BangladeshDivision, CustomerAddressDTO } from '@your-choice/shared-types';
import type { CreateAddressInput, UpdateAddressInput } from '@your-choice/validation';

export interface StoredAddressRecord {
  id: number;
  publicId: string;
  userId: number;
  label: string;
  recipientName: string;
  phone: string;
  division: BangladeshDivision;
  district: string;
  area: string;
  addressLine: string;
  postalCode: string | null;
  isDefault: boolean;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}

export interface CreateAddressRecordParams extends CreateAddressInput {
  publicId: string;
  userId: number;
}

export interface AddressRepository {
  listByUserId(userId: number): Promise<StoredAddressRecord[]>;
  findByPublicIdAndUserId(publicId: string, userId: number): Promise<StoredAddressRecord | null>;
  create(params: CreateAddressRecordParams): Promise<StoredAddressRecord>;
  update(
    publicId: string,
    userId: number,
    input: UpdateAddressInput
  ): Promise<StoredAddressRecord | null>;
  softDelete(publicId: string, userId: number): Promise<boolean>;
}

export function toCustomerAddressDto(record: StoredAddressRecord): CustomerAddressDTO {
  return {
    id: record.publicId,
    label: record.label,
    recipientName: record.recipientName,
    phone: record.phone,
    division: record.division,
    district: record.district,
    area: record.area,
    addressLine: record.addressLine,
    postalCode: record.postalCode,
    isDefault: record.isDefault,
    createdAt: record.createdAt.toISOString(),
    updatedAt: record.updatedAt.toISOString(),
  };
}
