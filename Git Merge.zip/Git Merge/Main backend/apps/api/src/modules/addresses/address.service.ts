import { randomUUID } from 'node:crypto';
import type { CustomerAddressDTO } from '@your-choice/shared-types';
import type { CreateAddressInput, UpdateAddressInput } from '@your-choice/validation';
import { ApiError } from '../../utils/api-error.js';
import { type AddressRepository, toCustomerAddressDto } from './address.repository.js';

export class AddressService {
  constructor(private readonly repository: AddressRepository) {}

  async listAddresses(userId: number): Promise<CustomerAddressDTO[]> {
    const records = await this.repository.listByUserId(userId);
    return records.map(toCustomerAddressDto);
  }

  async createAddress(userId: number, input: CreateAddressInput): Promise<CustomerAddressDTO> {
    const created = await this.repository.create({
      ...input,
      publicId: randomUUID(),
      userId,
    });
    return toCustomerAddressDto(created);
  }

  async updateAddress(
    userId: number,
    addressPublicId: string,
    input: UpdateAddressInput
  ): Promise<CustomerAddressDTO> {
    const updated = await this.repository.update(addressPublicId, userId, input);
    if (!updated) {
      throw ApiError.notFound('Address not found');
    }
    return toCustomerAddressDto(updated);
  }

  async deleteAddress(userId: number, addressPublicId: string): Promise<string> {
    const deleted = await this.repository.softDelete(addressPublicId, userId);
    if (!deleted) {
      throw ApiError.notFound('Address not found');
    }
    return addressPublicId;
  }
}
