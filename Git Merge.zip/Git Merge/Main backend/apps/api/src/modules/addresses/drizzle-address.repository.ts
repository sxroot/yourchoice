import { userAddresses, type UserAddressRow } from '@your-choice/database/schema';
import type { BangladeshDivision } from '@your-choice/shared-types';
import type { UpdateAddressInput } from '@your-choice/validation';
import { and, desc, eq, isNull, ne } from 'drizzle-orm';
import type { AppDatabase } from '../../database/client.js';
import type {
  AddressRepository,
  CreateAddressRecordParams,
  StoredAddressRecord,
} from './address.repository.js';

function mapAddressRow(row: UserAddressRow): StoredAddressRecord {
  return {
    id: row.id,
    publicId: row.publicId,
    userId: row.userId,
    label: row.label,
    recipientName: row.recipientName,
    phone: row.phone,
    division: row.division as BangladeshDivision,
    district: row.district,
    area: row.area,
    addressLine: row.addressLine,
    postalCode: row.postalCode ?? null,
    isDefault: row.isDefault,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
    deletedAt: row.deletedAt ?? null,
  };
}

export class DrizzleAddressRepository implements AddressRepository {
  constructor(private readonly db: AppDatabase) {}

  async listByUserId(userId: number): Promise<StoredAddressRecord[]> {
    const rows = await this.db
      .select()
      .from(userAddresses)
      .where(and(eq(userAddresses.userId, userId), isNull(userAddresses.deletedAt)))
      .orderBy(desc(userAddresses.isDefault), desc(userAddresses.updatedAt));

    return rows.map(mapAddressRow);
  }

  async findByPublicIdAndUserId(
    publicId: string,
    userId: number
  ): Promise<StoredAddressRecord | null> {
    const [row] = await this.db
      .select()
      .from(userAddresses)
      .where(
        and(
          eq(userAddresses.publicId, publicId),
          eq(userAddresses.userId, userId),
          isNull(userAddresses.deletedAt)
        )
      )
      .limit(1);

    return row ? mapAddressRow(row) : null;
  }

  async create(params: CreateAddressRecordParams): Promise<StoredAddressRecord> {
    return this.db.transaction(async (tx) => {
      const existingRows = await tx
        .select({ id: userAddresses.id })
        .from(userAddresses)
        .where(and(eq(userAddresses.userId, params.userId), isNull(userAddresses.deletedAt)))
        .limit(1);

      const shouldBeDefault = params.isDefault || existingRows.length === 0;

      if (shouldBeDefault) {
        await tx
          .update(userAddresses)
          .set({ isDefault: false })
          .where(and(eq(userAddresses.userId, params.userId), isNull(userAddresses.deletedAt)));
      }

      const [inserted] = await tx
        .insert(userAddresses)
        .values({
          publicId: params.publicId,
          userId: params.userId,
          label: params.label,
          recipientName: params.recipientName,
          phone: params.phone,
          division: params.division,
          district: params.district,
          area: params.area,
          addressLine: params.addressLine,
          postalCode: params.postalCode ?? null,
          isDefault: shouldBeDefault,
        })
        .$returningId();

      if (!inserted) {
        throw new Error('Failed to retrieve newly created address ID');
      }

      const [created] = await tx
        .select()
        .from(userAddresses)
        .where(eq(userAddresses.id, inserted.id))
        .limit(1);

      if (!created) {
        throw new Error('Failed to load newly created address record');
      }

      return mapAddressRow(created);
    });
  }

  async update(
    publicId: string,
    userId: number,
    input: UpdateAddressInput
  ): Promise<StoredAddressRecord | null> {
    return this.db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(userAddresses)
        .where(
          and(
            eq(userAddresses.publicId, publicId),
            eq(userAddresses.userId, userId),
            isNull(userAddresses.deletedAt)
          )
        )
        .limit(1);

      if (!existing) {
        return null;
      }

      if (input.isDefault === true) {
        await tx
          .update(userAddresses)
          .set({ isDefault: false })
          .where(
            and(
              eq(userAddresses.userId, userId),
              isNull(userAddresses.deletedAt),
              ne(userAddresses.id, existing.id)
            )
          );
      }

      const patch: Partial<typeof userAddresses.$inferInsert> = {};
      if (input.label !== undefined) patch.label = input.label;
      if (input.recipientName !== undefined) patch.recipientName = input.recipientName;
      if (input.phone !== undefined) patch.phone = input.phone;
      if (input.division !== undefined) patch.division = input.division;
      if (input.district !== undefined) patch.district = input.district;
      if (input.area !== undefined) patch.area = input.area;
      if (input.addressLine !== undefined) patch.addressLine = input.addressLine;
      if (input.postalCode !== undefined) patch.postalCode = input.postalCode;
      if (input.isDefault !== undefined) patch.isDefault = input.isDefault;

      await tx.update(userAddresses).set(patch).where(eq(userAddresses.id, existing.id));

      const [updated] = await tx
        .select()
        .from(userAddresses)
        .where(eq(userAddresses.id, existing.id))
        .limit(1);

      return updated ? mapAddressRow(updated) : null;
    });
  }

  async softDelete(publicId: string, userId: number): Promise<boolean> {
    return this.db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(userAddresses)
        .where(
          and(
            eq(userAddresses.publicId, publicId),
            eq(userAddresses.userId, userId),
            isNull(userAddresses.deletedAt)
          )
        )
        .limit(1);

      if (!existing) {
        return false;
      }

      await tx
        .update(userAddresses)
        .set({ deletedAt: new Date(), isDefault: false })
        .where(eq(userAddresses.id, existing.id));

      if (existing.isDefault) {
        const [replacement] = await tx
          .select({ id: userAddresses.id })
          .from(userAddresses)
          .where(and(eq(userAddresses.userId, userId), isNull(userAddresses.deletedAt)))
          .orderBy(desc(userAddresses.updatedAt))
          .limit(1);

        if (replacement) {
          await tx
            .update(userAddresses)
            .set({ isDefault: true })
            .where(eq(userAddresses.id, replacement.id));
        }
      }

      return true;
    });
  }
}
