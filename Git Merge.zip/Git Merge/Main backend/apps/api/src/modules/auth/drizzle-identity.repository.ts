import {
  type AuthUserDTO,
  PERMISSION_CODES,
  type PermissionCode,
  USER_ROLES,
  type UserRole,
} from '@your-choice/shared-types';
import type { UpdateProfileInput } from '@your-choice/validation';
import {
  permissions,
  rolePermissions,
  roles,
  sessions,
  userProfiles,
  userRoles,
  users,
} from '@your-choice/database/schema';
import { and, desc, eq, gt, inArray, isNull } from 'drizzle-orm';
import type { AppDatabase } from '../../database/client.js';
import { ApiError, isDuplicateEntryError } from '../../utils/api-error.js';
import {
  type CreateSessionParams,
  type CreateUserParams,
  type IdentityRepository,
  type SessionWithUserRecord,
  type StoredSessionRecord,
  type StoredUserRecord,
  toAuthUserDto,
} from './identity.repository.js';

const KNOWN_ROLE_SET = new Set<string>(USER_ROLES);
const KNOWN_PERMISSION_SET = new Set<string>(PERMISSION_CODES);

function normalizeRoles(rawCodes: string[]): UserRole[] {
  const valid = rawCodes.filter((code): code is UserRole => KNOWN_ROLE_SET.has(code));
  return Array.from(new Set(valid)).sort();
}

function normalizePermissions(rawCodes: string[]): PermissionCode[] {
  const valid = rawCodes.filter((code): code is PermissionCode => KNOWN_PERMISSION_SET.has(code));
  return Array.from(new Set(valid)).sort();
}

export class DrizzleIdentityRepository implements IdentityRepository {
  constructor(private readonly db: AppDatabase) {}

  private async hydrateUserRecord(userRow: typeof users.$inferSelect): Promise<StoredUserRecord> {
    const [profileRow] = await this.db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userRow.id))
      .limit(1);

    const assignedRoleRows = await this.db
      .select({
        roleId: roles.id,
        roleCode: roles.code,
      })
      .from(userRoles)
      .innerJoin(roles, eq(userRoles.roleId, roles.id))
      .where(eq(userRoles.userId, userRow.id));

    const assignedRoleIds = assignedRoleRows.map((row) => row.roleId);
    const roleCodes = normalizeRoles(assignedRoleRows.map((row) => row.roleCode));

    let permissionCodes: PermissionCode[] = [];
    if (assignedRoleIds.length > 0) {
      const permissionRows = await this.db
        .select({
          code: permissions.code,
        })
        .from(rolePermissions)
        .innerJoin(permissions, eq(rolePermissions.permissionId, permissions.id))
        .where(inArray(rolePermissions.roleId, assignedRoleIds));

      permissionCodes = normalizePermissions(permissionRows.map((row) => row.code));
    }

    return {
      id: userRow.id,
      publicId: userRow.publicId,
      email: userRow.email,
      passwordHash: userRow.passwordHash,
      fullName: profileRow?.fullName ?? 'YOUR CHOICE Member',
      phone: profileRow?.phone ?? null,
      preferredLocale: profileRow?.preferredLocale ?? 'en',
      status: userRow.status,
      emailVerifiedAt: userRow.emailVerifiedAt ?? null,
      lastLoginAt: userRow.lastLoginAt ?? null,
      createdAt: userRow.createdAt,
      updatedAt: userRow.updatedAt,
      deletedAt: userRow.deletedAt ?? null,
      roles: roleCodes,
      permissions: permissionCodes,
    };
  }

  async findUserByEmail(email: string): Promise<StoredUserRecord | null> {
    const [userRow] = await this.db
      .select()
      .from(users)
      .where(and(eq(users.email, email.toLowerCase()), isNull(users.deletedAt)))
      .limit(1);

    if (!userRow) {
      return null;
    }

    return this.hydrateUserRecord(userRow);
  }

  async findUserByPublicId(publicId: string): Promise<StoredUserRecord | null> {
    const [userRow] = await this.db
      .select()
      .from(users)
      .where(and(eq(users.publicId, publicId), isNull(users.deletedAt)))
      .limit(1);

    if (!userRow) {
      return null;
    }

    return this.hydrateUserRecord(userRow);
  }

  async createUser(params: CreateUserParams): Promise<StoredUserRecord> {
    const initialRoleCode = params.initialRoleCode ?? 'customer';

    try {
      const createdUserId = await this.db.transaction(async (tx) => {
        const [roleRow] = await tx
          .select()
          .from(roles)
          .where(eq(roles.code, initialRoleCode))
          .limit(1);

        if (!roleRow) {
          throw new ApiError(
            500,
            'RBAC_NOT_SEEDED',
            'RBAC role catalog has not been initialized. Run pnpm db:seed.'
          );
        }

        const [insertResult] = await tx.insert(users).values({
          publicId: params.publicId,
          email: params.email.toLowerCase(),
          passwordHash: params.passwordHash,
          status: 'active',
        });

        const userId = Number(insertResult.insertId);

        await tx.insert(userProfiles).values({
          userId,
          fullName: params.fullName,
          phone: params.phone,
          preferredLocale: params.preferredLocale,
        });

        await tx.insert(userRoles).values({
          userId,
          roleId: roleRow.id,
          assignedByUserId: userId,
        });

        return userId;
      });

      const [userRow] = await this.db
        .select()
        .from(users)
        .where(eq(users.id, createdUserId))
        .limit(1);
      if (!userRow) {
        throw ApiError.internal('Created user could not be reloaded');
      }

      return this.hydrateUserRecord(userRow);
    } catch (error: unknown) {
      if (isDuplicateEntryError(error)) {
        throw ApiError.conflict(
          'EMAIL_ALREADY_REGISTERED',
          'An account with this email address already exists'
        );
      }
      throw error;
    }
  }

  async createSession(params: CreateSessionParams): Promise<StoredSessionRecord> {
    const [result] = await this.db.insert(sessions).values({
      publicId: params.publicId,
      userId: params.userId,
      tokenHash: params.tokenHash,
      ipAddress: params.ipAddress,
      userAgent: params.userAgent,
      expiresAt: params.expiresAt,
      lastSeenAt: new Date(),
    });

    const sessionId = Number(result.insertId);
    const [row] = await this.db.select().from(sessions).where(eq(sessions.id, sessionId)).limit(1);

    if (!row) {
      throw ApiError.internal('Created session could not be reloaded');
    }

    return {
      id: row.id,
      publicId: row.publicId,
      userId: row.userId,
      tokenHash: row.tokenHash,
      ipAddress: row.ipAddress ?? null,
      userAgent: row.userAgent ?? null,
      expiresAt: row.expiresAt,
      lastSeenAt: row.lastSeenAt,
      revokedAt: row.revokedAt ?? null,
      createdAt: row.createdAt,
    };
  }

  async findActiveSessionByTokenHash(
    tokenHash: string,
    now: Date
  ): Promise<SessionWithUserRecord | null> {
    const [row] = await this.db
      .select({
        session: sessions,
        user: users,
      })
      .from(sessions)
      .innerJoin(users, eq(sessions.userId, users.id))
      .where(
        and(
          eq(sessions.tokenHash, tokenHash),
          isNull(sessions.revokedAt),
          gt(sessions.expiresAt, now),
          isNull(users.deletedAt)
        )
      )
      .limit(1);

    if (!row) {
      return null;
    }

    const hydratedUser = await this.hydrateUserRecord(row.user);

    return {
      session: {
        id: row.session.id,
        publicId: row.session.publicId,
        userId: row.session.userId,
        tokenHash: row.session.tokenHash,
        ipAddress: row.session.ipAddress ?? null,
        userAgent: row.session.userAgent ?? null,
        expiresAt: row.session.expiresAt,
        lastSeenAt: row.session.lastSeenAt,
        revokedAt: row.session.revokedAt ?? null,
        createdAt: row.session.createdAt,
      },
      user: hydratedUser,
    };
  }

  async touchSession(
    sessionId: number,
    updates: { lastSeenAt: Date; expiresAt?: Date }
  ): Promise<void> {
    await this.db
      .update(sessions)
      .set({
        lastSeenAt: updates.lastSeenAt,
        ...(updates.expiresAt ? { expiresAt: updates.expiresAt } : {}),
      })
      .where(eq(sessions.id, sessionId));
  }

  async revokeSessionById(sessionId: number, revokedAt: Date): Promise<void> {
    await this.db
      .update(sessions)
      .set({ revokedAt })
      .where(and(eq(sessions.id, sessionId), isNull(sessions.revokedAt)));
  }

  async revokeAllUserSessions(userId: number, revokedAt: Date): Promise<void> {
    await this.db
      .update(sessions)
      .set({ revokedAt })
      .where(and(eq(sessions.userId, userId), isNull(sessions.revokedAt)));
  }

  async updateLastLoginAt(userId: number, timestamp: Date): Promise<void> {
    await this.db.update(users).set({ lastLoginAt: timestamp }).where(eq(users.id, userId));
  }

  async updateUserProfile(userId: number, patch: UpdateProfileInput): Promise<StoredUserRecord> {
    await this.db
      .update(userProfiles)
      .set({
        ...(patch.fullName !== undefined ? { fullName: patch.fullName } : {}),
        ...(patch.phone !== undefined ? { phone: patch.phone } : {}),
        ...(patch.preferredLocale !== undefined ? { preferredLocale: patch.preferredLocale } : {}),
      })
      .where(eq(userProfiles.userId, userId));

    const [userRow] = await this.db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!userRow) {
      throw ApiError.notFound('User account not found');
    }

    return this.hydrateUserRecord(userRow);
  }

  async replaceUserRoles(
    userId: number,
    roleCodes: UserRole[],
    assignedByUserId: number
  ): Promise<StoredUserRecord> {
    await this.db.transaction(async (tx) => {
      const targetRoleRows = await tx.select().from(roles).where(inArray(roles.code, roleCodes));

      if (targetRoleRows.length !== roleCodes.length) {
        throw new ApiError(400, 'INVALID_ROLE_CODES', 'One or more requested roles do not exist');
      }

      await tx.delete(userRoles).where(eq(userRoles.userId, userId));
      await tx.insert(userRoles).values(
        targetRoleRows.map((roleRow) => ({
          userId,
          roleId: roleRow.id,
          assignedByUserId,
        }))
      );
    });

    const [userRow] = await this.db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!userRow) {
      throw ApiError.notFound('User account not found');
    }

    return this.hydrateUserRecord(userRow);
  }

  async listUsersSummary(limit = 25): Promise<AuthUserDTO[]> {
    const userRows = await this.db
      .select()
      .from(users)
      .where(isNull(users.deletedAt))
      .orderBy(desc(users.createdAt))
      .limit(limit);

    const hydrated = await Promise.all(userRows.map((row) => this.hydrateUserRecord(row)));
    return hydrated.map(toAuthUserDto);
  }
}
