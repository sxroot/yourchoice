import type {
  AuthSessionDTO,
  AuthUserDTO,
  PermissionCode,
  PreferredLocale,
  UserRole,
  UserStatus,
} from '@your-choice/shared-types';
import type { UpdateProfileInput } from '@your-choice/validation';

export interface StoredUserRecord {
  id: number;
  publicId: string;
  email: string;
  passwordHash: string;
  fullName: string;
  phone: string | null;
  preferredLocale: PreferredLocale;
  status: UserStatus;
  emailVerifiedAt: Date | null;
  lastLoginAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
  roles: UserRole[];
  permissions: PermissionCode[];
}

export interface StoredSessionRecord {
  id: number;
  publicId: string;
  userId: number;
  tokenHash: string;
  ipAddress: string | null;
  userAgent: string | null;
  expiresAt: Date;
  lastSeenAt: Date;
  revokedAt: Date | null;
  createdAt: Date;
}

export interface CreateUserParams {
  publicId: string;
  email: string;
  passwordHash: string;
  fullName: string;
  phone: string | null;
  preferredLocale: PreferredLocale;
  initialRoleCode?: UserRole;
}

export interface CreateSessionParams {
  publicId: string;
  userId: number;
  tokenHash: string;
  ipAddress: string | null;
  userAgent: string | null;
  expiresAt: Date;
}

export interface SessionWithUserRecord {
  session: StoredSessionRecord;
  user: StoredUserRecord;
}

export interface IdentityRepository {
  findUserByEmail(email: string): Promise<StoredUserRecord | null>;
  findUserByPublicId(publicId: string): Promise<StoredUserRecord | null>;
  createUser(params: CreateUserParams): Promise<StoredUserRecord>;
  createSession(params: CreateSessionParams): Promise<StoredSessionRecord>;
  findActiveSessionByTokenHash(tokenHash: string, now: Date): Promise<SessionWithUserRecord | null>;
  touchSession(sessionId: number, updates: { lastSeenAt: Date; expiresAt?: Date }): Promise<void>;
  revokeSessionById(sessionId: number, revokedAt: Date): Promise<void>;
  revokeAllUserSessions(userId: number, revokedAt: Date): Promise<void>;
  updateLastLoginAt(userId: number, timestamp: Date): Promise<void>;
  updateUserProfile(userId: number, patch: UpdateProfileInput): Promise<StoredUserRecord>;
  replaceUserRoles(
    userId: number,
    roles: UserRole[],
    assignedByUserId: number
  ): Promise<StoredUserRecord>;
  listUsersSummary(limit?: number): Promise<AuthUserDTO[]>;
}

export function toAuthUserDto(record: StoredUserRecord): AuthUserDTO {
  return {
    id: record.publicId,
    email: record.email,
    fullName: record.fullName,
    phone: record.phone,
    preferredLocale: record.preferredLocale,
    status: record.status,
    emailVerified: record.emailVerifiedAt !== null,
    roles: [...record.roles],
    permissions: [...record.permissions],
    createdAt: record.createdAt.toISOString(),
  };
}

export function toAuthSessionDto(record: StoredSessionRecord): AuthSessionDTO {
  return {
    id: record.publicId,
    expiresAt: record.expiresAt.toISOString(),
    lastSeenAt: record.lastSeenAt.toISOString(),
  };
}
