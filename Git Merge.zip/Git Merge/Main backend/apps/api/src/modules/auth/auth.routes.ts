import type {
  AuthMeResponseData,
  AuthSuccessData,
  CsrfTokenResponseData,
  LogoutResponseData,
} from '@your-choice/shared-types';
import { loginSchema, registerRequestSchema } from '@your-choice/validation';
import { type Request, type Response, Router } from 'express';
import type { ApiEnv } from '../../config/env.js';
import { getAuthContext, requireAuth } from '../../middleware/auth.js';
import { ensureCsrfToken } from '../../middleware/csrf.js';
import { createAuthRateLimiters, type AuthRateLimitConfig } from '../../middleware/rate-limit.js';
import { validateRequest } from '../../middleware/validate.js';
import { sendSuccess } from '../../utils/api-response.js';
import {
  buildClearCartCookieOptions,
  buildClearSessionCookieOptions,
  buildSessionCookieOptions,
  parseCookieHeader,
} from '../../utils/cookies.js';
import type { CartService } from '../cart/cart.service.js';
import type { AuthService } from './auth.service.js';

function getClientMetadata(req: Request) {
  return {
    ipAddress: req.ip ?? null,
    userAgent: req.get('user-agent') ?? null,
  };
}

async function mergeGuestCartIfPresent(
  req: Request,
  res: Response,
  env: ApiEnv,
  userId: number,
  cartService?: CartService
): Promise<void> {
  if (!cartService) {
    return;
  }

  const cookies = parseCookieHeader(req.headers.cookie);
  const rawGuestCartToken = cookies[env.CART_COOKIE_NAME] ?? null;
  if (!rawGuestCartToken) {
    return;
  }

  await cartService.mergeGuestCartForAuthenticatedUser(rawGuestCartToken, userId);
  res.clearCookie(env.CART_COOKIE_NAME, buildClearCartCookieOptions(env));
}

export function createAuthRouter(
  authService: AuthService,
  env: ApiEnv,
  rateLimitConfig?: AuthRateLimitConfig,
  cartService?: CartService
): Router {
  const router = Router();
  const { strictAuthLimiter, generalAuthLimiter } = createAuthRateLimiters(rateLimitConfig);

  router.get('/csrf', generalAuthLimiter, (req, res) => {
    const csrfToken = ensureCsrfToken(req, res, env);
    sendSuccess<CsrfTokenResponseData>(res, { csrfToken });
  });

  router.get('/me', generalAuthLimiter, (req, res) => {
    const csrfToken = ensureCsrfToken(req, res, env);
    const auth = getAuthContext(res);
    if (!auth) {
      sendSuccess<AuthMeResponseData>(res, {
        authenticated: false,
        user: null,
        session: null,
        csrfToken,
      });
      return;
    }

    sendSuccess<AuthMeResponseData>(res, {
      authenticated: true,
      user: auth.user,
      session: auth.session,
      csrfToken,
    });
  });

  router.post(
    '/register',
    strictAuthLimiter,
    validateRequest({ body: registerRequestSchema }),
    async (req, res) => {
      const result = await authService.register(req.body, getClientMetadata(req));
      await mergeGuestCartIfPresent(req, res, env, result.internalUserId, cartService);
      res.cookie(
        env.SESSION_COOKIE_NAME,
        result.rawSessionToken,
        buildSessionCookieOptions(env, result.expiresAt)
      );
      const csrfToken = ensureCsrfToken(req, res, env);

      sendSuccess<AuthSuccessData>(
        res,
        {
          user: result.user,
          session: result.session,
          csrfToken,
        },
        201
      );
    }
  );

  router.post(
    '/login',
    strictAuthLimiter,
    validateRequest({ body: loginSchema }),
    async (req, res) => {
      const result = await authService.login(req.body, getClientMetadata(req));
      await mergeGuestCartIfPresent(req, res, env, result.internalUserId, cartService);
      res.cookie(
        env.SESSION_COOKIE_NAME,
        result.rawSessionToken,
        buildSessionCookieOptions(env, result.expiresAt)
      );
      const csrfToken = ensureCsrfToken(req, res, env);

      sendSuccess<AuthSuccessData>(res, {
        user: result.user,
        session: result.session,
        csrfToken,
      });
    }
  );

  router.post('/logout', generalAuthLimiter, requireAuth, async (_req, res) => {
    const auth = getAuthContext(res);
    if (auth) {
      await authService.logoutSession(auth.internalSessionId);
    }
    res.clearCookie(env.SESSION_COOKIE_NAME, buildClearSessionCookieOptions(env));
    sendSuccess<LogoutResponseData>(res, { revoked: true });
  });

  router.post('/logout-all', generalAuthLimiter, requireAuth, async (_req, res) => {
    const auth = getAuthContext(res);
    if (auth) {
      await authService.logoutAllSessions(auth.internalUserId);
    }
    res.clearCookie(env.SESSION_COOKIE_NAME, buildClearSessionCookieOptions(env));
    sendSuccess<LogoutResponseData>(res, { revoked: true });
  });

  return router;
}
