import { argon2, randomBytes, timingSafeEqual } from 'node:crypto';

const DEFAULT_MEMORY_KIB = 19_456; // 19 MiB (OWASP Argon2id baseline)
const DEFAULT_PASSES = 2;
const DEFAULT_PARALLELISM = 1;
const DEFAULT_SALT_BYTES = 16;
const DEFAULT_TAG_BYTES = 32;

const ARGON2_VERSION = 19;

let cachedDummyHash: string | null = null;

function toBase64NoPad(buffer: Buffer): string {
  return buffer.toString('base64').replace(/=+$/, '');
}

function fromBase64NoPad(encoded: string): Buffer | null {
  if (!/^[A-Za-z0-9+/]+$/.test(encoded)) {
    return null;
  }
  const padLen = (4 - (encoded.length % 4)) % 4;
  return Buffer.from(encoded + '='.repeat(padLen), 'base64');
}

function deriveArgon2idKey(params: {
  password: string;
  nonce: Buffer;
  memory: number;
  passes: number;
  parallelism: number;
  tagLength: number;
}): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    argon2(
      'argon2id',
      {
        message: params.password,
        nonce: params.nonce,
        memory: params.memory,
        passes: params.passes,
        parallelism: params.parallelism,
        tagLength: params.tagLength,
      },
      (error, derivedKey) => {
        if (error) {
          reject(error);
          return;
        }
        resolve(derivedKey);
      }
    );
  });
}

/**
 * Hashes a user password with OWASP-recommended Argon2id (`RFC 9106`) via Node.js 24 native `node:crypto.argon2`
 * and formats it using the standard PHC string representation.
 */
export async function hashPassword(plainPassword: string): Promise<string> {
  const salt = randomBytes(DEFAULT_SALT_BYTES);
  const derivedKey = await deriveArgon2idKey({
    password: plainPassword,
    nonce: salt,
    memory: DEFAULT_MEMORY_KIB,
    passes: DEFAULT_PASSES,
    parallelism: DEFAULT_PARALLELISM,
    tagLength: DEFAULT_TAG_BYTES,
  });

  return `$argon2id$v=${ARGON2_VERSION}$m=${DEFAULT_MEMORY_KIB},t=${DEFAULT_PASSES},p=${DEFAULT_PARALLELISM}$${toBase64NoPad(salt)}$${toBase64NoPad(derivedKey)}`;
}

interface ParsedPhcArgon2id {
  memory: number;
  passes: number;
  parallelism: number;
  salt: Buffer;
  expectedTag: Buffer;
}

function parsePhcArgon2id(encoded: string): ParsedPhcArgon2id | null {
  const parts = encoded.split('$');
  if (parts.length !== 6 || parts[0] !== '' || parts[1] !== 'argon2id') {
    return null;
  }

  if (parts[2] !== `v=${ARGON2_VERSION}`) {
    return null;
  }

  const paramMatch = /^m=(\d+),t=(\d+),p=(\d+)$/.exec(parts[3] ?? '');
  if (!paramMatch) {
    return null;
  }

  const memory = Number(paramMatch[1]);
  const passes = Number(paramMatch[2]);
  const parallelism = Number(paramMatch[3]);
  if (
    !Number.isInteger(memory) ||
    memory < 4_096 ||
    memory > 262_144 ||
    !Number.isInteger(passes) ||
    passes < 1 ||
    passes > 16 ||
    !Number.isInteger(parallelism) ||
    parallelism < 1 ||
    parallelism > 8
  ) {
    return null;
  }

  const salt = fromBase64NoPad(parts[4] ?? '');
  const expectedTag = fromBase64NoPad(parts[5] ?? '');
  if (!salt || !expectedTag || salt.length < 8 || expectedTag.length < 16) {
    return null;
  }

  return {
    memory,
    passes,
    parallelism,
    salt,
    expectedTag,
  };
}

/**
 * Verifies a candidate password against a stored PHC Argon2id hash in constant time.
 */
export async function verifyPassword(
  storedHash: string,
  candidatePassword: string
): Promise<boolean> {
  const parsed = parsePhcArgon2id(storedHash);
  if (!parsed) {
    return false;
  }

  try {
    const derivedKey = await deriveArgon2idKey({
      password: candidatePassword,
      nonce: parsed.salt,
      memory: parsed.memory,
      passes: parsed.passes,
      parallelism: parsed.parallelism,
      tagLength: parsed.expectedTag.length,
    });

    if (derivedKey.length !== parsed.expectedTag.length) {
      return false;
    }

    return timingSafeEqual(derivedKey, parsed.expectedTag);
  } catch {
    return false;
  }
}

/**
 * Performs a constant-cost dummy Argon2id check when no user matches an email on login,
 * preventing timing-based account enumeration.
 */
export async function verifyDummyPassword(candidatePassword: string): Promise<void> {
  if (!cachedDummyHash) {
    cachedDummyHash = await hashPassword('your-choice-timing-equalizer-password');
  }
  await verifyPassword(cachedDummyHash, candidatePassword);
}
