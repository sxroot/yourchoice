import { randomUUID } from 'node:crypto';
import type { AuthSessionDTO, AuthUserDTO, UserRole } from '@your-choice/shared-types';
import type { LoginInput, RegisterRequestInput, UpdateProfileInput } from '@your-choice/validation';
import type { ApiEnv } from '../../config/env.js';
import { ApiError } from '../../utils/api-error.js';
import { type IdentityRepository, toAuthSessionDto, toAuthUserDto } from './identity.repository.js';
import { hashPassword, verifyDummyPassword, verifyPassword } from './password.js';
import { generateOpaqueToken, hashSessionToken } from './tokens.js';

export interface RequestClientMetadata {
  ipAddress: string | null;
  userAgent: string | null;
}

export interface AuthenticatedContext {
  internalUserId: number;
  internalSessionId: number;
  user: AuthUserDTO;
  session: AuthSessionDTO;
  renewedExpiresAt: Date | null;
}

export interface LoginOrRegisterResult {
  internalUserId: number;
  user: AuthUserDTO;
  session: AuthSessionDTO;
  rawSessionToken: string;
  expiresAt: Date;
}

const SHORT_SESSION_HOURS = 24;
const LAST_SEEN_TOUCH_THROTTLE_MS = 5 * 60 * 1000;

export class AuthService {
  constructor(
    private readonly repository: IdentityRepository,
    private readonly env: ApiEnv
  ) {}

  private computeSessionTtlMs(rememberMe: boolean): number {
    const maxHours = this.env.SESSION_TTL_HOURS;
    const effectiveHours = rememberMe ? maxHours : Math.min(maxHours, SHORT_SESSION_HOURS);
    return effectiveHours * 60 * 60 * 1000;
  }

  private async issueSession(
    userId: number,
    meta: RequestClientMetadata,
    ttlMs: number
  ): Promise<{ rawToken: string; session: AuthSessionDTO; expiresAt: Date }> {
    const rawToken = generateOpaqueToken(32);
    const tokenHash = hashSessionToken(rawToken);
    const expiresAt = new Date(Date.now() + ttlMs);

    const created = await this.repository.createSession({
      publicId: randomUUID(),
      userId,
      tokenHash,
      ipAddress: meta.ipAddress ? meta.ipAddress.slice(0, 64) : null,
      userAgent: meta.userAgent ? meta.userAgent.slice(0, 512) : null,
      expiresAt,
    });

    return {
      rawToken,
      session: toAuthSessionDto(created),
      expiresAt,
    };
  }

  async register(
    input: RegisterRequestInput,
    meta: RequestClientMetadata
  ): Promise<LoginOrRegisterResult> {
    const normalizedEmail = input.email.toLowerCase();
    const existing = await this.repository.findUserByEmail(normalizedEmail);
    if (existing) {
      throw ApiError.conflict(
        'EMAIL_ALREADY_REGISTERED',
        'An account with this email address already exists'
      );
    }

    const passwordHash = await hashPassword(input.password);
    const createdUser = await this.repository.createUser({
      publicId: randomUUID(),
      email: normalizedEmail,
      passwordHash,
      fullName: input.fullName,
      phone: input.phone ?? null,
      preferredLocale: input.preferredLocale ?? 'en',
      initialRoleCode: 'customer',
    });

    const ttlMs = this.computeSessionTtlMs(true);
    const issued = await this.issueSession(createdUser.id, meta, ttlMs);

    return {
      internalUserId: createdUser.id,
      user: toAuthUserDto(createdUser),
      session: issued.session,
      rawSessionToken: issued.rawToken,
      expiresAt: issued.expiresAt,
    };
  }

  async login(input: LoginInput, meta: RequestClientMetadata): Promise<LoginOrRegisterResult> {
    const normalizedEmail = input.email.toLowerCase();
    const userRecord = await this.repository.findUserByEmail(normalizedEmail);

    if (!userRecord) {
      await verifyDummyPassword(input.password);
      throw new ApiError(401, 'INVALID_CREDENTIALS', 'Invalid email or password');
    }

    const passwordMatches = await verifyPassword(userRecord.passwordHash, input.password);
    if (!passwordMatches) {
      throw new ApiError(401, 'INVALID_CREDENTIALS', 'Invalid email or password');
    }

    if (userRecord.status === 'suspended') {
      throw new ApiError(
        403,
        'ACCOUNT_SUSPENDED',
        'This account is suspended. Contact YOUR CHOICE support for assistance.'
      );
    }

    if (userRecord.status === 'deleted' || userRecord.deletedAt !== null) {
      throw new ApiError(401, 'INVALID_CREDENTIALS', 'Invalid email or password');
    }

    const now = new Date();
    await this.repository.updateLastLoginAt(userRecord.id, now);

    const ttlMs = this.computeSessionTtlMs(input.rememberMe ?? true);
    const issued = await this.issueSession(userRecord.id, meta, ttlMs);

    return {
      internalUserId: userRecord.id,
      user: toAuthUserDto(userRecord),
      session: issued.session,
      rawSessionToken: issued.rawToken,
      expiresAt: issued.expiresAt,
    };
  }

  async authenticateSession(
    rawToken: string,
    now = new Date()
  ): Promise<AuthenticatedContext | null> {
    if (!rawToken || rawToken.length < 16) {
      return null;
    }

    const tokenHash = hashSessionToken(rawToken);
    const found = await this.repository.findActiveSessionByTokenHash(tokenHash, now);
    if (!found) {
      return null;
    }

    if (found.user.status !== 'active' || found.user.deletedAt !== null) {
      await this.repository.revokeSessionById(found.session.id, now);
      return null;
    }

    const maxTtlMs = this.env.SESSION_TTL_HOURS * 60 * 60 * 1000;
    const remainingMs = found.session.expiresAt.getTime() - now.getTime();
    const shouldRenewExpiry = remainingMs < maxTtlMs * 0.5;
    const shouldTouchLastSeen =
      now.getTime() - found.session.lastSeenAt.getTime() >= LAST_SEEN_TOUCH_THROTTLE_MS;

    let effectiveSession = found.session;
    let renewedExpiresAt: Date | null = null;

    if (shouldRenewExpiry || shouldTouchLastSeen) {
      renewedExpiresAt = shouldRenewExpiry ? new Date(now.getTime() + maxTtlMs) : null;
      await this.repository.touchSession(found.session.id, {
        lastSeenAt: now,
        ...(renewedExpiresAt ? { expiresAt: renewedExpiresAt } : {}),
      });

      effectiveSession = {
        ...found.session,
        lastSeenAt: now,
        ...(renewedExpiresAt ? { expiresAt: renewedExpiresAt } : {}),
      };
    }

    return {
      internalUserId: found.user.id,
      internalSessionId: found.session.id,
      user: toAuthUserDto(found.user),
      session: toAuthSessionDto(effectiveSession),
      renewedExpiresAt,
    };
  }

  async logoutSession(internalSessionId: number): Promise<void> {
    await this.repository.revokeSessionById(internalSessionId, new Date());
  }

  async logoutAllSessions(internalUserId: number): Promise<void> {
    await this.repository.revokeAllUserSessions(internalUserId, new Date());
  }

  async getUserByPublicId(publicId: string): Promise<AuthUserDTO> {
    const found = await this.repository.findUserByPublicId(publicId);
    if (!found || found.deletedAt !== null) {
      throw ApiError.notFound('User account not found');
    }
    return toAuthUserDto(found);
  }

  async updateOwnProfile(internalUserId: number, patch: UpdateProfileInput): Promise<AuthUserDTO> {
    const updated = await this.repository.updateUserProfile(internalUserId, patch);
    return toAuthUserDto(updated);
  }

  async assignUserRoles(
    targetPublicId: string,
    roles: UserRole[],
    actorInternalUserId: number
  ): Promise<AuthUserDTO> {
    const target = await this.repository.findUserByPublicId(targetPublicId);
    if (!target || target.deletedAt !== null) {
      throw ApiError.notFound('Target user account not found');
    }

    if (target.id === actorInternalUserId && !roles.includes('super_admin')) {
      throw ApiError.badRequest('Super administrators cannot remove their own super_admin role');
    }

    const updated = await this.repository.replaceUserRoles(target.id, roles, actorInternalUserId);
    return toAuthUserDto(updated);
  }

  async listUsersForAdmin(limit = 25): Promise<AuthUserDTO[]> {
    return this.repository.listUsersSummary(limit);
  }
}
