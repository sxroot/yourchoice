import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

/**
 * Generates a high-entropy 256-bit opaque token encoded as base64url.
 */
export function generateOpaqueToken(byteLength = 32): string {
  return randomBytes(byteLength).toString('base64url');
}

/**
 * Computes deterministic SHA-256 hex digest persisted in `sessions.token_hash`.
 */
export function hashSessionToken(rawToken: string): string {
  return createHash('sha256').update(rawToken, 'utf8').digest('hex');
}

function signCsrfNonce(nonce: string, secret: string): string {
  return createHmac('sha256', secret).update(`yc_csrf:${nonce}`, 'utf8').digest('base64url');
}

/**
 * Creates an HMAC-signed CSRF double-submit token tied to `SESSION_SECRET`.
 */
export function createSignedCsrfToken(secret: string): string {
  const nonce = randomBytes(16).toString('base64url');
  const signature = signCsrfNonce(nonce, secret);
  return `${nonce}.${signature}`;
}

/**
 * Verifies the signature structure of a CSRF token using timing-safe comparison.
 */
export function verifySignedCsrfToken(token: string, secret: string): boolean {
  const dotIndex = token.indexOf('.');
  if (dotIndex <= 0 || dotIndex === token.length - 1) {
    return false;
  }

  const nonce = token.slice(0, dotIndex);
  const signature = token.slice(dotIndex + 1);
  if (!nonce || !signature) {
    return false;
  }

  const expectedSignature = signCsrfNonce(nonce, secret);
  const providedBuf = Buffer.from(signature, 'utf8');
  const expectedBuf = Buffer.from(expectedSignature, 'utf8');

  if (providedBuf.length !== expectedBuf.length) {
    return false;
  }

  return timingSafeEqual(providedBuf, expectedBuf);
}

/**
 * Timing-safe UTF-8 string comparison for double-submit cookie vs header tokens.
 */
export function safeEqualStrings(left: string, right: string): boolean {
  const leftBuf = Buffer.from(left, 'utf8');
  const rightBuf = Buffer.from(right, 'utf8');
  if (leftBuf.length !== rightBuf.length) {
    return false;
  }
  return timingSafeEqual(leftBuf, rightBuf);
}
