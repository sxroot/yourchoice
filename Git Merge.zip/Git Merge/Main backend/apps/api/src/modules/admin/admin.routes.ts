import type { AuthUserDTO } from '@your-choice/shared-types';
import { updateUserRolesSchema, userPublicIdParamSchema } from '@your-choice/validation';
import { Router } from 'express';
import { requireAuthContext, requirePermissions, requireRoles } from '../../middleware/auth.js';
import { validateRequest } from '../../middleware/validate.js';
import { sendSuccess } from '../../utils/api-response.js';
import type { AuthService } from '../auth/auth.service.js';

export function createAdminRouter(authService: AuthService): Router {
  const router = Router();

  router.get(
    '/overview',
    requireRoles('admin', 'super_admin'),
    requirePermissions('users:read'),
    async (_req, res) => {
      const auth = requireAuthContext(res);
      const recentUsers = await authService.listUsersForAdmin(20);
      sendSuccess(res, {
        actorId: auth.user.id,
        actorRoles: auth.user.roles,
        userCountSampled: recentUsers.length,
        users: recentUsers,
      });
    }
  );

  router.patch(
    '/users/:userPublicId/roles',
    requireRoles('super_admin'),
    requirePermissions('roles:manage'),
    validateRequest({
      params: userPublicIdParamSchema,
      body: updateUserRolesSchema,
    }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const updatedUser = await authService.assignUserRoles(
        String(req.params.userPublicId),
        req.body.roles,
        auth.internalUserId
      );
      sendSuccess<{ user: AuthUserDTO }>(res, { user: updatedUser });
    }
  );

  return router;
}
