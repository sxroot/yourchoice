import crypto from 'node:crypto';
import type {
  CanonicalDesignDocument,
  CanonicalDesignObject,
  CartDTO,
  CartItemCustomizationDTO,
  DesignAssetDTO,
  DesignDetailDTO,
  DesignPrintExportDTO,
  DesignSummaryDTO,
  OrderItemProductionSpecDTO,
  PaginationMeta,
  PrintAreaSurfaceKey,
  ProductDetailDTO,
  ProductPrintAreaDTO,
} from '@your-choice/shared-types';
import { decimalToMinorUnits, minorUnitsToDecimal } from '@your-choice/shared-utils';
import {
  type AddDesignToCartInput,
  type CreateDesignInput,
  type UpdateDesignInput,
  validateDesignDocumentForPrint,
} from '@your-choice/validation';
import { fileTypeFromBuffer } from 'file-type';
import sharp from 'sharp';
import type { ApiEnv } from '../../config/env.js';
import { ApiError } from '../../utils/api-error.js';
import type { AuditService } from '../audit/audit.service.js';
import type { CartService } from '../cart/cart.service.js';
import type { CatalogService } from '../catalog/catalog.service.js';
import type { StorageService } from '../storage/storage.service.js';
import { renderDesignSurfaceToPng } from './design-rasterizer.js';
import type {
  DesignRepository,
  ResolvedDesignRecord,
  StoredDesignAssetRecord,
} from './design.repository.js';

const ALLOWED_UPLOAD_MIME_EXT: Record<string, string> = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/webp': 'webp',
};

function collectAssetIds(objects: readonly CanonicalDesignObject[], out: Set<string>): void {
  for (const obj of objects) {
    if (obj.type === 'image') {
      out.add(obj.assetId);
    } else if (obj.type === 'group') {
      collectAssetIds(obj.children, out);
    }
  }
}

export class DesignService {
  constructor(
    private readonly designRepo: DesignRepository,
    private readonly catalogService: CatalogService,
    private readonly cartService: CartService,
    private readonly storage: StorageService,
    private readonly auditService: AuditService,
    private readonly env: ApiEnv
  ) {}

  private isFulfillmentOrAdmin(actorRole: string): boolean {
    return actorRole === 'staff' || actorRole === 'admin' || actorRole === 'super_admin';
  }

  private assertDesignAccess(
    record: ResolvedDesignRecord,
    actorUserId: number,
    actorRole: string,
    allowStaffRead = false
  ): void {
    if (record.ownerUserId === actorUserId) {
      return;
    }
    if (allowStaffRead && this.isFulfillmentOrAdmin(actorRole)) {
      return;
    }
    throw ApiError.notFound('Saved design not found');
  }

  private async resolveOwnedAssetsForDocument(
    document: CanonicalDesignDocument,
    ownerUserId: number
  ): Promise<Map<string, StoredDesignAssetRecord>> {
    const assetIds = new Set<string>();
    for (const surface of Object.values(document.surfaces)) {
      collectAssetIds(surface.objects, assetIds);
    }

    if (assetIds.size === 0) {
      return new Map();
    }

    const records = await this.designRepo.findAssetsByPublicIds(Array.from(assetIds));
    const map = new Map<string, StoredDesignAssetRecord>();
    for (const record of records) {
      if (record.ownerUserId === ownerUserId) {
        map.set(record.publicId, record);
      }
    }
    return map;
  }

  private computeServerCustomizationFee(
    product: ProductDetailDTO,
    activeSurfaces: readonly PrintAreaSurfaceKey[]
  ): {
    fee: string;
    customizedAreaMap: Map<PrintAreaSurfaceKey, ProductPrintAreaDTO>;
  } {
    const areasByKey = new Map(
      product.printAreas.filter((pa) => pa.isActive).map((pa) => [pa.surfaceKey, pa])
    );

    let totalMinor = 0n;
    const customizedAreaMap = new Map<PrintAreaSurfaceKey, ProductPrintAreaDTO>();

    for (const surfaceKey of activeSurfaces) {
      const area = areasByKey.get(surfaceKey);
      if (area) {
        customizedAreaMap.set(surfaceKey, area);
        totalMinor += decimalToMinorUnits(area.surchargeAmount);
      }
    }

    return {
      fee: minorUnitsToDecimal(totalMinor),
      customizedAreaMap,
    };
  }

  private sanitizeDocumentWithPrintAreas(
    document: CanonicalDesignDocument,
    product: ProductDetailDTO
  ): CanonicalDesignDocument {
    const areasByKey = new Map(
      product.printAreas.filter((pa) => pa.isActive).map((pa) => [pa.surfaceKey, pa])
    );

    const nextSurfaces: CanonicalDesignDocument['surfaces'] = {};
    for (const [key, surface] of Object.entries(document.surfaces)) {
      const area = areasByKey.get(key as PrintAreaSurfaceKey);
      nextSurfaces[key] = area
        ? {
            ...surface,
            surfaceKey: area.surfaceKey,
            printAreaId: area.id,
            physicalWidthMm: area.physicalWidthMm,
            physicalHeightMm: area.physicalHeightMm,
            targetDpi: area.targetDpi,
            safeInsetMm: area.safeInsetMm,
          }
        : surface;
    }

    return {
      ...document,
      productId: product.id,
      updatedAt: new Date().toISOString(),
      surfaces: nextSurfaces,
    };
  }

  async uploadArtworkAsset(params: {
    ownerUserId: number;
    ownerPublicId: string;
    originalFilename: string;
    buffer: Buffer;
  }): Promise<DesignAssetDTO> {
    if (params.buffer.byteLength === 0) {
      throw ApiError.badRequest('Uploaded artwork file is empty');
    }

    const detected = await fileTypeFromBuffer(params.buffer);
    if (!detected || !ALLOWED_UPLOAD_MIME_EXT[detected.mime]) {
      throw ApiError.badRequest(
        'Unsupported artwork file signature. Only verified PNG, JPEG, or WebP images are permitted.'
      );
    }

    let sanitized: Buffer;
    let widthPx: number;
    let heightPx: number;
    try {
      const result = await sharp(params.buffer, {
        limitInputPixels: 100_000_000,
      })
        .rotate()
        .toBuffer({ resolveWithObject: true });

      sanitized = result.data;
      widthPx = result.info.width;
      heightPx = result.info.height;
    } catch {
      throw ApiError.badRequest('Uploaded image is corrupted or exceeds safe pixel bounds');
    }

    if (widthPx < 50 || heightPx < 50) {
      throw ApiError.badRequest('Artwork image must be at least 50 × 50 pixels');
    }

    const previewBuffer = await sharp(sanitized, { limitInputPixels: 100_000_000 })
      .resize({
        width: 1200,
        height: 1200,
        fit: 'inside',
        withoutEnlargement: true,
      })
      .ensureAlpha()
      .png({ compressionLevel: 8 })
      .toBuffer();

    const assetPublicId = crypto.randomUUID();
    const ext = ALLOWED_UPLOAD_MIME_EXT[detected.mime]!;
    const objectKey = `private/uploads/${params.ownerPublicId}/${assetPublicId}.${ext}`;
    const previewObjectKey = `private/previews/${params.ownerPublicId}/assets/${assetPublicId}.png`;
    const sha256 = crypto.createHash('sha256').update(sanitized).digest('hex');

    await this.storage.putPrivateObject(objectKey, sanitized);
    await this.storage.putPrivateObject(previewObjectKey, previewBuffer);

    return this.designRepo.createAsset({
      publicId: assetPublicId,
      ownerUserId: params.ownerUserId,
      storageDriver: this.storage.driver,
      objectKey,
      previewObjectKey,
      originalFilename: params.originalFilename.slice(0, 240),
      mimeType: detected.mime,
      byteSize: sanitized.byteLength,
      widthPx,
      heightPx,
      sha256,
    });
  }

  async listOwnAssets(ownerUserId: number): Promise<DesignAssetDTO[]> {
    return this.designRepo.listAssetsByOwner(ownerUserId);
  }

  async getOwnerAssetPreview(
    assetPublicId: string,
    actorUserId: number,
    actorRole: string
  ): Promise<{ buffer: Buffer; mimeType: string }> {
    const asset = await this.designRepo.findAssetByPublicId(assetPublicId);
    if (!asset) {
      throw ApiError.notFound('Uploaded asset was not found');
    }
    if (asset.ownerUserId !== actorUserId && !this.isFulfillmentOrAdmin(actorRole)) {
      throw ApiError.notFound('Uploaded asset was not found');
    }

    const buffer = await this.storage.getPrivateObject(asset.previewObjectKey);
    return { buffer, mimeType: 'image/png' };
  }

  async listOwnDesigns(
    ownerUserId: number,
    page: number,
    pageSize: number
  ): Promise<{ designs: DesignSummaryDTO[]; pagination: PaginationMeta }> {
    return this.designRepo.listDesignsByOwner(ownerUserId, page, pageSize);
  }

  async getDesignById(
    designPublicId: string,
    actorUserId: number,
    actorRole: string
  ): Promise<DesignDetailDTO> {
    const resolved = await this.designRepo.findDesignByPublicId(designPublicId);
    if (!resolved) {
      throw ApiError.notFound('Saved design not found');
    }
    this.assertDesignAccess(resolved, actorUserId, actorRole, true);
    return resolved.detail;
  }

  async createDesign(params: {
    ownerUserId: number;
    ownerPublicId: string;
    input: CreateDesignInput;
  }): Promise<DesignDetailDTO> {
    const product = await this.catalogService.getPublicProductByPublicId(
      params.input.document.productId
    );
    if (!product.isCustomizable) {
      throw ApiError.badRequest('Selected garment does not support studio customization');
    }

    const variant = product.variants.find(
      (v) => v.id === params.input.document.productVariantId && v.isActive
    );
    if (!variant) {
      throw ApiError.notFound('Selected garment variant is unavailable');
    }

    const normalizedDoc = this.sanitizeDocumentWithPrintAreas(params.input.document, product);
    const ownedAssets = await this.resolveOwnedAssetsForDocument(normalizedDoc, params.ownerUserId);
    const validation = validateDesignDocumentForPrint(
      normalizedDoc,
      product.printAreas,
      new Set(ownedAssets.keys())
    );
    const { fee } = this.computeServerCustomizationFee(product, validation.activePrintSurfaces);

    const designPublicId = crypto.randomUUID();
    const created = await this.designRepo.createDesign({
      publicId: designPublicId,
      ownerUserId: params.ownerUserId,
      productPublicId: product.id,
      productVariantPublicId: variant.id,
      title: params.input.title,
      preferredMode: normalizedDoc.preferredMode,
      status: validation.isValidForPrint ? 'saved' : 'draft',
      latestPreviewKey: null,
      document: {
        ...normalizedDoc,
        designId: designPublicId,
      },
      validation,
      customizedSurfaces: validation.activePrintSurfaces,
      estimatedCustomizationFee: fee,
      currencyCode: product.currencyCode,
    });

    await this.auditService.record({
      actorUserId: params.ownerUserId,
      action: 'design.created',
      entityType: 'design',
      entityPublicId: created.id,
      metadata: {
        productSlug: product.slug,
        variantSku: variant.sku,
        surfaces: validation.activePrintSurfaces,
      },
    });

    return created;
  }

  async updateDesign(params: {
    designPublicId: string;
    ownerUserId: number;
    input: UpdateDesignInput;
  }): Promise<DesignDetailDTO> {
    const existing = await this.designRepo.findDesignByPublicId(params.designPublicId);
    if (!existing || existing.ownerUserId !== params.ownerUserId) {
      throw ApiError.notFound('Saved design not found');
    }

    const product = await this.catalogService.getPublicProductByPublicId(existing.detail.productId);
    const variant = product.variants.find(
      (v) => v.id === params.input.document.productVariantId && v.isActive
    );
    if (!variant) {
      throw ApiError.notFound('Selected garment variant is unavailable for this design');
    }

    const normalizedDoc = this.sanitizeDocumentWithPrintAreas(params.input.document, product);
    const ownedAssets = await this.resolveOwnedAssetsForDocument(normalizedDoc, params.ownerUserId);
    const validation = validateDesignDocumentForPrint(
      normalizedDoc,
      product.printAreas,
      new Set(ownedAssets.keys())
    );
    const { fee } = this.computeServerCustomizationFee(product, validation.activePrintSurfaces);

    return this.designRepo.updateDesign({
      designPublicId: existing.detail.id,
      ownerUserId: params.ownerUserId,
      title: params.input.title,
      productVariantPublicId: variant.id,
      preferredMode: normalizedDoc.preferredMode,
      status: existing.detail.status === 'ordered' ? 'ordered' : 'saved',
      document: normalizedDoc,
      validation,
      customizedSurfaces: validation.activePrintSurfaces,
      estimatedCustomizationFee: fee,
      currencyCode: product.currencyCode,
      createVersionSnapshot: params.input.createVersionSnapshot,
    });
  }

  async deleteDesign(designPublicId: string, ownerUserId: number): Promise<void> {
    const deleted = await this.designRepo.softDeleteDesign(designPublicId, ownerUserId);
    if (!deleted) {
      throw ApiError.notFound('Saved design not found');
    }
  }

  async renderSurfacePreview(params: {
    designPublicId: string;
    surfaceKey: PrintAreaSurfaceKey;
    actorUserId: number;
    actorRole: string;
  }): Promise<Buffer> {
    const resolved = await this.designRepo.findDesignByPublicId(params.designPublicId);
    if (!resolved) {
      throw ApiError.notFound('Saved design not found');
    }
    this.assertDesignAccess(resolved, params.actorUserId, params.actorRole, true);

    const surface = resolved.detail.document.surfaces[params.surfaceKey];
    if (!surface) {
      throw ApiError.notFound(`No artwork found on surface "${params.surfaceKey}"`);
    }

    const product = await this.catalogService.getPublicProductByPublicId(resolved.detail.productId);
    const printArea = product.printAreas.find(
      (pa) => pa.surfaceKey === params.surfaceKey && pa.isActive
    );
    if (!printArea) {
      throw ApiError.notFound(`Active print area "${params.surfaceKey}" was not found`);
    }

    const assetsById = await this.resolveOwnedAssetsForDocument(
      resolved.detail.document,
      resolved.ownerUserId
    );

    const rendered = await renderDesignSurfaceToPng({
      surface,
      printArea,
      assetsById,
      storage: this.storage,
      mode: 'preview',
    });

    return rendered.buffer;
  }

  async exportSurfacePrintMaster(params: {
    designPublicId: string;
    surfaceKey: PrintAreaSurfaceKey;
    actorUserId: number;
    actorRole: string;
  }): Promise<DesignPrintExportDTO> {
    const resolved = await this.designRepo.findDesignByPublicId(params.designPublicId);
    if (!resolved) {
      throw ApiError.notFound('Saved design not found');
    }
    this.assertDesignAccess(resolved, params.actorUserId, params.actorRole, true);

    const product = await this.catalogService.getPublicProductByPublicId(resolved.detail.productId);
    const printArea = product.printAreas.find(
      (pa) => pa.surfaceKey === params.surfaceKey && pa.isActive
    );
    if (!printArea) {
      throw ApiError.notFound(`Active print area "${params.surfaceKey}" was not found`);
    }

    const surface = resolved.detail.document.surfaces[params.surfaceKey];
    if (!surface || surface.objects.filter((obj) => obj.visible).length === 0) {
      throw ApiError.badRequest(
        `Surface "${printArea.labelEn}" contains no visible artwork to export.`
      );
    }

    const assetsById = await this.resolveOwnedAssetsForDocument(
      resolved.detail.document,
      resolved.ownerUserId
    );
    const validation = validateDesignDocumentForPrint(
      resolved.detail.document,
      product.printAreas,
      new Set(assetsById.keys())
    );
    const surfaceErrors = validation.issues.filter(
      (issue) => issue.severity === 'error' && issue.surfaceKey === params.surfaceKey
    );

    if (surfaceErrors.length > 0) {
      throw ApiError.conflict('PRINT_VALIDATION_FAILED', surfaceErrors[0]!.messageEn);
    }

    const rendered = await renderDesignSurfaceToPng({
      surface,
      printArea,
      assetsById,
      storage: this.storage,
      mode: 'print_master',
    });

    const exportId = crypto.randomUUID();
    const versionNum = resolved.detail.currentVersionNumber;
    const objectKey = `private/print-masters/${resolved.detail.id}/v${versionNum}/${params.surfaceKey}-${exportId}.png`;

    await this.storage.putPrivateObject(objectKey, rendered.buffer);

    const recorded = await this.designRepo.recordPrintExport({
      publicId: exportId,
      designInternalId: resolved.internalId,
      designVersionInternalId: resolved.currentVersionId,
      surfaceKey: params.surfaceKey,
      objectKey,
      widthPx: rendered.widthPx,
      heightPx: rendered.heightPx,
      dpi: rendered.dpi,
      byteSize: rendered.buffer.byteLength,
      sha256: rendered.sha256,
      requestedByUserId: params.actorUserId,
    });

    await this.auditService.record({
      actorUserId: params.actorUserId,
      action: 'design.print_master_exported',
      entityType: 'design_print_export',
      entityPublicId: recorded.id,
      metadata: {
        designId: resolved.detail.id,
        surfaceKey: params.surfaceKey,
        widthPx: recorded.widthPx,
        heightPx: recorded.heightPx,
        dpi: recorded.dpi,
        sha256: recorded.sha256,
      },
    });

    return {
      ...recorded,
      designVersionNumber: versionNum,
    };
  }

  async downloadProtectedPrintMaster(params: {
    exportPublicId: string;
    actorUserId: number;
    actorRole: string;
  }): Promise<{ buffer: Buffer; filename: string; dpi: number }> {
    const exportRecord = await this.designRepo.findPrintExportByPublicId(params.exportPublicId);
    if (!exportRecord) {
      throw ApiError.notFound('Print export artifact not found');
    }

    if (
      exportRecord.ownerUserId !== params.actorUserId &&
      !this.isFulfillmentOrAdmin(params.actorRole)
    ) {
      throw ApiError.notFound('Print export artifact not found');
    }

    const buffer = await this.storage.getPrivateObject(exportRecord.objectKey);
    return {
      buffer,
      filename: `your-choice-${exportRecord.designPublicId.slice(0, 8)}-${exportRecord.surfaceKey}-${exportRecord.dpi}dpi.png`,
      dpi: exportRecord.dpi,
    };
  }

  async addDesignToCart(params: {
    designPublicId: string;
    actorUserId: number;
    actorRole: string;
    rawGuestCartToken: string | null;
    input: AddDesignToCartInput;
  }): Promise<{ cart: CartDTO; newRawGuestToken: string | null; expiresAt: Date }> {
    const resolved = await this.designRepo.findDesignByPublicId(params.designPublicId);
    if (!resolved) {
      throw ApiError.notFound('Saved design not found');
    }
    this.assertDesignAccess(resolved, params.actorUserId, params.actorRole, false);

    const product = await this.catalogService.getPublicProductByPublicId(resolved.detail.productId);
    const targetVariantId = params.input.variantId ?? resolved.detail.productVariantId;
    const variant = product.variants.find((v) => v.id === targetVariantId && v.isActive);
    if (!variant) {
      throw ApiError.conflict('VARIANT_UNAVAILABLE', 'Selected garment variant is unavailable');
    }

    const assetsById = await this.resolveOwnedAssetsForDocument(
      resolved.detail.document,
      resolved.ownerUserId
    );
    const validation = validateDesignDocumentForPrint(
      resolved.detail.document,
      product.printAreas,
      new Set(assetsById.keys())
    );

    if (!validation.isValidForPrint) {
      const blocking = validation.issues.find((i) => i.severity === 'error');
      throw ApiError.conflict(
        'PRINT_VALIDATION_FAILED',
        blocking?.messageEn ?? 'Design failed production print validation'
      );
    }

    const { fee, customizedAreaMap } = this.computeServerCustomizationFee(
      product,
      validation.activePrintSurfaces
    );

    const versionNumber = resolved.detail.currentVersionNumber;
    const surfacesMeta: CartItemCustomizationDTO['surfaces'] = [];
    const productionSurfaces: OrderItemProductionSpecDTO['surfaces'] = [];

    for (const surfaceKey of validation.activePrintSurfaces) {
      const area = customizedAreaMap.get(surfaceKey);
      if (!area) continue;

      surfacesMeta.push({
        surfaceKey,
        labelEn: area.labelEn,
        labelBn: area.labelBn,
        previewImageRef: `${this.env.API_PREFIX}/designs/${resolved.detail.id}/surfaces/${surfaceKey}/preview?v=${versionNumber}`,
        surchargeAmount: area.surchargeAmount,
      });

      const latestExport = resolved.detail.exports.find(
        (exp) => exp.surfaceKey === surfaceKey && exp.designVersionNumber === versionNumber
      );

      productionSurfaces.push({
        surfaceKey,
        labelEn: area.labelEn,
        labelBn: area.labelBn,
        physicalWidthMm: area.physicalWidthMm,
        physicalHeightMm: area.physicalHeightMm,
        targetDpi: area.targetDpi,
        printReadyAssetRef: latestExport?.downloadUrl ?? null,
      });
    }

    const customizationMeta: CartItemCustomizationDTO = {
      designTitle: resolved.detail.title,
      designVersionNumber: versionNumber,
      preferredMode: resolved.detail.preferredMode,
      surfaces: surfacesMeta,
      note: params.input.note ?? null,
    };

    return this.cartService.addItem(
      { userId: params.actorUserId, rawGuestCartToken: params.rawGuestCartToken },
      variant.id,
      params.input.quantity,
      {
        designPublicId: resolved.detail.id,
        designTitle: resolved.detail.title,
        designVersionNumber: versionNumber,
        customizationFee: fee,
        customizationMeta,
        productionSpecPreview: {
          printMethod: 'dtf',
          targetDpi: Math.max(
            300,
            ...Array.from(customizedAreaMap.values()).map((a) => a.targetDpi)
          ),
          designVersionNumber: versionNumber,
          preferredMode: resolved.detail.preferredMode,
          surfaces: productionSurfaces,
        },
      }
    );
  }
}
