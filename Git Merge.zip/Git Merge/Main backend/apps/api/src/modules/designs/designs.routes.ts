import type {
  CartResponseData,
  DesignAssetListResponseData,
  DesignAssetUploadResponseData,
  DesignDetailResponseData,
  DesignListResponseData,
  DesignPrintExportResponseData,
  PrintAreaSurfaceKey,
} from '@your-choice/shared-types';
import {
  addDesignToCartSchema,
  createDesignSchema,
  designAssetIdParamSchema,
  designExportParamSchema,
  designIdParamSchema,
  designListQuerySchema,
  designSurfaceExportParamSchema,
  updateDesignSchema,
} from '@your-choice/validation';
import { type NextFunction, type Request, type Response, Router } from 'express';
import multer from 'multer';
import type { ApiEnv } from '../../config/env.js';
import { requireAuth, requireAuthContext } from '../../middleware/auth.js';
import { createJsonRateLimiter } from '../../middleware/rate-limit.js';
import { validateRequest } from '../../middleware/validate.js';
import { ApiError } from '../../utils/api-error.js';
import { sendSuccess } from '../../utils/api-response.js';
import { buildCartCookieOptions, parseCookieHeader } from '../../utils/cookies.js';
import type { DesignService } from './design.service.js';

const MAX_ARTWORK_UPLOAD_BYTES = 15 * 1024 * 1024; // 15 MB

const uploadMiddleware = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: MAX_ARTWORK_UPLOAD_BYTES,
    files: 1,
  },
});

function handleSingleFileUpload(req: Request, res: Response, next: NextFunction): void {
  uploadMiddleware.single('file')(req, res, (err: unknown) => {
    if (!err) {
      next();
      return;
    }
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        next(new ApiError(413, 'UPLOAD_TOO_LARGE', 'Artwork upload exceeds the 15 MB file limit.'));
        return;
      }
      next(ApiError.badRequest(err.message));
      return;
    }
    next(err);
  });
}

function resolvePrimaryActorRole(roles: readonly string[]): string {
  if (roles.includes('super_admin')) return 'super_admin';
  if (roles.includes('admin')) return 'admin';
  if (roles.includes('staff')) return 'staff';
  if (roles.includes('creator')) return 'creator';
  return 'customer';
}

export function createDesignsRouter(designService: DesignService, env: ApiEnv): Router {
  const router = Router();
  const uploadLimiter = createJsonRateLimiter({
    windowMs: 15 * 60 * 1000,
    limit: 60,
    message: 'Too many artwork upload or export requests. Please pause briefly.',
  });

  router.use(requireAuth);

  // --- Uploaded Artwork Assets ---
  router.get('/assets', async (_req, res) => {
    const auth = requireAuthContext(res);
    const assets = await designService.listOwnAssets(auth.internalUserId);
    sendSuccess<DesignAssetListResponseData>(res, { assets });
  });

  router.post('/assets/upload', uploadLimiter, handleSingleFileUpload, async (req, res) => {
    const auth = requireAuthContext(res);
    if (!req.file) {
      throw ApiError.badRequest('Select a PNG, JPEG, or WebP artwork image to upload.');
    }

    const asset = await designService.uploadArtworkAsset({
      ownerUserId: auth.internalUserId,
      ownerPublicId: auth.user.id,
      originalFilename: req.file.originalname || 'artwork.png',
      buffer: req.file.buffer,
    });

    sendSuccess<DesignAssetUploadResponseData>(res, { asset }, 201);
  });

  router.get(
    '/assets/:assetId/preview',
    validateRequest({ params: designAssetIdParamSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const { assetId } = req.params as { assetId: string };
      const preview = await designService.getOwnerAssetPreview(
        assetId,
        auth.internalUserId,
        resolvePrimaryActorRole(auth.user.roles)
      );

      res.setHeader('Content-Type', preview.mimeType);
      res.setHeader('Cache-Control', 'private, max-age=300');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.status(200).send(preview.buffer);
    }
  );

  // --- Protected 300 DPI Print Master Download (Owner or Fulfillment/Admin Only) ---
  router.get(
    '/exports/:exportId/download',
    validateRequest({ params: designExportParamSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const { exportId } = req.params as { exportId: string };
      const result = await designService.downloadProtectedPrintMaster({
        exportPublicId: exportId,
        actorUserId: auth.internalUserId,
        actorRole: resolvePrimaryActorRole(auth.user.roles),
      });

      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Content-Disposition', `attachment; filename="${result.filename}"`);
      res.setHeader('Cache-Control', 'private, no-store');
      res.setHeader('X-Print-DPI', String(result.dpi));
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.status(200).send(result.buffer);
    }
  );

  // --- Saved Designs ---
  router.get('/', validateRequest({ query: designListQuerySchema }), async (req, res) => {
    const auth = requireAuthContext(res);
    const { page, pageSize } = req.query as unknown as { page: number; pageSize: number };
    const result = await designService.listOwnDesigns(auth.internalUserId, page, pageSize);
    sendSuccess<DesignListResponseData>(res, result);
  });

  router.post('/', validateRequest({ body: createDesignSchema }), async (req, res) => {
    const auth = requireAuthContext(res);
    const design = await designService.createDesign({
      ownerUserId: auth.internalUserId,
      ownerPublicId: auth.user.id,
      input: req.body,
    });
    sendSuccess<DesignDetailResponseData>(res, { design }, 201);
  });

  router.get('/:designId', validateRequest({ params: designIdParamSchema }), async (req, res) => {
    const auth = requireAuthContext(res);
    const { designId } = req.params as { designId: string };
    const design = await designService.getDesignById(
      designId,
      auth.internalUserId,
      resolvePrimaryActorRole(auth.user.roles)
    );
    sendSuccess<DesignDetailResponseData>(res, { design });
  });

  router.put(
    '/:designId',
    validateRequest({ params: designIdParamSchema, body: updateDesignSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const { designId } = req.params as { designId: string };
      const design = await designService.updateDesign({
        designPublicId: designId,
        ownerUserId: auth.internalUserId,
        input: req.body,
      });
      sendSuccess<DesignDetailResponseData>(res, { design });
    }
  );

  router.delete(
    '/:designId',
    validateRequest({ params: designIdParamSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const { designId } = req.params as { designId: string };
      await designService.deleteDesign(designId, auth.internalUserId);
      sendSuccess<{ deleted: boolean }>(res, { deleted: true });
    }
  );

  // --- Downscaled Surface Preview vs Protected Server 300 DPI DTF Print Master ---
  router.get(
    '/:designId/surfaces/:surfaceKey/preview',
    validateRequest({ params: designSurfaceExportParamSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const { designId, surfaceKey } = req.params as {
        designId: string;
        surfaceKey: PrintAreaSurfaceKey;
      };
      const pngBuffer = await designService.renderSurfacePreview({
        designPublicId: designId,
        surfaceKey,
        actorUserId: auth.internalUserId,
        actorRole: resolvePrimaryActorRole(auth.user.roles),
      });

      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Cache-Control', 'private, max-age=60');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.status(200).send(pngBuffer);
    }
  );

  router.post(
    '/:designId/surfaces/:surfaceKey/export-print-master',
    uploadLimiter,
    validateRequest({ params: designSurfaceExportParamSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const { designId, surfaceKey } = req.params as {
        designId: string;
        surfaceKey: PrintAreaSurfaceKey;
      };
      const printExport = await designService.exportSurfacePrintMaster({
        designPublicId: designId,
        surfaceKey,
        actorUserId: auth.internalUserId,
        actorRole: resolvePrimaryActorRole(auth.user.roles),
      });
      sendSuccess<DesignPrintExportResponseData>(res, { printExport }, 201);
    }
  );

  router.post(
    '/:designId/add-to-cart',
    validateRequest({ params: designIdParamSchema, body: addDesignToCartSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const { designId } = req.params as { designId: string };
      const cookies = parseCookieHeader(req.headers.cookie);

      const result = await designService.addDesignToCart({
        designPublicId: designId,
        actorUserId: auth.internalUserId,
        actorRole: resolvePrimaryActorRole(auth.user.roles),
        rawGuestCartToken: cookies[env.CART_COOKIE_NAME] ?? null,
        input: req.body,
      });

      if (result.newRawGuestToken) {
        res.cookie(
          env.CART_COOKIE_NAME,
          result.newRawGuestToken,
          buildCartCookieOptions(env, result.expiresAt)
        );
      }

      sendSuccess<CartResponseData>(res, { cart: result.cart }, 201);
    }
  );

  return router;
}
