import type {
  CanonicalDesignDocument,
  DesignAssetDTO,
  DesignDetailDTO,
  DesignPrintExportDTO,
  DesignRecordStatus,
  DesignSummaryDTO,
  DesignValidationReport,
  PaginationMeta,
  PrintAreaSurfaceKey,
} from '@your-choice/shared-types';

export interface StoredDesignAssetRecord {
  id: number;
  publicId: string;
  ownerUserId: number;
  storageDriver: 'local' | 's3';
  objectKey: string;
  previewObjectKey: string;
  originalFilename: string;
  mimeType: string;
  byteSize: number;
  widthPx: number;
  heightPx: number;
  sha256: string;
  createdAt: Date;
}

export interface CreateDesignAssetParams {
  publicId: string;
  ownerUserId: number;
  storageDriver: 'local' | 's3';
  objectKey: string;
  previewObjectKey: string;
  originalFilename: string;
  mimeType: string;
  byteSize: number;
  widthPx: number;
  heightPx: number;
  sha256: string;
}

export interface CreateDesignRecordParams {
  publicId: string;
  ownerUserId: number;
  productPublicId: string;
  productVariantPublicId: string;
  title: string;
  preferredMode: '2d' | '3d';
  status: DesignRecordStatus;
  latestPreviewKey: string | null;
  document: CanonicalDesignDocument;
  validation: DesignValidationReport;
  customizedSurfaces: PrintAreaSurfaceKey[];
  estimatedCustomizationFee: string;
  currencyCode: string;
}

export interface UpdateDesignRecordParams {
  designPublicId: string;
  ownerUserId: number;
  title?: string;
  productVariantPublicId?: string;
  preferredMode?: '2d' | '3d';
  status?: DesignRecordStatus;
  latestPreviewKey?: string | null;
  document: CanonicalDesignDocument;
  validation: DesignValidationReport;
  customizedSurfaces: PrintAreaSurfaceKey[];
  estimatedCustomizationFee: string;
  currencyCode: string;
  createVersionSnapshot: boolean;
}

export interface ResolvedDesignRecord {
  internalId: number;
  ownerUserId: number;
  currentVersionId: number;
  detail: DesignDetailDTO;
}

export interface CreatePrintExportRecordParams {
  publicId: string;
  designInternalId: number;
  designVersionInternalId: number;
  surfaceKey: PrintAreaSurfaceKey;
  objectKey: string;
  widthPx: number;
  heightPx: number;
  dpi: number;
  byteSize: number;
  sha256: string;
  requestedByUserId: number;
}

export interface ResolvedPrintExportRecord {
  internalId: number;
  publicId: string;
  designPublicId: string;
  ownerUserId: number;
  surfaceKey: PrintAreaSurfaceKey;
  objectKey: string;
  widthPx: number;
  heightPx: number;
  dpi: number;
  byteSize: number;
  sha256: string;
  createdAt: Date;
}

export interface DesignRepository {
  createAsset(params: CreateDesignAssetParams): Promise<DesignAssetDTO>;
  listAssetsByOwner(ownerUserId: number): Promise<DesignAssetDTO[]>;
  findAssetByPublicId(assetPublicId: string): Promise<StoredDesignAssetRecord | null>;
  findAssetsByPublicIds(assetPublicIds: readonly string[]): Promise<StoredDesignAssetRecord[]>;

  listDesignsByOwner(
    ownerUserId: number,
    page: number,
    pageSize: number
  ): Promise<{ designs: DesignSummaryDTO[]; pagination: PaginationMeta }>;
  findDesignByPublicId(designPublicId: string): Promise<ResolvedDesignRecord | null>;
  createDesign(params: CreateDesignRecordParams): Promise<DesignDetailDTO>;
  updateDesign(params: UpdateDesignRecordParams): Promise<DesignDetailDTO>;
  softDeleteDesign(designPublicId: string, ownerUserId: number): Promise<boolean>;

  recordPrintExport(params: CreatePrintExportRecordParams): Promise<DesignPrintExportDTO>;
  findPrintExportByPublicId(exportPublicId: string): Promise<ResolvedPrintExportRecord | null>;
}
