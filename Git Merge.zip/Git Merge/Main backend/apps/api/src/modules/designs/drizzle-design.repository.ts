import crypto from 'node:crypto';
import {
  type DatabaseCanonicalDesignDocumentJson,
  type DatabaseDesignSurfaceSummaryJson,
  type DatabaseDesignValidationSummaryJson,
  designAssets,
  designPrintExports,
  designVersions,
  designs,
  productVariants,
  products,
} from '@your-choice/database/schema';
import type {
  CanonicalDesignDocument,
  DesignAssetDTO,
  DesignDetailDTO,
  DesignPrintExportDTO,
  DesignRecordStatus,
  DesignSummaryDTO,
  DesignValidationReport,
  PaginationMeta,
  PrintAreaSurfaceKey,
} from '@your-choice/shared-types';
import { and, desc, eq, inArray, isNull, sql } from 'drizzle-orm';
import type { AppDatabase } from '../../database/client.js';
import { ApiError } from '../../utils/api-error.js';
import type {
  CreateDesignAssetParams,
  CreateDesignRecordParams,
  CreatePrintExportRecordParams,
  DesignRepository,
  ResolvedDesignRecord,
  ResolvedPrintExportRecord,
  StoredDesignAssetRecord,
  UpdateDesignRecordParams,
} from './design.repository.js';

export class DrizzleDesignRepository implements DesignRepository {
  constructor(
    private readonly db: AppDatabase,
    private readonly apiPrefix = '/api/v1'
  ) {}

  private toAssetDto(row: typeof designAssets.$inferSelect): DesignAssetDTO {
    return {
      id: row.publicId,
      originalFilename: row.originalFilename,
      mimeType: row.mimeType,
      byteSize: row.byteSize,
      widthPx: row.widthPx,
      heightPx: row.heightPx,
      sha256: row.sha256,
      previewUrl: `${this.apiPrefix}/designs/assets/${row.publicId}/preview`,
      createdAt: row.createdAt.toISOString(),
    };
  }

  private toStoredAssetRecord(row: typeof designAssets.$inferSelect): StoredDesignAssetRecord {
    return {
      id: row.id,
      publicId: row.publicId,
      ownerUserId: row.ownerUserId,
      storageDriver: row.storageDriver,
      objectKey: row.objectKey,
      previewObjectKey: row.previewObjectKey,
      originalFilename: row.originalFilename,
      mimeType: row.mimeType,
      byteSize: row.byteSize,
      widthPx: row.widthPx,
      heightPx: row.heightPx,
      sha256: row.sha256,
      createdAt: row.createdAt,
    };
  }

  private toExportDto(
    row: typeof designPrintExports.$inferSelect,
    designPublicId: string,
    versionNumber: number
  ): DesignPrintExportDTO {
    return {
      id: row.publicId,
      designId: designPublicId,
      designVersionNumber: versionNumber,
      surfaceKey: row.surfaceKey,
      widthPx: row.widthPx,
      heightPx: row.heightPx,
      dpi: row.dpi,
      byteSize: row.byteSize,
      sha256: row.sha256,
      downloadUrl: `${this.apiPrefix}/designs/exports/${row.publicId}/download`,
      createdAt: row.createdAt.toISOString(),
    };
  }

  private toSummaryDto(params: {
    design: typeof designs.$inferSelect;
    product: typeof products.$inferSelect;
    variant: typeof productVariants.$inferSelect;
    version: typeof designVersions.$inferSelect;
  }): DesignSummaryDTO {
    const surfaceSummary = params.version.surfaceSummaryJson;
    const validationSummary = params.version.validationSummaryJson;
    const customizedSurfaces = (surfaceSummary.customizedSurfaces ?? []) as PrintAreaSurfaceKey[];
    const firstSurface = customizedSurfaces[0] ?? null;

    return {
      id: params.design.publicId,
      title: params.design.title,
      productId: params.product.publicId,
      productSlug: params.product.slug,
      productNameEn: params.product.nameEn,
      productNameBn: params.product.nameBn,
      productVariantId: params.variant.publicId,
      variantSku: params.variant.sku,
      variantColorNameEn: params.variant.colorNameEn,
      variantColorNameBn: params.variant.colorNameBn,
      variantColorHex: params.variant.colorHex,
      variantSizeCode: params.variant.sizeCode,
      preferredMode: params.design.preferredMode,
      currentVersionNumber: params.design.currentVersionNumber,
      status: params.design.status as DesignRecordStatus,
      customizedSurfaces,
      estimatedCustomizationFee: surfaceSummary.estimatedCustomizationFee ?? '0.00',
      currencyCode: surfaceSummary.currencyCode ?? params.product.currencyCode,
      isValidForPrint: Boolean(validationSummary.isValidForPrint),
      previewUrl: firstSurface
        ? `${this.apiPrefix}/designs/${params.design.publicId}/surfaces/${firstSurface}/preview?v=${params.design.currentVersionNumber}`
        : null,
      createdAt: params.design.createdAt.toISOString(),
      updatedAt: params.design.updatedAt.toISOString(),
    };
  }

  async createAsset(params: CreateDesignAssetParams): Promise<DesignAssetDTO> {
    await this.db.insert(designAssets).values({
      publicId: params.publicId,
      ownerUserId: params.ownerUserId,
      storageDriver: params.storageDriver,
      objectKey: params.objectKey,
      previewObjectKey: params.previewObjectKey,
      originalFilename: params.originalFilename,
      mimeType: params.mimeType,
      byteSize: params.byteSize,
      widthPx: params.widthPx,
      heightPx: params.heightPx,
      sha256: params.sha256,
      status: 'active',
    });

    const [created] = await this.db
      .select()
      .from(designAssets)
      .where(eq(designAssets.publicId, params.publicId))
      .limit(1);

    if (!created) {
      throw ApiError.internal('Failed to persist design asset');
    }

    return this.toAssetDto(created);
  }

  async listAssetsByOwner(ownerUserId: number): Promise<DesignAssetDTO[]> {
    const rows = await this.db
      .select()
      .from(designAssets)
      .where(
        and(
          eq(designAssets.ownerUserId, ownerUserId),
          eq(designAssets.status, 'active'),
          isNull(designAssets.deletedAt)
        )
      )
      .orderBy(desc(designAssets.createdAt))
      .limit(100);

    return rows.map((row) => this.toAssetDto(row));
  }

  async findAssetByPublicId(assetPublicId: string): Promise<StoredDesignAssetRecord | null> {
    const [row] = await this.db
      .select()
      .from(designAssets)
      .where(
        and(
          eq(designAssets.publicId, assetPublicId),
          eq(designAssets.status, 'active'),
          isNull(designAssets.deletedAt)
        )
      )
      .limit(1);

    return row ? this.toStoredAssetRecord(row) : null;
  }

  async findAssetsByPublicIds(
    assetPublicIds: readonly string[]
  ): Promise<StoredDesignAssetRecord[]> {
    if (assetPublicIds.length === 0) {
      return [];
    }

    const rows = await this.db
      .select()
      .from(designAssets)
      .where(
        and(
          inArray(designAssets.publicId, [...assetPublicIds]),
          eq(designAssets.status, 'active'),
          isNull(designAssets.deletedAt)
        )
      );

    return rows.map((row) => this.toStoredAssetRecord(row));
  }

  async listDesignsByOwner(
    ownerUserId: number,
    page: number,
    pageSize: number
  ): Promise<{ designs: DesignSummaryDTO[]; pagination: PaginationMeta }> {
    const offset = (page - 1) * pageSize;

    const [countRow] = await this.db
      .select({ total: sql<number>`COUNT(*)` })
      .from(designs)
      .where(and(eq(designs.ownerUserId, ownerUserId), isNull(designs.deletedAt)));

    const totalItems = Number(countRow?.total ?? 0);
    const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));

    const rows = await this.db
      .select({
        design: designs,
        product: products,
        variant: productVariants,
        version: designVersions,
      })
      .from(designs)
      .innerJoin(products, eq(designs.productId, products.id))
      .innerJoin(productVariants, eq(designs.productVariantId, productVariants.id))
      .innerJoin(
        designVersions,
        and(
          eq(designVersions.designId, designs.id),
          eq(designVersions.versionNumber, designs.currentVersionNumber)
        )
      )
      .where(and(eq(designs.ownerUserId, ownerUserId), isNull(designs.deletedAt)))
      .orderBy(desc(designs.updatedAt))
      .limit(pageSize)
      .offset(offset);

    return {
      designs: rows.map((row) => this.toSummaryDto(row)),
      pagination: {
        page,
        pageSize,
        totalItems,
        totalPages,
      },
    };
  }

  async findDesignByPublicId(designPublicId: string): Promise<ResolvedDesignRecord | null> {
    const [row] = await this.db
      .select({
        design: designs,
        product: products,
        variant: productVariants,
        version: designVersions,
      })
      .from(designs)
      .innerJoin(products, eq(designs.productId, products.id))
      .innerJoin(productVariants, eq(designs.productVariantId, productVariants.id))
      .innerJoin(
        designVersions,
        and(
          eq(designVersions.designId, designs.id),
          eq(designVersions.versionNumber, designs.currentVersionNumber)
        )
      )
      .where(and(eq(designs.publicId, designPublicId), isNull(designs.deletedAt)))
      .limit(1);

    if (!row) {
      return null;
    }

    const exportRows = await this.db
      .select({
        exportRow: designPrintExports,
        versionNum: designVersions.versionNumber,
      })
      .from(designPrintExports)
      .innerJoin(designVersions, eq(designPrintExports.designVersionId, designVersions.id))
      .where(eq(designPrintExports.designId, row.design.id))
      .orderBy(desc(designPrintExports.createdAt))
      .limit(20);

    const summary = this.toSummaryDto(row);
    const detail: DesignDetailDTO = {
      ...summary,
      document: row.version.documentJson as unknown as CanonicalDesignDocument,
      validation: row.version.validationSummaryJson as unknown as DesignValidationReport,
      exports: exportRows.map((e) =>
        this.toExportDto(e.exportRow, row.design.publicId, e.versionNum)
      ),
    };

    return {
      internalId: row.design.id,
      ownerUserId: row.design.ownerUserId,
      currentVersionId: row.version.id,
      detail,
    };
  }

  async createDesign(params: CreateDesignRecordParams): Promise<DesignDetailDTO> {
    await this.db.transaction(async (tx) => {
      const [productRow] = await tx
        .select()
        .from(products)
        .where(and(eq(products.publicId, params.productPublicId), isNull(products.deletedAt)))
        .limit(1);

      if (!productRow) {
        throw ApiError.notFound('Product not found');
      }

      const [variantRow] = await tx
        .select()
        .from(productVariants)
        .where(
          and(
            eq(productVariants.publicId, params.productVariantPublicId),
            eq(productVariants.productId, productRow.id),
            isNull(productVariants.deletedAt)
          )
        )
        .limit(1);

      if (!variantRow) {
        throw ApiError.notFound('Selected product variant was not found');
      }

      const normalizedDocument: CanonicalDesignDocument = {
        ...params.document,
        designId: params.publicId,
        version: 1,
      };

      const [designInsert] = await tx.insert(designs).values({
        publicId: params.publicId,
        ownerUserId: params.ownerUserId,
        productId: productRow.id,
        productVariantId: variantRow.id,
        title: params.title,
        preferredMode: params.preferredMode,
        currentVersionNumber: 1,
        status: params.status,
        latestPreviewKey: params.latestPreviewKey,
      });

      const designId = designInsert.insertId;

      await tx.insert(designVersions).values({
        publicId: crypto.randomUUID(),
        designId,
        versionNumber: 1,
        documentJson: normalizedDocument as unknown as DatabaseCanonicalDesignDocumentJson,
        validationSummaryJson: params.validation as unknown as DatabaseDesignValidationSummaryJson,
        surfaceSummaryJson: {
          customizedSurfaces: params.customizedSurfaces,
          estimatedCustomizationFee: params.estimatedCustomizationFee,
          currencyCode: params.currencyCode,
        } satisfies DatabaseDesignSurfaceSummaryJson,
        createdByUserId: params.ownerUserId,
      });
    });

    const created = await this.findDesignByPublicId(params.publicId);
    if (!created) {
      throw ApiError.internal('Failed to load created design');
    }
    return created.detail;
  }

  async updateDesign(params: UpdateDesignRecordParams): Promise<DesignDetailDTO> {
    await this.db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(designs)
        .where(and(eq(designs.publicId, params.designPublicId), isNull(designs.deletedAt)))
        .limit(1);

      if (!existing || existing.ownerUserId !== params.ownerUserId) {
        throw ApiError.notFound('Saved design not found');
      }

      let nextVariantId = existing.productVariantId;
      if (params.productVariantPublicId) {
        const [variantRow] = await tx
          .select()
          .from(productVariants)
          .where(
            and(
              eq(productVariants.publicId, params.productVariantPublicId),
              eq(productVariants.productId, existing.productId),
              isNull(productVariants.deletedAt)
            )
          )
          .limit(1);

        if (!variantRow) {
          throw ApiError.notFound('Selected product variant was not found for this garment');
        }
        nextVariantId = variantRow.id;
      }

      const nextVersionNumber = params.createVersionSnapshot
        ? existing.currentVersionNumber + 1
        : existing.currentVersionNumber;

      const normalizedDocument: CanonicalDesignDocument = {
        ...params.document,
        designId: existing.publicId,
        version: nextVersionNumber,
      };

      const surfaceSummary: DatabaseDesignSurfaceSummaryJson = {
        customizedSurfaces: params.customizedSurfaces,
        estimatedCustomizationFee: params.estimatedCustomizationFee,
        currencyCode: params.currencyCode,
      };

      await tx
        .update(designs)
        .set({
          title: params.title ?? existing.title,
          productVariantId: nextVariantId,
          preferredMode: params.preferredMode ?? existing.preferredMode,
          currentVersionNumber: nextVersionNumber,
          status: params.status ?? existing.status,
          latestPreviewKey:
            params.latestPreviewKey !== undefined
              ? params.latestPreviewKey
              : existing.latestPreviewKey,
          updatedAt: new Date(),
        })
        .where(eq(designs.id, existing.id));

      if (params.createVersionSnapshot) {
        await tx.insert(designVersions).values({
          publicId: crypto.randomUUID(),
          designId: existing.id,
          versionNumber: nextVersionNumber,
          documentJson: normalizedDocument as unknown as DatabaseCanonicalDesignDocumentJson,
          validationSummaryJson:
            params.validation as unknown as DatabaseDesignValidationSummaryJson,
          surfaceSummaryJson: surfaceSummary,
          createdByUserId: params.ownerUserId,
        });
      } else {
        await tx
          .update(designVersions)
          .set({
            documentJson: normalizedDocument as unknown as DatabaseCanonicalDesignDocumentJson,
            validationSummaryJson:
              params.validation as unknown as DatabaseDesignValidationSummaryJson,
            surfaceSummaryJson: surfaceSummary,
            updatedAt: new Date(),
          })
          .where(
            and(
              eq(designVersions.designId, existing.id),
              eq(designVersions.versionNumber, existing.currentVersionNumber)
            )
          );
      }
    });

    const updated = await this.findDesignByPublicId(params.designPublicId);
    if (!updated) {
      throw ApiError.internal('Failed to load updated design');
    }
    return updated.detail;
  }

  async softDeleteDesign(designPublicId: string, ownerUserId: number): Promise<boolean> {
    const [result] = await this.db
      .update(designs)
      .set({
        deletedAt: new Date(),
        status: 'archived',
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(designs.publicId, designPublicId),
          eq(designs.ownerUserId, ownerUserId),
          isNull(designs.deletedAt)
        )
      );

    return (result.affectedRows ?? 0) > 0;
  }

  async recordPrintExport(params: CreatePrintExportRecordParams): Promise<DesignPrintExportDTO> {
    await this.db.insert(designPrintExports).values({
      publicId: params.publicId,
      designId: params.designInternalId,
      designVersionId: params.designVersionInternalId,
      surfaceKey: params.surfaceKey,
      objectKey: params.objectKey,
      widthPx: params.widthPx,
      heightPx: params.heightPx,
      dpi: params.dpi,
      byteSize: params.byteSize,
      sha256: params.sha256,
      requestedByUserId: params.requestedByUserId,
    });

    const resolved = await this.findPrintExportByPublicId(params.publicId);
    if (!resolved) {
      throw ApiError.internal('Failed to persist print export metadata');
    }

    return {
      id: resolved.publicId,
      designId: resolved.designPublicId,
      designVersionNumber: 1,
      surfaceKey: resolved.surfaceKey,
      widthPx: resolved.widthPx,
      heightPx: resolved.heightPx,
      dpi: resolved.dpi,
      byteSize: resolved.byteSize,
      sha256: resolved.sha256,
      downloadUrl: `${this.apiPrefix}/designs/exports/${resolved.publicId}/download`,
      createdAt: resolved.createdAt.toISOString(),
    };
  }

  async findPrintExportByPublicId(
    exportPublicId: string
  ): Promise<ResolvedPrintExportRecord | null> {
    const [row] = await this.db
      .select({
        exportRow: designPrintExports,
        design: designs,
      })
      .from(designPrintExports)
      .innerJoin(designs, eq(designPrintExports.designId, designs.id))
      .where(and(eq(designPrintExports.publicId, exportPublicId), isNull(designs.deletedAt)))
      .limit(1);

    if (!row) {
      return null;
    }

    return {
      internalId: row.exportRow.id,
      publicId: row.exportRow.publicId,
      designPublicId: row.design.publicId,
      ownerUserId: row.design.ownerUserId,
      surfaceKey: row.exportRow.surfaceKey,
      objectKey: row.exportRow.objectKey,
      widthPx: row.exportRow.widthPx,
      heightPx: row.exportRow.heightPx,
      dpi: row.exportRow.dpi,
      byteSize: row.exportRow.byteSize,
      sha256: row.exportRow.sha256,
      createdAt: row.exportRow.createdAt,
    };
  }
}
