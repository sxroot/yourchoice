import crypto from 'node:crypto';
import type {
  CanonicalDesignObject,
  CanonicalDesignSurface,
  CanonicalGraphicObject,
  CanonicalGroupObject,
  CanonicalImageObject,
  CanonicalShapeObject,
  CanonicalTextObject,
  ProductPrintAreaDTO,
} from '@your-choice/shared-types';
import { STUDIO_FONT_PRESETS } from '@your-choice/shared-types';
import sharp, { type OverlayOptions } from 'sharp';
import type { StorageService } from '../storage/storage.service.js';

export interface ResolvedAssetBinaryInfo {
  publicId: string;
  objectKey: string;
  mimeType: string;
}

export interface RasterizedSurfaceOutput {
  buffer: Buffer;
  widthPx: number;
  heightPx: number;
  dpi: number;
  sha256: string;
}

const FONT_STACK_BY_FAMILY = new Map(
  STUDIO_FONT_PRESETS.map((preset) => [preset.family, preset.fallbackStack])
);

function escapeXml(value: string): string {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;');
}

export function computePrintMasterPixelDimensions(printArea: {
  physicalWidthMm: number;
  physicalHeightMm: number;
  targetDpi: number;
}): { widthPx: number; heightPx: number; dpi: number } {
  const dpi = Math.max(150, Math.min(600, Math.round(printArea.targetDpi || 300)));
  const widthPx = Math.max(64, Math.round((printArea.physicalWidthMm / 25.4) * dpi));
  const heightPx = Math.max(64, Math.round((printArea.physicalHeightMm / 25.4) * dpi));
  return { widthPx, heightPx, dpi };
}

function resolveFontCssStack(family: string): string {
  return FONT_STACK_BY_FAMILY.get(family) ?? `'${family.replaceAll("'", '')}', sans-serif`;
}

function buildPolygonPoints(sides: number, rx: number, ry: number, angleOffsetDeg = -90): string {
  const pts: string[] = [];
  for (let i = 0; i < sides; i += 1) {
    const deg = angleOffsetDeg + (i * 360) / sides;
    const rad = (deg * Math.PI) / 180;
    pts.push(`${(Math.cos(rad) * rx).toFixed(2)},${(Math.sin(rad) * ry).toFixed(2)}`);
  }
  return pts.join(' ');
}

function buildStarPoints(outerRx: number, outerRy: number): string {
  const innerRx = outerRx * 0.42;
  const innerRy = outerRy * 0.42;
  const pts: string[] = [];
  for (let i = 0; i < 10; i += 1) {
    const rad = ((-90 + i * 36) * Math.PI) / 180;
    const rx = i % 2 === 0 ? outerRx : innerRx;
    const ry = i % 2 === 0 ? outerRy : innerRy;
    pts.push(`${(Math.cos(rad) * rx).toFixed(2)},${(Math.sin(rad) * ry).toFixed(2)}`);
  }
  return pts.join(' ');
}

function renderShapeSvgNode(
  obj: CanonicalShapeObject,
  boxW: number,
  boxH: number,
  canvasW: number
): string {
  const strokeAttr =
    obj.stroke && obj.strokeWidth > 0
      ? `stroke="${escapeXml(obj.stroke)}" stroke-width="${((obj.strokeWidth / 1000) * canvasW).toFixed(2)}"`
      : 'stroke="none"';

  const hw = boxW / 2;
  const hh = boxH / 2;

  switch (obj.shapeKind) {
    case 'rect': {
      const rx = Math.min(hw, hh, (obj.cornerRadius / 1000) * canvasW);
      return `<rect x="${(-hw).toFixed(2)}" y="${(-hh).toFixed(2)}" width="${boxW.toFixed(2)}" height="${boxH.toFixed(2)}" rx="${rx.toFixed(2)}" ry="${rx.toFixed(2)}" fill="${escapeXml(obj.fill)}" ${strokeAttr} />`;
    }
    case 'circle':
      return `<ellipse cx="0" cy="0" rx="${hw.toFixed(2)}" ry="${hh.toFixed(2)}" fill="${escapeXml(obj.fill)}" ${strokeAttr} />`;
    case 'triangle':
      return `<polygon points="0,${(-hh).toFixed(2)} ${hw.toFixed(2)},${hh.toFixed(2)} ${(-hw).toFixed(2)},${hh.toFixed(2)}" fill="${escapeXml(obj.fill)}" ${strokeAttr} stroke-linejoin="round" />`;
    case 'star':
      return `<polygon points="${buildStarPoints(hw, hh)}" fill="${escapeXml(obj.fill)}" ${strokeAttr} stroke-linejoin="round" />`;
    case 'hexagon':
      return `<polygon points="${buildPolygonPoints(6, hw, hh, -90)}" fill="${escapeXml(obj.fill)}" ${strokeAttr} stroke-linejoin="round" />`;
    case 'line': {
      const lineStrokeWidth = Math.max(2, (Math.max(obj.strokeWidth, 4) / 1000) * canvasW);
      const color = escapeXml(obj.stroke ?? obj.fill);
      return `<line x1="${(-hw).toFixed(2)}" y1="0" x2="${hw.toFixed(2)}" y2="0" stroke="${color}" stroke-width="${lineStrokeWidth.toFixed(2)}" stroke-linecap="round" />`;
    }
  }
}

function renderGraphicSvgNode(
  obj: CanonicalGraphicObject,
  boxW: number,
  boxH: number,
  canvasW: number
): string {
  const sx = boxW / obj.viewBoxSize;
  const sy = boxH / obj.viewBoxSize;
  const strokeAttr =
    obj.stroke && obj.strokeWidth > 0
      ? `stroke="${escapeXml(obj.stroke)}" stroke-width="${(((obj.strokeWidth / 1000) * canvasW) / Math.max(0.01, (sx + sy) / 2)).toFixed(2)}"`
      : 'stroke="none"';

  return `<g transform="translate(${(-boxW / 2).toFixed(2)} ${(-boxH / 2).toFixed(2)}) scale(${sx.toFixed(5)} ${sy.toFixed(5)})">
    <path d="${escapeXml(obj.pathData)}" fill="${escapeXml(obj.fill)}" ${strokeAttr} stroke-linejoin="round" />
  </g>`;
}

function renderTextSvgNode(
  obj: CanonicalTextObject,
  boxW: number,
  canvasW: number,
  canvasH: number
): string {
  const lines = obj.text.split(/\r?\n/);
  const fontSizePx = Math.max(8, obj.fontSizeRatio * canvasH);
  const lineStep = fontSizePx * obj.lineHeight;
  const totalTextHeight = lines.length * lineStep;
  const firstBaselineY = -totalTextHeight / 2 + fontSizePx * 0.82;

  let anchor = 'middle';
  let anchorX = 0;
  if (obj.textAlign === 'left') {
    anchor = 'start';
    anchorX = -boxW / 2;
  } else if (obj.textAlign === 'right') {
    anchor = 'end';
    anchorX = boxW / 2;
  }

  const strokeAttr =
    obj.stroke && obj.strokeWidth > 0
      ? `stroke="${escapeXml(obj.stroke)}" stroke-width="${((obj.strokeWidth / 1000) * canvasW).toFixed(2)}" paint-order="stroke fill"`
      : '';

  const letterSpacingEm = (obj.letterSpacing / 1000).toFixed(4);
  const tspans = lines
    .map((line, index) => {
      const y = firstBaselineY + index * lineStep;
      const content = line.length > 0 ? escapeXml(line) : '&#160;';
      return `<tspan x="${anchorX.toFixed(2)}" y="${y.toFixed(2)}">${content}</tspan>`;
    })
    .join('');

  return `<text text-anchor="${anchor}" font-family="${escapeXml(resolveFontCssStack(obj.fontFamily))}" font-size="${fontSizePx.toFixed(2)}" font-weight="${obj.fontWeight}" font-style="${obj.fontStyle}" letter-spacing="${letterSpacingEm}em" fill="${escapeXml(obj.fill)}" ${strokeAttr}>${tspans}</text>`;
}

async function applyBufferOpacity(pngBuffer: Buffer, opacity: number): Promise<Buffer> {
  if (opacity >= 0.999) {
    return pngBuffer;
  }
  const clamped = Math.max(0, Math.min(1, opacity));
  const { data, info } = await sharp(pngBuffer)
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  for (let i = 3; i < data.length; i += 4) {
    data[i] = Math.round((data[i] ?? 0) * clamped);
  }

  return sharp(data, {
    raw: {
      width: info.width,
      height: info.height,
      channels: 4,
    },
  })
    .png()
    .toBuffer();
}

async function renderImageOverlay(
  obj: CanonicalImageObject,
  boundsPx: { x: number; y: number; width: number; height: number },
  rotationDeg: number,
  opacity: number,
  flipX: boolean,
  flipY: boolean,
  canvasW: number,
  canvasH: number,
  assetsById: ReadonlyMap<string, ResolvedAssetBinaryInfo>,
  storage: StorageService
): Promise<OverlayOptions | null> {
  const asset = assetsById.get(obj.assetId);
  if (!asset) {
    return null;
  }

  const rawBuffer = await storage.getPrivateObject(asset.objectKey);
  const targetW = Math.max(1, Math.round(boundsPx.width));
  const targetH = Math.max(1, Math.round(boundsPx.height));

  let pipeline = sharp(rawBuffer, { limitInputPixels: 100_000_000 }).rotate();
  if (obj.cropRect) {
    const meta = await pipeline.metadata();
    const imgW = meta.width ?? obj.naturalWidthPx;
    const imgH = meta.height ?? obj.naturalHeightPx;
    const left = Math.max(0, Math.min(imgW - 1, Math.round(obj.cropRect.x * imgW)));
    const top = Math.max(0, Math.min(imgH - 1, Math.round(obj.cropRect.y * imgH)));
    const width = Math.max(1, Math.min(imgW - left, Math.round(obj.cropRect.width * imgW)));
    const height = Math.max(1, Math.min(imgH - top, Math.round(obj.cropRect.height * imgH)));
    pipeline = pipeline.extract({ left, top, width, height });
  }

  pipeline = pipeline.resize(targetW, targetH, { fit: 'fill' });
  if (flipX) {
    pipeline = pipeline.flop();
  }
  if (flipY) {
    pipeline = pipeline.flip();
  }
  if (Math.abs(rotationDeg) > 0.01) {
    pipeline = pipeline.rotate(rotationDeg, {
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    });
  }

  let layerBuffer: Buffer = Buffer.from(await pipeline.ensureAlpha().png().toBuffer());
  layerBuffer = await applyBufferOpacity(layerBuffer, opacity);

  const rotatedMeta = await sharp(layerBuffer).metadata();
  const layerW = rotatedMeta.width ?? targetW;
  const layerH = rotatedMeta.height ?? targetH;

  const cx = boundsPx.x + boundsPx.width / 2;
  const cy = boundsPx.y + boundsPx.height / 2;
  const desiredLeft = Math.round(cx - layerW / 2);
  const desiredTop = Math.round(cy - layerH / 2);

  // Clip layer strictly within the transparent surface canvas so out-of-edge fragments never crash sharp.composite.
  const srcLeft = Math.max(0, -desiredLeft);
  const srcTop = Math.max(0, -desiredTop);
  const dstLeft = Math.max(0, desiredLeft);
  const dstTop = Math.max(0, desiredTop);
  const visibleW = Math.min(layerW - srcLeft, canvasW - dstLeft);
  const visibleH = Math.min(layerH - srcTop, canvasH - dstTop);

  if (visibleW <= 0 || visibleH <= 0) {
    return null;
  }

  if (srcLeft > 0 || srcTop > 0 || visibleW < layerW || visibleH < layerH) {
    layerBuffer = await sharp(layerBuffer)
      .extract({
        left: srcLeft,
        top: srcTop,
        width: visibleW,
        height: visibleH,
      })
      .png()
      .toBuffer();
  }

  return {
    input: layerBuffer,
    left: dstLeft,
    top: dstTop,
  };
}

async function renderLeafToOverlay(
  obj: Exclude<CanonicalDesignObject, CanonicalGroupObject>,
  boxInCanvas: { x: number; y: number; width: number; height: number },
  accumulatedRotationDeg: number,
  accumulatedOpacity: number,
  canvasW: number,
  canvasH: number,
  assetsById: ReadonlyMap<string, ResolvedAssetBinaryInfo>,
  storage: StorageService
): Promise<OverlayOptions | null> {
  if (!obj.visible || accumulatedOpacity <= 0) {
    return null;
  }

  if (obj.type === 'image') {
    return renderImageOverlay(
      obj,
      boxInCanvas,
      accumulatedRotationDeg,
      accumulatedOpacity,
      obj.flipX,
      obj.flipY,
      canvasW,
      canvasH,
      assetsById,
      storage
    );
  }

  const cx = boxInCanvas.x + boxInCanvas.width / 2;
  const cy = boxInCanvas.y + boxInCanvas.height / 2;
  const flipSx = obj.flipX ? -1 : 1;
  const flipSy = obj.flipY ? -1 : 1;

  let innerSvg = '';
  if (obj.type === 'shape') {
    innerSvg = renderShapeSvgNode(obj, boxInCanvas.width, boxInCanvas.height, canvasW);
  } else if (obj.type === 'graphic') {
    innerSvg = renderGraphicSvgNode(obj, boxInCanvas.width, boxInCanvas.height, canvasW);
  } else if (obj.type === 'text') {
    // Adjust canonical fontSizeRatio relative to parent scale if nested inside a group
    const scaledTextObj: CanonicalTextObject = {
      ...obj,
      fontSizeRatio: obj.fontSizeRatio,
    };
    innerSvg = renderTextSvgNode(scaledTextObj, boxInCanvas.width, canvasW, canvasH);
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${canvasW}" height="${canvasH}" viewBox="0 0 ${canvasW} ${canvasH}">
    <g opacity="${accumulatedOpacity.toFixed(3)}" transform="translate(${cx.toFixed(2)} ${cy.toFixed(2)}) rotate(${accumulatedRotationDeg.toFixed(2)}) scale(${flipSx} ${flipSy})">
      ${innerSvg}
    </g>
  </svg>`;

  const pngBuffer = await sharp(Buffer.from(svg, 'utf8')).png().toBuffer();
  return {
    input: pngBuffer,
    left: 0,
    top: 0,
  };
}

async function collectOverlays(
  objects: readonly CanonicalDesignObject[],
  parentBox: { x: number; y: number; width: number; height: number },
  parentRotationDeg: number,
  parentOpacity: number,
  canvasW: number,
  canvasH: number,
  assetsById: ReadonlyMap<string, ResolvedAssetBinaryInfo>,
  storage: StorageService,
  out: OverlayOptions[]
): Promise<void> {
  for (const obj of objects) {
    if (!obj.visible) {
      continue;
    }

    const box = {
      x: parentBox.x + obj.x * parentBox.width,
      y: parentBox.y + obj.y * parentBox.height,
      width: obj.width * parentBox.width,
      height: obj.height * parentBox.height,
    };
    const nextOpacity = Math.max(0, Math.min(1, parentOpacity * obj.opacity));
    const nextRotation = parentRotationDeg + obj.rotationDeg;

    if (obj.type === 'group') {
      await collectOverlays(
        obj.children,
        box,
        nextRotation,
        nextOpacity,
        canvasW,
        canvasH,
        assetsById,
        storage,
        out
      );
      continue;
    }

    const overlay = await renderLeafToOverlay(
      obj,
      box,
      nextRotation,
      nextOpacity,
      canvasW,
      canvasH,
      assetsById,
      storage
    );
    if (overlay) {
      out.push(overlay);
    }
  }
}

/**
 * Renders a CanonicalDesignSurface server-side into a transparent RGBA PNG master (`targetDpi`, default 300 DPI)
 * or downscaled owner preview PNG without trusting client browser `toDataURL()` exports.
 */
export async function renderDesignSurfaceToPng(params: {
  surface: CanonicalDesignSurface;
  printArea: ProductPrintAreaDTO;
  assetsById: ReadonlyMap<string, ResolvedAssetBinaryInfo>;
  storage: StorageService;
  mode: 'print_master' | 'preview';
}): Promise<RasterizedSurfaceOutput> {
  const fullSpec = computePrintMasterPixelDimensions(params.printArea);

  let widthPx = fullSpec.widthPx;
  let heightPx = fullSpec.heightPx;
  const dpi = params.mode === 'print_master' ? fullSpec.dpi : 72;

  if (params.mode === 'preview') {
    const maxEdge = 900;
    const scale = Math.min(1, maxEdge / Math.max(widthPx, heightPx));
    widthPx = Math.max(120, Math.round(widthPx * scale));
    heightPx = Math.max(120, Math.round(heightPx * scale));
  }

  const overlays: OverlayOptions[] = [];
  await collectOverlays(
    params.surface.objects,
    { x: 0, y: 0, width: widthPx, height: heightPx },
    0,
    1,
    widthPx,
    heightPx,
    params.assetsById,
    params.storage,
    overlays
  );

  let pipeline = sharp({
    create: {
      width: widthPx,
      height: heightPx,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    },
  });

  if (overlays.length > 0) {
    pipeline = pipeline.composite(overlays);
  }

  const buffer = await pipeline
    .png({ compressionLevel: 9 })
    .withMetadata({ density: dpi })
    .toBuffer();

  const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');

  return {
    buffer,
    widthPx,
    heightPx,
    dpi,
    sha256,
  };
}
