import type { HealthCheckResponse, LivenessResponse } from '@your-choice/shared-types';
import type { ApiEnv } from '../../config/env.js';
import type { DatabasePingFn } from '../../database/health.js';

export interface HealthService {
  getLiveness: () => LivenessResponse;
  getHealth: () => Promise<HealthCheckResponse>;
}

export function createHealthService(
  env: Pick<ApiEnv, 'APP_NAME' | 'APP_VERSION' | 'NODE_ENV'>,
  pingDatabase: DatabasePingFn
): HealthService {
  return {
    getLiveness: (): LivenessResponse => ({
      status: 'alive',
      service: env.APP_NAME,
      timestamp: new Date().toISOString(),
    }),

    getHealth: async (): Promise<HealthCheckResponse> => {
      const database = await pingDatabase();
      const status = database.status === 'up' ? 'healthy' : 'degraded';

      return {
        status,
        service: env.APP_NAME,
        version: env.APP_VERSION,
        environment: env.NODE_ENV,
        uptimeSeconds: Math.floor(process.uptime()),
        timestamp: new Date().toISOString(),
        checks: {
          database,
        },
      };
    },
  };
}
