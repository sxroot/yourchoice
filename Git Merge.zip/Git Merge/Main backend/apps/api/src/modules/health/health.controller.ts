import type { Request, Response } from 'express';
import { sendSuccess } from '../../utils/api-response.js';
import type { HealthService } from './health.service.js';

export function createHealthController(healthService: HealthService) {
  return {
    liveness: (_req: Request, res: Response): void => {
      sendSuccess(res, healthService.getLiveness(), 200);
    },

    health: async (_req: Request, res: Response): Promise<void> => {
      const report = await healthService.getHealth();
      sendSuccess(res, report, 200);
    },

    readiness: async (_req: Request, res: Response): Promise<void> => {
      const report = await healthService.getHealth();
      const statusCode = report.status === 'healthy' ? 200 : 503;
      sendSuccess(res, report, statusCode);
    },
  };
}
