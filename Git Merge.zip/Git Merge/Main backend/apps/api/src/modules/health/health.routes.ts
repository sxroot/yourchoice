import { Router } from 'express';
import { createHealthController } from './health.controller.js';
import type { HealthService } from './health.service.js';

export function createHealthRouter(healthService: HealthService): Router {
  const router = Router();
  const controller = createHealthController(healthService);

  router.get('/', controller.health);
  router.get('/live', controller.liveness);
  router.get('/ready', controller.readiness);

  return router;
}
