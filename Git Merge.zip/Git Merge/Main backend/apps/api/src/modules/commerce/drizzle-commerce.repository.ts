import crypto from 'node:crypto';
import {
  type CartRow,
  type OrderItemRow,
  type OrderRow,
  type OrderStatusHistoryRow,
  type PaymentTransactionRow,
  type ShippingZoneRow,
  cartItems,
  carts,
  orderItems,
  orderStatusHistory,
  orders,
  paymentTransactions,
  productImages,
  productVariants,
  products,
  shippingZones,
} from '@your-choice/database/schema';
import {
  ALLOWED_ORDER_TRANSITIONS,
  type BangladeshDivision,
  CUSTOMER_CANCELLABLE_STATUSES,
  type CartDTO,
  type CartItemDTO,
  type GarmentSizeCode,
  type OrderDetailDTO,
  type OrderStatus,
  type OrderSummaryDTO,
  type PaymentMethod,
  type PaymentStatus,
  type PaymentTransactionStatus,
  type ShippingZoneDTO,
} from '@your-choice/shared-types';
import { decimalToMinorUnits, minorUnitsToDecimal } from '@your-choice/shared-utils';
import type { AdminOrderListQueryInput } from '@your-choice/validation';
import { and, asc, desc, eq, gte, inArray, isNull, like, or, sql } from 'drizzle-orm';
import type { AppDatabase } from '../../database/client.js';
import { ApiError } from '../../utils/api-error.js';
import type {
  AdminSettleCodParams,
  AdminUpdateOrderStatusParams,
  ApplyWebhookPaymentParams,
  CancelOrderParams,
  CartItemCustomizationPayload,
  CommerceOrderListResult,
  CommerceRepository,
  PlaceOrderParams,
  ResolvedCartIdentity,
} from './commerce.repository.js';
import {
  computeEffectiveUnitPrice,
  computeLineTotal,
  computeOrderTotalMinor,
  computeShippingQuote,
  generateOrderNumber,
} from './pricing.js';

function mapShippingZoneRow(row: ShippingZoneRow): ShippingZoneDTO {
  return {
    id: row.publicId,
    code: row.code,
    nameEn: row.nameEn,
    nameBn: row.nameBn,
    divisions: row.divisionsJson,
    flatFee: row.flatFee,
    freeShippingThreshold: row.freeShippingThreshold ?? null,
    estimatedDaysMin: row.estimatedDaysMin,
    estimatedDaysMax: row.estimatedDaysMax,
    currencyCode: row.currencyCode,
    isActive: row.isActive,
  };
}

type DbExecutor = Pick<AppDatabase, 'select' | 'insert' | 'update' | 'delete'>;

export class DrizzleCommerceRepository implements CommerceRepository {
  constructor(private readonly db: AppDatabase) {}

  async listActiveShippingZones(): Promise<ShippingZoneDTO[]> {
    const rows = await this.db
      .select()
      .from(shippingZones)
      .where(eq(shippingZones.isActive, true))
      .orderBy(asc(shippingZones.sortOrder), asc(shippingZones.id));

    return rows.map(mapShippingZoneRow);
  }

  async findShippingZoneByDivision(division: BangladeshDivision): Promise<ShippingZoneDTO | null> {
    const zones = await this.listActiveShippingZones();
    return zones.find((zone) => zone.divisions.includes(division)) ?? null;
  }

  async findCartByUserId(userId: number): Promise<ResolvedCartIdentity | null> {
    const [row] = await this.db
      .select()
      .from(carts)
      .where(eq(carts.userId, userId))
      .orderBy(desc(carts.updatedAt))
      .limit(1);

    if (!row) return null;
    const dto = await this.hydrateCart(this.db, row);
    return { cartId: row.id, cartPublicId: row.publicId, dto };
  }

  async findCartByGuestTokenHash(tokenHash: string): Promise<ResolvedCartIdentity | null> {
    const [row] = await this.db
      .select()
      .from(carts)
      .where(and(eq(carts.guestTokenHash, tokenHash), gte(carts.expiresAt, new Date())))
      .limit(1);

    if (!row) return null;
    const dto = await this.hydrateCart(this.db, row);
    return { cartId: row.id, cartPublicId: row.publicId, dto };
  }

  async createUserCart(userId: number, expiresAt: Date): Promise<ResolvedCartIdentity> {
    const publicId = crypto.randomUUID();
    const [res] = await this.db.insert(carts).values({
      publicId,
      userId,
      guestTokenHash: null,
      currencyCode: 'BDT',
      expiresAt,
    });
    const [created] = await this.db.select().from(carts).where(eq(carts.id, res.insertId)).limit(1);

    const dto = await this.hydrateCart(this.db, created!);
    return { cartId: created!.id, cartPublicId: created!.publicId, dto };
  }

  async createGuestCart(tokenHash: string, expiresAt: Date): Promise<ResolvedCartIdentity> {
    const publicId = crypto.randomUUID();
    const [res] = await this.db.insert(carts).values({
      publicId,
      userId: null,
      guestTokenHash: tokenHash,
      currencyCode: 'BDT',
      expiresAt,
    });
    const [created] = await this.db.select().from(carts).where(eq(carts.id, res.insertId)).limit(1);

    const dto = await this.hydrateCart(this.db, created!);
    return { cartId: created!.id, cartPublicId: created!.publicId, dto };
  }

  async upsertCartItem(
    cartId: number,
    variantPublicId: string,
    quantityToAdd: number,
    customization?: CartItemCustomizationPayload
  ): Promise<CartDTO> {
    return this.db.transaction(async (tx) => {
      const [variantJoin] = await tx
        .select({
          variant: productVariants,
          product: products,
        })
        .from(productVariants)
        .innerJoin(products, eq(productVariants.productId, products.id))
        .where(
          and(
            eq(productVariants.publicId, variantPublicId),
            isNull(productVariants.deletedAt),
            isNull(products.deletedAt)
          )
        )
        .limit(1);

      if (!variantJoin) {
        throw ApiError.notFound('Product variant not found');
      }

      const { variant, product } = variantJoin;
      if (!variant.isActive || product.status !== 'active') {
        throw ApiError.conflict(
          'VARIANT_UNAVAILABLE',
          'Product variant is currently unavailable for purchase'
        );
      }

      const itemKey = customization
        ? `variant:${variant.id}:design:${customization.designPublicId}:v${customization.designVersionNumber}`
        : `variant:${variant.id}`;
      const [existing] = await tx
        .select()
        .from(cartItems)
        .where(and(eq(cartItems.cartId, cartId), eq(cartItems.itemKey, itemKey)))
        .limit(1);

      const nextQty = (existing?.quantity ?? 0) + quantityToAdd;
      if (nextQty > 50) {
        throw ApiError.badRequest('Maximum 50 units per SKU line in cart');
      }
      if (variant.stockQuantity < nextQty) {
        throw ApiError.conflict(
          'INSUFFICIENT_STOCK',
          variant.stockQuantity === 0
            ? 'Selected variant is out of stock'
            : `Only ${variant.stockQuantity} unit(s) available in stock`
        );
      }

      const unitPrice = computeEffectiveUnitPrice(product.basePrice, variant.priceOverride);

      if (existing) {
        await tx
          .update(cartItems)
          .set({
            quantity: nextQty,
            unitPriceSnapshot: unitPrice,
            customizationFee: customization?.customizationFee ?? existing.customizationFee,
            customizationMetaJson:
              customization?.customizationMeta ?? existing.customizationMetaJson,
            updatedAt: new Date(),
          })
          .where(eq(cartItems.id, existing.id));
      } else {
        await tx.insert(cartItems).values({
          publicId: crypto.randomUUID(),
          cartId,
          variantId: variant.id,
          itemKey,
          quantity: nextQty,
          unitPriceSnapshot: unitPrice,
          customizationFee: customization?.customizationFee ?? '0.00',
          currencyCode: product.currencyCode,
          designPublicId: customization?.designPublicId ?? null,
          customizationMetaJson: customization?.customizationMeta ?? null,
        });
      }

      const [cartRow] = await tx.select().from(carts).where(eq(carts.id, cartId)).limit(1);
      return this.hydrateCart(tx, cartRow!);
    });
  }

  async updateCartItemQuantity(
    cartId: number,
    itemPublicId: string,
    quantity: number
  ): Promise<CartDTO> {
    return this.db.transaction(async (tx) => {
      const [itemRow] = await tx
        .select()
        .from(cartItems)
        .where(and(eq(cartItems.cartId, cartId), eq(cartItems.publicId, itemPublicId)))
        .limit(1);

      if (!itemRow) {
        throw ApiError.notFound('Cart item not found');
      }

      const [variantJoin] = await tx
        .select({ variant: productVariants, product: products })
        .from(productVariants)
        .innerJoin(products, eq(productVariants.productId, products.id))
        .where(
          and(
            eq(productVariants.id, itemRow.variantId),
            isNull(productVariants.deletedAt),
            isNull(products.deletedAt)
          )
        )
        .limit(1);

      if (
        !variantJoin ||
        !variantJoin.variant.isActive ||
        variantJoin.product.status !== 'active'
      ) {
        throw ApiError.conflict(
          'VARIANT_UNAVAILABLE',
          'This product variant is no longer available'
        );
      }

      if (variantJoin.variant.stockQuantity < quantity) {
        throw ApiError.conflict(
          'INSUFFICIENT_STOCK',
          `Only ${variantJoin.variant.stockQuantity} unit(s) available in stock`
        );
      }

      const unitPrice = computeEffectiveUnitPrice(
        variantJoin.product.basePrice,
        variantJoin.variant.priceOverride
      );

      await tx
        .update(cartItems)
        .set({ quantity, unitPriceSnapshot: unitPrice, updatedAt: new Date() })
        .where(eq(cartItems.id, itemRow.id));

      const [cartRow] = await tx.select().from(carts).where(eq(carts.id, cartId)).limit(1);
      return this.hydrateCart(tx, cartRow!);
    });
  }

  async removeCartItem(cartId: number, itemPublicId: string): Promise<CartDTO> {
    await this.db
      .delete(cartItems)
      .where(and(eq(cartItems.cartId, cartId), eq(cartItems.publicId, itemPublicId)));

    const [cartRow] = await this.db.select().from(carts).where(eq(carts.id, cartId)).limit(1);
    return this.hydrateCart(this.db, cartRow!);
  }

  async clearCart(cartId: number): Promise<CartDTO> {
    await this.db.delete(cartItems).where(eq(cartItems.cartId, cartId));
    const [cartRow] = await this.db.select().from(carts).where(eq(carts.id, cartId)).limit(1);
    return this.hydrateCart(this.db, cartRow!);
  }

  async mergeGuestCartToUser(
    guestTokenHash: string,
    userId: number,
    expiresAt: Date
  ): Promise<void> {
    await this.db.transaction(async (tx) => {
      const [guestCart] = await tx
        .select()
        .from(carts)
        .where(eq(carts.guestTokenHash, guestTokenHash))
        .limit(1);

      if (!guestCart) return;

      const [existingUserCart] = await tx
        .select()
        .from(carts)
        .where(eq(carts.userId, userId))
        .limit(1);

      if (!existingUserCart) {
        await tx
          .update(carts)
          .set({ userId, guestTokenHash: null, expiresAt, updatedAt: new Date() })
          .where(eq(carts.id, guestCart.id));
        return;
      }

      const guestItems = await tx
        .select()
        .from(cartItems)
        .where(eq(cartItems.cartId, guestCart.id));

      for (const guestItem of guestItems) {
        const [variantRow] = await tx
          .select()
          .from(productVariants)
          .where(
            and(eq(productVariants.id, guestItem.variantId), isNull(productVariants.deletedAt))
          )
          .limit(1);

        if (!variantRow || !variantRow.isActive || variantRow.stockQuantity <= 0) {
          continue;
        }

        const [targetItem] = await tx
          .select()
          .from(cartItems)
          .where(
            and(eq(cartItems.cartId, existingUserCart.id), eq(cartItems.itemKey, guestItem.itemKey))
          )
          .limit(1);

        const combinedQty = Math.min(
          50,
          variantRow.stockQuantity,
          (targetItem?.quantity ?? 0) + guestItem.quantity
        );

        if (targetItem) {
          await tx
            .update(cartItems)
            .set({ quantity: combinedQty, updatedAt: new Date() })
            .where(eq(cartItems.id, targetItem.id));
        } else {
          await tx.insert(cartItems).values({
            publicId: crypto.randomUUID(),
            cartId: existingUserCart.id,
            variantId: guestItem.variantId,
            itemKey: guestItem.itemKey,
            quantity: combinedQty,
            unitPriceSnapshot: guestItem.unitPriceSnapshot,
            customizationFee: guestItem.customizationFee,
            currencyCode: guestItem.currencyCode,
            designPublicId: guestItem.designPublicId,
            customizationMetaJson: guestItem.customizationMetaJson,
          });
        }
      }

      await tx.delete(carts).where(eq(carts.id, guestCart.id));
    });
  }

  async placeOrderTransactionally(params: PlaceOrderParams): Promise<OrderDetailDTO> {
    return this.db.transaction(async (tx) => {
      const [zoneRow] = await tx
        .select()
        .from(shippingZones)
        .where(
          and(eq(shippingZones.code, params.shippingZoneCode), eq(shippingZones.isActive, true))
        )
        .limit(1);

      if (!zoneRow) {
        throw ApiError.badRequest('Configured shipping zone is unavailable for selected division');
      }

      const items = await tx
        .select()
        .from(cartItems)
        .where(eq(cartItems.cartId, params.cartId))
        .orderBy(asc(cartItems.createdAt));

      if (items.length === 0) {
        throw ApiError.badRequest('Your shopping cart is empty');
      }

      let subtotalMinor = 0n;
      const preparedSnapshots: Array<{
        productId: number;
        variantId: number;
        productNameEn: string;
        productNameBn: string;
        productSlug: string;
        sku: string;
        colorNameEn: string;
        colorNameBn: string;
        colorHex: string;
        sizeCode: string;
        primaryImageUrl: string | null;
        quantity: number;
        unitPrice: string;
        customizationFee: string;
        lineTotal: string;
        currencyCode: string;
        designPublicId: string | null;
        designTitleSnapshot: string | null;
        productionSpecJson: OrderItemRow['productionSpecJson'];
      }> = [];

      for (const line of items) {
        const [variantJoin] = await tx
          .select({ variant: productVariants, product: products })
          .from(productVariants)
          .innerJoin(products, eq(productVariants.productId, products.id))
          .where(
            and(
              eq(productVariants.id, line.variantId),
              isNull(productVariants.deletedAt),
              isNull(products.deletedAt)
            )
          )
          .limit(1);

        if (
          !variantJoin ||
          !variantJoin.variant.isActive ||
          variantJoin.product.status !== 'active'
        ) {
          throw ApiError.conflict(
            'VARIANT_UNAVAILABLE',
            'One or more cart items are no longer active for purchase'
          );
        }

        // Atomic conditional stock decrement prevents overselling under concurrent requests.
        const [decrementHeader] = await tx
          .update(productVariants)
          .set({
            stockQuantity: sql`${productVariants.stockQuantity} - ${line.quantity}`,
            updatedAt: new Date(),
          })
          .where(
            and(
              eq(productVariants.id, variantJoin.variant.id),
              gte(productVariants.stockQuantity, line.quantity)
            )
          );

        if ((decrementHeader.affectedRows ?? 0) === 0) {
          throw ApiError.conflict(
            'INSUFFICIENT_STOCK',
            `Insufficient stock for SKU ${variantJoin.variant.sku}. Only ${variantJoin.variant.stockQuantity} unit(s) left.`
          );
        }

        const [primaryImage] = await tx
          .select()
          .from(productImages)
          .where(eq(productImages.productId, variantJoin.product.id))
          .orderBy(desc(productImages.isPrimary), asc(productImages.sortOrder))
          .limit(1);

        const unitPrice = computeEffectiveUnitPrice(
          variantJoin.product.basePrice,
          variantJoin.variant.priceOverride
        );
        const lineTotal = computeLineTotal(unitPrice, line.customizationFee, line.quantity);
        subtotalMinor += decimalToMinorUnits(lineTotal);

        preparedSnapshots.push({
          productId: variantJoin.product.id,
          variantId: variantJoin.variant.id,
          productNameEn: variantJoin.product.nameEn,
          productNameBn: variantJoin.product.nameBn,
          productSlug: variantJoin.product.slug,
          sku: variantJoin.variant.sku,
          colorNameEn: variantJoin.variant.colorNameEn,
          colorNameBn: variantJoin.variant.colorNameBn,
          colorHex: variantJoin.variant.colorHex,
          sizeCode: variantJoin.variant.sizeCode,
          primaryImageUrl: primaryImage?.url ?? null,
          quantity: line.quantity,
          unitPrice,
          customizationFee: line.customizationFee,
          lineTotal,
          currencyCode: variantJoin.product.currencyCode,
          designPublicId: line.designPublicId ?? null,
          designTitleSnapshot: line.customizationMetaJson?.designTitle ?? null,
          productionSpecJson: line.customizationMetaJson
            ? {
                printMethod: 'dtf',
                targetDpi: 300,
                surfaces: line.customizationMetaJson.surfaces.map((s) => ({
                  surfaceKey: s.surfaceKey,
                  labelEn: s.labelEn,
                  labelBn: s.labelBn,
                  printReadyAssetRef: s.previewImageRef ?? null,
                })),
              }
            : null,
        });
      }

      const zoneDto = mapShippingZoneRow(zoneRow);
      const quote = computeShippingQuote(
        params.shippingAddress.division,
        zoneDto,
        minorUnitsToDecimal(subtotalMinor)
      );
      const shippingMinor = decimalToMinorUnits(quote.shippingFee);
      const totalAmount = minorUnitsToDecimal(computeOrderTotalMinor(subtotalMinor, shippingMinor));
      const orderNumber = generateOrderNumber();

      const [orderInsert] = await tx.insert(orders).values({
        publicId: crypto.randomUUID(),
        orderNumber,
        userId: params.userId,
        customerEmail: params.customerEmail.toLowerCase(),
        customerPhone: params.customerPhone,
        shippingAddressJson: params.shippingAddress,
        shippingZoneCode: zoneDto.code,
        shippingZoneNameSnapshot: zoneDto.nameEn,
        paymentMethod: params.paymentMethod,
        paymentStatus: 'unpaid',
        orderStatus: 'pending',
        subtotalAmount: quote.subtotal,
        shippingAmount: quote.shippingFee,
        discountAmount: '0.00',
        totalAmount,
        currencyCode: zoneDto.currencyCode,
        customerNote: params.customerNote,
      });

      const orderId = orderInsert.insertId;

      for (const snap of preparedSnapshots) {
        await tx.insert(orderItems).values({
          publicId: crypto.randomUUID(),
          orderId,
          productId: snap.productId,
          variantId: snap.variantId,
          productNameEnSnapshot: snap.productNameEn,
          productNameBnSnapshot: snap.productNameBn,
          productSlugSnapshot: snap.productSlug,
          skuSnapshot: snap.sku,
          colorNameEnSnapshot: snap.colorNameEn,
          colorNameBnSnapshot: snap.colorNameBn,
          colorHexSnapshot: snap.colorHex,
          sizeCodeSnapshot: snap.sizeCode,
          primaryImageUrlSnapshot: snap.primaryImageUrl,
          quantity: snap.quantity,
          unitPrice: snap.unitPrice,
          customizationFee: snap.customizationFee,
          lineTotal: snap.lineTotal,
          currencyCode: snap.currencyCode,
          designPublicId: snap.designPublicId,
          designTitleSnapshot: snap.designTitleSnapshot,
          productionSpecJson: snap.productionSpecJson,
        });
      }

      await tx.insert(orderStatusHistory).values({
        orderId,
        fromStatus: null,
        toStatus: 'pending',
        changedByUserId: params.userId,
        actorRole: params.actorRole,
        note: 'Order placed via checkout',
      });

      await tx.insert(paymentTransactions).values({
        publicId: crypto.randomUUID(),
        orderId,
        gateway: params.paymentMethod,
        transactionRef: params.paymentMethod === 'cod' ? `COD-${orderNumber}` : null,
        providerPaymentId: null,
        amount: totalAmount,
        currencyCode: zoneDto.currencyCode,
        status: params.paymentMethod === 'cod' ? 'unpaid' : 'pending',
        verificationSource: params.paymentMethod === 'cod' ? 'cod_promise' : null,
        rawPayloadJson: null,
        verifiedAt: null,
      });

      await tx.delete(cartItems).where(eq(cartItems.cartId, params.cartId));

      const hydrated = await this.hydrateOrderById(tx, orderId);
      return hydrated!;
    });
  }

  async listOrdersByUserId(
    userId: number,
    page: number,
    pageSize: number
  ): Promise<CommerceOrderListResult> {
    const offset = (page - 1) * pageSize;
    const allRows = await this.db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt), desc(orders.id));

    const slice = allRows.slice(offset, offset + pageSize);
    const summaries = await this.hydrateOrderSummaries(this.db, slice);

    return {
      orders: summaries,
      pagination: {
        page,
        pageSize,
        totalItems: allRows.length,
        totalPages: Math.max(1, Math.ceil(allRows.length / pageSize)),
      },
    };
  }

  async findOrderByNumber(orderNumber: string): Promise<{
    ownerUserId: number | null;
    order: OrderDetailDTO;
  } | null> {
    const [row] = await this.db
      .select()
      .from(orders)
      .where(eq(orders.orderNumber, orderNumber))
      .limit(1);

    if (!row) return null;
    const detail = await this.hydrateOrderById(this.db, row.id);
    if (!detail) return null;

    return {
      ownerUserId: row.userId ?? null,
      order: detail,
    };
  }

  async cancelOrderTransactionally(params: CancelOrderParams): Promise<OrderDetailDTO> {
    return this.db.transaction(async (tx) => {
      const [row] = await tx
        .select()
        .from(orders)
        .where(eq(orders.orderNumber, params.orderNumber))
        .limit(1);

      if (!row) {
        throw ApiError.notFound('Order not found');
      }

      if (params.isCustomerSelfService && row.userId !== params.actorUserId) {
        throw ApiError.forbidden('You do not have permission to cancel this order');
      }

      const currentStatus = row.orderStatus as OrderStatus;
      if (params.isCustomerSelfService) {
        if (!CUSTOMER_CANCELLABLE_STATUSES.includes(currentStatus)) {
          throw ApiError.conflict(
            'ORDER_NOT_CANCELLABLE',
            `Order in status "${currentStatus}" can no longer be cancelled self-service`
          );
        }
      } else if (!ALLOWED_ORDER_TRANSITIONS[currentStatus].includes('cancelled')) {
        throw ApiError.conflict(
          'ORDER_STATUS_CONFLICT',
          `Cannot cancel order in status "${currentStatus}"`
        );
      }

      await this.restoreOrderStock(tx, row.id);

      const now = new Date();
      await tx
        .update(orders)
        .set({
          orderStatus: 'cancelled',
          cancelledAt: now,
          cancellationReason: params.reason,
          updatedAt: now,
        })
        .where(eq(orders.id, row.id));

      await tx.insert(orderStatusHistory).values({
        orderId: row.id,
        fromStatus: currentStatus,
        toStatus: 'cancelled',
        changedByUserId: params.actorUserId,
        actorRole: params.actorRole,
        note: params.reason ?? 'Order cancelled and inventory restored',
      });

      const hydrated = await this.hydrateOrderById(tx, row.id);
      return hydrated!;
    });
  }

  async adminListOrders(query: AdminOrderListQueryInput): Promise<CommerceOrderListResult> {
    const conditions = [];
    if (query.status) {
      conditions.push(eq(orders.orderStatus, query.status));
    }
    if (query.search && query.search.trim().length > 0) {
      const pattern = `%${query.search.trim()}%`;
      conditions.push(
        or(
          like(orders.orderNumber, pattern),
          like(orders.customerEmail, pattern),
          like(orders.customerPhone, pattern)
        )
      );
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
    const allRows = await this.db
      .select()
      .from(orders)
      .where(whereClause)
      .orderBy(desc(orders.createdAt), desc(orders.id));

    const offset = (query.page - 1) * query.pageSize;
    const slice = allRows.slice(offset, offset + query.pageSize);
    const summaries = await this.hydrateOrderSummaries(this.db, slice);

    return {
      orders: summaries,
      pagination: {
        page: query.page,
        pageSize: query.pageSize,
        totalItems: allRows.length,
        totalPages: Math.max(1, Math.ceil(allRows.length / query.pageSize)),
      },
    };
  }

  async adminUpdateOrderStatus(params: AdminUpdateOrderStatusParams): Promise<OrderDetailDTO> {
    if (params.toStatus === 'cancelled') {
      return this.cancelOrderTransactionally({
        orderNumber: params.orderNumber,
        actorUserId: params.actorUserId,
        actorRole: params.actorRole,
        reason: params.note,
        isCustomerSelfService: false,
      });
    }

    return this.db.transaction(async (tx) => {
      const [row] = await tx
        .select()
        .from(orders)
        .where(eq(orders.orderNumber, params.orderNumber))
        .limit(1);

      if (!row) {
        throw ApiError.notFound('Order not found');
      }

      const currentStatus = row.orderStatus as OrderStatus;
      if (!ALLOWED_ORDER_TRANSITIONS[currentStatus].includes(params.toStatus)) {
        throw ApiError.conflict(
          'ORDER_STATUS_CONFLICT',
          `Invalid order status transition from "${currentStatus}" to "${params.toStatus}"`
        );
      }

      await tx
        .update(orders)
        .set({ orderStatus: params.toStatus, updatedAt: new Date() })
        .where(eq(orders.id, row.id));

      await tx.insert(orderStatusHistory).values({
        orderId: row.id,
        fromStatus: currentStatus,
        toStatus: params.toStatus,
        changedByUserId: params.actorUserId,
        actorRole: params.actorRole,
        note: params.note,
      });

      const hydrated = await this.hydrateOrderById(tx, row.id);
      return hydrated!;
    });
  }

  async adminSettleCodPayment(params: AdminSettleCodParams): Promise<OrderDetailDTO> {
    return this.db.transaction(async (tx) => {
      const [row] = await tx
        .select()
        .from(orders)
        .where(eq(orders.orderNumber, params.orderNumber))
        .limit(1);

      if (!row) {
        throw ApiError.notFound('Order not found');
      }
      if (row.paymentMethod !== 'cod') {
        throw ApiError.conflict(
          'PAYMENT_SETTLEMENT_CONFLICT',
          'Only Cash-on-Delivery orders can be manually settled here'
        );
      }
      if (row.orderStatus === 'cancelled') {
        throw ApiError.conflict(
          'ORDER_STATUS_CONFLICT',
          'Cannot settle payment for a cancelled order'
        );
      }

      const now = new Date();
      await tx
        .update(orders)
        .set({ paymentStatus: 'paid', updatedAt: now })
        .where(eq(orders.id, row.id));

      await tx
        .update(paymentTransactions)
        .set({
          transactionRef: params.transactionRef,
          status: 'paid',
          verificationSource: 'admin_settlement',
          verifiedAt: now,
          updatedAt: now,
        })
        .where(eq(paymentTransactions.orderId, row.id));

      await tx.insert(orderStatusHistory).values({
        orderId: row.id,
        fromStatus: row.orderStatus,
        toStatus: row.orderStatus,
        changedByUserId: params.actorUserId,
        actorRole: params.actorRole,
        note: params.note ?? `COD cash collection verified (${params.transactionRef})`,
      });

      const hydrated = await this.hydrateOrderById(tx, row.id);
      return hydrated!;
    });
  }

  async applyVerifiedPaymentWebhook(params: ApplyWebhookPaymentParams): Promise<{
    order: OrderDetailDTO;
    paymentStatus: PaymentStatus;
    idempotentReplay: boolean;
  }> {
    return this.db.transaction(async (tx) => {
      const [row] = await tx
        .select()
        .from(orders)
        .where(eq(orders.orderNumber, params.orderNumber))
        .limit(1);

      if (!row) {
        throw ApiError.notFound('Order referenced by webhook not found');
      }
      if (row.paymentMethod !== params.gateway) {
        throw ApiError.conflict('WEBHOOK_GATEWAY_MISMATCH', 'Order payment gateway mismatch');
      }

      const expectedMinor = decimalToMinorUnits(row.totalAmount);
      const webhookMinor = decimalToMinorUnits(params.amount);
      if (
        expectedMinor !== webhookMinor ||
        row.currencyCode.toUpperCase() !== params.currencyCode.toUpperCase()
      ) {
        throw ApiError.conflict(
          'WEBHOOK_AMOUNT_MISMATCH',
          'Webhook payment amount or currency does not match order total'
        );
      }

      const [existingTx] = await tx
        .select()
        .from(paymentTransactions)
        .where(
          and(
            eq(paymentTransactions.gateway, params.gateway),
            eq(paymentTransactions.transactionRef, params.transactionRef)
          )
        )
        .limit(1);

      if (existingTx && existingTx.status === params.nextTransactionStatus) {
        const hydrated = await this.hydrateOrderById(tx, row.id);
        return {
          order: hydrated!,
          paymentStatus: row.paymentStatus as PaymentStatus,
          idempotentReplay: true,
        };
      }

      const nextOrderPaymentStatus: PaymentStatus =
        params.nextTransactionStatus === 'paid' ? 'paid' : 'failed';
      const now = new Date();

      await tx
        .update(paymentTransactions)
        .set({
          transactionRef: params.transactionRef,
          providerPaymentId: params.providerPaymentId,
          status: params.nextTransactionStatus,
          verificationSource: 'gateway_webhook',
          rawPayloadJson: params.rawPayload,
          verifiedAt: now,
          updatedAt: now,
        })
        .where(eq(paymentTransactions.orderId, row.id));

      const shouldAutoConfirm = nextOrderPaymentStatus === 'paid' && row.orderStatus === 'pending';

      await tx
        .update(orders)
        .set({
          paymentStatus: nextOrderPaymentStatus,
          orderStatus: shouldAutoConfirm ? 'confirmed' : row.orderStatus,
          updatedAt: now,
        })
        .where(eq(orders.id, row.id));

      if (shouldAutoConfirm) {
        await tx.insert(orderStatusHistory).values({
          orderId: row.id,
          fromStatus: 'pending',
          toStatus: 'confirmed',
          changedByUserId: null,
          actorRole: `gateway:${params.gateway}`,
          note: `Payment verified via signed ${params.gateway} webhook (${params.transactionRef})`,
        });
      }

      const hydrated = await this.hydrateOrderById(tx, row.id);
      return {
        order: hydrated!,
        paymentStatus: nextOrderPaymentStatus,
        idempotentReplay: false,
      };
    });
  }

  private async restoreOrderStock(tx: DbExecutor, orderId: number): Promise<void> {
    const items = await tx.select().from(orderItems).where(eq(orderItems.orderId, orderId));

    for (const item of items) {
      await tx
        .update(productVariants)
        .set({
          stockQuantity: sql`${productVariants.stockQuantity} + ${item.quantity}`,
          updatedAt: new Date(),
        })
        .where(eq(productVariants.id, item.variantId));
    }
  }

  private async hydrateCart(executor: DbExecutor, cartRow: CartRow): Promise<CartDTO> {
    const rows = await executor
      .select({
        item: cartItems,
        variant: productVariants,
        product: products,
      })
      .from(cartItems)
      .innerJoin(productVariants, eq(cartItems.variantId, productVariants.id))
      .innerJoin(products, eq(productVariants.productId, products.id))
      .where(eq(cartItems.cartId, cartRow.id))
      .orderBy(asc(cartItems.createdAt), asc(cartItems.id));

    const productIds = Array.from(new Set(rows.map((r) => r.product.id)));
    const imageMap = new Map<number, string>();
    if (productIds.length > 0) {
      const imgs = await executor
        .select()
        .from(productImages)
        .where(inArray(productImages.productId, productIds))
        .orderBy(desc(productImages.isPrimary), asc(productImages.sortOrder));

      for (const img of imgs) {
        if (!imageMap.has(img.productId)) {
          imageMap.set(img.productId, img.url);
        }
      }
    }

    let subtotalMinor = 0n;
    let itemCount = 0;
    let hasUnavailableItems = false;

    const hydratedItems: CartItemDTO[] = rows.map(({ item, variant, product }) => {
      const isVariantAvailable =
        variant.deletedAt === null &&
        product.deletedAt === null &&
        variant.isActive &&
        product.status === 'active' &&
        variant.stockQuantity >= item.quantity;

      if (!isVariantAvailable) {
        hasUnavailableItems = true;
      }

      const unitPrice = computeEffectiveUnitPrice(product.basePrice, variant.priceOverride);
      const lineTotal = computeLineTotal(unitPrice, item.customizationFee, item.quantity);

      subtotalMinor += decimalToMinorUnits(lineTotal);
      itemCount += item.quantity;

      return {
        id: item.publicId,
        variantId: variant.publicId,
        productId: product.publicId,
        productSlug: product.slug,
        productNameEn: product.nameEn,
        productNameBn: product.nameBn,
        sku: variant.sku,
        colorNameEn: variant.colorNameEn,
        colorNameBn: variant.colorNameBn,
        colorHex: variant.colorHex,
        sizeCode: variant.sizeCode as GarmentSizeCode,
        primaryImageUrl: imageMap.get(product.id) ?? null,
        quantity: item.quantity,
        availableStock: variant.stockQuantity,
        isVariantAvailable,
        unitPrice,
        customizationFee: item.customizationFee,
        lineTotal,
        currencyCode: product.currencyCode,
        designPublicId: item.designPublicId ?? null,
        customizationMeta: item.customizationMetaJson ?? null,
      };
    });

    return {
      id: cartRow.publicId,
      items: hydratedItems,
      itemCount,
      subtotal: minorUnitsToDecimal(subtotalMinor),
      currencyCode: cartRow.currencyCode,
      hasUnavailableItems,
      expiresAt: cartRow.expiresAt.toISOString(),
    };
  }

  private async hydrateOrderSummaries(
    executor: DbExecutor,
    orderRows: OrderRow[]
  ): Promise<OrderSummaryDTO[]> {
    if (orderRows.length === 0) return [];

    const orderIds = orderRows.map((o) => o.id);
    const items = await executor
      .select({ orderId: orderItems.orderId, quantity: orderItems.quantity })
      .from(orderItems)
      .where(inArray(orderItems.orderId, orderIds));

    const countsByOrder = new Map<number, number>();
    for (const item of items) {
      countsByOrder.set(item.orderId, (countsByOrder.get(item.orderId) ?? 0) + item.quantity);
    }

    return orderRows.map((row) => ({
      id: row.publicId,
      orderNumber: row.orderNumber,
      customerEmail: row.customerEmail,
      customerPhone: row.customerPhone,
      shippingDivision: row.shippingAddressJson.division,
      shippingZoneCode: row.shippingZoneCode,
      shippingZoneName: row.shippingZoneNameSnapshot,
      paymentMethod: row.paymentMethod as PaymentMethod,
      paymentStatus: row.paymentStatus as PaymentStatus,
      orderStatus: row.orderStatus as OrderStatus,
      subtotalAmount: row.subtotalAmount,
      shippingAmount: row.shippingAmount,
      discountAmount: row.discountAmount,
      totalAmount: row.totalAmount,
      currencyCode: row.currencyCode,
      itemCount: countsByOrder.get(row.id) ?? 0,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    }));
  }

  private async hydrateOrderById(
    executor: DbExecutor,
    orderId: number
  ): Promise<OrderDetailDTO | null> {
    const [row] = await executor.select().from(orders).where(eq(orders.id, orderId)).limit(1);

    if (!row) return null;

    const itemRows: OrderItemRow[] = await executor
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, orderId))
      .orderBy(asc(orderItems.id));

    const historyRows: OrderStatusHistoryRow[] = await executor
      .select()
      .from(orderStatusHistory)
      .where(eq(orderStatusHistory.orderId, orderId))
      .orderBy(asc(orderStatusHistory.createdAt), asc(orderStatusHistory.id));

    const paymentRows: PaymentTransactionRow[] = await executor
      .select()
      .from(paymentTransactions)
      .where(eq(paymentTransactions.orderId, orderId))
      .orderBy(asc(paymentTransactions.createdAt), asc(paymentTransactions.id));

    const status = row.orderStatus as OrderStatus;
    const itemCount = itemRows.reduce((sum, item) => sum + item.quantity, 0);

    return {
      id: row.publicId,
      orderNumber: row.orderNumber,
      customerEmail: row.customerEmail,
      customerPhone: row.customerPhone,
      shippingDivision: row.shippingAddressJson.division,
      shippingZoneCode: row.shippingZoneCode,
      shippingZoneName: row.shippingZoneNameSnapshot,
      paymentMethod: row.paymentMethod as PaymentMethod,
      paymentStatus: row.paymentStatus as PaymentStatus,
      orderStatus: status,
      subtotalAmount: row.subtotalAmount,
      shippingAmount: row.shippingAmount,
      discountAmount: row.discountAmount,
      totalAmount: row.totalAmount,
      currencyCode: row.currencyCode,
      itemCount,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
      shippingAddress: row.shippingAddressJson,
      customerNote: row.customerNote ?? null,
      cancelledAt: row.cancelledAt ? row.cancelledAt.toISOString() : null,
      cancellationReason: row.cancellationReason ?? null,
      canCustomerCancel: CUSTOMER_CANCELLABLE_STATUSES.includes(status),
      allowedNextStatuses: [...ALLOWED_ORDER_TRANSITIONS[status]],
      items: itemRows.map((item) => ({
        id: item.publicId,
        productSlug: item.productSlugSnapshot,
        productNameEn: item.productNameEnSnapshot,
        productNameBn: item.productNameBnSnapshot,
        sku: item.skuSnapshot,
        colorNameEn: item.colorNameEnSnapshot,
        colorNameBn: item.colorNameBnSnapshot,
        colorHex: item.colorHexSnapshot,
        sizeCode: item.sizeCodeSnapshot,
        primaryImageUrl: item.primaryImageUrlSnapshot ?? null,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        customizationFee: item.customizationFee,
        lineTotal: item.lineTotal,
        currencyCode: item.currencyCode,
        designPublicId: item.designPublicId ?? null,
        designTitle: item.designTitleSnapshot ?? null,
        productionSpec: item.productionSpecJson ?? null,
      })),
      statusHistory: historyRows.map((entry) => ({
        id: entry.id,
        fromStatus: (entry.fromStatus as OrderStatus | null) ?? null,
        toStatus: entry.toStatus as OrderStatus,
        actorRole: entry.actorRole ?? null,
        note: entry.note ?? null,
        createdAt: entry.createdAt.toISOString(),
      })),
      paymentTransactions: paymentRows.map((txRow) => ({
        id: txRow.publicId,
        gateway: txRow.gateway as PaymentMethod,
        transactionRef: txRow.transactionRef ?? null,
        providerPaymentId: txRow.providerPaymentId ?? null,
        amount: txRow.amount,
        currencyCode: txRow.currencyCode,
        status: txRow.status as PaymentTransactionStatus,
        verificationSource: txRow.verificationSource ?? null,
        verifiedAt: txRow.verifiedAt ? txRow.verifiedAt.toISOString() : null,
        createdAt: txRow.createdAt.toISOString(),
      })),
    };
  }
}
