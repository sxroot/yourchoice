import type {
  BangladeshDivision,
  CartDTO,
  CartItemCustomizationDTO,
  OrderDetailDTO,
  OrderItemProductionSpecDTO,
  OrderStatus,
  OrderSummaryDTO,
  PaginationMeta,
  PaymentMethod,
  PaymentStatus,
  PaymentTransactionStatus,
  ShippingAddressSnapshotDTO,
  ShippingZoneDTO,
} from '@your-choice/shared-types';

export interface CartItemCustomizationPayload {
  designPublicId: string;
  designTitle: string;
  designVersionNumber: number;
  customizationFee: string;
  customizationMeta: CartItemCustomizationDTO;
  productionSpecPreview?: OrderItemProductionSpecDTO | null;
}
import type { AdminOrderListQueryInput } from '@your-choice/validation';

export interface PlaceOrderParams {
  userId: number | null;
  cartId: number;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: ShippingAddressSnapshotDTO;
  shippingZoneCode: string;
  paymentMethod: PaymentMethod;
  customerNote: string | null;
  actorRole: string;
}

export interface CancelOrderParams {
  orderNumber: string;
  actorUserId: number;
  actorRole: string;
  reason: string | null;
  isCustomerSelfService: boolean;
}

export interface AdminUpdateOrderStatusParams {
  orderNumber: string;
  toStatus: OrderStatus;
  actorUserId: number;
  actorRole: string;
  note: string | null;
}

export interface AdminSettleCodParams {
  orderNumber: string;
  transactionRef: string;
  actorUserId: number;
  actorRole: string;
  note: string | null;
}

export interface ApplyWebhookPaymentParams {
  orderNumber: string;
  gateway: Exclude<PaymentMethod, 'cod'>;
  providerPaymentId: string;
  transactionRef: string;
  nextTransactionStatus: Extract<PaymentTransactionStatus, 'paid' | 'failed' | 'cancelled'>;
  amount: string;
  currencyCode: string;
  rawPayload: Record<string, unknown>;
}

export interface CommerceOrderListResult {
  orders: OrderSummaryDTO[];
  pagination: PaginationMeta;
}

export interface ResolvedCartIdentity {
  cartId: number;
  cartPublicId: string;
  dto: CartDTO;
}

export interface CommerceRepository {
  listActiveShippingZones(): Promise<ShippingZoneDTO[]>;
  findShippingZoneByDivision(division: BangladeshDivision): Promise<ShippingZoneDTO | null>;

  findCartByUserId(userId: number): Promise<ResolvedCartIdentity | null>;
  findCartByGuestTokenHash(tokenHash: string): Promise<ResolvedCartIdentity | null>;
  createUserCart(userId: number, expiresAt: Date): Promise<ResolvedCartIdentity>;
  createGuestCart(tokenHash: string, expiresAt: Date): Promise<ResolvedCartIdentity>;
  upsertCartItem(
    cartId: number,
    variantPublicId: string,
    quantityToAdd: number,
    customization?: CartItemCustomizationPayload
  ): Promise<CartDTO>;
  updateCartItemQuantity(cartId: number, itemPublicId: string, quantity: number): Promise<CartDTO>;
  removeCartItem(cartId: number, itemPublicId: string): Promise<CartDTO>;
  clearCart(cartId: number): Promise<CartDTO>;
  mergeGuestCartToUser(guestTokenHash: string, userId: number, expiresAt: Date): Promise<void>;

  placeOrderTransactionally(params: PlaceOrderParams): Promise<OrderDetailDTO>;
  listOrdersByUserId(
    userId: number,
    page: number,
    pageSize: number
  ): Promise<CommerceOrderListResult>;
  findOrderByNumber(orderNumber: string): Promise<{
    ownerUserId: number | null;
    order: OrderDetailDTO;
  } | null>;
  cancelOrderTransactionally(params: CancelOrderParams): Promise<OrderDetailDTO>;

  adminListOrders(query: AdminOrderListQueryInput): Promise<CommerceOrderListResult>;
  adminUpdateOrderStatus(params: AdminUpdateOrderStatusParams): Promise<OrderDetailDTO>;
  adminSettleCodPayment(params: AdminSettleCodParams): Promise<OrderDetailDTO>;

  applyVerifiedPaymentWebhook(params: ApplyWebhookPaymentParams): Promise<{
    order: OrderDetailDTO;
    paymentStatus: PaymentStatus;
    idempotentReplay: boolean;
  }>;
}
