import crypto from 'node:crypto';
import type {
  BangladeshDivision,
  ShippingQuoteDTO,
  ShippingZoneDTO,
} from '@your-choice/shared-types';
import { decimalToMinorUnits, minorUnitsToDecimal } from '@your-choice/shared-utils';

export function computeEffectiveUnitPrice(basePrice: string, priceOverride: string | null): string {
  return minorUnitsToDecimal(decimalToMinorUnits(priceOverride ?? basePrice));
}

export function computeLineTotal(
  unitPrice: string,
  customizationFee: string,
  quantity: number
): string {
  const unitMinor = decimalToMinorUnits(unitPrice);
  const customMinor = decimalToMinorUnits(customizationFee);
  return minorUnitsToDecimal((unitMinor + customMinor) * BigInt(quantity));
}

export function computeOrderTotalMinor(
  subtotalMinor: bigint,
  shippingMinor: bigint,
  discountMinor = 0n
): bigint {
  const total = subtotalMinor + shippingMinor - discountMinor;
  return total > 0n ? total : 0n;
}

export function computeShippingQuote(
  division: BangladeshDivision,
  zone: ShippingZoneDTO,
  subtotalDecimal: string
): ShippingQuoteDTO {
  const subtotalMinor = decimalToMinorUnits(subtotalDecimal);
  const flatFeeMinor = decimalToMinorUnits(zone.flatFee);
  const thresholdMinor = zone.freeShippingThreshold
    ? decimalToMinorUnits(zone.freeShippingThreshold)
    : null;

  const freeShippingQualified =
    thresholdMinor !== null && subtotalMinor > 0n && subtotalMinor >= thresholdMinor;
  const shippingMinor = freeShippingQualified ? 0n : flatFeeMinor;

  const remainingMinor =
    thresholdMinor !== null && !freeShippingQualified && subtotalMinor < thresholdMinor
      ? thresholdMinor - subtotalMinor
      : null;

  return {
    division,
    zone,
    subtotal: minorUnitsToDecimal(subtotalMinor),
    shippingFee: minorUnitsToDecimal(shippingMinor),
    freeShippingQualified,
    amountRemainingForFreeShipping:
      remainingMinor !== null ? minorUnitsToDecimal(remainingMinor) : null,
    estimatedTotal: minorUnitsToDecimal(subtotalMinor + shippingMinor),
    currencyCode: zone.currencyCode,
  };
}

export function generateOrderNumber(now = new Date()): string {
  const yyyy = now.getUTCFullYear().toString();
  const mm = String(now.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(now.getUTCDate()).padStart(2, '0');
  const suffix = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `YC-${yyyy}${mm}${dd}-${suffix}`;
}
