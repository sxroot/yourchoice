import {
  type ProductCategoryRow,
  type ProductImageRow,
  type ProductPrintAreaRow,
  type ProductRow,
  type ProductVariantRow,
  productCategories,
  productImages,
  productPrintAreas,
  productVariants,
  products,
} from '@your-choice/database/schema';
import type {
  AdminCatalogQueryInput,
  CreateProductImageInput,
  CreateVariantInput,
  UpdateCategoryInput,
  UpdatePrintAreaInput,
  UpdateProductInput,
  UpdateVariantInput,
  UpsertPrintAreaInput,
} from '@your-choice/validation';
import { and, asc, desc, eq, exists, inArray, isNull, like, or, sql, type SQL } from 'drizzle-orm';
import type { AppDatabase } from '../../database/client.js';
import { ApiError, isDuplicateEntryError } from '../../utils/api-error.js';
import type {
  CatalogRepository,
  CreateCategoryParams,
  CreateProductParams,
  StoredCategoryRecord,
  StoredPrintAreaRecord,
  StoredProductAggregate,
  StoredProductImageRecord,
  StoredProductVariantRecord,
} from './catalog.repository.js';

function mapCategoryRow(row: ProductCategoryRow, productCount = 0): StoredCategoryRecord {
  return {
    id: row.id,
    publicId: row.publicId,
    parentId: row.parentId ?? null,
    slug: row.slug,
    nameEn: row.nameEn,
    nameBn: row.nameBn,
    descriptionEn: row.descriptionEn ?? null,
    descriptionBn: row.descriptionBn ?? null,
    sortOrder: row.sortOrder,
    isActive: row.isActive,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
    deletedAt: row.deletedAt ?? null,
    productCount,
  };
}

function mapImageRow(
  row: ProductImageRow,
  variantPublicIdMap?: Map<number, string>
): StoredProductImageRecord {
  return {
    id: row.id,
    publicId: row.publicId,
    productId: row.productId,
    variantId: row.variantId ?? null,
    variantPublicId: row.variantId ? (variantPublicIdMap?.get(row.variantId) ?? null) : null,
    viewType: row.viewType,
    url: row.url,
    altTextEn: row.altTextEn,
    altTextBn: row.altTextBn,
    sortOrder: row.sortOrder,
    isPrimary: row.isPrimary,
  };
}

function mapVariantRow(row: ProductVariantRow): StoredProductVariantRecord {
  return {
    id: row.id,
    publicId: row.publicId,
    productId: row.productId,
    sku: row.sku,
    colorNameEn: row.colorNameEn,
    colorNameBn: row.colorNameBn,
    colorHex: row.colorHex,
    sizeCode: row.sizeCode,
    priceOverride: row.priceOverride ?? null,
    currencyCode: row.currencyCode,
    stockQuantity: row.stockQuantity,
    isActive: row.isActive,
    deletedAt: row.deletedAt ?? null,
  };
}

function mapPrintAreaRow(row: ProductPrintAreaRow): StoredPrintAreaRecord {
  return {
    id: row.id,
    publicId: row.publicId,
    productId: row.productId,
    surfaceKey: row.surfaceKey,
    labelEn: row.labelEn,
    labelBn: row.labelBn,
    physicalWidthMm: row.physicalWidthMm,
    physicalHeightMm: row.physicalHeightMm,
    targetDpi: row.targetDpi,
    safeInsetMm: row.safeInsetMm,
    coordinateSpace: 'normalized_0_1',
    mockupBounds: row.mockupBoundsJson,
    uvRegion: row.uvRegionJson ?? null,
    printMethods: row.printMethodsJson,
    surchargeAmount: row.surchargeAmount,
    currencyCode: row.currencyCode,
    isDefault: row.isDefault,
    isActive: row.isActive,
    sortOrder: row.sortOrder,
  };
}

export class DrizzleCatalogRepository implements CatalogRepository {
  constructor(private readonly db: AppDatabase) {}

  private async hydrateProducts(
    productRows: ProductRow[],
    categoryMap?: Map<number, StoredCategoryRecord>
  ): Promise<StoredProductAggregate[]> {
    if (productRows.length === 0) {
      return [];
    }

    const productIds = productRows.map((p) => p.id);
    const categoryIds = Array.from(new Set(productRows.map((p) => p.categoryId)));

    const resolvedCategories = categoryMap ?? new Map<number, StoredCategoryRecord>();
    if (resolvedCategories.size === 0 && categoryIds.length > 0) {
      const catRows = await this.db
        .select()
        .from(productCategories)
        .where(inArray(productCategories.id, categoryIds));
      for (const row of catRows) {
        resolvedCategories.set(row.id, mapCategoryRow(row));
      }
    }

    const [imageRows, variantRows, printAreaRows] = await Promise.all([
      this.db
        .select()
        .from(productImages)
        .where(inArray(productImages.productId, productIds))
        .orderBy(asc(productImages.sortOrder), asc(productImages.id)),
      this.db
        .select()
        .from(productVariants)
        .where(
          and(inArray(productVariants.productId, productIds), isNull(productVariants.deletedAt))
        )
        .orderBy(asc(productVariants.id)),
      this.db
        .select()
        .from(productPrintAreas)
        .where(inArray(productPrintAreas.productId, productIds))
        .orderBy(asc(productPrintAreas.sortOrder), asc(productPrintAreas.id)),
    ]);

    const variantPublicIdMap = new Map<number, string>();
    const variantsByProduct = new Map<number, StoredProductVariantRecord[]>();
    for (const row of variantRows) {
      variantPublicIdMap.set(row.id, row.publicId);
      const list = variantsByProduct.get(row.productId) ?? [];
      list.push(mapVariantRow(row));
      variantsByProduct.set(row.productId, list);
    }

    const imagesByProduct = new Map<number, StoredProductImageRecord[]>();
    for (const row of imageRows) {
      const list = imagesByProduct.get(row.productId) ?? [];
      list.push(mapImageRow(row, variantPublicIdMap));
      imagesByProduct.set(row.productId, list);
    }

    const printAreasByProduct = new Map<number, StoredPrintAreaRecord[]>();
    for (const row of printAreaRows) {
      const list = printAreasByProduct.get(row.productId) ?? [];
      list.push(mapPrintAreaRow(row));
      printAreasByProduct.set(row.productId, list);
    }

    return productRows
      .map((row) => {
        const category = resolvedCategories.get(row.categoryId);
        if (!category) {
          return null;
        }
        return {
          id: row.id,
          publicId: row.publicId,
          categoryId: row.categoryId,
          category,
          slug: row.slug,
          skuPrefix: row.skuPrefix,
          nameEn: row.nameEn,
          nameBn: row.nameBn,
          subtitleEn: row.subtitleEn ?? null,
          subtitleBn: row.subtitleBn ?? null,
          descriptionEn: row.descriptionEn,
          descriptionBn: row.descriptionBn,
          fabricSpecEn: row.fabricSpecEn ?? null,
          fabricSpecBn: row.fabricSpecBn ?? null,
          gsm: row.gsm ?? null,
          fitType: row.fitType ?? null,
          basePrice: row.basePrice,
          currencyCode: row.currencyCode,
          isCustomizable: row.isCustomizable,
          status: row.status,
          featuredOrder: row.featuredOrder ?? null,
          createdAt: row.createdAt,
          updatedAt: row.updatedAt,
          deletedAt: row.deletedAt ?? null,
          images: imagesByProduct.get(row.id) ?? [],
          variants: variantsByProduct.get(row.id) ?? [],
          printAreas: printAreasByProduct.get(row.id) ?? [],
        };
      })
      .filter((item): item is StoredProductAggregate => item !== null);
  }

  async listCategories(includeInactive: boolean): Promise<StoredCategoryRecord[]> {
    const conditions: SQL[] = [isNull(productCategories.deletedAt)];
    if (!includeInactive) {
      conditions.push(eq(productCategories.isActive, true));
    }

    const categoryRows = await this.db
      .select()
      .from(productCategories)
      .where(and(...conditions))
      .orderBy(asc(productCategories.sortOrder), asc(productCategories.id));

    const productConditions: SQL[] = [isNull(products.deletedAt)];
    if (!includeInactive) {
      productConditions.push(eq(products.status, 'active'));
    }

    const countRows = await this.db
      .select({
        categoryId: products.categoryId,
        count: sql<number>`count(*)`,
      })
      .from(products)
      .where(and(...productConditions))
      .groupBy(products.categoryId);

    const countMap = new Map<number, number>();
    for (const entry of countRows) {
      countMap.set(entry.categoryId, Number(entry.count));
    }

    return categoryRows.map((row) => mapCategoryRow(row, countMap.get(row.id) ?? 0));
  }

  async findCategoryByPublicId(publicId: string): Promise<StoredCategoryRecord | null> {
    const [row] = await this.db
      .select()
      .from(productCategories)
      .where(and(eq(productCategories.publicId, publicId), isNull(productCategories.deletedAt)))
      .limit(1);

    return row ? mapCategoryRow(row) : null;
  }

  async createCategory(params: CreateCategoryParams): Promise<StoredCategoryRecord> {
    try {
      const [inserted] = await this.db
        .insert(productCategories)
        .values({
          publicId: params.publicId,
          slug: params.slug,
          nameEn: params.nameEn,
          nameBn: params.nameBn,
          descriptionEn: params.descriptionEn ?? null,
          descriptionBn: params.descriptionBn ?? null,
          sortOrder: params.sortOrder,
          isActive: params.isActive,
        })
        .$returningId();

      if (!inserted) {
        throw new Error('Failed to retrieve newly created category ID');
      }

      const [row] = await this.db
        .select()
        .from(productCategories)
        .where(eq(productCategories.id, inserted.id))
        .limit(1);

      if (!row) {
        throw new Error('Failed to load newly created category');
      }

      return mapCategoryRow(row);
    } catch (error: unknown) {
      if (isDuplicateEntryError(error)) {
        throw ApiError.conflict(
          'CATEGORY_SLUG_EXISTS',
          'An apparel category with this slug already exists'
        );
      }
      throw error;
    }
  }

  async updateCategory(
    publicId: string,
    input: UpdateCategoryInput
  ): Promise<StoredCategoryRecord | null> {
    const [existing] = await this.db
      .select()
      .from(productCategories)
      .where(and(eq(productCategories.publicId, publicId), isNull(productCategories.deletedAt)))
      .limit(1);

    if (!existing) {
      return null;
    }

    const patch: Partial<typeof productCategories.$inferInsert> = {};
    if (input.slug !== undefined) patch.slug = input.slug;
    if (input.nameEn !== undefined) patch.nameEn = input.nameEn;
    if (input.nameBn !== undefined) patch.nameBn = input.nameBn;
    if (input.descriptionEn !== undefined) patch.descriptionEn = input.descriptionEn;
    if (input.descriptionBn !== undefined) patch.descriptionBn = input.descriptionBn;
    if (input.sortOrder !== undefined) patch.sortOrder = input.sortOrder;
    if (input.isActive !== undefined) patch.isActive = input.isActive;

    try {
      await this.db
        .update(productCategories)
        .set(patch)
        .where(eq(productCategories.id, existing.id));
      const [updated] = await this.db
        .select()
        .from(productCategories)
        .where(eq(productCategories.id, existing.id))
        .limit(1);

      return updated ? mapCategoryRow(updated) : null;
    } catch (error: unknown) {
      if (isDuplicateEntryError(error)) {
        throw ApiError.conflict(
          'CATEGORY_SLUG_EXISTS',
          'An apparel category with this slug already exists'
        );
      }
      throw error;
    }
  }

  async listProducts(
    query: AdminCatalogQueryInput & { includeNonActive: boolean }
  ): Promise<{ items: StoredProductAggregate[]; totalItems: number }> {
    const conditions: SQL[] = [isNull(products.deletedAt)];

    if (!query.includeNonActive) {
      conditions.push(eq(products.status, 'active'));
      conditions.push(
        exists(
          this.db
            .select({ one: sql`1` })
            .from(productCategories)
            .where(
              and(
                eq(productCategories.id, products.categoryId),
                eq(productCategories.isActive, true),
                isNull(productCategories.deletedAt)
              )
            )
        )
      );
    } else if (query.status) {
      conditions.push(eq(products.status, query.status));
    }

    if (query.category) {
      const [categoryRow] = await this.db
        .select()
        .from(productCategories)
        .where(and(eq(productCategories.slug, query.category), isNull(productCategories.deletedAt)))
        .limit(1);

      if (!categoryRow) {
        return { items: [], totalItems: 0 };
      }
      conditions.push(eq(products.categoryId, categoryRow.id));
    }

    if (query.search && query.search.trim().length > 0) {
      const pattern = `%${query.search.trim()}%`;
      const searchCond = or(
        like(products.nameEn, pattern),
        like(products.nameBn, pattern),
        like(products.skuPrefix, pattern),
        like(products.slug, pattern)
      );
      if (searchCond) {
        conditions.push(searchCond);
      }
    }

    if (query.customizable !== undefined) {
      conditions.push(eq(products.isCustomizable, query.customizable));
    }

    if (query.size || query.color) {
      const variantFilter: SQL[] = [
        eq(productVariants.productId, products.id),
        isNull(productVariants.deletedAt),
      ];
      if (!query.includeNonActive) {
        variantFilter.push(eq(productVariants.isActive, true));
      }
      if (query.size) {
        variantFilter.push(eq(productVariants.sizeCode, query.size));
      }
      if (query.color) {
        variantFilter.push(eq(productVariants.colorHex, query.color));
      }
      conditions.push(
        exists(
          this.db
            .select({ one: sql`1` })
            .from(productVariants)
            .where(and(...variantFilter))
        )
      );
    }

    const whereClause = and(...conditions);

    const [countResult] = await this.db
      .select({ count: sql<number>`count(*)` })
      .from(products)
      .where(whereClause);

    const orderByColumns = (() => {
      switch (query.sort) {
        case 'price_asc':
          return [asc(products.basePrice), desc(products.createdAt)];
        case 'price_desc':
          return [desc(products.basePrice), desc(products.createdAt)];
        case 'newest':
          return [desc(products.createdAt), desc(products.id)];
        case 'featured':
        default:
          return [
            sql`CASE WHEN ${products.featuredOrder} IS NULL THEN 1 ELSE 0 END`,
            asc(products.featuredOrder),
            desc(products.createdAt),
          ];
      }
    })();

    const offset = (query.page - 1) * query.pageSize;
    const rows = await this.db
      .select()
      .from(products)
      .where(whereClause)
      .orderBy(...orderByColumns)
      .limit(query.pageSize)
      .offset(offset);

    const items = await this.hydrateProducts(rows);
    return {
      items,
      totalItems: Number(countResult?.count ?? 0),
    };
  }

  async findProductBySlug(
    slug: string,
    includeNonActive: boolean
  ): Promise<StoredProductAggregate | null> {
    const conditions: SQL[] = [eq(products.slug, slug), isNull(products.deletedAt)];
    if (!includeNonActive) {
      conditions.push(eq(products.status, 'active'));
    }

    const [row] = await this.db
      .select()
      .from(products)
      .where(and(...conditions))
      .limit(1);

    if (!row) {
      return null;
    }

    const [hydrated] = await this.hydrateProducts([row]);
    return hydrated ?? null;
  }

  async findProductByPublicId(
    publicId: string,
    includeNonActive: boolean
  ): Promise<StoredProductAggregate | null> {
    const conditions: SQL[] = [eq(products.publicId, publicId), isNull(products.deletedAt)];
    if (!includeNonActive) {
      conditions.push(eq(products.status, 'active'));
    }

    const [row] = await this.db
      .select()
      .from(products)
      .where(and(...conditions))
      .limit(1);

    if (!row) {
      return null;
    }

    const [hydrated] = await this.hydrateProducts([row]);
    return hydrated ?? null;
  }

  async createProduct(params: CreateProductParams): Promise<StoredProductAggregate> {
    try {
      const createdId = await this.db.transaction(async (tx) => {
        const [inserted] = await tx
          .insert(products)
          .values({
            publicId: params.publicId,
            categoryId: params.categoryInternalId,
            slug: params.slug,
            skuPrefix: params.skuPrefix,
            nameEn: params.nameEn,
            nameBn: params.nameBn,
            subtitleEn: params.subtitleEn ?? null,
            subtitleBn: params.subtitleBn ?? null,
            descriptionEn: params.descriptionEn,
            descriptionBn: params.descriptionBn,
            fabricSpecEn: params.fabricSpecEn ?? null,
            fabricSpecBn: params.fabricSpecBn ?? null,
            gsm: params.gsm ?? null,
            fitType: params.fitType ?? null,
            basePrice: params.basePrice,
            currencyCode: 'BDT',
            isCustomizable: params.isCustomizable,
            status: params.status,
            featuredOrder: params.featuredOrder ?? null,
          })
          .$returningId();

        if (!inserted) {
          throw new Error('Failed to retrieve newly created product ID');
        }

        if (params.images.length > 0) {
          await tx.insert(productImages).values(
            params.images.map((image, index) => ({
              publicId: image.publicId,
              productId: inserted.id,
              variantId: null,
              viewType: image.viewType,
              url: image.url,
              altTextEn: image.altTextEn,
              altTextBn: image.altTextBn,
              sortOrder: image.sortOrder ?? index,
              isPrimary: image.isPrimary ?? index === 0,
            }))
          );
        }

        if (params.variants.length > 0) {
          await tx.insert(productVariants).values(
            params.variants.map((variant) => ({
              publicId: variant.publicId,
              productId: inserted.id,
              sku: variant.sku,
              colorNameEn: variant.colorNameEn,
              colorNameBn: variant.colorNameBn,
              colorHex: variant.colorHex,
              sizeCode: variant.sizeCode,
              priceOverride: variant.priceOverride ?? null,
              currencyCode: 'BDT',
              stockQuantity: variant.stockQuantity,
              isActive: variant.isActive,
            }))
          );
        }

        if (params.printAreas.length > 0) {
          await tx.insert(productPrintAreas).values(
            params.printAreas.map((area, index) => ({
              publicId: area.publicId,
              productId: inserted.id,
              surfaceKey: area.surfaceKey,
              labelEn: area.labelEn,
              labelBn: area.labelBn,
              physicalWidthMm: area.physicalWidthMm,
              physicalHeightMm: area.physicalHeightMm,
              targetDpi: area.targetDpi,
              safeInsetMm: area.safeInsetMm,
              coordinateSpace: 'normalized_0_1',
              mockupBoundsJson: area.mockupBounds,
              uvRegionJson: area.uvRegion ?? null,
              printMethodsJson: area.printMethods,
              surchargeAmount: area.surchargeAmount,
              currencyCode: 'BDT',
              isDefault: area.isDefault ?? index === 0,
              isActive: area.isActive,
              sortOrder: area.sortOrder ?? index,
            }))
          );
        }

        return inserted.id;
      });

      const [row] = await this.db
        .select()
        .from(products)
        .where(eq(products.id, createdId))
        .limit(1);

      if (!row) {
        throw new Error('Failed to load created product');
      }

      const [hydrated] = await this.hydrateProducts([row]);
      if (!hydrated) {
        throw new Error('Failed to hydrate created product');
      }

      return hydrated;
    } catch (error: unknown) {
      if (isDuplicateEntryError(error)) {
        throw ApiError.conflict(
          'CATALOG_DUPLICATE_IDENTIFIER',
          'A product slug, variant SKU, or surface key already exists'
        );
      }
      throw error;
    }
  }

  async updateProduct(
    productId: number,
    input: Omit<UpdateProductInput, 'categoryId'> & { categoryInternalId?: number }
  ): Promise<StoredProductAggregate | null> {
    const patch: Partial<typeof products.$inferInsert> = {};
    if (input.categoryInternalId !== undefined) patch.categoryId = input.categoryInternalId;
    if (input.slug !== undefined) patch.slug = input.slug;
    if (input.skuPrefix !== undefined) patch.skuPrefix = input.skuPrefix;
    if (input.nameEn !== undefined) patch.nameEn = input.nameEn;
    if (input.nameBn !== undefined) patch.nameBn = input.nameBn;
    if (input.subtitleEn !== undefined) patch.subtitleEn = input.subtitleEn;
    if (input.subtitleBn !== undefined) patch.subtitleBn = input.subtitleBn;
    if (input.descriptionEn !== undefined) patch.descriptionEn = input.descriptionEn;
    if (input.descriptionBn !== undefined) patch.descriptionBn = input.descriptionBn;
    if (input.fabricSpecEn !== undefined) patch.fabricSpecEn = input.fabricSpecEn;
    if (input.fabricSpecBn !== undefined) patch.fabricSpecBn = input.fabricSpecBn;
    if (input.gsm !== undefined) patch.gsm = input.gsm;
    if (input.fitType !== undefined) patch.fitType = input.fitType;
    if (input.basePrice !== undefined) patch.basePrice = input.basePrice;
    if (input.isCustomizable !== undefined) patch.isCustomizable = input.isCustomizable;
    if (input.status !== undefined) patch.status = input.status;
    if (input.featuredOrder !== undefined) patch.featuredOrder = input.featuredOrder;

    try {
      await this.db
        .update(products)
        .set(patch)
        .where(and(eq(products.id, productId), isNull(products.deletedAt)));

      const [row] = await this.db
        .select()
        .from(products)
        .where(and(eq(products.id, productId), isNull(products.deletedAt)))
        .limit(1);

      if (!row) {
        return null;
      }

      const [hydrated] = await this.hydrateProducts([row]);
      return hydrated ?? null;
    } catch (error: unknown) {
      if (isDuplicateEntryError(error)) {
        throw ApiError.conflict(
          'PRODUCT_SLUG_EXISTS',
          'Another product already uses this slug identifier'
        );
      }
      throw error;
    }
  }

  async softDeleteProduct(productId: number): Promise<boolean> {
    const [existing] = await this.db
      .select({ id: products.id })
      .from(products)
      .where(and(eq(products.id, productId), isNull(products.deletedAt)))
      .limit(1);

    if (!existing) {
      return false;
    }

    await this.db
      .update(products)
      .set({
        status: 'archived',
        deletedAt: new Date(),
      })
      .where(eq(products.id, productId));

    return true;
  }

  async addImage(
    productId: number,
    input: CreateProductImageInput & { publicId: string }
  ): Promise<StoredProductImageRecord> {
    return this.db.transaction(async (tx) => {
      if (input.isPrimary) {
        await tx
          .update(productImages)
          .set({ isPrimary: false })
          .where(eq(productImages.productId, productId));
      }

      let resolvedVariantId: number | null = null;
      if (input.variantId) {
        const [variantRow] = await tx
          .select({ id: productVariants.id })
          .from(productVariants)
          .where(
            and(
              eq(productVariants.productId, productId),
              eq(productVariants.publicId, input.variantId),
              isNull(productVariants.deletedAt)
            )
          )
          .limit(1);
        resolvedVariantId = variantRow?.id ?? null;
      }

      const [inserted] = await tx
        .insert(productImages)
        .values({
          publicId: input.publicId,
          productId,
          variantId: resolvedVariantId,
          viewType: input.viewType,
          url: input.url,
          altTextEn: input.altTextEn,
          altTextBn: input.altTextBn,
          sortOrder: input.sortOrder,
          isPrimary: input.isPrimary,
        })
        .$returningId();

      if (!inserted) {
        throw new Error('Failed to retrieve newly created image ID');
      }

      const [row] = await tx
        .select()
        .from(productImages)
        .where(eq(productImages.id, inserted.id))
        .limit(1);

      if (!row) {
        throw new Error('Failed to load created product image');
      }

      return mapImageRow(row);
    });
  }

  async deleteImage(productId: number, imagePublicId: string): Promise<boolean> {
    const [existing] = await this.db
      .select({ id: productImages.id })
      .from(productImages)
      .where(and(eq(productImages.productId, productId), eq(productImages.publicId, imagePublicId)))
      .limit(1);

    if (!existing) {
      return false;
    }

    await this.db.delete(productImages).where(eq(productImages.id, existing.id));
    return true;
  }

  async addVariant(
    productId: number,
    input: CreateVariantInput & { publicId: string }
  ): Promise<StoredProductVariantRecord> {
    try {
      const [inserted] = await this.db
        .insert(productVariants)
        .values({
          publicId: input.publicId,
          productId,
          sku: input.sku,
          colorNameEn: input.colorNameEn,
          colorNameBn: input.colorNameBn,
          colorHex: input.colorHex,
          sizeCode: input.sizeCode,
          priceOverride: input.priceOverride ?? null,
          currencyCode: 'BDT',
          stockQuantity: input.stockQuantity,
          isActive: input.isActive,
        })
        .$returningId();

      if (!inserted) {
        throw new Error('Failed to retrieve newly created category ID');
      }

      const [row] = await this.db
        .select()
        .from(productVariants)
        .where(eq(productVariants.id, inserted.id))
        .limit(1);

      if (!row) {
        throw new Error('Failed to load created product variant');
      }

      return mapVariantRow(row);
    } catch (error: unknown) {
      if (isDuplicateEntryError(error)) {
        throw ApiError.conflict('VARIANT_SKU_EXISTS', `SKU "${input.sku}" already exists`);
      }
      throw error;
    }
  }

  async updateVariant(
    productId: number,
    variantPublicId: string,
    input: UpdateVariantInput
  ): Promise<StoredProductVariantRecord | null> {
    const [existing] = await this.db
      .select()
      .from(productVariants)
      .where(
        and(
          eq(productVariants.productId, productId),
          eq(productVariants.publicId, variantPublicId),
          isNull(productVariants.deletedAt)
        )
      )
      .limit(1);

    if (!existing) {
      return null;
    }

    const patch: Partial<typeof productVariants.$inferInsert> = {};
    if (input.sku !== undefined) patch.sku = input.sku;
    if (input.colorNameEn !== undefined) patch.colorNameEn = input.colorNameEn;
    if (input.colorNameBn !== undefined) patch.colorNameBn = input.colorNameBn;
    if (input.colorHex !== undefined) patch.colorHex = input.colorHex;
    if (input.sizeCode !== undefined) patch.sizeCode = input.sizeCode;
    if (input.priceOverride !== undefined) patch.priceOverride = input.priceOverride;
    if (input.stockQuantity !== undefined) patch.stockQuantity = input.stockQuantity;
    if (input.isActive !== undefined) patch.isActive = input.isActive;

    try {
      await this.db.update(productVariants).set(patch).where(eq(productVariants.id, existing.id));

      const [updated] = await this.db
        .select()
        .from(productVariants)
        .where(eq(productVariants.id, existing.id))
        .limit(1);

      return updated ? mapVariantRow(updated) : null;
    } catch (error: unknown) {
      if (isDuplicateEntryError(error)) {
        throw ApiError.conflict('VARIANT_SKU_EXISTS', 'Another variant already uses this SKU');
      }
      throw error;
    }
  }

  async softDeleteVariant(productId: number, variantPublicId: string): Promise<boolean> {
    const [existing] = await this.db
      .select({ id: productVariants.id })
      .from(productVariants)
      .where(
        and(
          eq(productVariants.productId, productId),
          eq(productVariants.publicId, variantPublicId),
          isNull(productVariants.deletedAt)
        )
      )
      .limit(1);

    if (!existing) {
      return false;
    }

    await this.db
      .update(productVariants)
      .set({ isActive: false, deletedAt: new Date() })
      .where(eq(productVariants.id, existing.id));

    return true;
  }

  async upsertPrintArea(
    productId: number,
    input: UpsertPrintAreaInput & { publicId: string }
  ): Promise<StoredPrintAreaRecord> {
    return this.db.transaction(async (tx) => {
      if (input.isDefault) {
        await tx
          .update(productPrintAreas)
          .set({ isDefault: false })
          .where(eq(productPrintAreas.productId, productId));
      }

      const [existing] = await tx
        .select()
        .from(productPrintAreas)
        .where(
          and(
            eq(productPrintAreas.productId, productId),
            eq(productPrintAreas.surfaceKey, input.surfaceKey)
          )
        )
        .limit(1);

      if (existing) {
        await tx
          .update(productPrintAreas)
          .set({
            labelEn: input.labelEn,
            labelBn: input.labelBn,
            physicalWidthMm: input.physicalWidthMm,
            physicalHeightMm: input.physicalHeightMm,
            targetDpi: input.targetDpi,
            safeInsetMm: input.safeInsetMm,
            mockupBoundsJson: input.mockupBounds,
            uvRegionJson: input.uvRegion ?? null,
            printMethodsJson: input.printMethods,
            surchargeAmount: input.surchargeAmount,
            isDefault: input.isDefault,
            isActive: input.isActive,
            sortOrder: input.sortOrder,
          })
          .where(eq(productPrintAreas.id, existing.id));

        const [updated] = await tx
          .select()
          .from(productPrintAreas)
          .where(eq(productPrintAreas.id, existing.id))
          .limit(1);

        if (!updated) {
          throw new Error('Failed to load updated print area');
        }
        return mapPrintAreaRow(updated);
      }

      const [inserted] = await tx
        .insert(productPrintAreas)
        .values({
          publicId: input.publicId,
          productId,
          surfaceKey: input.surfaceKey,
          labelEn: input.labelEn,
          labelBn: input.labelBn,
          physicalWidthMm: input.physicalWidthMm,
          physicalHeightMm: input.physicalHeightMm,
          targetDpi: input.targetDpi,
          safeInsetMm: input.safeInsetMm,
          coordinateSpace: 'normalized_0_1',
          mockupBoundsJson: input.mockupBounds,
          uvRegionJson: input.uvRegion ?? null,
          printMethodsJson: input.printMethods,
          surchargeAmount: input.surchargeAmount,
          currencyCode: 'BDT',
          isDefault: input.isDefault,
          isActive: input.isActive,
          sortOrder: input.sortOrder,
        })
        .$returningId();

      if (!inserted) {
        throw new Error('Failed to retrieve newly created print area ID');
      }

      const [created] = await tx
        .select()
        .from(productPrintAreas)
        .where(eq(productPrintAreas.id, inserted.id))
        .limit(1);

      if (!created) {
        throw new Error('Failed to load created print area');
      }
      return mapPrintAreaRow(created);
    });
  }

  async updatePrintArea(
    productId: number,
    printAreaPublicId: string,
    input: UpdatePrintAreaInput
  ): Promise<StoredPrintAreaRecord | null> {
    return this.db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(productPrintAreas)
        .where(
          and(
            eq(productPrintAreas.productId, productId),
            eq(productPrintAreas.publicId, printAreaPublicId)
          )
        )
        .limit(1);

      if (!existing) {
        return null;
      }

      if (input.isDefault === true) {
        await tx
          .update(productPrintAreas)
          .set({ isDefault: false })
          .where(eq(productPrintAreas.productId, productId));
      }

      const patch: Partial<typeof productPrintAreas.$inferInsert> = {};
      if (input.surfaceKey !== undefined) patch.surfaceKey = input.surfaceKey;
      if (input.labelEn !== undefined) patch.labelEn = input.labelEn;
      if (input.labelBn !== undefined) patch.labelBn = input.labelBn;
      if (input.physicalWidthMm !== undefined) patch.physicalWidthMm = input.physicalWidthMm;
      if (input.physicalHeightMm !== undefined) patch.physicalHeightMm = input.physicalHeightMm;
      if (input.targetDpi !== undefined) patch.targetDpi = input.targetDpi;
      if (input.safeInsetMm !== undefined) patch.safeInsetMm = input.safeInsetMm;
      if (input.mockupBounds !== undefined) patch.mockupBoundsJson = input.mockupBounds;
      if (input.uvRegion !== undefined) patch.uvRegionJson = input.uvRegion;
      if (input.printMethods !== undefined) patch.printMethodsJson = input.printMethods;
      if (input.surchargeAmount !== undefined) patch.surchargeAmount = input.surchargeAmount;
      if (input.isDefault !== undefined) patch.isDefault = input.isDefault;
      if (input.isActive !== undefined) patch.isActive = input.isActive;
      if (input.sortOrder !== undefined) patch.sortOrder = input.sortOrder;

      await tx.update(productPrintAreas).set(patch).where(eq(productPrintAreas.id, existing.id));

      const [updated] = await tx
        .select()
        .from(productPrintAreas)
        .where(eq(productPrintAreas.id, existing.id))
        .limit(1);

      return updated ? mapPrintAreaRow(updated) : null;
    });
  }

  async deletePrintArea(productId: number, printAreaPublicId: string): Promise<boolean> {
    const [existing] = await this.db
      .select({ id: productPrintAreas.id })
      .from(productPrintAreas)
      .where(
        and(
          eq(productPrintAreas.productId, productId),
          eq(productPrintAreas.publicId, printAreaPublicId)
        )
      )
      .limit(1);

    if (!existing) {
      return false;
    }

    await this.db.delete(productPrintAreas).where(eq(productPrintAreas.id, existing.id));
    return true;
  }
}
