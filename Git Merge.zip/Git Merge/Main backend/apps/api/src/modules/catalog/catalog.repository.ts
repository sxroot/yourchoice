import type {
  GarmentSizeCode,
  ImageViewType,
  MockupBoundsDTO,
  PrintAreaSurfaceKey,
  ProductCategoryDTO,
  ProductColorSwatchDTO,
  ProductDetailDTO,
  ProductImageDTO,
  ProductPrintAreaDTO,
  ProductStatus,
  ProductSummaryDTO,
  ProductVariantDTO,
  UvRegionDTO,
} from '@your-choice/shared-types';
import { decimalToMinorUnits, minorUnitsToDecimal } from '@your-choice/shared-utils';
import type {
  AdminCatalogQueryInput,
  CreateCategoryInput,
  CreateProductImageInput,
  CreateProductInput,
  CreateVariantInput,
  UpdateCategoryInput,
  UpdatePrintAreaInput,
  UpdateProductInput,
  UpdateVariantInput,
  UpsertPrintAreaInput,
} from '@your-choice/validation';

export interface StoredCategoryRecord {
  id: number;
  publicId: string;
  parentId: number | null;
  slug: string;
  nameEn: string;
  nameBn: string;
  descriptionEn: string | null;
  descriptionBn: string | null;
  sortOrder: number;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
  productCount?: number;
}

export interface StoredProductImageRecord {
  id: number;
  publicId: string;
  productId: number;
  variantId: number | null;
  variantPublicId?: string | null;
  viewType: ImageViewType;
  url: string;
  altTextEn: string;
  altTextBn: string;
  sortOrder: number;
  isPrimary: boolean;
}

export interface StoredProductVariantRecord {
  id: number;
  publicId: string;
  productId: number;
  sku: string;
  colorNameEn: string;
  colorNameBn: string;
  colorHex: string;
  sizeCode: GarmentSizeCode;
  priceOverride: string | null;
  currencyCode: string;
  stockQuantity: number;
  isActive: boolean;
  deletedAt: Date | null;
}

export interface StoredPrintAreaRecord {
  id: number;
  publicId: string;
  productId: number;
  surfaceKey: PrintAreaSurfaceKey;
  labelEn: string;
  labelBn: string;
  physicalWidthMm: number;
  physicalHeightMm: number;
  targetDpi: number;
  safeInsetMm: number;
  coordinateSpace: 'normalized_0_1';
  mockupBounds: MockupBoundsDTO;
  uvRegion: UvRegionDTO | null;
  printMethods: string[];
  surchargeAmount: string;
  currencyCode: string;
  isDefault: boolean;
  isActive: boolean;
  sortOrder: number;
}

export interface StoredProductAggregate {
  id: number;
  publicId: string;
  categoryId: number;
  category: StoredCategoryRecord;
  slug: string;
  skuPrefix: string;
  nameEn: string;
  nameBn: string;
  subtitleEn: string | null;
  subtitleBn: string | null;
  descriptionEn: string;
  descriptionBn: string;
  fabricSpecEn: string | null;
  fabricSpecBn: string | null;
  gsm: number | null;
  fitType: string | null;
  basePrice: string;
  currencyCode: string;
  isCustomizable: boolean;
  status: ProductStatus;
  featuredOrder: number | null;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
  images: StoredProductImageRecord[];
  variants: StoredProductVariantRecord[];
  printAreas: StoredPrintAreaRecord[];
}

export interface CreateCategoryParams extends CreateCategoryInput {
  publicId: string;
}

export interface CreateProductParams extends Omit<
  CreateProductInput,
  'categoryId' | 'images' | 'variants' | 'printAreas'
> {
  publicId: string;
  categoryInternalId: number;
  images: Array<CreateProductImageInput & { publicId: string }>;
  variants: Array<CreateVariantInput & { publicId: string }>;
  printAreas: Array<UpsertPrintAreaInput & { publicId: string }>;
}

export interface CatalogRepository {
  listCategories(includeInactive: boolean): Promise<StoredCategoryRecord[]>;
  findCategoryByPublicId(publicId: string): Promise<StoredCategoryRecord | null>;
  createCategory(params: CreateCategoryParams): Promise<StoredCategoryRecord>;
  updateCategory(
    publicId: string,
    input: UpdateCategoryInput
  ): Promise<StoredCategoryRecord | null>;

  listProducts(
    query: AdminCatalogQueryInput & { includeNonActive: boolean }
  ): Promise<{ items: StoredProductAggregate[]; totalItems: number }>;
  findProductBySlug(
    slug: string,
    includeNonActive: boolean
  ): Promise<StoredProductAggregate | null>;
  findProductByPublicId(
    publicId: string,
    includeNonActive: boolean
  ): Promise<StoredProductAggregate | null>;
  createProduct(params: CreateProductParams): Promise<StoredProductAggregate>;
  updateProduct(
    productId: number,
    input: Omit<UpdateProductInput, 'categoryId'> & { categoryInternalId?: number }
  ): Promise<StoredProductAggregate | null>;
  softDeleteProduct(productId: number): Promise<boolean>;

  addImage(
    productId: number,
    input: CreateProductImageInput & { publicId: string }
  ): Promise<StoredProductImageRecord>;
  deleteImage(productId: number, imagePublicId: string): Promise<boolean>;

  addVariant(
    productId: number,
    input: CreateVariantInput & { publicId: string }
  ): Promise<StoredProductVariantRecord>;
  updateVariant(
    productId: number,
    variantPublicId: string,
    input: UpdateVariantInput
  ): Promise<StoredProductVariantRecord | null>;
  softDeleteVariant(productId: number, variantPublicId: string): Promise<boolean>;

  upsertPrintArea(
    productId: number,
    input: UpsertPrintAreaInput & { publicId: string }
  ): Promise<StoredPrintAreaRecord>;
  updatePrintArea(
    productId: number,
    printAreaPublicId: string,
    input: UpdatePrintAreaInput
  ): Promise<StoredPrintAreaRecord | null>;
  deletePrintArea(productId: number, printAreaPublicId: string): Promise<boolean>;
}

export function resolveEffectiveVariantPrice(
  basePrice: string,
  priceOverride: string | null
): string {
  const effectiveMinor = decimalToMinorUnits(priceOverride ?? basePrice);
  return minorUnitsToDecimal(effectiveMinor);
}

export function toCategoryDto(record: StoredCategoryRecord): ProductCategoryDTO {
  return {
    id: record.publicId,
    slug: record.slug,
    parentId: null,
    nameEn: record.nameEn,
    nameBn: record.nameBn,
    descriptionEn: record.descriptionEn,
    descriptionBn: record.descriptionBn,
    sortOrder: record.sortOrder,
    isActive: record.isActive,
    productCount: record.productCount ?? 0,
  };
}

export function toImageDto(record: StoredProductImageRecord): ProductImageDTO {
  return {
    id: record.publicId,
    variantId: record.variantPublicId ?? null,
    viewType: record.viewType,
    url: record.url,
    altTextEn: record.altTextEn,
    altTextBn: record.altTextBn,
    sortOrder: record.sortOrder,
    isPrimary: record.isPrimary,
  };
}

export function toVariantDto(
  record: StoredProductVariantRecord,
  productBasePrice: string
): ProductVariantDTO {
  return {
    id: record.publicId,
    sku: record.sku,
    colorNameEn: record.colorNameEn,
    colorNameBn: record.colorNameBn,
    colorHex: record.colorHex,
    sizeCode: record.sizeCode,
    priceOverride: record.priceOverride,
    effectivePrice: resolveEffectiveVariantPrice(productBasePrice, record.priceOverride),
    currencyCode: record.currencyCode,
    stockQuantity: record.stockQuantity,
    inStock: record.isActive && record.stockQuantity > 0,
    isActive: record.isActive,
  };
}

export function toPrintAreaDto(record: StoredPrintAreaRecord): ProductPrintAreaDTO {
  return {
    id: record.publicId,
    surfaceKey: record.surfaceKey,
    labelEn: record.labelEn,
    labelBn: record.labelBn,
    physicalWidthMm: record.physicalWidthMm,
    physicalHeightMm: record.physicalHeightMm,
    targetDpi: record.targetDpi,
    safeInsetMm: record.safeInsetMm,
    coordinateSpace: record.coordinateSpace,
    mockupBounds: { ...record.mockupBounds },
    uvRegion: record.uvRegion ? { ...record.uvRegion } : null,
    printMethods: [...record.printMethods],
    surchargeAmount: minorUnitsToDecimal(decimalToMinorUnits(record.surchargeAmount)),
    currencyCode: record.currencyCode,
    isDefault: record.isDefault,
    isActive: record.isActive,
    sortOrder: record.sortOrder,
  };
}

function summarizeVariants(
  basePrice: string,
  variants: readonly StoredProductVariantRecord[]
): {
  minPrice: string;
  maxPrice: string;
  sizes: GarmentSizeCode[];
  colors: ProductColorSwatchDTO[];
  totalStock: number;
} {
  const baseMinor = decimalToMinorUnits(basePrice);
  const firstVariant = variants[0];
  if (!firstVariant) {
    const formatted = minorUnitsToDecimal(baseMinor);
    return {
      minPrice: formatted,
      maxPrice: formatted,
      sizes: [],
      colors: [],
      totalStock: 0,
    };
  }

  let minMinor = decimalToMinorUnits(firstVariant.priceOverride ?? basePrice);
  let maxMinor = minMinor;
  let totalStock = 0;
  const sizeSet = new Set<GarmentSizeCode>();
  const colorMap = new Map<string, ProductColorSwatchDTO>();

  for (const variant of variants) {
    const priceMinor = decimalToMinorUnits(variant.priceOverride ?? basePrice);
    if (priceMinor < minMinor) minMinor = priceMinor;
    if (priceMinor > maxMinor) maxMinor = priceMinor;
    totalStock += variant.stockQuantity;
    sizeSet.add(variant.sizeCode);
    if (!colorMap.has(variant.colorHex)) {
      colorMap.set(variant.colorHex, {
        colorNameEn: variant.colorNameEn,
        colorNameBn: variant.colorNameBn,
        colorHex: variant.colorHex,
      });
    }
  }

  return {
    minPrice: minorUnitsToDecimal(minMinor),
    maxPrice: minorUnitsToDecimal(maxMinor),
    sizes: Array.from(sizeSet),
    colors: Array.from(colorMap.values()),
    totalStock,
  };
}

export function toProductSummaryDto(
  aggregate: StoredProductAggregate,
  options?: { includeInactiveChildren?: boolean }
): ProductSummaryDTO {
  const includeInactive = options?.includeInactiveChildren ?? false;
  const visibleVariants = aggregate.variants.filter(
    (v) => v.deletedAt === null && (includeInactive || v.isActive)
  );
  const visiblePrintAreas = aggregate.printAreas.filter((p) => includeInactive || p.isActive);
  const summary = summarizeVariants(aggregate.basePrice, visibleVariants);
  const primaryImage = aggregate.images.find((img) => img.isPrimary) ?? aggregate.images[0] ?? null;

  return {
    id: aggregate.publicId,
    slug: aggregate.slug,
    skuPrefix: aggregate.skuPrefix,
    category: {
      id: aggregate.category.publicId,
      slug: aggregate.category.slug,
      nameEn: aggregate.category.nameEn,
      nameBn: aggregate.category.nameBn,
    },
    nameEn: aggregate.nameEn,
    nameBn: aggregate.nameBn,
    subtitleEn: aggregate.subtitleEn,
    subtitleBn: aggregate.subtitleBn,
    gsm: aggregate.gsm,
    fitType: aggregate.fitType,
    basePrice: minorUnitsToDecimal(decimalToMinorUnits(aggregate.basePrice)),
    minPrice: summary.minPrice,
    maxPrice: summary.maxPrice,
    currencyCode: aggregate.currencyCode,
    isCustomizable: aggregate.isCustomizable,
    status: aggregate.status,
    featuredOrder: aggregate.featuredOrder,
    primaryImage: primaryImage ? toImageDto(primaryImage) : null,
    availableSizes: summary.sizes,
    availableColors: summary.colors,
    printSurfaces: visiblePrintAreas.map((area) => area.surfaceKey),
    totalStock: summary.totalStock,
    variantCount: visibleVariants.length,
    createdAt: aggregate.createdAt.toISOString(),
    updatedAt: aggregate.updatedAt.toISOString(),
  };
}

export function toProductDetailDto(
  aggregate: StoredProductAggregate,
  options?: { includeInactiveChildren?: boolean }
): ProductDetailDTO {
  const includeInactive = options?.includeInactiveChildren ?? false;
  const baseSummary = toProductSummaryDto(aggregate, options);
  const visibleVariants = aggregate.variants.filter(
    (v) => v.deletedAt === null && (includeInactive || v.isActive)
  );
  const visiblePrintAreas = aggregate.printAreas.filter((p) => includeInactive || p.isActive);

  return {
    ...baseSummary,
    descriptionEn: aggregate.descriptionEn,
    descriptionBn: aggregate.descriptionBn,
    fabricSpecEn: aggregate.fabricSpecEn,
    fabricSpecBn: aggregate.fabricSpecBn,
    images: [...aggregate.images]
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map((img) => toImageDto(img)),
    variants: visibleVariants.map((variant) => toVariantDto(variant, aggregate.basePrice)),
    printAreas: [...visiblePrintAreas]
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map((area) => toPrintAreaDto(area)),
  };
}
