import { randomUUID } from 'node:crypto';
import type {
  GarmentSizeCode,
  ProductCategoryDTO,
  ProductColorSwatchDTO,
  ProductDetailDTO,
  ProductImageDTO,
  ProductListResponseData,
  ProductPrintAreaDTO,
  ProductVariantDTO,
} from '@your-choice/shared-types';
import type {
  AdminCatalogQueryInput,
  CatalogQueryInput,
  CreateCategoryInput,
  CreateProductImageInput,
  CreateProductInput,
  CreateVariantInput,
  UpdateCategoryInput,
  UpdatePrintAreaInput,
  UpdateProductInput,
  UpdateVariantInput,
  UpsertPrintAreaInput,
} from '@your-choice/validation';
import { ApiError } from '../../utils/api-error.js';
import {
  type CatalogRepository,
  type StoredProductAggregate,
  toCategoryDto,
  toImageDto,
  toPrintAreaDto,
  toProductDetailDto,
  toProductSummaryDto,
  toVariantDto,
} from './catalog.repository.js';

export class CatalogService {
  constructor(private readonly repository: CatalogRepository) {}

  private assertPublishInvariants(params: {
    status: 'draft' | 'active' | 'archived';
    isCustomizable: boolean;
    activeVariantCount: number;
    activePrintAreaCount: number;
  }): void {
    if (params.status !== 'active') {
      return;
    }

    if (params.activeVariantCount < 1) {
      throw new ApiError(
        400,
        'CATALOG_PUBLISH_REQUIRES_VARIANT',
        'A product must have at least one active SKU variant before publishing'
      );
    }

    if (params.isCustomizable && params.activePrintAreaCount < 1) {
      throw new ApiError(
        400,
        'CATALOG_PUBLISH_REQUIRES_PRINT_AREA',
        'A customizable garment must define at least one active print area before publishing'
      );
    }
  }

  private buildProductFacets(items: readonly StoredProductAggregate[]): {
    sizes: GarmentSizeCode[];
    colors: ProductColorSwatchDTO[];
  } {
    const sizeSet = new Set<GarmentSizeCode>();
    const colorMap = new Map<string, ProductColorSwatchDTO>();

    for (const product of items) {
      for (const variant of product.variants) {
        if (!variant.isActive || variant.deletedAt !== null) {
          continue;
        }
        sizeSet.add(variant.sizeCode);
        if (!colorMap.has(variant.colorHex)) {
          colorMap.set(variant.colorHex, {
            colorNameEn: variant.colorNameEn,
            colorNameBn: variant.colorNameBn,
            colorHex: variant.colorHex,
          });
        }
      }
    }

    return {
      sizes: Array.from(sizeSet),
      colors: Array.from(colorMap.values()),
    };
  }

  async listPublicCategories(): Promise<ProductCategoryDTO[]> {
    const records = await this.repository.listCategories(false);
    return records.map(toCategoryDto);
  }

  async listPublicProducts(query: CatalogQueryInput): Promise<ProductListResponseData> {
    const result = await this.repository.listProducts({
      ...query,
      includeNonActive: false,
    });
    const totalPages = Math.max(1, Math.ceil(result.totalItems / query.pageSize));

    return {
      products: result.items.map((item) =>
        toProductSummaryDto(item, { includeInactiveChildren: false })
      ),
      pagination: {
        page: query.page,
        pageSize: query.pageSize,
        totalItems: result.totalItems,
        totalPages,
      },
      facets: this.buildProductFacets(result.items),
    };
  }

  async getPublicProductBySlug(slug: string): Promise<ProductDetailDTO> {
    const product = await this.repository.findProductBySlug(slug, false);
    if (!product || product.status !== 'active' || !product.category.isActive) {
      throw ApiError.notFound('Product not found');
    }

    return toProductDetailDto(product, { includeInactiveChildren: false });
  }

  async getPublicProductByPublicId(productPublicId: string): Promise<ProductDetailDTO> {
    const product = await this.repository.findProductByPublicId(productPublicId, false);
    if (!product || product.status !== 'active' || !product.category.isActive) {
      throw ApiError.notFound('Product not found');
    }

    return toProductDetailDto(product, { includeInactiveChildren: false });
  }

  async listAdminCategories(): Promise<ProductCategoryDTO[]> {
    const records = await this.repository.listCategories(true);
    return records.map(toCategoryDto);
  }

  async createCategory(input: CreateCategoryInput): Promise<ProductCategoryDTO> {
    const created = await this.repository.createCategory({
      ...input,
      publicId: randomUUID(),
    });
    return toCategoryDto(created);
  }

  async updateCategory(
    categoryPublicId: string,
    input: UpdateCategoryInput
  ): Promise<ProductCategoryDTO> {
    const updated = await this.repository.updateCategory(categoryPublicId, input);
    if (!updated) {
      throw ApiError.notFound('Category not found');
    }
    return toCategoryDto(updated);
  }

  async listAdminProducts(query: AdminCatalogQueryInput): Promise<ProductListResponseData> {
    const result = await this.repository.listProducts({
      ...query,
      includeNonActive: true,
    });
    const totalPages = Math.max(1, Math.ceil(result.totalItems / query.pageSize));

    return {
      products: result.items.map((item) =>
        toProductSummaryDto(item, { includeInactiveChildren: true })
      ),
      pagination: {
        page: query.page,
        pageSize: query.pageSize,
        totalItems: result.totalItems,
        totalPages,
      },
      facets: this.buildProductFacets(result.items),
    };
  }

  async getAdminProductByPublicId(productPublicId: string): Promise<ProductDetailDTO> {
    const product = await this.repository.findProductByPublicId(productPublicId, true);
    if (!product) {
      throw ApiError.notFound('Product not found');
    }
    return toProductDetailDto(product, { includeInactiveChildren: true });
  }

  async createProduct(input: CreateProductInput): Promise<ProductDetailDTO> {
    const category = await this.repository.findCategoryByPublicId(input.categoryId);
    if (!category) {
      throw new ApiError(400, 'CATEGORY_NOT_FOUND', 'Selected apparel category does not exist');
    }

    const variants = (input.variants ?? []).map((variant) => ({
      ...variant,
      publicId: randomUUID(),
    }));
    const printAreas = (input.printAreas ?? []).map((area) => ({
      ...area,
      publicId: randomUUID(),
    }));
    const images = (input.images ?? []).map((img) => ({
      ...img,
      publicId: randomUUID(),
    }));

    this.assertPublishInvariants({
      status: input.status,
      isCustomizable: input.isCustomizable,
      activeVariantCount: variants.filter((v) => v.isActive).length,
      activePrintAreaCount: printAreas.filter((p) => p.isActive).length,
    });

    const created = await this.repository.createProduct({
      publicId: randomUUID(),
      categoryInternalId: category.id,
      slug: input.slug,
      skuPrefix: input.skuPrefix,
      nameEn: input.nameEn,
      nameBn: input.nameBn,
      subtitleEn: input.subtitleEn ?? null,
      subtitleBn: input.subtitleBn ?? null,
      descriptionEn: input.descriptionEn,
      descriptionBn: input.descriptionBn,
      fabricSpecEn: input.fabricSpecEn ?? null,
      fabricSpecBn: input.fabricSpecBn ?? null,
      gsm: input.gsm ?? null,
      fitType: input.fitType ?? null,
      basePrice: input.basePrice,
      isCustomizable: input.isCustomizable,
      status: input.status,
      featuredOrder: input.featuredOrder ?? null,
      images,
      variants,
      printAreas,
    });

    return toProductDetailDto(created, { includeInactiveChildren: true });
  }

  async updateProduct(
    productPublicId: string,
    input: UpdateProductInput
  ): Promise<ProductDetailDTO> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }

    let categoryInternalId: number | undefined;
    if (input.categoryId !== undefined) {
      const category = await this.repository.findCategoryByPublicId(input.categoryId);
      if (!category) {
        throw new ApiError(400, 'CATEGORY_NOT_FOUND', 'Selected apparel category does not exist');
      }
      categoryInternalId = category.id;
    }

    const targetStatus = input.status ?? existing.status;
    const targetCustomizable = input.isCustomizable ?? existing.isCustomizable;
    const activeVariants = existing.variants.filter((v) => v.deletedAt === null && v.isActive);
    const activePrintAreas = existing.printAreas.filter((p) => p.isActive);

    this.assertPublishInvariants({
      status: targetStatus,
      isCustomizable: targetCustomizable,
      activeVariantCount: activeVariants.length,
      activePrintAreaCount: activePrintAreas.length,
    });

    const { categoryId: _ignoredCategoryId, ...restInput } = input;
    const updated = await this.repository.updateProduct(existing.id, {
      ...restInput,
      categoryInternalId,
    });

    if (!updated) {
      throw ApiError.notFound('Product not found');
    }

    return toProductDetailDto(updated, { includeInactiveChildren: true });
  }

  async deleteProduct(productPublicId: string): Promise<string> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }
    const deleted = await this.repository.softDeleteProduct(existing.id);
    if (!deleted) {
      throw ApiError.notFound('Product not found');
    }
    return productPublicId;
  }

  async addProductImage(
    productPublicId: string,
    input: CreateProductImageInput
  ): Promise<ProductImageDTO> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }

    const created = await this.repository.addImage(existing.id, {
      ...input,
      publicId: randomUUID(),
    });
    return toImageDto(created);
  }

  async deleteProductImage(productPublicId: string, imagePublicId: string): Promise<string> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }

    const deleted = await this.repository.deleteImage(existing.id, imagePublicId);
    if (!deleted) {
      throw ApiError.notFound('Product image not found');
    }
    return imagePublicId;
  }

  async addVariant(productPublicId: string, input: CreateVariantInput): Promise<ProductVariantDTO> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }

    const created = await this.repository.addVariant(existing.id, {
      ...input,
      publicId: randomUUID(),
    });
    return toVariantDto(created, existing.basePrice);
  }

  async updateVariant(
    productPublicId: string,
    variantPublicId: string,
    input: UpdateVariantInput
  ): Promise<ProductVariantDTO> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }

    const updated = await this.repository.updateVariant(existing.id, variantPublicId, input);
    if (!updated) {
      throw ApiError.notFound('Product variant not found');
    }

    return toVariantDto(updated, existing.basePrice);
  }

  async deleteVariant(productPublicId: string, variantPublicId: string): Promise<string> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }

    const remainingActive = existing.variants.filter(
      (v) => v.deletedAt === null && v.isActive && v.publicId !== variantPublicId
    );
    if (existing.status === 'active' && remainingActive.length === 0) {
      throw new ApiError(
        400,
        'CATALOG_ACTIVE_PRODUCT_NEEDS_VARIANT',
        'Cannot remove the last active variant of a published product'
      );
    }

    const deleted = await this.repository.softDeleteVariant(existing.id, variantPublicId);
    if (!deleted) {
      throw ApiError.notFound('Product variant not found');
    }
    return variantPublicId;
  }

  async upsertPrintArea(
    productPublicId: string,
    input: UpsertPrintAreaInput
  ): Promise<ProductPrintAreaDTO> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }

    const saved = await this.repository.upsertPrintArea(existing.id, {
      ...input,
      publicId: randomUUID(),
    });
    return toPrintAreaDto(saved);
  }

  async updatePrintArea(
    productPublicId: string,
    printAreaPublicId: string,
    input: UpdatePrintAreaInput
  ): Promise<ProductPrintAreaDTO> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }

    const updated = await this.repository.updatePrintArea(existing.id, printAreaPublicId, input);
    if (!updated) {
      throw ApiError.notFound('Print area configuration not found');
    }
    return toPrintAreaDto(updated);
  }

  async deletePrintArea(productPublicId: string, printAreaPublicId: string): Promise<string> {
    const existing = await this.repository.findProductByPublicId(productPublicId, true);
    if (!existing) {
      throw ApiError.notFound('Product not found');
    }

    const remainingActive = existing.printAreas.filter(
      (area) => area.isActive && area.publicId !== printAreaPublicId
    );
    if (existing.status === 'active' && existing.isCustomizable && remainingActive.length === 0) {
      throw new ApiError(
        400,
        'CATALOG_ACTIVE_CUSTOMIZABLE_NEEDS_PRINT_AREA',
        'Cannot delete the last active print area on a published customizable garment'
      );
    }

    const deleted = await this.repository.deletePrintArea(existing.id, printAreaPublicId);
    if (!deleted) {
      throw ApiError.notFound('Print area configuration not found');
    }
    return printAreaPublicId;
  }
}
