import type {
  AdminCategoryMutationResponseData,
  AdminProductMutationResponseData,
  CategoryListResponseData,
  ProductDetailResponseData,
  ProductImageDTO,
  ProductListResponseData,
  ProductPrintAreaDTO,
  ProductVariantDTO,
} from '@your-choice/shared-types';
import {
  adminCatalogQuerySchema,
  categoryPublicIdParamSchema,
  createCategorySchema,
  createProductImageSchema,
  createProductSchema,
  createVariantSchema,
  imageParamsSchema,
  printAreaParamsSchema,
  productPublicIdParamSchema,
  updateCategorySchema,
  updatePrintAreaSchema,
  updateProductSchema,
  updateVariantSchema,
  upsertPrintAreaSchema,
  variantParamsSchema,
} from '@your-choice/validation';
import { type Request, type Response, Router } from 'express';
import { requireAuthContext, requirePermissions, requireRoles } from '../../middleware/auth.js';
import { validateRequest } from '../../middleware/validate.js';
import { sendSuccess } from '../../utils/api-response.js';
import type { AuditService } from '../audit/audit.service.js';
import type { CatalogService } from './catalog.service.js';

function getAuditRequestMeta(req: Request, res: Response) {
  return {
    ipAddress: req.ip ?? null,
    requestId: typeof res.locals.requestId === 'string' ? res.locals.requestId : null,
  };
}

export function createAdminCatalogRouter(
  catalogService: CatalogService,
  auditService: AuditService
): Router {
  const router = Router();

  router.get(
    '/categories',
    requireRoles('staff', 'admin', 'super_admin'),
    requirePermissions('catalog:read'),
    async (_req, res) => {
      const categories = await catalogService.listAdminCategories();
      sendSuccess<CategoryListResponseData>(res, { categories });
    }
  );

  router.post(
    '/categories',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({ body: createCategorySchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const category = await catalogService.createCategory(req.body);
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.category.created',
        entityType: 'product_category',
        entityPublicId: category.id,
        metadata: { slug: category.slug },
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<AdminCategoryMutationResponseData>(res, { category }, 201);
    }
  );

  router.patch(
    '/categories/:categoryPublicId',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({
      params: categoryPublicIdParamSchema,
      body: updateCategorySchema,
    }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const category = await catalogService.updateCategory(
        String(req.params.categoryPublicId),
        req.body
      );
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.category.updated',
        entityType: 'product_category',
        entityPublicId: category.id,
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<AdminCategoryMutationResponseData>(res, { category });
    }
  );

  router.get(
    '/products',
    requireRoles('staff', 'admin', 'super_admin'),
    requirePermissions('catalog:read'),
    validateRequest({ query: adminCatalogQuerySchema }),
    async (req, res) => {
      const query = adminCatalogQuerySchema.parse(req.query);
      const data = await catalogService.listAdminProducts(query);
      sendSuccess<ProductListResponseData>(res, data);
    }
  );

  router.get(
    '/products/:productPublicId',
    requireRoles('staff', 'admin', 'super_admin'),
    requirePermissions('catalog:read'),
    validateRequest({ params: productPublicIdParamSchema }),
    async (req, res) => {
      const product = await catalogService.getAdminProductByPublicId(
        String(req.params.productPublicId)
      );
      sendSuccess<ProductDetailResponseData>(res, { product });
    }
  );

  router.post(
    '/products',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({ body: createProductSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const product = await catalogService.createProduct(req.body);
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.product.created',
        entityType: 'product',
        entityPublicId: product.id,
        metadata: { slug: product.slug, status: product.status },
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<AdminProductMutationResponseData>(res, { product }, 201);
    }
  );

  router.patch(
    '/products/:productPublicId',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({
      params: productPublicIdParamSchema,
      body: updateProductSchema,
    }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const product = await catalogService.updateProduct(
        String(req.params.productPublicId),
        req.body
      );
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.product.updated',
        entityType: 'product',
        entityPublicId: product.id,
        metadata: { status: product.status },
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<AdminProductMutationResponseData>(res, { product });
    }
  );

  router.delete(
    '/products/:productPublicId',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({ params: productPublicIdParamSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const deletedId = await catalogService.deleteProduct(String(req.params.productPublicId));
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.product.deleted',
        entityType: 'product',
        entityPublicId: deletedId,
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<{ deletedId: string }>(res, { deletedId });
    }
  );

  router.post(
    '/products/:productPublicId/images',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({
      params: productPublicIdParamSchema,
      body: createProductImageSchema,
    }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const image = await catalogService.addProductImage(
        String(req.params.productPublicId),
        req.body
      );
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.image.added',
        entityType: 'product_image',
        entityPublicId: image.id,
        metadata: { productPublicId: req.params.productPublicId },
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<{ image: ProductImageDTO }>(res, { image }, 201);
    }
  );

  router.delete(
    '/products/:productPublicId/images/:imagePublicId',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({ params: imageParamsSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const deletedId = await catalogService.deleteProductImage(
        String(req.params.productPublicId),
        String(req.params.imagePublicId)
      );
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.image.deleted',
        entityType: 'product_image',
        entityPublicId: deletedId,
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<{ deletedId: string }>(res, { deletedId });
    }
  );

  router.post(
    '/products/:productPublicId/variants',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({
      params: productPublicIdParamSchema,
      body: createVariantSchema,
    }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const variant = await catalogService.addVariant(String(req.params.productPublicId), req.body);
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.variant.created',
        entityType: 'product_variant',
        entityPublicId: variant.id,
        metadata: { sku: variant.sku },
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<{ variant: ProductVariantDTO }>(res, { variant }, 201);
    }
  );

  router.patch(
    '/products/:productPublicId/variants/:variantPublicId',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({
      params: variantParamsSchema,
      body: updateVariantSchema,
    }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const variant = await catalogService.updateVariant(
        String(req.params.productPublicId),
        String(req.params.variantPublicId),
        req.body
      );
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.variant.updated',
        entityType: 'product_variant',
        entityPublicId: variant.id,
        metadata: { sku: variant.sku, stockQuantity: variant.stockQuantity },
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<{ variant: ProductVariantDTO }>(res, { variant });
    }
  );

  router.delete(
    '/products/:productPublicId/variants/:variantPublicId',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({ params: variantParamsSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const deletedId = await catalogService.deleteVariant(
        String(req.params.productPublicId),
        String(req.params.variantPublicId)
      );
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.variant.deleted',
        entityType: 'product_variant',
        entityPublicId: deletedId,
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<{ deletedId: string }>(res, { deletedId });
    }
  );

  router.put(
    '/products/:productPublicId/print-areas',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({
      params: productPublicIdParamSchema,
      body: upsertPrintAreaSchema,
    }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const printArea = await catalogService.upsertPrintArea(
        String(req.params.productPublicId),
        req.body
      );
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.print_area.upserted',
        entityType: 'product_print_area',
        entityPublicId: printArea.id,
        metadata: { surfaceKey: printArea.surfaceKey },
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<{ printArea: ProductPrintAreaDTO }>(res, { printArea });
    }
  );

  router.patch(
    '/products/:productPublicId/print-areas/:printAreaPublicId',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({
      params: printAreaParamsSchema,
      body: updatePrintAreaSchema,
    }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const printArea = await catalogService.updatePrintArea(
        String(req.params.productPublicId),
        String(req.params.printAreaPublicId),
        req.body
      );
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.print_area.updated',
        entityType: 'product_print_area',
        entityPublicId: printArea.id,
        metadata: { surfaceKey: printArea.surfaceKey },
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<{ printArea: ProductPrintAreaDTO }>(res, { printArea });
    }
  );

  router.delete(
    '/products/:productPublicId/print-areas/:printAreaPublicId',
    requireRoles('admin', 'super_admin'),
    requirePermissions('catalog:write'),
    validateRequest({ params: printAreaParamsSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const deletedId = await catalogService.deletePrintArea(
        String(req.params.productPublicId),
        String(req.params.printAreaPublicId)
      );
      await auditService.record({
        actorUserId: auth.internalUserId,
        action: 'catalog.print_area.deleted',
        entityType: 'product_print_area',
        entityPublicId: deletedId,
        ...getAuditRequestMeta(req, res),
      });
      sendSuccess<{ deletedId: string }>(res, { deletedId });
    }
  );

  return router;
}
