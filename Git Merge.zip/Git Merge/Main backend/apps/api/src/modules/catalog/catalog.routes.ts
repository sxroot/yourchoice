import type {
  CategoryListResponseData,
  ProductDetailResponseData,
  ProductListResponseData,
} from '@your-choice/shared-types';
import { catalogQuerySchema, productSlugParamSchema } from '@your-choice/validation';
import { Router } from 'express';
import { validateRequest } from '../../middleware/validate.js';
import { sendSuccess } from '../../utils/api-response.js';
import type { CatalogService } from './catalog.service.js';

export function createPublicCategoriesRouter(catalogService: CatalogService): Router {
  const router = Router();

  router.get('/', async (_req, res) => {
    const categories = await catalogService.listPublicCategories();
    sendSuccess<CategoryListResponseData>(res, { categories });
  });

  return router;
}

export function createPublicProductsRouter(catalogService: CatalogService): Router {
  const router = Router();

  router.get('/', validateRequest({ query: catalogQuerySchema }), async (req, res) => {
    const query = catalogQuerySchema.parse(req.query);
    const data = await catalogService.listPublicProducts(query);
    sendSuccess<ProductListResponseData>(res, data);
  });

  router.get('/:slug', validateRequest({ params: productSlugParamSchema }), async (req, res) => {
    const product = await catalogService.getPublicProductBySlug(String(req.params.slug));
    sendSuccess<ProductDetailResponseData>(res, { product });
  });

  return router;
}
