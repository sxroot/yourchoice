import type { CartDTO } from '@your-choice/shared-types';
import type { ApiEnv } from '../../config/env.js';
import { generateOpaqueToken, hashSessionToken } from '../auth/tokens.js';
import type {
  CartItemCustomizationPayload,
  CommerceRepository,
  ResolvedCartIdentity,
} from '../commerce/commerce.repository.js';

export interface ActiveCartResolution {
  identity: ResolvedCartIdentity;
  newRawGuestToken: string | null;
  expiresAt: Date;
}

export class CartService {
  constructor(
    private readonly commerceRepo: CommerceRepository,
    private readonly env: ApiEnv
  ) {}

  private computeExpiresAt(): Date {
    return new Date(Date.now() + this.env.CART_TTL_DAYS * 24 * 60 * 60 * 1000);
  }

  async resolveExistingCart(params: {
    userId: number | null;
    rawGuestCartToken: string | null;
  }): Promise<ResolvedCartIdentity | null> {
    if (params.userId !== null) {
      return this.commerceRepo.findCartByUserId(params.userId);
    }

    if (params.rawGuestCartToken) {
      return this.commerceRepo.findCartByGuestTokenHash(hashSessionToken(params.rawGuestCartToken));
    }

    return null;
  }

  async getOrCreateActiveCart(params: {
    userId: number | null;
    rawGuestCartToken: string | null;
  }): Promise<ActiveCartResolution> {
    const expiresAt = this.computeExpiresAt();
    const existing = await this.resolveExistingCart(params);
    if (existing) {
      return { identity: existing, newRawGuestToken: null, expiresAt };
    }

    if (params.userId !== null) {
      const created = await this.commerceRepo.createUserCart(params.userId, expiresAt);
      return { identity: created, newRawGuestToken: null, expiresAt };
    }

    const newRawGuestToken = generateOpaqueToken(32);
    const created = await this.commerceRepo.createGuestCart(
      hashSessionToken(newRawGuestToken),
      expiresAt
    );
    return { identity: created, newRawGuestToken, expiresAt };
  }

  async addItem(
    params: { userId: number | null; rawGuestCartToken: string | null },
    variantPublicId: string,
    quantity: number,
    customization?: CartItemCustomizationPayload
  ): Promise<{ cart: CartDTO; newRawGuestToken: string | null; expiresAt: Date }> {
    const resolved = await this.getOrCreateActiveCart(params);
    const cart = await this.commerceRepo.upsertCartItem(
      resolved.identity.cartId,
      variantPublicId,
      quantity,
      customization
    );
    return {
      cart,
      newRawGuestToken: resolved.newRawGuestToken,
      expiresAt: resolved.expiresAt,
    };
  }

  async updateItemQuantity(
    params: { userId: number | null; rawGuestCartToken: string | null },
    itemPublicId: string,
    quantity: number
  ): Promise<CartDTO | null> {
    const existing = await this.resolveExistingCart(params);
    if (!existing) {
      return null;
    }
    return this.commerceRepo.updateCartItemQuantity(existing.cartId, itemPublicId, quantity);
  }

  async removeItem(
    params: { userId: number | null; rawGuestCartToken: string | null },
    itemPublicId: string
  ): Promise<CartDTO | null> {
    const existing = await this.resolveExistingCart(params);
    if (!existing) {
      return null;
    }
    return this.commerceRepo.removeCartItem(existing.cartId, itemPublicId);
  }

  async clearActiveCart(params: {
    userId: number | null;
    rawGuestCartToken: string | null;
  }): Promise<CartDTO | null> {
    const existing = await this.resolveExistingCart(params);
    if (!existing) {
      return null;
    }
    return this.commerceRepo.clearCart(existing.cartId);
  }

  async mergeGuestCartForAuthenticatedUser(
    rawGuestCartToken: string | null,
    userId: number
  ): Promise<void> {
    if (!rawGuestCartToken) {
      return;
    }
    await this.commerceRepo.mergeGuestCartToUser(
      hashSessionToken(rawGuestCartToken),
      userId,
      this.computeExpiresAt()
    );
  }
}
