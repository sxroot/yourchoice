import type { CartDTO, CartResponseData } from '@your-choice/shared-types';
import {
  addCartItemSchema,
  cartItemIdParamSchema,
  updateCartItemSchema,
} from '@your-choice/validation';
import { type Request, type Response, Router } from 'express';
import type { ApiEnv } from '../../config/env.js';
import { getAuthContext } from '../../middleware/auth.js';
import { validateRequest } from '../../middleware/validate.js';
import { ApiError } from '../../utils/api-error.js';
import { sendSuccess } from '../../utils/api-response.js';
import { buildCartCookieOptions, parseCookieHeader } from '../../utils/cookies.js';
import type { CartService } from './cart.service.js';

function readCartActor(req: Request, res: Response, env: ApiEnv) {
  const auth = getAuthContext(res);
  const cookies = parseCookieHeader(req.headers.cookie);
  return {
    userId: auth?.internalUserId ?? null,
    rawGuestCartToken: cookies[env.CART_COOKIE_NAME] ?? null,
  };
}

function createEmptyCartDto(): CartDTO {
  return {
    id: '00000000-0000-0000-0000-000000000000',
    items: [],
    itemCount: 0,
    subtotal: '0.00',
    currencyCode: 'BDT',
    hasUnavailableItems: false,
    expiresAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
  };
}

export function createCartRouter(cartService: CartService, env: ApiEnv): Router {
  const router = Router();

  router.get('/', async (req, res) => {
    const actor = readCartActor(req, res, env);
    const resolved = await cartService.resolveExistingCart(actor);
    sendSuccess<CartResponseData>(res, {
      cart: resolved?.dto ?? createEmptyCartDto(),
    });
  });

  router.post('/items', validateRequest({ body: addCartItemSchema }), async (req, res) => {
    const actor = readCartActor(req, res, env);
    const { variantId, quantity } = req.body as { variantId: string; quantity: number };
    const result = await cartService.addItem(actor, variantId, quantity);

    if (result.newRawGuestToken) {
      res.cookie(
        env.CART_COOKIE_NAME,
        result.newRawGuestToken,
        buildCartCookieOptions(env, result.expiresAt)
      );
    }

    sendSuccess<CartResponseData>(res, { cart: result.cart }, 201);
  });

  router.patch(
    '/items/:itemId',
    validateRequest({ params: cartItemIdParamSchema, body: updateCartItemSchema }),
    async (req, res) => {
      const actor = readCartActor(req, res, env);
      const { itemId } = req.params as { itemId: string };
      const { quantity } = req.body as { quantity: number };

      const cart = await cartService.updateItemQuantity(actor, itemId, quantity);
      if (!cart) {
        throw ApiError.notFound('Cart item not found');
      }

      sendSuccess<CartResponseData>(res, { cart });
    }
  );

  router.delete(
    '/items/:itemId',
    validateRequest({ params: cartItemIdParamSchema }),
    async (req, res) => {
      const actor = readCartActor(req, res, env);
      const { itemId } = req.params as { itemId: string };
      const cart = await cartService.removeItem(actor, itemId);

      sendSuccess<CartResponseData>(res, {
        cart: cart ?? createEmptyCartDto(),
      });
    }
  );

  router.delete('/', async (req, res) => {
    const actor = readCartActor(req, res, env);
    const cart = await cartService.clearActiveCart(actor);

    sendSuccess<CartResponseData>(res, {
      cart: cart ?? createEmptyCartDto(),
    });
  });

  return router;
}
