import type {
  AddressListResponseData,
  AddressMutationResponseData,
  AuthUserDTO,
  DeleteAddressResponseData,
} from '@your-choice/shared-types';
import {
  addressPublicIdParamSchema,
  createAddressSchema,
  updateAddressSchema,
  updateProfileSchema,
  userPublicIdParamSchema,
} from '@your-choice/validation';
import { Router } from 'express';
import {
  requireAuth,
  requireAuthContext,
  requireOwnershipOrRole,
  requirePermissions,
} from '../../middleware/auth.js';
import { validateRequest } from '../../middleware/validate.js';
import { sendSuccess } from '../../utils/api-response.js';
import type { AddressService } from '../addresses/address.service.js';
import type { AuthService } from '../auth/auth.service.js';

export function createUsersRouter(
  authService: AuthService,
  addressService: AddressService
): Router {
  const router = Router();

  router.use(requireAuth);

  router.get('/me', requirePermissions('profile:read:own'), (_req, res) => {
    const auth = requireAuthContext(res);
    sendSuccess<{ user: AuthUserDTO }>(res, {
      user: auth.user,
    });
  });

  router.patch(
    '/me',
    requirePermissions('profile:write:own'),
    validateRequest({ body: updateProfileSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const updatedUser = await authService.updateOwnProfile(auth.internalUserId, req.body);
      sendSuccess<{ user: AuthUserDTO }>(res, { user: updatedUser });
    }
  );

  router.get('/me/addresses', requirePermissions('profile:read:own'), async (_req, res) => {
    const auth = requireAuthContext(res);
    const addresses = await addressService.listAddresses(auth.internalUserId);
    sendSuccess<AddressListResponseData>(res, { addresses });
  });

  router.post(
    '/me/addresses',
    requirePermissions('profile:write:own'),
    validateRequest({ body: createAddressSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const address = await addressService.createAddress(auth.internalUserId, req.body);
      sendSuccess<AddressMutationResponseData>(res, { address }, 201);
    }
  );

  router.patch(
    '/me/addresses/:addressPublicId',
    requirePermissions('profile:write:own'),
    validateRequest({
      params: addressPublicIdParamSchema,
      body: updateAddressSchema,
    }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const address = await addressService.updateAddress(
        auth.internalUserId,
        String(req.params.addressPublicId),
        req.body
      );
      sendSuccess<AddressMutationResponseData>(res, { address });
    }
  );

  router.delete(
    '/me/addresses/:addressPublicId',
    requirePermissions('profile:write:own'),
    validateRequest({ params: addressPublicIdParamSchema }),
    async (req, res) => {
      const auth = requireAuthContext(res);
      const deletedId = await addressService.deleteAddress(
        auth.internalUserId,
        String(req.params.addressPublicId)
      );
      sendSuccess<DeleteAddressResponseData>(res, { deletedId });
    }
  );

  router.get(
    '/:userPublicId',
    validateRequest({ params: userPublicIdParamSchema }),
    requireOwnershipOrRole({
      resolveOwnerPublicId: (req) => String(req.params.userPublicId ?? ''),
      bypassRoles: ['admin', 'super_admin'],
    }),
    async (req, res) => {
      const targetUser = await authService.getUserByPublicId(String(req.params.userPublicId));
      sendSuccess<{ user: AuthUserDTO }>(res, { user: targetUser });
    }
  );

  return router;
}
