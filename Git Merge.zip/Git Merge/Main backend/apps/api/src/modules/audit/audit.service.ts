import { auditLogs } from '@your-choice/database/schema';
import type { Logger } from 'pino';
import type { AppDatabase } from '../../database/client.js';

export interface AuditEventInput {
  actorUserId: number | null;
  action: string;
  entityType: string;
  entityPublicId?: string | null;
  metadata?: Record<string, unknown> | null;
  ipAddress?: string | null;
  requestId?: string | null;
}

export interface AuditRepository {
  insert(entry: AuditEventInput): Promise<void>;
}

export class DrizzleAuditRepository implements AuditRepository {
  constructor(private readonly db: AppDatabase) {}

  async insert(entry: AuditEventInput): Promise<void> {
    await this.db.insert(auditLogs).values({
      actorUserId: entry.actorUserId,
      action: entry.action,
      entityType: entry.entityType,
      entityPublicId: entry.entityPublicId ?? null,
      metadataJson: entry.metadata ?? null,
      ipAddress: entry.ipAddress ? entry.ipAddress.slice(0, 64) : null,
      requestId: entry.requestId ? entry.requestId.slice(0, 64) : null,
    });
  }
}

export class AuditService {
  constructor(
    private readonly logger: Logger,
    private readonly repository?: AuditRepository
  ) {}

  async record(entry: AuditEventInput): Promise<void> {
    this.logger.info(
      {
        auditAction: entry.action,
        entityType: entry.entityType,
        entityPublicId: entry.entityPublicId ?? null,
        actorUserId: entry.actorUserId,
        requestId: entry.requestId ?? null,
        metadata: entry.metadata ?? null,
      },
      'Audit event recorded'
    );

    if (!this.repository) {
      return;
    }

    try {
      await this.repository.insert(entry);
    } catch (error: unknown) {
      this.logger.warn(
        { error, auditAction: entry.action, entityType: entry.entityType },
        'Best-effort audit log insert failed'
      );
    }
  }
}
