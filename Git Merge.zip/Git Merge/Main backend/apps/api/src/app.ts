import cors from 'cors';
import express, { type Express } from 'express';
import helmet from 'helmet';
import type { Logger } from 'pino';
import type { ApiEnv } from './config/env.js';
import type { AppDatabase } from './database/client.js';
import type { DatabasePingFn } from './database/health.js';
import { createAttachAuthMiddleware } from './middleware/auth.js';
import { createCsrfProtectionMiddleware } from './middleware/csrf.js';
import { createErrorHandler } from './middleware/error-handler.js';
import { notFoundHandler } from './middleware/not-found.js';
import type { AuthRateLimitConfig } from './middleware/rate-limit.js';
import { requestContextMiddleware } from './middleware/request-context.js';
import { createRequestLogger } from './middleware/request-logger.js';
import type { AddressRepository } from './modules/addresses/address.repository.js';
import { AddressService } from './modules/addresses/address.service.js';
import { DrizzleAddressRepository } from './modules/addresses/drizzle-address.repository.js';
import { createAdminRouter } from './modules/admin/admin.routes.js';
import {
  type AuditRepository,
  AuditService,
  DrizzleAuditRepository,
} from './modules/audit/audit.service.js';
import { createAuthRouter } from './modules/auth/auth.routes.js';
import { AuthService } from './modules/auth/auth.service.js';
import { DrizzleIdentityRepository } from './modules/auth/drizzle-identity.repository.js';
import type { IdentityRepository } from './modules/auth/identity.repository.js';
import { createAdminCatalogRouter } from './modules/catalog/admin-catalog.routes.js';
import type { CatalogRepository } from './modules/catalog/catalog.repository.js';
import {
  createPublicCategoriesRouter,
  createPublicProductsRouter,
} from './modules/catalog/catalog.routes.js';
import { CatalogService } from './modules/catalog/catalog.service.js';
import { DrizzleCatalogRepository } from './modules/catalog/drizzle-catalog.repository.js';
import { createCartRouter } from './modules/cart/cart.routes.js';
import { CartService } from './modules/cart/cart.service.js';
import type { CommerceRepository } from './modules/commerce/commerce.repository.js';
import { DrizzleCommerceRepository } from './modules/commerce/drizzle-commerce.repository.js';
import type { DesignRepository } from './modules/designs/design.repository.js';
import { DesignService } from './modules/designs/design.service.js';
import { createDesignsRouter } from './modules/designs/designs.routes.js';
import { DrizzleDesignRepository } from './modules/designs/drizzle-design.repository.js';
import { createCreatorRouter } from './modules/creator/creator.routes.js';
import { createHealthRouter } from './modules/health/health.routes.js';
import { createHealthService } from './modules/health/health.service.js';
import { createAdminOrdersRouter } from './modules/orders/admin-orders.routes.js';
import { OrderService } from './modules/orders/order.service.js';
import { createCheckoutOptionsRouter, createOrdersRouter } from './modules/orders/orders.routes.js';
import { PaymentService } from './modules/payments/payment.service.js';
import { createPaymentWebhookRouter } from './modules/payments/payments.routes.js';
import { createShippingRouter } from './modules/shipping/shipping.routes.js';
import { ShippingService } from './modules/shipping/shipping.service.js';
import { createUsersRouter } from './modules/users/users.routes.js';
import { LocalDiskStorageService, type StorageService } from './modules/storage/storage.service.js';
import { ApiError } from './utils/api-error.js';

export interface AppDependencies {
  env: ApiEnv;
  logger: Logger;
  pingDatabase: DatabasePingFn;
  db?: AppDatabase;
  identityRepository?: IdentityRepository;
  addressRepository?: AddressRepository;
  catalogRepository?: CatalogRepository;
  commerceRepository?: CommerceRepository;
  designRepository?: DesignRepository;
  storageService?: StorageService;
  auditRepository?: AuditRepository;
  authRateLimits?: AuthRateLimitConfig;
}

function createUnavailableIdentityRepository(): IdentityRepository {
  const fail = (): never => {
    throw ApiError.serviceUnavailable('Identity database client is not configured');
  };

  return {
    findUserByEmail: fail,
    findUserByPublicId: fail,
    createUser: fail,
    createSession: fail,
    findActiveSessionByTokenHash: fail,
    touchSession: fail,
    revokeSessionById: fail,
    revokeAllUserSessions: fail,
    updateLastLoginAt: fail,
    updateUserProfile: fail,
    replaceUserRoles: fail,
    listUsersSummary: fail,
  };
}

function createUnavailableAddressRepository(): AddressRepository {
  const fail = (): never => {
    throw ApiError.serviceUnavailable('Address database client is not configured');
  };

  return {
    listByUserId: fail,
    findByPublicIdAndUserId: fail,
    create: fail,
    update: fail,
    softDelete: fail,
  };
}

function createUnavailableCatalogRepository(): CatalogRepository {
  const fail = (): never => {
    throw ApiError.serviceUnavailable('Catalog database client is not configured');
  };

  return {
    listCategories: fail,
    findCategoryByPublicId: fail,
    createCategory: fail,
    updateCategory: fail,
    listProducts: fail,
    findProductBySlug: fail,
    findProductByPublicId: fail,
    createProduct: fail,
    updateProduct: fail,
    softDeleteProduct: fail,
    addImage: fail,
    deleteImage: fail,
    addVariant: fail,
    updateVariant: fail,
    softDeleteVariant: fail,
    upsertPrintArea: fail,
    updatePrintArea: fail,
    deletePrintArea: fail,
  };
}

function createUnavailableCommerceRepository(): CommerceRepository {
  const fail = (): never => {
    throw ApiError.serviceUnavailable('Commerce database client is not configured');
  };

  return {
    listActiveShippingZones: fail,
    findShippingZoneByDivision: fail,
    findCartByUserId: fail,
    findCartByGuestTokenHash: fail,
    createUserCart: fail,
    createGuestCart: fail,
    upsertCartItem: fail,
    updateCartItemQuantity: fail,
    removeCartItem: fail,
    clearCart: fail,
    mergeGuestCartToUser: fail,
    placeOrderTransactionally: fail,
    listOrdersByUserId: fail,
    findOrderByNumber: fail,
    cancelOrderTransactionally: fail,
    adminListOrders: fail,
    adminUpdateOrderStatus: fail,
    adminSettleCodPayment: fail,
    applyVerifiedPaymentWebhook: fail,
  };
}

function createUnavailableDesignRepository(): DesignRepository {
  const fail = (): never => {
    throw ApiError.serviceUnavailable('Design database client is not configured');
  };

  return {
    createAsset: fail,
    listAssetsByOwner: fail,
    findAssetByPublicId: fail,
    findAssetsByPublicIds: fail,
    listDesignsByOwner: fail,
    findDesignByPublicId: fail,
    createDesign: fail,
    updateDesign: fail,
    softDeleteDesign: fail,
    recordPrintExport: fail,
    findPrintExportByPublicId: fail,
  };
}

export function createApp({
  env,
  logger,
  pingDatabase,
  db,
  identityRepository,
  addressRepository,
  catalogRepository,
  commerceRepository,
  designRepository,
  storageService,
  auditRepository,
  authRateLimits,
}: AppDependencies): Express {
  const app = express();

  app.disable('x-powered-by');
  if (env.TRUST_PROXY) {
    app.set('trust proxy', 1);
  }

  app.use(requestContextMiddleware);
  app.use(createRequestLogger(logger));
  app.use(helmet());
  app.use(
    cors({
      origin: (origin, callback) => {
        if (!origin || env.corsOriginsList.includes(origin)) {
          callback(null, true);
          return;
        }
        callback(new ApiError(403, 'CORS_ORIGIN_DENIED', 'Origin is not allowed by CORS'));
      },
      credentials: true,
    })
  );
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));

  const healthService = createHealthService(env, pingDatabase);
  const healthRouter = createHealthRouter(healthService);

  app.use('/api/health', healthRouter);

  const resolvedIdentityRepo =
    identityRepository ??
    (db ? new DrizzleIdentityRepository(db) : createUnavailableIdentityRepository());
  const resolvedAddressRepo =
    addressRepository ??
    (db ? new DrizzleAddressRepository(db) : createUnavailableAddressRepository());
  const resolvedCatalogRepo =
    catalogRepository ??
    (db ? new DrizzleCatalogRepository(db) : createUnavailableCatalogRepository());
  const resolvedCommerceRepo =
    commerceRepository ??
    (db ? new DrizzleCommerceRepository(db) : createUnavailableCommerceRepository());
  const resolvedDesignRepo =
    designRepository ??
    (db ? new DrizzleDesignRepository(db, env.API_PREFIX) : createUnavailableDesignRepository());
  const resolvedStorage = storageService ?? new LocalDiskStorageService(env.STORAGE_LOCAL_ROOT);
  const resolvedAuditRepo = auditRepository ?? (db ? new DrizzleAuditRepository(db) : undefined);

  const authService = new AuthService(resolvedIdentityRepo, env);
  const addressService = new AddressService(resolvedAddressRepo);
  const catalogService = new CatalogService(resolvedCatalogRepo);
  const auditService = new AuditService(logger, resolvedAuditRepo);
  const shippingService = new ShippingService(resolvedCommerceRepo);
  const paymentService = new PaymentService(resolvedCommerceRepo, env);
  const cartService = new CartService(resolvedCommerceRepo, env);
  const designService = new DesignService(
    resolvedDesignRepo,
    catalogService,
    cartService,
    resolvedStorage,
    auditService,
    env
  );
  const orderService = new OrderService(
    resolvedCommerceRepo,
    cartService,
    shippingService,
    paymentService,
    addressService,
    auditService,
    env
  );

  // Payment provider webhooks use provider HMAC signatures instead of browser CSRF cookies.
  app.use(`${env.API_PREFIX}/payments/webhooks`, createPaymentWebhookRouter(paymentService));

  const apiV1 = express.Router();
  apiV1.use('/health', healthRouter);

  // Stateful API routes validate session cookies and enforce CSRF/Origin rules on mutations.
  apiV1.use(createCsrfProtectionMiddleware(env));
  apiV1.use(createAttachAuthMiddleware(authService, env));

  apiV1.use('/auth', createAuthRouter(authService, env, authRateLimits, cartService));
  apiV1.use('/users', createUsersRouter(authService, addressService));
  apiV1.use('/categories', createPublicCategoriesRouter(catalogService));
  apiV1.use('/products', createPublicProductsRouter(catalogService));
  apiV1.use('/shipping', createShippingRouter(shippingService));
  apiV1.use('/cart', createCartRouter(cartService, env));
  apiV1.use('/designs', createDesignsRouter(designService, env));
  apiV1.use('/checkout', createCheckoutOptionsRouter(orderService));
  apiV1.use('/orders', createOrdersRouter(orderService, env));
  apiV1.use('/creator', createCreatorRouter());
  apiV1.use('/admin', createAdminRouter(authService));
  apiV1.use('/admin', createAdminCatalogRouter(catalogService, auditService));
  apiV1.use('/admin', createAdminOrdersRouter(orderService));

  app.use(env.API_PREFIX, apiV1);

  app.use(notFoundHandler);
  app.use(createErrorHandler(logger, env.NODE_ENV === 'production'));

  return app;
}
