import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { z } from 'zod';
import { parseCorsOrigins } from '@your-choice/shared-utils';

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const repoRootDir = path.resolve(currentDir, '../../../..');

const booleanFlagSchema = z
  .union([z.boolean(), z.enum(['true', 'false', '1', '0'])])
  .transform((value) => value === true || value === 'true' || value === '1');

export const apiEnvSchema = z
  .object({
    NODE_ENV: z.enum(['development', 'test', 'staging', 'production']).default('development'),
    APP_NAME: z.string().trim().min(1).default('YOUR CHOICE'),
    APP_VERSION: z.string().trim().min(1).default('0.1.0'),
    API_HOST: z.string().trim().min(1).default('0.0.0.0'),
    API_PORT: z.coerce.number().int().min(1).max(65535).default(4000),
    API_PREFIX: z.string().trim().startsWith('/').default('/api/v1'),
    APP_URL: z.string().url().default('http://localhost:4000'),
    WEB_URL: z.string().url().default('http://localhost:5173'),
    CORS_ORIGINS: z.string().default('http://localhost:5173'),
    LOG_LEVEL: z
      .enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent'])
      .default('info'),
    TRUST_PROXY: booleanFlagSchema.default(false),

    DB_HOST: z.string().trim().min(1).default('127.0.0.1'),
    DB_PORT: z.coerce.number().int().min(1).max(65535).default(3306),
    DB_USER: z.string().trim().min(1).default('your_choice_dev'),
    DB_PASSWORD: z.string().default(''),
    DB_NAME: z.string().trim().min(1).default('your_choice_dev'),
    DB_CONNECTION_LIMIT: z.coerce.number().int().min(1).max(100).default(10),
    DB_SSL: booleanFlagSchema.default(false),
    DATABASE_URL: z.string().trim().optional(),

    SESSION_SECRET: z.string().min(16).default('dev-only-change-this-session-secret-min-32-chars'),
    SESSION_COOKIE_NAME: z.string().trim().min(1).default('yc_session'),
    SESSION_TTL_HOURS: z.coerce.number().int().min(1).max(8760).default(168),
    CART_COOKIE_NAME: z.string().trim().min(1).default('yc_cart'),
    CART_TTL_DAYS: z.coerce.number().int().min(1).max(90).default(14),
    CSRF_ENABLED: booleanFlagSchema.default(true),

    BKASH_WEBHOOK_SECRET: z.string().trim().min(16).optional(),
    NAGAD_WEBHOOK_SECRET: z.string().trim().min(16).optional(),
    SSLCOMMERZ_STORE_PASSWD: z.string().trim().min(8).optional(),

    STORAGE_DRIVER: z.enum(['local', 's3']).default('local'),
    STORAGE_LOCAL_ROOT: z.string().trim().min(1).default('./storage'),
    S3_ENDPOINT: z.string().url().optional(),
    S3_REGION: z.string().trim().min(1).default('auto'),
    S3_BUCKET: z.string().trim().min(1).optional(),
    S3_ACCESS_KEY_ID: z.string().trim().min(1).optional(),
    S3_SECRET_ACCESS_KEY: z.string().trim().min(1).optional(),

    REDIS_ENABLED: booleanFlagSchema.default(false),
    REDIS_URL: z.string().trim().optional(),
  })
  .superRefine((values, ctx) => {
    const isStrictEnv = values.NODE_ENV === 'production' || values.NODE_ENV === 'staging';

    if (isStrictEnv) {
      if (values.SESSION_SECRET.length < 32 || values.SESSION_SECRET.includes('dev-only')) {
        ctx.addIssue({
          code: 'custom',
          path: ['SESSION_SECRET'],
          message:
            'SESSION_SECRET must be at least 32 characters and non-default in staging/production.',
        });
      }

      if (!values.DATABASE_URL && values.DB_PASSWORD.length === 0) {
        ctx.addIssue({
          code: 'custom',
          path: ['DB_PASSWORD'],
          message: 'DB_PASSWORD or DATABASE_URL is required in staging/production.',
        });
      }
    }

    if (values.STORAGE_DRIVER === 's3') {
      const requiredS3Fields = ['S3_BUCKET', 'S3_ACCESS_KEY_ID', 'S3_SECRET_ACCESS_KEY'] as const;
      for (const field of requiredS3Fields) {
        if (!values[field]) {
          ctx.addIssue({
            code: 'custom',
            path: [field],
            message: `${field} is required when STORAGE_DRIVER=s3.`,
          });
        }
      }
    }

    if (values.REDIS_ENABLED && !values.REDIS_URL) {
      ctx.addIssue({
        code: 'custom',
        path: ['REDIS_URL'],
        message: 'REDIS_URL is required when REDIS_ENABLED=true.',
      });
    }
  });

export type RawApiEnv = z.infer<typeof apiEnvSchema>;

export interface ApiEnv extends RawApiEnv {
  corsOriginsList: string[];
}

export function parseApiEnv(raw: Record<string, string | undefined>): ApiEnv {
  const parsed = apiEnvSchema.safeParse(raw);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((issue) => `${issue.path.join('.') || 'env'}: ${issue.message}`)
      .join('; ');
    throw new Error(`Invalid API environment configuration: ${issues}`);
  }

  return {
    ...parsed.data,
    corsOriginsList: parseCorsOrigins(parsed.data.CORS_ORIGINS),
  };
}

let cachedEnv: ApiEnv | null = null;

export function getEnv(): ApiEnv {
  if (!cachedEnv) {
    dotenv.config({ path: path.join(repoRootDir, '.env'), quiet: true });
    cachedEnv = parseApiEnv(process.env);
  }
  return cachedEnv;
}
