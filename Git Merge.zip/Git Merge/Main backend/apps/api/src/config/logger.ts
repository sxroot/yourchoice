import pino, { type Logger } from 'pino';
import type { ApiEnv } from './env.js';

export function createLogger(env: Pick<ApiEnv, 'NODE_ENV' | 'LOG_LEVEL' | 'APP_NAME'>): Logger {
  const isDev = env.NODE_ENV === 'development';

  return pino({
    name: env.APP_NAME,
    level: env.NODE_ENV === 'test' ? 'silent' : env.LOG_LEVEL,
    redact: {
      paths: [
        'req.headers.authorization',
        'req.headers.cookie',
        'req.headers["x-api-key"]',
        'req.headers["x-csrf-token"]',
        'res.headers["set-cookie"]',
        '*.password',
        '*.passwordHash',
        '*.secret',
        '*.token',
        '*.apiKey',
        '*.accessKeyId',
        '*.secretAccessKey',
        '*.sessionSecret',
        '*.credentials',
      ],
      censor: '[REDACTED]',
    },
    ...(isDev
      ? {
          transport: {
            target: 'pino-pretty',
            options: {
              colorize: true,
              translateTime: 'SYS:standard',
              ignore: 'pid,hostname',
            },
          },
        }
      : {}),
  });
}
