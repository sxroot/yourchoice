import { describe, expect, it } from 'vitest';
import { parseApiEnv } from '../src/config/env.js';

describe('API environment validation', () => {
  it('parses valid development defaults cleanly', () => {
    const env = parseApiEnv({
      NODE_ENV: 'development',
      API_PORT: '4000',
      CORS_ORIGINS: 'http://localhost:5173, http://127.0.0.1:5173',
    });

    expect(env.NODE_ENV).toBe('development');
    expect(env.API_PORT).toBe(4000);
    expect(env.corsOriginsList).toEqual(['http://localhost:5173', 'http://127.0.0.1:5173']);
  });

  it('rejects weak default session secrets in production', () => {
    expect(() =>
      parseApiEnv({
        NODE_ENV: 'production',
        DB_PASSWORD: 'secure-db-password',
        SESSION_SECRET: 'dev-only-change-this-session-secret-min-32-chars',
      })
    ).toThrow(/SESSION_SECRET/);
  });

  it('requires REDIS_URL when REDIS_ENABLED=true', () => {
    expect(() =>
      parseApiEnv({
        NODE_ENV: 'development',
        REDIS_ENABLED: 'true',
      })
    ).toThrow(/REDIS_URL/);
  });

  it('requires S3 credentials when STORAGE_DRIVER=s3', () => {
    expect(() =>
      parseApiEnv({
        NODE_ENV: 'development',
        STORAGE_DRIVER: 's3',
      })
    ).toThrow(/S3_BUCKET/);
  });
});
