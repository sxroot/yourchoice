import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { parseApiEnv } from '../src/config/env.js';
import { createLogger } from '../src/config/logger.js';
import type { AuthRateLimitConfig } from '../src/middleware/rate-limit.js';
import { hashPassword, verifyPassword } from '../src/modules/auth/password.js';
import {
  createSignedCsrfToken,
  hashSessionToken,
  verifySignedCsrfToken,
} from '../src/modules/auth/tokens.js';
import { InMemoryIdentityRepository } from './helpers/in-memory-identity.js';

function createAuthTestApp(rateLimits?: AuthRateLimitConfig) {
  const env = parseApiEnv({
    NODE_ENV: 'test',
    LOG_LEVEL: 'silent',
    CORS_ORIGINS: 'http://localhost:5173',
    SESSION_SECRET: 'test-session-secret-must-be-long-enough-1234',
    SESSION_COOKIE_NAME: 'yc_session',
    SESSION_TTL_HOURS: '168',
    CSRF_ENABLED: 'true',
  });
  const logger = createLogger(env);
  const repo = new InMemoryIdentityRepository();

  const app = createApp({
    env,
    logger,
    pingDatabase: async () => ({ status: 'up', dialect: 'mariadb', latencyMs: 1.0 }),
    identityRepository: repo,
    authRateLimits: rateLimits,
  });

  return { app, env, repo };
}

function extractSetCookies(res: request.Response): Record<string, string> {
  const rawSetCookie = res.headers['set-cookie'];
  const headerArray = Array.isArray(rawSetCookie)
    ? rawSetCookie
    : rawSetCookie
      ? [rawSetCookie]
      : [];

  const jar: Record<string, string> = {};
  for (const header of headerArray) {
    const firstPart = header.split(';')[0] ?? '';
    const eqIndex = firstPart.indexOf('=');
    if (eqIndex > 0) {
      const name = firstPart.slice(0, eqIndex).trim();
      const val = decodeURIComponent(firstPart.slice(eqIndex + 1).trim());
      jar[name] = val;
    }
  }
  return jar;
}

async function fetchCsrf(app: ReturnType<typeof createApp>) {
  const res = await request(app).get('/api/v1/auth/csrf');
  const cookies = extractSetCookies(res);
  const token = res.body.data.csrfToken as string;
  return {
    token,
    cookieHeader: `yc_csrf=${encodeURIComponent(cookies.yc_csrf ?? token)}`,
  };
}

describe('Phase 1A Identity, Authentication, Sessions & RBAC', () => {
  it('hashes passwords with Argon2id and signs CSRF/session tokens securely', async () => {
    const digest = await hashPassword('ChoicePass99');
    expect(digest.startsWith('$argon2id$')).toBe(true);
    expect(await verifyPassword(digest, 'ChoicePass99')).toBe(true);
    expect(await verifyPassword(digest, 'WrongPass99')).toBe(false);

    const tokenHash = hashSessionToken('raw-secret-token-value');
    expect(tokenHash).toHaveLength(64);
    expect(tokenHash).not.toContain('raw-secret-token-value');

    const secret = 'test-secret-012345678901234567890123';
    const csrf = createSignedCsrfToken(secret);
    expect(verifySignedCsrfToken(csrf, secret)).toBe(true);
    expect(verifySignedCsrfToken(`${csrf}tamper`, secret)).toBe(false);
  });

  it('registers a customer, stores hashed session in repository, sets HttpOnly cookie, and prevents duplicate emails', async () => {
    const { app, repo } = createAuthTestApp();
    const csrf = await fetchCsrf(app);

    const registerRes = await request(app)
      .post('/api/v1/auth/register')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', csrf.cookieHeader)
      .set('X-CSRF-Token', csrf.token)
      .send({
        fullName: 'Tanvir Ahmed',
        email: 'Tanvir@Example.com',
        password: 'StrongPassword123',
        confirmPassword: 'StrongPassword123',
      });

    expect(registerRes.status).toBe(201);
    expect(registerRes.body.success).toBe(true);
    expect(registerRes.body.data.user.email).toBe('tanvir@example.com');
    expect(registerRes.body.data.user.roles).toEqual(['customer']);
    expect(registerRes.body.data.user.passwordHash).toBeUndefined();

    const rawSetCookieHeader = String(registerRes.headers['set-cookie']);
    expect(rawSetCookieHeader).toContain('yc_session=');
    expect(rawSetCookieHeader).toContain('HttpOnly');
    expect(rawSetCookieHeader).toContain('SameSite=Lax');

    const cookies = extractSetCookies(registerRes);
    const rawSessionCookie = cookies.yc_session!;
    const storedSession = repo.getRawSessionByPublicId(registerRes.body.data.session.id);
    expect(storedSession).toBeDefined();
    expect(storedSession!.tokenHash).toBe(hashSessionToken(rawSessionCookie));
    expect(storedSession!.tokenHash).not.toBe(rawSessionCookie);

    // Duplicate registration returns safe 409 conflict
    const duplicateRes = await request(app)
      .post('/api/v1/auth/register')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', csrf.cookieHeader)
      .set('X-CSRF-Token', csrf.token)
      .send({
        fullName: 'Duplicate Tanvir',
        email: 'tanvir@example.com',
        password: 'StrongPassword123',
        confirmPassword: 'StrongPassword123',
      });

    expect(duplicateRes.status).toBe(409);
    expect(duplicateRes.body.error.code).toBe('EMAIL_ALREADY_REGISTERED');
  });

  it('rejects missing/forged CSRF tokens and cross-site Origins on state-changing routes', async () => {
    const { app } = createAuthTestApp();
    const csrf = await fetchCsrf(app);

    const noCsrfRes = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: 'a@example.com', password: 'Password123' });
    expect(noCsrfRes.status).toBe(403);
    expect(noCsrfRes.body.error.code).toBe('CSRF_TOKEN_INVALID');

    const badOriginRes = await request(app)
      .post('/api/v1/auth/login')
      .set('Origin', 'https://evil.example.net')
      .set('Cookie', csrf.cookieHeader)
      .set('X-CSRF-Token', csrf.token)
      .send({ email: 'a@example.com', password: 'Password123' });
    expect(badOriginRes.status).toBe(403);
    expect(['CORS_ORIGIN_DENIED', 'CSRF_ORIGIN_DENIED']).toContain(badOriginRes.body.error.code);

    const mismatchTokenRes = await request(app)
      .post('/api/v1/auth/login')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', csrf.cookieHeader)
      .set('X-CSRF-Token', 'forged.token')
      .send({ email: 'a@example.com', password: 'Password123' });
    expect(mismatchTokenRes.status).toBe(403);
    expect(mismatchTokenRes.body.error.code).toBe('CSRF_TOKEN_INVALID');
  });

  it('validates login credentials safely, supports sliding session renewal, suspension, and logout revocation', async () => {
    const { app, repo } = createAuthTestApp();
    const agent = request.agent(app);

    const csrfRes = await agent.get('/api/v1/auth/csrf');
    const csrfToken = csrfRes.body.data.csrfToken as string;

    const regRes = await agent
      .post('/api/v1/auth/register')
      .set('Origin', 'http://localhost:5173')
      .set('X-CSRF-Token', csrfToken)
      .send({
        fullName: 'Nusrat Jahan',
        email: 'nusrat@example.com',
        password: 'Password123',
        confirmPassword: 'Password123',
      });
    expect(regRes.status).toBe(201);
    const userId = regRes.body.data.user.id as string;

    // Logout revokes active session
    const logoutRes = await agent
      .post('/api/v1/auth/logout')
      .set('Origin', 'http://localhost:5173')
      .set('X-CSRF-Token', csrfToken);
    expect(logoutRes.status).toBe(200);
    expect(logoutRes.body.data.revoked).toBe(true);

    const meAfterLogout = await agent.get('/api/v1/auth/me');
    expect(meAfterLogout.status).toBe(200);
    expect(meAfterLogout.body.data.authenticated).toBe(false);
    expect(meAfterLogout.body.data.user).toBeNull();

    // Wrong password & unknown email return identical 401 INVALID_CREDENTIALS
    const badPassRes = await agent
      .post('/api/v1/auth/login')
      .set('Origin', 'http://localhost:5173')
      .set('X-CSRF-Token', csrfToken)
      .send({ email: 'nusrat@example.com', password: 'WrongPassword123' });
    expect(badPassRes.status).toBe(401);
    expect(badPassRes.body.error.code).toBe('INVALID_CREDENTIALS');

    const unknownEmailRes = await agent
      .post('/api/v1/auth/login')
      .set('Origin', 'http://localhost:5173')
      .set('X-CSRF-Token', csrfToken)
      .send({ email: 'nobody@example.com', password: 'WrongPassword123' });
    expect(unknownEmailRes.status).toBe(401);
    expect(unknownEmailRes.body.error.code).toBe('INVALID_CREDENTIALS');

    // Valid login issues fresh session
    const loginRes = await agent
      .post('/api/v1/auth/login')
      .set('Origin', 'http://localhost:5173')
      .set('X-CSRF-Token', csrfToken)
      .send({ email: 'nusrat@example.com', password: 'Password123', rememberMe: true });
    expect(loginRes.status).toBe(200);
    const sessionId = loginRes.body.data.session.id as string;
    const originalExpiryMs = Date.parse(loginRes.body.data.session.expiresAt as string);

    // Move remaining lifetime below 50% threshold to verify sliding renewal
    repo.expireSessionShortly(sessionId, 10 * 60 * 60 * 1000);
    const renewedMe = await agent.get('/api/v1/auth/me');
    expect(renewedMe.status).toBe(200);
    expect(renewedMe.body.data.authenticated).toBe(true);
    const renewedExpiryMs = Date.parse(renewedMe.body.data.session.expiresAt as string);
    expect(renewedExpiryMs).toBeGreaterThan(originalExpiryMs - 60_000);

    // Suspended accounts lose active session & cannot log back in
    repo.setUserStatus(userId, 'suspended');
    const suspendedMe = await agent.get('/api/v1/auth/me');
    expect(suspendedMe.body.data.authenticated).toBe(false);

    const suspendedLogin = await agent
      .post('/api/v1/auth/login')
      .set('Origin', 'http://localhost:5173')
      .set('X-CSRF-Token', csrfToken)
      .send({ email: 'nusrat@example.com', password: 'Password123' });
    expect(suspendedLogin.status).toBe(403);
    expect(suspendedLogin.body.error.code).toBe('ACCOUNT_SUSPENDED');
  });

  it('enforces RBAC roles, permissions, and resource ownership boundaries across customer, creator, admin, and super_admin', async () => {
    const { app, repo } = createAuthTestApp();

    const createActorAgent = async (
      email: string,
      roles?: ('customer' | 'creator' | 'admin' | 'super_admin')[]
    ) => {
      const agent = request.agent(app);
      const csrfRes = await agent.get('/api/v1/auth/csrf');
      const csrfToken = csrfRes.body.data.csrfToken as string;
      const regRes = await agent
        .post('/api/v1/auth/register')
        .set('Origin', 'http://localhost:5173')
        .set('X-CSRF-Token', csrfToken)
        .send({
          fullName: email.split('@')[0],
          email,
          password: 'Password123',
          confirmPassword: 'Password123',
        });
      const userId = regRes.body.data.user.id as string;
      if (roles) {
        const stored = await repo.findUserByPublicId(userId);
        await repo.replaceUserRoles(stored!.id, roles, stored!.id);
      }
      return { agent, csrfToken, userId };
    };

    // Anonymous access blocked
    const anonUsersRes = await request(app).get('/api/v1/users/me');
    expect(anonUsersRes.status).toBe(401);
    const anonAdminRes = await request(app).get('/api/v1/admin/overview');
    expect(anonAdminRes.status).toBe(401);

    const customer = await createActorAgent('customer@example.com');
    const creator = await createActorAgent('creator@example.com', ['customer', 'creator']);
    const admin = await createActorAgent('admin@example.com', ['admin']);
    const superAdmin = await createActorAgent('owner@example.com', ['super_admin']);

    // Ownership checks
    const ownProfileRes = await customer.agent.get(`/api/v1/users/${customer.userId}`);
    expect(ownProfileRes.status).toBe(200);

    const otherProfileForbidden = await customer.agent.get(`/api/v1/users/${creator.userId}`);
    expect(otherProfileForbidden.status).toBe(403);

    const adminReadsOtherProfile = await admin.agent.get(`/api/v1/users/${customer.userId}`);
    expect(adminReadsOtherProfile.status).toBe(200);

    // Profile update mutation requires CSRF and updates persisted data
    const patchProfile = await customer.agent
      .patch('/api/v1/users/me')
      .set('Origin', 'http://localhost:5173')
      .set('X-CSRF-Token', customer.csrfToken)
      .send({ fullName: 'Updated Customer Name', preferredLocale: 'bn' });
    expect(patchProfile.status).toBe(200);
    expect(patchProfile.body.data.user.fullName).toBe('Updated Customer Name');
    expect(patchProfile.body.data.user.preferredLocale).toBe('bn');

    // Creator workspace boundaries
    expect((await customer.agent.get('/api/v1/creator/workspace')).status).toBe(403);
    expect((await creator.agent.get('/api/v1/creator/workspace')).status).toBe(200);
    expect((await admin.agent.get('/api/v1/creator/workspace')).status).toBe(200);

    // Admin overview boundaries
    expect((await creator.agent.get('/api/v1/admin/overview')).status).toBe(403);
    const adminOverview = await admin.agent.get('/api/v1/admin/overview');
    expect(adminOverview.status).toBe(200);
    expect(adminOverview.body.data.userCountSampled).toBe(4);

    // Super admin exclusive role elevation
    const adminElevateForbidden = await admin.agent
      .patch(`/api/v1/admin/users/${customer.userId}/roles`)
      .set('Origin', 'http://localhost:5173')
      .set('X-CSRF-Token', admin.csrfToken)
      .send({ roles: ['customer', 'creator'] });
    expect(adminElevateForbidden.status).toBe(403);

    const superAdminElevates = await superAdmin.agent
      .patch(`/api/v1/admin/users/${customer.userId}/roles`)
      .set('Origin', 'http://localhost:5173')
      .set('X-CSRF-Token', superAdmin.csrfToken)
      .send({ roles: ['customer', 'creator'] });
    expect(superAdminElevates.status).toBe(200);
    expect(superAdminElevates.body.data.user.roles).toEqual(['creator', 'customer']);
    expect((await customer.agent.get('/api/v1/creator/workspace')).status).toBe(200);
  });

  it('enforces auth rate limiting cleanly with 429 TOO_MANY_REQUESTS', async () => {
    const { app } = createAuthTestApp({
      strictWindowMs: 60_000,
      strictMax: 2,
      generalWindowMs: 60_000,
      generalMax: 50,
    });
    const csrf = await fetchCsrf(app);

    for (let attempt = 0; attempt < 2; attempt++) {
      const res = await request(app)
        .post('/api/v1/auth/login')
        .set('Origin', 'http://localhost:5173')
        .set('Cookie', csrf.cookieHeader)
        .set('X-CSRF-Token', csrf.token)
        .send({ email: 'ratelimit@example.com', password: 'Password123' });
      expect(res.status).toBe(401);
    }

    const blockedRes = await request(app)
      .post('/api/v1/auth/login')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', csrf.cookieHeader)
      .set('X-CSRF-Token', csrf.token)
      .send({ email: 'ratelimit@example.com', password: 'Password123' });

    expect(blockedRes.status).toBe(429);
    expect(blockedRes.body.success).toBe(false);
    expect(blockedRes.body.error.code).toBe('TOO_MANY_REQUESTS');
  });
});
