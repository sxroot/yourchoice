import { resolvePermissionsForRoles } from '@your-choice/database';
import type { AuthUserDTO, PermissionCode, UserRole, UserStatus } from '@your-choice/shared-types';
import type { UpdateProfileInput } from '@your-choice/validation';
import {
  type CreateSessionParams,
  type CreateUserParams,
  type IdentityRepository,
  type SessionWithUserRecord,
  type StoredSessionRecord,
  type StoredUserRecord,
  toAuthUserDto,
} from '../../src/modules/auth/identity.repository.js';
import { ApiError } from '../../src/utils/api-error.js';

export class InMemoryIdentityRepository implements IdentityRepository {
  private nextUserId = 1;
  private nextSessionId = 1;
  private usersById = new Map<number, StoredUserRecord>();
  private sessionsById = new Map<number, StoredSessionRecord>();

  private cloneUser(user: StoredUserRecord): StoredUserRecord {
    return {
      ...user,
      roles: [...user.roles],
      permissions: [...user.permissions],
    };
  }

  private cloneSession(session: StoredSessionRecord): StoredSessionRecord {
    return { ...session };
  }

  async findUserByEmail(email: string): Promise<StoredUserRecord | null> {
    const normalized = email.toLowerCase();
    for (const user of this.usersById.values()) {
      if (user.email === normalized && user.deletedAt === null) {
        return this.cloneUser(user);
      }
    }
    return null;
  }

  async findUserByPublicId(publicId: string): Promise<StoredUserRecord | null> {
    for (const user of this.usersById.values()) {
      if (user.publicId === publicId && user.deletedAt === null) {
        return this.cloneUser(user);
      }
    }
    return null;
  }

  async createUser(params: CreateUserParams): Promise<StoredUserRecord> {
    const existing = await this.findUserByEmail(params.email);
    if (existing) {
      throw ApiError.conflict(
        'EMAIL_ALREADY_REGISTERED',
        'An account with this email address already exists'
      );
    }

    const now = new Date();
    const initialRole = params.initialRoleCode ?? 'customer';
    const permissions = resolvePermissionsForRoles([initialRole]) as PermissionCode[];

    const record: StoredUserRecord = {
      id: this.nextUserId++,
      publicId: params.publicId,
      email: params.email.toLowerCase(),
      passwordHash: params.passwordHash,
      fullName: params.fullName,
      phone: params.phone,
      preferredLocale: params.preferredLocale,
      status: 'active',
      emailVerifiedAt: null,
      lastLoginAt: null,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
      roles: [initialRole],
      permissions,
    };

    this.usersById.set(record.id, record);
    return this.cloneUser(record);
  }

  async createSession(params: CreateSessionParams): Promise<StoredSessionRecord> {
    const now = new Date();
    const record: StoredSessionRecord = {
      id: this.nextSessionId++,
      publicId: params.publicId,
      userId: params.userId,
      tokenHash: params.tokenHash,
      ipAddress: params.ipAddress,
      userAgent: params.userAgent,
      expiresAt: params.expiresAt,
      lastSeenAt: now,
      revokedAt: null,
      createdAt: now,
    };
    this.sessionsById.set(record.id, record);
    return this.cloneSession(record);
  }

  async findActiveSessionByTokenHash(
    tokenHash: string,
    now: Date
  ): Promise<SessionWithUserRecord | null> {
    for (const session of this.sessionsById.values()) {
      if (
        session.tokenHash === tokenHash &&
        session.revokedAt === null &&
        session.expiresAt.getTime() > now.getTime()
      ) {
        const user = this.usersById.get(session.userId);
        if (!user || user.deletedAt !== null) {
          return null;
        }
        return {
          session: this.cloneSession(session),
          user: this.cloneUser(user),
        };
      }
    }
    return null;
  }

  async touchSession(
    sessionId: number,
    updates: { lastSeenAt: Date; expiresAt?: Date }
  ): Promise<void> {
    const session = this.sessionsById.get(sessionId);
    if (!session) {
      return;
    }
    session.lastSeenAt = updates.lastSeenAt;
    if (updates.expiresAt) {
      session.expiresAt = updates.expiresAt;
    }
  }

  async revokeSessionById(sessionId: number, revokedAt: Date): Promise<void> {
    const session = this.sessionsById.get(sessionId);
    if (session && session.revokedAt === null) {
      session.revokedAt = revokedAt;
    }
  }

  async revokeAllUserSessions(userId: number, revokedAt: Date): Promise<void> {
    for (const session of this.sessionsById.values()) {
      if (session.userId === userId && session.revokedAt === null) {
        session.revokedAt = revokedAt;
      }
    }
  }

  async updateLastLoginAt(userId: number, timestamp: Date): Promise<void> {
    const user = this.usersById.get(userId);
    if (user) {
      user.lastLoginAt = timestamp;
      user.updatedAt = timestamp;
    }
  }

  async updateUserProfile(userId: number, patch: UpdateProfileInput): Promise<StoredUserRecord> {
    const user = this.usersById.get(userId);
    if (!user) {
      throw ApiError.notFound('User account not found');
    }
    if (patch.fullName !== undefined) {
      user.fullName = patch.fullName;
    }
    if (patch.phone !== undefined) {
      user.phone = patch.phone;
    }
    if (patch.preferredLocale !== undefined) {
      user.preferredLocale = patch.preferredLocale;
    }
    user.updatedAt = new Date();
    return this.cloneUser(user);
  }

  async replaceUserRoles(
    userId: number,
    roles: UserRole[],
    _assignedByUserId: number
  ): Promise<StoredUserRecord> {
    const user = this.usersById.get(userId);
    if (!user) {
      throw ApiError.notFound('User account not found');
    }
    user.roles = [...roles].sort();
    user.permissions = resolvePermissionsForRoles(user.roles) as PermissionCode[];
    user.updatedAt = new Date();
    return this.cloneUser(user);
  }

  async listUsersSummary(limit = 25): Promise<AuthUserDTO[]> {
    return Array.from(this.usersById.values())
      .filter((u) => u.deletedAt === null)
      .slice(0, limit)
      .map(toAuthUserDto);
  }

  // Test helper methods
  setUserStatus(publicId: string, status: UserStatus): void {
    for (const user of this.usersById.values()) {
      if (user.publicId === publicId) {
        user.status = status;
      }
    }
  }

  getRawSessionByPublicId(sessionPublicId: string): StoredSessionRecord | undefined {
    for (const session of this.sessionsById.values()) {
      if (session.publicId === sessionPublicId) {
        return this.cloneSession(session);
      }
    }
    return undefined;
  }

  expireSessionShortly(sessionPublicId: string, remainingMs: number): void {
    for (const session of this.sessionsById.values()) {
      if (session.publicId === sessionPublicId) {
        session.expiresAt = new Date(Date.now() + remainingMs);
      }
    }
  }
}
