import { randomUUID } from 'node:crypto';
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS } from '@your-choice/database';
import { decimalToMinorUnits } from '@your-choice/shared-utils';
import type {
  AdminCatalogQueryInput,
  CreateCategoryInput,
  CreateProductImageInput,
  CreateVariantInput,
  UpdateAddressInput,
  UpdateCategoryInput,
  UpdatePrintAreaInput,
  UpdateProductInput,
  UpdateVariantInput,
  UpsertPrintAreaInput,
} from '@your-choice/validation';
import type {
  AddressRepository,
  CreateAddressRecordParams,
  StoredAddressRecord,
} from '../../src/modules/addresses/address.repository.js';
import type { AuditEventInput, AuditRepository } from '../../src/modules/audit/audit.service.js';
import type {
  CatalogRepository,
  CreateCategoryParams,
  CreateProductParams,
  StoredCategoryRecord,
  StoredPrintAreaRecord,
  StoredProductAggregate,
  StoredProductImageRecord,
  StoredProductVariantRecord,
} from '../../src/modules/catalog/catalog.repository.js';
import { ApiError } from '../../src/utils/api-error.js';

export class InMemoryAddressRepository implements AddressRepository {
  private nextId = 1;
  private addresses: StoredAddressRecord[] = [];

  async listByUserId(userId: number): Promise<StoredAddressRecord[]> {
    return this.addresses
      .filter((a) => a.userId === userId && a.deletedAt === null)
      .sort((a, b) => Number(b.isDefault) - Number(a.isDefault) || b.id - a.id)
      .map((a) => ({ ...a }));
  }

  async findByPublicIdAndUserId(
    publicId: string,
    userId: number
  ): Promise<StoredAddressRecord | null> {
    const found = this.addresses.find(
      (a) => a.publicId === publicId && a.userId === userId && a.deletedAt === null
    );
    return found ? { ...found } : null;
  }

  async create(params: CreateAddressRecordParams): Promise<StoredAddressRecord> {
    const activeForUser = this.addresses.filter(
      (a) => a.userId === params.userId && a.deletedAt === null
    );
    const shouldBeDefault = params.isDefault || activeForUser.length === 0;
    if (shouldBeDefault) {
      for (const item of activeForUser) {
        item.isDefault = false;
      }
    }

    const now = new Date();
    const record: StoredAddressRecord = {
      id: this.nextId++,
      publicId: params.publicId,
      userId: params.userId,
      label: params.label,
      recipientName: params.recipientName,
      phone: params.phone,
      division: params.division,
      district: params.district,
      area: params.area,
      addressLine: params.addressLine,
      postalCode: params.postalCode ?? null,
      isDefault: shouldBeDefault,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
    };
    this.addresses.push(record);
    return { ...record };
  }

  async update(
    publicId: string,
    userId: number,
    input: UpdateAddressInput
  ): Promise<StoredAddressRecord | null> {
    const target = this.addresses.find(
      (a) => a.publicId === publicId && a.userId === userId && a.deletedAt === null
    );
    if (!target) {
      return null;
    }

    if (input.isDefault === true) {
      for (const item of this.addresses) {
        if (item.userId === userId && item.deletedAt === null && item.id !== target.id) {
          item.isDefault = false;
        }
      }
    }

    if (input.label !== undefined) target.label = input.label;
    if (input.recipientName !== undefined) target.recipientName = input.recipientName;
    if (input.phone !== undefined) target.phone = input.phone;
    if (input.division !== undefined) target.division = input.division;
    if (input.district !== undefined) target.district = input.district;
    if (input.area !== undefined) target.area = input.area;
    if (input.addressLine !== undefined) target.addressLine = input.addressLine;
    if (input.postalCode !== undefined) target.postalCode = input.postalCode ?? null;
    if (input.isDefault !== undefined) target.isDefault = input.isDefault;
    target.updatedAt = new Date();

    return { ...target };
  }

  async softDelete(publicId: string, userId: number): Promise<boolean> {
    const target = this.addresses.find(
      (a) => a.publicId === publicId && a.userId === userId && a.deletedAt === null
    );
    if (!target) {
      return false;
    }

    const wasDefault = target.isDefault;
    target.deletedAt = new Date();
    target.isDefault = false;

    if (wasDefault) {
      const replacement = this.addresses
        .filter((a) => a.userId === userId && a.deletedAt === null)
        .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())[0];
      if (replacement) {
        replacement.isDefault = true;
      }
    }

    return true;
  }
}

export class InMemoryAuditRepository implements AuditRepository {
  public readonly entries: AuditEventInput[] = [];

  async insert(entry: AuditEventInput): Promise<void> {
    this.entries.push({ ...entry });
  }
}

export class InMemoryCatalogRepository implements CatalogRepository {
  private nextCategoryId = 1;
  private nextProductId = 1;
  private nextImageId = 1;
  private nextVariantId = 1;
  private nextPrintAreaId = 1;

  private categories: StoredCategoryRecord[] = [];
  private products: StoredProductAggregate[] = [];

  constructor(seedDefaults = true) {
    if (seedDefaults) {
      this.seedFromCanonical();
    }
  }

  private seedFromCanonical(): void {
    const now = new Date();
    const catBySlug = new Map<string, StoredCategoryRecord>();

    for (const cat of INITIAL_CATEGORIES) {
      const stored: StoredCategoryRecord = {
        id: this.nextCategoryId++,
        publicId: cat.publicId,
        parentId: null,
        slug: cat.slug,
        nameEn: cat.nameEn,
        nameBn: cat.nameBn,
        descriptionEn: cat.descriptionEn,
        descriptionBn: cat.descriptionBn,
        sortOrder: cat.sortOrder,
        isActive: true,
        createdAt: now,
        updatedAt: now,
        deletedAt: null,
      };
      this.categories.push(stored);
      catBySlug.set(stored.slug, stored);
    }

    for (const prd of INITIAL_PRODUCTS) {
      const category = catBySlug.get(prd.categorySlug);
      if (!category) continue;

      const productId = this.nextProductId++;
      const aggregate: StoredProductAggregate = {
        id: productId,
        publicId: prd.publicId,
        categoryId: category.id,
        category,
        slug: prd.slug,
        skuPrefix: prd.skuPrefix,
        nameEn: prd.nameEn,
        nameBn: prd.nameBn,
        subtitleEn: prd.subtitleEn,
        subtitleBn: prd.subtitleBn,
        descriptionEn: prd.descriptionEn,
        descriptionBn: prd.descriptionBn,
        fabricSpecEn: prd.fabricSpecEn,
        fabricSpecBn: prd.fabricSpecBn,
        gsm: prd.gsm,
        fitType: prd.fitType,
        basePrice: prd.basePrice,
        currencyCode: 'BDT',
        isCustomizable: prd.isCustomizable,
        status: prd.status,
        featuredOrder: prd.featuredOrder,
        createdAt: now,
        updatedAt: now,
        deletedAt: null,
        images: prd.images.map((img) => ({
          id: this.nextImageId++,
          publicId: img.publicId,
          productId,
          variantId: null,
          variantPublicId: null,
          viewType: img.viewType,
          url: img.url,
          altTextEn: img.altTextEn,
          altTextBn: img.altTextBn,
          sortOrder: img.sortOrder,
          isPrimary: img.isPrimary,
        })),
        variants: prd.variants.map((variant) => ({
          id: this.nextVariantId++,
          publicId: variant.publicId,
          productId,
          sku: variant.sku,
          colorNameEn: variant.colorNameEn,
          colorNameBn: variant.colorNameBn,
          colorHex: variant.colorHex,
          sizeCode: variant.sizeCode,
          priceOverride: variant.priceOverride,
          currencyCode: 'BDT',
          stockQuantity: variant.stockQuantity,
          isActive: true,
          deletedAt: null,
        })),
        printAreas: prd.printAreas.map((area) => ({
          id: this.nextPrintAreaId++,
          publicId: area.publicId,
          productId,
          surfaceKey: area.surfaceKey,
          labelEn: area.labelEn,
          labelBn: area.labelBn,
          physicalWidthMm: area.physicalWidthMm,
          physicalHeightMm: area.physicalHeightMm,
          targetDpi: area.targetDpi,
          safeInsetMm: area.safeInsetMm,
          coordinateSpace: 'normalized_0_1',
          mockupBounds: { ...area.mockupBounds },
          uvRegion: { ...area.uvRegion },
          printMethods: [...area.printMethods],
          surchargeAmount: area.surchargeAmount,
          currencyCode: 'BDT',
          isDefault: area.isDefault,
          isActive: true,
          sortOrder: area.sortOrder,
        })),
      };
      this.products.push(aggregate);
    }
  }

  private cloneProduct(product: StoredProductAggregate): StoredProductAggregate {
    return {
      ...product,
      category: { ...product.category },
      images: product.images.map((i) => ({ ...i })),
      variants: product.variants.map((v) => ({ ...v })),
      printAreas: product.printAreas.map((p) => ({
        ...p,
        mockupBounds: { ...p.mockupBounds },
        uvRegion: p.uvRegion ? { ...p.uvRegion } : null,
        printMethods: [...p.printMethods],
      })),
    };
  }

  async listCategories(includeInactive: boolean): Promise<StoredCategoryRecord[]> {
    return this.categories
      .filter((c) => c.deletedAt === null && (includeInactive || c.isActive))
      .sort((a, b) => a.sortOrder - b.sortOrder || a.id - b.id)
      .map((cat) => {
        const count = this.products.filter(
          (p) =>
            p.categoryId === cat.id &&
            p.deletedAt === null &&
            (includeInactive || p.status === 'active')
        ).length;
        return { ...cat, productCount: count };
      });
  }

  async findCategoryByPublicId(publicId: string): Promise<StoredCategoryRecord | null> {
    const found = this.categories.find((c) => c.publicId === publicId && c.deletedAt === null);
    return found ? { ...found } : null;
  }

  async createCategory(params: CreateCategoryParams): Promise<StoredCategoryRecord> {
    if (this.categories.some((c) => c.slug === params.slug)) {
      throw ApiError.conflict(
        'CATEGORY_SLUG_EXISTS',
        'An apparel category with this slug already exists'
      );
    }
    const now = new Date();
    const record: StoredCategoryRecord = {
      id: this.nextCategoryId++,
      publicId: params.publicId,
      parentId: null,
      slug: params.slug,
      nameEn: params.nameEn,
      nameBn: params.nameBn,
      descriptionEn: params.descriptionEn ?? null,
      descriptionBn: params.descriptionBn ?? null,
      sortOrder: params.sortOrder,
      isActive: params.isActive,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
      productCount: 0,
    };
    this.categories.push(record);
    return { ...record };
  }

  async updateCategory(
    publicId: string,
    input: UpdateCategoryInput
  ): Promise<StoredCategoryRecord | null> {
    const cat = this.categories.find((c) => c.publicId === publicId && c.deletedAt === null);
    if (!cat) return null;

    if (
      input.slug !== undefined &&
      this.categories.some((c) => c.slug === input.slug && c.id !== cat.id)
    ) {
      throw ApiError.conflict(
        'CATEGORY_SLUG_EXISTS',
        'An apparel category with this slug already exists'
      );
    }

    const patch: Partial<CreateCategoryInput> = input;
    if (patch.slug !== undefined) cat.slug = patch.slug;
    if (patch.nameEn !== undefined) cat.nameEn = patch.nameEn;
    if (patch.nameBn !== undefined) cat.nameBn = patch.nameBn;
    if (patch.descriptionEn !== undefined) cat.descriptionEn = patch.descriptionEn ?? null;
    if (patch.descriptionBn !== undefined) cat.descriptionBn = patch.descriptionBn ?? null;
    if (patch.sortOrder !== undefined) cat.sortOrder = patch.sortOrder;
    if (patch.isActive !== undefined) cat.isActive = patch.isActive;
    cat.updatedAt = new Date();

    return { ...cat };
  }

  async listProducts(
    query: AdminCatalogQueryInput & { includeNonActive: boolean }
  ): Promise<{ items: StoredProductAggregate[]; totalItems: number }> {
    let filtered = this.products.filter((p) => p.deletedAt === null);

    if (!query.includeNonActive) {
      filtered = filtered.filter((p) => p.status === 'active' && p.category.isActive);
    } else if (query.status) {
      filtered = filtered.filter((p) => p.status === query.status);
    }

    if (query.category) {
      filtered = filtered.filter((p) => p.category.slug === query.category);
    }

    if (query.search && query.search.trim().length > 0) {
      const needle = query.search.trim().toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.nameEn.toLowerCase().includes(needle) ||
          p.nameBn.toLowerCase().includes(needle) ||
          p.skuPrefix.toLowerCase().includes(needle) ||
          p.slug.toLowerCase().includes(needle)
      );
    }

    if (query.customizable !== undefined) {
      filtered = filtered.filter((p) => p.isCustomizable === query.customizable);
    }

    if (query.size || query.color) {
      filtered = filtered.filter((p) =>
        p.variants.some((v) => {
          if (v.deletedAt !== null) return false;
          if (!query.includeNonActive && !v.isActive) return false;
          if (query.size && v.sizeCode !== query.size) return false;
          if (query.color && v.colorHex !== query.color) return false;
          return true;
        })
      );
    }

    filtered.sort((a, b) => {
      switch (query.sort) {
        case 'price_asc':
          return Number(decimalToMinorUnits(a.basePrice) - decimalToMinorUnits(b.basePrice));
        case 'price_desc':
          return Number(decimalToMinorUnits(b.basePrice) - decimalToMinorUnits(a.basePrice));
        case 'newest':
          return b.id - a.id;
        case 'featured':
        default: {
          const orderA = a.featuredOrder ?? Number.MAX_SAFE_INTEGER;
          const orderB = b.featuredOrder ?? Number.MAX_SAFE_INTEGER;
          return orderA - orderB || b.id - a.id;
        }
      }
    });

    const totalItems = filtered.length;
    const offset = (query.page - 1) * query.pageSize;
    const pageItems = filtered
      .slice(offset, offset + query.pageSize)
      .map((p) => this.cloneProduct(p));

    return { items: pageItems, totalItems };
  }

  async findProductBySlug(
    slug: string,
    includeNonActive: boolean
  ): Promise<StoredProductAggregate | null> {
    const found = this.products.find(
      (p) =>
        p.slug === slug &&
        p.deletedAt === null &&
        (includeNonActive || (p.status === 'active' && p.category.isActive))
    );
    return found ? this.cloneProduct(found) : null;
  }

  async findProductByPublicId(
    publicId: string,
    includeNonActive: boolean
  ): Promise<StoredProductAggregate | null> {
    const found = this.products.find(
      (p) =>
        p.publicId === publicId &&
        p.deletedAt === null &&
        (includeNonActive || (p.status === 'active' && p.category.isActive))
    );
    return found ? this.cloneProduct(found) : null;
  }

  async createProduct(params: CreateProductParams): Promise<StoredProductAggregate> {
    if (this.products.some((p) => p.slug === params.slug)) {
      throw ApiError.conflict(
        'CATALOG_DUPLICATE_IDENTIFIER',
        'A product with this slug already exists'
      );
    }
    const existingSkus = new Set(
      this.products.flatMap((p) => p.variants.map((v) => v.sku.toUpperCase()))
    );
    for (const v of params.variants) {
      if (existingSkus.has(v.sku.toUpperCase())) {
        throw ApiError.conflict('CATALOG_DUPLICATE_IDENTIFIER', `SKU "${v.sku}" already exists`);
      }
    }

    const category = this.categories.find((c) => c.id === params.categoryInternalId);
    if (!category) {
      throw new ApiError(400, 'CATEGORY_NOT_FOUND', 'Category not found');
    }

    const now = new Date();
    const productId = this.nextProductId++;
    const aggregate: StoredProductAggregate = {
      id: productId,
      publicId: params.publicId,
      categoryId: category.id,
      category: { ...category },
      slug: params.slug,
      skuPrefix: params.skuPrefix,
      nameEn: params.nameEn,
      nameBn: params.nameBn,
      subtitleEn: params.subtitleEn ?? null,
      subtitleBn: params.subtitleBn ?? null,
      descriptionEn: params.descriptionEn,
      descriptionBn: params.descriptionBn,
      fabricSpecEn: params.fabricSpecEn ?? null,
      fabricSpecBn: params.fabricSpecBn ?? null,
      gsm: params.gsm ?? null,
      fitType: params.fitType ?? null,
      basePrice: params.basePrice,
      currencyCode: 'BDT',
      isCustomizable: params.isCustomizable,
      status: params.status,
      featuredOrder: params.featuredOrder ?? null,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
      images: params.images.map((img, i) => ({
        id: this.nextImageId++,
        publicId: img.publicId,
        productId,
        variantId: null,
        variantPublicId: null,
        viewType: img.viewType,
        url: img.url,
        altTextEn: img.altTextEn,
        altTextBn: img.altTextBn,
        sortOrder: img.sortOrder ?? i,
        isPrimary: img.isPrimary ?? i === 0,
      })),
      variants: params.variants.map((v) => ({
        id: this.nextVariantId++,
        publicId: v.publicId,
        productId,
        sku: v.sku,
        colorNameEn: v.colorNameEn,
        colorNameBn: v.colorNameBn,
        colorHex: v.colorHex,
        sizeCode: v.sizeCode,
        priceOverride: v.priceOverride ?? null,
        currencyCode: 'BDT',
        stockQuantity: v.stockQuantity,
        isActive: v.isActive,
        deletedAt: null,
      })),
      printAreas: params.printAreas.map((a, i) => ({
        id: this.nextPrintAreaId++,
        publicId: a.publicId,
        productId,
        surfaceKey: a.surfaceKey,
        labelEn: a.labelEn,
        labelBn: a.labelBn,
        physicalWidthMm: a.physicalWidthMm,
        physicalHeightMm: a.physicalHeightMm,
        targetDpi: a.targetDpi,
        safeInsetMm: a.safeInsetMm,
        coordinateSpace: 'normalized_0_1',
        mockupBounds: { ...a.mockupBounds },
        uvRegion: a.uvRegion ? { ...a.uvRegion } : null,
        printMethods: [...a.printMethods],
        surchargeAmount: a.surchargeAmount,
        currencyCode: 'BDT',
        isDefault: a.isDefault ?? i === 0,
        isActive: a.isActive,
        sortOrder: a.sortOrder ?? i,
      })),
    };

    this.products.push(aggregate);
    return this.cloneProduct(aggregate);
  }

  async updateProduct(
    productId: number,
    input: Omit<UpdateProductInput, 'categoryId'> & { categoryInternalId?: number }
  ): Promise<StoredProductAggregate | null> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) return null;

    if (
      input.slug !== undefined &&
      this.products.some((p) => p.slug === input.slug && p.id !== productId)
    ) {
      throw ApiError.conflict(
        'PRODUCT_SLUG_EXISTS',
        'Another product already uses this slug identifier'
      );
    }

    if (input.categoryInternalId !== undefined) {
      const cat = this.categories.find((c) => c.id === input.categoryInternalId);
      if (cat) {
        product.categoryId = cat.id;
        product.category = { ...cat };
      }
    }

    if (input.slug !== undefined) product.slug = input.slug;
    if (input.skuPrefix !== undefined) product.skuPrefix = input.skuPrefix;
    if (input.nameEn !== undefined) product.nameEn = input.nameEn;
    if (input.nameBn !== undefined) product.nameBn = input.nameBn;
    if (input.subtitleEn !== undefined) product.subtitleEn = input.subtitleEn ?? null;
    if (input.subtitleBn !== undefined) product.subtitleBn = input.subtitleBn ?? null;
    if (input.descriptionEn !== undefined) product.descriptionEn = input.descriptionEn;
    if (input.descriptionBn !== undefined) product.descriptionBn = input.descriptionBn;
    if (input.fabricSpecEn !== undefined) product.fabricSpecEn = input.fabricSpecEn ?? null;
    if (input.fabricSpecBn !== undefined) product.fabricSpecBn = input.fabricSpecBn ?? null;
    if (input.gsm !== undefined) product.gsm = input.gsm ?? null;
    if (input.fitType !== undefined) product.fitType = input.fitType ?? null;
    if (input.basePrice !== undefined) product.basePrice = input.basePrice;
    if (input.isCustomizable !== undefined) product.isCustomizable = input.isCustomizable;
    if (input.status !== undefined) product.status = input.status;
    if (input.featuredOrder !== undefined) product.featuredOrder = input.featuredOrder ?? null;
    product.updatedAt = new Date();

    return this.cloneProduct(product);
  }

  async softDeleteProduct(productId: number): Promise<boolean> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) return false;
    product.status = 'archived';
    product.deletedAt = new Date();
    return true;
  }

  async addImage(
    productId: number,
    input: CreateProductImageInput & { publicId: string }
  ): Promise<StoredProductImageRecord> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) {
      throw ApiError.notFound('Product not found');
    }

    if (input.isPrimary) {
      for (const img of product.images) {
        img.isPrimary = false;
      }
    }

    const record: StoredProductImageRecord = {
      id: this.nextImageId++,
      publicId: input.publicId,
      productId,
      variantId: null,
      variantPublicId: input.variantId ?? null,
      viewType: input.viewType,
      url: input.url,
      altTextEn: input.altTextEn,
      altTextBn: input.altTextBn,
      sortOrder: input.sortOrder,
      isPrimary: input.isPrimary,
    };
    product.images.push(record);
    return { ...record };
  }

  async deleteImage(productId: number, imagePublicId: string): Promise<boolean> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) return false;
    const idx = product.images.findIndex((i) => i.publicId === imagePublicId);
    if (idx < 0) return false;
    product.images.splice(idx, 1);
    return true;
  }

  async addVariant(
    productId: number,
    input: CreateVariantInput & { publicId: string }
  ): Promise<StoredProductVariantRecord> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) {
      throw ApiError.notFound('Product not found');
    }

    const skuExists = this.products.some((p) =>
      p.variants.some((v) => v.sku.toUpperCase() === input.sku.toUpperCase())
    );
    if (skuExists) {
      throw ApiError.conflict('VARIANT_SKU_EXISTS', `SKU "${input.sku}" already exists`);
    }

    const record: StoredProductVariantRecord = {
      id: this.nextVariantId++,
      publicId: input.publicId,
      productId,
      sku: input.sku,
      colorNameEn: input.colorNameEn,
      colorNameBn: input.colorNameBn,
      colorHex: input.colorHex,
      sizeCode: input.sizeCode,
      priceOverride: input.priceOverride ?? null,
      currencyCode: 'BDT',
      stockQuantity: input.stockQuantity,
      isActive: input.isActive,
      deletedAt: null,
    };
    product.variants.push(record);
    return { ...record };
  }

  async updateVariant(
    productId: number,
    variantPublicId: string,
    input: UpdateVariantInput
  ): Promise<StoredProductVariantRecord | null> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) return null;

    const variant = product.variants.find(
      (v) => v.publicId === variantPublicId && v.deletedAt === null
    );
    if (!variant) return null;

    if (
      input.sku !== undefined &&
      this.products.some((p) =>
        p.variants.some(
          (v) => v.sku.toUpperCase() === input.sku!.toUpperCase() && v.publicId !== variantPublicId
        )
      )
    ) {
      throw ApiError.conflict('VARIANT_SKU_EXISTS', 'Another variant already uses this SKU');
    }

    if (input.sku !== undefined) variant.sku = input.sku;
    if (input.colorNameEn !== undefined) variant.colorNameEn = input.colorNameEn;
    if (input.colorNameBn !== undefined) variant.colorNameBn = input.colorNameBn;
    if (input.colorHex !== undefined) variant.colorHex = input.colorHex;
    if (input.sizeCode !== undefined) variant.sizeCode = input.sizeCode;
    if (input.priceOverride !== undefined) variant.priceOverride = input.priceOverride ?? null;
    if (input.stockQuantity !== undefined) variant.stockQuantity = input.stockQuantity;
    if (input.isActive !== undefined) variant.isActive = input.isActive;

    return { ...variant };
  }

  async softDeleteVariant(productId: number, variantPublicId: string): Promise<boolean> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) return false;
    const variant = product.variants.find(
      (v) => v.publicId === variantPublicId && v.deletedAt === null
    );
    if (!variant) return false;
    variant.isActive = false;
    variant.deletedAt = new Date();
    return true;
  }

  async upsertPrintArea(
    productId: number,
    input: UpsertPrintAreaInput & { publicId: string }
  ): Promise<StoredPrintAreaRecord> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) {
      throw ApiError.notFound('Product not found');
    }

    if (input.isDefault) {
      for (const area of product.printAreas) {
        area.isDefault = false;
      }
    }

    const existing = product.printAreas.find((area) => area.surfaceKey === input.surfaceKey);
    if (existing) {
      existing.labelEn = input.labelEn;
      existing.labelBn = input.labelBn;
      existing.physicalWidthMm = input.physicalWidthMm;
      existing.physicalHeightMm = input.physicalHeightMm;
      existing.targetDpi = input.targetDpi;
      existing.safeInsetMm = input.safeInsetMm;
      existing.mockupBounds = { ...input.mockupBounds };
      existing.uvRegion = input.uvRegion ? { ...input.uvRegion } : null;
      existing.printMethods = [...input.printMethods];
      existing.surchargeAmount = input.surchargeAmount;
      existing.isDefault = input.isDefault;
      existing.isActive = input.isActive;
      existing.sortOrder = input.sortOrder;
      return { ...existing, mockupBounds: { ...existing.mockupBounds } };
    }

    const created: StoredPrintAreaRecord = {
      id: this.nextPrintAreaId++,
      publicId: input.publicId || randomUUID(),
      productId,
      surfaceKey: input.surfaceKey,
      labelEn: input.labelEn,
      labelBn: input.labelBn,
      physicalWidthMm: input.physicalWidthMm,
      physicalHeightMm: input.physicalHeightMm,
      targetDpi: input.targetDpi,
      safeInsetMm: input.safeInsetMm,
      coordinateSpace: 'normalized_0_1',
      mockupBounds: { ...input.mockupBounds },
      uvRegion: input.uvRegion ? { ...input.uvRegion } : null,
      printMethods: [...input.printMethods],
      surchargeAmount: input.surchargeAmount,
      currencyCode: 'BDT',
      isDefault: input.isDefault,
      isActive: input.isActive,
      sortOrder: input.sortOrder,
    };
    product.printAreas.push(created);
    return { ...created, mockupBounds: { ...created.mockupBounds } };
  }

  async updatePrintArea(
    productId: number,
    printAreaPublicId: string,
    input: UpdatePrintAreaInput
  ): Promise<StoredPrintAreaRecord | null> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) return null;

    const area = product.printAreas.find((p) => p.publicId === printAreaPublicId);
    if (!area) return null;

    if (input.isDefault === true) {
      for (const sibling of product.printAreas) {
        sibling.isDefault = false;
      }
    }

    if (input.surfaceKey !== undefined) area.surfaceKey = input.surfaceKey;
    if (input.labelEn !== undefined) area.labelEn = input.labelEn;
    if (input.labelBn !== undefined) area.labelBn = input.labelBn;
    if (input.physicalWidthMm !== undefined) area.physicalWidthMm = input.physicalWidthMm;
    if (input.physicalHeightMm !== undefined) area.physicalHeightMm = input.physicalHeightMm;
    if (input.targetDpi !== undefined) area.targetDpi = input.targetDpi;
    if (input.safeInsetMm !== undefined) area.safeInsetMm = input.safeInsetMm;
    if (input.mockupBounds !== undefined) area.mockupBounds = { ...input.mockupBounds };
    if (input.uvRegion !== undefined) area.uvRegion = input.uvRegion ? { ...input.uvRegion } : null;
    if (input.printMethods !== undefined) area.printMethods = [...input.printMethods];
    if (input.surchargeAmount !== undefined) area.surchargeAmount = input.surchargeAmount;
    if (input.isDefault !== undefined) area.isDefault = input.isDefault;
    if (input.isActive !== undefined) area.isActive = input.isActive;
    if (input.sortOrder !== undefined) area.sortOrder = input.sortOrder;

    return { ...area, mockupBounds: { ...area.mockupBounds } };
  }

  async deletePrintArea(productId: number, printAreaPublicId: string): Promise<boolean> {
    const product = this.products.find((p) => p.id === productId && p.deletedAt === null);
    if (!product) return false;
    const idx = product.printAreas.findIndex((p) => p.publicId === printAreaPublicId);
    if (idx < 0) return false;
    product.printAreas.splice(idx, 1);
    return true;
  }

  /** Test helper for InMemoryCommerceRepository to inspect and mutate stock atomically. */
  getInternalProductVariantsForCommerce(
    variantPublicId?: string,
    variantId?: number
  ): { product: StoredProductAggregate; variant: StoredProductVariantRecord } | null {
    for (const product of this.products) {
      for (const variant of product.variants) {
        if (
          (variantPublicId && variant.publicId === variantPublicId) ||
          (variantId !== undefined && variant.id === variantId)
        ) {
          return { product, variant };
        }
      }
    }
    return null;
  }
}
