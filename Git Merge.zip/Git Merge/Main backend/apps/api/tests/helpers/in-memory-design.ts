import crypto from 'node:crypto';
import type {
  CanonicalDesignDocument,
  DesignAssetDTO,
  DesignDetailDTO,
  DesignPrintExportDTO,
  DesignRecordStatus,
  DesignSummaryDTO,
  DesignValidationReport,
  PaginationMeta,
  PrintAreaSurfaceKey,
} from '@your-choice/shared-types';
import type {
  CreateDesignAssetParams,
  CreateDesignRecordParams,
  CreatePrintExportRecordParams,
  DesignRepository,
  ResolvedDesignRecord,
  ResolvedPrintExportRecord,
  StoredDesignAssetRecord,
  UpdateDesignRecordParams,
} from '../../src/modules/designs/design.repository.js';
import type { StorageService } from '../../src/modules/storage/storage.service.js';
import { ApiError } from '../../src/utils/api-error.js';
import type { InMemoryCatalogRepository } from './in-memory-catalog.js';

export class InMemoryStorageService implements StorageService {
  public readonly driver = 'local' as const;
  private readonly objects = new Map<string, Buffer>();

  async putPrivateObject(objectKey: string, data: Buffer): Promise<void> {
    this.objects.set(objectKey, Buffer.from(data));
  }

  async getPrivateObject(objectKey: string): Promise<Buffer> {
    const found = this.objects.get(objectKey);
    if (!found) {
      throw ApiError.notFound('Stored artwork asset was not found');
    }
    return Buffer.from(found);
  }

  async deletePrivateObject(objectKey: string): Promise<void> {
    this.objects.delete(objectKey);
  }

  async objectExists(objectKey: string): Promise<boolean> {
    return this.objects.has(objectKey);
  }

  listKeys(): string[] {
    return Array.from(this.objects.keys());
  }
}

interface StoredDesign {
  internalId: number;
  publicId: string;
  ownerUserId: number;
  productPublicId: string;
  productVariantPublicId: string;
  title: string;
  preferredMode: '2d' | '3d';
  currentVersionNumber: number;
  status: DesignRecordStatus;
  latestPreviewKey: string | null;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}

interface StoredVersion {
  internalId: number;
  publicId: string;
  designInternalId: number;
  versionNumber: number;
  document: CanonicalDesignDocument;
  validation: DesignValidationReport;
  customizedSurfaces: PrintAreaSurfaceKey[];
  estimatedCustomizationFee: string;
  currencyCode: string;
}

interface StoredPrintExport extends ResolvedPrintExportRecord {
  designVersionInternalId: number;
  designVersionNumber: number;
}

export class InMemoryDesignRepository implements DesignRepository {
  private nextAssetId = 1;
  private nextDesignId = 1;
  private nextVersionId = 1;
  private nextExportId = 1;

  private readonly assets: StoredDesignAssetRecord[] = [];
  private readonly designs: StoredDesign[] = [];
  private readonly versions: StoredVersion[] = [];
  private readonly printExports: StoredPrintExport[] = [];

  constructor(
    private readonly catalogRepo: InMemoryCatalogRepository,
    private readonly apiPrefix = '/api/v1'
  ) {}

  private toAssetDto(row: StoredDesignAssetRecord): DesignAssetDTO {
    return {
      id: row.publicId,
      originalFilename: row.originalFilename,
      mimeType: row.mimeType,
      byteSize: row.byteSize,
      widthPx: row.widthPx,
      heightPx: row.heightPx,
      sha256: row.sha256,
      previewUrl: `${this.apiPrefix}/designs/assets/${row.publicId}/preview`,
      createdAt: row.createdAt.toISOString(),
    };
  }

  private resolveProductAndVariant(productPublicId: string, variantPublicId: string) {
    const ref = this.catalogRepo.getInternalProductVariantsForCommerce(variantPublicId);
    if (!ref || ref.product.publicId !== productPublicId) {
      throw ApiError.notFound('Product or variant not found');
    }
    return ref;
  }

  private buildSummary(design: StoredDesign, version: StoredVersion): DesignSummaryDTO {
    const { product, variant } = this.resolveProductAndVariant(
      design.productPublicId,
      design.productVariantPublicId
    );
    const firstSurface = version.customizedSurfaces[0] ?? null;

    return {
      id: design.publicId,
      title: design.title,
      productId: product.publicId,
      productSlug: product.slug,
      productNameEn: product.nameEn,
      productNameBn: product.nameBn,
      productVariantId: variant.publicId,
      variantSku: variant.sku,
      variantColorNameEn: variant.colorNameEn,
      variantColorNameBn: variant.colorNameBn,
      variantColorHex: variant.colorHex,
      variantSizeCode: variant.sizeCode,
      preferredMode: design.preferredMode,
      currentVersionNumber: design.currentVersionNumber,
      status: design.status,
      customizedSurfaces: version.customizedSurfaces,
      estimatedCustomizationFee: version.estimatedCustomizationFee,
      currencyCode: version.currencyCode,
      isValidForPrint: version.validation.isValidForPrint,
      previewUrl: firstSurface
        ? `${this.apiPrefix}/designs/${design.publicId}/surfaces/${firstSurface}/preview?v=${design.currentVersionNumber}`
        : null,
      createdAt: design.createdAt.toISOString(),
      updatedAt: design.updatedAt.toISOString(),
    };
  }

  async createAsset(params: CreateDesignAssetParams): Promise<DesignAssetDTO> {
    const stored: StoredDesignAssetRecord = {
      id: this.nextAssetId++,
      publicId: params.publicId,
      ownerUserId: params.ownerUserId,
      storageDriver: params.storageDriver,
      objectKey: params.objectKey,
      previewObjectKey: params.previewObjectKey,
      originalFilename: params.originalFilename,
      mimeType: params.mimeType,
      byteSize: params.byteSize,
      widthPx: params.widthPx,
      heightPx: params.heightPx,
      sha256: params.sha256,
      createdAt: new Date(),
    };
    this.assets.push(stored);
    return this.toAssetDto(stored);
  }

  async listAssetsByOwner(ownerUserId: number): Promise<DesignAssetDTO[]> {
    return this.assets
      .filter((a) => a.ownerUserId === ownerUserId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .map((a) => this.toAssetDto(a));
  }

  async findAssetByPublicId(assetPublicId: string): Promise<StoredDesignAssetRecord | null> {
    return this.assets.find((a) => a.publicId === assetPublicId) ?? null;
  }

  async findAssetsByPublicIds(
    assetPublicIds: readonly string[]
  ): Promise<StoredDesignAssetRecord[]> {
    const set = new Set(assetPublicIds);
    return this.assets.filter((a) => set.has(a.publicId));
  }

  async listDesignsByOwner(
    ownerUserId: number,
    page: number,
    pageSize: number
  ): Promise<{ designs: DesignSummaryDTO[]; pagination: PaginationMeta }> {
    const matching = this.designs
      .filter((d) => d.ownerUserId === ownerUserId && d.deletedAt === null)
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());

    const totalItems = matching.length;
    const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
    const slice = matching.slice((page - 1) * pageSize, page * pageSize);

    const summaries = slice.map((d) => {
      const v = this.versions.find(
        (ver) =>
          ver.designInternalId === d.internalId && ver.versionNumber === d.currentVersionNumber
      )!;
      return this.buildSummary(d, v);
    });

    return {
      designs: summaries,
      pagination: { page, pageSize, totalItems, totalPages },
    };
  }

  async findDesignByPublicId(designPublicId: string): Promise<ResolvedDesignRecord | null> {
    const design = this.designs.find((d) => d.publicId === designPublicId && d.deletedAt === null);
    if (!design) return null;

    const version = this.versions.find(
      (v) =>
        v.designInternalId === design.internalId && v.versionNumber === design.currentVersionNumber
    );
    if (!version) return null;

    const exportsList: DesignPrintExportDTO[] = this.printExports
      .filter((e) => e.designPublicId === design.publicId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .map((e) => ({
        id: e.publicId,
        designId: e.designPublicId,
        designVersionNumber: e.designVersionNumber,
        surfaceKey: e.surfaceKey,
        widthPx: e.widthPx,
        heightPx: e.heightPx,
        dpi: e.dpi,
        byteSize: e.byteSize,
        sha256: e.sha256,
        downloadUrl: `${this.apiPrefix}/designs/exports/${e.publicId}/download`,
        createdAt: e.createdAt.toISOString(),
      }));

    return {
      internalId: design.internalId,
      ownerUserId: design.ownerUserId,
      currentVersionId: version.internalId,
      detail: {
        ...this.buildSummary(design, version),
        document: structuredClone(version.document),
        validation: structuredClone(version.validation),
        exports: exportsList,
      },
    };
  }

  async createDesign(params: CreateDesignRecordParams): Promise<DesignDetailDTO> {
    this.resolveProductAndVariant(params.productPublicId, params.productVariantPublicId);
    const now = new Date();
    const internalId = this.nextDesignId++;

    const design: StoredDesign = {
      internalId,
      publicId: params.publicId,
      ownerUserId: params.ownerUserId,
      productPublicId: params.productPublicId,
      productVariantPublicId: params.productVariantPublicId,
      title: params.title,
      preferredMode: params.preferredMode,
      currentVersionNumber: 1,
      status: params.status,
      latestPreviewKey: params.latestPreviewKey,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
    };
    this.designs.push(design);

    this.versions.push({
      internalId: this.nextVersionId++,
      publicId: crypto.randomUUID(),
      designInternalId: internalId,
      versionNumber: 1,
      document: structuredClone({ ...params.document, designId: params.publicId, version: 1 }),
      validation: structuredClone(params.validation),
      customizedSurfaces: [...params.customizedSurfaces],
      estimatedCustomizationFee: params.estimatedCustomizationFee,
      currencyCode: params.currencyCode,
    });

    const created = await this.findDesignByPublicId(params.publicId);
    return created!.detail;
  }

  async updateDesign(params: UpdateDesignRecordParams): Promise<DesignDetailDTO> {
    const design = this.designs.find(
      (d) => d.publicId === params.designPublicId && d.deletedAt === null
    );
    if (!design || design.ownerUserId !== params.ownerUserId) {
      throw ApiError.notFound('Saved design not found');
    }

    const targetVariantId = params.productVariantPublicId ?? design.productVariantPublicId;
    this.resolveProductAndVariant(design.productPublicId, targetVariantId);

    const nextVersionNumber = params.createVersionSnapshot
      ? design.currentVersionNumber + 1
      : design.currentVersionNumber;

    design.title = params.title ?? design.title;
    design.productVariantPublicId = targetVariantId;
    design.preferredMode = params.preferredMode ?? design.preferredMode;
    design.currentVersionNumber = nextVersionNumber;
    design.status = params.status ?? design.status;
    if (params.latestPreviewKey !== undefined) {
      design.latestPreviewKey = params.latestPreviewKey;
    }
    design.updatedAt = new Date();

    const nextDoc: CanonicalDesignDocument = structuredClone({
      ...params.document,
      designId: design.publicId,
      version: nextVersionNumber,
    });

    if (params.createVersionSnapshot) {
      this.versions.push({
        internalId: this.nextVersionId++,
        publicId: crypto.randomUUID(),
        designInternalId: design.internalId,
        versionNumber: nextVersionNumber,
        document: nextDoc,
        validation: structuredClone(params.validation),
        customizedSurfaces: [...params.customizedSurfaces],
        estimatedCustomizationFee: params.estimatedCustomizationFee,
        currencyCode: params.currencyCode,
      });
    } else {
      const existingVer = this.versions.find(
        (v) =>
          v.designInternalId === design.internalId &&
          v.versionNumber === design.currentVersionNumber
      );
      if (existingVer) {
        existingVer.document = nextDoc;
        existingVer.validation = structuredClone(params.validation);
        existingVer.customizedSurfaces = [...params.customizedSurfaces];
        existingVer.estimatedCustomizationFee = params.estimatedCustomizationFee;
        existingVer.currencyCode = params.currencyCode;
      }
    }

    const updated = await this.findDesignByPublicId(design.publicId);
    return updated!.detail;
  }

  async softDeleteDesign(designPublicId: string, ownerUserId: number): Promise<boolean> {
    const design = this.designs.find(
      (d) => d.publicId === designPublicId && d.ownerUserId === ownerUserId && d.deletedAt === null
    );
    if (!design) return false;
    design.deletedAt = new Date();
    design.status = 'archived';
    design.updatedAt = new Date();
    return true;
  }

  async recordPrintExport(params: CreatePrintExportRecordParams): Promise<DesignPrintExportDTO> {
    const design = this.designs.find((d) => d.internalId === params.designInternalId);
    const version = this.versions.find((v) => v.internalId === params.designVersionInternalId);
    const stored: StoredPrintExport = {
      internalId: this.nextExportId++,
      publicId: params.publicId,
      designPublicId: design?.publicId ?? '',
      ownerUserId: design?.ownerUserId ?? params.requestedByUserId,
      designVersionInternalId: params.designVersionInternalId,
      designVersionNumber: version?.versionNumber ?? 1,
      surfaceKey: params.surfaceKey,
      objectKey: params.objectKey,
      widthPx: params.widthPx,
      heightPx: params.heightPx,
      dpi: params.dpi,
      byteSize: params.byteSize,
      sha256: params.sha256,
      createdAt: new Date(),
    };
    this.printExports.push(stored);

    return {
      id: stored.publicId,
      designId: stored.designPublicId,
      designVersionNumber: stored.designVersionNumber,
      surfaceKey: stored.surfaceKey,
      widthPx: stored.widthPx,
      heightPx: stored.heightPx,
      dpi: stored.dpi,
      byteSize: stored.byteSize,
      sha256: stored.sha256,
      downloadUrl: `${this.apiPrefix}/designs/exports/${stored.publicId}/download`,
      createdAt: stored.createdAt.toISOString(),
    };
  }

  async findPrintExportByPublicId(
    exportPublicId: string
  ): Promise<ResolvedPrintExportRecord | null> {
    return this.printExports.find((e) => e.publicId === exportPublicId) ?? null;
  }
}
