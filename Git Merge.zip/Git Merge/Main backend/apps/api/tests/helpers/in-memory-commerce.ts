import crypto from 'node:crypto';
import { SHIPPING_ZONE_SEED_DATA } from '@your-choice/database';
import {
  ALLOWED_ORDER_TRANSITIONS,
  type BangladeshDivision,
  CUSTOMER_CANCELLABLE_STATUSES,
  type CartDTO,
  type CartItemCustomizationDTO,
  type CartItemDTO,
  type GarmentSizeCode,
  type OrderDetailDTO,
  type OrderItemDTO,
  type OrderItemProductionSpecDTO,
  type OrderStatus,
  type OrderStatusHistoryEntryDTO,
  type OrderSummaryDTO,
  type PaymentMethod,
  type PaymentStatus,
  type PaymentTransactionDTO,
  type PaymentTransactionStatus,
  type ShippingZoneDTO,
} from '@your-choice/shared-types';
import { decimalToMinorUnits, minorUnitsToDecimal } from '@your-choice/shared-utils';
import type { AdminOrderListQueryInput } from '@your-choice/validation';
import type {
  AdminSettleCodParams,
  AdminUpdateOrderStatusParams,
  ApplyWebhookPaymentParams,
  CancelOrderParams,
  CartItemCustomizationPayload,
  CommerceOrderListResult,
  CommerceRepository,
  PlaceOrderParams,
  ResolvedCartIdentity,
} from '../../src/modules/commerce/commerce.repository.js';
import {
  computeEffectiveUnitPrice,
  computeLineTotal,
  computeOrderTotalMinor,
  computeShippingQuote,
  generateOrderNumber,
} from '../../src/modules/commerce/pricing.js';
import { ApiError } from '../../src/utils/api-error.js';
import type { InMemoryCatalogRepository } from './in-memory-catalog.js';

interface StoredCart {
  id: number;
  publicId: string;
  userId: number | null;
  guestTokenHash: string | null;
  currencyCode: string;
  expiresAt: Date;
}

interface StoredCartItem {
  id: number;
  publicId: string;
  cartId: number;
  variantId: number;
  itemKey: string;
  quantity: number;
  unitPriceSnapshot: string;
  customizationFee: string;
  currencyCode: string;
  designPublicId: string | null;
  customizationMeta: CartItemCustomizationDTO | null;
  productionSpecPreview: OrderItemProductionSpecDTO | null;
}

interface StoredOrder {
  id: number;
  publicId: string;
  orderNumber: string;
  userId: number | null;
  customerEmail: string;
  customerPhone: string;
  shippingAddressJson: OrderDetailDTO['shippingAddress'];
  shippingZoneCode: string;
  shippingZoneNameSnapshot: string;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  subtotalAmount: string;
  shippingAmount: string;
  discountAmount: string;
  totalAmount: string;
  currencyCode: string;
  customerNote: string | null;
  cancelledAt: Date | null;
  cancellationReason: string | null;
  createdAt: Date;
  updatedAt: Date;
  items: OrderItemDTO[];
  statusHistory: OrderStatusHistoryEntryDTO[];
  paymentTransactions: PaymentTransactionDTO[];
}

export class InMemoryCommerceRepository implements CommerceRepository {
  private nextCartId = 1;
  private nextCartItemId = 1;
  private nextOrderId = 1;
  private nextOrderItemId = 1;
  private nextHistoryId = 1;

  private readonly shippingZones: ShippingZoneDTO[];
  private readonly carts: StoredCart[] = [];
  private readonly cartItems: StoredCartItem[] = [];
  private readonly orders: StoredOrder[] = [];

  constructor(private readonly catalogRepo: InMemoryCatalogRepository) {
    this.shippingZones = SHIPPING_ZONE_SEED_DATA.map((entry) => ({
      id: entry.publicId,
      code: entry.code,
      nameEn: entry.nameEn,
      nameBn: entry.nameBn,
      divisions: [...entry.divisions],
      flatFee: entry.flatFee,
      freeShippingThreshold: entry.freeShippingThreshold,
      estimatedDaysMin: entry.estimatedDaysMin,
      estimatedDaysMax: entry.estimatedDaysMax,
      currencyCode: 'BDT',
      isActive: true,
    }));
  }

  async listActiveShippingZones(): Promise<ShippingZoneDTO[]> {
    return this.shippingZones.filter((z) => z.isActive).map((z) => ({ ...z }));
  }

  async findShippingZoneByDivision(division: BangladeshDivision): Promise<ShippingZoneDTO | null> {
    const found = this.shippingZones.find((z) => z.isActive && z.divisions.includes(division));
    return found ? { ...found, divisions: [...found.divisions] } : null;
  }

  private hydrateCart(cart: StoredCart): CartDTO {
    const rawItems = this.cartItems.filter((item) => item.cartId === cart.id);
    const items: CartItemDTO[] = [];
    let subtotalMinor = 0n;
    let itemCount = 0;
    let hasUnavailableItems = false;

    for (const line of rawItems) {
      const ref = this.catalogRepo.getInternalProductVariantsForCommerce(undefined, line.variantId);
      if (!ref || ref.product.deletedAt !== null || ref.variant.deletedAt !== null) {
        hasUnavailableItems = true;
        continue;
      }

      const { product, variant } = ref;
      const liveUnitPrice = computeEffectiveUnitPrice(product.basePrice, variant.priceOverride);
      const lineTotal = computeLineTotal(liveUnitPrice, line.customizationFee, line.quantity);
      const isAvailable =
        product.status === 'active' && variant.isActive && variant.stockQuantity >= line.quantity;

      if (!isAvailable) {
        hasUnavailableItems = true;
      }

      subtotalMinor += decimalToMinorUnits(lineTotal);
      itemCount += line.quantity;

      const sortedImages = [...product.images].sort(
        (a, b) => Number(b.isPrimary) - Number(a.isPrimary) || a.sortOrder - b.sortOrder
      );

      items.push({
        id: line.publicId,
        variantId: variant.publicId,
        productId: product.publicId,
        productSlug: product.slug,
        productNameEn: product.nameEn,
        productNameBn: product.nameBn,
        sku: variant.sku,
        colorNameEn: variant.colorNameEn,
        colorNameBn: variant.colorNameBn,
        colorHex: variant.colorHex,
        sizeCode: variant.sizeCode as GarmentSizeCode,
        primaryImageUrl: sortedImages[0]?.url ?? null,
        quantity: line.quantity,
        availableStock: variant.stockQuantity,
        isVariantAvailable: isAvailable,
        unitPrice: liveUnitPrice,
        customizationFee: line.customizationFee,
        lineTotal,
        currencyCode: line.currencyCode,
        designPublicId: line.designPublicId,
        customizationMeta: line.customizationMeta,
      });
    }

    return {
      id: cart.publicId,
      items,
      itemCount,
      subtotal: minorUnitsToDecimal(subtotalMinor),
      currencyCode: cart.currencyCode,
      hasUnavailableItems,
      expiresAt: cart.expiresAt.toISOString(),
    };
  }

  async findCartByUserId(userId: number): Promise<ResolvedCartIdentity | null> {
    const now = new Date();
    const found = this.carts.find((c) => c.userId === userId && c.expiresAt > now);
    if (!found) return null;
    return { cartId: found.id, cartPublicId: found.publicId, dto: this.hydrateCart(found) };
  }

  async findCartByGuestTokenHash(tokenHash: string): Promise<ResolvedCartIdentity | null> {
    const now = new Date();
    const found = this.carts.find(
      (c) => c.guestTokenHash === tokenHash && c.userId === null && c.expiresAt > now
    );
    if (!found) return null;
    return { cartId: found.id, cartPublicId: found.publicId, dto: this.hydrateCart(found) };
  }

  async createUserCart(userId: number, expiresAt: Date): Promise<ResolvedCartIdentity> {
    const created: StoredCart = {
      id: this.nextCartId++,
      publicId: crypto.randomUUID(),
      userId,
      guestTokenHash: null,
      currencyCode: 'BDT',
      expiresAt,
    };
    this.carts.push(created);
    return { cartId: created.id, cartPublicId: created.publicId, dto: this.hydrateCart(created) };
  }

  async createGuestCart(tokenHash: string, expiresAt: Date): Promise<ResolvedCartIdentity> {
    const created: StoredCart = {
      id: this.nextCartId++,
      publicId: crypto.randomUUID(),
      userId: null,
      guestTokenHash: tokenHash,
      currencyCode: 'BDT',
      expiresAt,
    };
    this.carts.push(created);
    return { cartId: created.id, cartPublicId: created.publicId, dto: this.hydrateCart(created) };
  }

  async upsertCartItem(
    cartId: number,
    variantPublicId: string,
    quantityToAdd: number,
    customization?: CartItemCustomizationPayload
  ): Promise<CartDTO> {
    const cart = this.carts.find((c) => c.id === cartId);
    if (!cart) throw ApiError.notFound('Cart not found');

    const ref = this.catalogRepo.getInternalProductVariantsForCommerce(variantPublicId);
    if (!ref || ref.product.deletedAt !== null || ref.variant.deletedAt !== null) {
      throw ApiError.notFound('Product variant not found');
    }
    const { product, variant } = ref;
    if (!variant.isActive || product.status !== 'active') {
      throw ApiError.conflict(
        'VARIANT_UNAVAILABLE',
        'Product variant is currently unavailable for purchase'
      );
    }

    const itemKey = customization
      ? `variant:${variant.id}:design:${customization.designPublicId}:v${customization.designVersionNumber}`
      : `variant:${variant.id}`;
    const existing = this.cartItems.find((i) => i.cartId === cartId && i.itemKey === itemKey);
    const nextQty = (existing?.quantity ?? 0) + quantityToAdd;

    if (nextQty > 50) {
      throw ApiError.badRequest('Maximum 50 units per SKU line in cart');
    }
    if (variant.stockQuantity < nextQty) {
      throw ApiError.conflict(
        'INSUFFICIENT_STOCK',
        variant.stockQuantity === 0
          ? 'Selected variant is out of stock'
          : `Only ${variant.stockQuantity} unit(s) available in stock`
      );
    }

    const unitPrice = computeEffectiveUnitPrice(product.basePrice, variant.priceOverride);
    if (existing) {
      existing.quantity = nextQty;
      existing.unitPriceSnapshot = unitPrice;
      if (customization) {
        existing.customizationFee = customization.customizationFee;
        existing.customizationMeta = customization.customizationMeta;
        existing.productionSpecPreview = customization.productionSpecPreview ?? null;
      }
    } else {
      this.cartItems.push({
        id: this.nextCartItemId++,
        publicId: crypto.randomUUID(),
        cartId,
        variantId: variant.id,
        itemKey,
        quantity: nextQty,
        unitPriceSnapshot: unitPrice,
        customizationFee: customization?.customizationFee ?? '0.00',
        currencyCode: product.currencyCode,
        designPublicId: customization?.designPublicId ?? null,
        customizationMeta: customization?.customizationMeta ?? null,
        productionSpecPreview: customization?.productionSpecPreview ?? null,
      });
    }

    return this.hydrateCart(cart);
  }

  async updateCartItemQuantity(
    cartId: number,
    itemPublicId: string,
    quantity: number
  ): Promise<CartDTO> {
    const cart = this.carts.find((c) => c.id === cartId);
    if (!cart) throw ApiError.notFound('Cart not found');

    const existing = this.cartItems.find((i) => i.cartId === cartId && i.publicId === itemPublicId);
    if (!existing) throw ApiError.notFound('Cart item not found');

    const ref = this.catalogRepo.getInternalProductVariantsForCommerce(
      undefined,
      existing.variantId
    );
    if (
      !ref ||
      ref.product.deletedAt !== null ||
      ref.variant.deletedAt !== null ||
      !ref.variant.isActive ||
      ref.product.status !== 'active'
    ) {
      throw ApiError.conflict('VARIANT_UNAVAILABLE', 'This product variant is no longer available');
    }
    if (ref.variant.stockQuantity < quantity) {
      throw ApiError.conflict(
        'INSUFFICIENT_STOCK',
        `Only ${ref.variant.stockQuantity} unit(s) available in stock`
      );
    }

    existing.quantity = quantity;
    existing.unitPriceSnapshot = computeEffectiveUnitPrice(
      ref.product.basePrice,
      ref.variant.priceOverride
    );

    return this.hydrateCart(cart);
  }

  async removeCartItem(cartId: number, itemPublicId: string): Promise<CartDTO> {
    const cart = this.carts.find((c) => c.id === cartId);
    if (!cart) throw ApiError.notFound('Cart not found');

    const idx = this.cartItems.findIndex((i) => i.cartId === cartId && i.publicId === itemPublicId);
    if (idx < 0) throw ApiError.notFound('Cart item not found');
    this.cartItems.splice(idx, 1);

    return this.hydrateCart(cart);
  }

  async clearCart(cartId: number): Promise<CartDTO> {
    const cart = this.carts.find((c) => c.id === cartId);
    if (!cart) throw ApiError.notFound('Cart not found');

    for (let i = this.cartItems.length - 1; i >= 0; i -= 1) {
      if (this.cartItems[i]?.cartId === cartId) {
        this.cartItems.splice(i, 1);
      }
    }
    return this.hydrateCart(cart);
  }

  async mergeGuestCartToUser(
    guestTokenHash: string,
    userId: number,
    expiresAt: Date
  ): Promise<void> {
    const guestCart = this.carts.find(
      (c) => c.guestTokenHash === guestTokenHash && c.userId === null
    );
    if (!guestCart) return;

    const guestLines = this.cartItems.filter((i) => i.cartId === guestCart.id);
    const existingUserCart = this.carts.find((c) => c.userId === userId);

    if (!existingUserCart) {
      guestCart.userId = userId;
      guestCart.guestTokenHash = null;
      guestCart.expiresAt = expiresAt;
      return;
    }

    for (const guestLine of guestLines) {
      const ref = this.catalogRepo.getInternalProductVariantsForCommerce(
        undefined,
        guestLine.variantId
      );
      const maxStock = ref?.variant.stockQuantity ?? 0;
      const existingLine = this.cartItems.find(
        (i) => i.cartId === existingUserCart.id && i.itemKey === guestLine.itemKey
      );

      if (existingLine) {
        existingLine.quantity = Math.min(
          50,
          Math.max(1, Math.min(maxStock, existingLine.quantity + guestLine.quantity))
        );
      } else {
        this.cartItems.push({
          id: this.nextCartItemId++,
          publicId: crypto.randomUUID(),
          cartId: existingUserCart.id,
          variantId: guestLine.variantId,
          itemKey: guestLine.itemKey,
          quantity: Math.min(
            50,
            Math.max(1, Math.min(maxStock || guestLine.quantity, guestLine.quantity))
          ),
          unitPriceSnapshot: guestLine.unitPriceSnapshot,
          customizationFee: guestLine.customizationFee,
          currencyCode: guestLine.currencyCode,
          designPublicId: guestLine.designPublicId,
          customizationMeta: guestLine.customizationMeta,
          productionSpecPreview: guestLine.productionSpecPreview,
        });
      }
    }

    for (let i = this.cartItems.length - 1; i >= 0; i -= 1) {
      if (this.cartItems[i]?.cartId === guestCart.id) {
        this.cartItems.splice(i, 1);
      }
    }
    const cartIdx = this.carts.findIndex((c) => c.id === guestCart.id);
    if (cartIdx >= 0) this.carts.splice(cartIdx, 1);
  }

  async placeOrderTransactionally(params: PlaceOrderParams): Promise<OrderDetailDTO> {
    const zone = this.shippingZones.find((z) => z.code === params.shippingZoneCode && z.isActive);
    if (!zone) {
      throw ApiError.badRequest('Selected shipping zone is unavailable');
    }

    const lines = this.cartItems.filter((i) => i.cartId === params.cartId);
    if (lines.length === 0) {
      throw ApiError.badRequest('Your cart is empty');
    }

    // Validate all stock & availability upfront before mutating inventory (simulates SQL TX rollback)
    const resolvedLines: Array<{
      line: StoredCartItem;
      product: NonNullable<
        ReturnType<InMemoryCatalogRepository['getInternalProductVariantsForCommerce']>
      >['product'];
      variant: NonNullable<
        ReturnType<InMemoryCatalogRepository['getInternalProductVariantsForCommerce']>
      >['variant'];
      unitPrice: string;
      lineTotal: string;
    }> = [];

    let subtotalMinor = 0n;
    for (const line of lines) {
      const ref = this.catalogRepo.getInternalProductVariantsForCommerce(undefined, line.variantId);
      if (
        !ref ||
        ref.product.deletedAt !== null ||
        ref.variant.deletedAt !== null ||
        !ref.variant.isActive ||
        ref.product.status !== 'active'
      ) {
        throw ApiError.conflict(
          'VARIANT_UNAVAILABLE',
          'One or more cart items are no longer active for purchase'
        );
      }

      if (ref.variant.stockQuantity < line.quantity) {
        throw ApiError.conflict(
          'INSUFFICIENT_STOCK',
          `Insufficient stock for SKU ${ref.variant.sku}. Only ${ref.variant.stockQuantity} unit(s) left.`
        );
      }

      const unitPrice = computeEffectiveUnitPrice(ref.product.basePrice, ref.variant.priceOverride);
      const lineTotal = computeLineTotal(unitPrice, line.customizationFee, line.quantity);
      subtotalMinor += decimalToMinorUnits(lineTotal);
      resolvedLines.push({
        line,
        product: ref.product,
        variant: ref.variant,
        unitPrice,
        lineTotal,
      });
    }

    // Mutate stock only after all items validated
    for (const entry of resolvedLines) {
      entry.variant.stockQuantity -= entry.line.quantity;
    }

    const quote = computeShippingQuote(
      params.shippingAddress.division,
      zone,
      minorUnitsToDecimal(subtotalMinor)
    );
    const shippingMinor = decimalToMinorUnits(quote.shippingFee);
    const totalAmount = minorUnitsToDecimal(computeOrderTotalMinor(subtotalMinor, shippingMinor));
    const orderNumber = generateOrderNumber();
    const now = new Date();
    const orderId = this.nextOrderId++;

    const orderItemsSnapshot: OrderItemDTO[] = resolvedLines.map((entry) => {
      const sortedImages = [...entry.product.images].sort(
        (a, b) => Number(b.isPrimary) - Number(a.isPrimary) || a.sortOrder - b.sortOrder
      );
      return {
        id: crypto.randomUUID(),
        __internalVariantId: entry.variant.id,
        productSlug: entry.product.slug,
        productNameEn: entry.product.nameEn,
        productNameBn: entry.product.nameBn,
        sku: entry.variant.sku,
        colorNameEn: entry.variant.colorNameEn,
        colorNameBn: entry.variant.colorNameBn,
        colorHex: entry.variant.colorHex,
        sizeCode: entry.variant.sizeCode as GarmentSizeCode,
        primaryImageUrl: sortedImages[0]?.url ?? null,
        quantity: entry.line.quantity,
        unitPrice: entry.unitPrice,
        customizationFee: entry.line.customizationFee,
        lineTotal: entry.lineTotal,
        currencyCode: entry.product.currencyCode,
        designPublicId: entry.line.designPublicId,
        designTitle: entry.line.customizationMeta?.designTitle ?? null,
        productionSpec: entry.line.productionSpecPreview ?? null,
      } as OrderItemDTO & { __internalVariantId: number };
    });

    const stored: StoredOrder = {
      id: orderId,
      publicId: crypto.randomUUID(),
      orderNumber,
      userId: params.userId,
      customerEmail: params.customerEmail.toLowerCase(),
      customerPhone: params.customerPhone,
      shippingAddressJson: { ...params.shippingAddress },
      shippingZoneCode: zone.code,
      shippingZoneNameSnapshot: zone.nameEn,
      paymentMethod: params.paymentMethod,
      paymentStatus: 'unpaid',
      orderStatus: 'pending',
      subtotalAmount: quote.subtotal,
      shippingAmount: quote.shippingFee,
      discountAmount: '0.00',
      totalAmount,
      currencyCode: zone.currencyCode,
      customerNote: params.customerNote,
      cancelledAt: null,
      cancellationReason: null,
      createdAt: now,
      updatedAt: now,
      items: orderItemsSnapshot,
      statusHistory: [
        {
          id: this.nextHistoryId++,
          fromStatus: null,
          toStatus: 'pending',
          actorRole: params.actorRole,
          note: 'Order placed via checkout',
          createdAt: now.toISOString(),
        },
      ],
      paymentTransactions: [
        {
          id: crypto.randomUUID(),
          gateway: params.paymentMethod,
          transactionRef: params.paymentMethod === 'cod' ? `COD-${orderNumber}` : null,
          providerPaymentId: null,
          amount: totalAmount,
          currencyCode: zone.currencyCode,
          status: params.paymentMethod === 'cod' ? 'unpaid' : 'pending',
          verificationSource: params.paymentMethod === 'cod' ? 'cod_promise' : null,
          verifiedAt: null,
          createdAt: now.toISOString(),
        },
      ],
    };

    this.orders.push(stored);

    for (let i = this.cartItems.length - 1; i >= 0; i -= 1) {
      if (this.cartItems[i]?.cartId === params.cartId) {
        this.cartItems.splice(i, 1);
      }
    }

    return this.toDetailDto(stored);
  }

  private toSummaryDto(row: StoredOrder): OrderSummaryDTO {
    return {
      id: row.publicId,
      orderNumber: row.orderNumber,
      customerEmail: row.customerEmail,
      customerPhone: row.customerPhone,
      orderStatus: row.orderStatus,
      paymentMethod: row.paymentMethod,
      paymentStatus: row.paymentStatus,
      subtotalAmount: row.subtotalAmount,
      shippingAmount: row.shippingAmount,
      discountAmount: row.discountAmount,
      totalAmount: row.totalAmount,
      currencyCode: row.currencyCode,
      itemCount: row.items.reduce((sum, item) => sum + item.quantity, 0),
      shippingDivision: row.shippingAddressJson.division,
      shippingZoneCode: row.shippingZoneCode,
      shippingZoneName: row.shippingZoneNameSnapshot,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  private toDetailDto(row: StoredOrder): OrderDetailDTO {
    return {
      ...this.toSummaryDto(row),
      shippingAddress: { ...row.shippingAddressJson },
      customerNote: row.customerNote,
      cancelledAt: row.cancelledAt ? row.cancelledAt.toISOString() : null,
      cancellationReason: row.cancellationReason,
      canCustomerCancel: CUSTOMER_CANCELLABLE_STATUSES.includes(row.orderStatus),
      allowedNextStatuses: [...ALLOWED_ORDER_TRANSITIONS[row.orderStatus]],
      items: row.items.map((item) => {
        const { __internalVariantId: _, ...publicItem } = item as OrderItemDTO & {
          __internalVariantId?: number;
        };
        return { ...publicItem };
      }),
      statusHistory: row.statusHistory.map((h) => ({ ...h })),
      paymentTransactions: row.paymentTransactions.map((tx) => ({ ...tx })),
    };
  }

  async listOrdersByUserId(
    userId: number,
    page: number,
    pageSize: number
  ): Promise<CommerceOrderListResult> {
    const filtered = this.orders
      .filter((o) => o.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime() || b.id - a.id);
    const offset = (page - 1) * pageSize;
    const totalItems = filtered.length;
    return {
      orders: filtered.slice(offset, offset + pageSize).map((o) => this.toSummaryDto(o)),
      pagination: {
        page,
        pageSize,
        totalItems,
        totalPages: Math.max(1, Math.ceil(totalItems / pageSize)),
      },
    };
  }

  async findOrderByNumber(orderNumber: string): Promise<{
    ownerUserId: number | null;
    order: OrderDetailDTO;
  } | null> {
    const found = this.orders.find((o) => o.orderNumber === orderNumber);
    if (!found) return null;
    return {
      ownerUserId: found.userId,
      order: this.toDetailDto(found),
    };
  }

  async cancelOrderTransactionally(params: CancelOrderParams): Promise<OrderDetailDTO> {
    const row = this.orders.find((o) => o.orderNumber === params.orderNumber);
    if (!row) throw ApiError.notFound('Order not found');

    if (params.isCustomerSelfService && row.userId !== params.actorUserId) {
      throw ApiError.forbidden('You do not have permission to cancel this order');
    }

    if (params.isCustomerSelfService) {
      if (!CUSTOMER_CANCELLABLE_STATUSES.includes(row.orderStatus)) {
        throw ApiError.conflict(
          'ORDER_NOT_CANCELLABLE',
          `Order in status "${row.orderStatus}" can no longer be cancelled self-service`
        );
      }
    } else if (!ALLOWED_ORDER_TRANSITIONS[row.orderStatus].includes('cancelled')) {
      throw ApiError.conflict(
        'ORDER_STATUS_CONFLICT',
        `Cannot cancel order in status "${row.orderStatus}"`
      );
    }

    // Restore variant inventory
    for (const item of row.items as Array<OrderItemDTO & { __internalVariantId?: number }>) {
      const ref = this.catalogRepo.getInternalProductVariantsForCommerce(
        item.id ? undefined : undefined,
        item.__internalVariantId
      );
      if (ref) {
        ref.variant.stockQuantity += item.quantity;
      }
    }

    const fromStatus = row.orderStatus;
    const now = new Date();
    row.orderStatus = 'cancelled';
    row.cancelledAt = now;
    row.cancellationReason = params.reason;
    row.updatedAt = now;

    row.statusHistory.push({
      id: this.nextHistoryId++,
      fromStatus,
      toStatus: 'cancelled',
      actorRole: params.actorRole,
      note:
        params.reason ??
        (params.isCustomerSelfService ? 'Cancelled by customer' : 'Cancelled by staff'),
      createdAt: now.toISOString(),
    });

    return this.toDetailDto(row);
  }

  async adminListOrders(query: AdminOrderListQueryInput): Promise<CommerceOrderListResult> {
    const searchLower = query.search?.trim().toLowerCase() ?? '';
    const filtered = this.orders
      .filter((o) => {
        if (query.status && o.orderStatus !== query.status) return false;
        if (
          searchLower &&
          !o.orderNumber.toLowerCase().includes(searchLower) &&
          !o.customerEmail.toLowerCase().includes(searchLower) &&
          !o.customerPhone.toLowerCase().includes(searchLower)
        ) {
          return false;
        }
        return true;
      })
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime() || b.id - a.id);

    const offset = (query.page - 1) * query.pageSize;
    const totalItems = filtered.length;
    return {
      orders: filtered.slice(offset, offset + query.pageSize).map((o) => this.toSummaryDto(o)),
      pagination: {
        page: query.page,
        pageSize: query.pageSize,
        totalItems,
        totalPages: Math.max(1, Math.ceil(totalItems / query.pageSize)),
      },
    };
  }

  async adminUpdateOrderStatus(params: AdminUpdateOrderStatusParams): Promise<OrderDetailDTO> {
    const row = this.orders.find((o) => o.orderNumber === params.orderNumber);
    if (!row) throw ApiError.notFound('Order not found');

    if (!ALLOWED_ORDER_TRANSITIONS[row.orderStatus].includes(params.toStatus)) {
      throw ApiError.conflict(
        'ORDER_STATUS_CONFLICT',
        `Invalid order status transition from "${row.orderStatus}" to "${params.toStatus}"`
      );
    }

    const fromStatus = row.orderStatus;
    const now = new Date();
    row.orderStatus = params.toStatus;
    row.updatedAt = now;
    row.statusHistory.push({
      id: this.nextHistoryId++,
      fromStatus,
      toStatus: params.toStatus,
      actorRole: params.actorRole,
      note: params.note,
      createdAt: now.toISOString(),
    });

    return this.toDetailDto(row);
  }

  async adminSettleCodPayment(params: AdminSettleCodParams): Promise<OrderDetailDTO> {
    const row = this.orders.find((o) => o.orderNumber === params.orderNumber);
    if (!row) throw ApiError.notFound('Order not found');
    if (row.paymentMethod !== 'cod') {
      throw ApiError.conflict(
        'PAYMENT_SETTLEMENT_CONFLICT',
        'Only Cash-on-Delivery orders can be manually settled here'
      );
    }
    if (row.orderStatus === 'cancelled') {
      throw ApiError.conflict(
        'ORDER_STATUS_CONFLICT',
        'Cannot settle payment for a cancelled order'
      );
    }

    const now = new Date();
    row.paymentStatus = 'paid';
    row.updatedAt = now;
    for (const tx of row.paymentTransactions) {
      tx.transactionRef = params.transactionRef;
      tx.status = 'paid';
      tx.verificationSource = 'admin_settlement';
      tx.verifiedAt = now.toISOString();
    }
    row.statusHistory.push({
      id: this.nextHistoryId++,
      fromStatus: row.orderStatus,
      toStatus: row.orderStatus,
      actorRole: params.actorRole,
      note: params.note ?? `COD cash collection verified (${params.transactionRef})`,
      createdAt: now.toISOString(),
    });

    return this.toDetailDto(row);
  }

  async applyVerifiedPaymentWebhook(params: ApplyWebhookPaymentParams): Promise<{
    order: OrderDetailDTO;
    paymentStatus: PaymentStatus;
    idempotentReplay: boolean;
  }> {
    const row = this.orders.find((o) => o.orderNumber === params.orderNumber);
    if (!row) throw ApiError.notFound('Order referenced by webhook not found');
    if (row.paymentMethod !== params.gateway) {
      throw ApiError.conflict('WEBHOOK_GATEWAY_MISMATCH', 'Order payment gateway mismatch');
    }

    if (
      decimalToMinorUnits(row.totalAmount) !== decimalToMinorUnits(params.amount) ||
      row.currencyCode.toUpperCase() !== params.currencyCode.toUpperCase()
    ) {
      throw ApiError.conflict(
        'WEBHOOK_AMOUNT_MISMATCH',
        'Webhook payment amount or currency does not match order total'
      );
    }

    const existingMatchingTx = row.paymentTransactions.find(
      (t) =>
        t.gateway === params.gateway &&
        t.transactionRef === params.transactionRef &&
        t.status === params.nextTransactionStatus
    );
    if (existingMatchingTx) {
      return {
        order: this.toDetailDto(row),
        paymentStatus: row.paymentStatus,
        idempotentReplay: true,
      };
    }

    const nextOrderPaymentStatus: PaymentStatus =
      params.nextTransactionStatus === 'paid' ? 'paid' : 'failed';
    const now = new Date();

    for (const tx of row.paymentTransactions) {
      tx.transactionRef = params.transactionRef;
      tx.providerPaymentId = params.providerPaymentId;
      tx.status = params.nextTransactionStatus as PaymentTransactionStatus;
      tx.verificationSource = 'gateway_webhook';
      tx.verifiedAt = now.toISOString();
    }

    row.paymentStatus = nextOrderPaymentStatus;
    if (nextOrderPaymentStatus === 'paid' && row.orderStatus === 'pending') {
      row.orderStatus = 'confirmed';
      row.statusHistory.push({
        id: this.nextHistoryId++,
        fromStatus: 'pending',
        toStatus: 'confirmed',
        actorRole: `gateway:${params.gateway}`,
        note: `Payment verified via signed ${params.gateway} webhook (${params.transactionRef})`,
        createdAt: now.toISOString(),
      });
    }
    row.updatedAt = now;

    return {
      order: this.toDetailDto(row),
      paymentStatus: nextOrderPaymentStatus,
      idempotentReplay: false,
    };
  }
}
