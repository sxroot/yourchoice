import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { parseApiEnv } from '../src/config/env.js';
import { createLogger } from '../src/config/logger.js';

function buildTestApp(dbUp: boolean) {
  const env = parseApiEnv({
    NODE_ENV: 'test',
    LOG_LEVEL: 'silent',
    CORS_ORIGINS: 'http://localhost:5173',
  });
  const logger = createLogger(env);

  return createApp({
    env,
    logger,
    pingDatabase: async () =>
      dbUp
        ? { status: 'up', dialect: 'mariadb', latencyMs: 1.42 }
        : {
            status: 'down',
            dialect: 'mariadb',
            latencyMs: null,
            error: 'Database unavailable (ECONNREFUSED)',
          },
  });
}

describe('Health endpoints', () => {
  it('returns 200 and alive status from /api/health/live and /api/v1/health/live', async () => {
    const app = buildTestApp(false);
    for (const endpoint of ['/api/health/live', '/api/v1/health/live']) {
      const res = await request(app).get(endpoint);
      expect(res.status).toBe(200);
      expect(res.headers['x-request-id']).toBeTruthy();
      expect(res.body.success).toBe(true);
      expect(res.body.data.status).toBe('alive');
      expect(res.body.data.service).toBe('YOUR CHOICE');
    }
  });

  it('returns 200 and healthy status from /api/health when MariaDB responds', async () => {
    const app = buildTestApp(true);
    for (const endpoint of ['/api/health', '/api/v1/health']) {
      const res = await request(app).get(endpoint);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.status).toBe('healthy');
      expect(res.body.data.checks.database).toEqual({
        status: 'up',
        dialect: 'mariadb',
        latencyMs: 1.42,
      });
    }
  });

  it('returns 200 degraded on /api/health and 503 on /api/health/ready when MariaDB is unreachable', async () => {
    const app = buildTestApp(false);

    const healthRes = await request(app).get('/api/health');
    expect(healthRes.status).toBe(200);
    expect(healthRes.body.data.status).toBe('degraded');
    expect(healthRes.body.data.checks.database.status).toBe('down');

    const readyRes = await request(app).get('/api/v1/health/ready');
    expect(readyRes.status).toBe(503);
    expect(readyRes.body.success).toBe(true);
    expect(readyRes.body.data.status).toBe('degraded');
    expect(readyRes.body.data.checks.database.status).toBe('down');
  });

  it('returns standardized 404 error envelope for unknown routes', async () => {
    const app = buildTestApp(true);
    const res = await request(app).get('/api/v1/does-not-exist');

    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('ROUTE_NOT_FOUND');
    expect(res.body.meta.requestId).toBeTruthy();
  });

  it('returns 403 CORS_ORIGIN_DENIED for disallowed origins instead of 500', async () => {
    const app = buildTestApp(true);
    const res = await request(app).get('/api/health').set('Origin', 'https://evil.example.com');

    expect(res.status).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('CORS_ORIGIN_DENIED');
  });
});
