import type { CanonicalDesignDocument } from '@your-choice/shared-types';
import sharp from 'sharp';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { parseApiEnv } from '../src/config/env.js';
import { createLogger } from '../src/config/logger.js';
import { InMemoryAuditRepository, InMemoryCatalogRepository } from './helpers/in-memory-catalog.js';
import { InMemoryCommerceRepository } from './helpers/in-memory-commerce.js';
import { InMemoryDesignRepository, InMemoryStorageService } from './helpers/in-memory-design.js';
import { InMemoryIdentityRepository } from './helpers/in-memory-identity.js';

function createDesignTestHarness() {
  const env = parseApiEnv({
    NODE_ENV: 'test',
    LOG_LEVEL: 'silent',
    CSRF_ENABLED: 'true',
    SESSION_SECRET: 'test-session-secret-with-more-than-32-chars',
    SESSION_COOKIE_NAME: 'yc_session',
    CART_COOKIE_NAME: 'yc_cart',
    SESSION_TTL_HOURS: '168',
    CORS_ORIGINS: 'http://localhost:5173',
  });

  const identityRepo = new InMemoryIdentityRepository();
  const catalogRepo = new InMemoryCatalogRepository(true);
  const commerceRepo = new InMemoryCommerceRepository(catalogRepo);
  const auditRepo = new InMemoryAuditRepository();
  const designRepo = new InMemoryDesignRepository(catalogRepo, env.API_PREFIX);
  const storageService = new InMemoryStorageService();
  const logger = createLogger(env);

  const app = createApp({
    env,
    logger,
    pingDatabase: async () => ({ status: 'up', dialect: 'mariadb', latencyMs: 1.0 }),
    identityRepository: identityRepo,
    catalogRepository: catalogRepo,
    commerceRepository: commerceRepo,
    auditRepository: auditRepo,
    designRepository: designRepo,
    storageService,
    authRateLimits: { strictMax: 200, generalMax: 500 },
  });

  return { app, catalogRepo, identityRepo, storageService, env };
}

async function createCsrfHeaders(agent: request.Agent) {
  const csrfRes = await agent.get('/api/v1/auth/csrf');
  const token = csrfRes.body.data.csrfToken as string;
  return {
    Origin: 'http://localhost:5173',
    'X-CSRF-Token': token,
  };
}

describe('Phase 2 Professional 2D Apparel Design Studio API, Validation & 300 DPI Export', () => {
  it('verifies binary magic bytes, strips EXIF, enforces asset IDOR isolation, and creates/exports 300 DPI transparent PNGs + custom cart orders', async () => {
    const { app, identityRepo, storageService } = createDesignTestHarness();

    const ownerAgent = request.agent(app);
    const otherAgent = request.agent(app);
    const adminAgent = request.agent(app);

    const ownerHeaders = await createCsrfHeaders(ownerAgent);
    await ownerAgent.post('/api/v1/auth/register').set(ownerHeaders).send({
      fullName: 'Amina Rahman',
      email: 'amina.studio@example.com',
      phone: '01711223344',
      password: 'StudioPassword123!',
    });

    const otherHeaders = await createCsrfHeaders(otherAgent);
    await otherAgent.post('/api/v1/auth/register').set(otherHeaders).send({
      fullName: 'Other User',
      email: 'other.studio@example.com',
      phone: '01811223344',
      password: 'OtherPassword123!',
    });

    // Seed admin session via existing identity repo helper
    const adminHeaders = await createCsrfHeaders(adminAgent);
    await adminAgent.post('/api/v1/auth/register').set(adminHeaders).send({
      fullName: 'Production Staff',
      email: 'staff.studio@example.com',
      phone: '01911223344',
      password: 'StaffPassword123!',
    });
    const staffUser = await identityRepo.findUserByEmail('staff.studio@example.com');
    expect(staffUser).not.toBeNull();
    await identityRepo.replaceUserRoles(staffUser!.id, ['admin'], staffUser!.id);

    // Fetch customizable product + variant + print areas from catalog
    const productsRes = await ownerAgent.get('/api/v1/products');
    const customizableSummary = (
      productsRes.body.data.products as Array<{ slug: string; isCustomizable: boolean }>
    ).find((p) => p.isCustomizable);
    expect(customizableSummary).toBeDefined();

    const detailRes = await ownerAgent.get(`/api/v1/products/${customizableSummary!.slug}`);
    const product = detailRes.body.data.product;
    const variant = product.variants[0];
    const frontArea = product.printAreas.find(
      (pa: { surfaceKey: string }) => pa.surfaceKey === 'front'
    );
    const backArea = product.printAreas.find(
      (pa: { surfaceKey: string }) => pa.surfaceKey === 'back'
    );
    expect(frontArea).toBeDefined();

    // 1. Unauthenticated upload rejected
    const anonAgent = request.agent(app);
    const anonHeaders = await createCsrfHeaders(anonAgent);
    const unauthUpload = await anonAgent
      .post('/api/v1/designs/assets/upload')
      .set(anonHeaders)
      .attach('file', Buffer.from('not-an-image'), 'fake.png');
    expect(unauthUpload.status).toBe(401);

    // 2. Spoofed SVG/XSS payload named evil.png rejected via magic-byte inspection
    const spoofedRes = await ownerAgent
      .post('/api/v1/designs/assets/upload')
      .set(ownerHeaders)
      .attach('file', Buffer.from('<svg onload="alert(1)"></svg>'), 'evil.png');
    expect(spoofedRes.status).toBe(400);
    expect(spoofedRes.body.error.code).toBe('BAD_REQUEST');

    // 3. Valid 1600x1600 RGBA PNG artwork upload
    const validPng = await sharp({
      create: {
        width: 1600,
        height: 1600,
        channels: 4,
        background: { r: 37, g: 99, b: 235, alpha: 0.9 },
      },
    })
      .png()
      .toBuffer();

    const uploadRes = await ownerAgent
      .post('/api/v1/designs/assets/upload')
      .set(ownerHeaders)
      .attach('file', validPng, 'dhaka-crest.png');
    expect(uploadRes.status).toBe(201);
    const uploadedAsset = uploadRes.body.data.asset;
    expect(uploadedAsset.widthPx).toBe(1600);
    expect(uploadedAsset.heightPx).toBe(1600);
    expect(storageService.listKeys().some((k) => k.startsWith('private/uploads/'))).toBe(true);

    // Owner preview works, other user blocked (404 IDOR defense)
    const ownAssetPreview = await ownerAgent.get(uploadedAsset.previewUrl);
    expect(ownAssetPreview.status).toBe(200);
    const otherAssetPreview = await otherAgent.get(uploadedAsset.previewUrl);
    expect(otherAssetPreview.status).toBe(404);

    // 4. Create CanonicalDesignDocument with Text, Graphic Pack, Group, and Uploaded Image
    const canonicalDoc: CanonicalDesignDocument = {
      schemaVersion: 1,
      designId: null,
      productId: product.id,
      productVariantId: variant.id,
      preferredMode: '2d',
      version: 1,
      updatedAt: new Date().toISOString(),
      surfaces: {
        front: {
          surfaceKey: 'front',
          printAreaId: frontArea.id,
          physicalWidthMm: frontArea.physicalWidthMm,
          physicalHeightMm: frontArea.physicalHeightMm,
          targetDpi: frontArea.targetDpi,
          safeInsetMm: frontArea.safeInsetMm,
          objects: [
            {
              id: 'shape-bg-badge',
              type: 'shape',
              name: 'Accent Badge',
              x: 0.2,
              y: 0.14,
              width: 0.6,
              height: 0.18,
              rotationDeg: 0,
              opacity: 0.95,
              flipX: false,
              flipY: false,
              visible: true,
              locked: false,
              shapeKind: 'rect',
              fill: '#1D4ED8',
              stroke: '#38BDF8',
              strokeWidth: 4,
              cornerRadius: 16,
            },
            {
              id: 'text-headline',
              type: 'text',
              name: 'Studio Headline',
              x: 0.22,
              y: 0.18,
              width: 0.56,
              height: 0.1,
              rotationDeg: 0,
              opacity: 1,
              flipX: false,
              flipY: false,
              visible: true,
              locked: false,
              text: 'DHAKA 26',
              fontFamily: 'Space Grotesk',
              fontSizeRatio: 0.08,
              fontWeight: 700,
              fontStyle: 'normal',
              textAlign: 'center',
              lineHeight: 1.15,
              letterSpacing: 40,
              fill: '#FFFFFF',
              stroke: null,
              strokeWidth: 0,
            },
            {
              id: 'img-crest',
              type: 'image',
              name: 'dhaka-crest.png',
              x: 0.3,
              y: 0.38,
              width: 0.4,
              height: 0.3,
              rotationDeg: 10,
              opacity: 1,
              flipX: false,
              flipY: false,
              visible: true,
              locked: false,
              assetId: uploadedAsset.id,
              naturalWidthPx: uploadedAsset.widthPx,
              naturalHeightPx: uploadedAsset.heightPx,
              cropRect: null,
            },
            ...(backArea
              ? []
              : [
                  {
                    id: 'grp-seal',
                    type: 'group' as const,
                    name: 'Emblem Group',
                    x: 0.35,
                    y: 0.72,
                    width: 0.3,
                    height: 0.16,
                    rotationDeg: 0,
                    opacity: 1,
                    flipX: false,
                    flipY: false,
                    visible: true,
                    locked: false,
                    children: [
                      {
                        id: 'grp-star',
                        type: 'graphic' as const,
                        name: 'Studio Starburst',
                        x: 0.1,
                        y: 0.1,
                        width: 0.8,
                        height: 0.8,
                        rotationDeg: 0,
                        opacity: 1,
                        flipX: false,
                        flipY: false,
                        visible: true,
                        locked: false,
                        graphicId: 'yc-starburst',
                        pathData:
                          'M 50 4 L 61 32 L 91 26 L 71 49 L 94 70 L 63 72 L 66 96 L 47 75 L 25 92 L 32 63 L 6 58 L 29 42 L 15 16 L 42 29 Z',
                        viewBoxSize: 100,
                        fill: '#38BDF8',
                        stroke: '#0F172A',
                        strokeWidth: 2,
                      },
                    ],
                  },
                ]),
          ],
        },
        ...(backArea
          ? {
              back: {
                surfaceKey: 'back' as const,
                printAreaId: backArea.id,
                physicalWidthMm: backArea.physicalWidthMm,
                physicalHeightMm: backArea.physicalHeightMm,
                targetDpi: backArea.targetDpi,
                safeInsetMm: backArea.safeInsetMm,
                objects: [
                  {
                    id: 'back-group',
                    type: 'group' as const,
                    name: 'Back Crest Group',
                    x: 0.3,
                    y: 0.2,
                    width: 0.4,
                    height: 0.35,
                    rotationDeg: 0,
                    opacity: 1,
                    flipX: false,
                    flipY: false,
                    visible: true,
                    locked: false,
                    children: [
                      {
                        id: 'back-shield',
                        type: 'graphic' as const,
                        name: 'Varsity Shield',
                        x: 0.2,
                        y: 0.05,
                        width: 0.6,
                        height: 0.55,
                        rotationDeg: 0,
                        opacity: 1,
                        flipX: false,
                        flipY: false,
                        visible: true,
                        locked: false,
                        graphicId: 'yc-crest-shield',
                        pathData:
                          'M 50 6 L 88 18 V 48 C 88 71 72 86 50 95 C 28 86 12 71 12 48 V 18 Z',
                        viewBoxSize: 100,
                        fill: '#2563EB',
                        stroke: '#FFFFFF',
                        strokeWidth: 3,
                      },
                      {
                        id: 'back-label',
                        type: 'text' as const,
                        name: 'Bangla Motto',
                        x: 0.05,
                        y: 0.68,
                        width: 0.9,
                        height: 0.25,
                        rotationDeg: 0,
                        opacity: 1,
                        flipX: false,
                        flipY: false,
                        visible: true,
                        locked: false,
                        text: 'নিজেই ডিজাইন করুন',
                        fontFamily: 'Noto Sans Bengali',
                        fontSizeRatio: 0.06,
                        fontWeight: 600,
                        fontStyle: 'normal',
                        textAlign: 'center',
                        lineHeight: 1.2,
                        letterSpacing: 0,
                        fill: '#F8FAFC',
                        stroke: null,
                        strokeWidth: 0,
                      },
                    ],
                  },
                ],
              },
            }
          : {}),
      },
    };

    const createRes = await ownerAgent.post('/api/v1/designs').set(ownerHeaders).send({
      title: 'Dhaka Varsity Crest v1',
      document: canonicalDoc,
    });

    expect(createRes.status).toBe(201);
    const createdDesign = createRes.body.data.design;
    expect(createdDesign.validation.isValidForPrint).toBe(true);
    expect(createdDesign.currentVersionNumber).toBe(1);
    expect(createdDesign.customizedSurfaces).toContain('front');

    // Other customer cannot read or export owner's design (IDOR check)
    const idorRead = await otherAgent.get(`/api/v1/designs/${createdDesign.id}`);
    expect(idorRead.status).toBe(404);

    // 5. Server-side Preview Render (downscaled <= 900px) vs Protected 300 DPI Transparent PNG Print Master
    const previewRes = await ownerAgent.get(
      `/api/v1/designs/${createdDesign.id}/surfaces/front/preview`
    );
    expect(previewRes.status).toBe(200);
    const previewMeta = await sharp(previewRes.body).metadata();
    expect(Math.max(previewMeta.width ?? 0, previewMeta.height ?? 0)).toBeLessThanOrEqual(900);
    expect(previewMeta.hasAlpha).toBe(true);

    const exportRes = await ownerAgent
      .post(`/api/v1/designs/${createdDesign.id}/surfaces/front/export-print-master`)
      .set(ownerHeaders);
    expect(exportRes.status).toBe(201);
    const printExport = exportRes.body.data.printExport;
    expect(printExport.dpi).toBe(frontArea.targetDpi);

    const expectedWidthPx = Math.round((frontArea.physicalWidthMm / 25.4) * frontArea.targetDpi);
    const expectedHeightPx = Math.round((frontArea.physicalHeightMm / 25.4) * frontArea.targetDpi);
    expect(printExport.widthPx).toBe(expectedWidthPx);
    expect(printExport.heightPx).toBe(expectedHeightPx);
    expect(
      storageService
        .listKeys()
        .some((k) => k.startsWith(`private/print-masters/${createdDesign.id}/`))
    ).toBe(true);

    // Other user blocked from protected download; Admin/Staff allowed
    const otherDownload = await otherAgent.get(printExport.downloadUrl);
    expect(otherDownload.status).toBe(404);

    const adminDownload = await adminAgent.get(printExport.downloadUrl);
    expect(adminDownload.status).toBe(200);
    const masterMeta = await sharp(adminDownload.body).metadata();
    expect(masterMeta.width).toBe(expectedWidthPx);
    expect(masterMeta.height).toBe(expectedHeightPx);
    expect(masterMeta.density).toBe(frontArea.targetDpi);
    expect(masterMeta.hasAlpha).toBe(true);

    // 6. Save version 2 + reject out-of-bounds artwork on export
    const updateRes = await ownerAgent
      .put(`/api/v1/designs/${createdDesign.id}`)
      .set(ownerHeaders)
      .send({
        title: 'Dhaka Varsity Crest v2',
        document: createdDesign.document,
        createVersionSnapshot: true,
      });
    expect(updateRes.status).toBe(200);
    expect(updateRes.body.data.design.currentVersionNumber).toBe(2);

    // 7. Add Customized Design to Cart -> Place COD Order -> Snapshot preserved on order_items
    const addToCartRes = await ownerAgent
      .post(`/api/v1/designs/${createdDesign.id}/add-to-cart`)
      .set(ownerHeaders)
      .send({ variantId: variant.id, quantity: 2 });
    expect(addToCartRes.status).toBe(201);

    const cartItem = addToCartRes.body.data.cart.items[0];
    expect(cartItem.designPublicId).toBe(createdDesign.id);
    expect(cartItem.customizationMeta.designTitle).toBe('Dhaka Varsity Crest v2');
    expect(cartItem.customizationMeta.designVersionNumber).toBe(2);

    const orderRes = await ownerAgent
      .post('/api/v1/orders')
      .set(ownerHeaders)
      .send({
        paymentMethod: 'cod',
        shippingAddress: {
          recipientName: 'Amina Rahman',
          phone: '01711223344',
          division: 'Dhaka',
          district: 'Dhaka',
          area: 'Banani',
          addressLine: 'House 12, Road 4, Block B',
        },
      });
    expect(orderRes.status).toBe(201);
    const orderedItem = orderRes.body.data.order.items[0];
    expect(orderedItem.designPublicId).toBe(createdDesign.id);
    expect(orderedItem.designTitle).toBe('Dhaka Varsity Crest v2');
    expect(orderedItem.productionSpec).not.toBeNull();
    expect(orderedItem.productionSpec.surfaces.length).toBeGreaterThanOrEqual(1);
  }, 30_000);
});
