import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const MODELS_DIR = path.resolve(__dirname, '..', '..', 'web', 'public', 'models');

function parseGlbJsonChunk(filePath: string) {
  const buf = fs.readFileSync(filePath);
  expect(buf.readUInt32LE(0)).toBe(0x46546c67); // 'glTF'
  expect(buf.readUInt32LE(4)).toBe(2);
  expect(buf.readUInt32LE(8)).toBe(buf.byteLength);

  const jsonLen = buf.readUInt32LE(12);
  expect(buf.readUInt32LE(16)).toBe(0x4e4f534a); // 'JSON'
  const jsonStr = buf.subarray(20, 20 + jsonLen).toString('utf8');
  return {
    byteLength: buf.byteLength,
    gltf: JSON.parse(jsonStr) as {
      nodes: Array<{ name: string }>;
      meshes: Array<{ name: string }>;
      materials: Array<{ name: string }>;
    },
  };
}

describe('Phase 3 Optimized Garment GLB Binary Assets', () => {
  it('validates crew-tshirt.glb and pique-polo.glb stay < 5MB and expose flat UV print islands', () => {
    const tee = parseGlbJsonChunk(path.join(MODELS_DIR, 'crew-tshirt.glb'));
    expect(tee.byteLength).toBeLessThan(1024 * 1024);
    expect(tee.gltf.meshes.map((m) => m.name)).toEqual(
      expect.arrayContaining(['garment_body', 'garment_collar', 'garment_front', 'garment_back'])
    );

    const polo = parseGlbJsonChunk(path.join(MODELS_DIR, 'pique-polo.glb'));
    expect(polo.byteLength).toBeLessThan(1024 * 1024);
    expect(polo.gltf.meshes.map((m) => m.name)).toEqual(
      expect.arrayContaining([
        'garment_body',
        'garment_collar',
        'garment_buttons',
        'polo_left_chest',
        'garment_back',
      ])
    );
  });
});
