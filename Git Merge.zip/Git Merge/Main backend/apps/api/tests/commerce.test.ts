import { createHmac } from 'node:crypto';
import { INITIAL_PRODUCTS } from '@your-choice/database';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { parseApiEnv } from '../src/config/env.js';
import { createLogger } from '../src/config/logger.js';
import { hashPassword } from '../src/modules/auth/password.js';
import { buildCanonicalWebhookPayload } from '../src/modules/payments/payment.service.js';
import { InMemoryAuditRepository, InMemoryCatalogRepository } from './helpers/in-memory-catalog.js';
import { InMemoryCommerceRepository } from './helpers/in-memory-commerce.js';
import { InMemoryIdentityRepository } from './helpers/in-memory-identity.js';

function createCommerceTestApp(extraEnv?: Record<string, string>) {
  const env = parseApiEnv({
    NODE_ENV: 'test',
    LOG_LEVEL: 'silent',
    CORS_ORIGINS: 'http://localhost:5173',
    SESSION_SECRET: 'test-session-secret-must-be-long-enough-1234',
    SESSION_COOKIE_NAME: 'yc_session',
    CART_COOKIE_NAME: 'yc_cart',
    SESSION_TTL_HOURS: '168',
    CSRF_ENABLED: 'true',
    ...extraEnv,
  });
  const logger = createLogger(env);
  const identityRepository = new InMemoryIdentityRepository();
  const catalogRepository = new InMemoryCatalogRepository(true);
  const commerceRepository = new InMemoryCommerceRepository(catalogRepository);
  const auditRepository = new InMemoryAuditRepository();

  const app = createApp({
    env,
    logger,
    pingDatabase: async () => ({ status: 'up', dialect: 'mariadb', latencyMs: 1.0 }),
    identityRepository,
    catalogRepository,
    commerceRepository,
    auditRepository,
  });

  return {
    app,
    env,
    identityRepository,
    catalogRepository,
    commerceRepository,
    auditRepository,
  };
}

function extractSetCookies(res: request.Response): Record<string, string> {
  const rawSetCookie = res.headers['set-cookie'];
  const headerArray = Array.isArray(rawSetCookie)
    ? rawSetCookie
    : rawSetCookie
      ? [rawSetCookie]
      : [];

  const jar: Record<string, string> = {};
  for (const header of headerArray) {
    const firstPart = header.split(';')[0] ?? '';
    const eqIndex = firstPart.indexOf('=');
    if (eqIndex > 0) {
      const name = firstPart.slice(0, eqIndex).trim();
      const val = decodeURIComponent(firstPart.slice(eqIndex + 1).trim());
      jar[name] = val;
    }
  }
  return jar;
}

function mergeCookieJars(
  current: Record<string, string>,
  res: request.Response
): Record<string, string> {
  return { ...current, ...extractSetCookies(res) };
}

function toCookieHeader(jar: Record<string, string>): string {
  return Object.entries(jar)
    .filter(([, val]) => val !== '')
    .map(([key, val]) => `${key}=${encodeURIComponent(val)}`)
    .join('; ');
}

async function bootstrapCsrf(app: ReturnType<typeof createApp>) {
  const csrfRes = await request(app).get('/api/v1/auth/csrf').expect(200);
  const jar = extractSetCookies(csrfRes);
  return {
    jar,
    csrfToken: csrfRes.body.data.csrfToken as string,
  };
}

async function loginSeededRole(
  app: ReturnType<typeof createApp>,
  identityRepository: InMemoryIdentityRepository,
  email: string,
  roles: ('customer' | 'staff' | 'admin')[]
) {
  const hash = await hashPassword('CommercePass123');
  const created = await identityRepository.createUser({
    publicId: `usr-${roles[0]}-${Math.random().toString(16).slice(2, 10)}`,
    email,
    passwordHash: hash,
    fullName: `${roles[0]} Tester`,
    phone: '+8801711000999',
    preferredLocale: 'en',
    initialRoleCode: roles[0],
  });
  await identityRepository.replaceUserRoles(created.id, roles, created.id);

  const csrf = await bootstrapCsrf(app);
  const loginRes = await request(app)
    .post('/api/v1/auth/login')
    .set('Origin', 'http://localhost:5173')
    .set('Cookie', toCookieHeader(csrf.jar))
    .set('X-CSRF-Token', csrf.csrfToken)
    .send({ email, password: 'CommercePass123', rememberMe: true })
    .expect(200);

  return {
    jar: mergeCookieJars(csrf.jar, loginRes),
    csrfToken: loginRes.body.data.csrfToken as string,
    user: loginRes.body.data.user as { id: string; email: string },
  };
}

describe('Phase 1C Cart, Bangladesh Shipping, Checkout, Payments & Order Lifecycle', () => {
  it('computes Bangladesh shipping quotes accurately with server-side thresholds', async () => {
    const { app } = createCommerceTestApp();

    const zonesRes = await request(app).get('/api/v1/shipping/zones').expect(200);
    expect(zonesRes.body.data.zones).toHaveLength(2);

    const dhakaPaid = await request(app)
      .get('/api/v1/shipping/quote?division=Dhaka&subtotal=1500.00')
      .expect(200);
    expect(dhakaPaid.body.data.quote.shippingFee).toBe('70.00');
    expect(dhakaPaid.body.data.quote.freeShippingQualified).toBe(false);
    expect(dhakaPaid.body.data.quote.amountRemainingForFreeShipping).toBe('1000.00');
    expect(dhakaPaid.body.data.quote.estimatedTotal).toBe('1570.00');

    const dhakaFree = await request(app)
      .get('/api/v1/shipping/quote?division=Dhaka&subtotal=2500.00')
      .expect(200);
    expect(dhakaFree.body.data.quote.shippingFee).toBe('0.00');
    expect(dhakaFree.body.data.quote.freeShippingQualified).toBe(true);

    const ctgPaid = await request(app)
      .get('/api/v1/shipping/quote?division=Chattogram&subtotal=2600.00')
      .expect(200);
    expect(ctgPaid.body.data.quote.shippingFee).toBe('130.00');
    expect(ctgPaid.body.data.quote.amountRemainingForFreeShipping).toBe('400.00');
  });

  it('persists guest carts in HttpOnly cookies and merges them cleanly on customer login', async () => {
    const { app, identityRepository } = createCommerceTestApp();
    const variant = INITIAL_PRODUCTS[0]!.variants[0]!;

    const csrf = await bootstrapCsrf(app);
    const addGuestRes = await request(app)
      .post('/api/v1/cart/items')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(csrf.jar))
      .set('X-CSRF-Token', csrf.csrfToken)
      .send({ variantId: variant.publicId, quantity: 2 })
      .expect(201);

    expect(addGuestRes.body.data.cart.itemCount).toBe(2);
    const guestJar = mergeCookieJars(csrf.jar, addGuestRes);
    expect(guestJar.yc_cart).toBeTruthy();

    // Seed an account & login while carrying the yc_cart guest cookie
    const hash = await hashPassword('MergePass123');
    await identityRepository.createUser({
      publicId: 'usr-merge-1',
      email: 'merge@example.com',
      passwordHash: hash,
      fullName: 'Nadia Chowdhury',
      phone: '+8801712345678',
      preferredLocale: 'en',
      initialRoleCode: 'customer',
    });

    const loginRes = await request(app)
      .post('/api/v1/auth/login')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(guestJar))
      .set('X-CSRF-Token', csrf.csrfToken)
      .send({ email: 'merge@example.com', password: 'MergePass123', rememberMe: true })
      .expect(200);

    const authedJar = mergeCookieJars(guestJar, loginRes);
    const authedCartRes = await request(app)
      .get('/api/v1/cart')
      .set('Cookie', toCookieHeader(authedJar))
      .expect(200);

    expect(authedCartRes.body.data.cart.itemCount).toBe(2);
    expect(authedCartRes.body.data.cart.items[0].variantId).toBe(variant.publicId);
  });

  it('enforces honest gateway availability and rejects unconfigured bKash/Nagad/SSLCommerz checkouts', async () => {
    const { app } = createCommerceTestApp();
    const variant = INITIAL_PRODUCTS[0]!.variants[0]!;

    const optionsRes = await request(app).get('/api/v1/checkout/options').expect(200);
    const providers = optionsRes.body.data.paymentProviders as Array<{
      method: string;
      enabled: boolean;
      configured: boolean;
    }>;
    expect(providers.find((p) => p.method === 'cod')).toMatchObject({
      enabled: true,
      configured: true,
    });
    expect(providers.find((p) => p.method === 'bkash')).toMatchObject({
      enabled: false,
      configured: false,
    });
    expect(providers.find((p) => p.method === 'nagad')).toMatchObject({
      enabled: false,
      configured: false,
    });

    const csrf = await bootstrapCsrf(app);
    const addRes = await request(app)
      .post('/api/v1/cart/items')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(csrf.jar))
      .set('X-CSRF-Token', csrf.csrfToken)
      .send({ variantId: variant.publicId, quantity: 1 })
      .expect(201);

    const jar = mergeCookieJars(csrf.jar, addRes);
    const failRes = await request(app)
      .post('/api/v1/orders')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(jar))
      .set('X-CSRF-Token', csrf.csrfToken)
      .send({
        customerEmail: 'buyer@example.com',
        customerPhone: '+8801712345678',
        paymentMethod: 'bkash',
        shippingAddress: {
          recipientName: 'Kamrul Hasan',
          phone: '+8801712345678',
          division: 'Dhaka',
          district: 'Dhaka',
          area: 'Uttara',
          addressLine: 'Sector 7, Road 12, House 8',
        },
      })
      .expect(400);

    expect(failRes.body.error.code).toBe('PAYMENT_PROVIDER_NOT_CONFIGURED');
  });

  it('processes COD checkout transactionally, protects guest order lookup, preserves snapshots, and handles self-cancel & admin transitions', async () => {
    const { app, identityRepository, catalogRepository } = createCommerceTestApp();
    const targetProduct = INITIAL_PRODUCTS[0]!;
    const targetVariant = targetProduct.variants[0]!;
    const startingStock = targetVariant.stockQuantity;

    // 1. Guest checkout with COD
    const csrf = await bootstrapCsrf(app);
    const addGuest = await request(app)
      .post('/api/v1/cart/items')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(csrf.jar))
      .set('X-CSRF-Token', csrf.csrfToken)
      .send({ variantId: targetVariant.publicId, quantity: 2 })
      .expect(201);

    const guestJar = mergeCookieJars(csrf.jar, addGuest);
    const guestOrderRes = await request(app)
      .post('/api/v1/orders')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(guestJar))
      .set('X-CSRF-Token', csrf.csrfToken)
      .send({
        customerEmail: 'guest.buyer@example.com',
        customerPhone: '+8801812345678',
        paymentMethod: 'cod',
        shippingAddress: {
          recipientName: 'Sadia Afrin',
          phone: '+8801812345678',
          division: 'Dhaka',
          district: 'Dhaka',
          area: 'Mirpur',
          addressLine: 'Section 10, Block C, House 14',
        },
      })
      .expect(201);

    const guestOrder = guestOrderRes.body.data.order;
    expect(guestOrder.orderStatus).toBe('pending');
    expect(guestOrder.paymentMethod).toBe('cod');
    expect(guestOrder.paymentStatus).toBe('unpaid');
    expect(guestOrder.items).toHaveLength(1);
    expect(guestOrder.items[0].productNameEn).toBe(targetProduct.nameEn);
    const guestReceiptJar = mergeCookieJars(guestJar, guestOrderRes);
    expect(guestReceiptJar.yc_order_receipt).toBeTruthy();

    // Anonymous lookup without receipt cookie must fail (401); lookup with receipt cookie succeeds (200)
    await request(app).get(`/api/v1/orders/${guestOrder.orderNumber}`).expect(401);
    const receiptLookup = await request(app)
      .get(`/api/v1/orders/${guestOrder.orderNumber}`)
      .set('Cookie', toCookieHeader(guestReceiptJar))
      .expect(200);
    expect(receiptLookup.body.data.order.orderNumber).toBe(guestOrder.orderNumber);

    // Stock decremented atomically
    const refAfterOrder = catalogRepository.getInternalProductVariantsForCommerce(
      targetVariant.publicId
    );
    expect(refAfterOrder?.variant.stockQuantity).toBe(startingStock - 2);

    // Mutate catalog product title & price: stored order snapshot MUST remain unchanged
    const originalUnitPrice = guestOrder.items[0].unitPrice;
    refAfterOrder!.product.nameEn = 'MUTATED PRODUCT NAME v2';
    refAfterOrder!.product.basePrice = '9999.00';

    const snapshotCheck = await request(app)
      .get(`/api/v1/orders/${guestOrder.orderNumber}`)
      .set('Cookie', toCookieHeader(guestReceiptJar))
      .expect(200);
    expect(snapshotCheck.body.data.order.items[0].productNameEn).toBe(targetProduct.nameEn);
    expect(snapshotCheck.body.data.order.items[0].unitPrice).toBe(originalUnitPrice);

    // Restore product price/name for clean follow-up test
    refAfterOrder!.product.nameEn = targetProduct.nameEn;
    refAfterOrder!.product.basePrice = targetProduct.basePrice;

    // 2. Customer checkout -> oversell block -> cancel -> stock restoration -> RBAC admin fulfillment
    const customer = await loginSeededRole(app, identityRepository, 'cust.flow@example.com', [
      'customer',
    ]);
    const staff = await loginSeededRole(app, identityRepository, 'staff.flow@example.com', [
      'staff',
    ]);

    // Exceed remaining stock
    const oversellRes = await request(app)
      .post('/api/v1/cart/items')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(customer.jar))
      .set('X-CSRF-Token', customer.csrfToken)
      .send({ variantId: targetVariant.publicId, quantity: 49 })
      .expect(409);
    expect(oversellRes.body.error.code).toBe('INSUFFICIENT_STOCK');

    // Add valid quantity 3 -> checkout -> cancel
    await request(app)
      .post('/api/v1/cart/items')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(customer.jar))
      .set('X-CSRF-Token', customer.csrfToken)
      .send({ variantId: targetVariant.publicId, quantity: 3 })
      .expect(201);

    const custOrderRes = await request(app)
      .post('/api/v1/orders')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(customer.jar))
      .set('X-CSRF-Token', customer.csrfToken)
      .send({
        paymentMethod: 'cod',
        shippingAddress: {
          recipientName: 'Ariful Islam',
          phone: '+8801712000111',
          division: 'Chattogram',
          district: 'Chattogram',
          area: 'Nasirabad',
          addressLine: 'Road 3, Block B, House 19',
        },
      })
      .expect(201);

    const custOrderNo = custOrderRes.body.data.order.orderNumber as string;
    expect(refAfterOrder?.variant.stockQuantity).toBe(startingStock - 5);

    // Customer cannot access admin order list
    await request(app)
      .get('/api/v1/admin/orders')
      .set('Cookie', toCookieHeader(customer.jar))
      .expect(403);

    // Customer cancels pending order -> stock restores by 3
    const cancelRes = await request(app)
      .post(`/api/v1/orders/${custOrderNo}/cancel`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(customer.jar))
      .set('X-CSRF-Token', customer.csrfToken)
      .send({ reason: 'Ordered wrong size' })
      .expect(200);
    expect(cancelRes.body.data.order.orderStatus).toBe('cancelled');
    expect(refAfterOrder?.variant.stockQuantity).toBe(startingStock - 2);

    // Staff settles COD and moves guest order through confirmed -> processing; customer cannot touch guest order
    await request(app)
      .patch(`/api/v1/admin/orders/${guestOrder.orderNumber}/status`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(staff.jar))
      .set('X-CSRF-Token', staff.csrfToken)
      .send({ toStatus: 'confirmed', note: 'Phone verified' })
      .expect(200);

    await request(app)
      .patch(`/api/v1/admin/orders/${guestOrder.orderNumber}/status`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(staff.jar))
      .set('X-CSRF-Token', staff.csrfToken)
      .send({ toStatus: 'processing' })
      .expect(200);

    const settledRes = await request(app)
      .post(`/api/v1/admin/orders/${guestOrder.orderNumber}/payment-settlement`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(staff.jar))
      .set('X-CSRF-Token', staff.csrfToken)
      .send({ transactionRef: 'STEADFAST-POD-7712', note: 'Cash collected by rider' })
      .expect(200);

    expect(settledRes.body.data.order.paymentStatus).toBe('paid');
    expect(settledRes.body.data.order.statusHistory.length).toBeGreaterThanOrEqual(4);
  });

  it('verifies HMAC webhooks for configured gateways, rejects tampering, and handles idempotent replay', async () => {
    const bkashSecret = 'test-bkash-webhook-secret-98765';
    const { app } = createCommerceTestApp({
      BKASH_WEBHOOK_SECRET: bkashSecret,
    });
    const variant = INITIAL_PRODUCTS[0]!.variants[0]!;

    const csrf = await bootstrapCsrf(app);
    const addRes = await request(app)
      .post('/api/v1/cart/items')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(csrf.jar))
      .set('X-CSRF-Token', csrf.csrfToken)
      .send({ variantId: variant.publicId, quantity: 1 })
      .expect(201);

    const jar = mergeCookieJars(csrf.jar, addRes);
    const orderRes = await request(app)
      .post('/api/v1/orders')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', toCookieHeader(jar))
      .set('X-CSRF-Token', csrf.csrfToken)
      .send({
        customerEmail: 'bkash.payer@example.com',
        customerPhone: '+8801719998887',
        paymentMethod: 'bkash',
        shippingAddress: {
          recipientName: 'Farhana Yasmin',
          phone: '+8801719998887',
          division: 'Dhaka',
          district: 'Dhaka',
          area: 'Gulshan',
          addressLine: 'Road 71, House 4',
        },
      })
      .expect(201);

    const createdOrder = orderRes.body.data.order;
    const validPayload = {
      orderNumber: createdOrder.orderNumber as string,
      providerPaymentId: 'BKPAY-001122',
      transactionRef: 'TRX909090',
      status: 'paid' as const,
      amount: createdOrder.totalAmount as string,
      currencyCode: 'BDT',
    };
    const validSig = createHmac('sha256', bkashSecret)
      .update(buildCanonicalWebhookPayload(validPayload), 'utf8')
      .digest('hex');

    // Invalid signature -> 401
    await request(app)
      .post('/api/v1/payments/webhooks/bkash')
      .set('X-Webhook-Signature', 'deadbeef'.repeat(8))
      .send(validPayload)
      .expect(401);

    // Valid signature but tampered amount -> 409
    const tamperedPayload = { ...validPayload, amount: '1.00' };
    const tamperedSig = createHmac('sha256', bkashSecret)
      .update(buildCanonicalWebhookPayload(tamperedPayload), 'utf8')
      .digest('hex');
    const mismatchRes = await request(app)
      .post('/api/v1/payments/webhooks/bkash')
      .set('X-Webhook-Signature', tamperedSig)
      .send(tamperedPayload)
      .expect(409);
    expect(mismatchRes.body.error.code).toBe('WEBHOOK_AMOUNT_MISMATCH');

    // Valid webhook -> marks order paid + confirmed
    const okRes = await request(app)
      .post('/api/v1/payments/webhooks/bkash')
      .set('X-Webhook-Signature', validSig)
      .send(validPayload)
      .expect(200);
    expect(okRes.body.data.paymentStatus).toBe('paid');
    expect(okRes.body.data.orderStatus).toBe('confirmed');
    expect(okRes.body.data.idempotentReplay).toBe(false);

    // Duplicate replay -> 200 idempotentReplay: true
    const replayRes = await request(app)
      .post('/api/v1/payments/webhooks/bkash')
      .set('X-Webhook-Signature', validSig)
      .send(validPayload)
      .expect(200);
    expect(replayRes.body.data.idempotentReplay).toBe(true);
  });
});
