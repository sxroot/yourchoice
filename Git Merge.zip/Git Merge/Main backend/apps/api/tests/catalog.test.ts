import { INITIAL_CATEGORIES } from '@your-choice/database';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { parseApiEnv } from '../src/config/env.js';
import { createLogger } from '../src/config/logger.js';
import { hashPassword } from '../src/modules/auth/password.js';
import { InMemoryAuditRepository, InMemoryCatalogRepository } from './helpers/in-memory-catalog.js';
import { InMemoryIdentityRepository } from './helpers/in-memory-identity.js';

function createCatalogTestApp() {
  const env = parseApiEnv({
    NODE_ENV: 'test',
    LOG_LEVEL: 'silent',
    CORS_ORIGINS: 'http://localhost:5173',
    SESSION_SECRET: 'test-session-secret-must-be-long-enough-1234',
    SESSION_COOKIE_NAME: 'yc_session',
    SESSION_TTL_HOURS: '168',
    CSRF_ENABLED: 'true',
  });
  const logger = createLogger(env);
  const identityRepository = new InMemoryIdentityRepository();
  const catalogRepository = new InMemoryCatalogRepository(true);
  const auditRepository = new InMemoryAuditRepository();

  const app = createApp({
    env,
    logger,
    pingDatabase: async () => ({ status: 'up', dialect: 'mariadb', latencyMs: 1.0 }),
    identityRepository,
    catalogRepository,
    auditRepository,
  });

  return { app, identityRepository, catalogRepository, auditRepository };
}

function extractSetCookies(res: request.Response): Record<string, string> {
  const rawSetCookie = res.headers['set-cookie'];
  const headerArray = Array.isArray(rawSetCookie)
    ? rawSetCookie
    : rawSetCookie
      ? [rawSetCookie]
      : [];

  const jar: Record<string, string> = {};
  for (const header of headerArray) {
    const firstPart = header.split(';')[0] ?? '';
    const eqIndex = firstPart.indexOf('=');
    if (eqIndex > 0) {
      const name = firstPart.slice(0, eqIndex).trim();
      const val = decodeURIComponent(firstPart.slice(eqIndex + 1).trim());
      jar[name] = val;
    }
  }
  return jar;
}

async function loginAsSeededUser(
  app: ReturnType<typeof createApp>,
  identityRepository: InMemoryIdentityRepository,
  email: string,
  roles: ('customer' | 'creator' | 'staff' | 'admin' | 'super_admin')[]
) {
  const hash = await hashPassword('AdminPass123');
  const created = await identityRepository.createUser({
    publicId: `usr-${roles[0]}-${Math.random().toString(16).slice(2, 10)}`,
    email,
    passwordHash: hash,
    fullName: `${roles[0]} User`,
    phone: null,
    preferredLocale: 'en',
    initialRoleCode: roles[0],
  });
  await identityRepository.replaceUserRoles(created.id, roles, created.id);

  const csrfRes = await request(app).get('/api/v1/auth/csrf').expect(200);
  const csrfCookies = extractSetCookies(csrfRes);
  const csrfToken = csrfRes.body.data.csrfToken as string;

  const loginRes = await request(app)
    .post('/api/v1/auth/login')
    .set('Origin', 'http://localhost:5173')
    .set('Cookie', [`yc_csrf=${encodeURIComponent(csrfCookies.yc_csrf ?? '')}`])
    .set('X-CSRF-Token', csrfToken)
    .send({ email, password: 'AdminPass123', rememberMe: true })
    .expect(200);

  const loginCookies = extractSetCookies(loginRes);
  const activeCsrf = loginRes.body.data.csrfToken as string;
  return {
    cookieHeader: [
      `yc_csrf=${encodeURIComponent(activeCsrf)}`,
      `yc_session=${encodeURIComponent(loginCookies.yc_session ?? '')}`,
    ].join('; '),
    csrfToken: activeCsrf,
  };
}

describe('Phase 1B Apparel Catalog, Print Areas & Admin Authorization', () => {
  it('serves public categories, filtered apparel products, and editor-agnostic print areas', async () => {
    const { app } = createCatalogTestApp();

    const categoriesRes = await request(app).get('/api/v1/categories').expect(200);
    expect(categoriesRes.body.data.categories).toHaveLength(2);
    expect(categoriesRes.body.data.categories.map((c: { slug: string }) => c.slug)).toEqual([
      't-shirts',
      'polo-shirts',
    ]);

    const poloProductsRes = await request(app)
      .get('/api/v1/products?category=polo-shirts&sort=price_desc')
      .expect(200);
    expect(poloProductsRes.body.data.products).toHaveLength(2);
    expect(poloProductsRes.body.data.products[0].basePrice).toBe('1390.00');

    const detailRes = await request(app).get('/api/v1/products/executive-knit-polo').expect(200);
    const polo = detailRes.body.data.product;
    expect(polo.nameEn).toBe('Executive Combed Pique Polo Shirt');
    expect(polo.variants.length).toBeGreaterThanOrEqual(3);
    expect(polo.printAreas).toHaveLength(2);
    expect(polo.printAreas[0]).toMatchObject({
      surfaceKey: 'left_chest',
      coordinateSpace: 'normalized_0_1',
      targetDpi: 300,
    });
    expect(polo.printAreas[0].uvRegion).toHaveProperty('islandKey', 'polo_left_chest');
  });

  it('enforces RBAC on admin catalog endpoints and blocks unauthorized mutations', async () => {
    const { app, identityRepository } = createCatalogTestApp();
    const customer = await loginAsSeededUser(app, identityRepository, 'shopper@example.com', [
      'customer',
    ]);
    const staff = await loginAsSeededUser(app, identityRepository, 'staff@example.com', ['staff']);

    await request(app)
      .get('/api/v1/admin/products')
      .set('Cookie', customer.cookieHeader)
      .expect(403);

    // Staff has catalog:read but not catalog:write
    await request(app).get('/api/v1/admin/products').set('Cookie', staff.cookieHeader).expect(200);

    await request(app)
      .post('/api/v1/admin/products')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', staff.cookieHeader)
      .set('X-CSRF-Token', staff.csrfToken)
      .send({
        categoryId: INITIAL_CATEGORIES[0]!.publicId,
        slug: 'blocked-tee',
        skuPrefix: 'YC-BLK',
        nameEn: 'Blocked Tee',
        nameBn: 'ব্লকড টি-শার্ট',
        descriptionEn: 'Should be rejected for staff role without catalog write permission.',
        descriptionBn: 'ক্যাটালগ রাইট পারমিশন ছাড়া এটি অনুমোদিত নয়।',
        basePrice: '650.00',
      })
      .expect(403);
  });

  it('supports admin draft -> variant + print area setup -> publish workflow while hiding drafts publicly', async () => {
    const { app, identityRepository, auditRepository } = createCatalogTestApp();
    const admin = await loginAsSeededUser(
      app,
      identityRepository,
      'catalog-admin@allyourchoice.com',
      ['admin']
    );

    // 1. Create draft product without variants first
    const createRes = await request(app)
      .post('/api/v1/admin/products')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', admin.cookieHeader)
      .set('X-CSRF-Token', admin.csrfToken)
      .send({
        categoryId: INITIAL_CATEGORIES[0]!.publicId,
        slug: 'studio-raglan-tee',
        skuPrefix: 'YC-RGL',
        nameEn: 'Studio Contrast Raglan Tee',
        nameBn: 'স্টুডিও কনট্রাস্ট র‍্যাগল্যান টি-শার্ট',
        subtitleEn: 'Two-tone sleeve performance blank',
        subtitleBn: 'টু-টোন স্লিভ স্টুডিও ব্ল্যাঙ্ক',
        descriptionEn: 'Constructed for multi-zone creator graphic drops in 210 GSM cotton.',
        descriptionBn: '২১০ জিএসএম কটনে তৈরি মাল্টি-জোন কাস্টম টি-শার্ট।',
        gsm: 210,
        fitType: 'Athletic Fit',
        basePrice: '880.00',
        isCustomizable: true,
        status: 'draft',
      })
      .expect(201);

    const productId = createRes.body.data.product.id as string;

    // Draft product must NOT be visible on public /products/:slug
    await request(app).get('/api/v1/products/studio-raglan-tee').expect(404);

    // Cannot publish while zero active variants exist
    const noVariantPublish = await request(app)
      .patch(`/api/v1/admin/products/${productId}`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', admin.cookieHeader)
      .set('X-CSRF-Token', admin.csrfToken)
      .send({ status: 'active' })
      .expect(400);
    expect(noVariantPublish.body.error.code).toBe('CATALOG_PUBLISH_REQUIRES_VARIANT');

    // Add variant (size/color/SKU/stock + price override)
    await request(app)
      .post(`/api/v1/admin/products/${productId}/variants`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', admin.cookieHeader)
      .set('X-CSRF-Token', admin.csrfToken)
      .send({
        sku: 'YC-RGL-BLK-M',
        colorNameEn: 'Obsidian Black',
        colorNameBn: 'কালো',
        colorHex: '#0F172A',
        sizeCode: 'M',
        priceOverride: '910.00',
        stockQuantity: 35,
      })
      .expect(201);

    // Duplicate SKU returns 409 Conflict
    await request(app)
      .post(`/api/v1/admin/products/${productId}/variants`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', admin.cookieHeader)
      .set('X-CSRF-Token', admin.csrfToken)
      .send({
        sku: 'YC-RGL-BLK-M',
        colorNameEn: 'Duplicate',
        colorNameBn: 'ডুপ্লিকেট',
        colorHex: '#0F172A',
        sizeCode: 'L',
        stockQuantity: 10,
      })
      .expect(409);

    // Customizable product still requires at least one print area before publishing
    const noPrintAreaPublish = await request(app)
      .patch(`/api/v1/admin/products/${productId}`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', admin.cookieHeader)
      .set('X-CSRF-Token', admin.csrfToken)
      .send({ status: 'active' })
      .expect(400);
    expect(noPrintAreaPublish.body.error.code).toBe('CATALOG_PUBLISH_REQUIRES_PRINT_AREA');

    // Configure front print area
    await request(app)
      .put(`/api/v1/admin/products/${productId}/print-areas`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', admin.cookieHeader)
      .set('X-CSRF-Token', admin.csrfToken)
      .send({
        surfaceKey: 'front',
        labelEn: 'Front Chest Zone',
        labelBn: 'সামনের চেস্ট জোন',
        physicalWidthMm: 280,
        physicalHeightMm: 350,
        targetDpi: 300,
        safeInsetMm: 10,
        mockupBounds: { x: 0.31, y: 0.25, width: 0.38, height: 0.48, rotationDeg: 0 },
        printMethods: ['dtf', 'screen_print'],
        surchargeAmount: '150.00',
        isDefault: true,
        isActive: true,
      })
      .expect(200);

    // Now publish succeeds
    await request(app)
      .patch(`/api/v1/admin/products/${productId}`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', admin.cookieHeader)
      .set('X-CSRF-Token', admin.csrfToken)
      .send({ status: 'active' })
      .expect(200);

    // Immediately resolves via public storefront detail endpoint
    const publishedRes = await request(app).get('/api/v1/products/studio-raglan-tee').expect(200);
    expect(publishedRes.body.data.product.variants[0].effectivePrice).toBe('910.00');
    expect(publishedRes.body.data.product.printAreas).toHaveLength(1);
    expect(auditRepository.entries.map((e) => e.action)).toContain('catalog.product.updated');
  });
});
