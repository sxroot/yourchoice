import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { parseApiEnv } from '../src/config/env.js';
import { createLogger } from '../src/config/logger.js';
import { InMemoryAddressRepository } from './helpers/in-memory-catalog.js';
import { InMemoryIdentityRepository } from './helpers/in-memory-identity.js';

function createAddressTestApp() {
  const env = parseApiEnv({
    NODE_ENV: 'test',
    LOG_LEVEL: 'silent',
    CORS_ORIGINS: 'http://localhost:5173',
    SESSION_SECRET: 'test-session-secret-must-be-long-enough-1234',
    SESSION_COOKIE_NAME: 'yc_session',
    SESSION_TTL_HOURS: '168',
    CSRF_ENABLED: 'true',
  });
  const logger = createLogger(env);
  const identityRepository = new InMemoryIdentityRepository();
  const addressRepository = new InMemoryAddressRepository();

  const app = createApp({
    env,
    logger,
    pingDatabase: async () => ({ status: 'up', dialect: 'mariadb', latencyMs: 1.0 }),
    identityRepository,
    addressRepository,
  });

  return { app };
}

function extractSetCookies(res: request.Response): Record<string, string> {
  const rawSetCookie = res.headers['set-cookie'];
  const headerArray = Array.isArray(rawSetCookie)
    ? rawSetCookie
    : rawSetCookie
      ? [rawSetCookie]
      : [];

  const jar: Record<string, string> = {};
  for (const header of headerArray) {
    const firstPart = header.split(';')[0] ?? '';
    const eqIndex = firstPart.indexOf('=');
    if (eqIndex > 0) {
      const name = firstPart.slice(0, eqIndex).trim();
      const val = decodeURIComponent(firstPart.slice(eqIndex + 1).trim());
      jar[name] = val;
    }
  }
  return jar;
}

async function registerCustomerSession(
  app: ReturnType<typeof createApp>,
  email: string,
  fullName: string
) {
  const csrfRes = await request(app).get('/api/v1/auth/csrf').expect(200);
  const csrfCookies = extractSetCookies(csrfRes);
  const csrfToken = csrfRes.body.data.csrfToken as string;

  const regRes = await request(app)
    .post('/api/v1/auth/register')
    .set('Origin', 'http://localhost:5173')
    .set('Cookie', [`yc_csrf=${encodeURIComponent(csrfCookies.yc_csrf ?? '')}`])
    .set('X-CSRF-Token', csrfToken)
    .send({
      fullName,
      email,
      password: 'Password123',
      confirmPassword: 'Password123',
    })
    .expect(201);

  const regCookies = extractSetCookies(regRes);
  const activeCsrf = regRes.body.data.csrfToken as string;
  const cookieHeader = [
    `yc_csrf=${encodeURIComponent(activeCsrf)}`,
    `yc_session=${encodeURIComponent(regCookies.yc_session ?? '')}`,
  ].join('; ');

  return { cookieHeader, csrfToken: activeCsrf };
}

describe('Phase 1B Customer Address Management', () => {
  it('blocks unauthenticated access and invalid Bangladesh divisions cleanly', async () => {
    const { app } = createAddressTestApp();

    const unauth = await request(app).get('/api/v1/users/me/addresses').expect(401);
    expect(unauth.body.error.code).toBe('UNAUTHORIZED');

    const session = await registerCustomerSession(app, 'customer1@example.com', 'Sadia Rahman');

    await request(app)
      .post('/api/v1/users/me/addresses')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', session.cookieHeader)
      .set('X-CSRF-Token', session.csrfToken)
      .send({
        label: 'Home',
        recipientName: 'Sadia Rahman',
        phone: '+8801712345678',
        division: 'UnknownDivision',
        district: 'Dhaka',
        area: 'Dhanmondi',
        addressLine: 'House 12, Road 6',
      })
      .expect(400);
  });

  it('supports CRUD, auto-defaulting, default switching, promotion on delete, and strict IDOR isolation', async () => {
    const { app } = createAddressTestApp();
    const customerA = await registerCustomerSession(app, 'a@example.com', 'Customer A');
    const customerB = await registerCustomerSession(app, 'b@example.com', 'Customer B');

    // First address automatically becomes default
    const firstRes = await request(app)
      .post('/api/v1/users/me/addresses')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', customerA.cookieHeader)
      .set('X-CSRF-Token', customerA.csrfToken)
      .send({
        label: 'Home',
        recipientName: 'Customer A',
        phone: '+8801711111111',
        division: 'Dhaka',
        district: 'Dhaka',
        area: 'Uttara Sector 7',
        addressLine: 'House 19, Road 4',
        postalCode: '1230',
        isDefault: false,
      })
      .expect(201);

    const firstId = firstRes.body.data.address.id as string;
    expect(firstRes.body.data.address.isDefault).toBe(true);

    // Second address set as default switches default away from first
    const secondRes = await request(app)
      .post('/api/v1/users/me/addresses')
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', customerA.cookieHeader)
      .set('X-CSRF-Token', customerA.csrfToken)
      .send({
        label: 'Studio Office',
        recipientName: 'Customer A',
        phone: '+8801822222222',
        division: 'Chattogram',
        district: 'Chattogram',
        area: 'Nasirabad',
        addressLine: 'Suite 4B, CDA Avenue',
        isDefault: true,
      })
      .expect(201);

    const secondId = secondRes.body.data.address.id as string;
    expect(secondRes.body.data.address.isDefault).toBe(true);

    const listRes = await request(app)
      .get('/api/v1/users/me/addresses')
      .set('Cookie', customerA.cookieHeader)
      .expect(200);
    expect(listRes.body.data.addresses).toHaveLength(2);
    expect(listRes.body.data.addresses[0].id).toBe(secondId);
    expect(listRes.body.data.addresses[1].isDefault).toBe(false);

    // Customer B cannot read, modify, or delete Customer A's address (IDOR -> 404)
    await request(app)
      .patch(`/api/v1/users/me/addresses/${secondId}`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', customerB.cookieHeader)
      .set('X-CSRF-Token', customerB.csrfToken)
      .send({ area: 'Hijacked Area' })
      .expect(404);

    await request(app)
      .delete(`/api/v1/users/me/addresses/${secondId}`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', customerB.cookieHeader)
      .set('X-CSRF-Token', customerB.csrfToken)
      .expect(404);

    // Deleting current default automatically promotes remaining address
    await request(app)
      .delete(`/api/v1/users/me/addresses/${secondId}`)
      .set('Origin', 'http://localhost:5173')
      .set('Cookie', customerA.cookieHeader)
      .set('X-CSRF-Token', customerA.csrfToken)
      .expect(200);

    const afterDeleteRes = await request(app)
      .get('/api/v1/users/me/addresses')
      .set('Cookie', customerA.cookieHeader)
      .expect(200);

    expect(afterDeleteRes.body.data.addresses).toHaveLength(1);
    expect(afterDeleteRes.body.data.addresses[0].id).toBe(firstId);
    expect(afterDeleteRes.body.data.addresses[0].isDefault).toBe(true);
  });
});
