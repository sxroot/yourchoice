import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  DEFAULT_PERMISSIONS,
  DEFAULT_ROLES,
  resolvePermissionsForRoles,
} from '@your-choice/database';
import * as schema from '@your-choice/database/schema';
import { getTableName } from 'drizzle-orm';
import { describe, expect, it } from 'vitest';

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(currentDir, '../../..');

describe('Identity & RBAC Database Schema + Migrations', () => {
  it('defines all required Phase 1A identity & RBAC Drizzle tables', () => {
    expect(getTableName(schema.users)).toBe('users');
    expect(getTableName(schema.userProfiles)).toBe('user_profiles');
    expect(getTableName(schema.roles)).toBe('roles');
    expect(getTableName(schema.permissions)).toBe('permissions');
    expect(getTableName(schema.rolePermissions)).toBe('role_permissions');
    expect(getTableName(schema.userRoles)).toBe('user_roles');
    expect(getTableName(schema.sessions)).toBe('sessions');
    expect(getTableName(schema.userAddresses)).toBe('user_addresses');
    expect(getTableName(schema.productCategories)).toBe('product_categories');
    expect(getTableName(schema.products)).toBe('products');
    expect(getTableName(schema.productVariants)).toBe('product_variants');
    expect(getTableName(schema.productImages)).toBe('product_images');
    expect(getTableName(schema.productPrintAreas)).toBe('product_print_areas');
    expect(getTableName(schema.auditLogs)).toBe('audit_logs');
  });

  it('ships valid MariaDB 10.11+ DDL migration SQL for identity & RBAC', () => {
    const migrationSqlPath = path.join(repoRoot, 'database/migrations/0001_unknown_romulus.sql');
    expect(fs.existsSync(migrationSqlPath)).toBe(true);

    const sql = fs.readFileSync(migrationSqlPath, 'utf8');
    for (const table of [
      'CREATE TABLE `users`',
      'CREATE TABLE `user_profiles`',
      'CREATE TABLE `roles`',
      'CREATE TABLE `permissions`',
      'CREATE TABLE `role_permissions`',
      'CREATE TABLE `user_roles`',
      'CREATE TABLE `sessions`',
    ]) {
      expect(sql).toContain(table);
    }

    expect(sql).toContain('CONSTRAINT `uq_users_public_id` UNIQUE(`public_id`)');
    expect(sql).toContain('CONSTRAINT `uq_users_email` UNIQUE(`email`)');
    expect(sql).toContain('CONSTRAINT `uq_sessions_token_hash` UNIQUE(`token_hash`)');
    expect(sql).toContain('datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)');
  });

  it('ships valid MariaDB 10.11+ DDL migration SQL for addresses, apparel catalog & print areas', () => {
    const migrationSqlPath = path.join(repoRoot, 'database/migrations/0002_tidy_silverclaw.sql');
    expect(fs.existsSync(migrationSqlPath)).toBe(true);

    const sql = fs.readFileSync(migrationSqlPath, 'utf8');
    for (const table of [
      'CREATE TABLE `user_addresses`',
      'CREATE TABLE `product_categories`',
      'CREATE TABLE `products`',
      'CREATE TABLE `product_variants`',
      'CREATE TABLE `product_images`',
      'CREATE TABLE `product_print_areas`',
      'CREATE TABLE `audit_logs`',
    ]) {
      expect(sql).toContain(table);
    }

    expect(sql).toContain('CONSTRAINT `uq_product_variants_sku` UNIQUE(`sku`)');
    expect(sql).toContain(
      'CONSTRAINT `uq_product_print_areas_product_surface` UNIQUE(`product_id`,`surface_key`)'
    );
    expect(sql).toContain('decimal(12,2)');
  });

  it('resolves effective permissions across single and multi-role assignments', () => {
    expect(DEFAULT_ROLES.map((r) => r.code)).toEqual([
      'guest',
      'customer',
      'creator',
      'staff',
      'admin',
      'super_admin',
    ]);

    const customerPerms = resolvePermissionsForRoles(['customer']);
    expect(customerPerms).toContain('profile:read:own');
    expect(customerPerms).not.toContain('creator:studio:access');

    const superAdminPerms = resolvePermissionsForRoles(['super_admin']);
    expect(superAdminPerms).toHaveLength(DEFAULT_PERMISSIONS.length);
  });

  it('defines Phase 1C commerce tables, shipping seeds, and SQL constraints', async () => {
    expect(getTableName(schema.shippingZones)).toBe('shipping_zones');
    expect(getTableName(schema.carts)).toBe('carts');
    expect(getTableName(schema.cartItems)).toBe('cart_items');
    expect(getTableName(schema.orders)).toBe('orders');
    expect(getTableName(schema.orderItems)).toBe('order_items');
    expect(getTableName(schema.orderStatusHistory)).toBe('order_status_history');
    expect(getTableName(schema.paymentTransactions)).toBe('payment_transactions');

    const dbPkg = await import('@your-choice/database');
    expect(dbPkg.SHIPPING_ZONE_SEED_DATA).toHaveLength(2);
    const coveredDivisions = dbPkg.SHIPPING_ZONE_SEED_DATA.flatMap((zone) => zone.divisions);
    expect(new Set(coveredDivisions).size).toBe(8);

    const migrationSql = fs.readFileSync(
      path.resolve(currentDir, '../../../database/migrations/0003_mushy_flatman.sql'),
      'utf8'
    );
    expect(migrationSql).toContain(
      'CONSTRAINT `uq_cart_items_cart_key` UNIQUE(`cart_id`,`item_key`)'
    );
    expect(migrationSql).toContain('CONSTRAINT `uq_orders_order_number` UNIQUE(`order_number`)');
    expect(migrationSql).toContain(
      'CONSTRAINT `uq_payment_transactions_gateway_ref` UNIQUE(`gateway`,`transaction_ref`)'
    );
    expect(migrationSql).toContain('design_public_id');
    expect(migrationSql).toContain('production_spec_json');

    const phase2MigrationSql = fs.readFileSync(
      path.resolve(repoRoot, 'database/migrations/0004_yellow_puma.sql'),
      'utf8'
    );
    expect(phase2MigrationSql).toContain('CREATE TABLE `designs`');
    expect(phase2MigrationSql).toContain('CREATE TABLE `design_assets`');
    expect(phase2MigrationSql).toContain('CREATE TABLE `design_versions`');
    expect(phase2MigrationSql).toContain('CREATE TABLE `design_print_exports`');
  });
});
