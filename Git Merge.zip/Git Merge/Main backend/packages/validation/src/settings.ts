import { z } from 'zod';

export const systemSettingValueTypeSchema = z.enum(['string', 'number', 'boolean', 'json']);

export const systemSettingKeySchema = z
  .string()
  .trim()
  .min(3)
  .max(128)
  .regex(
    /^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+$/,
    'Setting key must be dot-namespaced lowercase identifiers (e.g., platform.brand_name)'
  );

export const upsertSystemSettingSchema = z.object({
  key: systemSettingKeySchema,
  category: z.string().trim().min(2).max(64),
  value: z.unknown(),
  valueType: systemSettingValueTypeSchema,
  description: z.string().trim().max(500).optional(),
  isPublic: z.boolean().default(false),
});

export type UpsertSystemSettingInput = z.infer<typeof upsertSystemSettingSchema>;
