import {
  CATALOG_SORT_OPTIONS,
  GARMENT_SIZES,
  IMAGE_VIEW_TYPES,
  PRINT_AREA_SURFACES,
  PRINT_METHOD_CODES,
  PRODUCT_STATUSES,
} from '@your-choice/shared-types';
import { z } from 'zod';
import { decimalMoneySchema, paginationQuerySchema, slugSchema } from './common.js';

const COLOR_HEX_REGEX = /^#[0-9A-Fa-f]{6}$/;

const optionalNullableString = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((value) => (value.length === 0 ? null : value))
    .nullable()
    .optional();

const optionalNullableDecimal = z
  .string()
  .trim()
  .refine((value) => value.length === 0 || /^\d{1,10}(?:\.\d{1,2})?$/.test(value), {
    message: 'Money value must be a valid decimal with up to 2 decimal places',
  })
  .transform((value) => (value.length === 0 ? null : value))
  .nullable()
  .optional();

export const colorHexSchema = z
  .string()
  .trim()
  .regex(COLOR_HEX_REGEX, 'Color hex must be #RRGGBB format')
  .transform((value) => value.toUpperCase());

export const mockupBoundsSchema = z
  .object({
    x: z.coerce.number().min(0).max(0.95),
    y: z.coerce.number().min(0).max(0.95),
    width: z.coerce.number().min(0.05).max(1),
    height: z.coerce.number().min(0.05).max(1),
    rotationDeg: z.coerce.number().min(-180).max(180).default(0),
  })
  .refine((b) => b.x + b.width <= 1.0001, {
    path: ['width'],
    message: 'Mockup print width exceeds garment canvas right edge (x + width <= 1)',
  })
  .refine((b) => b.y + b.height <= 1.0001, {
    path: ['height'],
    message: 'Mockup print height exceeds garment canvas bottom edge (y + height <= 1)',
  });

export const uvRegionSchema = z
  .object({
    islandKey: z.string().trim().min(1).max(64),
    meshTarget: z.string().trim().min(1).max(64),
    uMin: z.coerce.number().min(0).max(1),
    uMax: z.coerce.number().min(0).max(1),
    vMin: z.coerce.number().min(0).max(1),
    vMax: z.coerce.number().min(0).max(1),
  })
  .refine((uv) => uv.uMin < uv.uMax && uv.vMin < uv.vMax, {
    message: 'UV island bounds must satisfy uMin < uMax and vMin < vMax',
  });

export const createCategorySchema = z.object({
  slug: slugSchema,
  nameEn: z.string().trim().min(2).max(120),
  nameBn: z.string().trim().min(2).max(120),
  descriptionEn: optionalNullableString(500),
  descriptionBn: optionalNullableString(500),
  sortOrder: z.coerce.number().int().min(0).max(10_000).default(0),
  isActive: z.boolean().default(true),
});

export const updateCategorySchema = createCategorySchema
  .partial()
  .refine((values) => Object.values(values).some((val) => val !== undefined), {
    message: 'Provide at least one category field to update',
  });

export const createProductImageSchema = z.object({
  variantId: z.string().uuid().nullable().optional(),
  viewType: z.enum(IMAGE_VIEW_TYPES),
  url: z
    .string()
    .trim()
    .min(1, 'Image URL or path is required')
    .max(500)
    .refine(
      (value) => value.startsWith('/') || /^https?:\/\//i.test(value),
      'Image URL must start with / or http(s)://'
    ),
  altTextEn: z.string().trim().min(2).max(240),
  altTextBn: z.string().trim().min(2).max(240),
  sortOrder: z.coerce.number().int().min(0).max(1000).default(0),
  isPrimary: z.boolean().default(false),
});

export const createVariantSchema = z.object({
  sku: z
    .string()
    .trim()
    .min(3, 'SKU must be at least 3 characters')
    .max(80)
    .regex(/^[A-Za-z0-9_-]+$/, 'SKU may contain only letters, numbers, hyphens, and underscores')
    .transform((value) => value.toUpperCase()),
  colorNameEn: z.string().trim().min(2).max(60),
  colorNameBn: z.string().trim().min(2).max(60),
  colorHex: colorHexSchema,
  sizeCode: z.enum(GARMENT_SIZES),
  priceOverride: optionalNullableDecimal,
  stockQuantity: z.coerce.number().int().min(0).max(1_000_000).default(0),
  isActive: z.boolean().default(true),
});

export const updateVariantSchema = createVariantSchema
  .partial()
  .refine((values) => Object.values(values).some((val) => val !== undefined), {
    message: 'Provide at least one variant field to update',
  });

export const upsertPrintAreaSchema = z.object({
  surfaceKey: z.enum(PRINT_AREA_SURFACES),
  labelEn: z.string().trim().min(2).max(80),
  labelBn: z.string().trim().min(2).max(80),
  physicalWidthMm: z.coerce.number().int().min(20).max(600),
  physicalHeightMm: z.coerce.number().int().min(20).max(800),
  targetDpi: z.coerce.number().int().min(150).max(600).default(300),
  safeInsetMm: z.coerce.number().int().min(0).max(50).default(10),
  mockupBounds: mockupBoundsSchema,
  uvRegion: uvRegionSchema.nullable().optional(),
  printMethods: z.array(z.enum(PRINT_METHOD_CODES)).min(1).default(['dtf']),
  surchargeAmount: decimalMoneySchema.default('0.00'),
  isDefault: z.boolean().default(false),
  isActive: z.boolean().default(true),
  sortOrder: z.coerce.number().int().min(0).max(100).default(0),
});

export const updatePrintAreaSchema = upsertPrintAreaSchema
  .partial()
  .refine((values) => Object.values(values).some((val) => val !== undefined), {
    message: 'Provide at least one print area field to update',
  });

export const createProductSchema = z.object({
  categoryId: z.string().uuid('Select a valid category'),
  slug: slugSchema,
  skuPrefix: z
    .string()
    .trim()
    .min(2)
    .max(40)
    .regex(/^[A-Za-z0-9-]+$/, 'SKU prefix may contain only letters, numbers, and hyphens')
    .transform((value) => value.toUpperCase()),
  nameEn: z.string().trim().min(2).max(160),
  nameBn: z.string().trim().min(2).max(160),
  subtitleEn: optionalNullableString(240),
  subtitleBn: optionalNullableString(240),
  descriptionEn: z.string().trim().min(10).max(5000),
  descriptionBn: z.string().trim().min(10).max(5000),
  fabricSpecEn: optionalNullableString(240),
  fabricSpecBn: optionalNullableString(240),
  gsm: z.coerce.number().int().min(80).max(600).nullable().optional(),
  fitType: optionalNullableString(64),
  basePrice: decimalMoneySchema,
  isCustomizable: z.boolean().default(true),
  status: z.enum(PRODUCT_STATUSES).default('draft'),
  featuredOrder: z.coerce.number().int().min(1).max(10_000).nullable().optional(),
  images: z.array(createProductImageSchema).max(12).optional(),
  variants: z.array(createVariantSchema).max(50).optional(),
  printAreas: z.array(upsertPrintAreaSchema).max(10).optional(),
});

export const updateProductSchema = createProductSchema
  .omit({ images: true, variants: true, printAreas: true })
  .partial()
  .refine((values) => Object.values(values).some((val) => val !== undefined), {
    message: 'Provide at least one product field to update',
  });

export const catalogQuerySchema = paginationQuerySchema.extend({
  category: slugSchema.optional(),
  search: z.string().trim().max(120).optional(),
  size: z.enum(GARMENT_SIZES).optional(),
  color: colorHexSchema.optional(),
  customizable: z
    .enum(['true', 'false'])
    .transform((val) => val === 'true')
    .optional(),
  sort: z.enum(CATALOG_SORT_OPTIONS).default('featured'),
});

export const adminCatalogQuerySchema = catalogQuerySchema.extend({
  status: z.enum(PRODUCT_STATUSES).optional(),
});

export const productSlugParamSchema = z.object({
  slug: slugSchema,
});

export const categoryPublicIdParamSchema = z.object({
  categoryPublicId: z.string().uuid('Invalid category identifier'),
});

export const productPublicIdParamSchema = z.object({
  productPublicId: z.string().uuid('Invalid product identifier'),
});

export const variantParamsSchema = z.object({
  productPublicId: z.string().uuid('Invalid product identifier'),
  variantPublicId: z.string().uuid('Invalid variant identifier'),
});

export const imageParamsSchema = z.object({
  productPublicId: z.string().uuid('Invalid product identifier'),
  imagePublicId: z.string().uuid('Invalid image identifier'),
});

export const printAreaParamsSchema = z.object({
  productPublicId: z.string().uuid('Invalid product identifier'),
  printAreaPublicId: z.string().uuid('Invalid print area identifier'),
});

export type CreateCategoryInput = z.infer<typeof createCategorySchema>;
export type UpdateCategoryInput = z.infer<typeof updateCategorySchema>;
export type CreateProductInput = z.infer<typeof createProductSchema>;
export type CreateProductFormInput = z.input<typeof createProductSchema>;
export type UpdateProductInput = z.infer<typeof updateProductSchema>;
export type CreateVariantInput = z.infer<typeof createVariantSchema>;
export type CreateVariantFormInput = z.input<typeof createVariantSchema>;
export type UpdateVariantInput = z.infer<typeof updateVariantSchema>;
export type CreateProductImageInput = z.infer<typeof createProductImageSchema>;
export type UpsertPrintAreaInput = z.infer<typeof upsertPrintAreaSchema>;
export type UpdatePrintAreaInput = z.infer<typeof updatePrintAreaSchema>;
export type CatalogQueryInput = z.infer<typeof catalogQuerySchema>;
export type AdminCatalogQueryInput = z.infer<typeof adminCatalogQuerySchema>;
