import { z } from 'zod';

/**
 * Validates trimmed non-empty strings up to a sensible max length.
 */
export function nonEmptyString(maxLength = 255) {
  return z.string().trim().min(1, 'Value cannot be empty').max(maxLength);
}

/**
 * Validates URL-safe lowercase kebab-case slugs.
 */
export const slugSchema = z
  .string()
  .trim()
  .min(2)
  .max(120)
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'Slug must be lowercase alphanumeric kebab-case');

/**
 * Validates decimal money strings without floating-point ambiguity.
 */
export const decimalMoneySchema = z
  .string()
  .trim()
  .regex(
    /^\d{1,10}(?:\.\d{1,2})?$/,
    'Money value must be a valid decimal with up to 2 decimal places'
  );

/**
 * Standard pagination query parameters for list endpoints.
 */
export const paginationQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export type PaginationQuery = z.infer<typeof paginationQuerySchema>;
