import { BANGLADESH_DIVISIONS, ORDER_STATUSES, PAYMENT_METHODS } from '@your-choice/shared-types';
import { z } from 'zod';
import { emailSchema, phoneSchema } from './auth.js';
import { paginationQuerySchema } from './common.js';

const optionalPostalCode = z
  .string()
  .trim()
  .refine((val) => val.length === 0 || /^\d{4,10}$/.test(val), {
    message: 'Postal code must be 4–10 digits',
  })
  .transform((val) => (val.length === 0 ? null : val))
  .nullable()
  .optional();

export const addCartItemSchema = z.object({
  variantId: z.string().uuid('Invalid variant identifier'),
  quantity: z.coerce
    .number()
    .int()
    .min(1, 'Quantity must be at least 1')
    .max(50, 'Max 50 per line'),
});

export const updateCartItemSchema = z.object({
  quantity: z.coerce
    .number()
    .int()
    .min(1, 'Quantity must be at least 1')
    .max(50, 'Max 50 per line'),
});

export const cartItemIdParamSchema = z.object({
  itemId: z.string().uuid('Invalid cart item identifier'),
});

export const shippingQuoteQuerySchema = z.object({
  division: z.enum(BANGLADESH_DIVISIONS, {
    message: 'Select a valid Bangladesh division',
  }),
  subtotal: z
    .string()
    .trim()
    .regex(/^\d{1,10}(?:\.\d{1,2})?$/, 'Subtotal must be a valid decimal amount')
    .default('0.00'),
});

export const checkoutShippingAddressSchema = z.object({
  label: z.string().trim().min(2).max(60).nullable().optional(),
  recipientName: z
    .string()
    .trim()
    .min(2, 'Recipient name must be at least 2 characters')
    .max(120, 'Recipient name must be 120 characters or fewer'),
  phone: phoneSchema,
  division: z.enum(BANGLADESH_DIVISIONS, {
    message: 'Select a valid Bangladesh division',
  }),
  district: z.string().trim().min(2, 'District is required').max(80),
  area: z.string().trim().min(2, 'Area / Thana is required').max(120),
  addressLine: z
    .string()
    .trim()
    .min(5, 'Street / house address must be at least 5 characters')
    .max(255),
  postalCode: optionalPostalCode,
});

export const createOrderSchema = z
  .object({
    savedAddressId: z.string().uuid('Invalid saved address identifier').optional(),
    shippingAddress: checkoutShippingAddressSchema.optional(),
    customerEmail: emailSchema.optional(),
    customerPhone: phoneSchema.optional(),
    paymentMethod: z.enum(PAYMENT_METHODS).default('cod'),
    customerNote: z
      .string()
      .trim()
      .max(500, 'Order note must be 500 characters or fewer')
      .transform((val) => (val.length === 0 ? null : val))
      .nullable()
      .optional(),
  })
  .refine((data) => Boolean(data.savedAddressId || data.shippingAddress), {
    path: ['shippingAddress'],
    message: 'Select a saved delivery address or provide a Bangladesh shipping address',
  });

export const orderNumberParamSchema = z.object({
  orderNumber: z
    .string()
    .trim()
    .regex(/^YC-\d{8}-[A-Z0-9]{6}$/, 'Invalid order number format'),
});

export const cancelOwnOrderSchema = z.object({
  reason: z
    .string()
    .trim()
    .min(3, 'Please provide a brief cancellation reason')
    .max(255, 'Cancellation reason must be 255 characters or fewer')
    .optional(),
});

export const adminOrderListQuerySchema = paginationQuerySchema.extend({
  status: z.enum(ORDER_STATUSES).optional(),
  search: z.string().trim().max(120).optional(),
});

export const adminUpdateOrderStatusSchema = z.object({
  toStatus: z.enum(ORDER_STATUSES),
  note: z
    .string()
    .trim()
    .max(500)
    .transform((val) => (val.length === 0 ? null : val))
    .nullable()
    .optional(),
});

export const adminSettleCodPaymentSchema = z.object({
  transactionRef: z
    .string()
    .trim()
    .min(3, 'Enter cash collection receipt or courier reference')
    .max(120),
  note: z.string().trim().max(255).optional(),
});

export const paymentWebhookGatewayParamSchema = z.object({
  gateway: z.enum(['bkash', 'nagad', 'sslcommerz_card']),
});

export const paymentWebhookPayloadSchema = z.object({
  orderNumber: z.string().trim().min(5).max(32),
  providerPaymentId: z.string().trim().min(3).max(120),
  transactionRef: z.string().trim().min(3).max(120),
  status: z.enum(['paid', 'failed', 'cancelled']),
  amount: z
    .string()
    .trim()
    .regex(/^\d{1,10}(?:\.\d{1,2})?$/),
  currencyCode: z.string().trim().length(3).default('BDT'),
});

export type AddCartItemInput = z.infer<typeof addCartItemSchema>;
export type UpdateCartItemInput = z.infer<typeof updateCartItemSchema>;
export type CheckoutShippingAddressInput = z.infer<typeof checkoutShippingAddressSchema>;
export type CreateOrderInput = z.infer<typeof createOrderSchema>;
export type CreateOrderFormInput = z.input<typeof createOrderSchema>;
export type CancelOwnOrderInput = z.infer<typeof cancelOwnOrderSchema>;
export type AdminOrderListQueryInput = z.infer<typeof adminOrderListQuerySchema>;
export type AdminUpdateOrderStatusInput = z.infer<typeof adminUpdateOrderStatusSchema>;
export type AdminSettleCodPaymentInput = z.infer<typeof adminSettleCodPaymentSchema>;
export type PaymentWebhookPayloadInput = z.infer<typeof paymentWebhookPayloadSchema>;
