import { USER_ROLES } from '@your-choice/shared-types';
import { z } from 'zod';

export const emailSchema = z
  .string()
  .trim()
  .min(3, 'Email address is required')
  .max(255, 'Email address must be 255 characters or fewer')
  .email('Enter a valid email address')
  .transform((value) => value.toLowerCase());

export const fullNameSchema = z
  .string()
  .trim()
  .min(2, 'Full name must be at least 2 characters')
  .max(120, 'Full name must be 120 characters or fewer');

const PHONE_REGEX = /^\+?[0-9\s-]{8,20}$/;

export const phoneSchema = z
  .string()
  .trim()
  .regex(PHONE_REGEX, 'Enter a valid phone number (8–20 digits)')
  .max(32);

export const optionalPhoneSchema = z
  .string()
  .trim()
  .refine((value) => value.length === 0 || (PHONE_REGEX.test(value) && value.length <= 32), {
    message: 'Enter a valid phone number (8–20 digits)',
  })
  .transform((value) => (value.length === 0 ? null : value))
  .nullable()
  .optional();

export const preferredLocaleSchema = z.enum(['en', 'bn']);

export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .max(128, 'Password must be 128 characters or fewer')
  .regex(/[A-Za-z]/, 'Password must contain at least one letter')
  .regex(/\d/, 'Password must contain at least one number');

const baseRegisterFields = {
  fullName: fullNameSchema,
  email: emailSchema,
  password: passwordSchema,
  phone: optionalPhoneSchema,
  preferredLocale: preferredLocaleSchema.default('en'),
};

export const registerRequestSchema = z
  .object({
    ...baseRegisterFields,
    confirmPassword: z.string().optional(),
  })
  .superRefine((values, ctx) => {
    if (values.confirmPassword !== undefined && values.confirmPassword !== values.password) {
      ctx.addIssue({
        code: 'custom',
        path: ['confirmPassword'],
        message: 'Passwords do not match',
      });
    }
  });

export const registerFormSchema = z
  .object({
    ...baseRegisterFields,
    confirmPassword: z.string().min(1, 'Please confirm your password'),
  })
  .refine((values) => values.password === values.confirmPassword, {
    path: ['confirmPassword'],
    message: 'Passwords do not match',
  });

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Password is required').max(128),
  rememberMe: z.boolean().default(true),
});

export const updateProfileSchema = z
  .object({
    fullName: fullNameSchema.optional(),
    phone: optionalPhoneSchema,
    preferredLocale: preferredLocaleSchema.optional(),
  })
  .refine(
    (values) =>
      values.fullName !== undefined ||
      values.phone !== undefined ||
      values.preferredLocale !== undefined,
    {
      message: 'Provide at least one profile field to update',
    }
  );

export const userPublicIdParamSchema = z.object({
  userPublicId: z.string().uuid('Invalid user identifier'),
});

export const updateUserRolesSchema = z.object({
  roles: z
    .array(z.enum(USER_ROLES))
    .min(1, 'At least one role is required')
    .max(USER_ROLES.length)
    .transform((roles) => Array.from(new Set(roles))),
});

export type RegisterRequestInput = z.infer<typeof registerRequestSchema>;
export type RegisterFormInput = z.input<typeof registerFormSchema>;
export type LoginInput = z.input<typeof loginSchema>;
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
export type UpdateUserRolesInput = z.infer<typeof updateUserRolesSchema>;
