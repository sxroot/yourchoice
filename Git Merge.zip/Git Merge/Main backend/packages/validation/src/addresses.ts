import { BANGLADESH_DIVISIONS } from '@your-choice/shared-types';
import { z } from 'zod';
import { phoneSchema } from './auth.js';

const optionalPostalCodeSchema = z
  .string()
  .trim()
  .refine((value) => value.length === 0 || /^\d{4,10}$/.test(value), {
    message: 'Postal code must be 4–10 digits',
  })
  .transform((value) => (value.length === 0 ? null : value))
  .nullable()
  .optional();

export const createAddressSchema = z.object({
  label: z
    .string()
    .trim()
    .min(2, 'Label must be at least 2 characters')
    .max(60, 'Label must be 60 characters or fewer'),
  recipientName: z
    .string()
    .trim()
    .min(2, 'Recipient name must be at least 2 characters')
    .max(120, 'Recipient name must be 120 characters or fewer'),
  phone: phoneSchema,
  division: z.enum(BANGLADESH_DIVISIONS, {
    message: 'Select a valid Bangladesh division',
  }),
  district: z
    .string()
    .trim()
    .min(2, 'District is required')
    .max(80, 'District must be 80 characters or fewer'),
  area: z
    .string()
    .trim()
    .min(2, 'Area / Thana is required')
    .max(120, 'Area / Thana must be 120 characters or fewer'),
  addressLine: z
    .string()
    .trim()
    .min(5, 'Street / house address must be at least 5 characters')
    .max(255, 'Street address must be 255 characters or fewer'),
  postalCode: optionalPostalCodeSchema,
  isDefault: z.boolean().default(false),
});

export const updateAddressSchema = createAddressSchema
  .partial()
  .refine((values) => Object.values(values).some((val) => val !== undefined), {
    message: 'Provide at least one address field to update',
  });

export const addressPublicIdParamSchema = z.object({
  addressPublicId: z.string().uuid('Invalid address identifier'),
});

export type CreateAddressInput = z.infer<typeof createAddressSchema>;
export type CreateAddressFormInput = z.input<typeof createAddressSchema>;
export type UpdateAddressInput = z.infer<typeof updateAddressSchema>;
