import {
  ALLOWED_STUDIO_FONT_FAMILIES,
  type CanonicalDesignDocument,
  type CanonicalDesignObject,
  type DesignValidationIssue,
  type DesignValidationReport,
  PRINT_AREA_SURFACES,
  type PrintAreaSurfaceKey,
  type ProductPrintAreaDTO,
  STUDIO_SHAPE_KINDS,
} from '@your-choice/shared-types';
import { z } from 'zod';
import { paginationQuerySchema } from './common.js';

const hexColorSchema = z
  .string()
  .trim()
  .regex(/^#[0-9a-fA-F]{6}$/, 'Color must be a valid 6-digit HEX code');

const normalizedCoord = z.number().finite().min(-0.25).max(1.25);
const normalizedSize = z.number().finite().min(0.005).max(1.5);

const objectBaseFields = {
  id: z.string().trim().min(1).max(80),
  name: z.string().trim().min(1).max(120),
  x: normalizedCoord,
  y: normalizedCoord,
  width: normalizedSize,
  height: normalizedSize,
  rotationDeg: z.number().finite().min(-360).max(360).default(0),
  opacity: z.number().finite().min(0).max(1).default(1),
  flipX: z.boolean().default(false),
  flipY: z.boolean().default(false),
  visible: z.boolean().default(true),
  locked: z.boolean().default(false),
};

export const canonicalTextObjectSchema = z.object({
  ...objectBaseFields,
  type: z.literal('text'),
  text: z.string().min(1, 'Text cannot be empty').max(500),
  fontFamily: z.string().trim().min(1).max(100),
  fontSizeRatio: z.number().finite().min(0.01).max(0.85),
  fontWeight: z.union([z.literal(400), z.literal(600), z.literal(700)]).default(600),
  fontStyle: z.enum(['normal', 'italic']).default('normal'),
  textAlign: z.enum(['left', 'center', 'right']).default('center'),
  lineHeight: z.number().finite().min(0.75).max(3).default(1.18),
  letterSpacing: z.number().finite().min(-100).max(800).default(0),
  fill: hexColorSchema,
  stroke: hexColorSchema.nullable().default(null),
  strokeWidth: z.number().finite().min(0).max(40).default(0),
});

export const canonicalShapeObjectSchema = z.object({
  ...objectBaseFields,
  type: z.literal('shape'),
  shapeKind: z.enum(STUDIO_SHAPE_KINDS),
  fill: hexColorSchema,
  stroke: hexColorSchema.nullable().default(null),
  strokeWidth: z.number().finite().min(0).max(40).default(0),
  cornerRadius: z.number().finite().min(0).max(200).default(0),
});

export const canonicalGraphicObjectSchema = z.object({
  ...objectBaseFields,
  type: z.literal('graphic'),
  graphicId: z.string().trim().min(1).max(80),
  pathData: z.string().trim().min(4).max(4000),
  viewBoxSize: z.number().finite().min(16).max(1024),
  fill: hexColorSchema,
  stroke: hexColorSchema.nullable().default(null),
  strokeWidth: z.number().finite().min(0).max(40).default(0),
});

export const canonicalImageObjectSchema = z.object({
  ...objectBaseFields,
  type: z.literal('image'),
  assetId: z.string().uuid('Invalid image asset identifier'),
  naturalWidthPx: z.number().int().min(1).max(20000),
  naturalHeightPx: z.number().int().min(1).max(20000),
  cropRect: z
    .object({
      x: z.number().finite().min(0).max(1),
      y: z.number().finite().min(0).max(1),
      width: z.number().finite().min(0.01).max(1),
      height: z.number().finite().min(0.01).max(1),
    })
    .nullable()
    .default(null),
});

const leafDesignObjectSchema = z.discriminatedUnion('type', [
  canonicalTextObjectSchema,
  canonicalShapeObjectSchema,
  canonicalGraphicObjectSchema,
  canonicalImageObjectSchema,
]);

export const canonicalGroupObjectSchema = z.object({
  ...objectBaseFields,
  type: z.literal('group'),
  children: z.array(leafDesignObjectSchema).min(1).max(40),
});

export const canonicalDesignObjectSchema = z.discriminatedUnion('type', [
  canonicalTextObjectSchema,
  canonicalShapeObjectSchema,
  canonicalGraphicObjectSchema,
  canonicalImageObjectSchema,
  canonicalGroupObjectSchema,
]);

export const canonicalDesignSurfaceSchema = z.object({
  surfaceKey: z.enum(PRINT_AREA_SURFACES),
  printAreaId: z.string().uuid('Invalid print area identifier'),
  physicalWidthMm: z.number().int().min(20).max(1000),
  physicalHeightMm: z.number().int().min(20).max(1200),
  targetDpi: z.number().int().min(150).max(600),
  safeInsetMm: z.number().int().min(0).max(100),
  objects: z.array(canonicalDesignObjectSchema).max(60),
});

export const canonicalDesignDocumentSchema = z.object({
  schemaVersion: z.literal(1),
  designId: z.string().uuid().nullable().default(null),
  productId: z.string().uuid('Invalid product identifier'),
  productVariantId: z.string().uuid('Invalid variant identifier'),
  preferredMode: z.enum(['2d', '3d']).default('2d'),
  version: z.number().int().min(1).max(100000),
  surfaces: z.partialRecord(z.enum(PRINT_AREA_SURFACES), canonicalDesignSurfaceSchema),
  updatedAt: z.string().trim().min(10).max(64),
});

export const createDesignSchema = z.object({
  title: z
    .string()
    .trim()
    .min(2, 'Design title must be at least 2 characters')
    .max(140, 'Design title must be 140 characters or fewer'),
  document: canonicalDesignDocumentSchema,
});

export const updateDesignSchema = z.object({
  title: z
    .string()
    .trim()
    .min(2, 'Design title must be at least 2 characters')
    .max(140, 'Design title must be 140 characters or fewer')
    .optional(),
  document: canonicalDesignDocumentSchema,
  createVersionSnapshot: z.boolean().default(false),
});

export const designListQuerySchema = paginationQuerySchema;

export const designIdParamSchema = z.object({
  designId: z.string().uuid('Invalid design identifier'),
});

export const designAssetIdParamSchema = z.object({
  assetId: z.string().uuid('Invalid asset identifier'),
});

export const designExportParamSchema = z.object({
  exportId: z.string().uuid('Invalid export identifier'),
});

export const designSurfaceExportParamSchema = z.object({
  designId: z.string().uuid('Invalid design identifier'),
  surfaceKey: z.enum(PRINT_AREA_SURFACES),
});

export const addDesignToCartSchema = z.object({
  variantId: z.string().uuid('Invalid variant identifier').optional(),
  quantity: z.coerce.number().int().min(1).max(50).default(1),
  note: z.string().trim().max(255).optional(),
});

const OUT_OF_BOUNDS_EPSILON = 0.012;

function inspectLeafObject(
  obj: CanonicalDesignObject,
  surfaceKey: PrintAreaSurfaceKey,
  printArea: ProductPrintAreaDTO,
  parentBounds: { x: number; y: number; width: number; height: number } | null,
  knownAssetIds: ReadonlySet<string> | null,
  issues: DesignValidationIssue[]
): void {
  const absX = parentBounds ? parentBounds.x + obj.x * parentBounds.width : obj.x;
  const absY = parentBounds ? parentBounds.y + obj.y * parentBounds.height : obj.y;
  const absWidth = parentBounds ? obj.width * parentBounds.width : obj.width;
  const absHeight = parentBounds ? obj.height * parentBounds.height : obj.height;

  if (obj.visible) {
    if (
      absX < -OUT_OF_BOUNDS_EPSILON ||
      absY < -OUT_OF_BOUNDS_EPSILON ||
      absX + absWidth > 1 + OUT_OF_BOUNDS_EPSILON ||
      absY + absHeight > 1 + OUT_OF_BOUNDS_EPSILON
    ) {
      issues.push({
        code: 'OUTSIDE_PRINT_BOUNDS',
        severity: 'error',
        surfaceKey,
        objectId: obj.id,
        objectName: obj.name,
        messageEn: `"${obj.name}" extends outside the printable ${printArea.labelEn} canvas.`,
        messageBn: `"${obj.name}" প্রিন্ট এরিয়ার সীমানার বাইরে চলে গেছে (${printArea.labelBn})।`,
      });
    } else {
      const safeX = printArea.safeInsetMm / printArea.physicalWidthMm;
      const safeY = printArea.safeInsetMm / printArea.physicalHeightMm;
      if (
        safeX > 0 &&
        safeY > 0 &&
        (absX < safeX - 0.002 ||
          absY < safeY - 0.002 ||
          absX + absWidth > 1 - safeX + 0.002 ||
          absY + absHeight > 1 - safeY + 0.002)
      ) {
        issues.push({
          code: 'SAFE_ZONE_BLEED',
          severity: 'warning',
          surfaceKey,
          objectId: obj.id,
          objectName: obj.name,
          messageEn: `"${obj.name}" crosses the ${printArea.safeInsetMm}mm safe print margin.`,
          messageBn: `"${obj.name}" ${printArea.safeInsetMm} মিমি সেফ মার্জিনের খুব কাছাকাছি রয়েছে।`,
        });
      }
    }
  }

  if (obj.type === 'text') {
    if (!ALLOWED_STUDIO_FONT_FAMILIES.includes(obj.fontFamily)) {
      issues.push({
        code: 'DISALLOWED_FONT',
        severity: 'error',
        surfaceKey,
        objectId: obj.id,
        objectName: obj.name,
        messageEn: `Font "${obj.fontFamily}" is not in the approved commercial studio font set.`,
        messageBn: `"${obj.fontFamily}" ফন্টটি অনুমোদিত বাণিজ্যিক স্টুডিও ফন্ট তালিকায় নেই।`,
      });
    }
    return;
  }

  if (obj.type === 'image') {
    if (knownAssetIds && !knownAssetIds.has(obj.assetId)) {
      issues.push({
        code: 'MISSING_IMAGE_ASSET',
        severity: 'error',
        surfaceKey,
        objectId: obj.id,
        objectName: obj.name,
        messageEn: `Uploaded artwork for "${obj.name}" could not be verified.`,
        messageBn: `"${obj.name}"-এর আপলোড করা ছবিটি যাচাই করা যায়নি।`,
      });
    }

    const cropW = obj.cropRect ? obj.cropRect.width : 1;
    const cropH = obj.cropRect ? obj.cropRect.height : 1;
    const effectiveSourceWidthPx = obj.naturalWidthPx * cropW;
    const effectiveSourceHeightPx = obj.naturalHeightPx * cropH;

    const physicalPrintWidthIn = (absWidth * printArea.physicalWidthMm) / 25.4;
    const physicalPrintHeightIn = (absHeight * printArea.physicalHeightMm) / 25.4;

    if (physicalPrintWidthIn > 0 && physicalPrintHeightIn > 0) {
      const dpiX = effectiveSourceWidthPx / physicalPrintWidthIn;
      const dpiY = effectiveSourceHeightPx / physicalPrintHeightIn;
      const minDpi = Math.round(Math.min(dpiX, dpiY));

      if (minDpi < 120) {
        issues.push({
          code: 'LOW_EFFECTIVE_DPI',
          severity: 'error',
          surfaceKey,
          objectId: obj.id,
          objectName: obj.name,
          effectiveDpi: minDpi,
          messageEn: `"${obj.name}" effective resolution is ${minDpi} DPI (minimum 120 DPI required for DTF output).`,
          messageBn: `"${obj.name}"-এর রেজোলিউশন মাত্র ${minDpi} DPI (ডিটিএফ প্রিন্টের জন্য কমপক্ষে 120 DPI প্রয়োজন)।`,
        });
      } else if (minDpi < printArea.targetDpi) {
        issues.push({
          code: 'LOW_EFFECTIVE_DPI',
          severity: 'warning',
          surfaceKey,
          objectId: obj.id,
          objectName: obj.name,
          effectiveDpi: minDpi,
          messageEn: `"${obj.name}" is ${minDpi} DPI at current size (${printArea.targetDpi} DPI recommended for sharpest print).`,
          messageBn: `"${obj.name}" বর্তমান সাইজে ${minDpi} DPI (সেরা প্রিন্টের জন্য ${printArea.targetDpi} DPI প্রয়োজন)।`,
        });
      }
    }
    return;
  }

  if (obj.type === 'group') {
    for (const child of obj.children) {
      inspectLeafObject(
        child,
        surfaceKey,
        printArea,
        { x: absX, y: absY, width: absWidth, height: absHeight },
        knownAssetIds,
        issues
      );
    }
  }
}

/**
 * Validates canonical design layers across active product print areas on both client and server.
 */
export function validateDesignDocumentForPrint(
  document: CanonicalDesignDocument,
  printAreas: readonly ProductPrintAreaDTO[],
  knownAssetIds: ReadonlySet<string> | null = null
): DesignValidationReport {
  const issues: DesignValidationIssue[] = [];
  const activePrintAreasByKey = new Map(
    printAreas.filter((pa) => pa.isActive).map((pa) => [pa.surfaceKey, pa])
  );

  const activePrintSurfaces: PrintAreaSurfaceKey[] = [];

  for (const [key, surface] of Object.entries(document.surfaces)) {
    const surfaceKey = key as PrintAreaSurfaceKey;
    const area = activePrintAreasByKey.get(surfaceKey);

    if (!area) {
      if (surface.objects.length > 0) {
        issues.push({
          code: 'UNKNOWN_SURFACE',
          severity: 'error',
          surfaceKey,
          objectId: null,
          objectName: null,
          messageEn: `Print area "${surfaceKey}" is not configured for this garment.`,
          messageBn: `"${surfaceKey}" প্রিন্ট এরিয়াটি এই পোশাকের জন্য কনফিগার করা নেই।`,
        });
      }
      continue;
    }

    const visibleObjects = surface.objects.filter((obj) => obj.visible);
    if (visibleObjects.length > 0) {
      activePrintSurfaces.push(surfaceKey);
    }

    for (const obj of surface.objects) {
      inspectLeafObject(obj, surfaceKey, area, null, knownAssetIds, issues);
    }
  }

  if (activePrintSurfaces.length === 0) {
    issues.push({
      code: 'NO_ARTWORK',
      severity: 'error',
      surfaceKey: printAreas[0]?.surfaceKey ?? 'front',
      objectId: null,
      objectName: null,
      messageEn:
        'Add at least one visible design element to a garment print area before exporting or ordering.',
      messageBn: 'এক্সপোর্ট বা অর্ডার করার আগে কমপক্ষে একটি দৃশ্যমান ডিজাইন উপাদান যোগ করুন।',
    });
  }

  const errorCount = issues.filter((issue) => issue.severity === 'error').length;
  const warningCount = issues.filter((issue) => issue.severity === 'warning').length;

  return {
    isValidForPrint: errorCount === 0,
    errorCount,
    warningCount,
    activePrintSurfaces,
    issues,
  };
}

export type CanonicalDesignDocumentInput = z.infer<typeof canonicalDesignDocumentSchema>;
export type CreateDesignInput = z.infer<typeof createDesignSchema>;
export type UpdateDesignInput = z.infer<typeof updateDesignSchema>;
export type AddDesignToCartInput = z.infer<typeof addDesignToCartSchema>;
