import { describe, expect, it } from 'vitest';
import {
  addCartItemSchema,
  adminSettleCodPaymentSchema,
  adminUpdateOrderStatusSchema,
  cancelOwnOrderSchema,
  canonicalDesignDocumentSchema,
  catalogQuerySchema,
  createAddressSchema,
  createDesignSchema,
  createOrderSchema,
  createProductSchema,
  createVariantSchema,
  decimalMoneySchema,
  loginSchema,
  orderNumberParamSchema,
  paginationQuerySchema,
  paymentWebhookPayloadSchema,
  registerFormSchema,
  registerRequestSchema,
  shippingQuoteQuerySchema,
  slugSchema,
  updateCartItemSchema,
  updateProfileSchema,
  updateUserRolesSchema,
  upsertPrintAreaSchema,
  upsertSystemSettingSchema,
  validateDesignDocumentForPrint,
} from '../src/index.js';

describe('validation schemas', () => {
  it('validates kebab-case slugs', () => {
    expect(slugSchema.safeParse('classic-crewneck-tee').success).toBe(true);
    expect(slugSchema.safeParse('Classic Tee!').success).toBe(false);
  });

  it('validates decimal money strings with up to 2 decimals', () => {
    expect(decimalMoneySchema.safeParse('1299.50').success).toBe(true);
    expect(decimalMoneySchema.safeParse('1299').success).toBe(true);
    expect(decimalMoneySchema.safeParse('12.345').success).toBe(false);
    expect(decimalMoneySchema.safeParse('-10.00').success).toBe(false);
  });

  it('coerces pagination parameters with safe defaults', () => {
    const parsed = paginationQuerySchema.parse({});
    expect(parsed).toEqual({ page: 1, pageSize: 20 });

    expect(paginationQuerySchema.safeParse({ page: '2', pageSize: '50' }).success).toBe(true);
    expect(paginationQuerySchema.safeParse({ page: 0 }).success).toBe(false);
    expect(paginationQuerySchema.safeParse({ pageSize: 500 }).success).toBe(false);
  });

  it('validates dot-namespaced system settings keys', () => {
    const valid = upsertSystemSettingSchema.safeParse({
      key: 'platform.brand_name',
      category: 'platform',
      value: 'YOUR CHOICE',
      valueType: 'string',
      isPublic: true,
    });
    expect(valid.success).toBe(true);

    const invalid = upsertSystemSettingSchema.safeParse({
      key: 'InvalidKey',
      category: 'platform',
      value: 'x',
      valueType: 'string',
    });
    expect(invalid.success).toBe(false);
  });

  it('validates registration email normalization, password strength, and confirmPassword matching', () => {
    const parsed = registerFormSchema.parse({
      fullName: '  Arafat Hossain  ',
      email: '  Arafat@Example.COM ',
      password: 'Password123',
      confirmPassword: 'Password123',
    });

    expect(parsed.fullName).toBe('Arafat Hossain');
    expect(parsed.email).toBe('arafat@example.com');
    expect(parsed.preferredLocale).toBe('en');

    const mismatch = registerRequestSchema.safeParse({
      fullName: 'Arafat Hossain',
      email: 'arafat@example.com',
      password: 'Password123',
      confirmPassword: 'Password999',
    });
    expect(mismatch.success).toBe(false);

    const weakPassword = registerRequestSchema.safeParse({
      fullName: 'Arafat Hossain',
      email: 'arafat@example.com',
      password: 'onlyletters',
    });
    expect(weakPassword.success).toBe(false);
  });

  it('validates login, profile updates, and RBAC role assignment payloads', () => {
    const login = loginSchema.parse({
      email: 'User@Example.com',
      password: 'Password123',
    });
    expect(login.email).toBe('user@example.com');
    expect(login.rememberMe).toBe(true);

    expect(updateProfileSchema.safeParse({}).success).toBe(false);
    expect(
      updateProfileSchema.safeParse({ fullName: 'Nusrat Jahan', preferredLocale: 'bn' }).success
    ).toBe(true);

    const roles = updateUserRolesSchema.parse({
      roles: ['customer', 'creator', 'customer'],
    });
    expect(roles.roles).toEqual(['customer', 'creator']);

    const blankPhoneReg = registerFormSchema.parse({
      fullName: 'Tariqul Islam',
      email: 'tariqul@example.com',
      password: 'StrongPass123',
      confirmPassword: 'StrongPass123',
      phone: '   ',
    });
    expect(blankPhoneReg.phone).toBeNull();

    const blankPhoneUpdate = updateProfileSchema.parse({ phone: '' });
    expect(blankPhoneUpdate.phone).toBeNull();

    const invalidPhone = registerFormSchema.safeParse({
      fullName: 'Tariqul Islam',
      email: 'tariqul@example.com',
      password: 'StrongPass123',
      confirmPassword: 'StrongPass123',
      phone: '123',
    });
    expect(invalidPhone.success).toBe(false);
  });

  it('validates Bangladesh customer addresses, product variants, and normalized print-area bounds', () => {
    const address = createAddressSchema.parse({
      label: 'Home',
      recipientName: 'Sadia Rahman',
      phone: '+8801712345678',
      division: 'Dhaka',
      district: 'Dhaka',
      area: 'Dhanmondi',
      addressLine: 'House 24, Road 9A',
      postalCode: '',
      isDefault: true,
    });
    expect(address.postalCode).toBeNull();
    expect(address.division).toBe('Dhaka');

    expect(
      createAddressSchema.safeParse({
        label: 'Home',
        recipientName: 'Sadia Rahman',
        phone: '+8801712345678',
        division: 'InvalidDivision',
        district: 'Dhaka',
        area: 'Dhanmondi',
        addressLine: 'House 24, Road 9A',
      }).success
    ).toBe(false);

    const variant = createVariantSchema.parse({
      sku: 'yc-tee-blk-m',
      colorNameEn: 'Obsidian Black',
      colorNameBn: 'অবসিডিয়ান কালো',
      colorHex: '#0f172a',
      sizeCode: 'M',
      priceOverride: '',
      stockQuantity: '25',
    });
    expect(variant.sku).toBe('YC-TEE-BLK-M');
    expect(variant.colorHex).toBe('#0F172A');
    expect(variant.priceOverride).toBeNull();
    expect(variant.stockQuantity).toBe(25);

    const validPrintArea = upsertPrintAreaSchema.parse({
      surfaceKey: 'front',
      labelEn: 'Front Chest Canvas',
      labelBn: 'সামনের চেস্ট',
      physicalWidthMm: 280,
      physicalHeightMm: 360,
      mockupBounds: { x: 0.3, y: 0.25, width: 0.4, height: 0.5, rotationDeg: 0 },
      uvRegion: {
        islandKey: 'tee_front',
        meshTarget: 'garment_front',
        uMin: 0.1,
        uMax: 0.5,
        vMin: 0.2,
        vMax: 0.7,
      },
    });
    expect(validPrintArea.targetDpi).toBe(300);

    const overflowingPrintArea = upsertPrintAreaSchema.safeParse({
      surfaceKey: 'front',
      labelEn: 'Overflow',
      labelBn: 'ওভারফ্লো',
      physicalWidthMm: 280,
      physicalHeightMm: 360,
      mockupBounds: { x: 0.7, y: 0.25, width: 0.5, height: 0.5, rotationDeg: 0 },
    });
    expect(overflowingPrintArea.success).toBe(false);

    const product = createProductSchema.parse({
      categoryId: '10000000-0000-4000-8000-000000000001',
      slug: 'heavy-crew-tee',
      skuPrefix: 'yc-hvy',
      nameEn: 'Heavy Crew Tee',
      nameBn: 'হেভি ক্রু টি-শার্ট',
      descriptionEn: 'Premium heavyweight Bangladesh combed cotton tee.',
      descriptionBn: 'প্রিমিয়াম হেভিওয়েট বাংলাদেশি কম্বড কটন টি-শার্ট।',
      basePrice: '890.00',
    });
    expect(product.skuPrefix).toBe('YC-HVY');

    const query = catalogQuerySchema.parse({
      category: 't-shirts',
      color: '#1d4ed8',
      customizable: 'true',
      sort: 'price_asc',
    });
    expect(query.color).toBe('#1D4ED8');
    expect(query.customizable).toBe(true);
    expect(query.sort).toBe('price_asc');
  });

  it('validates Phase 1C cart, Bangladesh shipping quote, checkout, and webhook contracts', () => {
    expect(
      addCartItemSchema.safeParse({
        variantId: '10000000-0000-4000-8000-000000000001',
        quantity: 2,
      }).success
    ).toBe(true);
    expect(
      addCartItemSchema.safeParse({
        variantId: 'not-a-uuid',
        quantity: 1,
      }).success
    ).toBe(false);
    expect(updateCartItemSchema.safeParse({ quantity: 0 }).success).toBe(false);
    expect(updateCartItemSchema.safeParse({ quantity: 51 }).success).toBe(false);

    const quote = shippingQuoteQuerySchema.parse({ division: 'Chattogram', subtotal: '1500.00' });
    expect(quote.division).toBe('Chattogram');
    expect(quote.subtotal).toBe('1500.00');
    expect(
      shippingQuoteQuerySchema.safeParse({ division: 'Atlantis', subtotal: '500' }).success
    ).toBe(false);

    const guestOrder = createOrderSchema.parse({
      customerEmail: 'Guest@Example.COM',
      customerPhone: '+8801712345678',
      shippingAddress: {
        recipientName: 'Tanvir Ahmed',
        phone: '01712345678',
        division: 'Dhaka',
        district: 'Dhaka',
        area: 'Banani',
        addressLine: 'House 12, Road 4, Banani',
        postalCode: '1213',
      },
      paymentMethod: 'cod',
      customerNote: 'Call before delivery',
    });
    expect(guestOrder.customerEmail).toBe('guest@example.com');
    expect(guestOrder.paymentMethod).toBe('cod');

    expect(createOrderSchema.safeParse({ paymentMethod: 'cod' }).success).toBe(false);
    expect(orderNumberParamSchema.safeParse({ orderNumber: 'YC-20261115-AB12CD' }).success).toBe(
      true
    );
    expect(orderNumberParamSchema.safeParse({ orderNumber: 'bad-order' }).success).toBe(false);

    expect(cancelOwnOrderSchema.safeParse({ reason: 'Changed size' }).success).toBe(true);
    expect(cancelOwnOrderSchema.safeParse({ reason: 'x' }).success).toBe(false);

    expect(
      adminUpdateOrderStatusSchema.safeParse({ toStatus: 'confirmed', note: 'Verified call' })
        .success
    ).toBe(true);
    expect(adminSettleCodPaymentSchema.safeParse({ transactionRef: 'COD-SLIP-001' }).success).toBe(
      true
    );
    expect(
      paymentWebhookPayloadSchema.safeParse({
        orderNumber: 'YC-20261115-AB12CD',
        providerPaymentId: 'bkash-trx-1',
        transactionRef: 'TRX9988',
        status: 'paid',
        amount: '1570.00',
        currencyCode: 'BDT',
      }).success
    ).toBe(true);
  });

  it('validates Phase 2 canonical design documents, print bounds, font allowlist, and DPI warnings', () => {
    const productId = '10000000-0000-4000-8000-000000000010';
    const variantId = '10000000-0000-4000-8000-000000000011';
    const printAreaId = '10000000-0000-4000-8000-000000000012';
    const assetId = '10000000-0000-4000-8000-000000000013';

    const parsed = createDesignSchema.parse({
      title: 'Dhaka Skyline Tee',
      document: {
        schemaVersion: 1,
        productId,
        productVariantId: variantId,
        preferredMode: '2d',
        version: 1,
        updatedAt: '2026-11-15T12:00:00.000Z',
        surfaces: {
          front: {
            surfaceKey: 'front',
            printAreaId,
            physicalWidthMm: 280,
            physicalHeightMm: 360,
            targetDpi: 300,
            safeInsetMm: 10,
            objects: [
              {
                id: 'txt-1',
                type: 'text',
                name: 'Brand Headline',
                x: 0.2,
                y: 0.2,
                width: 0.5,
                height: 0.14,
                rotationDeg: 0,
                opacity: 1,
                flipX: false,
                flipY: false,
                visible: true,
                locked: false,
                text: 'YOUR CHOICE',
                fontFamily: 'Outfit',
                fontSizeRatio: 0.09,
                fontWeight: 700,
                fontStyle: 'normal',
                textAlign: 'center',
                lineHeight: 1.15,
                letterSpacing: 40,
                fill: '#1D4ED8',
                stroke: null,
                strokeWidth: 0,
              },
              {
                id: 'img-1',
                type: 'image',
                name: 'Low-Res Upload',
                x: 0.2,
                y: 0.45,
                width: 0.5,
                height: 0.4,
                rotationDeg: 0,
                opacity: 1,
                flipX: false,
                flipY: false,
                visible: true,
                locked: false,
                assetId,
                naturalWidthPx: 900,
                naturalHeightPx: 900,
                cropRect: null,
              },
            ],
          },
        },
      },
    });
    expect(canonicalDesignDocumentSchema.safeParse(parsed.document).success).toBe(true);

    const printArea = {
      id: printAreaId,
      surfaceKey: 'front' as const,
      labelEn: 'Front Chest',
      labelBn: 'সামনে',
      physicalWidthMm: 280,
      physicalHeightMm: 360,
      targetDpi: 300,
      safeInsetMm: 10,
      coordinateSpace: 'normalized_0_1' as const,
      mockupBounds: { x: 0.3, y: 0.22, width: 0.4, height: 0.48, rotationDeg: 0 },
      uvRegion: null,
      printMethods: ['dtf'],
      surchargeAmount: '120.00',
      currencyCode: 'BDT',
      isDefault: true,
      isActive: true,
      sortOrder: 0,
    };

    const report = validateDesignDocumentForPrint(parsed.document, [printArea], new Set([assetId]));
    expect(report.isValidForPrint).toBe(true);
    const dpiIssue = report.issues.find((issue) => issue.code === 'LOW_EFFECTIVE_DPI');
    expect(dpiIssue).toBeDefined();
    expect(dpiIssue?.severity).toBe('warning');
    expect(dpiIssue?.effectiveDpi ?? 999).toBeLessThan(200);

    const badDoc = JSON.parse(JSON.stringify(parsed.document)) as typeof parsed.document;
    badDoc.surfaces.front!.objects[0] = {
      ...badDoc.surfaces.front!.objects[0]!,
      x: 0.9,
      width: 0.3,
    };
    const outOfBoundsReport = validateDesignDocumentForPrint(
      badDoc,
      [printArea],
      new Set([assetId])
    );
    expect(outOfBoundsReport.isValidForPrint).toBe(false);
    expect(outOfBoundsReport.issues.some((issue) => issue.code === 'OUTSIDE_PRINT_BOUNDS')).toBe(
      true
    );
  });
});
