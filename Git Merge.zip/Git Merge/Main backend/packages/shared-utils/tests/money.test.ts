import { describe, expect, it } from 'vitest';
import {
  addDecimalStrings,
  decimalToMinorUnits,
  formatMoneyDisplay,
  minorUnitsToDecimal,
} from '../src/money.js';

describe('money utilities', () => {
  it('avoids floating-point drift when adding 0.10 + 0.20', () => {
    expect(addDecimalStrings('0.10', '0.20')).toBe('0.30');
  });

  it('converts decimal strings to minor units and back accurately', () => {
    expect(decimalToMinorUnits('1250.5')).toBe(125050n);
    expect(minorUnitsToDecimal(125050n)).toBe('1250.50');
    expect(decimalToMinorUnits('-42.09')).toBe(-4209n);
    expect(minorUnitsToDecimal(-4209n)).toBe('-42.09');
  });

  it('throws on invalid decimal formats', () => {
    expect(() => decimalToMinorUnits('12.345')).toThrow();
    expect(() => decimalToMinorUnits('abc')).toThrow();
  });

  it('formats money strings with uppercase currency codes', () => {
    expect(formatMoneyDisplay('850', 'bdt')).toBe('BDT 850.00');
  });
});
