const DECIMAL_PATTERN = /^(-)?(\d+)(?:\.(\d{1,2}))?$/;

/**
 * Parses a fixed-decimal money string (e.g. "499.95") into integer minor units (e.g. 49995n)
 * without using IEEE-754 floating-point arithmetic.
 */
export function decimalToMinorUnits(value: string): bigint {
  const trimmed = value.trim();
  const match = DECIMAL_PATTERN.exec(trimmed);
  if (!match) {
    throw new Error(`Invalid decimal money string: "${value}"`);
  }

  const [, sign, wholePart = '0', fractionalPart = ''] = match;
  const paddedFraction = fractionalPart.padEnd(2, '0');
  const minor = BigInt(wholePart) * 100n + BigInt(paddedFraction);

  return sign === '-' ? -minor : minor;
}

/**
 * Formats integer minor units (e.g. 49995n) back into a canonical 2-decimal string ("499.95").
 */
export function minorUnitsToDecimal(minorUnits: bigint): string {
  const isNegative = minorUnits < 0n;
  const absolute = isNegative ? -minorUnits : minorUnits;
  const whole = absolute / 100n;
  const fraction = (absolute % 100n).toString().padStart(2, '0');

  return `${isNegative ? '-' : ''}${whole.toString()}.${fraction}`;
}

/**
 * Adds two decimal money strings exactly using minor-unit integer arithmetic.
 */
export function addDecimalStrings(a: string, b: string): string {
  return minorUnitsToDecimal(decimalToMinorUnits(a) + decimalToMinorUnits(b));
}

/**
 * Formats a decimal string with an ISO 4217 currency prefix/code for display.
 */
export function formatMoneyDisplay(value: string, currencyCode: string): string {
  const minor = decimalToMinorUnits(value);
  const canonical = minorUnitsToDecimal(minor);
  return `${currencyCode.toUpperCase()} ${canonical}`;
}
