/**
 * Converts arbitrary text into a clean lowercase URL slug.
 */
export function slugify(input: string): string {
  return input
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Parses a comma-separated CORS origins string into a clean array of origin strings.
 */
export function parseCorsOrigins(raw: string): string[] {
  return raw
    .split(',')
    .map((origin) => origin.trim())
    .filter((origin) => origin.length > 0);
}

/**
 * Truncates long text safely with an ellipsis without exceeding maxLength.
 */
export function truncateText(input: string, maxLength: number): string {
  if (maxLength <= 0) {
    return '';
  }
  if (input.length <= maxLength) {
    return input;
  }
  if (maxLength <= 3) {
    return input.slice(0, maxLength);
  }
  return `${input.slice(0, maxLength - 3)}...`;
}
