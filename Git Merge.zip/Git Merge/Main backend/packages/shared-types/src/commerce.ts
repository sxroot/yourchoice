import type { BangladeshDivision } from './addresses.js';
import type { PaginationMeta } from './api.js';
import type { GarmentSizeCode } from './catalog.js';

export const ORDER_STATUSES = [
  'pending',
  'confirmed',
  'processing',
  'packed',
  'shipped',
  'delivered',
  'cancelled',
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const PAYMENT_METHODS = ['cod', 'bkash', 'nagad', 'sslcommerz_card'] as const;
export type PaymentMethod = (typeof PAYMENT_METHODS)[number];

export const PAYMENT_STATUSES = ['unpaid', 'pending', 'paid', 'failed', 'refunded'] as const;
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

export const PAYMENT_TRANSACTION_STATUSES = [
  'unpaid',
  'pending',
  'authorized',
  'paid',
  'failed',
  'cancelled',
  'refunded',
] as const;
export type PaymentTransactionStatus = (typeof PAYMENT_TRANSACTION_STATUSES)[number];

export const ALLOWED_ORDER_TRANSITIONS: Record<OrderStatus, readonly OrderStatus[]> = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['processing', 'cancelled'],
  processing: ['packed', 'cancelled'],
  packed: ['shipped'],
  shipped: ['delivered'],
  delivered: [],
  cancelled: [],
};

export const CUSTOMER_CANCELLABLE_STATUSES: readonly OrderStatus[] = ['pending', 'confirmed'];

export interface ShippingAddressSnapshotDTO {
  label: string | null;
  recipientName: string;
  phone: string;
  division: BangladeshDivision;
  district: string;
  area: string;
  addressLine: string;
  postalCode: string | null;
}

export interface ShippingZoneDTO {
  id: string;
  code: string;
  nameEn: string;
  nameBn: string;
  divisions: BangladeshDivision[];
  flatFee: string;
  freeShippingThreshold: string | null;
  estimatedDaysMin: number;
  estimatedDaysMax: number;
  currencyCode: string;
  isActive: boolean;
}

export interface ShippingQuoteDTO {
  division: BangladeshDivision;
  zone: ShippingZoneDTO;
  subtotal: string;
  shippingFee: string;
  freeShippingQualified: boolean;
  amountRemainingForFreeShipping: string | null;
  estimatedTotal: string;
  currencyCode: string;
}

export interface CartItemCustomizationDTO {
  designTitle?: string | null;
  designVersionNumber?: number | null;
  preferredMode?: '2d' | '3d' | null;
  surfaces: Array<{
    surfaceKey: string;
    labelEn: string;
    labelBn: string;
    previewImageRef?: string | null;
    surchargeAmount?: string | null;
  }>;
  note?: string | null;
}

export interface CartItemDTO {
  id: string;
  variantId: string;
  productId: string;
  productSlug: string;
  productNameEn: string;
  productNameBn: string;
  sku: string;
  colorNameEn: string;
  colorNameBn: string;
  colorHex: string;
  sizeCode: GarmentSizeCode;
  primaryImageUrl: string | null;
  quantity: number;
  availableStock: number;
  isVariantAvailable: boolean;
  unitPrice: string;
  customizationFee: string;
  lineTotal: string;
  currencyCode: string;
  designPublicId: string | null;
  customizationMeta: CartItemCustomizationDTO | null;
}

export interface CartDTO {
  id: string;
  items: CartItemDTO[];
  itemCount: number;
  subtotal: string;
  currencyCode: string;
  hasUnavailableItems: boolean;
  expiresAt: string;
}

export interface PaymentProviderAvailabilityDTO {
  method: PaymentMethod;
  labelEn: string;
  labelBn: string;
  descriptionEn: string;
  descriptionBn: string;
  enabled: boolean;
  configured: boolean;
  mode: 'offline_settlement' | 'redirect_webhook';
  unavailableReasonEn: string | null;
  unavailableReasonBn: string | null;
}

export interface CheckoutOptionsResponseData {
  shippingZones: ShippingZoneDTO[];
  paymentProviders: PaymentProviderAvailabilityDTO[];
}

export interface OrderItemProductionSpecDTO {
  printMethod?: string | null;
  targetDpi?: number | null;
  designVersionNumber?: number | null;
  preferredMode?: '2d' | '3d' | null;
  surfaces: Array<{
    surfaceKey: string;
    labelEn: string;
    labelBn: string;
    physicalWidthMm?: number | null;
    physicalHeightMm?: number | null;
    targetDpi?: number | null;
    printReadyAssetRef?: string | null;
  }>;
}

export interface OrderItemDTO {
  id: string;
  productSlug: string;
  productNameEn: string;
  productNameBn: string;
  sku: string;
  colorNameEn: string;
  colorNameBn: string;
  colorHex: string;
  sizeCode: string;
  primaryImageUrl: string | null;
  quantity: number;
  unitPrice: string;
  customizationFee: string;
  lineTotal: string;
  currencyCode: string;
  designPublicId: string | null;
  designTitle: string | null;
  productionSpec: OrderItemProductionSpecDTO | null;
}

export interface OrderStatusHistoryEntryDTO {
  id: number;
  fromStatus: OrderStatus | null;
  toStatus: OrderStatus;
  actorRole: string | null;
  note: string | null;
  createdAt: string;
}

export interface PaymentTransactionDTO {
  id: string;
  gateway: PaymentMethod;
  transactionRef: string | null;
  providerPaymentId: string | null;
  amount: string;
  currencyCode: string;
  status: PaymentTransactionStatus;
  verificationSource: string | null;
  verifiedAt: string | null;
  createdAt: string;
}

export interface OrderSummaryDTO {
  id: string;
  orderNumber: string;
  customerEmail: string;
  customerPhone: string;
  shippingDivision: BangladeshDivision;
  shippingZoneCode: string;
  shippingZoneName: string;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  subtotalAmount: string;
  shippingAmount: string;
  discountAmount: string;
  totalAmount: string;
  currencyCode: string;
  itemCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface OrderDetailDTO extends OrderSummaryDTO {
  shippingAddress: ShippingAddressSnapshotDTO;
  customerNote: string | null;
  cancelledAt: string | null;
  cancellationReason: string | null;
  canCustomerCancel: boolean;
  allowedNextStatuses: OrderStatus[];
  items: OrderItemDTO[];
  statusHistory: OrderStatusHistoryEntryDTO[];
  paymentTransactions: PaymentTransactionDTO[];
}

export interface CartResponseData {
  cart: CartDTO;
}

export interface ShippingZonesResponseData {
  zones: ShippingZoneDTO[];
}

export interface ShippingQuoteResponseData {
  quote: ShippingQuoteDTO;
}

export interface OrderListResponseData {
  orders: OrderSummaryDTO[];
  pagination: PaginationMeta;
}

export interface OrderDetailResponseData {
  order: OrderDetailDTO;
}
