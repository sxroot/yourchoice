export const BANGLADESH_DIVISIONS = [
  'Dhaka',
  'Chattogram',
  'Rajshahi',
  'Khulna',
  'Barishal',
  'Sylhet',
  'Rangpur',
  'Mymensingh',
] as const;

export type BangladeshDivision = (typeof BANGLADESH_DIVISIONS)[number];

export interface CustomerAddressDTO {
  id: string;
  label: string;
  recipientName: string;
  phone: string;
  division: BangladeshDivision;
  district: string;
  area: string;
  addressLine: string;
  postalCode: string | null;
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AddressListResponseData {
  addresses: CustomerAddressDTO[];
}

export interface AddressMutationResponseData {
  address: CustomerAddressDTO;
}

export interface DeleteAddressResponseData {
  deletedId: string;
}
