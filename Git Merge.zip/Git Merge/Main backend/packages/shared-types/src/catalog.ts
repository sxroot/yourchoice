import type { PaginationMeta } from './api.js';

export const GARMENT_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'] as const;
export type GarmentSizeCode = (typeof GARMENT_SIZES)[number];

export const PRODUCT_STATUSES = ['draft', 'active', 'archived'] as const;
export type ProductStatus = (typeof PRODUCT_STATUSES)[number];

export const IMAGE_VIEW_TYPES = ['front', 'back', 'detail', 'flat_lay'] as const;
export type ImageViewType = (typeof IMAGE_VIEW_TYPES)[number];

export const PRINT_AREA_SURFACES = [
  'front',
  'back',
  'left_chest',
  'right_sleeve',
  'left_sleeve',
] as const;
export type PrintAreaSurfaceKey = (typeof PRINT_AREA_SURFACES)[number];

export const PRINT_METHOD_CODES = [
  'dtf',
  'screen_print',
  'sublimation',
  'embroidery_ready',
] as const;
export type PrintMethodCode = (typeof PRINT_METHOD_CODES)[number];

export const CATALOG_SORT_OPTIONS = ['featured', 'newest', 'price_asc', 'price_desc'] as const;
export type CatalogSortOption = (typeof CATALOG_SORT_OPTIONS)[number];

export interface MockupBoundsDTO {
  x: number;
  y: number;
  width: number;
  height: number;
  rotationDeg: number;
}

export interface UvRegionDTO {
  islandKey: string;
  meshTarget: string;
  uMin: number;
  uMax: number;
  vMin: number;
  vMax: number;
}

export interface ProductCategoryDTO {
  id: string;
  slug: string;
  parentId: string | null;
  nameEn: string;
  nameBn: string;
  descriptionEn: string | null;
  descriptionBn: string | null;
  sortOrder: number;
  isActive: boolean;
  productCount: number;
}

export interface ProductImageDTO {
  id: string;
  variantId: string | null;
  viewType: ImageViewType;
  url: string;
  altTextEn: string;
  altTextBn: string;
  sortOrder: number;
  isPrimary: boolean;
}

export interface ProductVariantDTO {
  id: string;
  sku: string;
  colorNameEn: string;
  colorNameBn: string;
  colorHex: string;
  sizeCode: GarmentSizeCode;
  priceOverride: string | null;
  effectivePrice: string;
  currencyCode: string;
  stockQuantity: number;
  inStock: boolean;
  isActive: boolean;
}

/**
 * Editor-agnostic configurable print-area specification consumed by storefront previews,
 * Mode A (2D Fabric.js canvas), and Mode B (3D Three.js/R3F UV islands).
 */
export interface ProductPrintAreaDTO {
  id: string;
  surfaceKey: PrintAreaSurfaceKey;
  labelEn: string;
  labelBn: string;
  physicalWidthMm: number;
  physicalHeightMm: number;
  targetDpi: number;
  safeInsetMm: number;
  coordinateSpace: 'normalized_0_1';
  mockupBounds: MockupBoundsDTO;
  uvRegion: UvRegionDTO | null;
  printMethods: string[];
  surchargeAmount: string;
  currencyCode: string;
  isDefault: boolean;
  isActive: boolean;
  sortOrder: number;
}

export interface ProductColorSwatchDTO {
  colorNameEn: string;
  colorNameBn: string;
  colorHex: string;
}

export interface ProductSummaryDTO {
  id: string;
  slug: string;
  skuPrefix: string;
  category: {
    id: string;
    slug: string;
    nameEn: string;
    nameBn: string;
  };
  nameEn: string;
  nameBn: string;
  subtitleEn: string | null;
  subtitleBn: string | null;
  gsm: number | null;
  fitType: string | null;
  basePrice: string;
  minPrice: string;
  maxPrice: string;
  currencyCode: string;
  isCustomizable: boolean;
  status: ProductStatus;
  featuredOrder: number | null;
  primaryImage: ProductImageDTO | null;
  availableSizes: GarmentSizeCode[];
  availableColors: ProductColorSwatchDTO[];
  printSurfaces: PrintAreaSurfaceKey[];
  totalStock: number;
  variantCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface ProductDetailDTO extends ProductSummaryDTO {
  descriptionEn: string;
  descriptionBn: string;
  fabricSpecEn: string | null;
  fabricSpecBn: string | null;
  images: ProductImageDTO[];
  variants: ProductVariantDTO[];
  printAreas: ProductPrintAreaDTO[];
}

export interface CategoryListResponseData {
  categories: ProductCategoryDTO[];
}

export interface ProductListResponseData {
  products: ProductSummaryDTO[];
  pagination: PaginationMeta;
  facets: {
    sizes: GarmentSizeCode[];
    colors: ProductColorSwatchDTO[];
  };
}

export interface ProductDetailResponseData {
  product: ProductDetailDTO;
}

export interface AdminCategoryMutationResponseData {
  category: ProductCategoryDTO;
}

export interface AdminProductMutationResponseData {
  product: ProductDetailDTO;
}
