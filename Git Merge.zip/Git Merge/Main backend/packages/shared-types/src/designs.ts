import type { PaginationMeta } from './api.js';
import type { PrintAreaSurfaceKey } from './catalog.js';

export interface StudioFontPreset {
  id: string;
  family: string;
  label: string;
  script: 'latin' | 'bengali';
  sampleText: string;
  weights: readonly number[];
  fallbackStack: string;
}

export const STUDIO_FONT_PRESETS: readonly StudioFontPreset[] = [
  {
    id: 'space-grotesk',
    family: 'Space Grotesk',
    label: 'Space Grotesk',
    script: 'latin',
    sampleText: 'DESIGN STUDIO',
    weights: [400, 600, 700],
    fallbackStack: "'Space Grotesk Variable', 'Space Grotesk', sans-serif",
  },
  {
    id: 'plus-jakarta-sans',
    family: 'Plus Jakarta Sans',
    label: 'Plus Jakarta Sans',
    script: 'latin',
    sampleText: 'Modern Editorial',
    weights: [400, 600, 700],
    fallbackStack: "'Plus Jakarta Sans Variable', 'Plus Jakarta Sans', sans-serif",
  },
  {
    id: 'outfit',
    family: 'Outfit',
    label: 'Outfit',
    script: 'latin',
    sampleText: 'Dhaka Drop 26',
    weights: [400, 600, 700],
    fallbackStack: "'Outfit', sans-serif",
  },
  {
    id: 'bebas-neue',
    family: 'Bebas Neue',
    label: 'Bebas Neue',
    script: 'latin',
    sampleText: 'STREETWEAR',
    weights: [400],
    fallbackStack: "'Bebas Neue', sans-serif",
  },
  {
    id: 'barlow-condensed',
    family: 'Barlow Condensed',
    label: 'Barlow Condensed',
    script: 'latin',
    sampleText: 'ATHLETIC CLUB',
    weights: [400, 600, 700],
    fallbackStack: "'Barlow Condensed', sans-serif",
  },
  {
    id: 'syne',
    family: 'Syne',
    label: 'Syne',
    script: 'latin',
    sampleText: 'CREATIVE LAB',
    weights: [400, 600, 700],
    fallbackStack: "'Syne', sans-serif",
  },
  {
    id: 'jetbrains-mono',
    family: 'JetBrains Mono',
    label: 'JetBrains Mono',
    script: 'latin',
    sampleText: 'SPEC // 300 DPI',
    weights: [400, 600, 700],
    fallbackStack: "'JetBrains Mono Variable', 'JetBrains Mono', monospace",
  },
  {
    id: 'noto-sans-bengali',
    family: 'Noto Sans Bengali',
    label: 'Noto Sans Bengali (বাংলা)',
    script: 'bengali',
    sampleText: 'নিজেই ডিজাইন করুন',
    weights: [400, 600, 700],
    fallbackStack: "'Noto Sans Bengali', 'Hind Siliguri', sans-serif",
  },
  {
    id: 'hind-siliguri',
    family: 'Hind Siliguri',
    label: 'Hind Siliguri (হিন্দ শিলিগুড়ি)',
    script: 'bengali',
    sampleText: 'বাংলা স্টুডিও',
    weights: [400, 600, 700],
    fallbackStack: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif",
  },
  {
    id: 'baloo-da-2',
    family: 'Baloo Da 2',
    label: 'Baloo Da 2 (ডিসপ্লে বাংলা)',
    script: 'bengali',
    sampleText: 'রয়্যাল ঢাকা',
    weights: [400, 600, 700],
    fallbackStack: "'Baloo Da 2', 'Noto Sans Bengali', sans-serif",
  },
] as const;

export const ALLOWED_STUDIO_FONT_FAMILIES = STUDIO_FONT_PRESETS.map((f) => f.family);

export const STUDIO_SHAPE_KINDS = [
  'rect',
  'circle',
  'triangle',
  'star',
  'hexagon',
  'line',
] as const;
export type StudioShapeKind = (typeof STUDIO_SHAPE_KINDS)[number];

export interface StudioGraphicPackItem {
  id: string;
  labelEn: string;
  labelBn: string;
  category: 'emblem' | 'badge' | 'accent';
  viewBoxSize: number;
  pathData: string;
  defaultFill: string;
  defaultStroke: string;
}

/**
 * In-house original geometric vector packs cleared for unlimited commercial POD exports (MIT/CC0).
 */
export const STUDIO_GRAPHIC_PACK: readonly StudioGraphicPackItem[] = [
  {
    id: 'yc-crest-shield',
    labelEn: 'Varsity Shield',
    labelBn: 'ভার্সিটি শিল্ড',
    category: 'badge',
    viewBoxSize: 100,
    pathData:
      'M 50 6 L 88 18 V 48 C 88 71 72 86 50 95 C 28 86 12 71 12 48 V 18 Z M 50 20 L 24 28 V 48 C 24 63 35 74 50 81 C 65 74 76 63 76 48 V 28 Z',
    defaultFill: '#2563EB',
    defaultStroke: '#0F172A',
  },
  {
    id: 'yc-starburst',
    labelEn: 'Studio Starburst',
    labelBn: 'স্টুডিও স্টারবার্স্ট',
    category: 'emblem',
    viewBoxSize: 100,
    pathData:
      'M 50 4 L 61 32 L 91 26 L 71 49 L 94 70 L 63 72 L 66 96 L 47 75 L 25 92 L 32 63 L 6 58 L 29 42 L 15 16 L 42 29 Z',
    defaultFill: '#38BDF8',
    defaultStroke: '#0F172A',
  },
  {
    id: 'yc-lightning',
    labelEn: 'Kinetic Bolt',
    labelBn: 'বোল্ট আইকন',
    category: 'accent',
    viewBoxSize: 100,
    pathData: 'M 58 6 L 18 56 H 46 L 38 94 L 82 42 H 53 Z',
    defaultFill: '#22D3EE',
    defaultStroke: '#0F172A',
  },
  {
    id: 'yc-crown',
    labelEn: 'Signature Crown',
    labelBn: 'সিগনেচার ক্রাউন',
    category: 'emblem',
    viewBoxSize: 100,
    pathData: 'M 12 74 L 18 32 L 36 52 L 50 22 L 64 52 L 82 32 L 88 74 Z M 14 80 H 86 V 90 H 14 Z',
    defaultFill: '#F59E0B',
    defaultStroke: '#0F172A',
  },
  {
    id: 'yc-dhaka-wave',
    labelEn: 'River Horizon Pill',
    labelBn: 'নদী দিগন্ত ব্যাজ',
    category: 'badge',
    viewBoxSize: 100,
    pathData:
      'M 10 42 C 26 26 42 58 58 42 C 70 30 82 32 90 42 V 62 C 78 52 66 54 54 66 C 38 80 22 50 10 62 Z',
    defaultFill: '#1D4ED8',
    defaultStroke: '#38BDF8',
  },
  {
    id: 'yc-diamond-seal',
    labelEn: 'Precision Seal',
    labelBn: 'প্রিসিশন সিল',
    category: 'badge',
    viewBoxSize: 100,
    pathData: 'M 50 6 L 94 50 L 50 94 L 6 50 Z M 50 24 L 24 50 L 50 76 L 76 50 Z',
    defaultFill: '#3B82F6',
    defaultStroke: '#E2E8F0',
  },
] as const;

export type DesignObjectType = 'text' | 'shape' | 'graphic' | 'image' | 'group';

export interface CanonicalDesignObjectBase {
  id: string;
  type: DesignObjectType;
  name: string;
  /** Left coordinate relative to print area width in [0..1] (typically 0..1) */
  x: number;
  /** Top coordinate relative to print area height in [0..1] (typically 0..1) */
  y: number;
  /** Rendered bounding width relative to print area width in (0..1] */
  width: number;
  /** Rendered bounding height relative to print area height in (0..1] */
  height: number;
  rotationDeg: number;
  opacity: number;
  flipX: boolean;
  flipY: boolean;
  visible: boolean;
  locked: boolean;
}

export interface CanonicalTextObject extends CanonicalDesignObjectBase {
  type: 'text';
  text: string;
  fontFamily: string;
  fontSizeRatio: number; // Font height ratio relative to print area height (canonical across DPIs)
  fontWeight: 400 | 600 | 700;
  fontStyle: 'normal' | 'italic';
  textAlign: 'left' | 'center' | 'right';
  lineHeight: number;
  letterSpacing: number; // Fabric charSpacing / 1000 em-like spacing
  fill: string;
  stroke: string | null;
  strokeWidth: number; // Normalized to 1000px print width
}

export interface CanonicalShapeObject extends CanonicalDesignObjectBase {
  type: 'shape';
  shapeKind: StudioShapeKind;
  fill: string;
  stroke: string | null;
  strokeWidth: number;
  cornerRadius: number;
}

export interface CanonicalGraphicObject extends CanonicalDesignObjectBase {
  type: 'graphic';
  graphicId: string;
  pathData: string;
  viewBoxSize: number;
  fill: string;
  stroke: string | null;
  strokeWidth: number;
}

export interface CanonicalImageObject extends CanonicalDesignObjectBase {
  type: 'image';
  assetId: string;
  naturalWidthPx: number;
  naturalHeightPx: number;
  cropRect: {
    x: number;
    y: number;
    width: number;
    height: number;
  } | null;
}

export interface CanonicalGroupObject extends CanonicalDesignObjectBase {
  type: 'group';
  /** Children positioned in normalized [0..1] coordinates relative to this group's bounding box */
  children: Array<
    CanonicalTextObject | CanonicalShapeObject | CanonicalGraphicObject | CanonicalImageObject
  >;
}

export type CanonicalDesignObject =
  | CanonicalTextObject
  | CanonicalShapeObject
  | CanonicalGraphicObject
  | CanonicalImageObject
  | CanonicalGroupObject;

export interface CanonicalDesignSurface {
  surfaceKey: PrintAreaSurfaceKey;
  printAreaId: string;
  physicalWidthMm: number;
  physicalHeightMm: number;
  targetDpi: number;
  safeInsetMm: number;
  objects: CanonicalDesignObject[];
}

export interface CanonicalDesignDocument {
  schemaVersion: 1;
  designId: string | null;
  productId: string;
  productVariantId: string;
  preferredMode: '2d' | '3d';
  version: number;
  surfaces: Record<string, CanonicalDesignSurface>;
  updatedAt: string;
}

export type DesignValidationSeverity = 'error' | 'warning';

export interface DesignValidationIssue {
  code:
    | 'NO_ARTWORK'
    | 'OUTSIDE_PRINT_BOUNDS'
    | 'SAFE_ZONE_BLEED'
    | 'LOW_EFFECTIVE_DPI'
    | 'DISALLOWED_FONT'
    | 'MISSING_IMAGE_ASSET'
    | 'UNKNOWN_SURFACE';
  severity: DesignValidationSeverity;
  surfaceKey: string;
  objectId: string | null;
  objectName: string | null;
  messageEn: string;
  messageBn: string;
  effectiveDpi?: number | null;
}

export interface DesignValidationReport {
  isValidForPrint: boolean;
  errorCount: number;
  warningCount: number;
  activePrintSurfaces: PrintAreaSurfaceKey[];
  issues: DesignValidationIssue[];
}

export interface DesignAssetDTO {
  id: string;
  originalFilename: string;
  mimeType: string;
  byteSize: number;
  widthPx: number;
  heightPx: number;
  sha256: string;
  previewUrl: string;
  createdAt: string;
}

export interface DesignPrintExportDTO {
  id: string;
  designId: string;
  designVersionNumber: number;
  surfaceKey: PrintAreaSurfaceKey;
  widthPx: number;
  heightPx: number;
  dpi: number;
  byteSize: number;
  sha256: string;
  downloadUrl: string;
  createdAt: string;
}

export type DesignRecordStatus = 'draft' | 'saved' | 'ordered' | 'archived';

export interface DesignSummaryDTO {
  id: string;
  title: string;
  productId: string;
  productSlug: string;
  productNameEn: string;
  productNameBn: string;
  productVariantId: string;
  variantSku: string;
  variantColorNameEn: string;
  variantColorNameBn: string;
  variantColorHex: string;
  variantSizeCode: string;
  preferredMode: '2d' | '3d';
  currentVersionNumber: number;
  status: DesignRecordStatus;
  customizedSurfaces: PrintAreaSurfaceKey[];
  estimatedCustomizationFee: string;
  currencyCode: string;
  isValidForPrint: boolean;
  previewUrl: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface DesignDetailDTO extends DesignSummaryDTO {
  document: CanonicalDesignDocument;
  validation: DesignValidationReport;
  exports: DesignPrintExportDTO[];
}

export interface DesignAssetUploadResponseData {
  asset: DesignAssetDTO;
}

export interface DesignAssetListResponseData {
  assets: DesignAssetDTO[];
}

export interface DesignListResponseData {
  designs: DesignSummaryDTO[];
  pagination: PaginationMeta;
}

export interface DesignDetailResponseData {
  design: DesignDetailDTO;
}

export interface DesignPrintExportResponseData {
  printExport: DesignPrintExportDTO;
}
