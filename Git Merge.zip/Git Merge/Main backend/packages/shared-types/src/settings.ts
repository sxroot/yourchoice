export type SystemSettingValueType = 'string' | 'number' | 'boolean' | 'json';

export interface PublicSystemSetting {
  key: string;
  category: string;
  value: unknown;
  valueType: SystemSettingValueType;
  description: string | null;
}
