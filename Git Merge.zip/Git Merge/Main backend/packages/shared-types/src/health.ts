export type HealthOverallStatus = 'healthy' | 'degraded' | 'unhealthy';
export type DependencyStatus = 'up' | 'down';

export interface DatabaseHealthCheck {
  status: DependencyStatus;
  dialect: 'mariadb';
  latencyMs: number | null;
  error?: string;
}

export interface HealthCheckResponse {
  status: HealthOverallStatus;
  service: string;
  version: string;
  environment: 'development' | 'test' | 'staging' | 'production';
  uptimeSeconds: number;
  timestamp: string;
  checks: {
    database: DatabaseHealthCheck;
  };
}

export interface LivenessResponse {
  status: 'alive';
  service: string;
  timestamp: string;
}
