export const USER_ROLES = [
  'guest',
  'customer',
  'creator',
  'staff',
  'admin',
  'super_admin',
] as const;

export type UserRole = (typeof USER_ROLES)[number];
