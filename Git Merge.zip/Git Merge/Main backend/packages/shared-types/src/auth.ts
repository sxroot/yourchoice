import type { UserRole } from './roles.js';

export const USER_STATUSES = ['active', 'suspended', 'deleted'] as const;
export type UserStatus = (typeof USER_STATUSES)[number];

export const PREFERRED_LOCALES = ['en', 'bn'] as const;
export type PreferredLocale = (typeof PREFERRED_LOCALES)[number];

export const PERMISSION_CODES = [
  'profile:read:own',
  'profile:write:own',
  'creator:studio:access',
  'creator:design:submit',
  'catalog:read',
  'catalog:write',
  'orders:read:all',
  'orders:write',
  'users:read',
  'users:manage',
  'roles:manage',
  'audit:read',
  'system:settings:write',
] as const;

export type PermissionCode = (typeof PERMISSION_CODES)[number];

/**
 * Public-safe authenticated user view model.
 * Uses non-sequential `publicId` (`id`) and never exposes internal BIGINT PKs or password hashes.
 */
export interface AuthUserDTO {
  id: string;
  email: string;
  fullName: string;
  phone: string | null;
  preferredLocale: PreferredLocale;
  status: UserStatus;
  emailVerified: boolean;
  roles: UserRole[];
  permissions: PermissionCode[];
  createdAt: string;
}

/**
 * Public-safe active session metadata returned to clients.
 */
export interface AuthSessionDTO {
  id: string;
  expiresAt: string;
  lastSeenAt: string;
}

export interface CsrfTokenResponseData {
  csrfToken: string;
}

export interface AuthSuccessData {
  user: AuthUserDTO;
  session: AuthSessionDTO;
  csrfToken: string;
}

export interface AuthMeResponseData {
  authenticated: boolean;
  user: AuthUserDTO | null;
  session: AuthSessionDTO | null;
  csrfToken: string;
}

export interface LogoutResponseData {
  revoked: boolean;
}
