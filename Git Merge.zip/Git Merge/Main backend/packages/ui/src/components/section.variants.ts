import { cva } from 'class-variance-authority';

export const sectionVariants = cva('w-full', {
  variants: {
    tone: {
      canvas: 'bg-canvas text-ink',
      surface: 'bg-surface text-ink',
      muted: 'bg-surface-muted text-ink',
      dark: 'bg-dark-tech text-ink-inverse',
      charcoal: 'bg-surface-charcoal text-ink-inverse',
    },
    spacing: {
      none: 'py-0',
      sm: 'py-8 sm:py-12',
      md: 'py-12 sm:py-16',
      lg: 'py-16 sm:py-24',
    },
  },
  defaultVariants: {
    tone: 'canvas',
    spacing: 'md',
  },
});
