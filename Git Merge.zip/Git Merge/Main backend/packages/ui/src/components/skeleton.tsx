import type { HTMLAttributes } from 'react';
import { cn } from '../lib/utils';

/**
 * Neutral pulse placeholder reserving layout dimensions to prevent CLS.
 */
export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      aria-hidden="true"
      className={cn('motion-safe:animate-pulse rounded-lg bg-surface-muted', className)}
      {...props}
    />
  );
}
