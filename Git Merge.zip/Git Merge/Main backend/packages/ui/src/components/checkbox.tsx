import { Check } from 'lucide-react';
import { type InputHTMLAttributes, forwardRef } from 'react';
import { cn } from '../lib/utils';

export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  description?: string;
}

/**
 * Accessible native-backed checkbox control with >= 24px visual alignment and >= 44px touch target wrapper.
 */
export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(
  ({ className, label, description, id, disabled, ...props }, ref) => {
    return (
      <label
        htmlFor={id}
        className={cn(
          'inline-flex min-h-11 cursor-pointer items-start gap-2.5 select-none',
          disabled && 'cursor-not-allowed opacity-60',
          className
        )}
      >
        <span className="relative mt-0.5 inline-flex size-5 shrink-0 items-center justify-center">
          <input
            ref={ref}
            id={id}
            type="checkbox"
            disabled={disabled}
            className="peer size-5 cursor-pointer appearance-none rounded-md border border-border bg-surface transition-colors checked:border-accent checked:bg-accent focus-visible:ring-2 focus-visible:ring-accent-electric focus-visible:ring-offset-2 disabled:cursor-not-allowed"
            {...props}
          />
          <Check
            className="pointer-events-none absolute size-3.5 text-white opacity-0 transition-opacity peer-checked:opacity-100"
            strokeWidth={2.5}
            aria-hidden="true"
          />
        </span>
        {(label || description) && (
          <span className="flex flex-col text-left">
            {label && <span className="text-sm font-medium text-ink">{label}</span>}
            {description && <span className="text-xs text-ink-muted">{description}</span>}
          </span>
        )}
      </label>
    );
  }
);

Checkbox.displayName = 'Checkbox';
