import { cva } from 'class-variance-authority';

export const badgeVariants = cva(
  'inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium tracking-wide',
  {
    variants: {
      variant: {
        neutral: 'border-border bg-surface-muted text-ink',
        accent: 'border-accent/35 bg-accent-soft text-accent-ink',
        cyan: 'border-accent-cyan/35 bg-accent-cyan/10 text-accent-cyan-ink',
        'cyan-dark':
          'border-accent-cyan-bright/35 bg-accent-cyan-bright/10 text-accent-cyan-bright',
        dark: 'border-border-dark bg-surface-charcoal text-ink-silver',
        success: 'border-success/30 bg-success-soft text-success',
        warning: 'border-warning/30 bg-warning-soft text-warning',
        danger: 'border-danger/30 bg-danger-soft text-danger',
      },
    },
    defaultVariants: {
      variant: 'neutral',
    },
  }
);
