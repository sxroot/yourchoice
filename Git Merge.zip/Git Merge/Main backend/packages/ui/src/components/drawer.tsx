import * as DialogPrimitive from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import type { ComponentPropsWithoutRef, HTMLAttributes } from 'react';
import { cn } from '../lib/utils';

export const Drawer = DialogPrimitive.Root;
export const DrawerTrigger = DialogPrimitive.Trigger;
export const DrawerPortal = DialogPrimitive.Portal;
export const DrawerClose = DialogPrimitive.Close;

export type DrawerSide = 'left' | 'right' | 'bottom';

export interface DrawerContentProps extends ComponentPropsWithoutRef<
  typeof DialogPrimitive.Content
> {
  side?: DrawerSide;
}

const SIDE_CLASSES: Record<DrawerSide, string> = {
  right:
    'inset-y-0 right-0 h-dvh w-[min(92vw,24rem)] border-l rounded-none sm:rounded-l-2xl data-[state=closed]:translate-x-full data-[state=open]:translate-x-0',
  left: 'inset-y-0 left-0 h-dvh w-[min(92vw,24rem)] border-r rounded-none sm:rounded-r-2xl data-[state=closed]:-translate-x-full data-[state=open]:translate-x-0',
  bottom:
    'inset-x-0 bottom-0 max-h-[85dvh] w-full rounded-t-2xl border-t data-[state=closed]:translate-y-full data-[state=open]:translate-y-0',
};

/**
 * Accessible slide-over drawer and mobile bottom sheet built on Radix Dialog.
 */
export function DrawerContent({
  side = 'right',
  className,
  children,
  ...props
}: DrawerContentProps) {
  return (
    <DrawerPortal>
      <DialogPrimitive.Overlay
        className={cn(
          'fixed inset-0 z-50 bg-surface-dark/70 backdrop-blur-xs transition-opacity duration-200',
          'data-[state=closed]:opacity-0 data-[state=open]:opacity-100'
        )}
      />
      <DialogPrimitive.Content
        className={cn(
          'fixed z-50 flex flex-col border-border bg-surface p-6 text-ink shadow-elevated',
          'transition-transform duration-200 ease-[cubic-bezier(0.16,1,0.3,1)]',
          SIDE_CLASSES[side],
          className
        )}
        {...props}
      >
        {children}
        <DialogPrimitive.Close
          aria-label="Close drawer"
          className="absolute top-3 right-3 inline-flex size-11 cursor-pointer items-center justify-center rounded-lg text-ink-muted transition-colors hover:bg-surface-muted hover:text-ink"
        >
          <X className="size-5" aria-hidden="true" />
        </DialogPrimitive.Close>
      </DialogPrimitive.Content>
    </DrawerPortal>
  );
}

export function DrawerHeader({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('flex flex-col space-y-1.5 pr-10 text-left', className)} {...props} />;
}

export function DrawerFooter({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('mt-auto flex flex-col gap-2 pt-4', className)} {...props} />;
}

export function DrawerTitle({
  className,
  ...props
}: ComponentPropsWithoutRef<typeof DialogPrimitive.Title>) {
  return (
    <DialogPrimitive.Title
      className={cn('font-display text-lg font-semibold text-ink', className)}
      {...props}
    />
  );
}

export function DrawerDescription({
  className,
  ...props
}: ComponentPropsWithoutRef<typeof DialogPrimitive.Description>) {
  return (
    <DialogPrimitive.Description className={cn('text-sm text-ink-muted', className)} {...props} />
  );
}
