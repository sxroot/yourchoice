import { cva } from 'class-variance-authority';

export const buttonVariants = cva(
  'inline-flex cursor-pointer items-center justify-center gap-2 rounded-lg font-medium transition-[background-color,border-color,color,transform,box-shadow] duration-150 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50',
  {
    variants: {
      variant: {
        primary: 'bg-accent text-white shadow-sm hover:bg-accent-hover hover:shadow-glow-blue',
        electric: 'bg-brand-gradient text-white shadow-glow-blue hover:brightness-110',
        secondary: 'border border-border bg-surface text-ink hover:bg-surface-muted',
        outline: 'border border-accent/40 bg-transparent text-accent-ink hover:bg-accent-soft',
        dark: 'border border-border-dark bg-surface-charcoal text-ink-inverse hover:bg-surface-charcoal-elevated',
        ghost: 'bg-transparent text-ink hover:bg-surface-muted',
        danger: 'bg-danger text-white shadow-sm hover:opacity-90',
      },
      size: {
        sm: 'min-h-10 px-3.5 py-1.5 text-xs',
        md: 'min-h-11 px-4 py-2 text-sm',
        lg: 'min-h-12 px-6 py-3 text-base',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);
