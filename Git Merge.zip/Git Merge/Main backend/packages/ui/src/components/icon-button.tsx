import { Slot } from '@radix-ui/react-slot';
import type { VariantProps } from 'class-variance-authority';
import type { ComponentProps } from 'react';
import { cn } from '../lib/utils';
import { buttonVariants } from './button.variants';

export interface IconButtonProps
  extends
    Omit<ComponentProps<'button'>, 'aria-label'>,
    Pick<VariantProps<typeof buttonVariants>, 'variant'> {
  'aria-label': string;
  size?: 'md' | 'lg';
  asChild?: boolean;
}

/**
 * Square icon-only button enforcing a >= 44x44px minimum touch target.
 */
export function IconButton({
  className,
  variant = 'secondary',
  size = 'md',
  asChild = false,
  type = 'button',
  ...props
}: IconButtonProps) {
  const Comp = asChild ? Slot : 'button';

  return (
    <Comp
      {...(!asChild ? { type } : {})}
      className={cn(
        buttonVariants({ variant }),
        'min-h-11 min-w-11 shrink-0 p-0',
        size === 'lg' ? 'size-12' : 'size-11',
        className
      )}
      {...props}
    />
  );
}
