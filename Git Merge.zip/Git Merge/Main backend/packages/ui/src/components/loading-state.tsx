import { Loader2 } from 'lucide-react';
import type { HTMLAttributes } from 'react';
import { cn } from '../lib/utils';
import { Skeleton } from './skeleton';

export interface LoadingStateProps extends HTMLAttributes<HTMLDivElement> {
  label?: string;
  variant?: 'inline' | 'cards';
  count?: number;
}

/**
 * Accessible status-announced loading state supporting inline spinner or card skeletons.
 */
export function LoadingState({
  label = 'Loading content...',
  variant = 'inline',
  count = 3,
  className,
  ...props
}: LoadingStateProps) {
  if (variant === 'cards') {
    return (
      <div
        role="status"
        aria-live="polite"
        aria-label={label}
        className={cn('grid gap-4 sm:grid-cols-2 lg:grid-cols-3', className)}
        {...props}
      >
        <span className="sr-only">{label}</span>
        {Array.from({ length: count }).map((_, index) => (
          <div key={index} className="space-y-3 rounded-2xl border border-border bg-surface p-5">
            <Skeleton className="h-36 w-full rounded-xl" />
            <Skeleton className="h-4 w-2/3" />
            <Skeleton className="h-3 w-1/2" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div
      role="status"
      aria-live="polite"
      className={cn(
        'flex items-center gap-3 rounded-xl border border-border bg-surface-muted px-4 py-3 text-sm text-ink-muted',
        className
      )}
      {...props}
    >
      <Loader2
        className="size-4 shrink-0 text-accent motion-safe:animate-spin"
        aria-hidden="true"
      />
      <span>{label}</span>
    </div>
  );
}
