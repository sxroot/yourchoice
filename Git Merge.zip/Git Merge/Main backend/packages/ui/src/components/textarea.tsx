import type { ComponentProps } from 'react';
import { cn } from '../lib/utils';

export interface TextareaProps extends ComponentProps<'textarea'> {
  invalid?: boolean;
}

/**
 * Accessible multi-line textarea preserving >= 16px mobile input font sizing.
 */
export function Textarea({ className, invalid = false, rows = 4, ...props }: TextareaProps) {
  return (
    <textarea
      rows={rows}
      aria-invalid={invalid || undefined}
      className={cn(
        'flex min-h-24 w-full rounded-lg border bg-surface px-3.5 py-2.5 text-base text-ink shadow-xs transition-colors duration-150 sm:text-sm',
        'placeholder:text-ink-muted/80',
        'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent-electric',
        'disabled:cursor-not-allowed disabled:bg-surface-muted disabled:opacity-60',
        invalid
          ? 'border-danger focus-visible:outline-danger'
          : 'border-border hover:border-ink-muted/50',
        className
      )}
      {...props}
    />
  );
}
