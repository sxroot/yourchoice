import type { ComponentProps } from 'react';
import { cn } from '../lib/utils';

export interface InputProps extends ComponentProps<'input'> {
  invalid?: boolean;
}

/**
 * Accessible text input with 44px minimum height and >= 16px mobile text sizing.
 */
export function Input({ className, invalid = false, type = 'text', ...props }: InputProps) {
  return (
    <input
      type={type}
      aria-invalid={invalid || undefined}
      className={cn(
        'flex min-h-11 w-full rounded-lg border bg-surface px-3.5 py-2 text-base text-ink shadow-xs transition-colors duration-150 sm:text-sm',
        'placeholder:text-ink-muted/80',
        'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent-electric',
        'disabled:cursor-not-allowed disabled:bg-surface-muted disabled:opacity-60',
        invalid
          ? 'border-danger focus-visible:outline-danger'
          : 'border-border hover:border-ink-muted/50',
        className
      )}
      {...props}
    />
  );
}
